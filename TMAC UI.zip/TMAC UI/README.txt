<<--------------------------->>
<<--------------------------->>
File: TMAC UI Setup README File	
Version: 3.3.03.06
<<--------------------------->>
<<--------------------------->>

Base TMAC UI Build: 
svn://202.150.209.18/InterLink/Products/TMAC/ReleaseNotes/Base Binaries/TMAC Client/TMAC_UI
---------------------------------------------------------
NOTE:
Remove all other client specific or browser specific related files.
*x is the version number.
--------------------------------------------------------
FOR IE please remove MaterialIcons-Regular.woff and MaterialIcons-Regular.woff2 which is located @ TMAC_Client\TMAC_Client_UI\assets\icons\material-design-icons.
