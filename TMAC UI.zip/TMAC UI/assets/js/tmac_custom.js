﻿$(function () {
    try {
        var $switcher = $('#style_switcher'),
            $switcher_toggle = $('#style_switcher_toggle'),
            $theme_switcher = $('#theme_switcher'),
            $mini_sidebar_toggle = $('#style_sidebar_mini'),
            $slim_sidebar_toggle = $('#style_sidebar_slim'),
            $boxed_layout_toggle = $('#style_layout_boxed'),
            $accordion_mode_toggle = $('#accordion_mode_main_menu'),
            $html = $('html'),
            $body = $('body');


        $switcher_toggle.click(function (e) {
            e.preventDefault();
            $switcher.toggleClass('switcher_active');
            CheckForChangeColorSwitch();
        });

        $theme_switcher.children('li').click(function (e) {
            e.preventDefault();
            var $this = $(this),
                this_theme = $this.attr('data-app-theme');

            $theme_switcher.children('li').removeClass('active_theme');
            $(this).addClass('active_theme');
            $html
                .removeClass('app_theme_a app_theme_b app_theme_c app_theme_d app_theme_e app_theme_f app_theme_g app_theme_h app_theme_i app_theme_dark')
                .addClass(this_theme);

            if (this_theme == '') {
                localStorage.removeItem('altair_theme');
                $('#kendoCSS').attr('href', 'assets/css/Kendo/kendo.material.min.css');
            } else {
                localStorage.setItem("altair_theme", this_theme);
                if (this_theme == 'app_theme_dark') {
                    $('#kendoCSS').attr('href', 'assets/css/Kendo/kendo.materialblack.min.css')
                } else {
                    $('#kendoCSS').attr('href', 'assets/css/Kendo/kendo.material.min.css');
                }
            }

        });

        // hide style switcher
        $document.on('click keyup', function (e) {
            if ($switcher.hasClass('switcher_active')) {
                if (
                    (!$(e.target).closest($switcher).length) ||
                    (e.keyCode == 27)
                ) {
                    $switcher.removeClass('switcher_active');
                }
            }
        });

        // get theme from local storage
        if (localStorage.getItem("altair_theme") !== null) {
            $theme_switcher.children('li[data-app-theme=' + localStorage.getItem("altair_theme") + ']').click();
        }
    } catch (ex) {
        console.log(ex);
    }
});

// check for theme
if (typeof (Storage) !== "undefined") {
    try {
        var root = document.getElementsByTagName('html')[0],
            theme = localStorage.getItem("altair_theme");
        if (theme == 'app_theme_dark' || root.classList.contains('app_theme_dark')) {
            root.className += ' app_theme_dark';
        }
    } catch (ex) {
        console.log(ex);
    }
}

function CheckForChangeColorSwitch() {
    try {
        var changeThemeColor = document.querySelector('#change_theme_color');
        if (changeThemeColor.checked === true) {
            changeThemeColor.checked = false;
            if (typeof Event === 'function' || !document.fireEvent) {
                var event = document.createEvent('HTMLEvents');
                event.initEvent('change', true, true);
                changeThemeColor.dispatchEvent(event);
            } else {
                changeThemeColor.fireEvent('onchange');
            }
        }
    } catch (ex) {
        console.log(ex);
    }
}

//change theme font
$(function () {
    try {
        var $body = $('body'),
            $dropdown_theme_fonts = $('.theme_fonts');
        $dropdown_theme_fonts.find('a').click(function (e) {
            e.preventDefault();
            var thisFont = $(this).attr('data-body-font');
            $('#fontsCSS').attr('href', 'assets/css/fonts/' + thisFont + '.css')

            if (thisFont == '') {
                localStorage.removeItem('font_family');
            } else {
                localStorage.setItem("font_family", thisFont);
            }

            $(this)
                .closest('li').addClass('uk-active')
                .siblings('li').removeClass('uk-active');

            setTimeout(function () {
                $(window).trigger('resize');
            }, 100);
        });

        // get theme from local storage
        if (localStorage.getItem("font_family") !== null) {
            $('#fontsCSS').attr('href', 'assets/css/fonts/' + localStorage.getItem("font_family") + '.css')
            $dropdown_theme_fonts.children('li[li-font="' + localStorage.getItem("font_family") + '"]').addClass('uk-active');

            //this approach will not set the font to login page
            //$dropdown_theme_fonts.children('li[li-font="' + localStorage.getItem("font_family") +
            //    '"]').children('a[data-body-font="' + localStorage.getItem("font_family") + '"]').click();
        }
        else {
            let font = $('#fontsCSS').attr('href');
            let fontName = font.split('/').pop().split('.')[0];
            localStorage.setItem("font_family", fontName);
            $dropdown_theme_fonts.children('li[li-font="' + localStorage.getItem("font_family") + '"]').addClass('uk-active');
        }
    } catch (ex) {
        console.log(ex);
    }
});

$(function () {
    try {
        if (isHighDensity()) {

            $.getScript("components/dense/src/dense.min.js", function () {
                // enable hires images
                altair_helpers.retina_images();
            })
        }
        if (Modernizr.touch) {
            // fastClick (touch devices)
            FastClick.attach(document.body);
        }
    } catch (ex) {
        console.log(ex);
    }
});

$window.load(function () {
    // ie fixes
    altair_helpers.ie_fix();
});

function ChangeChatColorInit(boxId, chartId) {
    try {
        var $chat = $('#' + boxId),
            $dropdown_chat_colors = $('#' + chartId);
        $dropdown_chat_colors.find('a').click(function (e) {
            e.preventDefault();
            var thisColor = $(this).attr('data-chat-color');

            $chat
                .removeClass('chat_box_colors_a chat_box_colors_b chat_box_colors_c chat_box_colors_d')
                .addClass(thisColor);

            if (thisColor == '') {
                localStorage.removeItem('chat_theme');
            } else {
                localStorage.setItem("chat_theme", thisColor);
            }

            $(this)
                .closest('li').addClass('uk-active')
                .siblings('li').removeClass('uk-active');
        });

        // check for chat theme and append last theme
        if (typeof (Storage) !== "undefined") {
            //get the theme from local storage
            var theme = localStorage.getItem("chat_theme");
            //if not null append the theme
            if (theme !== null) {
                $chat
                    .removeClass('chat_box_colors_a chat_box_colors_b chat_box_colors_c chat_box_colors_d')
                    .addClass(theme);
                //get the a tag inorder to select the dropdown value
                $.each($dropdown_chat_colors.find('a'), function (i, val) {
                    if ($(val).attr("data-chat-color") === theme) {
                        $(val)
                            .closest('li').addClass('uk-active')
                            .siblings('li').removeClass('uk-active');
                    }
                });
            }
        }
    } catch (ex) {
        console.log(ex);
    }
}