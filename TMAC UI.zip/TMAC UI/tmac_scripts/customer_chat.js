﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CustomerChat.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
customer_chat = {
    get_customerlist: function () {
        $("#customer_chatboxes").html("");
        $.each(dummyCustomerList, function (i, val) {
            var t = $("#customer_list_template").html(), //template divs
                e = $("#customer_chatboxes"), //to be appended to
                n = Handlebars.compile(t), //initialize handlebars for the template divs       
                context = {
                    nric: val.nric,
                    salute: val.salute,
                    name: val.name,
                    phone: val.phone,
                    email: val.email
                }, //add context data
                s = n(context); //execute the template with handlebar and context
            e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
        });

        //setInterval(function () {
        //    GetCustomerList();
        //    $("#loadcustomerlist").addClass("uk-icon-spin");
        //}, 5000);
    },
    customerlistloaded: function (data, obj) {
        try {
            $("#loadcustomerlist").removeClass("uk-icon-spin");
            if (data.length > 0) {
                $("#customer_chatboxes").html("");
                $.each(data, function (i, val) {
                    var t = $("#customer_list_template").html(), //template divs
                        e = $("#customer_chatboxes"), //to be appended to
                        n = Handlebars.compile(t), //initialize handlebars for the template divs       
                        context = {
                            customerid: val.CustomerIdentifier,
                            customername: val.CustomerIdentifier,
                            itemid: val.ItemID,
                            otherinfo: val.CustomerIdentifier
                        }, //add context data
                        s = n(context); //execute the template with handlebar and context
                    e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
                });
            } else {
                var li = "<li>No customer logged In</li>";
                $("#customer_chatboxes").html(li);
            }
        } catch (ex) {
            console.log(ex);
        }
    },
    pullchat: function (nric, salute, name, phone, email) {
        try {
            //PullTextChat(itemid);
            tmac_StartTextChatFromAgent("InitNewChatDone", null, nric, global_AgentID, salute, name, phone, email);
            ShowNotify("Please wait while we connect..", "info", null, "top-center");
            $("#sidebar_secondary_toggle").trigger("click");
        } catch (ex) {
            console.log(ex);
        }
    }
};

$(function () {
    console.log('customer chat loaded');
    customer_chat.get_customerlist();
});