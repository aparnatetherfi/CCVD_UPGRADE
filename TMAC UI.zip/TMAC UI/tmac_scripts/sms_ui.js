﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "SMSUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

$(function () {
    RegisterSMSSDK();
    SMSConfigurations();
});

function RegisterSMSSDK() {
    try {
        tmac_sms_initialize(
            global_DeviceID,
            global_AgentID,
            global_AgentName,
            "SMSIncomingCallback",
            "OutgoingSMSCallback",
            "SMSSentCallback",
            "SMSSendFailedCallback",
            "SMSReceivedCallback");
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.RegisterSMSSDK()", ex, false);
    }
}

function OpenComposeSMS() {
    try {
        GetTemplatesForInteraction("sms", "");
        $("#compose_sms_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.OpenComposeSMS()", ex, false);
    }
}

function SMSConfigurations() {
    try {
        //SmsDnisList list dropdown
        $("#SmsDnisList").kendoDropDownList();
        $('#SmsDnisList').data('kendoDropDownList').dataSource.data(smsDnisList);
        $("#SmsDnisList").data("kendoDropDownList").text("Select a from number...");

        //To SMS selectize
        if (maxSmsLineRecipents > 1) {
            smsNumberSelect = $('#toSmsNumber').selectize({
                plugins: {
                    'remove_button': {
                        label: ''
                    }
                },
                maxItems: maxSmsLineRecipents,
                delimiter: ';',
                persist: false,
                create: function (input) {
                    if (input.length > maxSmsLineNumberLength) {
                        log.LogDetails("Error", "SMSUI.SMSConfigurations()", "Max length is " + maxSmsLineNumberLength, true);
                        return false;
                    }

                    if ((new RegExp('^[0-9]*$', 'i')).test(input)) {
                        return { value: input, text: input };
                    }

                    log.LogDetails("Error", "SMSUI.SMSConfigurations()", "Invalid phone number...", true);
                    return false;
                },
                onDropdownOpen: function ($dropdown) {
                    $dropdown
                        .hide()
                        .velocity('slideDown', {
                            begin: function () {
                                $dropdown.css({ 'margin-top': '0' });
                            },
                            duration: 200,
                            easing: easing_swiftOut
                        });
                },
                onDropdownClose: function ($dropdown) {
                    $dropdown
                        .show()
                        .velocity('slideUp', {
                            complete: function () {
                                $dropdown.css({ 'margin-top': '' });
                            },
                            duration: 200,
                            easing: easing_swiftOut
                        });
                }
            });
            $("#toSmsNumber").removeAttr("onkeypress");
        }
        else {
            $("#toSmsNumber").removeClass("uk-margin-small-top");
            $("#toSmsNumber").addClass("md-input label-fixed");
            $("#toSmsNumber").attr("maxlength", maxSmsLineNumberLength);
            altair_md.inputs("#compose_sms_dialog");
        }

        //Create the sms template grid
        CreateChatTemplateGrid("", "sms");

        //  VP: May 18, '20: Register on change for checkboxes whether template or freetext
        $("[name=composeSmsMode]").change(function (event) {
            if (event.currentTarget.value === "template") {
                $("#divSmsTextArea").addClass("uk-display-none");
                $("#divSmsTemplate").removeClass("uk-display-none");
            }
            else
                if (event.currentTarget.value == "text") {
                    $("#divSmsTemplate").addClass("uk-display-none");
                    $("#divSmsTextArea").removeClass("uk-display-none");
                }
        });
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.SMSConfigurations()", ex, false);
    }
}

function SendSMSToServer() {
    try {
        //  VP: May 18, '20: SMS mode added. Template or Free Text
        let smsMode = $("[name=composeSmsMode]:checked").val();

        var fromNumber = $("#SmsDnisList").data("kendoDropDownList").value();
        var toNumber = $("#toSmsNumber").val();
        var $grid = $("#sms_template_grid").data("kendoGrid"); //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var isValid = true;
        var errorMsg = "";
        if (fromNumber === "") {
            errorMsg = "Please select a from number";
            isValid = false;
        }
        else if ($.trim(toNumber) === "") {
            errorMsg = "Please enter a to number";
            isValid = false;
        }
        else if (fromNumber === $.trim(toNumber)) {
            errorMsg = "From number and to number can not be same";
            isValid = false;
        }
        else if (smsMode === "template" && ($row === null || $row.length === 0)) {
            errorMsg = "Please select a template to send";
            isValid = false;
        }
        else if (smsMode === "text" && $("#composeTextArea").val().length === 0) {
            errorMsg = "Please enter your text message";
            isValid = false;
        }
        if (!isValid) {
            log.LogDetails("Error", "SMSUI.SendSMSToServer()", errorMsg, true);
            return false;
        }

        var rowData = $grid.dataItem($row); //selected row data
        _tempSmsMessage = smsMode === "text" ? $("#composeTextArea").val() : rowData.Text;
        DisableButton("#btnSendSMS");
        ComposeSMS(fromNumber, toNumber, null, "");
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.SendSMSToServer()", ex, false);
    }
}

function OutgoingSMSCallback(event) {
    try {
        //TODO :: create outgoing sms tab
        AddSMSTab(event);
        //of tem message is not empty and if this is not a recovery event then send the message
        if (_tempSmsMessage && !event.RecoveryEvent)
            SendSMS(event.InteractionID, _tempSmsMessage, null);
        else
            log.LogDetails("Error", "SMSUI.OutgoingSMSCallback()", "Message not found/Recovery event so don't sent the message", false);
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.OutgoingSMSCallback()", ex, false);
    }
}

function SMSSentCallback(event) {
    try {
        _tempSmsMessage = "";
        //if this is not recovery event show sms sent alert
        if (!event.RecoveryEvent)
            log.LogDetails("Success", "SMSUI.SMSSentCallback()", "SMS sent successfully to " + event.PhoneNumber, true);
        //close compose sms dialog
        $("#compose_sms_dialog").data("kendoWindow").close();
        //call close tab to close interaction in server
        CloseTab(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.SMSSentCallback()", ex, false);
    }
}

function SMSSendFailedCallback(event) {
    try {
        _tempSmsMessage = "";
        //if this is not recovery event show sms sent alert
        if (!event.RecoveryEvent)
            log.LogDetails("Error", "SMSUI.SMSSentCallback()", "SMS send failed to " + event.PhoneNumber, true);
        //close compose sms dialog
        $("#compose_sms_dialog").data("kendoWindow").close();
        //call close tab to close interaction in server
        CloseTab(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.SMSSendFailedCallback()", ex, false);
    }
}

function AddSMSTab(event) {
    try {
        var intid = event.InteractionID;
        SaveTabReference("sms", intid, "Connected");
    } catch (ex) {
        log.LogDetails("Error", "SMSUI.AddSMSTab()", ex, false);
    }
}
