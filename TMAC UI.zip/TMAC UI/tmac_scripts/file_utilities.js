// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "FileUtility.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
var recordedInterval;
var counter = 0;
var audioChunks = [];
var recordedChunks = [];
var isSendRecord = false;
let preview = document.getElementById('preview');
let previewImage = document.getElementById('preview_image');
let previewVideo = document.getElementById('preview_video');
var imageCapture;
var screenshotBlob = null;
var editedBlob = null;
var captureBlob = null;
var videoBlob = null;
var autoresize = true;

function OpenFileUpload() {
    try {
        UIkit.modal("#recent_file_list_dialog").hide();
        $("#recent_list_ul").html("");
        log.LogDetails("Warning", "FileUtility.OpenFileUpload()", "Max file size allowed is " + maxAttachFileSize + " MB", true);
        $("#attachFiles").click();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.OpenFileUpload()", ex, false);
    }
}

function CancelUpload() {
    try {
        $('.k-button.k-upload-action').trigger('click');
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.CancelUpload()", ex, false);
    }
}

function OpenCamera() {
    try {
        $("#btnTakePicture").show();
        $("#btnStartVideo").show();
        $("#btnSendCapture").hide();
        $("#btnStopVideo").hide();
        $("#btnRetake").hide();
        navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true
        }).then(stream => {
            recVideo = new MediaRecorder(stream);
            preview.srcObject = stream;
            //downloadButton.href = stream;
            recordedChunks = [];
            const mediaStreamTrack = stream.getVideoTracks()[0];
            imageCapture = new ImageCapture(mediaStreamTrack);

            recVideo.ondataavailable = e => {
                recordedChunks.push(e.data);
                if (recVideo.state === "inactive") {
                    let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });
                    var src = URL.createObjectURL(recordedBlob);
                    console.log("recVideo: " + src);
                    previewVideo.src = src;
                    videoBlob = recordedBlob;
                    $("#camera_tag").hide();
                    $("#video_tag").show();
                }
            }
            preview.captureStream = preview.captureStream || preview.mozCaptureStream;
            return new Promise(resolve => preview.onplaying = resolve);
        }).catch(ex => console.log(ex));
        UIkit.modal("#modal_camera").show();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.OpenCamera()", ex, false);
    }
}

function TakePicture() {
    try {
        imageCapture.takePhoto()
            .then(blob => {
                captureBlob = blob;
                previewImage.src = URL.createObjectURL(blob);
                console.log("TakePicture:" + URL.createObjectURL(blob));
                previewImage.onload = () => { URL.revokeObjectURL(this.src); }
                $("#camera_tag").hide();
                $("#capture_tag").show();
                $("#btnStartVideo").hide();
                $("#btnTakePicture").hide();
                $("#btnSendCapture").show();
                $("#btnRetake").show();
            })
            .catch(error => console.log('takePhoto() error:', error));
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.TakePicture()", ex, false);
    }
}

function RetakeImage() {
    try {
        $("#capture_tag").hide();
        $("#camera_tag").show();
        $("#video_tag").hide();

        $("#btnTakePicture").show();
        $("#btnStartVideo").show();
        $("#btnSendCapture").hide();
        $("#btnRetake").hide();
        recordedChunks = [];
        videoBlob = null;
        captureBlob = null;
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.RetakeImage()", ex, false);
    }
}

function CloseCamera() {
    try {
        preview.srcObject.getTracks().forEach(track => track.stop());
        $("#video_tag").hide();
        $("#capture_tag").hide();
        $("#camera_tag").show();
        recordedChunks = [];
        videoBlob = null;
        captureBlob = null;
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.CloseCamera()", ex, false);
    }
}

function SendCapture() {
    try {
        if (captureBlob !== null) {
            UploadFile(captureBlob, "image");
        }
        else if (videoBlob !== null) {
            UploadFile(videoBlob, "video");
        }
        $("#btnCloseCamera").trigger("click");
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.SendCapture()", ex, false);
    }
}

function StartVidoeRecording() {
    try {
        $("#btnTakePicture").hide();
        $("#btnStartVideo").hide();
        $("#btnSendCapture").hide();
        $("#btnStopVideo").show();
        recVideo.start();
        console.log(recVideo.state);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.StartVidoeRecording()", ex, false);
    }
}

function StopVideoRecording() {
    try {
        $("#btnTakePicture").hide();
        $("#btnStartVideo").hide();
        $("#btnSendCapture").show();
        $("#btnStopVideo").hide();
        $("#btnRetake").show();
        recVideo.stop();
        console.log(recVideo.state);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.StopVideoRecording()", ex, false);
    }
}

function StartVoiceRecording(intid) {
    try {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                rec = new MediaRecorder(stream);
                rec.start();
                rec.ondataavailable = e => {
                    audioChunks.push(e.data);
                    if (rec.state === "inactive") {
                        var recordedAudio = $("#recordedAudio" + global_activeTabInteractionID);
                        let blob = new Blob(audioChunks, { type: 'audio/x-mpeg-3' });
                        var src = URL.createObjectURL(blob);
                        console.log("recordedAudio: " + src);
                        if (isSendRecord) {
                            UploadFile(blob, "audio");
                        }
                        //audioDownload.href = recordedAudio.src;
                        //audioDownload.download = 'mp3';
                        //audioDownload.innerHTML = 'download';
                    }
                };
            })
            .catch(ex => console.log(ex));
        counter = 0;
        $("#voice_recoder_time" + intid).text("00:00");
        $("#btnTextChatSendVoice" + intid).hide();
        $("#spanTextChatSendVideo" + intid).hide();
        $("#div_voice_recorder" + intid).show();
        audioChunks = [];
        $("#voice_recoder_time" + intid).text(SecondsTimeSpanToMS(counter++));
        recordedInterval = setInterval(function () {
            $("#voice_recoder_time" + intid).text(SecondsTimeSpanToMS(counter++));
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.StartVoiceRecording()", ex, false);
    }
}

function CancelAudio(intid) {
    try {
        isSendRecord = false;
        StopVoiceRecording(intid);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.CancelAudio()", ex, false);
    }
}

function SendAudio(intid) {
    try {
        isSendRecord = true;
        StopVoiceRecording(intid);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.SendAudio()", ex, false);
    }
}

function StopVoiceRecording(intid) {
    try {
        if (rec.state === "recording")
            rec.stop();
        clearInterval(recordedInterval);
        $("#div_voice_recorder" + intid).hide();
        $("#btnTextChatSendVoice" + intid).show();
        $("#spanTextChatSendVideo" + intid).show();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.StopVoiceRecording()", ex, false);
    }
}

//paste screenshot taken from 'print screen' button
if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
    console.log("Firefox");
    $("#one").bind("input paste", function (ev) {
        window.setTimeout(function (ev) {
            var input = $("#one").children()[0].src;
            var s = input.split(',');
            var mime = s[0];
            var data = s[1];
            console.log(mime);
            console.log(data);
        }, 300);
    });
} else if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
    console.log("Chrome");
    $("body").on("paste", function (event) {
        var items = (event.clipboardData || event.originalEvent.clipboardData).items;
        console.log(JSON.stringify(items)); // will give you the mime types
        for (index in items) {
            var item = items[index];
            if (item.kind === 'file') {
                var blob = item.getAsFile();
                var reader = new FileReader();
                reader.onload = function (event) {
                    let clip_img = document.getElementById('img_screenshot' + global_activeTabInteractionID);
                    if (clip_img !== null) {
                        var source = event.target.result;
                        var base64 = source.split(',')[1];
                        var binary = FixBinary(atob(base64));
                        var blob = new Blob([binary], { type: 'image/png' });
                        screenshotBlob = blob;
                        var url = URL.createObjectURL(blob);
                        //var canvasId = "canvas_screenshot" + global_activeTabInteractionID;
                        //PasteImageToCanvas(url, canvasId);
                        console.log("Screenshot: " + url);
                        clip_img.src = url;
                        ShowAttachment("image");
                    }
                }; // data url!
                reader.readAsDataURL(blob);
            }
        }
    })
}

function FixBinary(bin) {
    try {
        var length = bin.length;
        var buf = new ArrayBuffer(length);
        var arr = new Uint8Array(buf);
        for (var i = 0; i < length; i++) {
            arr[i] = bin.charCodeAt(i);
        }
        return buf;
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.FixBinary()", ex, false);
    }
}

function EditPreview(intid) {
    try {
        var img = document.getElementById("img_screenshot" + intid);
        var pdf = document.getElementById("file_preview" + intid);
        if (editFileType === "image") {
            editingImage = true;
            var canvas = document.getElementById("sketch");
            var con = canvas.getContext("2d");
            canvas.width = img.width;
            canvas.height = img.height;
            $(".uk-edit-image-dialog").width(img.width);
            con.clearRect(0, 0, img.width, img.height);
            var image = new Image();
            image.src = img.src;
            con.drawImage(image, 0, 0, img.width, img.height);
            drawInit();
            UIkit.modal("#modal_image_edit").show();
        }
        else if (editFileType === "pdf") {
            showPDF(pdf.href);
            UIkit.modal("#modal_pdf_edit").show();
        }
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.EditPreview()", ex, false);
    }
}

function EditPdfPage() {
    try {
        UIkit.modal.confirm("Are you sure to edit this page?",
            function () {
                $("#img_screenshot" + global_activeTabInteractionID)[0].src = "";
                var base64 = $("#pdf-canvas")[0].toDataURL("image/png", 1).split(',')[1];
                var binary = FixBinary(atob(base64));
                var blob = new Blob([binary], { type: 'image/png' });
                var url = URL.createObjectURL(blob);
                $("#img_screenshot" + global_activeTabInteractionID)[0].src = url;
                $("#file_preview" + global_activeTabInteractionID).attr('src', 'null');
                ShowAttachment("image");
                UIkit.modal("#modal_pdf_edit").hide();
            },
            function oncancel() { });
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.EditPdfPage()", ex, false);
    }
}

function ChangePicture() {
    try {
        isEditedImage = true;
        editingImage = false;
        $("#img_screenshot" + global_activeTabInteractionID)[0].src = "";
        var base64 = $("#sketch")[0].toDataURL("image/png", 1).split(',')[1];
        var binary = FixBinary(atob(base64));
        var blob = new Blob([binary], { type: 'image/png' });
        editedBlob = blob;
        var url = URL.createObjectURL(blob);
        $("#img_screenshot" + global_activeTabInteractionID)[0].src = url;
        UIkit.modal("#modal_image_edit").hide();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ChangePicture()", ex, false);
    }
}

function ChangePenColor(type) {
    try {
        switch (type) {
            case 'red':
                drawStrokeStyle = "#e53935";
                break;
            case 'blue':
                drawStrokeStyle = "#1e88e5";
                break;
            case 'green':
                drawStrokeStyle = "#43a047";
                break;
            case 'yellow':
                drawStrokeStyle = "#fdd835";
                break;
            case 'black':
                drawStrokeStyle = "#000000";
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ChangePenColor()", ex, false);
    }
}

function ChangePenSize(type) {
    try {
        switch (type) {
            case 'more':
                drawStrokeSize = ++drawStrokeSize;
                break;
            case 'less':
                drawStrokeSize = --drawStrokeSize;
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ChangePenSize()", ex, false);
    }
}

function PasteImageToCanvas(source, canvasId) {
    try {
        var canvas = document.getElementById(canvasId);
        var ctx = document.getElementById(canvasId).getContext("2d");
        var pastedImage = new Image();
        pastedImage.onload = function () {
            if (autoresize === true) {
                //resize
                canvas.width = pastedImage.width;
                canvas.height = pastedImage.height;
            }
            else {
                //clear canvas
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
            ctx.drawImage(pastedImage, 0, 0);
        };
        pastedImage.src = source;
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.PasteImageToCanvas()", ex, false);
    }
}

function ShowAttachment(type) {
    try {
        $("#img_screenshot" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#aud_screenshot" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#vid_screenshot" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#file_screenshot" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#file_preview" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#btnEditPreview" + global_activeTabInteractionID).addClass("uk-display-none");
        $("#btnDrawPreview" + global_activeTabInteractionID).addClass("uk-display-none");
        if (type === "image") {
            editFileType = "image";
            $("#btnDrawPreview" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#btnEditPreview" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#img_screenshot" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#img_screenshot" + global_activeTabInteractionID).css("max-height", $("#chat_card" + global_activeTabInteractionID).height() - 20);
        }
        else if (type === "video") {
            $("#vid_screenshot" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#vid_screenshot" + global_activeTabInteractionID).css("max-height", $("#chat_card" + global_activeTabInteractionID).height() - 20);
        }
        else if (type === "audio") {
            $("#aud_screenshot" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#aud_screenshot" + global_activeTabInteractionID).css("max-height", $("#chat_card" + global_activeTabInteractionID).height() - 20);
        }
        else if (type === "file") {
            if ($("#file_preview" + global_activeTabInteractionID).text().split('.').pop() === "pdf") {
                editFileType = "pdf";
                $("#btnEditPreview" + global_activeTabInteractionID).removeClass("uk-display-none");
            }
            $("#file_preview" + global_activeTabInteractionID).removeClass("uk-display-none");
            $("#file_preview" + global_activeTabInteractionID).css("max-height", $("#chat_card" + global_activeTabInteractionID).height() - 20);
        }
        $("#screenshot_card" + global_activeTabInteractionID).css("height", $("#chat_card" + global_activeTabInteractionID).height());
        $("#screenshot_card" + global_activeTabInteractionID).css("height", $("#chat_card" + global_activeTabInteractionID).height());
        $("#screenshot_div" + global_activeTabInteractionID).css("height", $("#chat_card" + global_activeTabInteractionID).height());
        $("#screenshot_div" + global_activeTabInteractionID).show();
        $("#chat_card" + global_activeTabInteractionID).hide();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ShowAttachment()", ex, false);
    }
}

function SendPreview(intid) {
    try {
        if (isEditedImage && editedBlob) {
            UploadFile(editedBlob, "image");
        }
        else {
            if (!screenshotBlob) {
                $(".k-upload-selected").trigger("click");
            }
            else {
                UploadFile(screenshotBlob, "image");
            }
        }
        ClosePreview(intid);
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.SendPreview()", ex, false);
    }
}

function ClosePreview(intid) {
    try {
        if ($(".k-upload-files.k-reset").find("li").length > 0)
            $(".k-upload-files.k-reset").find("li").remove();
        $("#screenshot_div" + intid).hide();
        $("#chat_card" + intid).show();
        screenshotBlob = null;
        editingImage = false;
        isEditedImage = false;
        editedBlob = null;
        editFileType = "";
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ClosePreview()", ex, false);
    }
}

function UploadFile(blob, type) {
    try {
        var formData = new FormData();
        var fileName = "";
        var timeNow = moment(new Date()).format("YYYYMMDDHHmmssSS");
        if (type === "audio")
            fileName = "audio_" + timeNow + ".wav";
        else if (type === "image")
            fileName = "image_" + timeNow + ".jpg";
        else if (type === "video")
            fileName = "video_" + timeNow + ".mp4";

        console.log("data size: ", blob.size);
        var ajaxLink = global_connectedProxy + "OtherFileUpload";
        let customObj = {
            intId: global_activeTabInteractionID
        };
        var isReply = GetChatReferenceObj(customObj.intId).replyText !== "";
        var replyId = GetChatReferenceObj(customObj.intId).replyId ? GetChatReferenceObj(customObj.intId).replyId : "";

        var encodeData = new Blob([blob], { type: 'multipart/form-data' });
        formData.append("blob", encodeData, fileName);

        if (FileServerUrl.MediaProxy.length !== 0) {
            ajaxLink = FileServerUrl.MediaProxy + "/api/FileUpload/Post/";
            formData.append("SessionId", GetChatReferenceObj(global_activeTabInteractionID).sessionId);
            formData.append("other", JSON.stringify(customObj));
        }

        $.ajax({
            type: 'POST',
            url: ajaxLink,
            data: formData,
            processData: false,
            contentType: false,
            success: function (response, status, xmlData) {
                if (FileServerUrl.MediaProxy.length !== 0) {
                    response = FileServerUrl.MediaProxy + "/" + GetChatReferenceObj(customObj.intId).sessionId + "/" + fileName;
                }

                console.log("uploaded file: " + response);
                let message = "";
                let msgid = uuid();
                let replyJson = {};

                let obj = {
                    messageId: msgid,
                    attachment: {
                        src: response,
                        type: "",
                        name: fileName ? fileName : ""
                    },
                    message: "",
                    replyId: replyId,
                    type: "attachment"
                };
                if (type === "audio") {
                    obj.attachment.type = "audio";
                }
                else if (type === "image") {
                    obj.attachment.type = "image";
                }
                else if (type === "video") {
                    obj.attachment.type = "video";
                }

                GetChatReferenceObj(customObj.intId).isAgent = true;
                message = JSON.stringify(obj);

                SendTextChat(global_DeviceID, customObj.intId, message, "", msgid, false);
                replyJson.replyType = GetChatReferenceObj(customObj.intId).replyType;
                replyJson.replyId = GetChatReferenceObj(customObj.intId).replyId;
                replyJson.replyText = GetChatReferenceObj(customObj.intId).replyText;
                replyJson.replyUser = GetChatReferenceObj(customObj.intId).replyUser;
                AddMessageToChatbox(customObj.intId, msgid, response, "agent", "", "divTxtChatTranscript", obj.attachment.type, isReply, replyJson, global_AgentName.split(" ")[0], obj.attachment);
            }
        }).done(function (data) {
            console.log(data);
        });
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.UploadFile()", ex, false);
    }
}

function tmac_GetRecentFiles(intid) {
    try {
        $("#btnTextChatAttach" + intid).html('<i class="md-icon uk-icon-spinner uk-icon-small uk-icon-spin"></i>');
        //tmac_command(null, { "intid": intid }, {}, "GetRecentFiles");
        tmac_command("", { intid: intid }, { "customerNric": global_AgentID, "agentId": global_AgentID }, "GetRecentFiles");
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.tmac_GetRecentFiles()", ex, false);
    }
}

function tmac_GetRecentFilesDone(callbackfunction, userobject, data, resultData) {
    try {
        $("#recent_list_ul").html("");
        var fileList = resultData;
        if (fileList.length === 0) {
            var template = '<li><span class="md-list-addon-element" > <span class="k-icon k-i-file-add uk-text-muted k-icon-48"></span></span><div class="md-list-content"><span class="md-list-heading uk-text-danger">No recent files found</span></div></li >';
            $("#recent_list_ul").html(template);
        }
        else
            $.each(fileList, function (i, val) {
                var previewTag = "";
                if (imageFormats.indexOf(val.fileExtension.toUpperCase()) >= 0) { previewTag = "<img class='uk-animation-scale-up' src='" + val.filePath.replace(/\\/g, "\\\\") + "'/>" }
                else if (videoFormats.indexOf(val.fileExtension.toUpperCase()) >= 0) { previewTag = "<video controls class='uk-animation-scale-up' src='" + val.filePath.replace(/\\/g, "\\\\") + "'></video>" }
                else if (audioFormats.indexOf(val.fileExtension.toUpperCase()) >= 0) { previewTag = "<audio preload='true' controls class='uk-animation-scale-up' src='" + val.filePath.replace(/\\/g, "\\\\") + "'></audio>" }
                else if (val.fileExtension.toUpperCase() === ".DOC" || val.fileExtension.toUpperCase() === ".DOCX" || val.fileExtension.toUpperCase() === ".PDF") { previewTag = '<iframe class="recent_iframe" src="https://docs.google.com/gview?url=' + val.filePath.replace(/\\/g, "\\\\") + '&embedded=true" frameborder="0"></iframe >' }
                else { previewTag = "<p>No preview available</p>" }

                var t = $("#recent_file_list_template").html(), //template divs
                    e = $("#recent_list_ul"), //to be appended to
                    n = Handlebars.compile(t), //initialize handlebars for the template divs       
                    context = {
                        preview: previewTag,
                        tagid: "span_" + i,
                        filepath: val.filePath.replace(/\\/g, "\\\\"),
                        extension: val.fileExtension.toUpperCase(),
                        icon: GetIconByExtension(val.fileExtension.toUpperCase()),
                        filename: val.fileName,
                        filesize: BytesToSize(val.fileSize),
                        createdtime: moment(val.fileCreateTime, "YYYYMMDDHHmmss").format("DD/MM/YYYY hh:mm A")
                    }, //add context data
                    s = n(context); //execute the template with handlebar and context
                e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
                PreviewRecent("span_" + i);
            });
        $('#recent_files_content').scrollTo(0);
        UIkit.modal("#recent_file_list_dialog").show();
        $("#btnTextChatAttach" + userobject.intid).html('<i class="material-icons notranslate md-icon">attach_file</i>');
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.tmac_GetRecentFilesDone()", ex, false);
    }
}

function PreviewRecent(id) {
    try {
        $("#" + id).toggle();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.PreviewRecent()", ex, false);
    }
}

function BytesToSize(bytes) {
    try {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes === 0) return '0 Byte';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.BytesToSize()", ex, false);
    }
}

function GetIconByExtension(extension) {
    try {
        var ext = extension.split('.')[1];
        if (imageFormats.indexOf(extension) >= 0)
            return "k-i-image";
        else if (videoFormats.indexOf(extension) >= 0)
            return "k-i-media-manager";
        else if (audioFormats.indexOf(extension) >= 0)
            return "k-i-audio";
        else if (fileFormats.indexOf(extension) >= 0)
            return "k-i-file-" + ext.toLowerCase();
        else
            return "k-i-file";
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.GetIconByExtension()", ex, false);
    }
}

function RecentFileSelected(source, name, extension) {
    try {
        let msgid = uuid();
        let message = "";
        let src = source;
        let isReply = false;
        let replyJson = {};
        let obj = {};
        obj.id = msgid;
        if (toLowerCaseArray(imageFormats).indexOf(extension.toLowerCase()) >= 0) {
            obj.messageType = "image";
            obj.message = '<img class="attach_img" src="' + src + '"/>';
            type = "image";
        }
        else if (toLowerCaseArray(audioFormats).indexOf(extension.toLowerCase()) >= 0) {
            obj.messageType = "audio";
            obj.message = '<audio preload="true" controls src="' + src + '"></audio>';
            type = "audio";
        }
        else if (toLowerCaseArray(videoFormats).indexOf(extension.toLowerCase()) >= 0) {
            obj.messageType = "video";
            obj.message = '<video class="videoTag" controls src="' + src + '"></video>';
            type = "video";
        }
        else {
            var fileType = GetFileExtension(extension);
            if (toLowerCaseArray(fileFormats).indexOf(fileType.toLowerCase()) >= 0)
                type = "file";
            else
                type = "others";
            obj.messageType = "file";
            obj.message = '<a class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a>';
            src = name + "|" + src;
        }
        GetChatReferenceObj(global_activeTabInteractionID).isAgent = true;
        GetChatReferenceObj(global_activeTabInteractionID).replyText !== "" ? isReply = true : isReply = false;
        if (isReply) {
            obj.type = "reply";
            obj.replyIdTextType = GetChatReferenceObj(global_activeTabInteractionID).replyTextId + "|" + GetChatReferenceObj(global_activeTabInteractionID).replyText + "|" + GetChatReferenceObj(global_activeTabInteractionID).replyType;
        }
        else
            obj.type = "new";
        message = JSON.stringify(obj);
        //  ReviewCodeLine: Check if type needs to be empty. And check this uppload method and check last param of isAppMessage
        SendTextChat(global_DeviceID, global_activeTabInteractionID, message, obj.messageType, msgid, true);

        replyJson.replyType = GetChatReferenceObj(global_activeTabInteractionID).replyType;
        replyJson.replyTextId = GetChatReferenceObj(global_activeTabInteractionID).replyTextId;
        replyJson.replyText = GetChatReferenceObj(global_activeTabInteractionID).replyText;
        replyJson.replyUser = GetChatReferenceObj(global_activeTabInteractionID).replyUser;

        AddMessageToChatbox(global_activeTabInteractionID, msgid, src, "agent", "", "divTxtChatTranscript", type, isReply, replyJson, "");
        SetLastWriteTime(source);
        UIkit.modal("#recent_file_list_dialog").hide();
        $("#recent_list_ul").html("");
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.RecentFileSelected()", ex, false);
    }
}

function SetLastWriteTime(filePath) {
    try {
        var obj = {};
        obj.filePath = filePath;
        tmac_command(null, null, obj, "SetLastWriteTime");
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.SetLastWriteTime()", ex, false);
    }
}

function SetLastWriteTimeDone(callbackfunction, userobject, data, resultData) {

}

function toLowerCaseArray(array) {
    var newArray = [];
    $.each(array, function (i, val) {
        newArray.push(val.toLowerCase())
    });
    return newArray;
}

function GetFileExtension(fileUrl) {
    try {
        var extension = fileUrl.split('.').pop();
        if (toLowerCaseArray(fileFormats).indexOf(extension.toLowerCase()) >= 0)
            return extension.toLowerCase();
        else
            return "";
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.GetFileExtension()", ex, false);
    }
}

function PreviewFile(src) {
    try {
        LoadIFrame("previewFileIframe", "https://docs.google.com/gview?url=" + src + "&embedded=true");
        UIkit.modal("#modal_previewFile").show();
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.PreviewFile()", ex, false);
    }
}

function ClearFilePreviewSrc() {
    try {
        LoadIFrame("previewFileIframe", "");
    } catch (ex) {
        log.LogDetails("Error", "FileUtility.ClearFilePreviewSrc()", ex, false);
    }
}
