var cobrowseLoggingGuid = "";

function GenerateCobrowseGuid() {
    try {
        let possible = "0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z";
        for (var i = 1; i <= 32; i++) {
            var randChar = possible.charAt(Math.floor(Math.random() * possible.length));
            cobrowseLoggingGuid += randChar;
            if (i === 8 || i === 12 || i === 16 || i === 20)
                cobrowseLoggingGuid += "-";
        }
    } catch (e) {
        console.log(e);
    }
}

GenerateCobrowseGuid();

function CobrowseLogging(method, message, logtype) {
    try {
        if (logtype.toLowerCase() === "error") {
            logtype = "Error";
        }
        else if (logtype.toLowerCase() === "debug" || logtype.toLowerCase() === "info") {
            logtype = "Info";
        }
        console.log(FormatLog(logtype, method, message));
        if (isCustomer) {
            try {
                livechat.slog(logtype, "[" + cobrowseLoggingGuid + "] " + method, message);
            } catch (e) {
                console.log(e);
                try {
                    log.LogDetails(logtype, "[" + cobrowseLoggingGuid + "] " + method, message, false);
                } catch (e) {
                    console.log(e);
                }
            }
        }
    } catch (e) {
        console.log(e);
    }
}

function SystemDateTime() {
    var currentdate = new Date();
    var datetime = currentdate.getDate() + "/"
        + (currentdate.getMonth() + 1) + "/"
        + currentdate.getFullYear() + " "
        + currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":"
        + currentdate.getSeconds();

    return datetime;
}

/*
    Format the log message
*/
function FormatLog(type, method, message) {
    return SystemDateTime() + "[" + cobrowseLoggingGuid + "] " + ' [' + type + '] [' + method + '] :: ' + message;
}
var annotateJsVersion = "Annotate.js - v1.0.4.8";
CobrowseLogging("Initial JS File Load", annotateJsVersion, "info");
var isCustomer = true;
var cobrowseArea;

var brushColor = "#f8920f";
var brushSize = 5;

var isPdf = false;
var isImage = false;

var annotCanvasScrollPositionTop = 0;
var annotCanvasScrollPositionLeft = 0;

var pdfUrl;
var imageUrl;

var canvasSizeSet = false;

var annotstatus = {};

var annotCanvasArray = [];

var redoArray = [];
var redoReceiverArray = [];
var TempAnnotations = [];
var TempParticipantAnnotations = [];
//isMousedown = false;

//Shapes Global vars
var isRectangle = false;
var isElipse = false;
var isFreeDraw = false;
var isLine = false;
var isArrow = false;
var rectangles = [];
var rectangleTemp = [];
var elipses = [];
var elipsesTemp = [];
var lines = [];

var annotation = {
    types: {
        'freeDraw': 1,
        'elipse': 2,
        'rectangle': 3,
        'line': 4,
        'arrow': 5
    },

    style: {
        brushColor: "#f8920f",
        brushSize: 5
    },
    isEnabled: false,
    selectedDrawType: null,
    isMouseDown: false,
    selectAnnotationType: function (type) {

        switch (type) {
            case annotation.types.freeDraw:
            case annotation.types.elipse:
            case annotation.types.rectangle:
            case annotation.types.line:
            case annotation.types.arrow:
                this.selectedDrawType = type;
                break;
            default:
                CobrowseLogging("annotate.annotation()", "invalid draw type selected.", "error");
        }
    },
    disable: function (intid) {
        try {
            this.isEnabled = false;
            document.getElementById('sendersCanvas' + intid).style.pointerEvents = "none";
            //document.getElementById('datacanvas' + intid).style.pointerEvents = "none";
            //document.getElementById('annotdiv' + intid).style.pointerEvents = "none";
            if (isCustomer)
                document.getElementById('receiversCanvas' + intid).style.pointerEvents = "none";
        } catch (e) {
            CobrowseLogging("annotate.annotation.disable()", e, "error");
        }
    },
    enable: function (intid) {
        try {
            selectedDrawType = this.types.freeDraw;
            this.isEnabled = true;
            document.getElementById('sendersCanvas' + intid).style.pointerEvents = "all";
            //document.getElementById('datacanvas' + intid).style.pointerEvents = "all";
            //document.getElementById('annotdiv' + intid).style.pointerEvents = "all";
            if (isCustomer)
                document.getElementById('receiversCanvas' + intid).style.pointerEvents = "all";
        } catch (e) {
            CobrowseLogging("annotate.annotation.enable()", e, "error");
        }
    },
    drawEventTypes: {
        'startDrawing': 1,
        'updatePositions': 2,
        'finishDrawing': 3
    },
    drawEvent: function (drawEventType, e, intid) {
        try {
            if (!this.isEnabled)
                return;
            if (drawEventType === this.drawEventTypes.startDrawing) {
                if (this.isMouseDown) {
                    return;
                }
                this.startDrawing(this.selectedDrawType, e, intid);
                this.isMouseDown = true;

            }
            else if (drawEventType === this.drawEventTypes.updatePositions) {
                if (!this.isMouseDown) {
                    return;
                }
                document.getElementById("sendersCanvas" + intid).getContext('2d').clearRect(0, 0, document.getElementById('sendersCanvas' + intid).width, document.getElementById('sendersCanvas' + intid).height);
                this.updatePositions(this.selectedDrawType, e, intid);
                this.redrawAnnotations(intid);

            }
            else if (drawEventType === this.drawEventTypes.finishDrawing) {
                if (!this.isMouseDown) {
                    return;
                }
                this.finishDrawing(this.selectedDrawType, e, intid);
                this.redrawAnnotations(intid);
                this.isMouseDown = false;
                //ConvertHtml();
                UpdateData();
            }

        } catch (e) {
            CobrowseLogging("annotate.annotation.drawEvent()", e, "error");
        }
    },
    startDrawing: function (type, e, intid) {
        try {
            var style = Object.assign({}, this.style);
            if (type === this.types.rectangle) {
                rectangle.startDrawing(style, e, intid);
            }
            else if (type === this.types.line) {
                line.startAnnotation(style, e, intid);
            }
            else if (type === this.types.arrow) {
                arrow.startAnnotation(style, e, intid);
            }
            else if (type === this.types.elipse) {
                elipse.startDrawing(style, e, intid);
            }
            else if (type === this.types.freeDraw) {
                freeDraw.startDrawing(style, e, intid);
            }
            redoArray[intid] = [];
        } catch (e) {
            CobrowseLogging("annotate.annotation.startDrawing()", e, "error");
        }
    },
    updatePositions: function (type, e, intid) {
        try {
            if (type === this.types.rectangle) {
                rectangle.updatePositions(e, intid);
            }
            else if (type === this.types.line) {
                line.updateAnnotation(e, intid);
            }
            else if (type === this.types.arrow) {
                arrow.updateAnnotation(e, intid);
            }
            else if (type === this.types.elipse) {
                elipse.updatePositions(e, intid);
            }
            else if (type === this.types.freeDraw) {
                freeDraw.updatePositions(e, intid);
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.updatePositions()", e, "error");
        }
    },
    finishDrawing: function (type, e, intid) {
        try {
            if (type === this.types.rectangle) {
                rectangle.finishDrawing(e, intid);
            }
            else if (type === this.types.line) {
                line.finishAnnotation(e, intid);
            }
            else if (type === this.types.arrow) {
                arrow.finishAnnotation(e, intid);
            }
            else if (type === this.types.elipse) {
                elipse.finishDrawing(e, intid);
            }
            else if (type === this.types.freeDraw) {
                freeDraw.finishDrawing(e, intid);
            }
            //sendAnnotData();
        } catch (e) {
            CobrowseLogging("annotate.annotation.finishDrawing()", e, "error");
        }
    },
    redrawAnnotations: function (intid) {
        try {
            //if(anotData != null && anotData != ""){
            //TempAnnotations = anotData;
            //console.log("Annotation history data is changed");
            //}                       

            for (var i in TempAnnotations[intid]) {
                var obj = TempAnnotations[intid][i];
                if (obj.type === annotation.types.freeDraw) {
                    freeDraw.draw(obj, intid);
                }
                else if (obj.type === annotation.types.elipse) {
                    elipse.draw(obj, intid);
                }
                else if (obj.type === annotation.types.rectangle) {
                    rectangle.draw(obj, intid);
                }
                else if (obj.type === annotation.types.line) {
                    line.draw(obj, intid);
                }
                else if (obj.type === annotation.types.arrow) {
                    arrow.draw(obj, intid);
                }
            }
            this.setAnnotationStyle(this.style, intid);

        } catch (e) {
            CobrowseLogging("annotate.annotation.redrawAnnotations()", e, "error");
        }
    },
    redrawReceiverAnnotations: function (anotData, intid) {
        try {
            //if(anotData != null && anotData != ""){
            //TempParticipantAnnotations = anotData;
            //console.log("Annotation history data is changed");
            //}                       

            for (var i in TempParticipantAnnotations[intid]) {
                var obj = TempParticipantAnnotations[intid][i];
                if (obj.type === annotation.types.freeDraw) {
                    freeDraw.drawParticipant(obj, intid);
                }
                else if (obj.type === annotation.types.elipse) {
                    elipse.drawParticipant(obj, intid);
                }
                else if (obj.type === annotation.types.rectangle) {
                    rectangle.drawParticipant(obj, intid);
                }
                else if (obj.type === annotation.types.line) {
                    line.drawParticipant(obj, intid);
                }
                else if (obj.type === annotation.types.arrow) {
                    arrow.drawParticipant(obj, intid);
                }
            }
            this.setReceiverAnnotationStyle(this.style);

        } catch (e) {
            CobrowseLogging("annotate.annotation.redrawReceiverAnnotations()", e, "error");
        }
    },
    setAnnotationStyle: function (style, intid) {
        try {
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = style.brushSize;
        } catch (e) {
            CobrowseLogging("annotate.annotation.setAnnotationStyle()", e, "error");
        }
    },
    setReceiverAnnotationStyle: function (style) {
        try {
            var receiversCanvasContext = document.getElementById("receiversCanvas").getContext('2d');
            receiversCanvasContext.strokeStyle = style.brushColor;
            receiversCanvasContext.lineWidth = style.brushSize;
        } catch (e) {
            cCobrowseLogging("annotate.annotation.setReceiverAnnotationStyle()", e, "error");
        }
    },
    undo: function (intid) {
        try {
            if (TempAnnotations[intid].length !== 0) {
                document.getElementById("sendersCanvas" + intid).getContext('2d').clearRect(0, 0, document.getElementById('sendersCanvas' + intid).width, document.getElementById('sendersCanvas' + intid).height);
                var undoannotations = TempAnnotations[intid].pop();
                redoArray[intid].push(undoannotations);
                annotation.redrawAnnotations(intid);
                if (!isCustomer) {
                    var command = {};
                    var data = this.style;

                    command.type = "undoReceiver";
                    command.data = data;
                    sendMessageForCb(command);
                }
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.undo()", e, "error");
        }
    },
    undoReceiver: function (style, intid) {
        try {
            if (TempParticipantAnnotations[intid].length !== 0) {
                var receiversCanvasContext = document.getElementById("receiversCanvas" + intid).getContext('2d');
                receiversCanvasContext.clearRect(0, 0, document.getElementById('receiversCanvas' + intid).width, document.getElementById('receiversCanvas' + intid).height);
                var undoannotations = TempParticipantAnnotations[intid].pop();
                redoReceiverArray[intid].push(undoannotations);
                annotation.redrawReceiverAnnotations(style, intid);
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.undoReceiver()", e, "error");
        }
    },
    redo: function (intid) {
        try {
            if (redoArray[intid].length !== 0) {
                var redoannotations = redoArray[intid].pop();
                document.getElementById("sendersCanvas" + intid).getContext('2d').clearRect(0, 0, document.getElementById('sendersCanvas' + intid).width, document.getElementById('sendersCanvas' + intid).height);
                TempAnnotations[intid].push(redoannotations);
                annotation.redrawAnnotations(intid);
                if (!isCustomer) {
                    var command = {};
                    var data = this.style;

                    command.type = "redoReceiver";
                    command.data = data;
                    sendMessageForCb(command);
                }
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.redo()", e, "error");
        }
    },
    redoReceiver: function (style, intid) {
        try {
            if (redoReceiverArray[intid].length !== 0) {
                var redoannotations = redoReceiverArray[intid].pop();
                var receiversCanvasContext = document.getElementById("receiversCanvas" + intid).getContext('2d');
                receiversCanvasContext.clearRect(0, 0, document.getElementById('sendersCanvas' + intid).width, document.getElementById('sendersCanvas' + intid).height);
                TempParticipantAnnotations[intid].push(redoannotations);
                annotation.redrawReceiverAnnotations(style, intid);
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.redoReceiver()", e, "error");
        }
    },
    increaseBrushSize: function (intid) {
        try {
            if (annotation.style.brushSize < 20) {
                annotation.style.brushSize++;
                document.getElementById("sizeNumberId" + intid).children[0].innerHTML = annotation.style.brushSize.toString();
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.increaseBrushSize()", e, "error");
        }
    },
    decreaseBrushSize: function (intid) {
        try {
            if (annotation.style.brushSize > 1) {
                annotation.style.brushSize--;
                document.getElementById("sizeNumberId" + intid).children[0].innerHTML = annotation.style.brushSize.toString();
            }
        } catch (e) {
            CobrowseLogging("annotate.annotation.decreaseBrushSize()", e, "error");
        }
    },
    getAnnotationHistory: function (intid) {
        try {
            var anotHistory = Object.assign([], TempAnnotations[intid]);
            return anotHistory;
        }
        catch (e) {
            CobrowseLogging("annotate.annotation.getAnnotationHistory()", e, "error");
        }
    },
    reload: function (intid) {
        try {
            TempAnnotations[intid] = [];
            redoArray[intid] = [];
            this.redrawAnnotations(intid);
        }
        catch (e) {
            CobrowseLogging("annotate.annotation.reload()", e, "error");
        }
    }
};


var line = {
    tempObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.line,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    ParticipantObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.line,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    mouseX: 0,
    mouseY: 0,
    startAnnotation: function (style, e, intid) {
        try {
            this.tempObj.x1 = e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft;
            this.tempObj.y1 = e.offsetY - document.getElementById('sendersCanvas' + intid).offsetTop;
            this.tempObj.style = Object.assign({}, style);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "line";
                data.style = this.tempObj.style;
                data.positions = {};
                data.positions.x1 = this.tempObj.x1;
                data.positions.y1 = this.tempObj.y1;

                command.type = "startAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.line.startAnnotation()", e, "error");
        }
    },
    startParticipantAnnotation: function (style, e) {
        try {
            this.ParticipantObj.x1 = e.x1 * (cbScaleX - 0.016);
            this.ParticipantObj.y1 = e.y1 * cbScaleY;
            this.ParticipantObj.style = Object.assign({}, style);
        } catch (e) {
            CobrowseLogging("annotate.line.startParticipantAnnotation()", e, "error");
        }
    },
    finishAnnotation: function (e, intid) {
        try {
            this.draw(this.tempObj, intid);
            this.save(intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "line";

                command.type = "finishAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.line.finishAnnotation()", e, "error");
        }
    },
    finishParticipantAnnotation: function (intid) {
        try {
            this.drawParticipant(this.ParticipantObj, intid);
            this.saveParticipant(intid);
        } catch (e) {
            CobrowseLogging("annotate.line.finishParticipantAnnotation()", e, "error");
        }
    },
    updateAnnotation: function (e, intid) {
        try {
            this.tempObj.x2 = e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft;
            this.tempObj.y2 = e.offsetY - document.getElementById('sendersCanvas' + intid).offsetTop;
            this.draw(this.tempObj, intid);
            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "line";
                data.positions = {};
                data.positions.x2 = this.tempObj.x2;
                data.positions.y2 = this.tempObj.y2;

                command.type = "updateAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.line.updateAnnotation()", e, "error");
        }
    },
    updateParticipantAnnotation: function (e, intid) {
        try {
            this.ParticipantObj.x2 = e.x2 * (cbScaleX - 0.016);
            this.ParticipantObj.y2 = e.y2 * cbScaleY;
            //this.drawParticipant(this.ParticipantObj, intid);
        } catch (e) {
            CobrowseLogging("annotate.line.updateParticipantAnnotation()", e, "error");
        }
    },
    draw: function (obj, intid) {
        try {
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            document.getElementById("sendersCanvas" + intid).getContext('2d').beginPath();
            document.getElementById("sendersCanvas" + intid).getContext('2d').moveTo(obj.x1, obj.y1);
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineTo(obj.x2, obj.y2);
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
            document.getElementById("sendersCanvas" + intid).getContext('2d').stroke();
            document.getElementById("sendersCanvas" + intid).getContext('2d').closePath();
        } catch (e) {
            CobrowseLogging("annotate.line.draw()", e, "error");
        }
    },
    drawParticipant: function (obj, intid) {
        try {
            var receiverContext = document.getElementById("receiversCanvas" + intid).getContext("2d");
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            receiverContext.beginPath();
            receiverContext.moveTo(obj.x1, obj.y1);
            receiverContext.lineTo(obj.x2, obj.y2);
            receiverContext.strokeStyle = obj.style.brushColor;
            receiverContext.lineWidth = obj.style.brushSize;
            receiverContext.stroke();
            receiverContext.closePath();
        } catch (e) {
            CobrowseLogging("annotate.line.drawParticipant()", e, "error");
        }
    },
    save: function (intid) {
        try {
            var obj = Object.assign({}, this.tempObj);
            TempAnnotations[intid].push(obj);
            this.tempObj.x1 = -1;
            this.tempObj.y1 = -1;
            this.tempObj.x2 = -1;
            this.tempObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.line.save()", e, "error");
        }
    },
    saveParticipant: function (intid) {
        try {
            var obj = Object.assign({}, this.ParticipantObj);
            TempParticipantAnnotations[intid].push(obj);
            this.ParticipantObj.x1 = -1;
            this.ParticipantObj.y1 = -1;
            this.ParticipantObj.x2 = -1;
            this.ParticipantObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.line.saveParticipant()", e, "error");
        }
    }
};

var arrow = {
    tempObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.arrow,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    ParticipantObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.arrow,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    mouseX: 0,
    mouseY: 0,
    startAnnotation: function (style, e, intid) {
        try {
            this.tempObj.x1 = e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft;
            this.tempObj.y1 = e.offsetY - document.getElementById('sendersCanvas' + intid).offsetTop;
            this.tempObj.style = Object.assign({}, style);
            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "arrow";
                data.style = this.tempObj.style;
                data.positions = {};
                data.positions.x1 = this.tempObj.x1;
                data.positions.y1 = this.tempObj.y1;

                command.type = "startAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.arrow.startAnnotation()", e, "error");
        }
    },
    startParticipantAnnotation: function (style, e) {
        try {
            this.ParticipantObj.x1 = e.x1 * (cbScaleX - 0.016);
            this.ParticipantObj.y1 = e.y1 * cbScaleY;
            this.ParticipantObj.style = Object.assign({}, style);
        } catch (e) {
            CobrowseLogging("annotate.arrow.startParticipantAnnotation()", e, "error");
        }
    },
    finishAnnotation: function (e, intid) {
        try {
            this.draw(this.tempObj, intid);
            this.save(intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "arrow";

                command.type = "finishAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.arrow.finishAnnotation()", e, "error");
        }
    },
    finishParticipantAnnotation: function (intid) {
        try {
            this.drawParticipant(this.ParticipantObj, intid);
            this.saveParticipant(intid);
        } catch (e) {
            CobrowseLogging("annotate.arrow.finishParticipantAnnotation()", e, "error");
        }
    },
    updateAnnotation: function (e, intid) {
        try {
            this.tempObj.x2 = e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft;
            this.tempObj.y2 = e.offsetY - document.getElementById('sendersCanvas' + intid).offsetTop;
            this.draw(this.tempObj, intid);
            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "arrow";
                data.positions = {};
                data.positions.x2 = this.tempObj.x2;
                data.positions.y2 = this.tempObj.y2;

                command.type = "updateAnnotation";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.arrow.updateAnnotation()", e, "error");
        }
    },
    updateParticipantAnnotation: function (e, intid) {
        try {
            this.ParticipantObj.x2 = e.x2 * (cbScaleX - 0.016);
            this.ParticipantObj.y2 = e.y2 * cbScaleY;
            //this.drawParticipant(this.ParticipantObj, intid);
        } catch (e) {
            CobrowseLogging("annotate.arrow.updateParticipantAnnotation()", e, "error");
        }
    },
    draw: function (obj, intid) {
        try {
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            document.getElementById("sendersCanvas" + intid).getContext('2d').beginPath();
            document.getElementById("sendersCanvas" + intid).getContext('2d').moveTo(obj.x1, obj.y1);
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineTo(obj.x2, obj.y2);
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
            document.getElementById("sendersCanvas" + intid).getContext('2d').stroke();
            document.getElementById("sendersCanvas" + intid).getContext('2d').closePath();
            arrow.drawArrowhead(obj.x1, obj.y1, obj.x2, obj.y2, obj, intid);
        } catch (e) {
            CobrowseLogging("annotate.arrow.draw()", e, "error");
        }
    },
    drawParticipant: function (obj, intid) {
        try {
            var receiverContext = document.getElementById("receiversCanvas" + intid).getContext("2d");
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            receiverContext.beginPath();
            receiverContext.moveTo(obj.x1, obj.y1);
            receiverContext.lineTo(obj.x2, obj.y2);
            receiverContext.strokeStyle = obj.style.brushColor;
            receiverContext.lineWidth = obj.style.brushSize;
            receiverContext.stroke();
            receiverContext.closePath();
            arrow.drawParticipantArrowhead(obj.x1, obj.y1, obj.x2, obj.y2, obj, intid);
        } catch (e) {
            CobrowseLogging("annotate.arrow.drawParticipant()", e, "error");
        }
    },
    drawArrowhead: function (x1, y1, x2, y2, obj, intid) {
        try {
            var PI2 = Math.PI * 2;
            var dx = x2 - x1;
            var dy = y2 - y1;
            var arrowHeadWidth = obj.style.brushSize * 2;
            var arrowHeadHeight = obj.style.brushSize * 4;
            var radians = (Math.atan2(dy, dx) + PI2) % PI2;
            document.getElementById("sendersCanvas" + intid).getContext('2d').save();
            document.getElementById("sendersCanvas" + intid).getContext('2d').beginPath();
            document.getElementById("sendersCanvas" + intid).getContext('2d').translate(x2, y2);
            document.getElementById("sendersCanvas" + intid).getContext('2d').rotate(radians);
            document.getElementById("sendersCanvas" + intid).getContext('2d').moveTo(obj.style.brushSize, 0);
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineTo(-arrowHeadHeight, arrowHeadWidth);
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineTo(-arrowHeadHeight, -arrowHeadWidth);
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
            document.getElementById("sendersCanvas" + intid).getContext('2d').closePath();
            document.getElementById("sendersCanvas" + intid).getContext('2d').fillStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').fill();
            document.getElementById("sendersCanvas" + intid).getContext('2d').restore();
        } catch (e) {
            CobrowseLogging("annotate.arrow.drawArrowhead()", e, "error");
        }
    },
    drawParticipantArrowhead: function (x1, y1, x2, y2, obj, intid) {
        try {
            var receiverContext = document.getElementById("receiversCanvas" + intid).getContext("2d");
            var PI2 = Math.PI * 2;
            var dx = x2 - x1;
            var dy = y2 - y1;
            var arrowHeadWidth = obj.style.brushSize * 2;
            var arrowHeadHeight = obj.style.brushSize * 4;
            var radians = (Math.atan2(dy, dx) + PI2) % PI2;
            receiverContext.save();
            receiverContext.beginPath();
            receiverContext.translate(x2, y2);
            receiverContext.rotate(radians);
            receiverContext.moveTo(obj.style.brushSize, 0);
            receiverContext.lineTo(-arrowHeadHeight, arrowHeadWidth);
            receiverContext.lineTo(-arrowHeadHeight, -arrowHeadWidth);
            receiverContext.strokeStyle = obj.style.brushColor;
            receiverContext.lineWidth = obj.style.brushSize;
            receiverContext.closePath();
            receiverContext.fillStyle = obj.style.brushColor;
            receiverContext.fill();
            receiverContext.restore();
        } catch (e) {
            CobrowseLogging("annotate.arrow.drawParticipantArrowhead()", e, "error");
        }
    },
    save: function (intid) {
        try {
            var obj = Object.assign({}, this.tempObj);
            TempAnnotations[intid].push(obj);
            this.tempObj.x1 = -1;
            this.tempObj.y1 = -1;
            this.tempObj.x2 = -1;
            this.tempObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.arrow.save()", e, "error");
        }
    },
    saveParticipant: function (intid) {
        try {
            var obj = Object.assign({}, this.ParticipantObj);
            TempParticipantAnnotations[intid].push(obj);
            this.ParticipantObj.x1 = -1;
            this.ParticipantObj.y1 = -1;
            this.ParticipantObj.x2 = -1;
            this.ParticipantObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.arrow.saveParticipant()", e, "error");
        }
    }
};


var elipse = {
    tempObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.elipse,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    ParticipantObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.elipse,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    x1: 0,
    y1: 0,
    mousex: 0,
    mousey: 0,
    last_mousex: 0,
    last_mousey: 0,
    startDrawing: function (style, e, intid) {
        try {
            this.last_mousex = parseInt(e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft);
            this.last_mousey = parseInt(e.offsetY - document.getElementById('sendersCanvas' + intid).offsetTop);
            this.tempObj.style = Object.assign({}, style);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "elipse";
                data.style = this.tempObj.style;
                //data.positions = {};
                //data.positions.x1 = this.tempObj.x1;
                //data.positions.y1 = this.tempObj.y1;

                command.type = "startDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.elipse.startDrawing()", e, "error");
        }
    },
    startParticipantDrawing: function (style) {
        try {
            this.ParticipantObj.style = Object.assign({}, style);
        } catch (e) {
            CobrowseLogging("annotate.elipse.startParticipantDrawing()", e, "error");
        }
    },
    finishDrawing: function (e, intid) {
        try {
            this.draw(this.tempObj, intid);
            this.save(intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "elipse";

                command.type = "finishDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.elipse.finishDrawing()", e, "error");
        }
    },
    finishParticipantDrawing: function (intid) {
        try {
            this.drawParticipant(this.ParticipantObj, intid);
            this.saveParticipant(intid);
        } catch (e) {
            CobrowseLogging("annotate.elipse.finishParticipantDrawing()", e, "error");
        }
    },
    updatePositions: function (e, intid) {
        try {
            document.getElementById("sendersCanvas" + intid).getContext('2d').clearRect(0, 0, document.getElementById('sendersCanvas' + intid).width, document.getElementById('sendersCanvas' + intid).height);
            this.mousex = parseInt(e.offsetX - document.getElementById('sendersCanvas' + intid).offsetLeft);
            this.mousey = parseInt(e.offsetY - document.getElementById('sendersCanvas' + intid).offsetLeft);

            this.tempObj.x1 = this.last_mousex;
            this.tempObj.y1 = this.last_mousey;
            this.tempObj.x2 = this.mousex;
            this.tempObj.y2 = this.mousey;
            this.draw(this.tempObj, intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "elipse";
                data.positions = {};
                data.positions.x1 = this.tempObj.x1;
                data.positions.y1 = this.tempObj.y1;
                data.positions.x2 = this.tempObj.x2;
                data.positions.y2 = this.tempObj.y2;

                command.type = "updatePositions";
                command.data = data;
                sendMessageForCb(command);
            }

        } catch (e) {
            CobrowseLogging("annotate.elipse.updatePositions()", e, "error");
        }
    },
    updateParticipantPositions: function (e, intid) {
        try {
            this.ParticipantObj.x1 = e.x1 * (cbScaleX - 0.016);
            this.ParticipantObj.y1 = e.y1 * (cbScaleX - 0.016);
            this.ParticipantObj.x2 = e.x2 * cbScaleY;
            this.ParticipantObj.y2 = e.y2 * cbScaleY;
            //this.drawParticipant(this.ParticipantObj, intid);
        } catch (e) {
            CobrowseLogging("annotate.elipse.updateParticipantPositions()", e, "error");
        }
    },
    draw: function (obj, intid) {
        try {
            //ctx.clearRect(0, 0, canvas.width, canvas.height); //clear canvas
            //Save
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            document.getElementById("sendersCanvas" + intid).getContext('2d').beginPath();
            document.getElementById("sendersCanvas" + intid).getContext('2d').save();
            //Dynamic scaling
            var scalex = 1 * ((obj.x2 - obj.x1) / 2);
            var scaley = 1 * ((obj.y2 - obj.y1) / 2);
            document.getElementById("sendersCanvas" + intid).getContext('2d').scale(scalex, scaley);
            //Create ellipse
            var centerx = (obj.x1 / scalex) + 1;
            var centery = (obj.y1 / scaley) + 1;
            document.getElementById("sendersCanvas" + intid).getContext('2d').arc(centerx, centery, 1, 0, 2 * Math.PI);
            //Restore and draw
            document.getElementById("sendersCanvas" + intid).getContext('2d').restore();
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
            document.getElementById("sendersCanvas" + intid).getContext('2d').stroke();
            document.getElementById("sendersCanvas" + intid).getContext('2d').closePath();
        } catch (e) {
            CobrowseLogging("annotate.elipse.draw()", e, "error");
        }
    },
    drawParticipant: function (obj, intid) {
        try {
            var receiverContext = document.getElementById("receiversCanvas" + intid).getContext("2d");
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            receiverContext.beginPath();
            receiverContext.save();
            //Dynamic scaling
            var scalex = 1 * ((obj.x2 - obj.x1) / 2);
            var scaley = 1 * ((obj.y2 - obj.y1) / 2);
            receiverContext.scale(scalex, scaley);
            //Create ellipse
            var centerx = (obj.x1 / scalex) + 1;
            var centery = (obj.y1 / scaley) + 1;
            receiverContext.arc(centerx, centery, 1, 0, 2 * Math.PI);
            //Restore and draw
            receiverContext.restore();
            receiverContext.strokeStyle = obj.style.brushColor;
            receiverContext.lineWidth = obj.style.brushSize;
            receiverContext.stroke();
            receiverContext.closePath();

        } catch (e) {
            CobrowseLogging("annotate.elipse.drawParticipant()", e, "error");
        }
    },
    save: function (intid) {
        try {
            var obj = Object.assign({}, this.tempObj);
            TempAnnotations[intid].push(obj);
            this.tempObj.x1 = -1;
            this.tempObj.y1 = -1;
            this.tempObj.x2 = -1;
            this.tempObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.elipse.save()", e, "error");
        }
    },
    saveParticipant: function (intid) {
        try {
            var obj = Object.assign({}, this.ParticipantObj);
            TempParticipantAnnotations[intid].push(obj);
            this.ParticipantObj.x1 = -1;
            this.ParticipantObj.y1 = -1;
            this.ParticipantObj.x2 = -1;
            this.ParticipantObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.elipse.saveParticipant()", e, "error");
        }
    }
};

var rectangle = {
    tempObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.rectangle,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    ParticipantObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.rectangle,
        x1: -1,
        y1: -1,
        x2: -1,
        y2: -1
    },
    startDrawing: function (style, e, intid) {
        try {
            var rect = document.getElementById('sendersCanvas' + intid).getBoundingClientRect();
            this.tempObj.x1 = e.clientX - rect.left;
            this.tempObj.y1 = e.clientY - rect.top;
            this.tempObj.style = Object.assign({}, style);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "rectangle";
                data.style = this.tempObj.style;
                data.positions = {};
                data.positions.x1 = this.tempObj.x1;
                data.positions.y1 = this.tempObj.y1;

                command.type = "startDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.rectangle.startDrawing()", e, "error");
        }
    },
    startParticipantDrawing: function (style, e) {
        try {
            this.ParticipantObj.x1 = e.x1 * (cbScaleX - 0.016);
            this.ParticipantObj.y1 = e.y1 * cbScaleY;
            this.ParticipantObj.style = Object.assign({}, style);
        } catch (e) {
            CobrowseLogging("annotate.rectangle.startParticipantDrawing()", e, "error");
        }
    },
    finishDrawing: function (e, intid) {
        try {
            this.save(intid);
            this.draw(this.tempObj, intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "rectangle";

                command.type = "finishDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.rectangle.finishDrawing()", e, "error");
        }
    },
    finishParticipantDrawing: function (intid) {
        try {
            this.drawParticipant(this.ParticipantObj, intid);
            this.saveParticipant(intid);
        } catch (e) {
            CobrowseLogging("annotate.rectangle.finishParticipantDrawing()", e, "error");
        }
    },
    updatePositions: function (e, intid) {
        try {
            var rect = document.getElementById('sendersCanvas' + intid).getBoundingClientRect();
            this.tempObj.x2 = e.clientX - rect.left;
            this.tempObj.y2 = e.clientY - rect.top;
            //annotCanvasContext.clearRect(0, 0, sendersCanvas.width, sendersCanvas.height);
            //annotCanvasContext.strokeStyle = 'rgba(0, 0, 0, 1)';
            this.draw(this.tempObj, intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "rectangle";
                data.positions = {};
                data.positions.x2 = this.tempObj.x2;
                data.positions.y2 = this.tempObj.y2;

                command.type = "updatePositions";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.rectangle.updatePositions()", e, "error");
        }
    },
    updateParticipantPositions: function (e, intid) {
        try {
            this.ParticipantObj.x2 = e.x2 * (cbScaleX - 0.016);
            this.ParticipantObj.y2 = e.y2 * cbScaleY;
            //annotCanvasContext.clearRect(0, 0, sendersCanvas.width, sendersCanvas.height);
            //annotCanvasContext.strokeStyle = 'rgba(0, 0, 0, 1)';
            //this.drawParticipant(this.ParticipantObj, intid);
        } catch (e) {
            CobrowseLogging("annotate.rectangle.updateParticipantPositions()", e, "error");
        }
    },
    draw: function (obj, intid) {
        try {
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
            document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
            document.getElementById('sendersCanvas' + intid).getContext('2d').strokeRect(obj.x1, obj.y1, obj.x2 - obj.x1, obj.y2 - obj.y1);

        } catch (e) {
            CobrowseLogging("annotate.rectangle.draw()", e, "error");
        }
    },
    drawParticipant: function (obj, intid) {
        try {
            if (obj.x1 === -1 || obj.x2 === -1 || obj.y1 === -1 || obj.y2 === -1) {
                return;
            }
            document.getElementById("receiversCanvas" + intid).getContext("2d").strokeStyle = obj.style.brushColor;
            document.getElementById("receiversCanvas" + intid).getContext("2d").lineWidth = obj.style.brushSize;
            document.getElementById("receiversCanvas" + intid).getContext("2d").strokeRect(obj.x1, obj.y1, obj.x2 - obj.x1, obj.y2 - obj.y1);

        } catch (e) {
            CobrowseLogging("annotate.rectangle.drawParticipant()", e, "error");
        }
    },
    save: function (intid) {
        try {
            var obj = Object.assign({}, this.tempObj);
            TempAnnotations[intid].push(obj);
            this.tempObj.x1 = -1;
            this.tempObj.y1 = -1;
            this.tempObj.x2 = -1;
            this.tempObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.rectangle.save()", e, "error");
        }
    },
    saveParticipant: function (intid) {
        try {
            var obj = Object.assign({}, this.ParticipantObj);
            TempParticipantAnnotations[intid].push(obj);
            this.ParticipantObj.x1 = -1;
            this.ParticipantObj.y1 = -1;
            this.ParticipantObj.x2 = -1;
            this.ParticipantObj.y2 = -1;
        } catch (e) {
            CobrowseLogging("annotate.rectangle.saveParticipant()", e, "error");
        }
    }
};

var freeDraw = {
    tempObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.freeDraw,
        positions: []
    },
    ParticipantObj: {
        style: {
            brushColor: "#f8920f",
            brushSize: 5
        },
        type: annotation.types.freeDraw,
        positions: []
    },
    startDrawing: function (style, e) {
        try {
            this.tempObj.style = Object.assign({}, style);
            this.tempObj.positions.push({ 'X': e.offsetX, 'Y': e.offsetY });

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "freeDraw";
                data.style = this.tempObj.style;
                data.positions = {};
                data.positions.offsetX = e.offsetX;
                data.positions.offsetY = e.offsetY;

                command.type = "startDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.startDrawing()", e, "error");
        }
    },
    startParticipantDrawing: function (style, e) {
        try {
            this.ParticipantObj.style = Object.assign({}, style);
            this.ParticipantObj.positions.push({ 'X': e.offsetX * (cbScaleX - 0.016), 'Y': e.offsetY * cbScaleY });
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.startParticipantDrawing()", e, "error");
        }
    },
    finishDrawing: function (e, intid) {
        try {
            this.draw(this.tempObj, intid);
            this.save(intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "freeDraw";

                command.type = "finishDrawing";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.finishDrawing()", e, "error");
        }
    },
    finishParticipantDrawing: function (intid) {
        try {
            this.drawParticipant(this.ParticipantObj, intid);
            this.saveParticipant(intid);
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.finishParticipantDrawing()", e, "error");
        }
    },
    updatePositions: function (e, intid) {
        try {
            this.tempObj.positions.push({ 'X': e.offsetX, 'Y': e.offsetY });
            this.draw(this.tempObj, intid);

            if (!isCustomer) {
                var command = {};
                var data = {};

                data.selectedDrawType = "freeDraw";
                data.positions = {};
                data.positions.offsetX = e.offsetX;
                data.positions.offsetY = e.offsetY;

                command.type = "updatePositions";
                command.data = data;
                sendMessageForCb(command);
            }
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.updatePositions()", e, "error");
        }
    },
    updateParticipantPositions: function (e, intid) {
        try {
            this.ParticipantObj.positions.push({ 'X': e.offsetX * (cbScaleX - 0.016), 'Y': e.offsetY * cbScaleY });
            this.drawParticipant(this.ParticipantObj, intid);
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.updateParticipantPositions()", e, "error");
        }
    },
    draw: function (obj, intid) {
        try {
            document.getElementById("sendersCanvas" + intid).getContext("2d").beginPath();
            for (i = 0; i < obj.positions.length; i++) {
                document.getElementById("sendersCanvas" + intid).getContext("2d").lineTo(obj.positions[i].X, obj.positions[i].Y);
                document.getElementById("sendersCanvas" + intid).getContext("2d").strokeStyle = obj.style.brushColor;
                document.getElementById("sendersCanvas" + intid).getContext("2d").lineWidth = obj.style.brushSize;
                document.getElementById("sendersCanvas" + intid).getContext("2d").stroke();
            }
            document.getElementById("sendersCanvas" + intid).getContext("2d").closePath();
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.draw()", e, "error");
        }
    },
    drawParticipant: function (obj, intid) {
        try {
            var receiversCanvasContext = document.getElementById("receiversCanvas" + intid).getContext('2d');
            receiversCanvasContext.beginPath();
            for (i = 0; i < obj.positions.length; i++) {
                receiversCanvasContext.lineTo(obj.positions[i].X, obj.positions[i].Y);
                receiversCanvasContext.strokeStyle = obj.style.brushColor;
                receiversCanvasContext.lineWidth = obj.style.brushSize;
                receiversCanvasContext.stroke();
            }
            receiversCanvasContext.closePath();
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.drawParticipant()", e, "error");
        }
    },

    save: function (intid) {
        try {
            var obj = Object.assign({}, this.tempObj);
            TempAnnotations[intid].push(obj);
            this.tempObj.positions = [];
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.save()", e, "error");
        }
    },
    saveParticipant: function (intid) {
        try {
            var obj = Object.assign({}, this.ParticipantObj);
            TempParticipantAnnotations[intid].push(obj);
            this.ParticipantObj.positions = [];
        } catch (e) {
            CobrowseLogging("annotate.freeDraw.saveParticipant()", e, "error");
        }
    }
};


function ClearPreviousAnnotations() {
    try {
        rectangles = [];
        elipses = [];
        lines = [];
    } catch (e) {
        CobrowseLogging("annotate.ClearPreviousAnnotations()", e, "error");
    }
}

function getPosition(mouseEvent, sigCanvas) {
    try {
        var x, y;
        if (mouseEvent.pageX !== undefined && mouseEvent.pageY !== undefined) {
            x = mouseEvent.pageX;
            y = mouseEvent.pageY;

        } else {
            x = mouseEvent.clientX + coBrowseContainer.scrollLeft + document.documentElement.scrollLeft;
            y = mouseEvent.clientY + coBrowseContainer.scrollTop + document.documentElement.scrollTop;
        }

        return {
            X: x - sigCanvas.offsetLeft,
            Y: y - sigCanvas.offsetTop
        };
    } catch (e) {
        CobrowseLogging("annotate.getPosition()", e, "error");
    }
}

function setAnnotCanvasAndDiv(width, height, type, intid) {
    try {
        //width = parseInt(width, 10);
        //height = parseInt(height, 10);
        var annotdiv = document.getElementById('annotdiv' + intid);
        var sendersCanvas = document.getElementById('sendersCanvas' + intid);
        var datacanvas = document.getElementById('datacanvas' + intid);
        var receiversCanvas = document.getElementById('receiversCanvas' + intid);

        if (annotdiv) {
            annotdiv.width = width;
            annotdiv.height = height;
            //annotdiv.getContext('2d').save();
        }
        if (sendersCanvas) {
            sendersCanvas.width = width;
            sendersCanvas.height = height;
            //sendersCanvas.getContext('2d').save();
        }
        if (datacanvas) {
            datacanvas.width = width;
            datacanvas.height = height;
            //datacanvas.getContext('2d').save();
        }
        if (receiversCanvas) {
            receiversCanvas.width = width;
            receiversCanvas.height = height;
            //receiversCanvas.getContext('2d').save();
        }
        //if (type === "pdf" || type === "image") {
        //    annotdiv.width = width;
        //    annotdiv.height = height;

        //    //coBrowseContainer.style.width = width + "px";
        //    //coBrowseContainer.style.height = height + "px";

        //    if (canvasSizeSet === false && height !== 0) {
        //        annotdiv.width = width;
        //        annotdiv.height = height;
        //        sendersCanvas.width = width;
        //        sendersCanvas.height = height;
        //        datacanvas.width = width;
        //        datacanvas.height = height;

        //        if (isCustomer) {
        //            receiversCanvas.width = width;
        //            receiversCanvas.height = height;
        //        }
        //    }
        //}
        //else {
        //    annotdiv.style.width = width + "%";
        //    annotdiv.style.height = height + "%";

        //    sendersCanvas.width = width + "%";
        //    sendersCanvas.height = height + "%";

        //    datacanvas.width = width + "%";
        //    datacanvas.height = height + "%";

        //    if (isCustomer) {
        //        receiversCanvas.width = width + "%";
        //        receiversCanvas.height = height + "%";
        //    }
        //}


    }
    catch (e) {
        CobrowseLogging("annotate.setAnnotCanvasAndDiv()", e, "error");
    }
}

/**
 * Delete elements if they exist such as canvas, mouse pointer and mouse pointer
 * @param intid Interaction Id of Chat (for Agent)
 */
function DestroyCobrowseElements(intid) {
    try {
        if (document.getElementById('sendersCanvas' + intid) !== null)
            document.getElementById('sendersCanvas' + intid).parentNode.removeChild(document.getElementById('sendersCanvas' + intid));
        if (document.getElementById('datacanvas' + intid) !== null)
            document.getElementById('datacanvas' + intid).parentNode.removeChild(document.getElementById('datacanvas' + intid));
        if (document.getElementById('annotdiv' + intid) !== null)
            document.getElementById('annotdiv' + intid).parentNode.removeChild(document.getElementById('annotdiv' + intid));
        if (document.getElementById('annotToolbox' + intid) !== null)
            document.getElementById('annotToolbox' + intid).parentNode.removeChild(document.getElementById('annotToolbox' + intid));
        if (document.getElementById('mycursor' + intid) !== null)
            document.getElementById('mycursor' + intid).parentNode.removeChild(document.getElementById('mycursor' + intid));
        if (isCustomer) {
            if (document.getElementById('receiversCanvas') !== null)
                document.getElementById('receiversCanvas').parentNode.removeChild(document.getElementById('receiversCanvas'));
        }
    } catch (e) {
        CobrowseLogging("annotate.DestroyCobrowseElements()", e, "error");
    }
}

/**
 * 
 * @param intid Interaction ID of the chat
 * @param isMousePointerCapture Boolean to indicate if mouse pointer needs to be captured or not
 */
function InitializeCobrowseVariables(intid, isMousePointerCapture) {
    try {
        redoArray[intid] = [];
        redoReceiverArray[intid] = [];
        TempAnnotations[intid] = [];
        TempParticipantAnnotations[intid] = [];
        mousePointer[intid] = {
            isUserMouseCaptureEnabled: isMousePointerCapture, //Used to denote if the Current user co-browsing has mouse capture enabled or not
            isReceiverMouseCaptureEnabled: false, //Used to denote if the receiver/participant has mouse capture enabled or not
            lastXPosition: 0, //X Coordinate of the Receiver's Mouse Pointer
            lastYPosition: 0 //Y Coordinate of the Receiver's Mouse Pointer
        };
    } catch (e) {
        CobrowseLogging("annotate.InitializeCobrowseVariables()", e, "error");
    }
}

/**
 * 
 * @param intid
 */
function DestroyCobrowseVariables(intid) {
    try {
        redoArray[intid] = [];
        redoReceiverArray[intid] = [];
        TempAnnotations[intid] = [];
        TempParticipantAnnotations[intid] = [];
        if (mousePointer[intid]) {
            mousePointer[intid].lastXPosition = "";
            mousePointer[intid].lastYPosition = "";
        }
    } catch (e) {
        CobrowseLogging("annotate.DestroyCobrowseVariables()", e, "error");
    }
}

/**
 * Called when Canvas and other elements need to be created and register events needed
 * @param domElement
 * @param intid
 */
function InitializeCobrowseElements(cobrowseArea, intid, isAnnotationEnabled) {
    try {

        //Create sendersCanvas, this is the canvas upon which the user will annotate, for Customer side his annotation will be on this canvas, for agent side his annotation will be on this canvas
        var sendersCanvas = document.createElement("canvas");
        sendersCanvas.style.position = "absolute";
        sendersCanvas.id = "sendersCanvas" + intid;
        sendersCanvas.style.zIndex = 999999998;
        cobrowseArea.appendChild(sendersCanvas);

        //Set Canvas strokestyle, brushColor etc.
        sendersCanvas.getContext("2d").strokeStyle = brushColor;
        sendersCanvas.getContext("2d").lineJoin = "round";
        sendersCanvas.getContext("2d").lineWidth = brushSize;

        //Creating base canvas to load image/pdf/form
        //var dataCanvas = document.createElement("canvas");
        //dataCanvas.id = "datacanvas" + intid;
        //dataCanvas.style.position = "absolute";
        //cobrowseArea.appendChild(dataCanvas);

        //Creating a div to receive and draw the annotations
        //var div1 = document.getElementById("annotdiv");
        //if (div1 !== null) {
        //    cobrowseArea.removeChild(div1);
        //}

        //Create receiversCanvas only on the Customer side
        if (isCustomer) {
            //Create receiversCanvas, this is the canvas upon which the participant annotation will be drawn, on the Customer side the agent annotation will be drawn here
            var receiversCanvas = document.createElement("canvas");
            receiversCanvas.id = "receiversCanvas";
            receiversCanvas.style.zIndex = 999999997;
            cobrowseArea.appendChild(receiversCanvas);
        }

        //var annotDiv = document.createElement("div");
        //annotDiv.id = "annotdiv" + intid;
        //annotDiv.style.position = "absolute";
        //cobrowseArea.appendChild(annotDiv);

        //Create Annotation toolbox if annotation is enabled
        if (isAnnotationEnabled) {
            CreateAnnotToolbox(intid);
        }

        //Disable annotation at the start
        annotation.disable(intid);

        //Register events on the senderCanvas to detect drawing via mouse and touch
        sendersCanvas.onmousedown = function (e) {
            try {
                var intid = sendersCanvas.id.split("sendersCanvas")[1];
                annotation.drawEvent(annotation.drawEventTypes.startDrawing, e, intid);
            } catch (e) {
                CobrowseLogging("annotate.sendersCanvas.onmousedown()", e, "error");
            }
        };

        sendersCanvas.onmouseup = function (e) {
            try {
                var intid = sendersCanvas.id.split("sendersCanvas")[1];
                annotation.drawEvent(annotation.drawEventTypes.finishDrawing, e, intid);
            } catch (e) {
                CobrowseLogging("annotate.sendersCanvas.onmouseup()", e, "error");
            }
        };

        sendersCanvas.onmousemove = function (e) {
            try {
                var intid = sendersCanvas.id.split("sendersCanvas")[1];
                annotation.drawEvent(annotation.drawEventTypes.updatePositions, e, intid);
            } catch (e) {
                CobrowseLogging("annotate.sendersCanvas.onmousemove()", e, "error");
            }
        };

        sendersCanvas.onmouseout = function (e) {
            try {
                var intid = sendersCanvas.id.split("sendersCanvas")[1];
                annotation.drawEvent(annotation.drawEventTypes.finishDrawing, e, intid);
            } catch (e) {
                CobrowseLogging("annotate.sendersCanvas.onmouseout()", e, "error");
            }
        };

        // This will be defined on a TOUCH device such as iPad or Android, etc.
        var is_touch_device = 'ontouchstart' in document.documentElement;

        if (is_touch_device) {
            // create a drawer which tracks touch movements
            var drawer = {
                isDrawing: false,
                touchstart: function (coors) {
                    context.beginPath();
                    context.moveTo(coors.x, coors.y);
                    this.isDrawing = true;
                },
                touchmove: function (coors) {
                    if (this.isDrawing) {
                        context.lineTo(coors.x, coors.y);
                        context.stroke();
                    }
                },
                touchend: function (coors) {
                    if (this.isDrawing) {
                        this.touchmove(coors);
                        this.isDrawing = false;
                    }
                }
            };



            // attach the touchstart, touchmove, touchend event listeners.
            sendersCanvas.addEventListener('touchstart', function (event) { draw(event, intid); }, false);
            sendersCanvas.addEventListener('touchmove', function (event) { draw(event, intid); }, false);
            //sigCanvas.addEventListener('touchend', function (event) { draw(event, intid); }, false);

            sendersCanvas.addEventListener('touchend',
                function (event) {
                    draw(event, intid);
                    finishDrawing(event, sendersCanvas, intid);
                },
                false);

            // prevent elastic scrolling
            sendersCanvas.addEventListener('touchmove', function (event) {
                event.preventDefault();
            }, false);
        }

    } catch (e) {
        CobrowseLogging("annotate.InitializeCobrowseElements()", e, "error");
    }
}

// create a function to pass touch events and coordinates to drawer
function draw(event, intid) {
    try {
        // get the touch coordinates.  Using the first touch in case of multi-touch
        var coors = {
            x: event.targetTouches[0].pageX,
            y: event.targetTouches[0].pageY
        };

        // Now we need to get the offset of the canvas location
        var obj = document.getElementById('sendersCanvas' + intid);

        if (obj.offsetParent) {
            // Every time we find a new object, we add its offsetLeft and offsetTop to curleft and curtop.
            do {
                coors.x -= obj.offsetLeft;
                coors.y -= obj.offsetTop;
            }
            // The while loop can be "while (obj = obj.offsetParent)" only, which does return null
            // when null is passed back, but that creates a warning in some editors (i.e. VS2010).
            while ((obj = obj.offsetParent) != null);
        }

        // pass the coordinates to the appropriate handler
        drawer[event.type](coors);
    } catch (e) {
        CobrowseLogging("annotate.draw()", e, "error");
    }
}

// draws a line to the x and y coordinates of the mouse event inside
// the specified element using the specified context
//function drawLine(mouseEvent, sigCanvas, context) {
//    try {
//        if (isFreeDraw) {
//            var position = getPosition(mouseEvent, sigCanvas);
//            freeAnnotObj.positions.push({ 'X': position.X, 'Y': position.Y });
//            context.lineTo(position.X, position.Y);
//            context.stroke();
//        }
//    } catch (e) {
//        CobrowseLogging("annotate.drawLine()", e, "error");
//    }
//}

// draws a line from the last coordiantes in the path to the finishing
// coordinates and unbind any event handlers which need to be preceded
// by the mouse down event
function finishDrawing(mouseEvent, sigCanvas, intid) {
    try {
        // draw the line to the finishing coordinates
        //drawLine(mouseEvent, sigCanvas, context);
        if (isFreeDraw) {
            var obj = Object.assign({}, freeAnnotObj);
            TempAnnotations[intid].push(obj);
            freeAnnotObj.positions = [];
            document.getElementById("receiversCanvas" + intid).getContext("2d").closePath();
        }

        //sendAnnotData();
        annotstatus[currentPage] = true;
    } catch (e) {
        CobrowseLogging("annotate.finishDrawing()", e, "error");
    }
}

//Coverting canvas to image and sending data
function sendAnnotData() {
    try {
        //return;//
        var canvas = document.getElementById("sendersCanvas");
        var data = canvas.toDataURL();

        var command = {};
        command.type = "annot";
        command.data = data;
        sendMessageForCb(command);
    } catch (e) {
        CobrowseLogging("annotate.sendAnnotData()", e, "error");
    }
}

// Clear the canvas context using the canvas width and height
function clearCanvas(intid) {
    try {
        var canvas = document.getElementById("sendersCanvas" + intid);
        var ctx = canvas.getContext("2d");
        var interactionId = intid;
        TempAnnotations[intid] = [];
        ClearPreviousAnnotations();
        //document.getElementById('annotdiv').style.background="";
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (isPdf) {
            annotCanvasArray[currentPage] = [];
            showPDF(pdfUrl, currentPage);
        }
        else if (isImage) {
            var image = new Image();
            image.src = imageUrl;
            image.onload = function () {
                if (image.width > document.getElementById('datacanvas' + interactionId).width || image.height > document.getElementById('datacanvas' + interactionId).height) {
                    DrawImageOnCanvas(document.getElementById('datacanvas' + interactionId), document.getElementById('datacanvas' + interactionId).getContext("2d"), image);
                }
                else {
                    //document.getElementById('sendersCanvas').width = image.width;
                    //document.getElementById('sendersCanvas').height = image.height;
                    document.getElementById('datacanvas' + interactionId).getContext("2d").drawImage(image, 0, 0, image.width, image.height);
                }
                //sendAnnotData();
                //();
                if (isCustomer) {
                    UpdateData();
                }
                else {
                    var command = {};

                    command.type = "clearReceiverCanvas";
                    command.data = "";
                    sendMessageForCb(command);
                }
            };
        }
        else {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
        //sendAnnotData();
        if (isCustomer) {
            UpdateData();
        }
        else {
            var command = {};

            command.type = "clearReceiverCanvas";
            command.data = "";
            sendMessageForCb(command);
        }
    } catch (e) {
        CobrowseLogging("annotate.clearCanvas()", e, "error");
    }
}


//Receiving annotation data from peer
function annotReceived(data) {
    try {
        var annotdiv = document.getElementById("annotdiv");
        //annotdiv.style.width = "100%";
        //annotdiv.style.height = "100%";
        var image = new Image();
        image.src = data;
        var img = "url('" + data + "')";
        annotdiv.style.background = img;

        annotdiv.style.backgroundRepeat = "no-repeat";
        annotstatus[currentPage] = true;

    } catch (e) {
        CobrowseLogging("annotate.annotReceived()", e, "error");
    }
}

function SaveCustomerAnnotation(pageNo) {
    try {
        annotCanvasArray[pageNo] = annotation.getAnnotationHistory();
        annotation.reload();
    } catch (exception) {
        console.log(exception);
    }
}


function captureCanvasWithAnnotations() {
    var tempCanvas = document.createElement('canvas');
    var ctx = tempCanvas.getContext('2d');
    var img = new Image();
    var dataCanvasData = document.getElementById("datacanvas").toDataURL();
    //console.log("beforeDataCanvasdata", dataCanvasData);
    img.src = dataCanvasData;
    var height = 0;
    var width = 0;
    img.onload = function () {
        height = img.height;
        width = img.width;
        //base canvas image
        tempCanvas.height = height;
        tempCanvas.width = width;
        ctx.drawImage(img, 0, 0, width, height);
        //console.log("afterdataCanvasData", tempCanvas.toDataURL());

        //user annot
        var img1 = new Image();
        var annotDivData = document.getElementById("annotdiv").style.background.replace('url("', '').replace('")', '').replace(" no-repeat", ""); //sendersCanvas.toDataURL();
        //console.log("beforeAnnotDivData", annotDivData);
        img1.src = annotDivData;
        img1.onload = function () {
            ctx.drawImage(img1, 0, 0, width, height);
            //console.log("afterAnnotDivData", tempCanvas.toDataURL());

            //agent annot 
            var img2 = new Image();

            var annotCanvasData = document.getElementById("sendersCanvas").toDataURL();  //annotdiv.background-image
            //console.log("beforeAnnotCanvasData", annotCanvasData)
            img2.src = annotCanvasData;
            img2.onload = function () {
                ctx.drawImage(img2, 0, 0, width, height);
                //console.log("afterAnnotCanvasData", tempCanvas.toDataURL());

                // aLink.href = tempCanvas.toDataURL();
                // aLink.click();	
                //return tempCanvas.toDataURL();
                parent.SaveImageToServer(tempCanvas.toDataURL());
            };
        };
    };
}

function DrawImageOnCanvas(canvas, context, imageObj) {
    try {
        var imageAspectRatio = imageObj.width / imageObj.height;
        var canvasAspectRatio = canvas.width / canvas.height;
        var renderableHeight, renderableWidth, xStart, yStart;

        // If image's aspect ratio is less than canvas's we fit on height
        // and place the image centrally along width
        if (imageAspectRatio < canvasAspectRatio) {
            renderableHeight = canvas.height;
            renderableWidth = imageObj.width * (renderableHeight / imageObj.height);
            xStart = (canvas.width - renderableWidth) / 2;
            yStart = 0;
        }

        // If image's aspect ratio is greater than canvas's we fit on width
        // and place the image centrally along height
        else if (imageAspectRatio > canvasAspectRatio) {
            renderableWidth = canvas.width;
            renderableHeight = imageObj.height * (renderableWidth / imageObj.width);
            xStart = 0;
            yStart = (canvas.height - renderableHeight) / 2;
        }

        // Happy path - keep aspect ratio
        else {
            renderableHeight = canvas.height;
            renderableWidth = canvas.width;
            xStart = 0;
            yStart = 0;
        }
        context.drawImage(imageObj, xStart, yStart, renderableWidth, renderableHeight);
    } catch (e) {
        CobrowseLogging("annotate.DrawImageOnCanvas()", e, "error");
    }
}
//--------------Function Definations------------------


//-------------------------------------- Create Annot toolbox - START -------------------------------
//Creating Button to stop annotation
function CreateStopAnnotTool(intid) {
    try {
        var stopButton = document.createElement("a");
        stopButton.id = "stopId" + intid;
        stopButton.title = "Stop Annotate";
        stopButton.classList.add("toolboxButton");
        stopButton.style.display = "none";
        stopButton.href = "#";
        stopButton.innerHTML = "<i class='fas fa-times'></i>";
        stopButton.addEventListener('click', function () {
            annotation.disable(intid);
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            document.getElementById("stopId" + intid).style.display = "none";
            document.getElementById("startId" + intid).style.display = "block";
            document.getElementById("clearId" + intid).style.display = "none";
            document.getElementById("ColorPaletId" + intid).style.display = "none";
            document.getElementById("ShapePaletId" + intid).style.display = "none";
            document.getElementById("undoId" + intid).style.display = "none";
            document.getElementById("redoId" + intid).style.display = "none";
            document.getElementById("sizeIncreaseId" + intid).style.display = "none";
            document.getElementById("sizeNumberId" + intid).style.display = "none";
            document.getElementById("sizeDecreaseId" + intid).style.display = "none";
            //document.getElementById("textId").style.display = "none";
            //document.getElementById("squareId").style.display = "none";
            //document.getElementById("highlighterId").style.display = "none";
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        return stopButton;
    } catch (ex) {
        CobrowseLogging("annotate.CreateStopAnnotTool()", ex, "error");
    }
}

//Creating Button to start annotation
function CreateStartAnnotTool(intid) {
    try {
        var startButton = document.createElement("a");
        startButton.classList.add("toolboxButton");
        startButton.id = "startId" + intid;
        startButton.title = "Start Annotate";
        startButton.href = "#";
        startButton.innerHTML = "<i class='fas fa-pencil-alt'></i>";
        startButton.addEventListener('click', function () {
            //annotation.selectAnnotationType(annotation.types.freeDraw);
            annotation.enable(intid);
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            document.getElementById("startId" + intid).style.display = "none";
            document.getElementById("ColorPaletId" + intid).style.display = "block";
            document.getElementById("ShapePaletId" + intid).style.display = "block";
            document.getElementById("stopId" + intid).style.display = "block";
            document.getElementById("clearId" + intid).style.display = "block";
            document.getElementById("undoId" + intid).style.display = "block";
            document.getElementById("redoId" + intid).style.display = "block";
            document.getElementById("sizeIncreaseId" + intid).style.display = "block";
            document.getElementById("sizeNumberId" + intid).style.display = "block";
            document.getElementById("sizeDecreaseId" + intid).style.display = "block";
            //document.getElementById("textId").style.display = "block";
            //document.getElementById("squareId").style.display = "block";
            //document.getElementById("highlighterId").style.display = "block";
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        return startButton;
    } catch (ex) {
        CobrowseLogging("annotate.CreateStartAnnotTool()", ex, "error");
    }
}

var icons = {
    shapes: {
        "pencil": "<i class='fas fa-pencil-alt'></i>",
        "elipse": "<i class='far fa-circle'></i>",
        "rectangle": "<i class='far fa-square'></i>",
        "line": "<i class='fas fa-minus'></i>",
        "arrow": "<i class='fas fa-long-arrow-alt-up'></i>"
    },
    colors: {
        "black": "#000000",
        "white": "#ffffff",
        "orange": "#F63",
        "red": "#F00",
        "yellow": "#FC0",
        "green": "#0C0",
        "blue": "#2700ff",
        "purple": "#63C"
    }

};

function SetCurrentShapeIcon(iconTag, intid) {
    try {
        var button = document.getElementById('ShapePaletId' + intid);
        button.innerHTML = iconTag;
    } catch (ex) {
        CobrowseLogging("annotate.SetCurrentShapeIcon()", ex, "error");
    }
}
function SetCurrentColorIcon(iconColor, intid) {
    try {
        var color = document.getElementById('ColorPaletId' + intid);
        color.style.color = iconColor;
    } catch (ex) {
        CobrowseLogging("annotate.SetCurrentColorIcon()", ex, "error");
    }
}

//Creating Button to free draw in canvas
function CreatePencilAnnotTool(intid) {
    try {
        var pencilButton = document.createElement("a");
        pencilButton.classList.add("toolboxButton");
        pencilButton.id = "pencilId" + intid;
        pencilButton.title = "Pencil";
        pencilButton.href = "#";
        pencilButton.innerHTML = "<i class='fas fa-pencil-alt'></i>";
        pencilButton.addEventListener('click', function () {
            annotation.selectAnnotationType(annotation.types.freeDraw);
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var shapeUL = document.getElementById("shapeInputer" + intid);
            SetCurrentShapeIcon(icons.shapes.pencil, intid);
            fadeOut(shapeUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        return pencilButton;
    } catch (ex) {
        CobrowseLogging("annotate.CreatePencilAnnotTool()", ex, "error");
    }
}

//Creating Button to clear annotation
function CreateClearAnnotTool(intid) {
    try {
        var clearBtn = document.createElement("a");
        clearBtn.classList.add("toolboxButton");
        clearBtn.id = "clearId" + intid;
        clearBtn.title = "Clear Annotate";
        clearBtn.style.display = "none";
        clearBtn.addEventListener('click', function () {
            clearCanvas(intid);
        });
        clearBtn.innerHTML = "<i class='fas fa-eraser'></i>";

        return clearBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateClearAnnotTool()", ex, "error");
    }
}

function CreateSquareAnnotTool(intid) {
    try {
        var squareBtn = document.createElement("a");
        squareBtn.classList.add("toolboxButton");
        squareBtn.id = "squareId" + intid;
        squareBtn.title = "Select Area";
        //squareBtn.style.display = "none";
        squareBtn.addEventListener('click', function () {
            annotation.selectAnnotationType(annotation.types.rectangle);
            isRectangle = true;
            isElipse = false;
            isLine = false;
            isArrow = false;
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var shapeUL = document.getElementById("shapeInputer" + intid);
            SetCurrentShapeIcon(icons.shapes.rectangle, intid);
            fadeOut(shapeUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        squareBtn.innerHTML = "<i class='far fa-square'></i>";

        return squareBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateSquareAnnotTool()", ex, "error");
    }
}

function CreateLineAnnotTool(intid) {
    try {
        var lineBtn = document.createElement("a");
        lineBtn.classList.add("toolboxButton");
        lineBtn.id = "lineId" + intid;
        lineBtn.title = "Line";
        lineBtn.addEventListener('click', function () {
            annotation.selectAnnotationType(annotation.types.line);
            isRectangle = false;
            isElipse = false;
            isLine = true;
            isArrow = false;
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var shapeUL = document.getElementById("shapeInputer" + intid);
            SetCurrentShapeIcon(icons.shapes.line, intid);
            fadeOut(shapeUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        lineBtn.innerHTML = "<i class='fas fa-minus'></i>";

        return lineBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateLineAnnotTool()", ex, "error");
    }
}

function CreateArrowAnnotTool(intid) {
    try {
        var arrowBtn = document.createElement("a");
        arrowBtn.classList.add("toolboxButton");
        arrowBtn.id = "lineId" + intid;
        arrowBtn.title = "Line";
        arrowBtn.addEventListener('click', function () {
            annotation.selectAnnotationType(annotation.types.arrow);
            isRectangle = false;
            isElipse = false;
            isLine = false;
            isArrow = true;
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var shapeUL = document.getElementById("shapeInputer" + intid);
            SetCurrentShapeIcon(icons.shapes.arrow, intid);
            fadeOut(shapeUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        arrowBtn.innerHTML = "<i class='fas fa-long-arrow-alt-up'></i>";

        return arrowBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateArrowAnnotTool()", ex, "error");
    }
}

//Create Button to Undo annotation
function CreateUndoAnnotTool(intid) {
    try {
        var UndoBtn = document.createElement("a");
        UndoBtn.classList.add("toolboxButton");
        UndoBtn.id = "undoId" + intid;
        UndoBtn.title = "Undo";
        UndoBtn.style.display = "none";
        UndoBtn.addEventListener('click', function () {
            annotation.undo(intid);
        });
        UndoBtn.innerHTML = "<i class='fas fa-undo-alt'></i>";

        return UndoBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateUndoAnnotTool()", ex, "error");
    }
}

//Create Button to Redo annotation
function CreateRedoAnnotTool(intid) {
    try {
        var RedoBtn = document.createElement("a");
        RedoBtn.classList.add("toolboxButton");
        RedoBtn.id = "redoId" + intid;
        RedoBtn.title = "Redo";
        RedoBtn.style.display = "none";
        RedoBtn.addEventListener('click', function () {
            annotation.redo(intid);

        });
        RedoBtn.innerHTML = "<i class='fas fa-redo-alt'></i>";

        return RedoBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateRedoAnnotTool()", ex, "error");
    }
}

function CreateTextAnnotTool(intid) {
    try {
        var TextBtn = document.createElement("a");
        TextBtn.classList.add("toolboxButton");
        TextBtn.id = "textId" + intid;
        TextBtn.title = "Text Box";
        //TextBtn.style.display = "none";
        TextBtn.addEventListener('click', function () {
            //clearCanvas();
        });
        TextBtn.innerHTML = "<i class='fab fa-tumblr-square'></i>";

        return TextBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateTextAnnotTool()", ex, "error");
    }
}

function CreateHighlightAnnotTool(intid) {
    try {
        var HighlighterBtn = document.createElement("a");
        HighlighterBtn.classList.add("toolboxButton");
        HighlighterBtn.id = "highlighterId" + intid;
        HighlighterBtn.title = "Highlight Text";
        //HighlighterBtn.style.display = "none";
        HighlighterBtn.addEventListener('click', function () {
            //clearCanvas();
        });
        HighlighterBtn.innerHTML = "<i class='fas fa-highlighter'></i>";

        return HighlighterBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateHighlightAnnotTool()", ex, "error");
    }
}

function CreateCircleAnnotTool(intid) {
    try {
        var CircleBtn = document.createElement("a");
        CircleBtn.classList.add("toolboxButton");
        CircleBtn.id = "circleId" + intid;
        CircleBtn.title = "Circle";
        //CircleBtn.style.display = "none";
        CircleBtn.addEventListener('click', function () {
            annotation.selectAnnotationType(annotation.types.elipse);
            isRectangle = false;
            isElipse = true;
            isLine = false;
            isArrow = false;
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var shapeUL = document.getElementById("shapeInputer" + intid);
            SetCurrentShapeIcon(icons.shapes.elipse, intid);
            //document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = this.value;
            fadeOut(shapeUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        CircleBtn.innerHTML = "<i class='far fa-circle'></i>";

        return CircleBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateCircleAnnotTool()", ex, "error");
    }
}

function CreateAudioAnnotTool() {
    try {
        var AudioBtn = document.createElement("a");
        AudioBtn.classList.add("toolboxButton");
        AudioBtn.id = "audio";
        AudioBtn.title = "Audio";
        //AudioBtn.style.display = "none";
        AudioBtn.addEventListener('click', function () {
            //clearCanvas();
        });
        AudioBtn.innerHTML = "<i class='fas fa-file-audio'></i>";

        return AudioBtn;
    } catch (ex) {
        CobrowseLogging("annotate.CreateAudioAnnotTool()", ex, "error");
    }
}

//Creating Button to set the Shapes
function CreateShapeSelectorTool(intid) {
    try {
        var li = document.createElement('li');
        li.append(CreateAnchorShape(intid));
        annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
        annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
        var shapeUl = document.createElement("ul");
        shapeUl.id = "shapeInputer" + intid;
        shapeUl.classList.add("is-hidden");
        shapeUl.classList.add("color-list");

        shapeUl.append(CreatePencilAnnotTool(intid));
        shapeUl.append(CreateCircleAnnotTool(intid));
        shapeUl.append(CreateSquareAnnotTool(intid));
        shapeUl.append(CreateLineAnnotTool(intid));
        shapeUl.append(CreateArrowAnnotTool(intid));
        //shapeUl.append();
        //shapeUl.append();
        //shapeUl.append();
        //shapeUl.append();

        li.appendChild(shapeUl);
        setTimeout(function () {
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
        }, 1);
        return li;
    } catch (e) {
        CobrowseLogging("annotate.CreateShapeSelectorTool()", e, "error");
    }
}

//Creating Button to set the color of the brush
function CreateColorSelectorTool(intid) {
    try {
        var li = document.createElement('li');
        li.append(CreateAnchor(intid));
        annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
        annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
        var colorUl = document.createElement("ul");
        colorUl.id = "colorInputer" + intid;
        colorUl.classList.add("is-hidden");
        colorUl.classList.add("color-list");


        colorUl.append(CreateColorType("black", "black", intid));
        colorUl.append(CreateColorType("white", "white", intid));
        colorUl.append(CreateColorType("red", "red", intid));
        colorUl.append(CreateColorType("orange", "orange", intid));
        colorUl.append(CreateColorType("yellow", "yellow", intid));
        colorUl.append(CreateColorType("green", "green", intid));
        colorUl.append(CreateColorType("blue", "blue", intid));
        colorUl.append(CreateColorType("purple", "purple", intid));

        li.appendChild(colorUl);
        setTimeout(function () {
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
        }, 1);
        return li;
    } catch (e) {
        CobrowseLogging("annotate.CreateColorSelectorTool()", e, "error");
    }
}
function CreateAnchor(intid) {
    try {
        var ColorPalet = document.createElement('a');
        ColorPalet.href = "#";
        ColorPalet.classList.add("toolboxButton");
        ColorPalet.id = "ColorPaletId" + intid;
        ColorPalet.title = "Color";
        ColorPalet.style.display = "none";
        ColorPalet.innerHTML = "<i class='fas fa-palette'></i>";
        ColorPalet.addEventListener('click', function (e) {
            CloseAllOpenToolbarsUl(intid);
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var colorUl = document.getElementById("colorInputer" + intid);
            fadeIn(colorUl, "inline-block");
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });
        return ColorPalet;
    } catch (e) {
        CobrowseLogging("annotate.CreateAnchor()", e, "error");
    }
}

function CreateAnchorShape(intid) {
    var ShapePalet = document.createElement('a');
    ShapePalet.href = "#";
    ShapePalet.classList.add("toolboxButton");
    ShapePalet.id = "ShapePaletId" + intid;
    ShapePalet.title = "Shapes";
    ShapePalet.style.display = "none";
    ShapePalet.innerHTML = "<i class='fas fa-shapes'></i>";
    ShapePalet.addEventListener('click', function (e) {
        CloseAllOpenToolbarsUl(intid);
        annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
        annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
        var shapeUl = document.getElementById("shapeInputer" + intid);
        fadeIn(shapeUl, "inline-block", intid);
        setTimeout(function () {
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
        }, 1);
    });
    return ShapePalet;
}

function CreateColorType(className, color, intid) {
    try {
        var colorLi = document.createElement("li");
        var a = document.createElement('a');
        a.classList.add(className);
        a.value = color;
        a.href = "#";
        a.addEventListener('click', function (e) {
            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
            var colorUL = document.getElementById("colorInputer" + intid);
            annotation.style.brushColor = this.value;
            SetCurrentColorIcon(this.value, intid);
            fadeOut(colorUL);
            setTimeout(function () {
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
            }, 1);
        });

        colorLi.appendChild(a);

        return colorLi;
    } catch (e) {
        CobrowseLogging("annotate.CreateCololorTypes()", e, "error");
    }
}


//function CreateShapeType() {
//    try {
//        var shapeLi = document.createElement("li");
//        var a = document.createElement('a');
//        a.classList.add(className);
//        //a.value = color;
//        a.href = "#";
//        a.addEventListener('click', function (e) {
//            annotCanvasScrollPositionTop = document.scrollingElement.scrollTop;
//            annotCanvasScrollPositionLeft = document.scrollingElement.scrollLeft;
//            var shapeUL = document.getElementById("shapeInputer");
//            //document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = this.value;
//            fadeOut(shapeUL);
//            setTimeout(function () {
//                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
//                document.scrollingElement.scrollTop = annotCanvasScrollPositionTop;
//            }, 1);
//        });

//        shapeLi.appendChild(a);

//        return shapeLi;
//    } catch (ex) {
//        console.error("[CreateShapeTypes]", ex);
//    }
//}

function CreatePreviousPageTool() {
    try {
        var previousPageButton = document.createElement("a");
        previousPageButton.classList.add("toolboxButton");
        previousPageButton.id = "previousPageButton";
        previousPageButton.title = "Previous Page";
        previousPageButton.innerHTML = "<i class='fas fa-arrow-left'></i>";
        previousPageButton.addEventListener('click', function (e) {
            SaveCustomerAnnotation(currentPage);

            var command = {};
            command.type = "clickclear";     //Clearing the canvas before going to previous page
            command.page = currentPage;
            document.getElementById('annotdiv').style.background = "";
            //captureCanvas();
            captureAnnotCanvas();
            sendMessageForCb(command);
            if (currentPage !== 1) {
                --currentPage;
            }
            if (pageRenderingInProgress !== 1) {
                showPage(currentPage);

                command = {};
                command.type = "CurrentPage";
                command.page = currentPage;
                sendMessageForCb(command);
            }
        });
        return previousPageButton;
    } catch (e) {
        CobrowseLogging("annotate.CreatePreviousPageTool()", e, "error");
    }
}

function CreateNextPageTool() {
    try {
        var nextPageButton = document.createElement("a");
        nextPageButton.classList.add("toolboxButton");
        nextPageButton.id = "nextPageButton";
        nextPageButton.title = "Next Page";
        nextPageButton.innerHTML = "<i class='fas fa-arrow-right'></i>";
        nextPageButton.addEventListener('click', function (e) {
            SaveCustomerAnnotation(currentPage);

            var command = {};
            command.type = "clickclear";
            command.page = currentPage;
            document.getElementById('annotdiv').style.background = "";
            //captureCanvas();
            captureAnnotCanvas();
            sendMessageForCb(command);
            if (currentPage !== totalPages) {
                ++currentPage;
            }

            if (pageRenderingInProgress !== 1) {
                showPage(currentPage);

                command = {};
                command.type = "CurrentPage";
                command.page = currentPage;
                sendMessageForCb(command);
            }
        });
        return nextPageButton;
    } catch (e) {
        CobrowseLogging("annotate.CreateNextPageTool()", e, "error");
    }
}

function saveAnnotPageDone(data) {
    try {
        var capturedData = captureCanvasWithAnnotations();
        // // aLink.href = data;
        // // aLink.click();
        // if(isPdf){
        // parent.SaveCobrowsePdfPage(data, pageNo);
        // parent.SaveCobrowsePdf();
        // }
        // else
        parent.SaveImageToServer(capturedData);
    } catch (e) {
        //console.error(e);
        CobrowseLogging("annotate.saveAnnotPageDone()", e, "error");
    }
}

var aLink = document.createElement('a');
function CreateSaveAnnotPage(intid) {
    try {
        var aLinkButton = document.createElement('a');
        aLinkButton.id = "aLinkBtnId";
        aLinkButton.title = "Save";
        aLinkButton.classList.add("toolboxButton");
        aLinkButton.innerHTML = "<i class='far fa-save'></i>";
        aLinkButton.addEventListener('click', function () {
            document.getElementById("annotToolbox").style.display = "none";
            document.getElementById("mycursor").style.display = "none";
            if (isPdf) {
                if (annotstatus[currentPage]) {
                    //captureCanvas("saveAnnotPageDone", currentPage);
                    //captureAnnotCanvas();
                    captureCanvasWithAnnotations();
                }
            }
            else {
                //captureCanvas("saveAnnotPageDone");
                var can = document.getElementById('sendersCanvas');
                data = can.toDataURL();
                //saveAnnotPageDone(data);
                captureCanvasWithAnnotations();
            }

            document.getElementById("annotToolbox").style.display = "block";
            document.getElementById("mycursor").style.display = "block";
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent("click");
            aLink.download = 'image.png';
            aLink.href = data;
            localStorage.setItem("coBrowseImage", data);
            aLink.dispatchEvent(evt);
            //parent.downloadImage(d);
            //aLink.click();
        });
        return aLinkButton;

    } catch (e) {
        CobrowseLogging("annotate.CreateSaveAnnotPage()", e, "error");
    }
}

function CreateSizeIncreaseTool(intid) {
    try {
        var sizeIncreaseButton = document.createElement("a");
        sizeIncreaseButton.classList.add("toolboxButton");
        sizeIncreaseButton.id = "sizeIncreaseId" + intid;
        sizeIncreaseButton.title = "Increase Brush Size";
        sizeIncreaseButton.style.display = "none";
        sizeIncreaseButton.innerHTML = "<i class='fas fa-plus'></i>";
        sizeIncreaseButton.addEventListener('click', function (e) {
            annotation.increaseBrushSize(intid);
        });
        return sizeIncreaseButton;
    } catch (e) {
        CobrowseLogging("annotate.CreateSizeIncreaseTool()", e, "error");
    }
}

function CreateSizeDecreaseTool(intid) {
    try {
        var sizeDecreaseButton = document.createElement("a");
        sizeDecreaseButton.classList.add("toolboxButton");
        sizeDecreaseButton.id = "sizeDecreaseId" + intid;
        sizeDecreaseButton.title = "Decrease Brush Size";
        sizeDecreaseButton.style.display = "none";
        sizeDecreaseButton.innerHTML = "<i class='fas fa-minus'></i>";
        sizeDecreaseButton.addEventListener('click', function (e) {
            annotation.decreaseBrushSize(intid);
        });
        return sizeDecreaseButton;
    } catch (e) {
        CobrowseLogging("annotate.CreateSizeDecreaseTool()", e, "error");
    }
}

function CreateSizeNumberTool(intid) {
    try {
        var sizeNumber = document.createElement("a");
        sizeNumber.classList.add("toolboxButton");
        sizeNumber.id = "sizeNumberId" + intid;
        sizeNumber.style.display = "none";
        sizeNumber.innerHTML = "<i class='size-number'>" + brushSize + "</i>";
        return sizeNumber;
    } catch (e) {
        CobrowseLogging("annotate.CreateSizeNumberTool()", e, "error");
    }
}

//Floating div for Annotation control
function CreateAnnotToolbox(intid) {
    try {
        var toolbox = document.createElement("ul");
        toolbox.classList.add("pdf-edit-tools");
        toolbox.style.zIndex = 999999999;
        toolbox.id = "annotToolbox" + intid;
        //toolbox.attr('data-html2canvas-ignore');
        var att = document.createAttribute("data-html2canvas-ignore");
        toolbox.setAttributeNode(att);
        toolbox.style.height = "100%";
        toolbox.style.top = "0px";
        var list = document.createElement("li");
        list.appendChild(CreateColorSelectorTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateShapeSelectorTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateStartAnnotTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateStopAnnotTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateClearAnnotTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateUndoAnnotTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateRedoAnnotTool(intid));
        toolbox.append(list);

        //if (isPdf) {
        //list = document.createElement("li");
        //list.appendChild(CreateNextPageTool());
        //toolbox.append(list);

        //list = document.createElement("li");
        //list.appendChild(CreatePreviousPageTool());
        //toolbox.append(list);
        //}

        //list = document.createElement("li");
        //list.appendChild(CreateAudioAnnotTool());
        //toolbox.append(list);

        //list = document.createElement("li");
        //list.appendChild(CreateTextAnnotTool());
        //toolbox.append(list);

        //list = document.createElement("li");
        //list.appendChild(CreateHighlightAnnotTool());
        //toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateSizeIncreaseTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateSizeNumberTool(intid));
        toolbox.append(list);

        list = document.createElement("li");
        list.appendChild(CreateSizeDecreaseTool(intid));
        toolbox.append(list);

        //list = document.createElement("li");
        //list.appendChild(CreateSaveAnnotPage(intid));
        //toolbox.append(list);

        //toolboxDiv.classList.add("toolboxContainer");

        coBrowseContainer.append(toolbox);

    } catch (ex) {
        CobrowseLogging("annotate.CreateAnnotToolbox()", ex, "error");
    }
}

//-------------------------------------- Create Annot toolbox - END-------------------------------

// fade out
function fadeOut(el) {
    try {
        el.style.opacity = 1;

        (function fade() {
            if ((el.style.opacity -= .1) < 0) {
                el.style.display = 'none';
                el.classList.add('is-hidden');
            } else {
                requestAnimationFrame(fade);
            }
        })();
    } catch (e) {
        CobrowseLogging("annotate.fadeOut()", e, "error");
    }

}

// fade in

function fadeIn(e, display) {
    try {
        if (e.classList.contains('is-hidden')) {
            e.classList.remove('is-hidden');
        }
        e.style.opacity = 0;
        e.style.display = display || "block";

        (function fade() {
            var val = parseFloat(e.style.opacity);
            if (!((val += .1) > 1)) {
                e.style.opacity = val;
                requestAnimationFrame(fade);
            }
        })();
    } catch (e) {
        CobrowseLogging("annotate.fadeIn()", e, "error");
    }

}

function UpdateData() {
    try {
        //opener.ConvertHtml(coBrowseContainer);
        //ConvertHtml(coBrowseContainer);
    } catch (e) {
        CobrowseLogging("annotate.UpdateData()", e, "error");
    }
}


// function drawCoordinates(x,y){	
// var ctx = document.getElementById("canvas").getContext("2d");


// ctx.fillStyle = "#ff2626"; // Red color
// ctx.strokeStyle = "#ff2626";
// ctx.beginPath();

// ctx.strokeStyle = "#ff2626";
// ctx.lineTo(x,y);
// ctx.stroke();

// ctx.arc(x, y, 1, 0, Math.PI * 2, true);
// ctx.arc(x, y, 1, 0, 2 * Math.PI);
// ctx.fill();

// document.getElementById("sendersCanvas" + intid).getContext('2d').beginPath();
// for (i = 0; i < obj.positions.length; i++) {
// document.getElementById("sendersCanvas" + intid).getContext('2d').lineTo(obj.positions[i].X, obj.positions[i].Y);
// document.getElementById("sendersCanvas" + intid).getContext('2d').strokeStyle = obj.style.brushColor;
// document.getElementById("sendersCanvas" + intid).getContext('2d').lineWidth = obj.style.brushSize;
// document.getElementById("sendersCanvas" + intid).getContext('2d').stroke();
// }
// document.getElementById("sendersCanvas" + intid).getContext('2d').closePath();

// }

function CloseAllOpenToolbarsUl(intid) {
    try {
        [].forEach.call(document.getElementById("annotToolbox" + intid).querySelectorAll("ul"), function (el) {
            el.style.display = 'none';
        });
    } catch (e) {
        CobrowseLogging("annotate.CloseAllOpenToolbarsUl()", e, "error");
    }
}

var ttfcbUserJsVersion = "ttfcbUser.js - v1.0.4.8";
CobrowseLogging("Initial JS File Load", ttfcbUserJsVersion, "info");
//Container used to mantain the object to be co-browsed upon
var coBrowseContainer;
//var lastTimeMouseMoved = "";
//Object used to mantain the last X and Y coordinates of the Mouse Pointer for each interaction
var mousePointer = {};

//Width and height of the co-browse Container of the Participant
var lastDomElementWidth = "";
var lastDomElementHeight = "";

//Used to mantain the scroll width and height of the page
var scrollXCoordinate = 0;
var scrollYCoordinate = 0;

//variable to store the co-browse controls to be monitored from Customer
var customerCobrowseControls = {};

//var canvasInitDetails = {
//    scaleX: 0,
//    scaleY: 0,
//    orginalWidth: 0,
//    originalHeight: 0
//};

/**
 * Called when agent initiates co-browse
 * @param cobrowseArea Area upon which annotation is to be performed
 * @param intid Interaction Id of the chat
 * @param isMousePointerCapture Should Agent Mouse Pointer be captured
 */
function OnAgentInitiate(cobrowseArea, intid, isMousePointerCapture, isAnnotationEnabled) {
    try {
        //Set isCustomer to false to indicate Agent has initiated co-browse
        isCustomer = false;
        //Call Start Up to intialize components
        InitializeCobrowse(cobrowseArea, intid, isMousePointerCapture, isAnnotationEnabled);
        //Send the Agent Container size to Customer intially
        SendCobrowseContainerSize();
        //Add a resize event listener specific to agent
        cobrowseArea.addEventListener('resize', function () {
            OnAgentCobrowseAreaResize();
        });
    }
    catch (e) {
        CobrowseLogging("ttfcbUser.OnAgentInitiate()", e, "error");
    }
}

/**
 * Called when Customer initiates co-browse
 * @param cobrowseArea Area upon which annotation is to be performed
 * @param isMousePointerCapture Should Agent Mouse Pointer be captured
 */
function OnCustomerInitiate(cobrowseArea, isMousePointerCapture, isAnnotationEnabled, cobrowseControls) {
    try {
        //Set isCustomer to true to indicate Customer has initiated co-browse
        isCustomer = true;
        //Set the controls to be monitored
        customerCobrowseControls = cobrowseControls;
        //Call Start Up to intialize components (intid is blank as it is one customer)
        InitializeCobrowse(cobrowseArea, "", isMousePointerCapture, isAnnotationEnabled);
        //canvasInitDetails.orginalWidth = coBrowseContainer.scrollWidth;
        //canvasInitDetails.originalHeight = coBrowseContainer.scrollHeight;
        //canvasInitDetails.scaleX = cbScaleX;
        //canvasInitDetails.scaleY = cbScaleY;
        //if (cobrowseArea === document.body) {

        //Add Event Listener for Customer scroll event
        document.addEventListener("scroll", function (e) {
            scrollXCoordinate = window.pageXOffset;
            scrollYCoordinate = window.pageYOffset;
            drawMouse("");
        }, true);

        //Add event for Customer window resize
        window.addEventListener('resize', function () {
            OnCustomerCobrowseAreaResize();
        });
        //}
        //}
    } catch (e) {
        CobrowseLogging("ttfcbUser.OnCustomerInitiate()", e, "error");
    }
}

/**
 * Called when Agent window is resized
 */
function OnAgentCobrowseAreaResize() {
    try {
        //window.resizeTo(screen.width, screen.height);
        //alert("Resize of cobrowse window is not allowed");
        cbScaleX = (window.innerWidth / parseInt(lastDomElementWidth));
        cbScaleY = window.innerHeight / parseInt(lastDomElementHeight);

        var cbdiv = document.body.getElementsByTagName("video")[0];
        var rect = cbdiv.getBoundingClientRect();

        document.body.style.width = window.innerWidth + "px";
        document.body.style.height = window.innerHeight + "px";

        for (i = 1; i < global_InteractionTabs.length - 1; i++) {
            if (global_InteractionTabs[i].type !== "main") {

                document.getElementById("sendersCanvas" + global_InteractionTabs[i].intid).clearRect(0, 0, document.getElementById("sendersCanvas" + global_InteractionTabs[i].intid).width, document.getElementById("sendersCanvas" + global_InteractionTabs[i].intid).height);
                drawMouse(global_InteractionTabs[i].intid);

                document.getElementById("sendersCanvas" + global_InteractionTabs[i].intid).width = rect.width;
                document.getElementById("sendersCanvas" + global_InteractionTabs[i].intid).height = rect.height;

                document.getElementById("datacanvas" + global_InteractionTabs[i].intid).width = rect.width;
                document.getElementById("datacanvas" + global_InteractionTabs[i].intid).height = rect.height;

                annotation.redrawAnnotations(global_InteractionTabs[i].intid);
                annotation.redrawReceiverAnnotations("", global_InteractionTabs[i].intid);
            }
        }
        SendCobrowseContainerSize();
    } catch (e) {
        CobrowseLogging("ttfcbUser.OnAgentCobrowseAreaResize()", e, "error");
    }
}

/**
 * Called when Customer window is resized
 */
function OnCustomerCobrowseAreaResize() {
    try {
        //window.resizeTo(screen.width, screen.height);
        //alert("Resize of cobrowse window is not allowed");
        //var rect = coBrowseContainer.getBoundingClientRect();
        //var senderCanvasData = document.getElementById("sendersCanvas").toDataURL();
        //var receiverCanvasData = document.getElementById("receiversCanvas").toDataURL();
        //var dataCanvasData = document.getElementById("datacanvas").toDataURL();
        cbScaleX = (window.innerWidth / parseInt(lastDomElementWidth));
        cbScaleY = window.innerHeight / parseInt(lastDomElementHeight);

        //var sendersCanvasImage = new Image();
        //document.getElementById("sendersCanvas").width = rect.width;
        //document.getElementById("sendersCanvas").height = rect.height;
        //sendersCanvasImage.onload = function () {
        //    document.getElementById("sendersCanvas").getContext("2d").drawImage(sendersCanvasImage, 0, 0);
        //};
        //sendersCanvasImage.src = senderCanvasData;


        //var receiversCanvasImage = new Image();
        //document.getElementById("receiversCanvas").width = rect.width;
        //document.getElementById("receiversCanvas").height = rect.height;
        //receiversCanvasImage.onload = function () {
        //    document.getElementById("receiversCanvas").getContext("2d").drawImage(receiversCanvasImage, 0, 0);
        //};
        //receiversCanvasImage.src = receiverCanvasData;

        //var dataCanvasImage = new Image();
        //document.getElementById("datacanvas").width = rect.width;
        //document.getElementById("datacanvas").height = rect.height;
        //dataCanvasImage.onload = function () {
        //    document.getElementById("datacanvas").getContext("2d").drawImage(dataCanvasImage, 0, 0);
        //};
        //dataCanvasImage.src = dataCanvasData;
        //var sendersCanvasContext = document.getElementById("sendersCanvas").getContext('2d');
        //var receiversCanvasContext = document.getElementById("receiversCanvas").getContext('2d');
        //var dataCanvasContext = document.getElementById("datacanvas").getContext('2d');
        //sendersCanvasContext.clearRect(0, 0, document.getElementById("sendersCanvas").width, document.getElementById("sendersCanvas").height);
        //receiversCanvasContext.clearRect(0, 0, document.getElementById("receiversCanvas").width, document.getElementById("receiversCanvas").height);
        //dataCanvasContext.clearRect(0, 0, document.getElementById("datacanvas").width, document.getElementById("datacanvas").height);

        setTimeout(function () {
            document.getElementById("sendersCanvas").width = coBrowseContainer.offsetWidth;
            document.getElementById("sendersCanvas").height = window.innerHeight;

            document.getElementById("receiversCanvas").width = coBrowseContainer.offsetWidth;
            document.getElementById("receiversCanvas").height = window.innerHeight;

            document.getElementById("datacanvas").width = coBrowseContainer.offsetWidth;
            document.getElementById("datacanvas").height = window.innerHeight;
        }, 500);

        //if (canvasInitDetails.orginalWidth === coBrowseContainer.scrollWidth && canvasInitDetails.originalHeight === coBrowseContainer.scrollHeight) {
        //    document.getElementById("sendersCanvas").getContext('2d').restore();
        //    document.getElementById("receiversCanvas").getContext('2d').restore();
        //    document.getElementById("datacanvas").getContext('2d').restore();
        //}
        //else {
        //    document.getElementById("sendersCanvas").getContext('2d').scale(cbScaleX, cbScaleY);
        //    document.getElementById("receiversCanvas").getContext('2d').scale(cbScaleX, cbScaleY);
        //    document.getElementById("datacanvas").getContext('2d').scale(cbScaleX, cbScaleY);

        //}

        annotation.redrawAnnotations("");
        annotation.redrawReceiverAnnotations("", "");

        SendCobrowseContainerSize();
        captureControls();
    } catch (e) {
        CobrowseLogging("ttfcbUser.OnCustomerCobrowseAreaResize()", e, "error");
    }
}

/**
 * Method called when Co-browse is stopped
 * @param intid Interaction ID of the chat
 */
function EndCobrowse(intid) {
    try {
        //Remove UI created elements if they exist like canvas, mouse, toolbox etc., this is used when there are variables created for multiple chat sessions on agent side
        DestroyCobrowseElements(intid);
        //Remove(unset) variables used in co-browse, this is used when there are variables created for multiple chat sessions on agent side
        DestroyCobrowseVariables(intid);

        //if (!isCustomer) {
        //    coBrowseContainer.removeEventListener('resize', function () {
        //        OnAgentCobrowseAreaResize();
        //    });
        //}
    } catch (e) {
        CobrowseLogging("ttfcbUser.EndCobrowse()", e, "error");
    }

}

/**
 * 
 * @param cobrowseArea Area upon which annotation is to be performed
 * @param intid Interaction Id of the Chat Interaction
 * @param isMousePointerCapture Is Mouse Pointer to be Captured
 * @param isAnnotationEnabled Allow user to annotate
 */
function InitializeCobrowse(cobrowseArea, intid, isMousePointerCapture, isAnnotationEnabled) {
    try {
        //Check the intid and set it to blank, incase it doesnt exist
        if (intid === undefined || intid === null || intid === "") {
            intid = "";
        }

        //Destroy UI created elements (before we create them later below) if they exist like canvas, mouse, toolbox etc., this is used when there are variables created for multiple chat sessions on agent side
        DestroyCobrowseElements(intid);
        //Create(set) variables used in co-browse, this is used when there are variables created for multiple chat sessions on agent side
        InitializeCobrowseVariables(intid, isMousePointerCapture);

        //Set Page scrolled Coordinates in case the page is loaded (i.e. it is already scrolled horizontally/vertically on load), used mainly in Customer Side
        scrollXCoordinate = window.pageXOffset;
        scrollYCoordinate = window.pageYOffset;

        //Store the Area to be cobrowsed in a global variable so it can be used
        coBrowseContainer = cobrowseArea;

        //Create UI created elements like canvas, mouse, toolbox etc.
        InitializeCobrowseElements(coBrowseContainer, intid, isAnnotationEnabled);

        //if (isCustomer)
        //    setAnnotCanvasAndDiv(coBrowseContainer.scrollWidth, coBrowseContainer.scrollHeight, "image", intid);
        //else
        setAnnotCanvasAndDiv(coBrowseContainer.offsetWidth, window.innerHeight, "image", intid);

        if (isMousePointerCapture)
            coBrowseContainer.addEventListener('mousemove', function (e) {
                //var $that = e;
                //lastTimeMouseMoved = new Date().getTime();
                showCoords(e, intid);
                //mousetimer = setTimeout(function () {
                //    var currentTime = new Date().getTime();
                //    if (currentTime - lastTimeMouseMoved > 1000) {
                //        showCoords($that);
                //    }
                //}, 1000);
            }, true);
    } catch (e) {
        CobrowseLogging("ttfcbUser.InitializeCobrowse()", e, "error");
    }

}

// create agent's mouse pointer
function createMousePointer(intid) {
    try {
        if (!document.getElementById("mycursor" + intid)) {
            var c = document.createElement("IMG");
            c.setAttribute("src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAA9oSURBVHhe7Z17yGZVFYdnHHVKJSdjBJnpgpUWVjZIYFGCSBRdJoykaDAwKIuppCK7X6SY/iiUCaTAKOxChWFT2YWkK5HVNJaUEaHRhZiiGrqqeaHWqu/Y9PnN977nnL33Wnut54X9x8ycc/Zez/mtZ857PRs29PHYLMvcKeOjMg7K+JeMO2T8SMYeGTv6KINVQgACYwnskh1+stL02vhrjXvk7z8sY+vYg7M9BCDgk8AmWdaVCxp/tQz2y/bbfZbDqiAAgTEE9o5s/kEGP0QCYzCzLQT8EXjmxOZHAv7OJSuCwCgCG2Xrr88UgIqAK4FR2NkYAj4InCbLuL2AAJCAj/PJKiAwisAFhZqfpwOjsLMxBHwQ2F1YAFwJ+DivrAICSxG4pIIAkMBS6NkIAvYEXlVJAEjA/tyyAggsJFBTAEhgIX42gIAtgdoCQAK255fZIbAugRYCQAKEEAJOCbQSABJwGgCWlZtASwEggdxZo3qHBFoLAAk4DAFLykvAQgBIIG/eqNwZASsBIAFnQWA5OQlYCgAJ5MwcVTsiYC0AJOAoDCwlHwEPAkAC+XJHxU4IeBEAEnASCJaRi4AnASCBXNmjWgcEvAkACTgIBUvIQ8CjAJBAnvxRqTEBrwJAAsbBYPocBDwLAAnkyCBVGhLwLgAkYBgOpo5PoAcBIIH4OaRCIwK9CAAJGAWEaWMT6EkASCB2FqnOgEBvAkACBiFhyrgEehQAEoibRyprTKBXASCBxkFhupgEehYAEoiZSapqSKB3ASCBhmFhqngEIggACcTLJRU1IhBFAEigUWCYJhaBSAJAArGySTUNCEQTgErgRhnbG7BjCgh0TyCiAJBA97GkgFYEogoACbRKEPN0TSCyAJBA19Fk8S0IRBcAEmiRIubolkAGASCBbuPJwmsTyCIAJFA7SRy/SwKZBIAEuowoi65JIJsAkEDNNHHs7ghkFAAS6C6mLLgWgawCQAK1EsVxuyKQWQBIoKuostgaBLILAAnUSBXH7IYAAtiwAQl0E1cWWpoAAvivAJBA6WRxvC4IIID/CQAJdBFZFlmSAAL4fwEggZLp4ljuCSCA+woACbiPLQssRQABrC0AJFAqYRzHNQEEcGQBIAHX0WVxJQgggPUFgARKpIxjuCWAABYLAAm4jS8Lm0sAASwnACQwN2ns75IAAlheAEjAZYRZ1BwCCGCcAJDAnLSxrzsCCGC8AJCAuxizoKkEEMA0ASCBqYljP1cEEMB0ASABV1FmMVMIIIB5AkACU1LHPm4IIID5AkACbuLMQsYSQABlBIAExiaP7V0QQADlBIAEXESaRYwhgADKCgAJjEkf25oTQADlBYAEzGPNApYlgADqCAAJLJtAtjMlgADqCQAJmEabyZchgADqCgAJLJNCtjEjgADqCwAJmMWbiRcRQABtBIAEFiWRfzchgADaCQAJmEScSdcjgADaCgAJ0I+uCCCA9gJAAq5aIPdiEICNAJBA7r5zUz0CsBMAEnDTBnkXggBsBYAE8vaei8oRgL0AkICLVsi5CATgQwBIIGf/mVeNAPwIAAmYt0O+BSAAXwJAAvl60LRiBOBPAEjAtCVyTY4AfAoACeTqQ7NqEYBfASABs7bIMzEC8C0AJJCnF00qRQD+BYAETFojx6QIoA8BIIEc/di8SgTQjwCQQPP2iD8hAuhLAEggfk82rRAB9CcAJNC0RWJPhgD6FAASiN2XzapDAP0KAAk0a5O4EyGAvgWABOL2ZpPKEED/AkACTVol5iQIIIYAkEDM/qxeFQKIIwAkUL1d4k2AAGIJAAnE69GqFSGAeAJAAlVbJtbBEUBMASCBWH1arRoEEFcASKBa28Q5MAKILQAkEKdXq1SCAOILAAlUaZ0YB0UAOQSABGL0a/EqEEAeASCB4u3T/wERQC4BDBLY1n90qaAEAQSQTwAqgQMykECJDur8GAggpwCQQOeNW2r5CCCvAJBAqS7q+DgIILcAkEDHzVti6QgAASCBEp3U6TEQAAJQASCBTht47rIRAAIYBIAE5nZTh/sjAARwuACQQIdNPGfJCAABrBYAEpjTUZ3tiwAQwFoCQAKdNfLU5SIABHAkASCBqV3V0X4IAAGsJwAk0FEzT1kqAkAAiwSABKZ0Vif7IAAEsIwAkEAnDT12mQgAASwrACQwtrs62B4BIIAxAkACHTT1mCUiAAQwVgBIYEyHOd8WASCAKQJAAs4be9nlIQAEMFUASGDZLnO8HQJAAHMEgAQcN/cyS0MACGCuAJDAMp3mdBsEgABKCAAJOG3wRctCAAiglACQwKJuc/jvCAABlBQAEnDY5OstCQEggNICQAIdSQABIIAaAkACnUgAASCAWgJAAh1IAAEggJoCQALOJYAAEEBtASABxxJAAAighQCQgFMJIAAE0EoASMChBBAAAmgpACTgTAIIAAG0FgAScCQBBIAALASABJxIAAEgACsBIAEHEkAACMBSAEjAWAIIAAFYC0Dn3y/jZONeSDk9AkAAHgSga/isjKNSdqFh0QgAAXgRgK7jQsNeSDk1AkAAngTwXenCTSk70ahoBIAAPAngn9IHjzbqhZTTIgAE4EkAupZnpexEo6IRAALwJoCdRr2QcloEgAA8CeAu6cIdKTvRqGgEgAA8CeAW6YPjjHoh5bQIAAF4EsAVKbvQsGgEgAC8COB26YMzDHsh5dQIAAF4EcDlKTvQuGgEgAA8CEA/AHSicS+knB4BIABrAXxbOu/BKbvPQdEIAAFYCeBXkv+3yTjeQR+kXQIC8CeAGySNe2ToK+LRxnukpjfJ0A/7nJS26xwVjgD8CeB6R/lgKcEJIAB/ArhHMndu8NxRnhMCCMCfAPQ5+ced5INlBCeAAHwK4G+Su1ODZ4/yHBBAAD4FoFcBlznIB0sITgAB+BXArZK9E4Lnj/KMCSAAvwLQq4Bdxvlg+uAEEIBvAXwteP4oz5gAAvAtgLslH2cbZ4TpAxNAAL4FoE8DrgqcP0ozJoAA/AvgkGRkm3FOmD4oAQTgXwB6FXBp0PxRljEBBNCHAG6WnGw2zgrTBySAAPoQgF4FnB8wf5RkTAAB9COA64yzwvQBCSCAfgSgt806M2AGKcmQAALoRwD6NGCvYVaYOiABBNCXAA5KBrcGzCElGRFAAH0JQK8CdhtlhWkDEkAA/QnggOTw6IBZpCQDAtkEoD+3ZfUruCXnfZpBVpgyIIFMAtDv1z9Hhv4cdclmtDjWNQGzSEkGBLIIQJv+cSt8rwwggNukhtMN8sKUwQhkEIA2/+Hvn58lf74zgAT03gE8IDCLQHQBrG7+AdaXAwhAa+N+erPiz86RBXCk5tezfkEAAehrDxcRYQjMIRBVAOs1v/K6n4yfBZCA3lhz45wAsG9uAhEFsKj5hzP+xgAC0Lc1z8kdYaqfQyCaAJZtfmX2EBl/DiCBq+cEgH1zE4gkgDHNP5z1DwUQgErsobljTPVTCUQRwJTmV2ZPlhHh04FvmRoA9stNIIIApja/nnl9Ae1bAa4Cfi413D93lKl+CoHeBTCn+QdeLwogAH1L8PlTAsA+uQn0LIASza9n/wEyfhlAAl/JHWWqn0KgVwGUav6B2bsCCOAuqeEJU0LAPnkJ9CiA0s2vZ/+RMv4eQALvzxtlKp9CoDcB1Gj+gdsnAwjgD1LDKVOCwD45CfQkgJrNr2f/qQEEoC8GvjpnlKl6CoFeBFC7+ZXdJhn7A0jgJqnhmClhYJ98BHoQQIvmH878ywIIQK8Cnp0vylQ8hYB3AbRsfuX3IBm/DSCBfVPCwD75CHgWQOvmH87+5QEEcIfUcEa+OFPxWAJeBWDV/MrvsTL0NlwWP/ZZcs73jg0D2+cj4FEAls0/JOBzAQSgT2VOyhdpKh5DwJsAPDS/8tsZQAB6NXHxmDCwbT4CngTgpfk1BcfK+HEACXxPatC3N3lAYE0CXgTgqfkHUK8NIAC9CjiP7EPgSAQ8CMBj8ysv/UjtHwNI4BPEHwJeBeC1+Qde+uWakq/MWxxLv+T0CFoAAmsRsLwC8N78yku/Xqtfs7Vo3JJzXkb8IeBJAD00/8Dr+gAC+IXUcAItAIHVBCyuAHpqfuX1ggAC0KuJC4k/BKwF0FvzK6/jZOiPbpa8JLc41jeIPwQsBdBj8w+89Ge3LZq25Jx3Sw1PogUgcDiBVk8Bem5+5fUwGX8JIIEPEn8ItBZA780/8Lo6gAAOSQ3baQEIDARqXwFEaX7ldY6MCHcRej3xh0ALAURqfuWldxHS23GXfF5ucayfSg16e3QeENhwSaVAR2v+ISovrsSrtQieS/YhoAReWSHQUZtfeW2RofW1btjS832R+ENACewqHObIzT8kZk9hZqWbe5nj3Sk17KAFIHCmICj1WfcMza+JOV3GbQEk8D7iD4GjBcEPCoQ5S/MPibmmALNl/qeuuc3vpIaTaQEI6GfE5wQtW/NrYp4+k9kc3iX3fQXxh8BRgmDq/2gZm18To1dOBwJI4MaVWuiC5AROlPr3jQz0LbK9voaQ9bF7JK+S/3OXPJZezfCAwH9+PPLNMvQOs4sCpm8jPTw5s61S/8ElWC1iaf3vn05+Hil/FQFt7HfI+L4M/QKM3mXmHyth16cKz4PYvQT2BhCAvqPxKM4pBFYT0Oe522Q8fiUgW0B0HwL6FCjCXYTewLmFAASmEbguwFXAtdNKZy8IQOD8AALQp3t6xccDAhAYSWCzbH9z5xLQtzSPGVk3m0MAAisELu1cAF/gTEIAAtMJ6Iulf+pYAu+cXjp7QgACSuCqTgWgPxZ6FqcQAhCYR+Bs2b3UNytbfjiIDwLNO+/sDYF7CXy1s6sAvfnpaZw/CECgDIEXdiSAv8pan1GmbI4CAQgogeNl6JekWl7CT5nrJlnjUzhlEIBAeQJvdywA/bzC62Totz95QAACFQicKsfUy+sp/zPX2EdfmPySDL3Jqd7nkAcEIFCZwMccCOD3soYPyHhi5Vo5PAQgsIrAufJnq7sI6cd6XyODW4ARSwgYEdCfWftOw6sA/UryPhn6xaRjjWpmWghA4DACL2kggN/IHFfI4JN8RA8CzghskfX8upIEbpDjvlwGP+vt7KSzHAgcTkB/drvUK/v6012fkqEf3tHfb+QBAQg4J6CN+pmZErhV9n+3jMc4r5XlQQACaxDQpwKfnyCBb8o+F8l4IFQhAIG+Ceiv7bxVxqKfXNdfYf6IjPNkbOy7ZFYPAQisJnCK/MXFMvSTeYdWrgr0G3l6hfBSGbx3Hzgz/waAABM531PGeAAAAABJRU5ErkJggg==");
            if (isCustomer) {
                var att = document.createAttribute("data-html2canvas-ignore");
                c.setAttributeNode(att);
            }
            c.id = "mycursor" + intid;
            c.style.zIndex = 1000;
            c.style.position = "absolute";
            c.style.top = 0;
            c.style.left = 0;
            c.style.height = "10px";
            c.style.width = "10px";
            //c.classList.add("pulsating-circle");
            coBrowseContainer.appendChild(c);
        }
    } catch (e) {
        CobrowseLogging("ttfcbUser.createMousePointer()", e, "error");
    }

}


//called from peer when a control value is changed
function controlChanged(id, value) {
    try {
        document.getElementById(id).value = value;
    } catch (e) {
        CobrowseLogging("ttfcbUser.controlChanged()", e, "error");
    }

}

function checkClick(id) {
    try {
        document.getElementById(id).click();
    } catch (e) {
        CobrowseLogging("ttfcbUser.checkClick()", e, "error");
    }
}


//called from peer when the cursor position changed
function drawMouse(intid) {
    try {
        if (mousePointer[intid].isReceiverMouseCaptureEnabled) {
            createMousePointer(intid);
            //var posx = (x / 100) * parseInt(document.body.offsetWidth);
            //var posy = (y / 100) * parseInt(document.body.offsetHeight);
            //var posx = ((x * window.innerWidth) / 100) + scrollXCoordinate;
            //(posx < 0) ? posx = 0 : "";
            //var posy = ((y * window.innerHeight) / 100) + scrollYCoordinate;

            //var posx = ((x * (window.scrollWidth / parseInt(lastDomElementWidth)))) + scrollXCoordinate;
            //(posx < 0) ? posx = 0 : "";
            //var posy = ((y * (window.scrollHeight / parseInt(lastDomElementHeight)))) + scrollYCoordinate;
            var posx = (mousePointer[intid].lastXPosition * (window.innerWidth / lastDomElementWidth)) + scrollXCoordinate;
            (posx < 0) ? posx = 0 : "";
            var posy = ((mousePointer[intid].lastYPosition * window.innerHeight) / lastDomElementHeight) + scrollYCoordinate;

            document.getElementById('mycursor' + intid).style.left = posx.toString() + "px";
            document.getElementById('mycursor' + intid).style.top = posy.toString() + "px";
        }
    } catch (e) {
        CobrowseLogging("ttfcbUser.drawMouse()", e, "error");
    }
}

function drawParaSelect(type, top, left, height, width) {
    try {
        var elementx = document.createElement("span");
        var child = document.getElementById("ttfcb_span");
        if (child !== null) {
            document.body.removeChild(child);
            //return;
        }
        elementx.id = "ttfcb_span";
        if (type === "agentParaClick") {
            elementx.style.position = "absolute";
            elementx.style.top = top;
            elementx.style.left = left;
            elementx.style.height = height;
            elementx.style.width = width;
        }
        else {
            var sel = window.getSelection();
            var s = sel.getRangeAt(0);
            var r = s.getBoundingClientRect();
            elementx.style.position = "absolute";
            elementx.style.top = r.y + "px";
            elementx.style.left = r.x + "px";
            elementx.style.height = r.height + "px";
            elementx.style.width = r.width + "px";
        }

        elementx.style.border = "1px solid black";
        elementx.style.backgroundColor = "blue";
        elementx.style.zIndex = "-1";
        document.body.appendChild(elementx);
    } catch (e) {
        CobrowseLogging("ttfcbUser.drawParaSelect()", e, "error");
    }
}

//get coordinates of mouse pointer
var mousemoves = {};
var mousemovecnt = 0;
function sendMouseCoords() {
    try {
        var command = {};
        command.type = "drawMouse";
        command.data = {};
        command.data.x = mousemoves.x;
        command.data.y = mousemoves.y;

        sendMessageForCb(command);
    } catch (e) {
        CobrowseLogging("ttfcbUser.sendMouseCoords()", e, "error");
    }

}

function showCoords(event, intid) {
    try {
        //var rect = coBrowseContainer.getBoundingClientRect();

        mousemoves.x = (event.pageX - coBrowseContainer.getBoundingClientRect().left);
        mousemoves.y = (event.pageY - coBrowseContainer.getBoundingClientRect().top);

        //mousemoves.x = (((event.pageX - coBrowseContainer.offsetLeft) / coBrowseContainer.clientWidth) * 100);
        //mousemoves.y = (((event.pageY - coBrowseContainer.offsetTop) / coBrowseContainer.clientHeight) * 100);

        sendMouseCoords();
    } catch (e) {
        CobrowseLogging("ttfcbUser.showCoords()", e, "error");
    }
}


function sendMessageForCb(message) {
    try {
        message.isCbMsg = true;
        //message.isRealTime = true;
        var mymsg = JSON.stringify(message);

        try {
            livechat.SendAppMessage(mymsg);
        }
        catch (e) {
            try {
                tmac_SendAppMessage(null, null, global_DeviceID, global_activeTabInteractionID, mymsg);
            }
            catch (e) {
                CobrowseLogging("ttfcbUser.sendMessageForCb()", e, "error");
            }
        }
    } catch (e) {
        CobrowseLogging("ttfcbUser.sendMessageForCb()", e, "error");
    }
}

function cb_ReceiveCommand(data, intid) {
    try {
        if (intid === undefined || intid === null || intid === "") {
            intid = "";
        }
        onMessage(data, intid);
    } catch (e) {
        CobrowseLogging("ttfcbUser.cb_ReceiveCommand()", e, "error");
    }

}

//message received from peer 
function onMessage(message, intid) {
    try {
        //parse the message
        var msg = message;//JSON.parse(message.data);


        if (msg.type === "containersize") {
            //find scale
            var rect = {};

            if (isCustomer) {
                rect.width = window.innerWidth;
                rect.height = window.innerHeight;
            }
            else {
                rect.width = coBrowseContainer.style.width;
                rect.height = coBrowseContainer.style.height;
            }

            cbScreenDiffX = msg.totalw - rect.width;
            cbScreenDiffY = msg.totalh - rect.height;

            lastDomElementWidth = msg.totalw;
            lastDomElementHeight = msg.totalh;

            cbScaleX = (window.innerWidth / parseInt(msg.totalw));
            cbScaleY = window.innerHeight / parseInt(msg.totalh);

            //document.body.style.width = window.innerWidth + "px";
            //document.body.style.height = window.innerHeight + "px";

            //document.getElementById("sendersCanvas" + intid).style.width = rect.width + "px";
            //document.getElementById("sendersCanvas" + intid).style.height = rect.height + "px";

            if (isCustomer) {
                drawMouse(mousePointer[intid].lastXPosition, mousePointer[intid].lastYPosition, intid);
                SendCobrowseContainerSize();
            }
            //captureControls();
        }
        else if (msg.type === "drawImage") {
            drawImage(0, 0, msg.data.d, msg.data.parts, msg.data.inputControls, msg.data.splitImage);
        }
        // else if (msg.type == "receiverready") {
        // //captureCanvas();
        // captureAnnotCanvas();
        // }
        else if (msg.type === "drawMouse") {
            //if (msg.data.targetId !== undefined)
            //{
            //    OverlayElement(msg.data.targetId);
            //}
            mousePointer[intid].isReceiverMouseCaptureEnabled = true;
            if (isCustomer) {
                mousePointer[intid].lastXPosition = msg.data.x;
                mousePointer[intid].lastYPosition = msg.data.y;
            }
            else {
                mousePointer[intid].lastXPosition = msg.data.x;
                mousePointer[intid].lastYPosition = msg.data.y;
            }

            drawMouse(intid);
        }
        else if (msg.type === "controlChanged") {
            controlChanged(msg.data.id, msg.data.value);
        }
        else if (msg.type === "checkClick") {
            checkClick(msg.data.id);
        }
        else if (msg.type === "inputdata") {
            var input = document.getElementById(msg.id);
            input.value = msg.value;
        }
        else if (msg.type === "annot") {
            annotReceived(msg.data);
        }
        else if (msg.type === "buttonclick") {

            document.getElementById(msg.id).click();
        }
        else if (msg.type === "linkClick") {

            document.getElementById(msg.id).click();
        }
        else if (msg.type === "agentParaClick") {

            drawParaSelect(msg.type, msg.top, msg.left, msg.height, msg.width);
        }
        else if (msg.type === "startDrawing" || msg.type === "startAnnotation") {
            if (msg.data.selectedDrawType === "freeDraw") {
                freeDraw.startParticipantDrawing(msg.data.style, msg.data.positions);
            }
            else if (msg.data.selectedDrawType === "rectangle") {
                rectangle.startParticipantDrawing(msg.data.style, msg.data.positions);
            }
            else if (msg.data.selectedDrawType === "elipse") {
                elipse.startParticipantDrawing(msg.data.style);
            }
            else if (msg.data.selectedDrawType === "arrow") {
                arrow.startParticipantAnnotation(msg.data.style, msg.data.positions);
            }
            else if (msg.data.selectedDrawType === "line") {
                line.startParticipantAnnotation(msg.data.style, msg.data.positions);
            }
        }
        else if (msg.type === "finishDrawing" || msg.type === "finishAnnotation") {
            if (msg.data.selectedDrawType === "freeDraw") {
                freeDraw.finishParticipantDrawing(intid);
            }
            else if (msg.data.selectedDrawType === "rectangle") {
                rectangle.finishParticipantDrawing(intid);
            }
            else if (msg.data.selectedDrawType === "elipse") {
                elipse.finishParticipantDrawing(intid);
            }
            else if (msg.data.selectedDrawType === "arrow") {
                arrow.finishParticipantAnnotation(intid);
            }
            else if (msg.data.selectedDrawType === "line") {
                line.finishParticipantAnnotation(intid);
            }
        }
        else if (msg.type === "updatePositions" || msg.type === "updateAnnotation") {
            if (msg.data.selectedDrawType === "freeDraw") {
                freeDraw.updateParticipantPositions(msg.data.positions, intid);
            }
            else if (msg.data.selectedDrawType === "rectangle") {
                rectangle.updateParticipantPositions(msg.data.positions, intid);
            }
            else if (msg.data.selectedDrawType === "elipse") {
                elipse.updateParticipantPositions(msg.data.positions, intid);
            }
            else if (msg.data.selectedDrawType === "arrow") {
                arrow.updateParticipantAnnotation(msg.data.positions, intid);
            }
            else if (msg.data.selectedDrawType === "line") {
                line.updateParticipantAnnotation(msg.data.positions, intid);
            }
        }
        else if (msg.type === "clearReceiverCanvas") {
            var receiversCanvasContext = document.getElementById("receiversCanvas" + intid).getContext('2d');
            receiversCanvasContext.clearRect(0, 0, document.getElementById("receiversCanvas" + intid).width, document.getElementById("receiversCanvas" + intid).height);
            TempParticipantAnnotations[intid] = [];
        }
        else if (msg.type === "undoReceiver") {
            annotation.undoReceiver(msg.data, intid);
        }
        else if (msg.type === "redoReceiver") {
            annotation.redoReceiver(msg.data, intid);
        }
        else if (msg.type === "deleteAllControls-textbox") {
            for (i = 0; i < msg.data.length; i++) {
                if (document.getElementById(msg.data[i])) {
                    document.getElementById(msg.data[i]).remove();
                }
            }
        }
        else if (msg.type === "deleteAllControls-checkbox") {
            for (i = 0; i < msg.data.length; i++) {
                if (document.getElementById(msg.data[i])) {
                    document.getElementById(msg.data[i]).remove();
                }
            }
        }
        else if (msg.type === "deleteAllControls-radiobutton") {
            for (i = 0; i < msg.data.length; i++) {
                if (document.getElementById(msg.data[i])) {
                    document.getElementById(msg.data[i]).remove();
                }
            }
        }
        else if (msg.type === "deleteAllControls-dropdown") {
            for (i = 0; i < msg.data.length; i++) {
                if (document.getElementById(msg.data[i])) {
                    document.getElementById(msg.data[i]).remove();
                }
            }
        }
        // else if (msg.type == "LoadDone"){
        // document.getElementById("loading").style.display = "none";
        // }

        //  When customer resizes his page, clear agent's canvas as well
        else if (msg.type === "resize") {
            clearCanvas(intid)
        }

    } catch (e) {
        CobrowseLogging("ttfcbUser.onMessage()", e, "error");
    }
}



var cbScaleX = 1;
var cbScaleY = 1;
var cbScreenDiffX = 0;
var cbScreenDiffY = 0;
//user page image received, draw it
function drawImage(w, h, d, parts, x, splitImage) {
    try {

        //set the controls
        if (x !== null && x.length > 0) {
            for (var i = 0; i < x.length; i++) {
                try {
                    var child = document.getElementById(x[i].id);
                    if (child !== null) {
                        coBrowseContainer.removeChild(child);
                    }
                } catch (e) {
                    CobrowseLogging("ttfcbUser.drawImage()", e, "error");
                }

                if (x[i].ttfclass === "ttf-cb-text") {
                    createInput(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-select") {
                    createSelect(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-hide") {
                    createHide(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-btn") {
                    createButton(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-link") {
                    createHLink(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-para") {
                    createPara(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-checkbox") {
                    createCheckbox(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-radiobox") {
                    createRadiobox(x[i]);
                }
                else if (x[i].ttfclass === "ttf-cb-hr") {
                    createHrLine(x[i]);
                }
            }
        }
    } catch (e) {
        CobrowseLogging("ttfcbUser.drawImage()", e, "error");
    }

}

//Creating Input element in agent side
function createInput(x) {
    try {
        var c = document.createElement("INPUT");
        c.id = x.id;
        //c.style = x.style;
        c.value = x.value;
        c.type = x.type;
        c.style.position = "absolute";

        c.style.top = x.coordinates.top + "px";
        c.style.left = x.coordinates.left + "px";

        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";

        coBrowseContainer.appendChild(c);

        c.onchange = function () {
            var command = {};
            command.type = "controlChanged";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createInput()", e, "error");
    }
}

function createCheckbox(x) {
    try {
        var c = document.createElement('input');
        c.type = x.type;
        c.value = x.value;
        c.id = x.id;
        c.checked = x.checked;
        c.style.position = "absolute";
        c.style.top = (x.coordinates.top).toString() + "px";
        c.style.left = (x.coordinates.left).toString() + "px";
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";
        coBrowseContainer.appendChild(c);
        c.onchange = function () {
            var command = {};
            command.type = "checkClick";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createCheckbox()", e, "error");
    }

}

function createRadiobox(x) {
    try {
        var c = document.createElement('input');
        c.type = x.type;
        c.value = x.value;
        c.name = x.name;
        c.id = x.id;
        c.checked = x.checked;
        c.style.position = "absolute";
        c.style.top = (x.coordinates.top).toString() + "px";
        c.style.left = (x.coordinates.left).toString() + "px";
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";
        coBrowseContainer.appendChild(c);
        c.onchange = function () {
            var command = {};
            command.type = "checkClick";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createRadiobox()", e, "error");
    }
}

//Creating Dropdown element in agent side
function createSelect(x) {
    try {
        var c = document.createElement("SELECT");
        c.id = x.id;
        //c.style = x.style;
        c.value = x.value;
        //c.options[c.selectedIndex].value = x.value;
        c.style.position = "absolute";
        c.style.top = x.coordinates.top + "px";
        c.style.left = x.coordinates.left + "px";
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";

        if (x.options.length > 0) {
            for (var z = 0; z < x.options.length; z++) {

                var option = document.createElement("option");
                option.text = x.options[z].text;
                option.value = x.options[z].value;

                if (z === x.selectedIndex)
                    option.setAttribute('selected', true);
                c.add(option);
            }
        }

        coBrowseContainer.appendChild(c);

        c.onchange = function () {
            var command = {};
            command.type = "controlChanged";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createSelect()", e, "error");
    }
}

//Creating Hidden TextBox in agent side 
function createHide(x) {
    try {
        var c = document.createElement("SPAN");
        var t = document.createTextNode("******");
        c.appendChild(t);

        c.id = x.id;
        c.style.backgroundColor = "black";
        c.style.color = "white";

        //c.value = "";
        c.style.position = "absolute";
        c.style.top = x.coordinates.top + "px";
        c.style.left = x.coordinates.left + "px";
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";
        coBrowseContainer.appendChild(c);
    } catch (e) {
        CobrowseLogging("ttfcbUser.createHide()", e, "error");
    }
}

//Creating Horizontal line
function createHrLine(x) {
    try {
        var c = document.createElement("hr");
        c.id = x.id;
        c.style.position = "absolute";
        c.style.top = x.coordinates.top;
        c.style.left = x.coordinates.left;
        c.style.width = x.coordinates.w + "px";

        coBrowseContainer.appendChild(c);

    } catch (e) {
        CobrowseLogging("ttfcbUser.createHrLine()", e, "error");
    }
}


//Creating Button element in agent side
function createButton(x) {
    try {
        var c = document.createElement("BUTTON");
        c.id = x.id;
        c.style = x.style;
        //c.value = x.value;
        if (x.id === "Custom1" || x.id === "Custom2") {
            c.style.backgroundColor = "#337ab7";
            c.style.borderColor = "#2e6da4";
            c.style.color = "#ffffff";
        }
        else {
            c.style.backgroundColor = x.style.backgroundColor;
            c.style.borderColor = x.style.borderColor;
            c.style.color = x.style.color;
        }
        c.style.height = x.style.height;
        c.style.border = x.style.border;
        c.innerHTML = x.value;
        c.style.position = "absolute";

        c.style.top = x.coordinates.top + "px";;
        c.style.left = x.coordinates.left + "px";;

        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";

        coBrowseContainer.appendChild(c);

        c.onchange = function () {
            var command = {};
            command.type = "controlChanged";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };

        c.onclick = function () {
            var command = {};
            command.type = "buttonclick";
            command.id = this.id;

            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createButton()", e, "error");
    }
}

//Creating HyperLink element in agent side
function createHLink(x) {
    try {
        var c = document.createElement("A");
        var t = document.createTextNode(x.value);
        c.setAttribute("href", "");
        c.id = x.id;
        //c.style = x.style;
        //c.value = x.value;
        //c.innerHTML = x.value;
        c.style.position = "absolute";
        c.style.top = x.coordinates.top + "px";;
        c.style.left = x.coordinates.left + "px";
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";
        c.appendChild(t);

        coBrowseContainer.appendChild(c);

        c.onchange = function () {
            var command = {};
            command.type = "controlChanged";
            command.data = {};
            command.data.id = this.id;
            command.data.value = this.value;

            sendMessageForCb(command);
        };

        c.onclick = function () {
            var command = {};
            command.type = "linkClick";
            command.id = this.id;
            sendMessageForCb(command);
        };
    } catch (e) {
        CobrowseLogging("ttfcbUser.createHLink()", e, "error");
    }
}
//Creating Paragraph element in agent side
function createPara(x) {
    try {
        var c = document.createElement("P");
        c.id = x.id;
        c.style = x.style;
        c.innerHTML = x.text;
        c.type = x.type;
        c.style.position = "relative";
        c.style.top = x.coordinates.top + "px";;
        c.style.left = x.coordinates.left + "px";;
        c.style.height = x.coordinates.h + "px";
        c.style.width = x.coordinates.w + "px";

        c.onmouseup = function () {
            var command = {};
            command.type = "agentParaClick";
            command.id = this.id;
            drawParaSelect();
            var ele = document.getElementById("ttfcb_span");
            if (ele !== null) {
                command.top = ele.style.top;
                command.left = ele.style.left;
                command.height = ele.style.height;
                command.width = ele.style.width;
            }

            sendMessageForCb(command);
        };
        coBrowseContainer.appendChild(c);
    } catch (e) {
        CobrowseLogging("ttfcbUser.createPara()", e, "error");
    }
}


//var container = document.getElementById("container");
function setUserEvents() {
    try {
        const delegate = (selector) => (cb) => (e) => e.target.matches(selector) && cb(e);

        const inputDelegate = delegate('input[type=text]');
        const emailDelegate = delegate('input[type=email]');
        const dateDelegate = delegate('input[type=date]');
        const checkDelegate = delegate('input[type=checkbox]');
        //const selectDelegate = delegate('select');

        document.body.addEventListener('keyup', inputDelegate((el) => InputTextKeyUpEvent(el)));
        document.body.addEventListener('keyup', emailDelegate((el) => InputTextKeyUpEvent(el)));
        document.body.addEventListener('keyup', dateDelegate((el) => InputTextKeyUpEvent(el)));
        document.body.addEventListener('change', dateDelegate((el) => InputTextKeyUpEvent(el)));
        document.body.addEventListener('change', checkDelegate((el) => CheckboxKeyUpEvent(el)));

        //document.body.addEventListener('focusin', selectDelegate((el) => InputTextFocusInEvent(el)));
        //document.body.addEventListener('focusout', selectDelegate((el) => InputTextFocusOutEvent(el)));

        //document.body.addEventListener('focusin', inputDelegate((el) => InputTextFocusInEvent(el)));
        //document.body.addEventListener('focusout', inputDelegate((el) => InputTextFocusOutEvent(el)));
    } catch (e) {
        CobrowseLogging("ttfcbUser.setUserEvents()", e, "error");
    }
}

function InputTextKeyUpEvent(el) {
    try {
        var obj = {};
        obj.type = "inputdata";
        obj.value = el.target.value;
        obj.id = el.target.id;
        sendMessageForCb(obj);
    } catch (e) {
        CobrowseLogging("ttfcbUser.InputTextKeyUpEvent()", e, "error");
    }
}

function CheckboxKeyUpEvent(el) {
    try {
        var obj = {};
        obj.type = "checkClick";
        obj.checked = el.target.checked;
        obj.id = el.target.id;
        sendMessageForCb(obj);
    } catch (e) {
        CobrowseLogging("ttfcbUser.CheckboxKeyUpEvent()", e, "error");
    }
}

function offset(el) {
    try {
        var rect = el.getBoundingClientRect(),
            //scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
            //scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            scrollLeft = document.body.scrollLeft, //Fix for controlls offset
            scrollTop = document.body.scrollTop;
        return { top: rect.top + scrollTop, left: rect.left + scrollLeft, h: rect.height, w: rect.width }
    } catch (e) {
        CobrowseLogging("ttfcbUser.offset()", e, "error");
    }
}

function captureControls(intid) {
    try {
        //---------------capture input controls which is enabled for cb----------------------
        //TextBox Controls 
        var inputControls = new Array();
        var cnt = 0;

        var command = {};

        command.data = {};
        //command.data.totalh = rect.height;
        //command.data.totalw = rect.width;

        // try {
        // command.data.scrollHeight = document.scrollingElement.scrollTop;
        // } catch (e) {
        // console.log(e);
        // }
        try {
            command.data.w = document.getElementById('sendersCanvas').width; //document.body.scrollWidth;
            command.data.h = document.getElementById('sendersCanvas').height;
        } catch (e) {
            command.data.w = document.body.offsetWidth; //document.body.scrollWidth;
            command.data.h = document.body.offsetHeight;
        }
        //command.data.w = document.getElementById('sendersCanvas').width; //document.body.scrollWidth;
        //command.data.h = document.getElementById('sendersCanvas').height;
        //command.data.d = d;
        //command.data.splitImage = splitImage;
        //command.data.parts = partsIdsToSend;
        var element = "";
        var c = {};

        if (customerCobrowseControls && customerCobrowseControls !== undefined && customerCobrowseControls !== null && customerCobrowseControls !== "") {
            if (customerCobrowseControls.textboxId && customerCobrowseControls.textboxId !== undefined && customerCobrowseControls.textboxId !== null && customerCobrowseControls.textboxId !== "")
                for (i = 0; i < customerCobrowseControls.textboxId.length; i++) {
                    element = document.getElementById(customerCobrowseControls.textboxId[i]);
                    command.type = "deleteAllControls-textbox";
                    command.data = customerCobrowseControls.textboxId;
                    sendMessageForCb(command);
                    if (isElementInViewport(element)) {
                        c = {};
                        c.id = element.id;
                        //c.style = element.style;
                        c.value = element.value;
                        c.type = element.type;
                        c.coordinates = offset(element);
                        c.ttfclass = "ttf-cb-text";
                        inputControls[cnt] = c;
                        cnt++;

                        command.type = "drawImage";
                        command.data = {};
                        command.data.inputControls = inputControls;
                        sendMessageForCb(command);
                    }
                }
            if (customerCobrowseControls.radioButtonId && customerCobrowseControls.radioButtonId !== undefined && customerCobrowseControls.radioButtonId !== null && customerCobrowseControls.radioButtonId !== "")
                for (i = 0; i < customerCobrowseControls.radioButtonId.length; i++) {
                    element = document.getElementById(customerCobrowseControls.radioButtonId[i]);
                    command.type = "deleteAllControls-radiobutton";
                    command.data = customerCobrowseControls.radioButtonId;
                    sendMessageForCb(command);
                    if (isElementInViewport(element)) {
                        c = {};
                        c.id = element.id;
                        //c.style = element.style;
                        c.name = element.name;
                        c.type = element.type;
                        c.value = element.value;
                        c.checked = element.checked;
                        c.coordinates = offset(element);
                        c.ttfclass = "ttf-cb-radiobox";
                        inputControls[cnt] = c;
                        cnt++;
                        command.type = "drawImage";
                        command.data = {};
                        command.data.inputControls = inputControls;
                        sendMessageForCb(command);
                    }
                }
            if (customerCobrowseControls.checkboxId && customerCobrowseControls.checkboxId !== undefined && customerCobrowseControls.checkboxId !== null && customerCobrowseControls.checkboxId !== "")
                for (i = 0; i < customerCobrowseControls.checkboxId.length; i++) {
                    element = document.getElementById(customerCobrowseControls.checkboxId[i]);
                    command.type = "deleteAllControls-checkbox";
                    command.data = customerCobrowseControls.checkboxId;
                    sendMessageForCb(command);
                    if (isElementInViewport(element)) {
                        c = {};
                        c.id = element.id;
                        //c.style = element.style;
                        c.type = element.type;
                        c.value = element.value;
                        c.checked = element.checked;
                        c.coordinates = offset(element);
                        c.ttfclass = "ttf-cb-checkbox";
                        inputControls[cnt] = c;
                        cnt++;
                        command.type = "drawImage";
                        command.data = {};
                        command.data.inputControls = inputControls;
                        sendMessageForCb(command);
                    }
                }
            if (customerCobrowseControls.dropdownId && customerCobrowseControls.dropdownId !== undefined && customerCobrowseControls.dropdownId !== null && customerCobrowseControls.dropdownId !== "")
                for (i = 0; i < customerCobrowseControls.dropdownId.length; i++) {
                    element = document.getElementById(customerCobrowseControls.dropdownId[i]);
                    command.type = "deleteAllControls-dropdown";
                    command.data = customerCobrowseControls.dropdownId;
                    sendMessageForCb(command);
                    if (isElementInViewport(element)) {
                        c = {};
                        c.id = element.id;
                        //c.style = element.style;
                        c.value = element.value;
                        c.coordinates = offset(element);
                        c.options = new Array();
                        c.ttfclass = "ttf-cb-select";
                        c.selectedIndex = element.options.selectedIndex;

                        for (var z = 0; z < element.options.length; z++) {
                            var op = {};
                            op.value = element.options[z].value;
                            op.text = element.options[z].text;

                            c.options[z] = op;
                        }
                        inputControls[cnt] = c;
                        cnt++;
                        command.type = "drawImage";
                        command.data = {};
                        command.data.inputControls = inputControls;
                        sendMessageForCb(command);
                    }
                }
        }

        //var x = document.getElementsByClassName("ttf-cb-text");
        //for (var i = 0; i < x.length; i++) {
        //    var c = {};
        //    c.id = x[i].id;
        //    c.style = x[i].style;
        //    c.value = x[i].value;
        //    c.type = x[i].type;
        //    c.coordinates = offset(x[i]);
        //    c.ttfclass = "ttf-cb-text";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //var ch = document.getElementsByClassName("ttf-cb-checkbox");
        //for (var i = 0; i < ch.length; i++) {
        //    var c = {};
        //    c.id = ch[i].id;
        //    c.style = ch[i].style;
        //    c.type = ch[i].type;
        //    c.value = ch[i].value;
        //    c.checked = ch[i].checked;
        //    c.coordinates = offset(ch[i]);
        //    c.ttfclass = "ttf-cb-checkbox";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //var rd = document.getElementsByClassName("ttf-cb-radiobox");
        //for (var i = 0; i < rd.length; i++) {
        //    var c = {};
        //    c.id = rd[i].id;
        //    c.style = rd[i].style;
        //    c.name = rd[i].name;
        //    c.type = rd[i].type;
        //    c.value = rd[i].value;
        //    c.checked = rd[i].checked;
        //    c.coordinates = offset(rd[i]);
        //    c.ttfclass = "ttf-cb-radiobox";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        ////Dropdown Controls
        //var y = document.getElementsByClassName("ttf-cb-select");
        //for (var i = 0; i < y.length; i++) {
        //    var c = {};
        //    c.id = y[i].id;
        //    //c.style = y[i].style;
        //    c.value = y[i].value;
        //    c.coordinates = offset(y[i]);
        //    c.ttfclass = "ttf-cb-select";
        //    c.options = new Array();
        //    c.selectedIndex = y[i].options.selectedIndex;

        //    for (var z = 0; z < y[i].options.length; z++) {
        //        var op = {};
        //        op.value = y[i].options[z].value;
        //        op.text = y[i].options[z].text;

        //        c.options[z] = op;
        //    }
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //Hidden TextBox Controls
        //var hide = document.getElementsByClassName("ttf-cb-hide");
        //for (var i = 0; i < hide.length; i++) {
        //    var c = {};
        //    c.id = hide[i].id;
        //    //c.style = hide[i].style;
        //    c.value = hide[i].value;
        //    c.coordinates = offset(hide[i]);
        //    c.ttfclass = "ttf-cb-hide";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //Horizontal Line control
        //var hr = document.getElementsByClassName("ttf-cb-hr");
        //for (var i = 0; i < hr.length; i++) {
        //    var c = {};
        //    c.id = hr[i].id;
        //    c.coordinates = offset(hr[i]);
        //    c.ttfclass = "ttf-cb-hr";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //HyperLink Controls
        //var alist = document.getElementsByTagName("a");
        //for (var i = 0; i < alist.length; i++) {
        //    var url = new URL(alist[i].href);
        //    //if (url.search.includes("?")) {
        //    //    if (url.search.includes("ttfcb_id"))
        //    //    {; }
        //    //    else
        //    //        url.search = url.search + "&ttfcb_id=" + localId;
        //    //}
        //    //else {
        //    //    if (url.search.includes("ttfcb_id"))
        //    //    { }
        //    //    else
        //    //        url.search = "?ttfcb_id=" + localId;
        //    //}
        //    //alist[i].href = url;

        //    var c = {};
        //    c.id = alist[i].id;
        //    //c.style = alist[i].style;
        //    c.value = alist[i].innerHTML;
        //    c.coordinates = offset(alist[i]);
        //    c.ttfclass = "ttf-cb-link";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //Button Controls
        //var btn = document.getElementsByClassName("ttf-cb-btn");
        //for (var i = 0; i < btn.length; i++) {
        //    var c = {};
        //    if (btn[i].id != null || btn[i].id != "" || btn[i].id != undefined) {
        //        c.id = btn[i].id;
        //    }
        //    c.style = btn[i].style;
        //    c.value = btn[i].innerHTML;
        //    c.style.backgroundColor = btn[i].style.backgroundColor;
        //    c.coordinates = offset(btn[i]);
        //    c.ttfclass = "ttf-cb-btn";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        ////Paragraph Controls
        //var para = document.getElementsByClassName("ttf-cb-para");
        //for (var i = 0; i < para.length; i++) {
        //    var c = {};
        //    c.id = para[i].id;
        //    //c.style = btn[i].style;
        //    c.text = para[i].innerHTML;
        //    c.value = para[i].value;
        //    c.coordinates = offset(para[i]);
        //    c.ttfclass = "ttf-cb-para";
        //    inputControls[cnt] = c;
        //    cnt++;
        //}

        //var rect = coBrowseContainer.getBoundingClientRect();
    } catch (e) {
        CobrowseLogging("ttfcbUser.captureControls()", e, "error");
    }
}

function isElementInViewport(element) {
    var top = element.offsetTop;
    var left = element.offsetLeft;
    var width = element.offsetWidth;
    var height = element.offsetHeight;

    while (element.offsetParent) {
        element = element.offsetParent;
        top += element.offsetTop;
        left += element.offsetLeft;
    }

    return (
        top < (window.pageYOffset + window.innerHeight) && left < (window.pageXOffset + window.innerWidth) && (top + height) > window.pageYOffset && (left + width) > window.pageXOffset
    );
}

/**
 * Send the Cobrowse Container side to the other user when window is resized
 */
function SendCobrowseContainerSize() {
    try {
        var rect = coBrowseContainer.getBoundingClientRect();
        var command = {};
        command.type = "containersize";
        command.totalh = rect.height;
        command.totalw = rect.width;
        sendMessageForCb(command);

        //if (cb_started)
        //setTimeout(SendCobrowseContainerSize, 3000);
    } catch (e) {
        CobrowseLogging("ttfcbUser.SendCobrowseContainerSize()", e, "error");
    }
}