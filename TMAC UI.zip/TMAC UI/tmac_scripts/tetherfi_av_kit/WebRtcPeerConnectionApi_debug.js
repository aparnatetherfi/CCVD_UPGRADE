/*
 * Copyright (c) 2018 Tetherfi Pte. Ltd. (www.tetherfi.com).
 * All rights reserved.
 *
 * This source code is property of Tetherfi Pte. Ltd. product suit. Any use of this code in any 
 * form, for any purpose is strictly prohibited unless prior written permission is obtained from 
 * Tetherfi Pte. Ltd.
 */

var WrsJsVersion = "1.1.3.7";

/**
 * The Error code constants
 */
var WrsErrorCodes = {
    /**
     * Following errors are recoverable and would not cause the object to transit to a error state.
     */
    INVALID_USER_STATE: 10,
    INVALID_CONNECTION_STATE: 11,
    ADD_ICE_FAILED: 12,
    INVALID_ARGUMENT: 13,

    /**
     * Following errors are irrecoverable and would cause the object to transit to a error state. 
     * Any subsequent calls to the functions of the object would result a error after the object 
     * has moved to a error state. 
     */
    GET_USER_MEDIA_FAILED: 30,
    CREATE_SDP_FAILED: 31,
    RECORDING_FAILED: 32,
    REQUEST_TIMED_OUT: 33
}

/**
 * The Call connection mode constants
 */
var WrsConnectionModes = {
    /**
     * The call will be made normally and will be recorded if a MediaServer is present in 
     * between and configured accordingly
     */
    Normal: 0,

    /**
     * The call will be made such that all video streams will flow as described in Normal mode 
     * (via MS) and all audio streams will bypass any intermediate MediaServer even if such is 
     * present in between
     */
    DirectAudio: 1,

    /**
     * The call will be made such that all audio streams will flow as described in Normal mode
     * (via MS) and all video streams will bypass any intermediate MediaServer even if such is
     * present in between 
     */
    DirectVideo: 2,

    /**
     * The call will bypass any intermediate MediaServer setup all-together and will connect P2P
     * straight to the browser at other end
     */
    Direct: 3
}

/**
 * The stream status events
 */
var WrsStreamEvents = {
    /**
     * The stream was connected and media flowing
     */
    Connected: 1,

    /**
     * The stream was disconnected temporarily and media flow paused 
     */
    Disconnected: 2,

    /**
     * The stream was closed and media flow stopped permanently
     */
    Ended: 3
}

/**
 * DTMF tones
 */
var WrsDtmfTones = {
    NUM_0: 0,
    NUM_1: 1,
    NUM_2: 2,
    NUM_3: 3,
    NUM_4: 4,
    NUM_5: 5,
    NUM_6: 6,
    NUM_7: 7,
    NUM_8: 8,
    NUM_9: 9,
    Star: 100,     // Dialpad key '*'
    Pound: 101     // Dialpad key '#'
}

/**
 * The utility class interface. These methods provide enhanced and cross browser compatible 
 * functionality that may be useful for API users.
 * 
 * User is not required to implement this interface. Instead this describes the functionality
 * given by WrsUtils global variable. Please refer to WrsUtils global variable described bellow
 * 
 * @class WrsUtilsInterface
 */
function WrsUtilsInterface(instance) {
    var this_ = instance;

    /**
     * Call this method to retrieve the device information and check to audio/video capabilities  
     
     * @return   Promise   A promise object that will eventually resolve to check device capabilities. 
     
     hasWebcam => type:boolean , webcam is available or not available
     hasMicrophone  => type:boolean , microphone is available or not available
     isMicrophoneAlreadyCaptured/isWebcamAlreadyCaptured  => device usage 
     MediaDevices =>  => type:array , available media device list
     {hasWebcam,hasMicrophone,isMicrophoneAlreadyCaptured,isWebcamAlreadyCaptured,MediaDevices}
     
     If user didn't allow webcam and/or microphone, then media-devices will be having "NULL" value for the "label" attribute. will show this message: "Please invoke getUserMedia once."
     */
    this_.checkDeviceSupport = function () { return null; }

    /**
     * Captures audio/video streams as per provided constraints.
     * 
     * @param   object   constraints   A WebRTC Media constraints object as described in 
     *  WrsConfigurationInterface.getMediaConstraints method.
     * @param   function(string)   tracefn   A function that takes a string and loggs the given 
     *  string for debugging and troubleshooting purposes. This argument is optional and can be 
     *  omitted or null.
     * 
     * @return   Promise   Returns a Promise that ultimately resolves to a MediaStream object.
     */
    this_.getUserMedia = function (constraints, tracefn) { return null; }


    /**
     * Get the browser model and the version information.
     * 
     * @return   Object   A object of the format { name: string, version: string } describing the 
     *  browser running this script.
     */
    this_.getUserAgentInfo = function () { return null; }

    /**
     * Create a conference mixer that implements WrsMixerInterface
     * 
     * @return   WrsMixerInterface   A instance of mixer that provides conference mixing
     */
    this_.createConferenceMixer = function () { return null; }

    /**
     * Checks if a given message is of a known type by WrsPeerConnection instance.
     * 
     * @param   Object   message  The parsed message as a A JSON Object
     * 
     * @return  bool   Returns true if the message is of a known type.
     */
    this_.isKnownMessage = function (message) { return false; }
    
    /**
     * This can be used to marks a stream as screen share when implementing WrsPeerConnection.onModifyStreams
     * or WrsPeerConnection.onAcquireVideo methods to denote a stream is to be treated as screen share. Screen 
     * share streams will be treated different to other streams (e.g. they will be marked on the other side,
     * as well as they will be given high bit rates when possible and their degradation mechanism will be more
     * towards lowering frame rate over quality).
     * 
     * @param   MediaStream   stream   The stream to be marked
     * 
     * @return  MediaStream   The marked stream or a promise that resolves to a marked stream.
     */
    this_.markStreamAsScreenshare = function (stream) { return stream; }

    /**
     * This can be used to mark the owner of a stream.
     * 
     * @param   MediaStream   stream   The stream to set the owner
     * @param   string    owner   The owner id
     */
    this_.setStreamOwner = function (stream, owner) { }

    return this_;
}

/**
 * A object that implements WrsUtilsInterface. This global instance can be used to access the utility methods described 
 * in WrsUtilsInterface.
 * This instance will be initialized by the SDK and user can use once this file is loaded.
 */
var WrsUtils = WrsUtilsInterface({});

/**
 * The Channel interface represents the interface used by the WrsPeerConnection class to 
 * do the signalling between it and MediaServer.
 * 
 * User is expected to implement a class with the bellow interface.
 *
 * @class WrsChannelInterface
 */
function WrsChannelInterface(instance) {
    var this_ = instance;

    /**
     * The channel should trigger this callback upon successful receipt and decode of a JSON 
     * message.
     * It is assumed that the messages received is in the same order of the messages sent via
     * the MediaServer that this channel connects to (i.e. If the underlying transport does not
     * support message sequencing the application should handle sequencing and make sure this 
     * event is fired in proper sequence).
     * This callback will return a boolean specifying the message was consumed by this library.
     * 
     * @param   JSON   jsonObject should be a valid JSON object (i.e. a javascript object with  
     *  a dictionary interface). A string can be converted to such object by calling 
     *  JSON.parse(jsonString) function call supported in most web browsers.
     * 
     * @return   bool   Returns true if the message was of known type and it was consumed. Returns 
     *  false otherwise.
     */
    this_.onMessage = function (jsonObject) { return false; }

    /**
     * The channel should implement the function getId that returns a string that represents 
     * the local end point identifier (i.e. A name for the local endpoint such as 'customer',
     * 'agent', an-agent-ID). This string is used only for identification and logging purposes and
     * this API does not depend on the format or the content of this identifier. However it is 
     * recommended that this identifier be unique for a single instance (i.e. a web page or a 
     * session)
     * 
     * @return   string   The identifier representing the destination of the channel
     */
    this_.getId = function () { return '0000'; }

    /**
     * The channel should implement the send() function to send the message to the other party that 
     * this channel represents.
     * The WrsPeerConnection class assumes any message sent is delivered to the other party, any send 
     * errors and exceptions should be handled by the implementer.
     * 
     * @param  JSON   jsonObject A JSON object (i.e. a javascript object with a dictionary interface). 
     *  This can be converted to a string using JSON.stringify(jsonObject) function call supported 
     *  in most web browsers. 
     */
    this_.send = function (jsonObject) { }

    return this_;
}

/**
 * The Configuration interface represents the interface used by the WrsPeerConnection class to 
 * retrieve runtime configurations. The methods implemented in this class will be called when
 * those configurations are required.
 * 
 * User is expected to implement a class with the bellow interface.
 *
 * @class WrsConfigurationInterface
 */
function WrsConfigurationInterface(instance) {
    var this_ = instance;

    /**
     * @return   RTCConfiguration   A WebRTC configuration dictionary as specified at 
     *  https://www.w3.org/TR/webrtc. An example configuration would be.
     * 
     *     var configuration = {
     *         iceServers : [
     *             {urls: 'turn:turn2.l.google.com:19303', credential: 'test', username: 'test'},
     *             {urls: 'stun:stun2.l.google.com:19302'}
     *         ],
     *         iceTransportPolicy : "relay",
     *     }
     */
    this_.getWebRTCConfigurations = function () { }

    /**
     * @return   MediaStreamConstraints   A WebRTC media constraints dictionary as specified at
     *  https://www.w3.org/TR/mediacapture-streams. In addition to those keys specified by the mentioned 
     *  W3C specification, the existence of the key-value "custom" with a value "true" would allow 
     *  the caller to use a custom stream by overriding WrsPeerConnection.onAcquireUserMedia method. In addition to this
     *  if a specific device needs to be captured for audio/video the existence of "deviceName" with a value 
     *  either as an Array containing multiple regular expression patterns of  the names of the device(s) or a string with a single regular expression pattern
     *  which would allow the caller to use a specific camera(s)/mic(s) for audio/video
     *  These regular expression pattern(s) have to be configured correctly by escaping special characters
     *  Special characters include [ \ ^ $ . | ? * + ( ) 
     *  To escape these special characters, each and every special character in the string(s) needs to be prefixed with \\
     *  
     *  An example to escape special characters would be 
     *      Consider the literal string USB2.0 HD UVC WebCam (13d3:5666)
     *      Consider the string pattern that needs to be passed for matching as USB2.0 HD
     *      This pattern needs to be formatted to a proper regular expression as USB2\\.0 HD and then it should be passed to the "deviceName" property in the constraints for user media as shown below
     *      Please note, since we are passing a regular expression, while reading, javascript automatically formats the regular expression to a literal string, hence we use \\ (double-backslash) instead of \ (single-backslash) for escaping
     *
     *  An example constraints would be for default user media would be
     *     var mediaConstraints = { audio: true, video: true }
     *
     *  An example constraints for custom user media would be
     *      var mediaConstraints = { custom: true, custom_config_1: "custom value", custom_config_2: "another custom value" }
     *
     *  An example constraints for user media with deviceName would be
     *   var mediaConstraints = { audio: {enabled:true; deviceName:["Logitech-225","\\(Realtek High Definition Audio\\)"]}, video: {enabled:true; deviceName:"2\\.0 HD UVC WebCam"} }
     */
    this_.getMediaConstraints = function () { }

    /**
     * @return   RTCOfferOptions   A WebRTC offer options dictionary as specified at 
     *  https://www.w3.org/TR/webrtc. Usually it would be a variable as shown bellow.
     *
     *     var offerOptions = { offerToReceiveAudio: true, offerToReceiveVideo: true, iceRestart: true }
     */
    this_.getOfferOptions = function () { }

    /**
     * @return   RTCAnswerOptions   A WebRTC answer options dictionary as specified at
     *  https://www.w3.org/TR/webrtc.  Usually it would be a variable as shown bellow.
     * 
     *     var answerOptions = { iceRestart: true }
     */
    this_.getAnswerOptions = function () { }

    /**
     * @return   int   The bandwidth upper limit for the entire connection (i.e. all tracks)
     *  in kbps (kilobits per second).
     */
    this_.getConnectionBandwidthUpperLimit = function () { return 2048; }

    /**
     * @return   int   The bandwidth upper limit for a single audio track in kbps (kilobits per 
     *  second).
     */
    this_.getAudioTrackBandwidthUpperLimit = function () { return 32; }

    /**
     * @return   int   The bandwidth upper limit for a single video track in kbps (kilobits per 
     *  second).
     */
    this_.getVideoTrackBandwidthUpperLimit = function () { return 512; }

    /**
     * @deprecated Do not use this methhod.
     */
    this_.enableCdcAutoSelection = function () { return false; }

    /**
     * @return   WrsConnectionModes   Specifies whether to (or not to) create two underlying 
     *  connections for audio and video communication and which streams should direct connect to 
     *  other end.
     *  This parameter should be carefully set in all parties for the solution to work properly.
     *  Changing the default behavior is only necessary in very specific scenarios only; thus 
     *  application users should not be overriding this in normal scenarios.
     */
    this_.getAudioVideoConnectionMode = function () { return WrsConnectionModes.Normal; }

    /**
     * @return   bool   Specifies whether to merge unrelated streams that has single tracks
     *  of opposite types in to one stream. If set this would cause incoming stream with
     *  single audio track of one source (e.g. Sip Phone, Other Peer) to be merged with a 
     *  stream of single video track of another source. This will not merge single track 
     *  streams coming form same source. The sources are distinguished based on the underlying
     *  connection as specified by getAudioVideoConnectionMode function.
     */
    this_.tryToMergeSingleTrackStreamsFromDifferentSources = function () { return false; }

    /**
     * @return   Objecct   Specifies whether to enable incoming stream recording and specifies
     *  the configurations for where to store/push them. If the return is false the recording 
     *  will be disabled and no recording done.
     *  
     *  The object is fo following format
     *      var recordingConfig = {
     *          enabled: true,
     *          codec: "vp9",
     *          recordLocal: true,
     *          audioKbps: 32,
     *          videoKbps: 512
     *      }
     *  
     *  The recordingConfig.enabled specifies whether to enable recordings; and the codec specifies 
     *  output codec. The codec can be "vp8", "vp9" or "h264" depending on the browser support. 
     *  When unspecified, this will automatically determined based on web borwser. Codec parameter
     *  should usually be unspecified.
     *  
     *  The recordLoacl parameter can be specified to enable recording local streams as well. By default
     *  the local streams will be recorded; this behaviour can be changed by setting it to false.
     *  
     *  The audioKbps and videoKbps parameters specify the audio and video recording bitrates in Kbps.
     *  Setting this to unnecessarily higher values may increase the mabdwidth required between 
     *  communication from this api to the  temporary media storage (i.e. MediaServer) system. When 
     *  unspecified audio track will be encoded at 32Kbps and video track at 512Kbps. 
     */
    this_.getRecordingOptions = function () {
        return {
            enabled: false
        }
    }
	
	/** @return bool specifies whether to talk detection techniques are enabled using stat's audio level or not.
	 By default we have disabled it. If application is interested to fetch who is speaking in the during 
	 conference, then application needs to override this function and return true. true return value indicates
	 its talk detection is enabled, false indicates its disabled.
	*/
    this_.isAudioLevelCheckEnabled = function() { return false; }
	
	/** @return double specifies the minimum threshold audiolevel value needed to mark the remote stream is 
	  talking, the remote audio stream stat's audioLevel is compared against this threshold audioLevel value, 
	  if the remote stream audiolevel is above the this value, then only that stream is considered as talking else it will
	  be considered as not talking.
	*/
    this_.getAudioLevelThreshold = function() { return 0.11; }

    /**
     * @return   bool   Specifies whether to enable audio mixing capabilities. When Mixing is enabled
     *  the WrsPeerConnection can be user as a valid input to WrsConferenceMixer to mix audio that allows
     *  conference like behavior.
     */
    this_.isAudioMixerEnabled = function () { return false; }

    return this_;
}

/**
 * The Stats interface represents the interface used by the WrsPeerConnection class to 
 * get the WebRTC stats information.
 * 
 * User is expected to implement a class with the bellow interface.
 * 
 * @class WrsStatsInterface
 */
function WrsStatsInterface(instance) {
    var this_ = instance;

    /**
     * The channel should implement the getStatsInterval() function to get the interval timeout 
     * set for the WebRTC get stats method, by default if this method is overridden it will return 0
     * 
     * @return The interval in milliseconds for stats querying. The value returned should be either 0
     * or within the range 250 - 10000.
     */
    this_.getStatsInterval = function () { return 0; };

    /**
     * This callback will be triggered when media stats are available. The user can override  
     * this function to capture the WebRTC stats for processing.
     * 
     * @param {array} stats array of stats which can be send to monitor
     */
    this_.onStats = function (stats) { };

    return this_;
}

/**
 * The mixer interface provides basic functionality of mixing between various WrsPeerConnection
 * objects. Please use WrsUtilsInterface to instantiate various mixers.
 * 
 * @class WrsMixerInterface
 */
function WrsMixerInterface(instance) {
    var this_ = instance;

    /**
     * Add the give WrsPeerConnection for mixing
     * 
     * @param   WrsPeerConnection   pc   A WrsPeerConnection to be to be mixed with others
     * 
     * @return   bool   Returns if operation was successful
     */
    this_.add = function (pc) { return false; }

    /**
     * Remove given WrsPeerConnection from mixing
     * 
     * @param   WrsPeerConnection   pc   A previously added WrsPeerConnection to be removed
     * 
     * @return   bool   Returns if operation was successful
     */
    this_.remove = function (pc) { return false; }
}


/**
 * The player interface provides basic functionality of contralling media file playback on a call
 * objects. Please use WrsPeerConnection to instantiate a player.
 * 
 * @class WrsPlayerInterface
 */
function WrsPlayerInterface(instance) {
    var this_ = instance;

    /**
     * Enable looping playback. this must be called while audio is being played (i.e. before onEnd 
     * event is triggered)
     * 
     * @param   boolean   loop   Whether to loop playing the audio file. When this is set, the onEnd 
     *  will never be triggered.
     */
    this_.setLoop = function(loop) { }

    /**
     * Pause playback of the file. by default the player will start playing after creation. User
     * can call this method just after instentiating this object to prevent playback immdiately.
     */
    this_.pause = function() { }

    /**
     * Resumes playback of the file.
     */
    this_.resume = function() { }

    /**
     * Stpos playback and cleans resources
     */
    this_.stop = function() { }

    /**
     * Provide the current playback position as a perscentage of the total length of the file.
     * Returns 100 when calling after the playback has ended.
     */
    this_.getPosition = function() { }

    /**
     * Provides the duration of the audio file in seconds if duration can be pre determined.
     * For stream files, the duration may return the current playback time.
     */
    this_.getDuration = function() {}

    /**
     * Specifies whether the playback is currently paused.
     */
    this_.isPaused = function() { return false; }

    /**
     * Specifies whether the playback looping is currently enabled.
     */
    this_.isLooped = function() { return false; }

    /**
     * Triggered when the media file is played to the end
     */
    this_.onEnd = function() { }
}

/**
 * The WrsPeerConnection class handles a single WebRTC audio/video call. Using the channel given 
 * in the constructor it communicates with the MediaServer to establish a WebRTC call.
 * 
 * @class WrsPeerConnection
 * 
 * @param   WrsChannelInterface   channel   The channel to communicate with MediaServer. The object  
 *  should implement the WrsChannelInterface.
 *
 * @param   WrsConfigurationInterface   configs   The object used to query runtime configurations.
 *  The object should implement the WrsConfigurationInterface.
 * 
 * @param   string   intent   A string that identifies this instance from other use of WrsPeerConnection
 *  instances for a single signaling channel. For example, this can be "call", "cobrowse" ...etc. 
 *  If unspecified, defaults to "call". 
 *  
 * @param   WrsStatsInterface   statsifs   The object used for stats publishing and querying stat 
 *  related configurations. When unspecified or null, the media connection stat publishing will be
 *  disabled.
 */
function WrsPeerConnection(channel, configs, intent, statsifs) {
    var this_ = this;

    /**
     * This callback will be triggered when a new stream is received or a existing stream is modified
     * (i.e. a new track is added to a stream). The user can override this method to handle the new
     * stream and to place audio/video as required.
     * 
     * @param   Array   streams   An array of MediaStream objects (note: the actual datatype is
     *  FrozenArray<MediaStream>) as specified in https://www.w3.org/TR/webrtc and 
     *  https://www.w3.org/TR/mediacapture-streams.
     *  
     *  @param   Object  info   A map that maps stream id to a object that contains stream info
     *   The structure of the Object is { stream-id-1: { owner: stream-1-user-id }, ... }
     */
    this_.onAddVideo = function (streams, info) { }

    /**
     * This callback will be triggered when the local media is captured. The user can override  
     * this method to display own audio/video stream as required.
     * 
     * @param   Array   streams   An array of MediaStream object as specified in
     *  https://www.w3.org/TR/webrtc and https://www.w3.org/TR/mediacapture-streams. The returned
     *  Array is frozen and non-mutable.
     * 
     * @note From release 1.0.0.9, this method has changed such that it is not backward compatible
     *  with the previous releases. The "streams" argument which used to be a MediaStream object in
     *  previous releases; has been changed to a Array of MediaStream objects from 1.0.0.9 release 
     *  onwards. Any application using this interface should update their applications accordingly.
     *  User can use WrsUtils.setStreamOwner or WrsUtils.markStreamAsScreenshare as described in 
     *  WrsPeerConnection.onModifyStreams() to mark screenshare streams or to specify owner for 
     *  forwarded streams.
     */
    this_.onAcquireVideo = function (streams) { }

    /**
     * This callback is triggered when a call request is received. The user can override this method
     * to prepare the UI/application for a incoming call. This call should not be used to prompt user
     * acceptance nor the API process any return value to reject a call. The call agreement must be 
     * done separately via separate application level signaling.
     */
    this_.onCallRequest = function () { }

    /**
     * This callback will be triggered when the connection was established upon successful WebRTC 
     * handshake. The onAddVideo() may be called prior to this call and it is recommended that the 
     * video display to be hidden from view while onAddVideo() is called and only shown to user 
     * after onConnect() is triggered. User may display a connecting message (i.e. ring tone, 
     * advertisement ...etc) during the period between user call to call() method and until 
     * onConnect() is triggered.
     */
    this_.onConnect = function () { }

    /**
     * This callback will be triggered when the connection is temporarily disconnected. When this callback is
     * triggered, application can show reconnecting state.
     */
    this_.onReconnecting = function () { }

    /**
     * This callback will be triggered when the connection was established after temporary disconnection. When this callback is
     * triggered, application can show reconnected state.
     */
    this_.onReconnected = function () { }

    /**
     * This callback will be triggered when the connection has been ended. When this callback is 
     * triggered, application can hide the video views.
     */
    this_.onDisconnect = function () { }

    /**
     * This callback will be triggered when the connection (ICE) state is changed. This callback can be used 
     * to store the state of connection for troubleshooting purposes.
     * 
     * @param   string   state   State of the connection (ICE)
     */
    this_.onIceStateChanged = function (state) { }

    /**
     * This call back is fired when the call is put to hold by a request from remote end. This will not be 
     * fired when thc call is put on hold by local end.
     * 
     * @param   bool   hold   Whether call is on hold or not
     */
    this_.onHoldUnhold = function (hold) { }

    /**
     * This callback will be triggered when a error occurs.
     * @param   int   code   The error code
     * @param   string   msg   The error message string
     */
    this_.onError = function (code, msg) { }

    /**
     * This callback will be triggered when this application needs to output log messages. These log 
     * messages are useful for troubleshooting issues, thus application should output them in a 
     * appropriate manner. The default implementation is to log to the debug console.
     */
    this_.onTrace = function (messageString) {
        console.log(messageString);
    }

    /**
     * This callback will be triggered when the api requires retrieval of user media. This method 
     * is expected to return a MediaStream object, Array of MediaStream objects, A Promise that 
     * evaluates to a MediaStream object or a Promise that evaluates to a Array of MediaStream 
     * objects.
     * 
     * A MediaStream object is specified at https://w3c.github.io/mediacapture-main/#mediastream URL.
     * 
     * When overridden user can provide a custom media to be streamed to the peer. To enable this 
     * the user must set the "custom" attribute of the media constraints dictionary returned by the 
     * getMediaConstraints method of WrsConfigurationInterface.
     * 
     * The returned MediaStream object is allowed to have up-to maximum 1 audio track and 1 video 
     * track. A exception would be fired when a given stream has more that 1 audio/video track.
     */
    this_.onAcquireUserMedia = function (mediaConstraints) {
        return null;
    }

    /**
     * User should call this method to initiate a new WebRTC audio/video communication. If the application
     * is awaiting a communication from other party, the application does not need to call this method.
     */
    this_.call = function () { }

    /**
     * User should call this method to join a existing a WebRTC audio/video communication. If the application
     * is awaiting a communication from other party, the application does not need to call this method.
     * @param   object   parameters   The parameters object specifying join details. When omitted, defaults to 
     *  "conference" mode. The parameters object is expected to be in following format.
     *
     *     var parameters = {
     *         // The "<mode>" can be one of "wisper", "conference" or "monitor". The callers who are agents are 
     *         // only allowed to join in wisper and monitor modes. Any user is allowed to be joined in conference
     *         // mode.
     *         // The wisper mode would join a agent to the conversation such that he can listen to customers and 
     *         // other agents and he can be heard only by other agents.
     *         // The conference mode would join the a caller to the conversation such that he can listen to all 
     *         // other parties joined as conference (and other agents joined as wisper if the caller is a agent) 
     *         // and he can be heard by all the other parties.
     *         // The monitor mord would join a agent to the conversation such that no other party can hear the caller
     *         // and the caller can listen to all other parties joined either as wisper or conference.
     *         mode : "<mode>"
     *     };
     */
    this_.join = function (parameters) { }

    /**
     * User can call this method to mute components of the call.
     * 
     * @param   bool   audio   Specifies whether to mute all audio tracks
     * @param   bool   video   Specifies whether to pause all video tracks
     */
    this_.mute = function (audio, video) { }

    /**
     * User can call this method to unmute components of the call.
     * 
     * @param   bool   audio   Specifies whether to unmute all audio tracks
     * @param   bool   video   Specifies whether to resume all video tracks
     */
    this_.unMute = function (audio, video) { }

    /**
     * User can call this method to hold the call. When clicked both audio/video streams will be muted/paused
     * in all parties connected to the call.
     */
    this_.hold = function () { }

    /**
     * User can call this method to unhold the call. When clicked any effects of hold() will be reversed on
     * all parties.
     */
    this_.unHold = function () { }

    /**
     * User can call this method to end a connected WebRTC communication channel. Upon calling this method
     * user should dispose of this WrsPeerConnection instance and it should not be used for further 
     * communications.
     */
    this_.close = function () { }

    /**
     * User can check whether the connection is alive by using this method.
     * @return   bool   Returns whether the connection is initiated or not.
     */
    this_.isConnected = function () { }

    /**
     * This call can be used to check if the current instance is in a error state. When the object is in a 
     * error state any user method call will result in a failure and object is not usable. User should 
     * dispose the object by calling close() method and instantiate a new object.
     * User will be notified via a onError callback prior to the object moving to the error state.
     */
    this_.isError = function () { }
	
	/**
     * This callback will be fired for every one second, this will pass the remote streamId for the user
	 * who is talking, if no one is talking then empty string ("") streamId will be passed. there will be threshold 
	 * value set from the application configuration, if the audiolevel crosses that threshold then the audio level 
	 * from that stream is treated as talking and streamid will be passed to this function. Application is expected
	 * to map the streamId to the userId. 
     * 
     * @param   string   streamId   The id of the current active audio stream. A empty string will be passed if no 
     *  audio stream is active at the moment. A active audio stream is the stream with the most prominent speech 
     *  output
     *  
     *  @param   number   level   A number representing audio level of the stream
	 */
    this_.onVoiceActivity = function (streamId, level) { return ""; }

    /**
     * This call back can be overridden by the user to modify the provided streams and to add new streams
     * to be sent to the remote side.
     * 
     * When this method is not overridden, by default this would add a video stream to the existing audio
     * only streams if any. Otherwise this will not change the streams.
     * 
     * @param   array   streams   A array of MediaStream objects to be modified
     * 
     * @param   any   arg   The user defined argument given to modify, or undefined if no argument was provided
     * 
     * @return  array   A array or a Promise that resolves to a array of MediaStream objects with the  
     *  modified streams. If this method returns undefined, still the changes done to streams object 
     *  would be applied. Any modifications to the returned array with respect to provided array will be 
     *  applied. This includes any additions to the array and removals from the array.
     *  User can use WrsUtils.setStreamOwner() to specify the stream owner for re-negotiation.
     *  if the stream is owned by another partyy and is being frowarded by this WrsPeerConnection. Further
     *  User can use WrsUtils.markStreamAsScreenshare() to mark screen share streams. Screen share stream
     *  will be treated differently that video streams (e.g. priority will be given to quality over 
     *  framerate).
     */
    this_.onModifyStreams = function (streams, arg) { return streams; }

    /**
     * Request the SDK to trigger stream modifying call backs and update the call with the new streams.
     * User can override the onModifyStreams callback to provide custom stream modification behavior.
     * 
     * @param   any   arg   User defined argument of any type. This will be given to the onModufyStreams callback
     *  as is, and user may use it for additional control. This argument is optional and can be omited.
     */
    this_.modify = function (arg) { }

    /**
     * This callback can be overridden
     * 
     * @param   string   stream   Stream id
     * @param   WrsStreamEvents   status   The new status
     */
    this_.onStreamStatusChange = function (stream, status) { }

    /**
     * For internal use only. Please do not use this method.
     * Checks if the call is connected directly (i.e. without going through Media Server)
     * 
     * @return True if call is connected directly. False if call is connected through Media Server. Undefined if 
     * this method is called prior to call connected and the coknnectivity path is not yet determined.
     */
    this_.isDirectCall = function () { return undefined; }

    /**
     * Plays the given audio buffer on the call. This will not play/pause voice thus caller must do this by 
     * calling apropriate mute/unmute methods.
     * Audio mixing (refer to WrsConfigurationInterface.isAudioMixerEnabled) must be enabled for this call 
     * to work properly.
     * 
     * @param   ArrayBuffer   buf   A buffer containing audio file to be played. Usually a buffer can be 
     *  generated using XMLHttpRequest.responce (by using XMLHttpRequest to downlaod a URL) or by FileReader 
     *  or a Blob. 
     * 
     * @returns   WrsPlayerInterface   The player instance for monitoring and controling audio play. 
     *  Returns null if the call failed or mixer is not enabled.
     */
    this_.playAudio = function (buf) { return null; }

    /**
     * Inserts a DTMF tone to the call. Can be used to porvide inputs to IVR like systems.
     * Audio mixing (refer to WrsConfigurationInterface.isAudioMixerEnabled) must be enabled for this call 
     * to work properly.
     * 
     * @param   WrsDtmfTones   tone   One of the WrsDtmfTones enums that denotes the tone to be sent.
     * 
     * @returns   boolean   Returns true if successful. otherwise false is returned.
     */
    this_.sendDtmf = function (tone) { return false; }

    /**
     * This is a internal function call and user should not modify/change this code.
     */
    WrsPeerConnectionInternal(this_, channel, configs, intent, statsifs);
}
