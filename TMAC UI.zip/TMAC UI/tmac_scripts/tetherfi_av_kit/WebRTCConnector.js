﻿/*
 * Copyright (c) 2020 Tetherfi Pte. Ltd. (www.tetherfi.com).
 * All rights reserved.
 *
 * This source code is property of Tetherfi Pte. Ltd. product suit. Any use of this code in any 
 * form, for any purpose is strictly prohibited unless prior written permission is obtained from 
 * Tetherfi Pte. Ltd.
 */

// version: '4.1.2.15';

// default webrtc config
let WrcWebRTCConfig = {
    iceServers: [], // webrtc ice server config
    iceTransportPolicy: 'all', // ice transport policy - relay(with turn urls), all (without turn urls)
    sdpSemantics: 'plan-b' // sdp semantice type - plan-b, unified-plan
};

// default webrtc offer options
let WrcOfferOptions = {
    offerToReceiveAudio: true,
    offerToReceiveVideo: true,
    iceRestart: true
};

// default video size
let WrcVideoSize = {
    width: 640,
    height: 480
};

// call types enum
let WrcCallTypes = {
    Audio: 1,
    Video: 2,
    Screenshare: 3,
    CoBrowse: 4,
    OneWayVideo: 5
}

// call types enum
let WrcErrorCodes = {
    Rejected: 1,
    MediaFailed: 2,
    RequestTimeout: 3
}

// AV configuration method
let AVConfiguration = function (callType) {
    try {
        var this_ = this;

        // call base constructor
        WrsConfigurationInterface(this_);

        // if the config is null create an empty project
        if (!webRTCApiConfig) {
            webRTCApiConfig = {};
        }

        this_.getWebRTCConfigurations = function () {
            if (webRTCApiConfig.webRTCConfig) {
                return webRTCApiConfig.webRTCConfig;
            } else {
                return WrcWebRTCConfig;
            }
        };

        this_.getMediaConstraints = function () {
            if (webRTCApiConfig.getMediaConstraints && webRTCApiConfig.getMediaConstraints.type === 'custom') {
                return { custom: true };
            }
            if (webRTCApiConfig.getMediaConstraints && webRTCApiConfig.getMediaConstraints.video) {
                return {
                    audio: true,
                    video: callType !== WrcCallTypes.Audio &&
                        webRTCApiConfig.getMediaConstraints.type !== WrcCallTypes.OneWayVideo ?
                        webRTCApiConfig.getMediaConstraints.video : false
                };
            } else {
                return {
                    audio: true,
                    video: callType !== WrcCallTypes.Audio ? WrcVideoSize : false
                };
            }
        };

        this_.getOfferOptions = function () {
            if (webRTCApiConfig.getOfferOptions) {
                return webRTCApiConfig.getOfferOptions;
            } else {
                return WrcOfferOptions;
            }
        };

        this_.getRecordingOptions = function () {
            if (webRTCApiConfig.getRecordingOptions) {
                return webRTCApiConfig.getRecordingOptions;
            } else {
                return {
                    enabled: false,
                    recordLocal: false
                };
            }
        };

        this_.getConnectionBandwidthUpperLimit = function () {
            if (webRTCApiConfig.getConnectionBandwidthUpperLimit) {
                return webRTCApiConfig.getConnectionBandwidthUpperLimit;
            } else {
                return 2048;
            }
        };

        this_.getAudioTrackBandwidthUpperLimit = function () {
            if (webRTCApiConfig.getAudioTrackBandwidthUpperLimit) {
                return webRTCApiConfig.getAudioTrackBandwidthUpperLimit;
            } else {
                return 32;
            }
        };

        this_.getVideoTrackBandwidthUpperLimit = function () {
            if (webRTCApiConfig.getVideoTrackBandwidthUpperLimit) {
                return webRTCApiConfig.getVideoTrackBandwidthUpperLimit;
            } else {
                return 512;
            }
        };

        this_.isAudioLevelCheckEnabled = function () {
            if (webRTCApiConfig.audioLevelCheck) {
                return webRTCApiConfig.audioLevelCheck.enabled;
            } else {
                return false;
            }
        };

        this_.getAudioLevelThreshold = function () {
            if (webRTCApiConfig.audioLevelCheck) {
                return webRTCApiConfig.audioLevelCheck.threshold;
            } else {
                return 0.11;
            }
        };

        this_.isAudioMixerEnabled = function () {
            if (webRTCApiConfig.isAudioMixerEnabled) {
                return webRTCApiConfig.isAudioMixerEnabled;
            } else {
                return false;
            }
        };

    } catch (ex) {
        console.error('WebRTCConnector.AVConfiguration(): ' + ex);
    }
}

// AV channel method
let AVChannel = function (intid, userId, userName, sessionId, tunnel) {
    try {
        /**
         * PRIVATE VARIABLES
         */

        let this_ = this;

        // private object for WrsChannelInterface Interace method implementation
        let channel_ = new Object();

        // private object for WrsStatsInterface Interace method implementation
        let statsifs_ = new Object();

        // call type ref
        let callType_ = undefined;

        // intent of the channel
        let intent_ = undefined;

        // user id for connection
        let userId_ = userId;

        // id of the current connection
        let id_ = `${intid}_${userId}_${userName}`;

        // session id of the call
        let sessionId_ = sessionId;

        // base channel media for the webrtc call
        let tunnel_ = tunnel;

        // stats interval
        let statsInterval_ = 1000;

        // last voice activity user
        let lastVoiceStreamId_ = '';

        // escalate timeout 
        let escalateTimeout_ = null;

        // screenshare trigger flag
        let screenshareStartTriggered_ = false;

        // screenshare connect trigger flag
        let screenshareConnectTriggered_ = false;

        // screenshare stream ref
        let screenshareStream_ = null;

        // flag to check the screenshare presenter
        let isScreensharePresenter_ = false;

        // av call duration
        let duration_ = undefined;

        // media summary stats
        let mediaSummaryStats_ = {
            duration: 0,
            mos: {
                min: 0,
                max: 0
            },
            packetsLost: '',
            // available send bandwidth
            ASB: {
                min: 0,
                max: 0
            },
            jitter: {
                min: 0,
                max: 0
            },
            // 
            ABS: '',
            ABR: '',
            VBS: '',
            VBR: ''
        };

        // source stream details
        let _localStreamDetails = [];

        // remote stream details
        let _remoteStreamDetails = [];

        // stats collector object
        let statsCollector = null;

        // create a conference mixer
        let mixer = WrsUtils.createConferenceMixer();

        /**
         * PUBLIC VARIABLES
         */

        // peer connection object
        this_._pc = null;

        // remote video container
        this_._remoteVideo = null;

        // local video container
        this_._localVideo = null;

        // define a getter for intent_
        Object.defineProperty(this_, '_intent', {
            get: function () { return intent_; }
        });

        // define a getter for id_
        Object.defineProperty(this_, '_id', {
            get: function () { return id_; }
        });

        // call the internal WrsChannelInterface constructor exposed in the API for channel
        WrsChannelInterface(channel_);

        // this method is used by internal implementation to get the id
        channel_.getId = function () {
            return id_;
        };

        // override the implementation send method
        channel_.send = function (json) {
            // add the intent to the message
            json.intent = intent_;
            // based on tunnel add the sessionid
            if (tunnel_ === 'voice') {
                // add the from to the message
                json.from = id_;
                // append the session id
                json.session = sessionId_;
            } else {
                // append session id
                json.sessionid = sessionId_;
                // send stats for chat tunnel and call intent
                if (intent_ === 'call') {
                    // create a copy of object json
                    let stat = Object.assign({}, json);
                    // add stat source for reference
                    stat._statSource = 's';
                    // send av stats
                    sendAVStats('signalling', {
                        message: stat,
                        type: stat.type,
                    });
                }
            }
            // expose to the instance to override from the initiator
            this_.sendMessage(JSON.stringify(json), json.type, sessionId_);
        };

        // call the internal WrsStatsInterface constructor exposed in the API for stats
        WrsStatsInterface(statsifs_);

        // this method is used by internal implementation to get stats interval
        statsifs_.getStatsInterval = function () {
            return statsInterval_;
        };

        // override the onStats method implemented internally to send the WebRTC stats
        statsifs_.onStats = function (stats) {
            // check if statsCollector is null, then return
            if (!statsCollector) {
                this_.onError('TfiStatsCollector: statsCollector is not available');
                return;
            }
            // call the collector and push the stats
            statsCollector.pushStats(stats);
        };

        /**
         * private methods 
         */

        // to create peer connection
        let createPc = function (param) {
            // clear the existing pc, if in error/dispose state
            if (this_._pc !== null && this_._pc._state() < 0) {
                this_._pc = null;
            }

            if (this_._pc === null) {
                this_.onTrace('Creating peer connection');
                // set the call type
                setCallType(param);
                // [private method] get the peer connection
                this_._pc = new WrsPeerConnection(channel_, new AVConfiguration(callType_), intent_, statsifs_);
            } else {
                this_.onTrace('Peer connection is already created, state=' + this_._pc._state());
                return;
            }

            // pc on connect
            this_._pc.onConnect = function () {
                // trigger on av stats event
                this_.onAVStats('connected');
                // set the duration
                duration_ = typeof moment === 'function' ? moment() : undefined;
                // clear escalate timeout
                clearTimeout(escalateTimeout_);
                // expose to the instance to override from the initiator
                this_.onConnected();
            };

            // pc on disconnect
            this_._pc.onDisconnect = function () {
                // trigger on av stats event
                this_.onAVStats('disconnected');
                // if video available then clear the the src video
                if (this_._localVideo && document.getElementById(this_._localVideo)) {
                    document.getElementById(this_._localVideo).srcObject = null;
                }
                // clear all the remote videos
                if (this_._remoteVideo && typeof this_._remoteVideo.clear === 'function') {
                    this_._remoteVideo.clear();
                }
                // clear escalate timeout
                clearTimeout(escalateTimeout_);
                // send stats
                sendAVStats('mediasummary');
                // expose to the instance to override from the initiator
                this_.onDisconnected();
            };

            // pc on connect
            this_._pc.onReconnecting = function () {
                // trigger on av stats event
                this_.onAVStats('reconnecting');
                // expose to the instance to override from the initiator
                this_.onReconnecting();
            };

            // pc on connect
            this_._pc.onReconnected = function () {
                // trigger on av stats event
                this_.onAVStats('connected');
                // expose to the instance to override from the initiator
                this_.onReconnected();
            };

            // pc on connect
            this_._pc.onIceStateChanged = function (status) {
                // send stats
                sendAVStats('signalling', {
                    message: status,
                    type: 'icestatus'
                });
            };

            // pc on onHoldUnhold
            this_._pc.onHoldUnhold = function (hold) {
                // expose to the instance to override from the initiator
                this_.onHoldUnhold(hold);
            };

            // pc on acquire video [source video]
            this_._pc.onAcquireVideo = function (streams) {
                // add to the source stream object
                _localStreamDetails = {
                    user: userId_,
                    stream: streams
                };
                // for video call only
                if (callType_ === WrcCallTypes.Video) {
                    // add the source video after 2 seconds to make sure the video tag is created
                    setTimeout(function (x) {
                        if (this_._localVideo && document.getElementById(this_._localVideo)) {
                            document.getElementById(this_._localVideo).srcObject = x[0];
                        }
                    }, 2000, streams);
                }
                // expose to the instance to override from the initiator
                this_.onSourceVideoAdded(streams);
            };

            // pc on remote video added
            this_._pc.onAddVideo = function (streams, streamInfo) {
                // process the streams
                streams.forEach(function (stream) {
                    let hasAudio = false;
                    let hasVideo = false;
                    let hasStreamInfo = Object.keys(streamInfo).length !== 0;
                    let userInfo = hasStreamInfo && streamInfo[stream.id].owner.split('_') || [];
                    let owner = hasStreamInfo && streamInfo[stream.id].owner || '';
                    let id = '';
                    let user = '';
                    let info = new Object();

                    // check if unknown
                    if (owner === '') {
                        id = stream.id;
                        user = 'unknown';
                    }
                    // check if customer
                    else if (owner === '0' || owner === 'customer') {
                        id = 0;
                        user = 'customer';
                    }
                    // check if user name
                    else if (userInfo.length > 2) {
                        id = userInfo[1];
                        user = userInfo[2];
                    }
                    // check if user id
                    else if (userInfo.length === 2) {
                        id = userInfo[1];
                        user = userInfo[1];
                    }
                    // check default
                    else {
                        id = userInfo[0];
                        user = userInfo[0];
                    }

                    // set the user id and user to info
                    info = { id: id, user: user, type: '' };

                    //This processing needs to be done only for screenshare streams since there are seperate events for screenshare connect and disconnect
                    if (hasStreamInfo && streamInfo[stream.id].type !== undefined && streamInfo[stream.id].type === 'screenshare') {
                        // screenshareStream_ will already be set if the user is a Presenter, 
                        // only if the user is on the receiving end of the screenshare, then we save the stream here
                        if (!isScreensharePresenter_) {
                            screenshareStream_ = stream;
                        }

                        // set the type
                        info.type = 'screenshare';

                        // set the remote stream info
                        setStreamInfo(stream, id, 'screenshare');

                        //If this is not a one-one screenshare and the screenshare stream is being received after the audio/video call is connected
                        if (!screenshareConnectTriggered_) {
                            screenshareConnectTriggered_ = true;
                            // check if presenter
                            if (isScreensharePresenter_) {
                                onScreenshareStarted();
                            } else {
                                // trigger add video if _remoteVideo assigned
                                if (this_._remoteVideo && typeof this_._remoteVideo.addVideo === 'function') {
                                    this_._remoteVideo.addVideo(stream, info);
                                }

                                // expose to the instance to override from the initiator
                                this_.onScreenshareConnected(stream, info);
                            }
                        }

                        // check tracks
                        stream.getTracks().forEach(function (track) {
                            // on ended event
                            track.onended = function () {
                                // check if the stream is there, then remove the stream info ref
                                if (!removeStreamInfo(stream.id)) {
                                    // if the stream is not there in reference then do not process, return
                                    return;
                                }
                                // remove the video from window
                                if (this_._remoteVideo && typeof this_._remoteVideo.removeVideo === 'function') {
                                    this_._remoteVideo.removeVideo(stream);
                                }
                                // expose to the instance to override from the initiator
                                this_.onRemoteStreamEnded(stream, { id: id, user: user, type: 'screenshare' });
                            };
                        });
                        return;
                    } else {
                        // check tracks
                        stream.getTracks().forEach(function (track) {
                            if (track.kind == 'audio') {
                                hasAudio = true;
                            } else if (track.kind == 'video') {
                                hasVideo = true;
                            }
                            // on ended event
                            track.onended = function () {
                                // check if the stream is there, then remove the stream info ref
                                if (!removeStreamInfo(stream.id)) {
                                    // if the stream is not there in reference then do not process, return
                                    return;
                                }
                                // remove the video from window
                                if (this_._remoteVideo && typeof this_._remoteVideo.removeVideo === 'function') {
                                    this_._remoteVideo.removeVideo(stream);
                                }
                                // expose to the instance to override from the initiator
                                this_.onRemoteStreamEnded(stream, { id: id, user: user, type: type });
                            };
                        });

                        // get the type and set to info
                        let type = info.type = (hasVideo ? 'video' : 'audio');

                        // NOTE: to prevent double 'added' events for streams that have audio and video tracks
                        if (getStreamRef(stream.id).length > 0) {
                            return;
                        }

                        // set the remote stream info
                        setStreamInfo(stream, id, type);

                        // trigger add video if _remoteVideo assigned
                        if (this_._remoteVideo && typeof this_._remoteVideo.addVideo === 'function') {
                            this_._remoteVideo.addVideo(stream, info);
                        }

                        // expose to the instance to override from the initiator
                        this_.onRemoteVideoAdded(stream, info);
                    }
                });
            };

            // peer connection on call request
            this_._pc.onCallRequest = function () {
                // expose to the instance to override from the initiator
                this_.onCallRequest();
            };

            // peer connection on stream status change
            this_._pc.onStreamStatusChange = function (stream, status) {
                // expose to the instance to override from the initiator
                this_.onStreamStatusChanged(stream, status);
            };

            // peer connection onModifyStreams
            this_._pc.onModifyStreams = function (streams, arg) {
                // check if the arg is a function callback
                if (arg != null && typeof arg === 'function') {
                    return arg(streams);
                }
                // check if the screenshare start is triggerend
                else if (screenshareStartTriggered_) {
                    let getDisplayMediaFn = (navigator.mediaDevices.getDisplayMedia !== undefined) ?
                        navigator.mediaDevices.getDisplayMedia.bind(navigator.mediaDevices) :
                        (navigator.getDisplayMedia !== undefined) ? navigator.getDisplayMedia.bind(navigator) : undefined;

                    // check if the dispaly media is a function
                    if (getDisplayMediaFn !== undefined) {
                        return Promise.resolve(getDisplayMediaFn({ video: { frameRate: 5 }, audio: false }).then(screenshareStream => {
                            // set the screenshare triggered flag to false
                            screenshareStartTriggered_ = false;
                            screenshareStream = WrsUtils.markStreamAsScreenshare(screenshareStream);
                            screenshareStream.oninactive = function () {
                                // check if the screenshare is connected
                                if (screenshareConnectTriggered_) {
                                    //send endav to inform MSS screenshare has ended
                                    send({ type: 'endav', reason: 'presenter ended screenshare', param: 'screenshare' });
                                    // expose screenshare stopped event
                                    this_.onScreenshareEnded();
                                    // reset screenshare
                                    screenshareReset();
                                }
                            }
                            // set the screenshare reference
                            screenshareStream_ = screenshareStream;
                            // trigger screenshare started event
                            setTimeout(function () {
                                screenshareConnectTriggered_ = true;
                                this_.onScreenshareStarted();
                            }, 100);
                            // push the screenshare stream to streams and return
                            streams.push(screenshareStream)
                            return streams;
                        }).catch(error => {
                            // set the screenshare triggered flag to false
                            screenshareStartTriggered_ = false;
                            // at this point, MSS still thinks that a screenshare is going on in the a/v call, so we need to inform MSS that there is no screenshare happening                                //send endav to inform MSS screenshare has ended
                            send({ type: 'endav', reason: 'Screenshare Cancelled ([' + error.code + '] ' + error.message + ' )', param: 'screenshare' });
                            this_.onError(error.message, error.code);
                            return Promise.reject({ message: '[' + error.name + '] ' + error.message });
                        }));
                    } else {
                        // set the screenshare triggered flag to false
                        screenshareStartTriggered_ = false;
                        // at this point, MSS still thinks that a screenshare is going on in the a/v call, so we need to inform MSS that there is no screenshare happening                                //send endav to inform MSS screenshare has ended
                        send({ type: 'endav', reason: 'Browser does not support getDisplayMedia', param: 'screenshare' });
                        this_.onError('systemerror: Browser does not support getDisplayMedia');
                        return Promise.reject({ message: 'Browser does not support getDisplayMedia' });
                    }
                }
                // expose to the instance to override from the initiator
                return this_.onModifyStreams(streams, arg);
            };

            // peer on acquire user media
            this_._pc.onAcquireUserMedia = function (mediaConstraints) {
                // expose to the instance to override from the initiator
                return this_.onAcquireUserMedia(mediaConstraints);
            };

            // peer connection onVoiceActivity
            this_._pc.onVoiceActivity = function (streamId, level) {
                if (streamId === '' && lastVoiceStreamId_ !== '' || level < 40) {
                    lastVoiceStreamId_ = '';
                    // expose to the instance to override from the initiator
                    this_.onVoiceActivity('', 0);
                }
                //expose to the instance to override from the initiator
                else if (lastVoiceStreamId_ !== streamId) {
                    lastVoiceStreamId_ = streamId;
                    // expose to the instance to override from the initiator
                    this_.onVoiceActivity(streamId, level);
                }
            };

            // peer connection on trace
            this_._pc.onTrace = function (log) {
                // expose to the instance to override from the initiator
                this_.onTrace(log);
            };

            // peer connection on error
            this_._pc.onError = function (code, msg) {
                // clear escalate timeout on error
                clearTimeout(escalateTimeout_);
                // send av stats for error having codes
                if (code) {
                    // save stats in db
                    sendAVStats('signalling', {
                        message: {
                            error: msg,
                            errorCode: code
                        },
                        type: 'error'
                    });
                }
                // expose to the instance to override from the initiator
                this_.onError(msg, code);
            };
        };

        // to send message to Wrs channel
        let send = function (message) {
            channel_.send(message);
        };

        // to set call types
        let setCallType = function (callType) {
            callType_ = callType;
            intent_ = callType_ === 4 ? 'cobrowse' : 'call';
        };

        // screenshare reset
        let screenshareReset = function () {
            screenshareStartTriggered_ = false;
            screenshareConnectTriggered_ = false;
            isScreensharePresenter_ = false;
            screenshareStream_ = null;
        }

        // to set stream info
        let setStreamInfo = function (stream, user, type) {
            // add the stream info reference
            _remoteStreamDetails.push({ user: user, type: type, stream: stream });
        };

        // get stream info ref
        let getStreamRef = function (streamId) {
            // check if avaialable
            return _remoteStreamDetails.filter(function (r) {
                return r.stream.id === streamId;
            });
        };

        // to remove stream info
        let removeStreamInfo = function (streamId) {
            // if reference of the stream is not available return false
            if (_remoteStreamDetails.filter(function (r) { return r.stream.id === streamId; }).length === 0) {
                return false;
            }
            // remove the stream from reference
            _remoteStreamDetails = _remoteStreamDetails.filter(function (r) {
                return r.stream.id !== streamId;
            });
            // return true
            return true;
        };

        // to send AV stats
        let sendAVStats = function (type, data) {
            let sendValue = '';
            //  VP: Jan 14, '21: Adding other data for additional info
            let otherData = '';

            if (type === 'config') {
                //  If media not ready, 0 else, 1
                if (data.mediaReady)
                    sendValue += '1' + ',';
                else
                    sendValue += '0' + ',';
                webRTCApiConfig.webRTCConfig.iceServers.forEach(function (item) {
                    sendValue += item.urls + '|';
                });
                sendValue = sendValue.slice(0, sendValue.length - 1);
            } else if (type === 'signalling') {
                let messageType = data.type;
                sendValue += messageType + ':';
                if (messageType === 'requestav') {
                    //  VP: Jan 14, '21: Adding other data for additional info
                    otherData = data.message.param;
                    // send data as 'requestav:0/1' (1-audio, 2-video, 3-screenshare, 4-cobrowse call by customer)
                    switch (data.message.param) {
                        case 'audio':
                            sendValue += '1' + ':' + data.message._statSource;
                            break;
                        case 'video':
                            sendValue += '2' + ':' + data.message._statSource;
                            break;
                        case 'screenshare':
                            sendValue += '3' + ':' + data.message._statSource;
                            break;
                        case 'cobrowse':
                            sendValue += '4' + ':' + data.message._statSource;
                            break;
                    }
                    // trigger on av stats event
                    this_.onAVStats(data.message.param + '-' + (data.message._statSource === 's' ? 'requested' : 'received'));
                } else if (messageType === 'ackav') {
                    //  VP: Jan 14, '21: Adding other data for additional info
                    otherData = data.message.originalType;
                    sendValue += data.message.originalType + ':' + data.message._statSource;
                    switch (data.message.originalType) {
                        case 'requestav':
                            // trigger on av stats event
                            this_.onAVStats(data.message._statSource === 's' ? 'incoming' : 'ringing');
                            break;
                    }
                } else if (messageType === 'ack-requestav') {
                    sendValue = 'ackav:requestav:' + data.message._statSource;
                    // trigger on av stats event
                    this_.onAVStats(data.message._statSource === 's' ? 'incoming' : 'ringing');
                } else if (messageType === 'avtstatus') {
                    //  VP: Jan 14, '21: Adding other data for additional info
                    otherData = data.message.param;
                    // send data as 'avtstatus:0/1' (0-rejected, 1-acepted by customer)
                    if (data.message.param === false || data.message.param === 'false') {
                        sendValue += '0' + ':' + data.message._statSource;
                        // trigger on av stats event
                        this_.onAVStats(data.message.param + '-' + (data.message._statSource === 's' ? 'rejecting' : 'rejected'));
                    } else {
                        sendValue += '1' + ':' + data.message._statSource;
                        // trigger on av stats event
                        this_.onAVStats(data.message.param + '-' + (data.message._statSource === 's' ? 'accepting' : 'accepted'));
                    }
                } else if (messageType === 'icestatus') {
                    //  VP: Jan 14, '21: Adding other data for additional info
                    otherData = data.message;
                    //  new: 1, checking: 2, connected: 3, completed: 4, failed: 5, disconnect: 6, closed: 7
                    switch (data.message) {
                        case 'new':
                            sendValue += '1';
                            break;
                        case 'checking':
                            sendValue += '2';
                            break;
                        case 'connected':
                            sendValue += '3';
                            break;
                        case 'completed':
                            sendValue += '4';
                            break;
                        case 'failed':
                            sendValue += '5';
                            break;
                        case 'disconnect':
                            sendValue += '6';
                            break;
                        case 'closed':
                            sendValue += '7';
                            break;
                    }
                    // trigger on av stats event
                    this_.onAVStats(data.message);
                } else if (messageType === 'error') {
                    sendValue += data.message.errorCode;
                    // trigger on av stats event
                    this_.onAVStats('error');
                } else {
                    if (messageType === 'offer') {
                        //  VP: Jan 14, '21: Adding other data for additional info
                        otherData = data.message.intent;
                        // trigger on av stats event
                        this_.onAVStats(data.message._statSource === 's' ? 'offering' : 'offer-received');
                    } else if (messageType === 'answer') {
                        //  VP: Jan 14, '21: Adding other data for additional info
                        otherData = data.message.intent;
                        // trigger on av stats event
                        this_.onAVStats(data.message._statSource === 's' ? 'answering' : 'answer-received');
                    } else if (messageType === 'candidates') {
                        // trigger on av stats event
                        // this_.onAVStats('media connecting');
                        this_.onAVStats('media connecting');
                    } else if (messageType === 'candidate') {
                        try {
                            //  VP: Jan 14, '21: Adding other data for additional info
                            otherData = data.message.candidate.replace(/candidate:[0-9]+ [0-9] /, "").replace(/ generation.*/, "");
                        }
                        catch (e) { }
                    } else if (messageType === 'endav') {
                        //  VP: Jan 14, '21: Adding other data for additional info
                        otherData = data.message.reason;
                    }
                    // webrtc messages, check if statSource available, ignore the rest
                    if (data.message._statSource) {
                        sendValue += data.message._statSource;
                    }
                }
            } else if (type === 'mediasummary') {
                // calculate av call duration
                let duration = duration_ !== undefined ? moment().diff(duration_) / 1000 : 0;
                sendValue = duration;
                sendValue += ',' + mediaSummaryStats_.mos.min + '|' + mediaSummaryStats_.mos.max;
                sendValue += ',' + mediaSummaryStats_.audioPacketsLost;
                sendValue += ',' + mediaSummaryStats_.videoPacketsLost;
                sendValue += ',' + mediaSummaryStats_.ASB.min + '|' + mediaSummaryStats_.ASB.max;
                sendValue += ',' + mediaSummaryStats_.jitter.min + '|' + mediaSummaryStats_.jitter.max;
                sendValue += ',' + mediaSummaryStats_.audioBytesSent;
                sendValue += ',' + mediaSummaryStats_.audioBytesReceived;
                sendValue += ',' + mediaSummaryStats_.videoBytesSent;
                sendValue += ',' + mediaSummaryStats_.videoBytesReceived;
            }
            // send av stats
            this_.sendAVStats([{
                Data: sendValue,
                DataType: type,
                DateTime: new Date().toISOString(),
                SessionId: sessionId_,
                Source: 'agent',
                OtherData: JSON.stringify({
                    0: otherData
                })
            }]);
        };

        // to set the stats collector
        let setStatsCollector = function () {
            try {
                // create an instance of TfiStatsCollector
                statsCollector = new TfiWebRTCStats.TfiStatsCollector(null, null);

                // register to the stats
                statsCollector.registerGlobals(false);

                // set the collector stats tag
                statsCollector.setTagsProviderFn(function () {
                    // create a map
                    let map = new Map();
                    // set the map variables
                    map.set('Location', 'agent');
                    map.set('AgentId', userId_);
                    map.set('SessionId', Date);
                    return Promise.resolve(map);
                });

                // set the Transport provider
                statsCollector.setTransportFn(sendStats);

            } catch (error) {
                this_.onError('setStatsCollector: ' + error);
            }
        };

        // internal sendStats method
        let sendStats = function (result) {
            //check if stats available
            if (!result || !result.stats) {
                this_.onError('TfiStatsCollector: stats is not available');
                return;
            }
            //get the mos value form stats
            let mos = result.stats.audio.local.mos;
            // calculate media summary
            mediaSummaryStats_.duration = 0;
            mediaSummaryStats_.audioPacketsLost = result.stats.audio.local.packetsLost;
            mediaSummaryStats_.videoPacketsLost = result.stats.video.local.packetsLost;
            let asb = result.stats.network.availableSendBandwidth;
            if (mediaSummaryStats_.ASB.min == 0 || mediaSummaryStats_.ASB.min > asb) {
                mediaSummaryStats_.ASB.min = asb;
            }
            if (mediaSummaryStats_.ASB.max == 0 || mediaSummaryStats_.ASB.max < asb) {
                mediaSummaryStats_.ASB.max = asb;
            }
            if (mediaSummaryStats_.mos.min == 0 || mediaSummaryStats_.mos.min > mos) {
                mediaSummaryStats_.mos.min = mos;
            }
            if (mediaSummaryStats_.mos.max == 0 || mediaSummaryStats_.mos.max < mos) {
                mediaSummaryStats_.mos.max = mos;
            }
            let jitter = result.stats.audio.local.jitter;
            if (mediaSummaryStats_.jitter.min == 0 || mediaSummaryStats_.jitter.min > jitter) {
                mediaSummaryStats_.jitter.min = jitter;
            }
            if (mediaSummaryStats_.jitter.max == 0 || mediaSummaryStats_.jitter.max < jitter) {
                mediaSummaryStats_.jitter.max = jitter;
            }
            mediaSummaryStats_.audioBytesSent = result.stats.audio.local.bytesSent;
            mediaSummaryStats_.audioBytesReceived = result.stats.audio.remote.bytesReceived;
            mediaSummaryStats_.videoBytesSent = result.stats.video.local.bytesSent;
            mediaSummaryStats_.videoBytesReceived = result.stats.video.remote.bytesReceived;
            // expose to the instance to override from the initiator and get the result
            let res = this_.onCollectorStats(result);
            // if successfully send return code 200
            if (res) {
                return Promise.resolve({ code: 200, status: 'OK' });
            }
            // else return code 500
            else {
                return Promise.reject();
            }
        };

        // set the stats collector
        setStatsCollector();

        /**
         * FUNCTIONS
         */

        // define a send method for the cosumer to transport webrtc messages
        this_.sendMessage = function (msg, type, sessionId) { };

        // on message from remote
        this_.onMessage = function (msg) {
            // parse the message
            let message = JSON.parse(msg);

            // check if this is a 'eventav' with 'call-ended' event then check if stats enabled
            if (message.type === 'eventav' && message.event === 'call-ended' || message.type === 'endav') {
                // check if statsCollector is null, then return
                if (!statsCollector) {
                    this_.onError('TfiStatsCollector: statsCollector is not available');
                    return;
                }
                // clean up
                statsCollector.cleanUp();
            }

            if (message.type === 'requestav') {
                // request call type
                let reqCallType = WrcGetCallCode(message.param);

                // create the peer connection
                createPc(reqCallType);

                // ReviewCodeLine - to change to below when change is done in call-sdk side
                // let ack = { type: 'ackav', originalType: 'requestav', callId: jsonMessage.callId, originalSequence: '' };

                // send ack
                send({ type: 'ack-requestav', owner: userId_, originalType: 'requestav', callId: message.callId ? message.callId : '', originalSequence: '' });

                // check for the call type
                if (WrcCallTypes.Audio === reqCallType || WrcCallTypes.Video === reqCallType) {
                    // check the user media
                    WrcCheckUserMedia(WrcGetCallMode(reqCallType), function () {
                        // trigger on incoming event
                        this_.onIncoming(WrcGetCallMode(reqCallType), function (accept) {
                            // send stats
                            sendAVStats('config', {
                                mediaReady: true
                            });
                            // user accept
                            if (accept) {
                                send({ type: 'avtstatus', owner: userId_, param: WrcGetCallMode(reqCallType), source: 'escalate' });
                            }
                            // user reject
                            else {
                                send({ type: 'avtstatus', owner: userId_, param: 'false', source: 'escalate', reason: 'reject' });
                            }
                        });
                    }, function (err) {
                        //send stats
                        sendAVStats('config', {
                            mediaReady: false
                        });
                        // send avt status, reject
                        send({ type: 'avtstatus', owner: userId_, param: 'false', source: 'escalate', reason: 'no media' });
                        // trigger on fail
                        this_.onFail(WrcErrorCodes.MediaFailed, err);
                    });
                } else {
                    // trigger on incoming event for non audio-video
                    this_.onIncoming(WrcGetCallMode(reqCallType), function (accept) {
                        // user accept
                        if (accept) {
                            send({ type: 'avtstatus', owner: userId_, param: WrcGetCallMode(reqCallType), source: 'escalate' });
                        }
                        // user reject
                        else {
                            send({ type: 'avtstatus', owner: userId_, param: 'false', source: 'escalate', reason: 'reject' });
                        }
                    });
                }
            } else if (message.type === 'cancelav') {
                // trigger on fail
                this_.onFail(WrcErrorCodes.RequestTimeout, 'request timeout');
            } else if (message.type === 'avtstatus') {
                // get the param
                let param = message.param;
                // send ack
                send({ type: 'ackav', owner: userId_, originalType: 'avtstatus', callId: message.callId ? message.callId : '', originalSequence: '' });
                // clear escalation timeout
                clearTimeout(escalateTimeout_);
                // check if the remote user rejected
                if (param === 'false' || param === false) {
                    // trigger on fail
                    this_.onFail(WrcErrorCodes.Rejected, 'user rejected');
                }
                // check for legacy mode, if not send offer
                else if (message.hasOwnProperty('version') && message.version === 2 || message.hasOwnProperty('source') && message.source === 'escalate') {
                    // send offer
                    this_.call();
                }
            } else if (message.type === 'endav') {
                // get the param
                let param = message.param;
                if (param === 'screenshare') {
                    // reset screenshare
                    screenshareReset();
                    // expose to the instance to override from the initiator
                    this_.onScreenshareDisconnected();
                    // screenshare ended
                    return;
                } else {
                    // send stat
                    sendAVStats('mediasummary');
                    // cstop screenshare if any
                    this_.stopScreenshare();
                    // trigger on end event
                    this_.onEnd(message.reason);
                    // close the peer connection
                    this_.close();
                }
            } else if (message.type === 'dropav') {
                // trigger on user left event
                this_.onUserLeft(message.userId, message.reason);
            } else if (message.type === 'requestcb') {
                // request call type
                let reqCallType = WrcGetCallCode(message.param);
                // create the peer connection
                createPc(reqCallType);
                // send through channel
                send({ type: 'cbtstatus', owner: userId_, param: WrcGetCallMode(reqCallType), source: 'escalate' });
            } else if (message.type === 'endcb') {
                console.log(message);
                this_.onCobrowseEnd();
            } else if (message.type === 'avcontrol') {
                this_.onTrace('Unhandled [avcontrol]');
            }

            // call implementation onMessage
            channel_.onMessage(message);

            // send stats
            if (intent_ === 'call') {
                message._statSource = 'r';
                sendAVStats('signalling', {
                    message: message,
                    type: message.type
                });
            }
        };

        // to start av call
        this_.call = function () {
            if (this_._pc) {
                this_._pc.call();
            } else {
                this_.onError('call: WrsPeerConnection is not available');
            }
        };

        // to join av call
        this_.join = function (param, mode) {
            // create peer connection
            createPc(param);
            if (this_._pc) {
                this_._pc.join(mode);
            } else {
                this_.onError('join: WrsPeerConnection is not available');
            }
        };

        // to mute the call
        this_.mute = function (audio, video) {
            if (this_._pc) {
                this_._pc.mute(audio, video);
            } else {
                this_.onError('mute: WrsPeerConnection is not available');
            }
        };

        // to un mute the call
        this_.unMute = function (audio, video) {
            if (this_._pc) {
                this_._pc.unMute(audio, video);
            } else {
                this_.onError('unMute: WrsPeerConnection is not available');
            }
        };

        // to hold the call
        this_.hold = function () {
            if (this_._pc) {
                this_._pc.hold();
            } else {
                this_.onError('hold: WrsPeerConnection is not available');
            }
        };

        // to un hold the call
        this_.unHold = function () {
            if (this_._pc) {
                this_._pc.unHold();
            } else {
                this_.onError('unHold: WrsPeerConnection is not available');
            }
        };

        // to check whether the call is alive
        this_.isConnected = function () {
            if (this_._pc) {
                return this_._pc.isConnected();
            } else {
                this_.onError('isConnected: WrsPeerConnection is not available');
            }
            return false;
        };

        // to close the call
        this_.close = function () {
            if (this_._pc) {
                this_._pc.close();
                // check if statsCollector is null, then return
                if (!statsCollector) {
                    this_.onError('TfiStatsCollector: statsCollector is not available');
                    return;
                }
                // clean up
                statsCollector.cleanUp();
                // cstop screenshare if any
                this_.stopScreenshare();
                // if video available then clear the the src video
                if (this_._localVideo && document.getElementById(this_._localVideo)) {
                    document.getElementById(this_._localVideo).srcObject = null;
                }
                // clear all the remote videos
                if (this_._remoteVideo && typeof this_._remoteVideo.clear === 'function') {
                    this_._remoteVideo.clear();
                }
                // send stats
                sendAVStats('mediasummary');
            } else {
                this_.onError('close: WrsPeerConnection is not available');
            }
        };

        // to modify the call
        this_.modify = function (arg) {
            if (this_._pc) {
                // expose to the instance to override from the initiator
                this_._pc.modify(arg);
            } else {
                this_.onError('modify: WrsPeerConnection is not available');
            }
        };

        // to add conference multiple parties
        this_.addConference = function (pc) {
            // add the source pc then add the conference pc
            mixer.add(this_._pc);
            // add the conference pc to the mixer
            mixer.add(pc);
        };

        // to remove the pc from the mixer
        this_.removeConference = function (pc) {
            // add the conference pc to the mixer
            mixer.remove(pc);
        };

        // to start a call
        this_.startCall = function (param, option, callback) {
            // create the peer connection
            createPc(param);
            // create a request message
            let msg = {
                type: 'requestav',
                param: WrcGetCallMode(callType_),
                owner: userId_
            };
            // Add an option. Currently adding co-browse option. Either link or self (customer's current web page)
            if (param === WrcCallTypes.CoBrowse && option && option.length > 0) {
                msg.coBrowseOption = option;
            }
            // check the user media
            WrcCheckUserMedia(param, function () {
                // send the message
                send(msg);
                // send stats
                sendAVStats('config', {
                    mediaReady: true,
                });
                // check for timeout
                escalateTimeout_ = setTimeout(function (d) {
                    let msg = {
                        type: 'avcontrol',
                        source: '',
                        owner: userId_,
                        value: 'cancelav',
                        reason: `Escalate ${d.param} request timed out`
                    };
                    // send to channel
                    send(msg);
                    // timeout callback
                    callback && typeof callback.onTimeout === 'function' ? callback.onTimeout(WrcGetCallMode(param)) : null;
                }, 30000, msg);
                // success callback
                callback && typeof callback.onSuccess === 'function' ? callback.onSuccess(WrcGetCallMode(param)) : null;
            }, function (err) {
                // send stats
                sendAVStats('config', {
                    mediaReady: false
                });
                // error callback
                callback && typeof callback.onError === 'function' ? callback.onError(WrcGetCallMode(param), err) : null;
            });
        };

        // to end a call
        this_.endCall = function (param, reason) {
            // send the signal
            send({ type: 'endav', reason: (reason ? reason : 'hungup'), param: WrcGetCallMode(param), callId: '' });
            // close the peer connection
            this_.close();
        };

        // to start screenshare
        this_.startScreenshare = function () {
            // check if the screenshare is already triggered 
            if (screenshareStartTriggered_) {
                //This means user is already on a screenshare
                this_.onError('startScreenshare: screenshare start has already been triggered');
                return;
            }
            // set the screenshare active flag to true
            screenshareStartTriggered_ = true;
            // set the presenter flag
            isScreensharePresenter_ = true;
            // call av channel to modify existiting video/audio stream to add screen share stream onModifyStream event
            this_.modify();
        };

        // to stop screenshare
        this_.stopScreenshare = function () {
            // check if the screenshare stream is present
            if (screenshareStream_ !== null && screenshareStream_.id !== null) {
                // modify the stream
                this_.modify(function (streams) {
                    // get the screenshare stream id
                    let ssid = screenshareStream_.id;
                    // remove screen share stream
                    let i = 0;
                    while (i < streams.length) {
                        if (streams[i].id == ssid) {
                            streams.splice(i, 1);
                        } else {
                            i++;
                        }
                    }
                    // return the modified stream
                    return streams;
                });
            } else {
                // there is no screenshare going on, return
                return;
            }

            // end the screenshare stream by stopping all the video tracks
            if (screenshareStream_ !== null && screenshareStream_.getVideoTracks !== undefined && screenshareStream_.getVideoTracks()[0] !== undefined) {
                screenshareStream_.getVideoTracks()[0].stop();
            }

            // if this user is not the presenter, could be a conferenced user or the other user in a one-one call
            // if the user is a presenter the screenshare streams video track onended event will be called
            if (isScreensharePresenter_ === false) {
                // trigger on ende event
                this_.onScreenshareEnded();
                // reset the flags and details
                screenshareReset();
            }
        };

        // to drop a call
        this_.dropCall = function (reason) {
            // send the signal
            send({ type: 'dropav', userId: userId_, reason: (reason ? reason : 'hungup'), callId: '' });
            // close the peer connection
            this_.close();
        };

        // to start direct call without signalling
        this_.startDirect = function (param, direction = 'out') {
            // create peer connection
            createPc(param);
            //  MS: Sep 1, '20: For in direction, create pc and ignore
            if (direction === 'in') {
                return;
            }
            // for voice tunnel direct call send offer
            if (tunnel_ === 'voice') {
                this_.call();
            }
            // else send avtstatus
            else {
                send({ type: 'avtstatus', owner: userId_, param: WrcGetCallMode(param), source: 'direct' });
            }
        };

        // to start a transfer call without signalling
        this_.startTransfer = function (param) {
            // create peer connection
            createPc(param);
            send({ type: 'avtstatus', owner: userId_, param: WrcGetCallMode(param), source: 'transfer' });
        };

        // this method is used to get session id
        this_.getSessionId = function () {
            return sessionId_;
        };

        // to get the stream info
        this_.getStreamInfo = function () {
            let object = {
                local: null,
                remote: null
            };
            if (_localStreamDetails) {
                object.local = { ..._localStreamDetails };
            }
            if (_remoteStreamDetails.length > 0) {
                object.remote = [..._remoteStreamDetails];
            }
            return object;
        };

        // to check if screenshare stream is there
        this_.hasScreenshareStream = function () {
            if (screenshareStream_ !== null && screenshareStream_.id !== undefined && !isScreensharePresenter_) {
                return true;
            }
            return false;
        };

        // to change the call type
        this_.changeCallMode = function (param) {
            // check if param is provided
            if (!param) {
                return;
            }
            // set the call type
            callType_ = WrcCallTypes[param] === 'undefined' ? WrcCallTypes.Audio : WrcCallTypes[param];
        };

        // to get the call type
        this_.getCallType = function () {
            return callType_;
        };

        // to get call type mode
        this_.getCallMode = function () {
            return WrcGetCallMode(callType_);
        };

        /**
         * Events
         */

        // on connected
        this_.onConnected = function () { };

        // on disconnected
        this_.onDisconnected = function () { };

        // on reconnecting
        this_.onReconnecting = function () { };

        // on reconnected
        this_.onReconnected = function () { };

        // on hold unhold
        this_.onHoldUnhold = function (hold) {
            this_.onTrace('Unhandled: onCallRequest - ' + hold);
        };

        // on source stream added
        this_.onSourceVideoAdded = function (streams) {
            this_.onTrace('Unhandled: onSourceVideoAdded');
        };

        // on remote stream added
        this_.onRemoteVideoAdded = function (stream, streamInfo) {
            this_.onTrace('Unhandled: onRemoteVideoAdded');
        };

        // on screenshare stream disconnected
        this_.onScreenshareDisconnected = function () {
            this_.onTrace('Unhandled: onScreenshareDisconnected');
        };

        // on call request
        this_.onCallRequest = function () {
            this_.onTrace('Unhandled: onCallRequest');
        };

        // on stream status changed
        this_.onStreamStatusChanged = function (stream, status) {
            this_.onTrace('Unhandled: onStreamStatusChanged - ' + status);
        };

        // on modify streams
        this_.onModifyStreams = function (streams, arg) {
            this_.onTrace('Unhandled: onModifyStreams');
        };

        // on acquire user media
        this_.onAcquireUserMedia = function (mediaConstraints) {
            this_.onTrace('Unhandled: onAcquireUserMedia');
        };

        // on voice activity
        this_.onVoiceActivity = function (streamId, level) {
            this_.onTrace('Unhandled: onVoiceActivity - ' + streamId + ',' + level);
        };
        // on remote stream ended
        this_.onRemoteStreamEnded = function (stream, streamInfo) {
            this_.onTrace('Unhandled: onRemoteStreamEnded');
        };

        // on screenshare stream connected
        this_.onScreenshareConnected = function (stream, streamInfo) {
            this_.onTrace('Unhandled: onScreenshareConnected');
        };

        // on user screnshare start
        this_.onScreenshareStarted = function () {
            this_.onTrace('Unhandled: onScreenshareStarted');
        };

        // on user screenshare end
        this_.onScreenshareEnded = function () {
            this_.onTrace('Unhandled: onScreenshareEnded');
        };

        // on collector stats
        this_.onCollectorStats = function (result) {
            this_.onTrace('Unhandled: onCollectorStats');
            return true;
        };

        // on incoming call
        this_.onIncoming = function (param, response) {
            this_.onTrace('Unhandled: onIncoming - ' + param);
        };

        // on call fail
        this_.onFail = function (code, error) {
            this_.onTrace('Unhandled: onFail - ' + code);
        };

        // on call ended
        this_.onEnd = function (reason) {
            this_.onTrace('Unhandled: onEnd - ' + reason);
        };

        // on user left
        this_.onUserLeft = function (userId, reason) {
            this_.onTrace('Unhandled: onUserLeft - ' + userId + ", " + reason);
        };

        // on co-browse ended
        this_.onCobrowseEnd = function () {
            this_.onTrace('Unhandled: onCobrowseEnd');
        };

        // on av stats
        this_.onAVStats = function (state) {
            this_.onTrace('Unhandled: onAVStats - ' + state);
        };

        // on av stats
        this_.sendAVStats = function (stats) {
            this_.onTrace('Unhandled: sendAVStats - ' + JSON.stringify(stats));
        };

        // on trace
        this_.onTrace = function (log) {
            console.debug('AVChannel: ' + log);
        };

        // on error
        this_.onError = function (msg, code) {
            this_.onTrace('Unhandled: onError :: ' + code + '|' + msg);
        };

        // to play Audio
        this_.playAudio = function (tone) {
            if (this_._pc) {
                return this_._pc.playAudio(tone);
            } else {
                this_.onError('playAudio: WrsPeerConnection is not available');
            }
            return null;
        };

        // to send DTMF
        this_.sendDtmf = function (tone) {
            if (this_._pc) {
                return this_._pc.sendDtmf(tone);
            } else {
                this_.onError('sendDtmf: WrsPeerConnection is not available');
            }
            return false;
        };
    } catch (ex) {
        console.error('WebRTCConnector.AVChannel(): ' + ex);
    }
};

// to get the call mode by type
let WrcGetCallMode = function (callType) {
    var callMode = '';
    switch (callType) {
        case WrcCallTypes.Audio:
            callMode = 'audio';
            break;
        case WrcCallTypes.Video:
            callMode = 'video';
            break;
        case WrcCallTypes.OneWayVideo:
            callMode = 'onewayvideo';
            break;
        case WrcCallTypes.Screenshare:
            callMode = 'screenshare';
            break;
        case WrcCallTypes.CoBrowse:
            callMode = 'cobrowse';
            break;
    }
    return callMode;
}

// to get call type mode
let WrcGetCallCode = function (code) {
    var callCode = '';
    switch (code) {
        case 'audio':
            callCode = WrcCallTypes.Audio;
            break;
        case 'video':
            callCode = WrcCallTypes.Video;
            break;
        case 'onewayvideo':
            callCode = WrcCallTypes.OneWayVideo;
            break;
        case 'screenshare':
            callCode = WrcCallTypes.Screenshare;
            break;
        case 'cobrowse':
            callCode = WrcCallTypes.CoBrowse;
            break;
    }
    return callCode;
}

// to check the user media
let WrcCheckUserMedia = function (type, successCallback, errorCallback) {
    try {
        WrsUtils.getUserMedia({ audio: true, video: type === 'video' })
            .then(function (stream) {
                stream.getTracks().forEach(function (track) {
                    track.stop();
                });
                typeof successCallback === 'function' ? successCallback() : null;
            }).catch(function (err) {
                typeof errorCallback === 'function' ? errorCallback(err) : null;
            });
    } catch (err) {
        console.error(err);
    }
};

// freeze constants so that there may not be any accidental changes to them by users or api developers
Object.freeze(WrcWebRTCConfig);
Object.freeze(WrcOfferOptions);
Object.freeze(WrcVideoSize);
Object.freeze(WrcCallTypes);
Object.freeze(WrcErrorCodes);