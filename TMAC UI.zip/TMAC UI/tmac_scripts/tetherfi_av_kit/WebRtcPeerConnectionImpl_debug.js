/*
 * Copyright (c) 2018 Tetherfi Pte. Ltd. (www.tetherfi.com).
 * All rights reserved.
 *
 * This source code is property of Tetherfi Pte. Ltd. product suit. Any use of this code in any 
 * form, for any purpose is strictly prohibited unless prior written permission is obtained from 
 * Tetherfi Pte. Ltd.
 */

/* include adapter.js */
/* include RecordRTC.js */
/* include WebRtcPeerConnectionApi.js */


/**
 * This is a private variable and user should not access it
 */
var WrsObjectId__ = 1000;
var WrsBuildTime__ = "Sep 11 2020 18:46:01";

var WrsConst = {
    PcType: {
        Combined: "Unified",
        Audio: "Audio",
        Video: "Video"
    },

    PcState: {
        // Negative states for error
        Error: -1,
        Disposed: -2,

        Initial: 0,
        Starting: 1,
        OfferSent: 2,
        AnswerRecieved: 3,
        OfferRecieved: 4,
        AnswerSent: 5,
        Renegotiating: 6,
        Connected: 7,

        // last state
        Intermediate: 8
    },

    PcMuteState: {
        MuteNone: 0,
        MuteAudio: 1,
        MuteVideo: 2,
        MuteAudioVideo: 3
    },

    PcMediaSource: {
        LocalAudioVideo: 0,
        RemoteAudioVideo: 1,
    },

    PcRmsRequests: {
        Acquire: 8,
        Release: 2,
        Create: 5,
        Put: 6
    }
}

// freeze constants so that there may not be any accidental changes to them by users or 
// api developers
Object.freeze(WrsConnectionModes);
Object.freeze(WrsErrorCodes);
Object.freeze(WrsConst.PcState);
Object.freeze(WrsConst.PcType);
Object.freeze(WrsConst.PcMuteState);
Object.freeze(WrsConst.PcMediaSource);
Object.freeze(WrsConst.PcRmsRequests);
Object.freeze(WrsConst);

/**
 * Utility methods
 */
function WrsUtilsInternal() {
    var this_ = this;

    // call base constructor
    WrsUtilsInterface(this_);

    this_.checkDeviceSupport = function(){

        if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
            // Firefox 38+ seems having support of enumerateDevicesx
            navigator.enumerateDevices = function(callback) {
                navigator.mediaDevices.enumerateDevices().then(callback);
            };
        }
        
        var MediaDevices = [];
        var isHTTPs = Location.protocol === 'https:';
        var canEnumerate = false;
        
        if (typeof MediaStreamTrack !== 'undefined' && 'getSources' in MediaStreamTrack) {
            canEnumerate = true;
        } else if (navigator.mediaDevices && !!navigator.mediaDevices.enumerateDevices) {
            canEnumerate = true;
        }
        
        var hasMicrophone = false;
        var hasSpeakers = false;
        var hasWebcam = false;
        
        var isMicrophoneAlreadyCaptured = false;
        var isWebcamAlreadyCaptured = false;


       return  new Promise( (resolutionFunc,rejectionFunc) => {
            
            if (!canEnumerate) {
                return;
            }
        
            if (!navigator.enumerateDevices && window.MediaStreamTrack && window.MediaStreamTrack.getSources) {
                navigator.enumerateDevices = window.MediaStreamTrack.getSources.bind(window.MediaStreamTrack);
            }
        
            if (!navigator.enumerateDevices && navigator.enumerateDevices) {
                navigator.enumerateDevices = navigator.enumerateDevices.bind(navigator);
            }
        
            if (!navigator.enumerateDevices) {
                resolutionFunc({hasWebcam,hasMicrophone,isMicrophoneAlreadyCaptured,isWebcamAlreadyCaptured,MediaDevices:null});
            }
        
            MediaDevices = [];
            navigator.enumerateDevices(function(devices) {
                devices.forEach(function(_device) {
                    var device = {};
                    for (var d in _device) {
                        device[d] = _device[d];
                    }
        
                    if (device.kind === 'audio') {
                        device.kind = 'audioinput';
                    }
        
                    if (device.kind === 'video') {
                        device.kind = 'videoinput';
                    }
        
                    var skip;
                    MediaDevices.forEach(function(d) {
                        if (d.id === device.id && d.kind === device.kind) {
                            skip = true;
                        }
                    });
        
                    if (skip) {
                        return;
                    }
        
                    if (!device.deviceId) {
                        device.deviceId = device.id;
                    }
        
                    if (!device.id) {
                        device.id = device.deviceId;
                    }
        
                    if (!device.label) {
                        device.label = 'Please invoke getUserMedia once.';
                        if (!isHTTPs) {
                            device.label = 'HTTPs is required to get label of this ' + device.kind + ' device.';
                        }
                    } else {
                        if (device.kind === 'videoinput' && !isWebcamAlreadyCaptured) {
                            isWebcamAlreadyCaptured = true;
                        }
        
                        if (device.kind === 'audioinput' && !isMicrophoneAlreadyCaptured) {
                            isMicrophoneAlreadyCaptured = true;
                        }
                    }
        
                    if (device.kind === 'audioinput') {
                        hasMicrophone = true;
                    }
        
                    if (device.kind === 'audiooutput') {
                        hasSpeakers = true;
                    }
        
                    if (device.kind === 'videoinput') {
                        hasWebcam = true;
                    }
        
                    // there is no 'videoouput' in the spec.
        
                    MediaDevices.push(device);
                });
        
                resolutionFunc({hasWebcam,hasMicrophone,isMicrophoneAlreadyCaptured,isWebcamAlreadyCaptured,MediaDevices});
            });


        });

    }
    
    this_.getUserMedia = function (constraintsIn, tracefn) {
        if (tracefn == null) {
            tracefn = function (msg) { }
        }

        var stream = null;
        var constraints = { audio: false, video: false };

        if (constraintsIn.audio !== undefined && constraintsIn.audio !== false && constraintsIn.audio.enabled !== false) {
            constraints.audio = constraintsIn.audio;
        }

        if (constraintsIn.video !== undefined && constraintsIn.video !== false && constraintsIn.video.enabled !== false) {
            constraints.video = constraintsIn.video;
        }

        if (constraints.audio == false && constraints.video == false) {
            // This scenario is when audio is through Avaya phone, and Agent can only see Customer video 
            // (Agent self - view is not used)
            return Promise.resolve(null);
        } else {
            // Check if device name is specified in constraints by the user for both audio and video
            if ((constraints.audio.deviceName) || (constraints.video.deviceName)) {
                return navigator.mediaDevices.enumerateDevices().then(devices => {
                    tracefn('Devices available are ' + JSON.stringify(devices));
                    var videoDevices = []; // Maintains list of video devices
                    var audioDevices = []; // Maintains list of audio devices
                    var deviceData = {};   // object that contains the data of the device being added to the above 2 variables
                    var stream = null;

                    // Create 2 flags to determine if both audio and video devices are found/not
                    var videoDeviceFoundFlag = false;
                    var audioDeviceFoundFlag = false;
                    var constraintsAudioDeviceNames = [];
                    var constraintsVideoDeviceNames = [];

                    // In-case audio/video device name is not specified, then we set their corresponding found flag
                    if (!constraints.audio.deviceName) {
                        audioDeviceFoundFlag = true;
                    }
                    if (!constraints.video.deviceName) {
                        videoDeviceFoundFlag = true;
                    }

                    if (constraints.audio.deviceName instanceof Array) {
                        // if the audio deviceName constraints is of type array

                        if (constraints.audio.deviceName.length === 0) {
                            // Check if the array is empty
                            tracefn('WebRTC Audio Constraints (deviceName) is empty');
                            audioDeviceFoundFlag = true;
                        }
                        else {
                            // If the array is not empty we can assign the array directly
                            constraintsAudioDeviceNames = constraints.audio.deviceName;
                        }
                    }
                    else if (typeof constraints.audio.deviceName === "string") {
                        // if the audio deviceName constraints is of type string

                        if (constraints.audio.deviceName.length === 0) {
                            // check if the string is empty
                            tracefn('WebRTC Audio Constraints (deviceName) is empty');
                            audioDeviceFoundFlag = true;
                        }
                        else {
                            // If the string is not empty we can push the string to the array, result will be an array
                            // containing a single string
                            constraintsAudioDeviceNames.push(constraints.audio.deviceName);
                        }
                    }
                    else {
                        // If the audio deviceName constraint is not an array or a string then we print a message
                        tracefn('WebRTC Audio Constraints (deviceName) has not been initialized as an Array or a String');
                        audioDeviceFoundFlag = true;
                    }

                    if (constraints.video.deviceName instanceof Array) {
                        // if the video deviceName constraints is of type array

                        if (constraints.video.deviceName.length === 0) { // Check if the array is empty
                            tracefn('WebRTC Video Constraints (deviceName) is empty');
                            videoDeviceFoundFlag = true;
                        }
                        else {
                            // If the array is not empty we can assign the array directly
                            constraintsVideoDeviceNames = constraints.video.deviceName;
                        }
                    }
                    else if (typeof constraints.video.deviceName === "string") {
                        // if the video deviceName constraints is of type string
                        if (constraints.video.deviceName.length === 0) { // Check if the string is empty
                            tracefn('WebRTC Video Constraints (deviceName) is empty');
                            videoDeviceFoundFlag = true;
                        }
                        else {
                            // If the string is not empty we can push the string to the array, result will be an array 
                            // containing a single string
                            constraintsVideoDeviceNames.push(constraints.video.deviceName);
                        }
                    }
                    else {
                        //If the video deviceName constraint is not an array or a string then we print a message
                        tracefn('WebRTC Video Constraints (deviceName) has not been initialized as an Array or a String');
                        videoDeviceFoundFlag = true;
                    }

                    // Set the device names as null since we will be passing the deviceId if there is a potential match, 
                    // else if no match then getUserMedia will use default values
                    constraints.audio.deviceName = null;
                    constraints.video.deviceName = null;

                    // Checking if the device is an audio or video device and adding it to respective variables, if device 
                    // has both audio / video then it will be added to both variables
                    if (!audioDeviceFoundFlag || !videoDeviceFoundFlag) {
                        // Checking if user has mentioned a specific deviceName for both audio and video, if not then no 
                        // need of using for loop to check
                        for (var i = 0; i < devices.length; i++) {
                            if (devices[i].kind === "videoinput" && !videoDeviceFoundFlag) {
                                // Checking if a device is an video input device and if any devices are mentioned in 
                                // config using the flag
                                deviceData.label = devices[i].label;
                                deviceData.kind = devices[i].kind;
                                deviceData.deviceId = devices[i].deviceId;
                                videoDevices.push(deviceData);
                            }
                            if (devices[i].kind === "audioinput" && !audioDeviceFoundFlag) {
                                // Checking if a device is an audio input device and if any devices are mentioned in
                                // config using the flag
                                deviceData.label = devices[i].label;
                                deviceData.kind = devices[i].kind;
                                deviceData.deviceId = devices[i].deviceId;
                                audioDevices.push(deviceData);
                            }
                            deviceData = {}; // Clear the object
                        }
                    }

                    if (!videoDeviceFoundFlag) tracefn('Video Input Devices available are ' + JSON.stringify(videoDevices));
                    if (!audioDeviceFoundFlag) tracefn('Audio Input Devices available are ' + JSON.stringify(audioDevices));

                    if (!videoDeviceFoundFlag) { // Check if any device name is mentioned in the config using the flag
                        for (var i = 0; i < videoDevices.length; i++) { // Iterate through all the video devices detected previously
                            if (!videoDeviceFoundFlag) { // Check if any device name has been found in the iteration previously
                                for (var j = 0; j < constraintsVideoDeviceNames.length; j++) {
                                    // We iterate through the device Names specified in config
                                    if (constraintsVideoDeviceNames[j] !== "" && constraintsVideoDeviceNames[j] !== null
                                        && constraintsVideoDeviceNames[j] !== undefined) {
                                        // Checking if the deviceName is mentioned as blank/null/undefined in the array
                                        if (this_._internal._checkIfDevicePatternMatches(videoDevices[i].label, constraintsVideoDeviceNames[j], tracefn) !== null) {
                                            // the video devices available will be searched and will be matched with the regular 
                                            // expression(case insensitive).
                                            // If there are multiple devices with the same pattern the first device found will be 
                                            // selected and used
                                            tracefn('Video Device Found: ' + JSON.stringify(videoDevices[i]));
                                            constraints.video.deviceId = videoDevices[i].deviceId;
                                            videoDeviceFoundFlag = true;
                                            break; // breaks out of the inner (second) loop
                                        }
                                    }
                                    else {
                                        // Print the position and value in the array if it is blank/null/undefined
                                        tracefn('Skipping check for the video device name in position ' + j + " as it is "
                                            + (constraintsVideoDeviceNames[j] === "" ? "blank"
                                                : constraintsVideoDeviceNames[j].toString()));
                                    }
                                }
                            }
                            else {
                                break; // If an video device has been found it will break so that no more iterations are made
                            }
                        }
                    }

                    if (!audioDeviceFoundFlag) { // Check if any device name is mentioned in the config using the flag
                        for (var i = 0; i < audioDevices.length; i++) { // Iterate through all the audio devices detected previously
                            if (!audioDeviceFoundFlag) { // Check if any device name has been found in the iteration previously
                                for (var j = 0; j < constraintsAudioDeviceNames.length; j++) {
                                    // We iterate through the device Names specified in config
                                    if (constraintsAudioDeviceNames[j] !== "" && constraintsAudioDeviceNames[j] !== null
                                        && constraintsAudioDeviceNames[j] !== undefined) {
                                        // Checking if the deviceName is mentioned as blank/null/undefined in the array
                                        if (this_._internal._checkIfDevicePatternMatches(audioDevices[i].label, constraintsAudioDeviceNames[j], tracefn) !== null) {
                                            // the audio devices available will be searched and will be matched with the regular 
                                            // expression(case insensitive).
                                            // If there are multiple devices with the same pattern the first device found will be selected 
                                            // and used
                                            tracefn('Audio Device Found: ' + JSON.stringify(audioDevices[i]));
                                            constraints.audio.deviceId = audioDevices[i].deviceId;
                                            audioDeviceFoundFlag = true;
                                            break; // breaks out of the inner (second) loop
                                        }
                                    }
                                    else {
                                        // Print the position and value in the array if it is blank/null/undefined
                                        tracefn('Skipping check for the audio device name in position ' + j + " as it is "
                                            + (constraintsAudioDeviceNames[j] === "" ? "blank"
                                                : constraintsAudioDeviceNames[j].toString()));
                                    }
                                }
                            }
                            else {
                                break; // If an audio device has been found it will break so that no more iterations are made
                            }
                        }
                    }

                    if (!audioDeviceFoundFlag) {
                        tracefn('Audio Device ( ' + constraintsAudioDeviceNames + ' ) not found');
                    }
                    if (!videoDeviceFoundFlag) {
                        tracefn('Video Device ( ' + constraintsVideoDeviceNames + ' ) not found');
                    }

                    if (audioDeviceFoundFlag && videoDeviceFoundFlag) {
                        return this_._internal._OsGetUserMediaWrapper(constraints, tracefn);
                    }
                    else {
                        return Promise.reject('getUserMedia() error: one of the requested devices not found');
                    }
                });
            }
            else {
                return this_._internal._OsGetUserMediaWrapper(constraints, tracefn);
            }
        }
    }

    /* Returns the User Agent description */
    this_.getUserAgentInfo = function () {
        var ua = navigator.userAgent;
        var tem = undefined;
        var M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];

        if (/trident/i.test(M[1])) {
            tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
            return { name: 'IE', version: (tem[1] || '') };
        }

        if (M[1] === 'Chrome') {
            tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
            if (tem != null) return { name: tem[1].replace('OPR', 'Opera'), version: tem[2] };
        }

        M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
        if ((tem = ua.match(/version\/(\d+)/i)) != null) {
            M.splice(1, 1, tem[1]);
        }

        return {
            name: M[0],
            version: M[1]
        }
    }

    this_.createConferenceMixer = function () {
        return new WrsConferenceMixerInternal();
    }

    this_.isKnownMessage = function (message) {
        return (this_.isKnownWebRTCMessage(message, 7)
            || this_.isKnownRecordingMessage(message));
    }

    // category is a bitfield 'dcn' where 
    //   n = (LSB) is normal
    //   c = is control
    //   d = is direct
    this_.isKnownWebRTCMessage = function (json, category) {
        var n = false;
        var c = false;
        var d = false;

        switch (category) {
            case 1:
                n = true;
                break;
            case 2:
                c = true;
                break;
            case 3:
                n = true;
                c = true;
                break;
            case 4:
                d = true;
                break;
            case 5:
                n = true;
                d = true;
                break;
            case 6:
                c = true;
                d = true;
                break;
            case 7:
                n = true;
                c = true;
                d = true;
        }

        var knownNormalType = (n && (json.type == "candidate"
            || json.type == "offer"
            || json.type == "answer"
            || json.type == "pranswer"));

        var knownDirectType = (d && (json.type == "direct:candidate"
            || json.type == "direct:offer"
            || json.type == "direct:answer"
            || json.type == "direct:pranswer"));

        var knownContorlTypes = (c && (json.type == "holdav"
            || json.type == "endav" || json.type == "eventav" || json.type == "ackav"));

        return (knownNormalType || knownDirectType || knownContorlTypes);
    }

    this_.isKnownRecordingMessage = function (json) {
        var knownType = (json.type == "queryms");

        return knownType;
    }
    
    //Adds a property to a stream to make it identifiable as a screenshare stream
    this_.markStreamAsScreenshare = function (stream) {
        if (stream !== undefined) {
            stream._wrsIsScreenshareStream = true;
            return stream;
        }
        else {
            return {};
        }
    } 

    // this is not exposed to outside through api. Only to be used internally
    this_.isScreenshareStream = function (stream) {
        if (stream.hasOwnProperty('_wrsIsScreenshareStream')) {
            if (stream._wrsIsScreenshareStream) {
                return true;
            }
        }

        return false;
    }

    this_.setStreamOwner = function (stream, owner) {
        if (stream !== undefined) {
            stream._wrsOwner = owner;
        }
    }

    this_.getStreamOwner = function (stream, defaultOwner) {
        if (stream.hasOwnProperty('_wrsOwner')) {
            if (stream._wrsOwner !== null && stream._wrsOwner !== undefined) {
                return stream._wrsOwner;
            }
        }

        return defaultOwner;
    }

    this_._internal = { };

    /* Returns a promise that resolves eventually to a stream */
    this_._internal._OsGetUserMediaWrapper = function (constraints, tracefn) {
        var ua = this_.getUserAgentInfo();
        if (ua.name == 'Safari' && ua.version.split('.')[0] == '13') {
            // Some iOS 13.x version on some types of phones has a issue, where captured
            // one and only audio stream is ended when it is muted. To prevent this
            // we capture a additional audio stream before capturing the transmitted stream
            tracefn('Capturing extra audio stream to support iOS 13.x');

            var prom = navigator.mediaDevices.getUserMedia(constraints);

            if (this_._internal.dummyCapture_ == null) {
                this_._internal.dummyCapture_ = { ref: 0, stream: null };
            }

            if (this_._internal.dummyCapture_.ref == 0) {
                prom = prom.then(function (stream) {
                    this_._internal.dummyCapture_.stream = stream;
                    return navigator.mediaDevices.getUserMedia(constraints);
                }).then(function (stream) {
                    this_._internal.dummyCapture_.stream.getVideoTracks().forEach(function (track) {
                        track.stop();
                        this_._internal.dummyCapture_.stream.removeTrack(track);
                    });

                    return stream;
                });
            }

            this_._internal.dummyCapture_.ref += 1;

            return prom.then(function (stream) {
                // Add handler to stop the dummy track
                var tracks = stream.getAudioTracks();
                if (tracks.length > 0) {
                    var track = tracks[0];
                    track._wrsStopFn = track.stop;
                    track.stop = function () {
                        if (this_._internal.dummyCapture_.ref == 1) {
                            if (this_._internal.dummyCapture_.stream != null) {
                                this_._internal.dummyCapture_.stream.getTracks().forEach(function (track) {
                                    track.stop();
                                });
                            }

                            this_._internal.dummyCapture_.ref = 0;
                            this_._internal.dummyCapture_.stream = null;
                        } else if (this_._internal.dummyCapture_.ref > 1) {
                            this_._internal.dummyCapture_.ref -= 1;
                        }

                        this._wrsStopFn();
                    }
                }

                return stream;
            });
        }
        else {
            return navigator.mediaDevices.getUserMedia(constraints);
        }
    }

    /* Regex match for device ID */
    this_._internal._checkIfDevicePatternMatches = function (deviceName, patternToMatch, tracefn) {
        // Escape all special characters in the pattern
        // patternToMatch = patternToMatch.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        tracefn('Trying to match device ' + deviceName + " with pattern: " + patternToMatch);

        // Perform Pattern Matching
        var result = deviceName.match(new RegExp(patternToMatch, 'gi'));
        if (result === null) {
            tracefn('Cannot match device with pattern as the result is null');
        }
        else
            tracefn('Device successfully matched with pattern \n No. of patterns matched: ' + result.length.toString());

        return result;
    }
}

// global utility method instance
var WrsUtilsInternalInst = new WrsUtilsInternal();
var WrsUtils = WrsUtilsInternalInst;

function WrsNativePeerConnectionWrapper(type, fnTrace, statsifs) {
    var this_ = this;

    this_.pc_ = null;
    this_.queueICE_ = true;
    this_.iceCandidates_ = [];
    this_.type_ = type;
    this_.requestTimeoutTimer_ = null;
    this_.miscellaneousTimers_ = { };
    this_.midStreamMap_ = { };
    this_.trackStreamMap_ = {};

    // following variable indicates waiting for initial CreateOffer or CreateAnswer to be called,
    // during which no renegotiation events are fired.
    this_.waitingForCreation_ = true;

    this_._trace = fnTrace;

    this_.state = WrsConst.PcState.Initial;

    this_.statsifs_ = statsifs;
    this_.statsInterval_ = ((this_.statsifs_ == null) ? 0 : this_.statsifs_.getStatsInterval());

    //stat interval loop
    this_.statIntervalFn_ = null;

    this_.open = function (configs) {
        this_.close();
        this_._init(configs);

        // send the stats if statsInterval is greater than 0
        if (this_.statsInterval_ > 0) {
            // we clamp the minimum interval to 250 ms
            if (this_.statsInterval_ < 250)
                this_.statsInterval_ = 250;

            // we clamp the maximum interval to 10000 ms
            if (this_.statsInterval_ > 10000)
                this_.statsInterval_ = 10000;

            this_.statIntervalFn_ = setInterval(function () {
                //check if the peer connection is available
                if (this_.pc_) {
                    //get the stats and expose it the initiator channel
                    this_.pc_.getStats().then(function (stats) {
                        //invoke the callback
                        this_.statsifs_.onStats(stats);
                    });
                }
                else {
                    this_._trace("RTCPeerConnection is not available for getStats");
                    //clear the stats interval
                    clearInterval(this_.statIntervalFn_);
                    this_.statIntervalFn_ = null;
                }
            }, this_.statsInterval_);
        }
    }

    this_.getStats = function (fncallback) {
        try {
            if (this_.pc_) {
                //get the stats and expose it the initiator channel
                this_.pc_.getStats().then(function (stats) {
                    fncallback(stats);
                });
            }
            else {
                this_._trace("RTCPeerConnection is not available for getStats");
                //clear the stats interval
            }
        }
        catch (e) {
        }
    }

    this_.close = function () {
        if (this_.pc_ != null) {
            this_.pc_.close();

            this_.queueICE_ = true;
            this_.iceCandidates_ = [];
            this_.state = WrsConst.PcState.Initial;
        }

        //clear the stats interval
        if (this_.statIntervalFn_ !== null) {
            clearInterval(this_.statIntervalFn_);
            this_.statIntervalFn_ = null;
        }

        if (this_.requestTimeoutTimer_ !== null) {
            clearTimeout(this_.requestTimeoutTimer_);
            this_.requestTimeoutTimer_ = null;
        }

        this_._clearTimers();

        this_.pc_ = null;
    }

    this_.addTrack = function (track, stream) {
        // add if track not already added
        var alreadyAdded = this_.pc_.getSenders().some(function (sender) {
            if (sender.track != null) {
                if (sender.track.id === track.id) {
                    return true;
                }
            }

            return false;
        });

        if (alreadyAdded) {
            return null;
        }

        // try to find a tranciever available to send this
        var tranciever = null;
        this_.pc_.getTransceivers().some(function (trnsvr) {
            // NOTE: RTPSender.setStreams is not supported by many browsers and there is no mechanism to get the
            // stream ids for a RTPSender in current API. Thus we have to only reuse RTPSenders if they have been 
            // used to send same stream in previous innstance from a call to a RTCPeerConnection.addTrack. Otherwise
            // the stream ids associated with the stream will be not as expected.
            var isReUsable = ((trnsvr.direction == "recvonly" || trnsvr.direction == "inactive")
                && (trnsvr.sender != null)
                && (trnsvr.sender.transport != null)
                && (trnsvr.sender.transport.state != "closed" && trnsvr.sender.transport.state != "failed")
                && (this_.midStreamMap_[trnsvr.mid] != undefined)
                && (this_.midStreamMap_[trnsvr.mid].type == stream.kind)
                && (this_.midStreamMap_[trnsvr.mid].stream == stream.id));

            if (isReUsable) {
                tranciever = trnsvr;
                return true;
            }

            return false;
        });

        var sender = null;

        if (tranciever != null) {
            // have a idel tranciever, use it to send
            sender = tranciever.sender;

            tranciever.direction = "sendrecv";
            sender.replaceTrack(track);
        } else {
            // if no free trancievers available, create new one by adding
            sender = this_.pc_.addTrack(track, stream);

            // update stream->mid map
            this_.pc_.getTransceivers().forEach(function (trnsvr) {
                if (trnsvr.sender != null && trnsvr.sender == sender) {
                    this_.midStreamMap_[trnsvr.mid] = { type: track.kind, stream: stream.id };
                }
            });
        }

        this_.trackStreamMap_[track.id] = { stream: stream.id, type: 'send', active: true };

        return sender;
    }

    this_.getTracksForLocalStream = function (stream) {
        var tracks = [];

        if (this_.pc_ != null) {
            this_.pc_.getSenders().forEach(function (sender) {
                if (sender.track != null) {
                    var info = this_.trackStreamMap_[sender.track.id];
                    if (info != null && info.stream == stream.id) {
                        tracks.push(sender.track);
                    };
                }
            });
        }

        return tracks;
    }

    this_.removeTrack = function (track) {
        var senderObj = null;
        this_.pc_.getSenders().some(function (sender) {
            if (sender.track != null) {
                if (sender.track.id === track.id) {
                    senderObj = sender;
                    return true;
                }
            }

            return false;
        });

        if (senderObj != null) {
            this_.pc_.removeTrack(senderObj);

            if (this_.trackStreamMap_[track.id])
                this_.trackStreamMap_[track.id].active = false;
        }
    }

    this_.addIceCandidate = function (json) {
        if (this_.queueICE_) {
            this_._trace('ICE candidate ' + json.candidate + ' queued for ' + this_.getType());
            this_.iceCandidates_.push(json);
        } else {
            this_._trace('ICE candidate ' + json.candidate + ' applied for ' + this_.getType());
            this_.pc_.addIceCandidate(json).then(this_._onAddIceCandidateSuccess
                , this_._onAddIceCandidateError);
        }
    }

    this_.createAnswer = function (opt) {
        this_.waitingForCreation_ = false;

        this_._cleanupPc();

        return this_.pc_.createAnswer(opt).then(function (desc) {
            this_._clearTimer("renegoatiate");
            return desc;
        });
    }

    this_.setLocalDescription = function (desc) {
        return this_.pc_.setLocalDescription(desc);
    }

    this_.setRemoteDescription = function (desc) {
        if (this_.requestTimeoutTimer_ !== null) {
            clearTimeout(this_.requestTimeoutTimer_);
            this_.requestTimeoutTimer_ = null;
        }

        var pro = new Promise(function (res, rej) {
            this_.miscellaneousTimers_["delayedSDP"] = setTimeout(function () {
                this_.miscellaneousTimers_["delayedSDP"] = null;
                this_._delayedSetRemoteDescription(0, desc, res, rej);
            }, 0);
        });
        return pro;
    }

    this_.getIceConnectionState = function () {
        if (this_.pc_ != null) {
            if (this_.pc_.connectionState === 'failed' && this_.pc_.iceConnectionState === 'disconnected') {
                // fix for chrome 76 not going to failed state
                return 'failed';
            }

            return this_.pc_.iceConnectionState;
        } else {
            return "new";
        }
    }

    this_.getType = function () {
        return this_.type_;
    }

    this_.createOffer = function (opt) {
        var copy = JSON.parse(JSON.stringify(opt));

        if (this_.type_ == WrsConst.PcType.Audio) {
            copy.offerToReceiveVideo = false;
        } else if (this_.type_ == WrsConst.PcType.Video) {
            copy.offerToReceiveAudio = false;
        }

        this_.requestTimeoutTimer_ = setTimeout(function () {
            this_.requestTimeoutTimer_ = null;
            this_.onrequesttimeout(this_);
        }, 20000);

        this_._cleanupPc();

        this_.waitingForCreation_ = false;
        return this_.pc_.createOffer(copy).then(function (desc) {
            this_._clearTimer("renegoatiate");
            return desc;
        });
    }

    this_.triggerRenegotiation = function () {
        this_._onnegotiationneeded({ });
    }

    this_.onicecandidate = function (o, e) {

    }

    this_.oniceconnectionstatechange = function (o, e) {

    }

    this_.onnegotiationneeded = function (o, e) {

    }

    this_.ontrack = function (o, e) {

    }

    // This is triggered when offer is sent but answer is not received within reasonable time
    this_.onrequesttimeout = function (o) {

    }

    this_._cleanupPc = function () {
        // remove any ended senders before creating offer/answer
        this_.pc_.getSenders().forEach(function (sender) {
            if (sender.track != null && sender.track.readyState == "ended") {
                this_.pc_.removeTrack(sender);
            }
        });
    }

    this_._clearTimers = function () {
        for (var timer in this_.miscellaneousTimers_) {
            if (this_.miscellaneousTimers_.hasOwnProperty(timer)) {
                if (this_.miscellaneousTimers_[timer] !== null) {
                    clearTimeout(this_.miscellaneousTimers_[timer]);
                    this_.miscellaneousTimers_[timer] = null;
                }
            }
        }

        this_.miscellaneousTimers_ = { };
    }

    this_._clearTimer = function (timer) {
        if (this_.miscellaneousTimers_.hasOwnProperty(timer)) {
            if (this_.miscellaneousTimers_[timer] !== null) {
                clearTimeout(this_.miscellaneousTimers_[timer]);
                this_.miscellaneousTimers_[timer] = null;
            }
        }
    }

    this_._delayedSetRemoteDescription = function (tries, desc, resolve, reject) {
        if (this_.pc_ == null) {
            tries += 1;
            this_._trace('waiting for getUserMedia to complete before setting SDP (' + tries + ')');
            if (tries > 1200) {
                reject("time out");
            } else {
                this_.miscellaneousTimers_["delayedSDP"] = setTimeout(function () {
                    this_.miscellaneousTimers_["delayedSDP"] = null;
                    this_._delayedSetRemoteDescription(tries, desc, resolve, reject);
                }, 50);
            }
        } else {
            var pro = this_.pc_.setRemoteDescription(desc);
            pro.then(function (v) {
                this_._loadQueuedIce();
                resolve(v);
            }, function (e) {
                reject(e);
            });
        }
    }

    this_._loadQueuedIce = function () {
        this_.queueICE_ = false;

        for (var idx in this_.iceCandidates_) {
            var json = this_.iceCandidates_[idx];
            this_.addIceCandidate(json);
        }

        this_.iceCandidates_ = [];
    }

    this_._onAddIceCandidateSuccess = function () {
        this_._trace('addIceCandidate success');
    }

    this_._onAddIceCandidateError = function (error) {
        this_._trace('failed to add ICE Candidate: ' + error);
    }

    this_._onnegotiationneeded = function (event) {
        // this is to delay renegotiations that each track add would not generate 
        // renegotiationneeded event but batch them and give out one every 50ms or so
        if (this_.miscellaneousTimers_["renegoatiate"] == null) {
            this_.miscellaneousTimers_["renegoatiate"] = setTimeout(function () {
                this_.miscellaneousTimers_["renegoatiate"] = null;
                this_._trace('Renegotiation needed');
                this_.onnegotiationneeded(this_, event);
            }, 50);
        }
    }

    this_._init = function (configurations) {
        this_.pc_ = new RTCPeerConnection(configurations);
        this_.waitingForCreation_ = true;
        this_.midStreamMap_ = { };
        this_.trackStreamMap_ = { };

        this_.pc_.onicecandidate = function (e) {
            this_.onicecandidate(this_, e);
        }

        this_.pc_.oniceconnectionstatechange = function (e) {
            this_.oniceconnectionstatechange(this_, e);
        }

        this_.pc_.onnegotiationneeded = function (e) {
            if (this_.waitingForCreation_) {
                // any negotiations while in a partial state should be handled in application logic
                return;
            }

            this_._onnegotiationneeded(e);
        }

        this_.pc_.ontrack = function (e) {
            this_.ontrack(this_, e);
        };
    }
}

/**
 * This is a internal function and user should not modify/change this code. User should not require to 
 * call this method directly under any circumstance. All variables/functions defined in this function 
 * should be considered as internal scope, thus should not be used by application programs. 
 * 
 * @param {object} inst instance
 * @param {object} channel channel
 * @param {object} configs configuration
 * @param {string} intent intent
 * @param {object} stats stats interface
 */
function WrsPeerConnectionInternal(inst, channel, configs, intent, statsifs) {
    var this_ = inst;

    // call base constructor
    WrsChannelInterface(this_);

    this_.channel_ = channel;
    this_.statsifs_ = statsifs;
    this_.configs_ = configs;
    this_.intent_ = ((intent == null || intent == "") ? "call" : intent);

    this_.muted_ = WrsConst.PcMuteState.MuteNone;   // is call muted
    this_.hold_ = false; // is call on hold
    this_.mutedInternal_ = WrsConst.PcMuteState.MuteNone; // stream muted due to internal error

    this_.temporaryDisconnect_ = false;

    this_.temporaryDisconnectTimer_ = null;
    this_.miscellaneousTimers_ = { };

    // The peer connection for audio/video in Normal or Direct scenarios (specified in WrsConnectionModes) 
    // or peer connection for audio when in DirectAudio or DirectVideo scenarios
    this_.pc_ = null;

    // The peer connection for video in DirectAudio or DirectVideo scenarios (specified in WrsConnectionModes) 
    this_.pc2_ = null;

    this_.connected_ = false;
    this_.myId_ = WrsObjectId__++;
    this_.remoteTracks_ = null;
    this_.remoteStreams_ = null;
    this_.remoteStreamInfo_ = {};
    this_.localStreams_ = [];
    this_.userMedia_ = null;
    this_.incoming_ = true; // Specifies if offer is sent or received when connecting
    this_.remoteAudioStreamInfo_ = {};
    this_.audioThreshold_ = 0.11;
    this_.fetchStatIntervalFn_ = undefined;
    this_.screenshareStreamId_ = "";
    this_.isMsUsed_ = undefined;

    this_.dtmf_ = null;

    this_.connectionMode_ = this_.configs_.getAudioVideoConnectionMode();
    this_.splitAv_ = (this_.connectionMode_ == WrsConnectionModes.DirectAudio
        || this_.connectionMode_ == WrsConnectionModes.DirectVideo);

    this_.callParameters_ = {
        mode: "conference",	// Can be one of conference, wisper, monitor or call
        create: false,
    };

    this_.recorder_ = new WrsRecorderInternal(this_, this_, this_.configs_.getRecordingOptions(), null);

    this_.call = function () {
        if (this_._state() != WrsConst.PcState.Initial) {
            this_._gotError(WrsErrorCodes.INVALID_USER_STATE, 'Not allowed to perform this action in current state');
            return;
        }

        this_._trace('Starting call');
        this_.connected_ = false;

        this_.callParameters_.mode = "conference";
        this_.callParameters_.create = true;

        this_._initiateCall();
    }

    this_.join = function (parameters) {
        if (this_._state() != WrsConst.PcState.Initial) {
            this_._gotError(WrsErrorCodes.INVALID_USER_STATE, 'Not allowed to perform this action in current state');
            return;
        }

        if (parameters.mode != "conference" && parameters.mode != "wisper" && parameters.mode != "monitor") {
            this_._gotError(WrsErrorCodes.INVALID_ARGUMENT, 'Invalid argument parameters.mode');
            return;
        }

        this_._trace('Starting call (join)');
        this_.connected_ = false;

        this_.callParameters_.mode = parameters.mode;
        this_.callParameters_.create = false;

        this_._initiateCall();
    }

    this_.mute = function (audio, video) {
        this_._muteUnMute(false, audio, video);
    }

    this_.unMute = function (audio, video) {
        this_._muteUnMute(true, audio, video);
    }

    this_.hold = function () {
        this_._holdUnhold(true, false);
    }

    this_.unHold = function () {
        this_._holdUnhold(false, false);
    }

    this_.close = function () {
        this_._close();
    }

    this_.isError = function () {
        return (this_._state() < WrsConst.PcState.Initial);
    }

    this_.isConnected = function () {
        return this_.connected_;
    }

    this_.getId = function () {
        return this_.channel_.getId();
    }

    this_.send = function (jsonObject) {
        this_._send(jsonObject);
    }

    // WrsRecorderInternal cb interface
    this_.onerror = function (error) {
        this_._gotError(WrsErrorCodes.RECORDING_FAILED, error);
        if (this_.connected_) {
            this_._gotDisconnected();
        }

        this_._close();
    }

    this_.onModifyStreams = function (streams) {
        // check if any video streams available
        var hasVideo = streams.some(function (stream) {
            if (stream.getVideoTracks().length > 0) {
                return true;
            }
            
            return false;
        });

        if (!hasVideo) {
            var constraints = JSON.parse(JSON.stringify(this_.configs_.getMediaConstraints()));

            // capture video only stream
            constraints.audio = false;
            constraints.custom = false;

            if (constraints.video === undefined || constraints.video === false) {
                constraints.video = true;
            } else if (constraints.video.enabled === undefined || constraints.video.enabled === false) {
                constraints.video.enabled = true;
            }

            var promise = WrsUtils.getUserMedia(constraints, this_._trace);

            promise = promise.then(function (stream) {
                if (streams.length > 0) {
                    // add video to existing stream
                    var videoTrack = stream.getVideoTracks()[0];
                    streams[0].addTrack(videoTrack);
                } else {
                    // add new video stream if no streams exist
                    streams.push(stream);
                }

                return streams;
            });

            return promise;
        } else {
            return streams;
        }
    }

    this_.modify = function (arg) {
        var streams = [];

        if (this_.userMedia_ != null) {
            streams = this_.userMedia_.slice();
        }

        var streamsMap = {};
        streams.forEach(function (stream) {
            var trackMap = {};

            stream.getTracks().forEach(function (track) {
                trackMap[track.id] = true;
            });

            trackMap.length = stream.getTracks().length;

            streamsMap[stream.id] = trackMap;
        });

        var ret = null;

        try {
            ret = this_.onModifyStreams(streams, arg);
        } catch (e) {
            ret = Promise.reject('exception in user code. ' + e.message);
        }

        if (ret == null) {
            ret = streams;
        }

        Promise.resolve(ret).then(function (streams) {
            // find removed streams
            var streamsAdded = [];
            var streamsRemoved = [];
            var streamsModified = [];

            streams.forEach(function (stream) {
                if (streamsMap[stream.id] !== undefined) {
                    var modified = false;
                    var trackMap = streamsMap[stream.id];

                    trackMap.found = true;

                    if (trackMap.length == stream.getTracks().length) {
                        stream.getTracks().forEach(function (track) {
                            if (!trackMap[track.id]) {
                                modified = true;
                            }
                        });
                    } else {
                        modified = true;
                    }

                    if (modified) {
                        streamsModified.push(stream);
                    }
                } else {
                    streamsAdded.push(stream);
                }
            });

            var streamsOrig = (this_.userMedia_ != null) ? this_.userMedia_ : [];

            streamsOrig.forEach(function (stream) {
                if (streamsMap[stream.id] !== undefined) {
                    if (!streamsMap[stream.id].found) {
                        streamsRemoved.push(stream);
                    }
                }
            });

            this_.userMedia_ = streams;

            streamsAdded.forEach(function (stream) {
                this_._addStream(stream);
            });

            streamsRemoved.forEach(function (stream) {
                this_._removeStream(stream);
            });

            streamsModified.forEach(function (stream) {
                this_._modifyStream(stream);
            });

            this_._updateMuteUnMuteHoldState();
        }).catch(function (e) {
            this_._trace('error: Modify stream failed' + e);
        });
    }

    // This method is only for internal use and is not to be exposed via the interfaces
    this_.mixStreams = function (other) {
        var thisMixerStream = null;
        var otherMixerStream = null;

        this_._trace('Conference Mixing PC{' + this_.myId_ + '} <-> PC{' + other.myId_ + '}');

        if (this_.userMedia_ != null) {
            this_.userMedia_.some(function (stream) {
                if (stream.wrsMixer_ != undefined && stream.wrsMixer_.wrsdestination_ != undefined) {
                    thisMixerStream = stream;
                    return true;
                }

                return false;
            });
        }

        if (other.userMedia_ != null) {
            other.userMedia_.some(function (stream) {
                if (stream.wrsMixer_ != undefined && stream.wrsMixer_.wrsdestination_ != undefined) {
                    otherMixerStream = stream;
                    return true;
                }

                return false;
            });
        }

        if (thisMixerStream == null || otherMixerStream == null) {
            this_._trace(' One of the streams not prepared for mixing');
            return false;
        }

        // mix remote streams of this pc to the other
        for (var key in this_.remoteStreams_) {
            if (this_.remoteStreams_.hasOwnProperty(key)) {
                var stream = this_.remoteStreams_[key];

                this_._trace(' Mixing {' + key + '} to PC{' + other.myId_ + '} ');

                if (otherMixerStream.wrsMixer_.createMediaStreamTrackSource === undefined) {
                    // NOTE: Only the first track will be used. This is ok for now. until other 
                    // browsers implement createMediaStreamTrackSource method
                    var node = otherMixerStream.wrsMixer_.createMediaStreamSource(stream);
                    node.connect(otherMixerStream.wrsMixer_.wrsdestination_);
                } else {
                    stream.getAudioTracks().forEach(function (track) {
                        var node = otherMixerStream.wrsMixer_.createMediaStreamTrackSource(track);
                        node.connect(otherMixerStream.wrsMixer_.wrsdestination_);
                    });
                }
            }
        }

        // mix remote streams of other pc to this one
        for (var key in other.remoteStreams_) {
            if (other.remoteStreams_.hasOwnProperty(key)) {
                var stream = other.remoteStreams_[key];

                this_._trace('  Mixing {' + key + '} to PC{' + this_.myId_ + '} ');

                if (thisMixerStream.wrsMixer_.createMediaStreamTrackSource === undefined) {
                    // NOTE: Only the first track will be used. This is ok for now. until other 
                    // browsers implement createMediaStreamTrackSource method
                    var node = thisMixerStream.wrsMixer_.createMediaStreamSource(stream);
                    node.connect(thisMixerStream.wrsMixer_.wrsdestination_);
                } else {
                    stream.getAudioTracks().forEach(function (track) {
                        var node = thisMixerStream.wrsMixer_.createMediaStreamTrackSource(track);
                        node.connect(thisMixerStream.wrsMixer_.wrsdestination_);
                    });
                }
            }
        }

        return true;
    }

    this_.isDirectCall = function () {
        return (this_.connectionMode_ == WrsConnectionModes.Direct) ? true
            : (this_.isMsUsed_ === undefined) ? undefined : !this_.isMsUsed_;
    }

    this_.playAudio = function(buf) {
        var thisMixerStream = null;

        if (this_.userMedia_ != null) {
            this_.userMedia_.some(function (stream) {
                if (stream.wrsMixer_ != undefined && stream.wrsMixer_.wrsdestination_ != undefined) {
                    thisMixerStream = stream;
                    return true;
                }

                return false;
            });
        }

        if (thisMixerStream == null  || thisMixerStream.wrsMixer_.state == "closed") {
            // no mixer found. probably call not started or mixer not enabled.
            this_._trace('Failed to create audio player. no mixer setup. '
                + 'please make sure call is active and mixer is enabled in configurations');
            
            return null;
        }

        var context = thisMixerStream.wrsMixer_;
        var destination = context.wrsdestination_;

        this_._trace('Creating Audio Player');
        return new WrsPlayerInterfaceImpl(context, destination, buf, this_._trace);
    }

    this_.sendDtmf = function (tone) { 
        if (this_.dtmf_ == null) {
            var thisMixerStream = null;

            if (this_.userMedia_ != null) {
                this_.userMedia_.some(function (stream) {
                    if (stream.wrsMixer_ != undefined && stream.wrsMixer_.wrsdestination_ != undefined) {
                        thisMixerStream = stream;
                        return true;
                    }
    
                    return false;
                });
            }
    
            if (thisMixerStream == null  || thisMixerStream.wrsMixer_.state == "closed") {
                // no mixer found. probably call not started or mixer not enabled.
                this_._trace('Failed to create DTMF generator. no mixer setup. '
                    + 'please make sure call is active and mixer is enabled in configurations');
                
                return false;
            }
    
            var context = thisMixerStream.wrsMixer_;
            var destination = context.wrsdestination_;
    
            this_._trace('Creating Dtmf Generator');
    
            this_.dtmf_ = new WrsDtmfGeneratorImpl(context, destination, this_._trace);
        }

        this_.dtmf_.send(tone);
        return true;
    }

    this_._state = function () {
        if (this_.splitAv_) {
            if (this_.pc_ == null || this_.pc2_ == null) {
                return WrsConst.PcState.Initial;
            }

            if (this_.pc_.state != this_.pc2_.state) {
                if (this_.pc_.state < WrsConst.PcState.Initial
                    || this_.pc2_.state < WrsConst.PcState.Initial) {
                    return WrsConst.PcState.Error;
                } else {
                    return WrsConst.PcState.Intermediate;
                }
            } else {
                return this_.pc_.state;
            }
        } else {
            if (this_.pc_ == null) {
                return WrsConst.PcState.Initial;
            } else {
                return this_.pc_.state;
            }
        }
    }

    this_._setState = function (state) {
        if (this_.pc_ != null) {
            this_.pc_.state = state;
        }

        if (this_.pc2_ != null) {
            this_.pc2_.state = state;
        }
    }

    this_._initiateCall = function () {
        this_._trace('Using WebClientAPI version ' + WrsJsVersion + '(build ' + WrsBuildTime__ + ')');

        //To-do to clone this
        var constraints = this_.configs_.getMediaConstraints();

        this_.incoming_ = false;

        if (this_.callParameters_.mode == "monitor") {
            // no need to get user media. we are not hoping to send anything
            this_._continueInitiateCallAfterAcquire(null);
        } else {
            this_._onAcquireUserMedia(constraints, function (streams) {
                this_._continueInitiateCallAfterAcquire(streams);
            });
        }
    }

    this_._continueInitiateCallAfterAcquire = function (streams) {
        this_.userMedia_ = streams;
        this_._createPc(streams, true);
        this_.pc_.triggerRenegotiation();
        if (this_.splitAv_) {
            this_.pc2_.triggerRenegotiation();
        }

        this_._gotLocalStream(streams, true);
        this_._updateMuteUnMuteHoldState();
    }

    this_._onAcquireUserMedia = function (constraints, then) {
        var stream = null;

        if (constraints.hasOwnProperty("custom") && constraints.custom == true) {
            try {
                stream = this_.onAcquireUserMedia(constraints);
            } catch (e) {
                // we ignore exceptions by user code
                stream = Promise.reject('getUserMedia() error: exception in user code');
            }
            this_._onAcquireUserMediaStreams(stream, then);
        } else {
            stream = WrsUtils.getUserMedia(constraints, this_._trace);
            this_._onAcquireUserMediaStreams(stream, then);
        }
    }

    this_._onAcquireUserMediaStreams = function (stream, then) {
        var promisedStream = Promise.resolve(stream);
        var promisedRecording = this_.recorder_.start();

        var onException = function (e) {
            this_._setState(WrsConst.PcState.Error);

            if (e.hasOwnProperty('code') && e.hasOwnProperty('message')) {
                this_._trace('error: ' + JSON.stringify(e));
                this_._gotError(e.code, e.message);
            }
            else {
                this_._trace('error: ' + e);
                this_._gotError(WrsErrorCodes.GET_USER_MEDIA_FAILED, 'Failed to capture local audio/video streams');
            }
        }

        Promise.all([promisedStream, promisedRecording]).then(function (result) {
            var streams = null;
            if (result[0] != null) {
                if (!(result[0] instanceof Array)) {
                    streams = [result[0]];
                } else {
                    streams = result[0];
                }
            }

            var videoCount = 0;
            var audioCount = 0;

            // verify each stream is compatible
            if (streams != null) {
                streams.forEach(function (stream, index) {
                    if (stream != null) {
                        stream.getAudioTracks().forEach(function (track) {
                            audioCount++;
                        });
        
                        stream.getVideoTracks().forEach(function (track) {
                            videoCount++;
                        });
                    }
                });
            }

            if (audioCount > 1 || videoCount > 1) {
                onException('Media streams with more that one audio/video track is not allowed');
                return;
            }

            if (this_.recorder_.enabled()) {
                if(streams != null) {
                    streams.forEach(function (s) {
                        this_.recorder_.add(s, WrsConst.PcMediaSource.LocalAudioVideo);
                    });
                }
            }

            if (this_.configs_.isAudioMixerEnabled() && streams.length > 0 && streams[0].getAudioTracks().length > 0) {
                // If mixer is enabled, we create a mixer for all the audio tracks of the first stream
                var streamToModify = streams[0];

                var AudioContext = window.AudioContext || window.webkitAudioContext;
                var mixer = new AudioContext();
                mixer.wrsdestination_ = mixer.createMediaStreamDestination();

                if (mixer.createMediaStreamTrackSource === undefined) {
                    // NOTE: Only the first track will be used. This is ok for now. until other 
                    // browsers implement createMediaStreamTrackSource method
                    var node = mixer.createMediaStreamSource(streamToModify);
                    node.connect(mixer.wrsdestination_);
                } else {
                    streamToModify.getAudioTracks().forEach(function (track) {
                        var node = mixer.createMediaStreamTrackSource(track);
                        node.connect(mixer.wrsdestination_);
                    });
                }

                var modifiedStream = new MediaStream();
                streamToModify.getVideoTracks().forEach(function (track) {
                    modifiedStream.addTrack(track);
                });

                mixer.wrsdestination_.stream.getAudioTracks().forEach(function (track) {
                    modifiedStream.addTrack(track);
                });
                
                modifiedStream.wrsMixer_ = mixer;
                modifiedStream.wrsOriginalAudioTracks_ = streamToModify.getAudioTracks();

                streams[0] = modifiedStream;
            }

            then(streams);
        }).catch(onException);
    }

    this_._muteUnMute = function (unmute, audio, video) {
        var audioMuted = false;
        var videoMuted = false;

        if (this_.muted_ == WrsConst.PcMuteState.MuteAudio) {
            audioMuted = true;
        } else if (this_.muted_ == WrsConst.PcMuteState.MuteVideo) {
            videoMuted = true;
        } else if (this_.muted_ == WrsConst.PcMuteState.MuteAudioVideo) {
            audioMuted = true;
            videoMuted = true;
        }

        if (audio == true) {
            audioMuted = (unmute == false);
        }

        if (video == true) {
            videoMuted = (unmute == false);
        }

        if (audioMuted == true && videoMuted == true) {
            this_.muted_ = WrsConst.PcMuteState.MuteAudioVideo;
        } else if (audioMuted == true) {
            this_.muted_ = WrsConst.PcMuteState.MuteAudio;
        } else if (videoMuted == true) {
            this_.muted_ = WrsConst.PcMuteState.MuteVideo;
        } else {
            this_.muted_ = WrsConst.PcMuteState.MuteNone;
        }

        this_._trace('Call mute changed (current=' + this_.muted_ + ')');
        this_._updateMuteUnMuteHoldState();
    }

    this_._holdUnhold = function (hold, isEvent) {
        if (this_.hold_ != hold) {
            this_.hold_ = hold;

            this_._trace('Call hold changed (current=' + this_.hold_ + ')');
            this_._updateMuteUnMuteHoldState();

            if (isEvent) {
                // notify user
                this_._gotHoldUnholdEvent();
            } else {
                // notify other parties
                var json = { type: "holdav", hold: hold };
                this_._send(json);
            }
        }
    }

    this_._updateMuteUnMuteHoldState = function () {
        if (this_.userMedia_ !== null) {
            var audioEnabled = true;
            var videoEnabled = true;

            if (this_.hold_) {
                audioEnabled = false;
                videoEnabled = false;
            } else {
                if (this_.muted_ == WrsConst.PcMuteState.MuteAudioVideo) {
                    audioEnabled = false;
                    videoEnabled = false;
                } else if (this_.muted_ == WrsConst.PcMuteState.MuteAudio) {
                    audioEnabled = false;
                } else if (this_.muted_ == WrsConst.PcMuteState.MuteVideo) {
                    videoEnabled = false;
                }

                if (this_.mutedInternal_ == WrsConst.PcMuteState.MuteAudioVideo) {
                    audioEnabled = false;
                    videoEnabled = false;
                } else if (this_.mutedInternal_ == WrsConst.PcMuteState.MuteAudio) {
                    audioEnabled = false;
                } else if (this_.mutedInternal_ == WrsConst.PcMuteState.MuteVideo) {
                    videoEnabled = false;
                }
            }

            this_.userMedia_.forEach(function (stream) {
                if (stream.wrsOriginalAudioTracks_ === undefined) {
                    // when the call is put on hold or this is not a mixer stream, we hold the 
                    // input stream (i.e. there i no mixer stream for this stream)
                    stream.getAudioTracks().forEach(function (track) {
                        track.enabled = audioEnabled;
                    });
                } else {
                    // when the call is muted, we only disable input tracks for the mixer stream 
                    // if mixing is enabled

                    stream.wrsOriginalAudioTracks_.forEach(function (track) {
                        track.enabled = audioEnabled;
                    });

                    stream.getAudioTracks().forEach(function (track) {
                        track.enabled = !this_.hold_;
                    });
                }
            })

            this_.userMedia_.forEach(function (stream) {
                stream.getVideoTracks().forEach(function (track) {
                    track.enabled = videoEnabled;
                });
            });
        }
    }

    this_._close = function () {
        this_.remoteTracks_ = null;
        this_.remoteStreams_ = null;
        
        if (this_.dtmf_  != null) {
            this_.dtmf_.close();
        }

        if (this_.userMedia_ !== null) {
            this_.userMedia_.forEach(function (stream) {
                stream.getTracks().forEach(function (track) {
                    track.stop();
                });

                if (stream.wrsMixer_ != undefined) {
                    stream.wrsMixer_.close();
                }
            });

            this_.userMedia_ = null;
        }

        this_.recorder_.stop();
        this_._reInitPc();

        if (this_.temporaryDisconnectTimer_ !== null) {
            clearTimeout(this_.temporaryDisconnectTimer_);
            this_.temporaryDisconnectTimer_ = null;
        }

        this_._clearTimers();

        this_.connected_ = false;
        this_._setState(WrsConst.PcState.Disposed);
        this_._clearRemoteAudioStreamTimer();
    }

    this_._clearTimers = function () {
        for (var timer in this_.miscellaneousTimers_) {
            if (this_.miscellaneousTimers_.hasOwnProperty(timer)) {
                if (this_.miscellaneousTimers_[timer] !== null) {
                    clearTimeout(this_.miscellaneousTimers_[timer]);
                    this_.miscellaneousTimers_[timer] = null;
                }
            }
        }

        this_.miscellaneousTimers_ = {};
    }

    this_._trace = function (message) {
        var now = (window.performance.now() / 1000).toFixed(3);

        try {
            this_.onTrace(now + '|WRS|' + this_.myId_ + '|' + message);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._addStream = function (stream) {
        // get the owner info from stream object
        var ownerId = WrsUtilsInternalInst.getStreamOwner(stream, this_.getId());

        if (this_.splitAv_) {
            stream.getTracks().forEach(function (track) {
                // in split mode add audio/video to separate pc
                if (track.kind == "audio") {
                    this_.pc_.addTrack(track, stream);
                } else {
                    this_.pc2_.addTrack(track, stream);
                }
            });
        } else {
            stream.getTracks().forEach(function (track) {
                this_.pc_.addTrack(track, stream);
            });
        }

        //Added check to validate if a screenshare stream is being added
        if (WrsUtils.isScreenshareStream(stream)) {
            //If it is, then we save the stream id as a screenshare stream
            this_.screenshareStreamId_ = stream.id;
            this_._trace('Changed screen share stream to ' + stream.id);
        }    

        if (this_.localStreams_.some(function (elem) { return elem.id === stream.id; })) {
            this_._trace('Modified stream ' + stream.id);
        } else {               
            this_.localStreams_.push({ id: stream.id, owner: ownerId });
            this_._trace('Added stream ' + stream.id);
        }
    }

    this_._removeStream = function (stream) {
        if (this_.splitAv_) {
            stream.getTracks().forEach(function (track) {
                // in split mode add audio/video to separate pc
                if (track.kind == "audio") {
                    this_.pc_.removeTrack(track);
                } else {
                    this_.pc2_.removeTrack(track);
                }
            });
        } else {
            stream.getTracks().forEach(function (track) {
                this_.pc_.removeTrack(track);
            });
        }

        var count = 0;
        var i = 0;
        while (i < this_.localStreams_.length) {
            if (this_.localStreams_[i].id == stream.id) {
                this_.localStreams_.splice(i, 1);
                count++;
            } else {
                i++;
            }
        }

        if (count > 0) {
            if (this_.screenshareStreamId_ == stream.id) {
                this_.screenshareStreamId_ = null;
                this_._trace('Removed screen share stream ' + stream.id);
            } else {
                this_._trace('Removed stream ' + stream.id);
            }
        }
    }

    this_._modifyStream = function (stream) {
        // TODO: allow changing facing mode using RTPSender.setConstraints

        var previousTracks = [];
        if (this_.splitAv_) {
            previousTracks.push.apply(previousTracks, this_.pc_.getTracksForLocalStream(stream));

            if (this_.pc2_ != null) {
                previousTracks.push.apply(previousTracks, this_.pc2_.getTracksForLocalStream(stream));
            }
        } else {
            previousTracks.push.apply(previousTracks, this_.pc_.getTracksForLocalStream(stream));
        }

        var newTrackMap = { }
        stream.getTracks().forEach(function (track) {
            newTrackMap[track.id] = true;
        });

        // handle removed tracks
        if (this_.splitAv_) {
            previousTracks.forEach(function (track) {
                // in split mode add audio/video to separate pc
                if (newTrackMap[track.id] !== undefined) {
                    // keep the track
                } else if (track.kind == "audio") {
                    this_.pc_.removeTrack(track);
                } else {
                    this_.pc2_.removeTrack(track);
                }
            });
        } else {
            previousTracks.forEach(function (track) {
                if (newTrackMap[track.id] !== undefined) {
                    // keep the track
                } else {
                    this_.pc_.removeTrack(track);
                }
            });
        }

        // handle added tracks
        this_._addStream(stream);
    }

    this_._reInitPc = function () {
        if (this_.pc_ !== undefined && this_.pc_ !== null) {
            this_.pc_.close();
            this_.pc_ = null;
        }

        if (this_.splitAv_ && this_.pc2_ !== undefined && this_.pc2_ !== null) {
            this_.pc2_.close();
            this_.pc2_ = null;
        }

        if (this_.splitAv_) {
            this_.pc_ = this_._createPcInternal(WrsConst.PcType.Audio);
            this_.pc2_ = this_._createPcInternal(WrsConst.PcType.Video);
        } else {
            this_.pc_ = this_._createPcInternal(WrsConst.PcType.Combined);
        }
    }

    this_._createPc = function (streams, isOffer) {
        this_.remoteTracks_ = {};
        this_.remoteStreams_ = {};
        this_.remoteStreamInfo_ = {};
        this_.localStreams_ = [];

        var configurations = this_.configs_.getWebRTCConfigurations();
        if (this_.splitAv_) {
            this_.pc_.open(configurations);
            this_.pc2_.open(configurations);
        } else {
            this_.pc_.open(configurations);
        }

        this_._trace('Created local peer connection objects ' + (isOffer ? '(offer)' : '(answer)'));

        this_.audioThreshold_ = this_.configs_.isAudioLevelCheckEnabled() ?
            this_.configs_.getAudioLevelThreshold() : this_.audioThreshold_;

        if (streams != null) {
            streams.forEach(function (stream) {
                this_._addStream(stream);
            });

            this_._trace('Added local streams');
        }
    }

    this_._createPcInternal = function (type) {
        var pc = new WrsNativePeerConnectionWrapper(type, this_._trace, this_.statsifs_);

        pc.onicecandidate = function (o, e) {
            this_._onIceCandidate(o, e);
        }

        pc.oniceconnectionstatechange = function (o, e) {
            this_._onIceStateChange(o, e);
        }

        pc.onnegotiationneeded = function (o, e) {
            this_._onRenegotiate(o, e);
        }

        pc.ontrack = function (o, e) {
            var t = o.getType();
            if (this_.remoteTracks_[t] == null) {
                this_.remoteTracks_[t] = [];
            }

            this_.remoteTracks_[t].push(e);
        }

        pc.onrequesttimeout = function (o) {
            this_._onRequestTimeout(o);
        }

        pc.state = WrsConst.PcState.Initial;

        return pc;
    }

    this_._onCreateOfferSuccess = function (pc, desc) {
        this_._trace('Offer created \n' + desc.sdp);

        desc = this_._mungSdp(desc);

        pc.setLocalDescription(desc).then(this_._onSetLocalSuccess
            , this_._onSetSessionDescriptionError);

        var json = this_._sdp2json(pc, desc);

        if (!this_.callParameters_.create) {
            json.join = true;
            json.mode = this_.callParameters_.mode;
        }

        json.userAgent = this_._getUserAgentObj();
        json.streamInfo = this_._getStreamInfo();
        json.owner = this_.channel_.getId();

        pc.state = WrsConst.PcState.OfferSent;

        this_._send(json);
        this_._trace('SDP.offer (' + pc.getType() + ') sent');
    }

    this_._getStreamInfo = function () {
        var json = {};
        var id = this_.channel_.getId();
        this_.localStreams_.forEach(function (s) {
            var info = { owner: s.owner };
            if (s.id === this_.screenshareStreamId_) {
                info.type = "screenshare";
            }
            json[s.id] = info;
        });
        return json;
    }

    this_._getUserAgentObj = function () {
        return WrsUtils.getUserAgentInfo();
    }

    this_._mungSdp = function (desc) {
        var strsdp = desc.sdp;
        var start = 0;

        strsdp = strsdp.split('\r\n').join('\n');	// convert all line endings to \n
        var sdpLines = strsdp.split('\n');
        var sdpLinesUpdated = [];

        var addCT = (this_.configs_.getConnectionBandwidthUpperLimit() != 0);
        var addAAS = (this_.configs_.getAudioTrackBandwidthUpperLimit() != 0);
        var addVAS = (this_.configs_.getVideoTrackBandwidthUpperLimit() != 0);
        var codecSelect = (this_.configs_.enableCdcAutoSelection() == false);

        var section = 0; // 0=SDP; 1=Audio; 2=Video; 3=Other
        var bwAdded = false;

        sdpLines.forEach(function (line, index, arr) {
            if (line.startsWith('m=')) {
                bwAdded = false;

                if (line.startsWith('m=video')) {
                    // video media
                    section = 2;
                    var videoItems = line.split(' ');

                    if (codecSelect) {
                        // remove vp8 item
                        var vp8Index = videoItems.indexOf('96');
                        if (vp8Index < 0 || vp8Index < 3) {
                            this_._trace('Mung SDP : vp8 not specified [' + vp8Index
                                + '] at line ' + (index + 1));
                        } else {
                            videoItems.splice(vp8Index, 1);
                            videoItems.splice(3, 0, '96');
                        }

                        // remove vp9 item
                        var vp9Index = videoItems.indexOf('98');
                        if (vp9Index < 0 || vp9Index < 3) {
                            this_._trace('Mung SDP : vp9 not specified [' + vp9Index
                                + '] at line ' + (index + 1));
                        } else {
                            videoItems.splice(vp9Index, 1);
                            videoItems.splice(3, 0, '98');
                        }
                    }

                    var lineUpdated = videoItems.join(' ');
                    sdpLinesUpdated.push(lineUpdated);
                } else if (line.startsWith('m=audio')) {
                    section = 1;
                    sdpLinesUpdated.push(line);
                } else {
                    section = 3;
                    sdpLinesUpdated.push(line);
                }
            } else if (bwAdded == false && addCT == true && section == 0 && line.startsWith('s=')) {
                sdpLinesUpdated.push(line);
                sdpLinesUpdated.push('b=CT:' + this_.configs_.getConnectionBandwidthUpperLimit());
                bwAdded = true;
            } else if (bwAdded == false && addAAS == true && section == 1 && line.startsWith('a=mid:')) {
                sdpLinesUpdated.push(line);
                sdpLinesUpdated.push('b=AS:' + this_.configs_.getAudioTrackBandwidthUpperLimit());
                bwAdded = true;
            } else if (bwAdded == false && addVAS == true && section == 2 && line.startsWith('a=mid:')) {
                sdpLinesUpdated.push(line);
                sdpLinesUpdated.push('b=AS:' + this_.configs_.getVideoTrackBandwidthUpperLimit());
                bwAdded = true;
            } else if ((section == 0 || section == 1 || section == 2) && line.startsWith('b=')) {
                // 'b=' alrady added so we skip this
            } else {
                sdpLinesUpdated.push(line);
            }
        });

        var strsdpUpdated = sdpLinesUpdated.join('\r\n');
        desc.sdp = strsdpUpdated;

        this_._trace('SDP munged \n' + desc.sdp);

        return desc;
    }

    this_._send = function (json) {
        json.intent = this_.intent_;
        this_.channel_.send(json);
    }

    this_._sendAck = function (msg, rejected) {
        var reply = {
            type : "ackav",
            originalType: msg.type,
        }

        if (msg.avlsequence !== undefined) {
            reply.originalSequence = msg.avlsequence;
        }

        if (rejected !== undefined && rejected !== null) {
            reply.rejected = true;
            reply.rejectedReason = ("" + rejected);
        }

        this_._send(reply);
    }

    this_.recorder_.onTrace = function (message) {
        this_.onTrace(message);
    }

    this_.channel_.onMessage = function (json) {
        // filter out unwanted messages
        if (json == null || json == undefined) {
            return false;
        }

        var intent = (json.intent == null ? "call" : json.intent);
        if (intent != this_.intent_) {
            // this message is not intended for this call
            return false;
        }

        if (!WrsUtilsInternalInst.isKnownWebRTCMessage(json, 7)) {
            if (this_.onMessage != null) {
                return this_.onMessage(json);   // pass the message downwards the channel hierachy
            } else {
                return false;
            }
        }

        var rejected = false;
        var rejectReason = "";

        if (this_.connectionMode_ == WrsConnectionModes.Direct && WrsUtilsInternalInst.isKnownWebRTCMessage(json, 1)) {
            this_._trace('Ignored unexpected message in current connection mode');
            rejected = true;
            rejectReason = "unexpected message in current connection mode";
        } else if (this_.connectionMode_ == WrsConnectionModes.Normal && WrsUtilsInternalInst.isKnownWebRTCMessage(json, 4)) {
            this_._trace('Ignored unexpected message in current connection mode');
            rejected = true;
            rejectReason = "unexpected message in current connection mode";
        }
        else if (this_._state() < WrsConst.PcState.Initial) {
            this_._trace('Ignored message "' + json.type  + '" from channel due to error state');
            rejected = true;
            rejectReason = "unexpected message in current state";
        }

        if (rejected) {
            if (json.type == "offer" || json.type == "answer" || json.type == "pranswer"
                || json.type == "direct:offer" || json.type == "direct:answer" || json.type == "direct:pranswer") {
                // send ack
                this_._sendAck(json, rejectReason);
            }
            return true;
        }

        var flip = (this_.connectionMode_ == WrsConnectionModes.DirectAudio)
            || (this_.connectionMode_ == WrsConnectionModes.Direct);

        var pc1 = (flip) ? this_.pc2_ : this_.pc_;

        var pc2 = (flip) ? this_.pc_ : this_.pc2_;

        // handle messages
        if (json.type == "candidate") {
            pc1.addIceCandidate(json);
        } else if (json.type == "offer") {
            this_._sendAck(json);

            if (this_.isMsUsed_ === undefined) {
                // NOTE: Media server does not set the user agent in SDP message. We can use this to distinguish
                // if this call is going through MS.
                this_.isMsUsed_ = (json.userAgent === undefined);
            }

            this_.callParameters_.create = false;
            if (json.hasOwnProperty("mode")) {
                this_.callParameters_.mode = json.mode;
            } else {
                this_.callParameters_.mode = "conference";
            }

            if (pc1.state == WrsConst.PcState.Initial) {
                // new connection
                this_._onSdpOffer(pc1, json);
            } else {
                // renegotiation
                this_._onSdpRenegoatiate(pc1, json);
            }
        } else if (json.type == "answer" || json.type == "pranswer") {
            this_._sendAck(json);

            if (this_.isMsUsed_ === undefined) {
                // NOTE: Media server does not set the user agent in SDP message. We can use this to distinguish
                // if this call is going through MS.
                this_.isMsUsed_ = (json.userAgent === undefined);
            }

            this_.callParameters_.create = false;
            this_._onSdpAnswer(pc1, json);
        } else if (json.type == "direct:candidate") {
            json.type = "candidate";
            pc2.addIceCandidate(json);
        } else if (json.type == "direct:offer") {
            this_._sendAck(json);

            json.type = "offer";
            if (pc2 == null || pc2.state == WrsConst.PcState.Initial) {
                // new connection
                this_._onSdpOffer(pc2, json);
            } else {
                // renegotiation
                this_._onSdpRenegoatiate(pc2, json);
            }
        } else if (json.type == "direct:answer" || json.type == "direct:pranswer") {
            this_._sendAck(json);

            json.type = (json.type == "direct:answer") ? "answer" : "pranswer";

            this_.callParameters_.create = false;
            this_._onSdpAnswer(pc2, json);
        } else if (json.type == "holdav") {
            var hold = (json.hold == true);
            this_._holdUnhold(hold, true);
        } else if (json.type == "endav") {
            if (json.param === "screenshare") {
                // Note: Hack to ignore screenshare endeav messages when used without callsdk
                return false;
            }

            this_._trace('Terminating call upon endav');
            if (this_.connected_) {
                this_._gotDisconnected();
            }
            this_._close();
            return false;   // handover this message to upper layer as well
        } else if (json.type == "eventav") {
            // trigger track event if track available
            this_._onAvEvent(json);
        } else if (json.type == "ackav") {
            // these are ack messages and nothing to do here
            // usually these messages will be intercepted by server side and consumed for monitoring
        } else {
            this_._trace('Ignored unidentified message type "' + json.type + '"');
        }

        return true;
    }

    this_._onAvEvent = function (json) {
        var event = (json.event == "connected") ? WrsStreamEvents.Connected
            : (json.event == "disconnected") ? WrsStreamEvents.Disconnected
            : (json.event == "ended") ? WrsStreamEvents.Ended
            : undefined;

        if (!this_.connected_ || event === undefined) {
            return;
        }

        if (json.streams === undefined) {
            json.streams = [ ];
        }

        json.streams.forEach(function (stream) {
            if (this_.remoteStreams_[stream] !== undefined) {
                this_._trace('Stream ' + stream + ' status changed to ' + json.event);
                this_._gotStreamStatusChange(stream, event);
            } else {
                this_._trace('Stream ' + stream + ' (unknown) status changed to ' + json.event);
            }
        });
    }

    this_._onSdpAnswer = function (pc, json) {
        if (pc.state != WrsConst.PcState.OfferSent) {
            this_._trace('Answer received unexpectedly is ignored (state='
                + pc.state + '; pc=' + pc.getType() + ')');
            return;
        }

        this_._trace('SDP.answer received for ' + pc.getType() + '\n' + json.sdp);

        this_.recorder_.setRemoteUserAgent(json.userAgent);
        this_._mergeStreamInfo(json.streamInfo);

        var desc = new RTCSessionDescription(json);

        pc.setRemoteDescription(desc).then(function () {
            this_._onSetRemoteSuccess(pc, true);
        }, this_._onSetSessionDescriptionError);
    }

    this_._onSdpOffer = function (pc, offer) {
        if (this_._state() != WrsConst.PcState.Initial && this_._state() != WrsConst.PcState.Intermediate) {
            this_._trace('Offer received unexpectedly is ignored (state='
                + this_._state() + ')');
            return;
        }

        var oneOfferRecieved = false;
        if (this_._state() != WrsConst.PcState.Initial) {
            oneOfferRecieved = true;
        }

        this_._trace('SDP.offer received for ' + pc.getType() + '\n' + offer.sdp);

        this_.connected_ = false;
        this_.incoming_ = true;

        if (!oneOfferRecieved) {
            this_._gotCallRequest();
        }

        var constraints = this_.configs_.getMediaConstraints();
        pc.state = WrsConst.PcState.Starting;

        if (oneOfferRecieved) {
            this_._mergeStreamInfo(offer.streamInfo);
            this_._doSdpRenegoation(pc, offer);
        } else {
            this_._trace('Incoming Call');
            this_._trace('Using WebClientAPI version ' + WrsJsVersion + '(build ' + WrsBuildTime__ + ')');

            this_.recorder_.setRemoteUserAgent(offer.userAgent);

            this_._onAcquireUserMedia(constraints, function (streams) {
                this_.userMedia_ = streams;
                this_._createPc(streams, false);

                this_._mergeStreamInfo(offer.streamInfo);

                this_._doSdpRenegoation(pc, offer);
                this_._gotLocalStream(streams, false);
                this_._updateMuteUnMuteHoldState();
            });
        }
    }

    this_._mergeStreamInfo = function (info) {
        if (this_.remoteStreamInfo_ == null) {
            this_.remoteStreamInfo_ = {};
        }

        if (info !== undefined) {
            for (var key in info) {
                if (info.hasOwnProperty(key)) {
                    this_.remoteStreamInfo_[key] = info[key];
                }
            }
        }
    }

    this_._onSdpRenegoatiate = function (pc, offer) {
        if (pc.state != WrsConst.PcState.Connected) {
            this_._trace('Offer received unexpectedly is ignored (state='
                + pc.state + '; pc=' + pc.getType() + ')');
            return;
        }

        pc.state = WrsConst.PcState.Renegotiating;
        this_._trace('SDP.renegoatiate received for ' + pc.getType() + '\n' + offer.sdp);

        this_._mergeStreamInfo(offer.streamInfo);
        this_._doSdpRenegoation(pc, offer);
    }

    this_._doSdpRenegoation = function (pc, offer) {
        var desc = new RTCSessionDescription(offer);
        pc.setRemoteDescription(desc).then(function () {
            this_._onSetRemoteSuccess(pc, false);
        }, this_._onSetSessionDescriptionError);
    }

    this_._consolidateRecievedTracks = function (events) {
        if (events == null)
            return;

        var mergedEvents = [];
        events.forEach(function (e) {
            var trackEvent = {
                receiver: e.receiver,
                track: e.track,
                streams: [],
                transceiver: e.transceiver
            }

            var unique = {};

            e.streams.forEach(function (stream, index) {
                if (this_.remoteStreams_[stream.id] == null) {
                    var newStream = new MediaStream();
                    this_.remoteStreams_[stream.id] = newStream;
                    this_.remoteStreamInfo_[newStream.id] = this_.remoteStreamInfo_[stream.id];
                }

                stream.getTracks().forEach(function (track) {
                    // Note: sometimes, when the ssrc changes, we get a track with same ID but internally different
                    // we do this trick to verify if the track is identical and if not we need to remove the duplicate 
                    // before adding the new one.
                    var oldTrack = this_.remoteStreams_[stream.id].getTrackById(track.id);
                    if (oldTrack != null) {
                        // check if stream is same
                        var tmpStream = new MediaStream();
                        tmpStream.addTrack(oldTrack);
                        tmpStream.removeTrack(track);
                        var isStreamIdentical = (tmpStream.getTrackById(track.id) == null);
                        tmpStream.removeTrack(oldTrack);

                        if (!isStreamIdentical) {
                            this_.remoteStreams_[stream.id].removeTrack(oldTrack);
                        }
                    }

                    this_.remoteStreams_[stream.id].addTrack(track);
                });

                if (!unique[stream.id]) {
                    unique[stream.id] = true;
                    trackEvent.streams.push(this_.remoteStreams_[stream.id]);
                }
            });

            mergedEvents.push(trackEvent);
        });

        // NOTE: This will add tracks of unrelated streams to single stream. When
        // a stream has only 1 audio track or only 1 video tracks, it will find a suitable
        // stream with a video (for audio) track, or with a audio (for video) track 
        // and merge to a single stream. The match is not based on any other attribute 
        // of the streams. The merging is only done if the track of that stream is only 
        // attached that stream (i.e. only if attached to no other stream).
        var mergeAloneStreams = this_.configs_.tryToMergeSingleTrackStreamsFromDifferentSources();
        if (mergeAloneStreams) {
            mergedEvents.forEach(function (e) {
                if ((e.streams.length == 1) && (e.streams[0].getTracks().length == 1)) {
                    var suitableMatch = null;
                    var track = e.streams[0].getTracks()[0];
                    var kind = track.kind;

                    for (var key in this_.remoteStreams_) {
                        if (this_.remoteStreams_.hasOwnProperty(key)) {
                            var stream = this_.remoteStreams_[key];
                            if (stream.getTracks().length == 1) {
                                if (stream.getTracks()[0].kind != kind) {
                                    suitableMatch = key;
                                    break;
                                }
                            }
                        }
                    }

                    if (suitableMatch != null) {
                        var oldStream = e.streams[0];
                        var newStream = this_.remoteStreams_[suitableMatch];

                        var oldTrack = oldStream.getTrackById(track.id);
                        if (oldTrack != null) {
                            oldStream.removeTrack(oldTrack);
                        }

                        newStream.addTrack(track);

                        e.streams = [];
                        e.streams.push(newStream);
                    }
                }
            });
        }

        mergedEvents.forEach(function (e) {
            this_._gotRemoteStream(e);
        });

        // start recording streams if necessary
        this_._setupUIRecordingForStreams(mergedEvents);
    }

    this_._setupUIRecordingForStreams = function (events) {
        if (this_.recorder_.enabled() == false) {
            this_._trace('FE recording disabled');
            return;
        }

        events.forEach(function (e) {
            e.streams.forEach(function (stream) {
                this_.recorder_.add(stream, WrsConst.PcMediaSource.RemoteAudioVideo);
            })
        });
    }

    this_._onSetRemoteSuccess = function (pc, isOffer) {
        this_._trace('setRemoteDescription completed for ' + pc.getType());

        if (!isOffer) {
            if (pc.state != WrsConst.PcState.Renegotiating) {
                pc.state = WrsConst.PcState.OfferRecieved;
            }
            var answerOptions = this_.configs_.getAnswerOptions();

            pc.createAnswer(answerOptions).then(function (desc) {
                this_._onCreateAnswerSuccess(pc, desc);
            }).catch(function (e) {
                this_._onCreateSessionDescriptionError(e);
            });
        } else {
            // move to answer received; then move to connected without a input
            pc.state = WrsConst.PcState.AnswerRecieved;
            pc.state = WrsConst.PcState.Connected;

            this_._consolidateRecievedTracks(this_.remoteTracks_[pc.getType()]);
            this_.remoteTracks_[pc.getType()] = null;

            if (this_._state() == WrsConst.PcState.Connected) {
                if (this_.connected_ == false) {
                    this_._gotConnected();
                }
            } else {
                this_._trace('awaiting answers for other streams');
            }
        }
    }

    this_._onCreateAnswerSuccess = function (pc, desc) {
        this_._trace('Answer created for ' + pc.getType() + '\n' + desc.sdp);

        desc = this_._mungSdp(desc);

        pc.setLocalDescription(desc).then(function () {
            this_._onSetLocalSuccess();
            pc.state = WrsConst.PcState.Connected;

            this_._consolidateRecievedTracks(this_.remoteTracks_[pc.getType()]);
            this_.remoteTracks_[pc.getType()] = null;

            if (this_._state() == WrsConst.PcState.Connected) {
                if (this_.connected_ == false) {
                    this_._gotConnected();
                }
            }
        }, this_._onSetSessionDescriptionError);

        pc.state = WrsConst.PcState.AnswerSent;

        var json = this_._sdp2json(pc, desc);
        json.userAgent = this_._getUserAgentObj();
        json.streamInfo = this_._getStreamInfo();
        json.owner = this_.channel_.getId();

        this_._send(json);
        this_._trace('SDP.answer sent back for ' + pc.getType());
    }

    this_._onCreateSessionDescriptionError = function (error) {
        this_._setState(WrsConst.PcState.Error);
        this_._trace('Failed to create session description: ' + error);
        this_._gotError(WrsErrorCodes.CREATE_SDP_FAILED, 'Failed to create Session Description');
    }

    this_._onSetSessionDescriptionError = function (error) {
        this_._setState(WrsConst.PcState.Error);
        this_._trace('Failed to set session description: ' + error);
        this_._gotError(WrsErrorCodes.SET_SDP_FAILED, 'Failed to set Session Description');
    }

    this_._onSetLocalSuccess = function () {
        this_._trace('setLocalDescription complete');
    }

    this_._onRequestTimeout = function (o) {
        this_._gotError(WrsErrorCodes.REQUEST_TIMED_OUT, 'Timeout while waiting for response');

        if (this_.connected_) {
            this_._gotDisconnected();
        }

        this_._close();
    }

    this_._onIceStateChange = function (pc, event) {
        this_._trace('ICE state of ' + pc.getType() + ' change to: ' + pc.getIceConnectionState());
        if (pc.getIceConnectionState() == 'failed' || pc.getIceConnectionState() == 'closed') {
            this_._gotDisconnected();
            this_._close();
        } else if (pc.getIceConnectionState() == 'disconnected') {
            // ICE disconnected timer start
            if (pc.getType() == WrsConst.PcType.Audio || pc.getType() == WrsConst.PcType.Combined) {
                this_.temporaryDisconnect_ = true;

                if (this_.temporaryDisconnectTimer_ === null) {
                    this_.temporaryDisconnectTimer_ = setTimeout(function () {
                        this_.temporaryDisconnectTimer_ = null;
                        this_._trace('Disconnecting after audio failed');
                        this_._gotDisconnected();
                        this_._close();
                    }, 20000);
                }

                if (pc.getType() == WrsConst.PcType.Audio) {
                    this_.mutedInternal_ = WrsConst.PcMuteState.MuteVideo;
                    this_._updateMuteUnMuteHoldState();
                }

                // let the uesr know about the temporary disconnect
                this_._gotTempDisconnected();

                this_._trace('Temporary disconnect detected');
            }

            // wait for 3 seconds and try trigger a ICE restart
            this_.miscellaneousTimers_["iceRestart"] = setTimeout(function () {
                this_.miscellaneousTimers_["iceRestart"] = null;
                this_._triggerIceRestart();
            }, 3000);
        } else if (pc.getIceConnectionState() == 'connected' || pc.getIceConnectionState() == 'completed') {
            if (this_.temporaryDisconnect_) {
                if (pc.getType() == WrsConst.PcType.Audio || pc.getType() == WrsConst.PcType.Combined) {
                    this_.temporaryDisconnect_ = false;

                    if (pc.getType() == WrsConst.PcType.Audio) {
                        this_.mutedInternal_ = WrsConst.PcMuteState.MuteNone;
                        this_._updateMuteUnMuteHoldState();
                    }

                    if (this_.temporaryDisconnectTimer_ !== null) {
                        clearTimeout(this_.temporaryDisconnectTimer_);
                        this_.temporaryDisconnectTimer_ = null;
                    }

                    // let the user know about the reconnect after temporary disconnect
                    this_._gotReconnected();

                    this_._trace('Reconnected after temporary disconnect');
                }
            }
        }

        // expose the ice state change to the api
        this_._gotIceStateChange(pc.getIceConnectionState());
    }

    this_._triggerIceRestart = function () {
        if (this_.incoming_)
            return; // receiving side should not initiate a ICE restart

        if (navigator.onLine === false) {
            this_.miscellaneousTimers_["iceRestart"] = setTimeout(function () {
                this_.miscellaneousTimers_["iceRestart"] = null;
                this_._triggerIceRestart();
            }, 3000);
            return;
        }

        this_._trace('ICE restart triggered');

        if (this_.pc_.getIceConnectionState() != 'connected'
            && this_.pc_.getIceConnectionState() != 'completed') {
            // trigger ICE restart on primary PC
            this_._doRenegotiate(this_.pc_, true);
        }

        if (this_.splitAv_ && this_.pc2_.getIceConnectionState() != 'connected'
            && this_.pc2_.getIceConnectionState() != 'completed') {
            // trigger ICE restart on secondary PC
            this_._doRenegotiate(this_.pc2_, true);
        }
    }

    this_._onIceCandidate = function (pc, event) {
        if (event.candidate === null) {
            return;
        }

        var json = event.candidate.toJSON();

        var isDirect = (this_.connectionMode_ == WrsConnectionModes.Direct)
            || (this_.connectionMode_ == WrsConnectionModes.DirectAudio && pc.getType() == WrsConst.PcType.Audio)
            || (this_.connectionMode_ == WrsConnectionModes.DirectVideo && pc.getType() == WrsConst.PcType.Video);

        if (!isDirect) {
            // we send split audio or non-split mode media without modification so that they will 
            // go through media server if a media server is  present 
            json.type = "candidate";
        } else {
            // we send split video with a modified type so that it will reach the other end bypassing
            // media server (if any) in between
            json.type = "direct:" + "candidate";
        }

        json.id = event.candidate.sdpMid;
        json.label = event.candidate.sdpMLineIndex;
        this_._send(json);

        this_._trace('ICE candidate sent for ' + pc.getType() + ' \n'
            + (event.candidate ? event.candidate.candidate : '(null)'));
    }

    this_._onRenegotiate = function (pc, e) {
        this_._doRenegotiate(pc, false);
    }

    this_._doRenegotiate = function (pc, iceRestart) {
        var offerOptions = this_.configs_.getOfferOptions();
        if (offerOptions === undefined) {
            offerOptions = { };
        }

        offerOptions.iceRestart = (iceRestart == true);

        pc.createOffer(offerOptions).then(function (desc) {
            this_._onCreateOfferSuccess(pc, desc);
        }).catch(function (e) {
            this_._onCreateSessionDescriptionError(e);
        });
    }

    this_._gotLocalStream = function (streams, isOffer) {
        var output = [];

        if (streams != null) {
            streams.forEach(function (stream) {
                output.push(stream);
            });
        }

        this_._trace('Acquired local streams [' + output.length + ']');

        if (output.length == 0)
            return;

        Object.freeze(output);

        try {
            this_.onAcquireVideo(output);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotRemoteStream = function (event) {
        this_._trace('Received remote stream');

        var streamInfo = {};
        event.streams.forEach(function (s) {
            if (this_.remoteStreamInfo_[s.id] != null) {
                streamInfo[s.id] = this_.remoteStreamInfo_[s.id];

                var objAudTrack = s.getAudioTracks();

                if (null !== objAudTrack && undefined !== objAudTrack) {
                    objAudTrack.forEach(function (item) {
                        this_.remoteAudioStreamInfo_[item.id] = s.id;
                    });
                }
            }
        });

        try {
            this_.onAddVideo(event.streams, streamInfo);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotCallRequest = function () {
        try {
            this_.onCallRequest();
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotConnected = function () {
        this_.connected_ = true;

        try {
            this_.onConnect();
        } catch (e) {
            // we ignore exceptions by user code
        }
        if (this_.configs_.isAudioLevelCheckEnabled()) {
            this_.fetchStatIntervalFn_ = setInterval(function () {
                //check if the peer connection is available
                if (this_.pc_) {
                    //get the stats and expose it the initiator channel
                    this_.pc_.getStats(this_._getAudioLevel);
                }
                else {
                    this_._trace("RTCPeerConnection is not available to get audiolevel.. stopping timer");
                    //clear the stats interval
                    if(undefined !== this_.fetchStatIntervalFn_)
                    {
                        clearTimeout(this_.fetchStatIntervalFn_);
                        this_.fetchStatIntervalFn_ = undefined;
                    }
               }
            }, 1000);
        }
    }

    // on temporary disconnect
    this_._gotTempDisconnected = function () {
        try {
            // expose to the API's onReconnecting
            this_.onReconnecting();
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    // on connect after temporary disconnect
    this_._gotReconnected = function () {
        try {
            // expose to the API's onReconnected
            this_.onReconnected();
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    // on ice state change event
    this_._gotIceStateChange = function (state) {
        try {
            // expose to the API's onIceStateChanged
            this_.onIceStateChanged(state);
        } catch (e) {
            // we ignore exceptions by user code
        }
    };

    this_._gotDisconnected = function () {
        try {
            this_.onDisconnect();
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotError = function (code, msg) {
        try {
            this_.onError(code, msg);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotHoldUnholdEvent = function () {
        try {
            this_.onHoldUnhold(this_.hold_);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._gotStreamStatusChange = function (stream, event) {
        try {
            this_.onStreamStatusChange(stream, event);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._sdp2json = function (pc, desc) {
        var json = {};

        var isDirect = (this_.connectionMode_ == WrsConnectionModes.Direct)
            || (this_.connectionMode_ == WrsConnectionModes.DirectAudio && pc.getType() == WrsConst.PcType.Audio)
            || (this_.connectionMode_ == WrsConnectionModes.DirectVideo && pc.getType() == WrsConst.PcType.Video);

        if (!isDirect) {
            // we send split audio or non-split mode media without modification so that they will 
            // go through media server if a media server is  present 
            json["type"] = desc.type;
        } else {
            // we send split video with a modified type so that it will reach the other end bypassing
            // media server (if any) in between
            json["type"] = "direct:" + desc.type;
        }

        json["sdp"] = desc.sdp;
        return json;
    }

    this_._parseStats = function (statsReport) {
        try {
            if (!statsReport || (Array.isArray(statsReport) &&
                Object.prototype.toString.call(statsReport.values) !== '[object Array]')) {
                return null;
            }
            const neutralResults = [];
            if (typeof statsReport !== 'undefined') {
                statsReport.forEach((value, key) => {
                    neutralResults.push({ key, value });
                });
            } else if (Object.keys(statsReport).length > 0) {
                Object.keys(statsReport).forEach(key => {
                    neutralResults.push({
                        key,
                        value: statsReport[key]
                    });
                });
            } else {
                console.log('Unknown stats results format, returning unmodified', statsReport);
                return statsReport;
            }
            return neutralResults;
        }
        catch (e) {
            console.log("Parse stat error: " + e);
            return null;
        }
    }

    this_._getAudioLevel = function (stats) {
        var neutralResults = this_._parseStats(stats);
        if (neutralResults == null) {
            console.log("Unknown stats format");
            return;
        }

        try {

            for (let i = 0; i < neutralResults.length; i++) {
                const kv = neutralResults[i];
                const stat = kv.value;
                const type = stat.type.replace('-', '');

                if (type === 'track' &&
                    "audio" === stat.kind &&
                    true === stat.remoteSource) {

                    try {
                        if (stat.audioLevel !== undefined) {
                            var num = stat.audioLevel * 1000;
                            if (this_.audioThreshold_ <= Number(num.toFixed(2))) {
                                if (this_.remoteAudioStreamInfo_[stat.trackIdentifier] !== undefined &&
                                    this_.remoteAudioStreamInfo_[stat.trackIdentifier] !== null &&
                                    this_.remoteAudioStreamInfo_[stat.trackIdentifier] !== "") {
                                    console.log('id: ' + this_.remoteAudioStreamInfo_[stat.trackIdentifier]);
                                    try {
                                        this_.onVoiceActivity(this_.remoteAudioStreamInfo_[stat.trackIdentifier], num);
                                    }
                                    catch (e) { }
                                }
                            }
                            else {
                                try {
                                    //TODO: need to identify when no one talks
                                    this_.onVoiceActivity("", 0);
                                } catch (e) { }
                            }
                        }
                    } catch (e) {
                        // we ignore exceptions by user code
                    }

                }
            }

        }
        catch (e) {
            console.error(`Unsupported key:${e}`, e);
        }
    }

    this_._clearRemoteAudioStreamTimer = function() {
            //Clear the remote stream list
            this_.remoteAudioStreamInfo_ = { };

            //Stop the getstat timer.
            if(undefined !== this_.fetchStatIntervalFn_)
            {
               clearTimeout(this_.fetchStatIntervalFn_);
               this_.fetchStatIntervalFn_ = undefined;
            }
    }

    this_._trace('Initializing WebClientAPI version ' + WrsJsVersion + '(build ' + WrsBuildTime__ + ')');
    this_._reInitPc();
}

function WrsRecorderInternal(channel, cb,  options, intent) {
    var this_ = this;

    this_.intent_ = intent;
    this_.channel_ = channel;
    this_.errorcb_ = cb;

    this_.myId_ = WrsObjectId__++;

    this_.recordingStreams_ = null;
    this_.recordingOptions_ = options;
    this_.recordingEnabled_ = false;
    this_.recordingDummyAudio_ = null;

    this_.streamQ_ = null;
    this_.state_ = null; 
    this_.timeDiffMs_ = 0;
    this_.lastProbeTime_ = null;
    this_.probeCount_ = 0;

    this_.probeTimer_ = null;

    this_.useAlternateRecorderForRemote_ = false;

    this_.start = function () {
        if (this_.state_ != null) {
            this_._trace('Recorder already started');
            return;
        }

        // returns a promise
        this_.recordingStreams_ = { };
        this_.recordingEnabled_ = false;

        var enabled = (this_.recordingOptions_ !== false && this_.recordingOptions_.enabled == true);
        if (!enabled) {
            return;
        }

        if (typeof RecordRTC !== "function") {
            this_._trace('Recording enabled in configurations but recordinng library not found');
            return new Promise(function (res, rej) {
                rej('Recording enabled in configurations but recordinng library not found');
            });
        }

        this_.state_ = {
            res: null,
            rej: null,
            timer: null,
            started: true,
            storage: {
                address: null,
                socket: null,
                token: "",
                sid: null,
                intent: null,
                id: 0,
                stimer: null,
                queue: [],
                qp: 0,
                rmap: {},
                halt: false
            }
        };

        var prom = new Promise(function (res, rej) {
            this_.state_.res = res;
            this_.state_.rej = rej;

            var now = new Date();
            var ts = this_._getTimestamp(now);

            // query chat server and get the MediaServer address
            var json = { type: "queryms", request: "captureUrl", t1: ts };

            this_._send(json);
            this_._trace('UI recording upload destination requested');
            
            this_._sendTimeSyncProbe();

            this_.state_.timer = setTimeout(function () {
                if (this_.state_.rej != null) {
                    this_.state_.rej('request timed out');
                }

                this_._resetPromise();
            }, 15000);
        });

        this_._trace('Recorder started');

        return prom;
    }

    this_.stop = function () {
        if (this_.recordingStreams_ != null) {
            var streams = this_.recordingStreams_;

            for (var sid in streams) {
                if (streams.hasOwnProperty(sid)) {
                    this_._stopRecording(streams[sid]);
                }
            }
        }

        if (this_.state_ != null) {
            if (this_.state_.rej != null) {
                this_.state_.rej('request canceled by user');
            }

            this_._resetPromise();

            this_.state_.started = false;
        }

        if (this_.probeTimer_ !== null) {
            clearTimeout(this_.probeTimer_);
            this_.probeTimer_ = null;
        }
    }

    // NOTE: When remote end is running on Safari (iOS) when remote end is paused; the local (Chrome Desktop tab)
    // crashes due to a issue in Chrome MediaStream Recorder API. This is to avoid the crash. Here we detect remote
    // browser via messaging and switch to WebAssemblyRecorder. This will prevent crash but does not allow time 
    // sliced recording upload.
    this_.setRemoteUserAgent = function (userAgent) {
        var uaName = undefined;
        var uaVersion = undefined;
        if (userAgent != null) {
            if (userAgent.name != null) {
                uaName = '' + userAgent.name;
            }

            if (userAgent.version != null) {
                uaVersion = '' + userAgent.version;
            }

            if (uaName == 'Safari') {
                this_.useAlternateRecorderForRemote_ = true;
            }

            this_._trace('Remote UA info recieved ' + uaName + ' ' + uaVersion);
        }
    }

    this_.add = function (stream, type) {
        if (!this_.recordingEnabled_) {
            this_._trace('Unable to add stream to recorder. Recorder not setup properly');
            return;
        }

        if (this_.recordingOptions_.recordLocal != null && this_.recordingOptions_.recordLocal == false) {
            if (type == WrsConst.PcMediaSource.LocalAudioVideo) {
                this_._trace('Skiping local audio/video recording');
                return;
            }
        }

        // capture dummy audio track if necessary
        if (this_.streamQ_ == null) {
            if (stream.getAudioTracks().length == 0 && stream.getVideoTracks().length > 0
                && this_.recordingDummyAudio_ == null) {
                // This is a single video track stream

                // As per bug https://github.com/muaz-khan/WebRTC-Experiment/issues/596 in RecordRTC 
                // we need a dummy audio track for recording this. So we need to capture a audio track.

                this_.streamQ_ = [{ s: stream, t: type }];
                var prom = navigator.mediaDevices.getUserMedia({ audio: true, video: false });
                prom.then(function (dummyAudio) {
                    if (dummyAudio != null) {
                        this_.recordingDummyAudio_ = dummyAudio.getAudioTracks()[0];
                        this_.recordingDummyAudio_.enabled = false;   // mute dummy audio track
                    }

                    this_._trace('continueing seting up UI recording after silent stream capture');
                    var q = this_.streamQ_;
                    this_.streamQ_ = null;

                    this_._continueSetupUIRecording(q);
                }).catch(function () {
                    this_._trace('failed to capture silent audio track');
                });
            } else {
                this_._continueSetupUIRecording([{ s: stream, t: type }]);
            }
        } else {
            this_.streamQ_.push({ s: stream, t: type });
        }
    }

    this_.enabled = function () {
        return this_.recordingEnabled_;
    }

    this_.onTrace = function (messageString) {
        console.log(messageString)
    }

    this_.channel_.onMessage = function (json) {
        if (this_.intent_ != null) {
            var intent = (json.intent == null ? "call" : json.intent);
            if (intent != this_.intent_) {
                // this message is not intended for this call
                return false;
            }
        }

        if (!WrsUtilsInternalInst.isKnownRecordingMessage(json)) {
            return false;
        }

        if (json.type == "queryms") {
            if (json.request == "captureUrl") {
                // We recieve Query message only when the Signaling / Chat server does not handle this message
                // We simply send a error responce
                this_._trace('MediaServer query request recieved. Sending a reject reply');
                var reply = { type: "queryms", responce: "captureUrl", data: false };
                this_._send(reply);
            } else if (json.responce == "captureUrl") {
                if (json.data == false) {
                    // failed to determine upload url
                    this_.state_.rej('failed to determine upload target');
                    this_._resetPromise();
                } else {
                    // connect to target
                    var now = new Date();
                    var ts = this_._getTimestamp(now);

                    json.t4 = ts;
                    this_._onTymeSyncProbeResponce(json);

                    this_.state_.storage.sid = json.session;
                    this_.state_.storage.intent = json.intent;

                    var target = json.data;
                    this_._ConnectToStorage(target);
                }
            } else if (json.responce == "timeSyncProbe") {
                var now = new Date();
                var ts = this_._getTimestamp(now);

                json.t4 = ts;
                this_._onTymeSyncProbeResponce(json);
            }
        }

        return true;
    }

    this_._trace = function (message) {
        var now = (window.performance.now() / 1000).toFixed(3);

        try {
            this_.onTrace(now + '|WRR|' + this_.myId_ + '|' + message);
        } catch (e) {
            // we ignore exceptions by user code
        }
    }

    this_._send = function (json) {
        if (this_.intent_ != null) {
            json.intent = this_.intent_;
        }

        this_.channel_.send(json);
    }

    this_._sendTimeSyncProbe = function () {
        if (this_.probeCount_ > 10) {
            return;
        } else if (!this_.state_.started) {
            return;
        }

        // query chat server and get the MediaServer address
        var now = new Date();

        if (this_.lastProbeTime_ != null) {
            if (now - this_.lastProbeTime_ < 1000) {
                // should not probe more than once a second
                return;
            }
        }

        this_.probeCount_ += 1;
        this_.lastProbeTime_ = now;

        var ts = this_._getTimestamp(now);

        var json = { type: "queryms", request: "timeSyncProbe", t1: ts };

        try {
            this_._send(json);
        } catch (e) {
            this_._trace('Failed to send time sync probe. ' + e);
            if (e.stack) {
                this_._trace('' + e.stack);
            }

            // retry probe
            this_.probeCount_ -= 1;
            this_.probeTimer_ = setTimeout(function () {
                this_.probeTimer_ = null;
                this_._sendTimeSyncProbe();
            }, 1000);
        }
        
        this_._trace('Time sync probe sent');
    }

    this_._onTymeSyncProbeResponce = function (msg) {
        try {
            var t1 = new Date(msg.t1.replace(' ', 'T').slice(0, -3));
            var t2 = new Date(msg.t2.replace(' ', 'T').slice(0, -3));
            var t3 = new Date(msg.t3.replace(' ', 'T').slice(0, -3));
            var t4 = new Date(msg.t4.replace(' ', 'T').slice(0, -3));

            var dt = Math.round(((t2 - t1) + (t3 - t4)) / 2);

            if (this_.timeDiffMs_ == 0 || Math.abs(this_.timeDiffMs_) > Math.abs(dt)) {
                if (dt > -1 && dt < 1) {
                    this_.timeDiffMs_ = dt > 0 ? 1 : -1;
                } else {
                    this_.timeDiffMs_ = dt;
                }
            }

            this_._trace('Time sync probe updated {current: ' + dt + ', min: ' + this_.timeDiffMs_ + '}');

            // send another probe in 5s
            this_.probeTimer_ = setTimeout(function () {
                this_.probeTimer_ = null;
                this_._sendTimeSyncProbe();
            }, 5000);
        } catch (e) {
            this_._trace('Failed to calculate time probe ' + e);
        }
    }

    this_._PushToStorage = function () {
        if (this_.state_.storage.socket != null
            && this_.state_.storage.socket.readyState == WebSocket.OPEN) {
            var ntime = window.performance.now();

            // check for unresponsive sockets
            if (this_.state_.storage.qp > 0) {
                var entry = this_.state_.storage.queue[0];
                var etime = entry.ts;
                if (ntime - etime > 10000) {
                    // no response for messages sent 10s before
                    this_.state_.storage.socket.close();
                    return;
                }
            }

            // send items in queue
            while (this_.state_.storage.qp < this_.state_.storage.queue.length) {
                var entry = this_.state_.storage.queue[this_.state_.storage.qp];
                var json = entry.msg;
                var recordingState = entry.state;

                if (recordingState.open == 0) {
                    this_._requestOpenStream(recordingState);
                }

                this_.state_.storage.rmap[json.id] = json.seq;
                this_._sendToStorage(json);
                this_.state_.storage.qp += 1;
                entry.ts = ntime;

                this_._trace('Sent recording (' + json.data.length + ' bytes) to storage server');
            }
        } else if (this_.state_.storage.socket == null && this_.state_.storage.address != "") {
            this_._trace('Storage server disconnect detected. Trying to reconnect');

            clearInterval(this_.state_.storage.stimer);
            this_.state_.storage.stimer = null;

            this_._ConnectToStorage(this_.state_.storage.address);
        } else if (this_.state_.storage.socket == null) {
            this_._trace('Storage thread exit');

            clearInterval(this_.state_.storage.stimer);
            this_.state_.storage.stimer = null;
        }
    }

    this_._ConnectToStorage = function (target) {
        try {
            this_.state_.storage.address = target;
            this_.state_.storage.socket = new WebSocket(target);
        } catch (e) {
            if (this_.state_.rej != null) {
                this_.state_.rej('failed to connect to recording storage');
                this_._resetPromise();
            }
        }

        this_.state_.storage.socket.onopen = function (event) {
            // acquire session
            this_.state_.storage.id += 1;

            var json = {
                id: ('' + WrsConst.PcRmsRequests.Acquire + ':' + this_.state_.storage.id),
                request: WrsConst.PcRmsRequests.Acquire,
                token: this_.state_.storage.token,
                sessionId: this_.state_.storage.sid,
                intent: this_.state_.storage.intent
            };

            this_._sendToStorage(json);
        }

        this_.state_.storage.socket.onmessage = function (event) {
            var json = JSON.parse(event.data);
            var id = '' + json.id + 'x';
            var type = id.charAt(0);

            if (type == WrsConst.PcRmsRequests.Acquire) {
                // responce to acquire
                if (json.status == 0) {
                    this_.state_.storage.token = json.token;
                    var reconnect = true;
                    if (this_.state_.res != null) {
                        this_.recordingEnabled_ = true;
                        this_.state_.res(true);
                        this_._resetPromise();
                        reconnect = false;
                    }

                    if (this_.recordingEnabled_) {
                        if (reconnect) {
                            this_._trace('Reonnected to storage server');
                        } else {
                            this_._trace('Connected to storage server');
                            this_._trace('Storage thread started');
                        }

                        this_.state_.storage.qp = 0;
                        this_.state_.storage.stimer = setInterval(function () { this_._PushToStorage(); }, 200);
                    }
                } else {
                    this_._trace('request rejected by storage server. ' + json.error);
                }

                if (this_.state_.rej != null) {
                    this_.state_.rej('failed to acquire session');
                    this_._resetPromise();
                }
            } else if (type == WrsConst.PcRmsRequests.Put && json.id != null) {
                // remove upto successful item from send queue
                if (this_.state_.storage.rmap[json.id] != null) {
                    var seq = this_.state_.storage.rmap[json.id];
                    delete this_.state_.storage.rmap[json.id];

                    var qp = 0;
                    while (qp < this_.state_.storage.queue.length) {
                        if (this_.state_.storage.queue[qp].msg.seq > seq)
                            break;
                        qp++;
                    }

                    if (this_.state_.storage.qp < qp) {
                        // this should not happen
                        this_._trace('qp error');
                    }

                    if (qp > 0) {
                        this_.state_.storage.queue.splice(0, qp);
                        this_.state_.storage.qp -= qp;
                    }

                    this_._trace('Storage queue flushed (count:' + qp + ', size:' + this_.state_.storage.queue.length
                        + ', qp:' + this_.state_.storage.qp + ')');

                    if (json.status != 0) {
                        // UI recording upload rejected by server
                        // No way to recover from this error. Need to end call immediately

                        this_._trace('Recording upload rejected by storage server: '
                            + (json.error != null ? json.error : 'unknown error'));

                        if (!this_.state_.storage.halt) {
                            this_.state_.storage.halt = true;
                            this_.errorcb_.onerror('Recording stream failed');
                        }
                    }
                }
            }
        }

        this_.state_.storage.socket.onerror = function (event) {
            this_._trace('storage socket disconnected due to error. ' + event.reason);
            this_.state_.storage.socket = null;
            if (this_.state_.rej != null) {
                this_.state_.rej('failed to connect to recording storage');
                this_._resetPromise();
            }
        }

        this_.state_.storage.socket.onclose = function (event) {
            this_._trace('storage socket closed. ' + event.reason);
            this_.state_.storage.socket = null;
            if (this_.state_.rej != null) {
                this_.state_.rej('failed to connect to recording storage');
                this_._resetPromise();
            }
        }
    }

    this_._resetPromise = function () {
        if (this_.state_.timer != null) {
            clearTimeout(this_.state_.timer);
        }
        this_.state_.res = null;
        this_.state_.rej = null;
        this_.state_.timer = null;
    }

    this_._sendToStorage = function (json) {
        var jsonStr = JSON.stringify(json);
        this_.state_.storage.socket.send(jsonStr);
    }

    this_._continueSetupUIRecording = function (streams) {
        // Start recording the streams
        streams.forEach(function (rec) {
            var stream = rec.s;
            var type = rec.t;

            if (this_.recordingStreams_[stream.id] == null) {
                // no recording for this stream. We start one
                var mimeLine = "video/webm;codecs=vp9";
                if (this_.recordingOptions_.codec != null)
                    mimeLine = "video/webm;codecs=" + this_.recordingOptions_.codec;

                var audioBps = 32000;   // audio recording bit rate bps
                if (this_.recordingOptions_.audioKbps != null)
                    audioBps = this_.recordingOptions_.audioKbps * 1000;

                var videoBps = 256000;  // video recording bit rate bps
                if (this_.recordingOptions_.videoKbps != null)
                    videoBps = this_.recordingOptions_.videoKbps * 1000;

                var recordingState = {
                    id: stream.id,
                    started: false,
                    ended: 0,   //< 0=undefined, 1=ending, 2=ended
                    recorder: null,

                    // NOTE: asume video data starts in 1 second after SDP. When using WebAssemblyRecorder we have no choice
                    // but to make a assumption here
                    start: this_._getTimestamp(new Date((Date.now() + 1))),

                    blobs: [],
                    completedTrackCount: 0,
                    open: 0, //< 0=initial; 1=opening, 2=open, 3=closed
                    totalTrackCount: stream.getTracks().length,
                    type: type,
                    timeSlice: 5000, // width of a time slice in miliseconds
                };

                stream.getTracks().forEach(function (track) {
                    track.onended = function (e) {
                        recordingState.completedTrackCount += 1;
                        if (recordingState.completedTrackCount >= recordingState.totalTrackCount) {
                            // all tracks completed. we need to stop recording now
                            this_._stopRecording(recordingState, false);
                        }
                    }
                });

                if (stream.getVideoTracks().length > 0 && stream.getAudioTracks().length == 0) {
                    var modifiedStream = new MediaStream(stream.getVideoTracks());
                    modifiedStream.addTrack(this_.recordingDummyAudio_);

                    stream = modifiedStream;
                    recordingState.stream = modifiedStream;
                    this_._trace('Stream modified');
                }

                var recorderModule = undefined;
                if (recordingState.type == WrsConst.PcMediaSource.RemoteAudioVideo
                    && this_.useAlternateRecorderForRemote_) {
                    recorderModule = window.WhammyRecorder;
                    this_._trace('Using WhammyRecorder for ' + recordingState.id);
                } else {
                    recorderModule = window.MediaStreamRecorder;
                    this_._trace('Using MediaStreamRecorder for ' + recordingState.id);
                }

                recordingState.recorder = new window.RecordRTC(stream, {
                    type: "video",
                    mimeType: mimeLine,
                    recorderType: recorderModule,
                    audioBitsPerSecond: audioBps,
                    videoBitsPerSecond: videoBps,
                    bitrate: videoBps,
                    canvas: { width: 640, height: 480 },
                    timeSlice: recordingState.timeSlice,
                    ondataavailable: function (blob) {
                        if (!recordingState.started) {
                            // if we have 1s of data here (as per above config recordingState.timeSlice); the first call 
                            // of this will be made exactly 1s after the recording actually started. We asume this call 
                            // is accurate to 30th of a second so that we may not see any sync issue with other streams 
                            // captured by other applications in this call. This time should be synced with respect
                            // to a global time server (in our case we use MediaServer) so that all parties have a 
                            // agreed global time relative to that time server.

                            recordingState.started = true;
                            var now = new Date((Date.now() - recordingState.timeSlice));
                            recordingState.start = this_._getTimestamp(now);
                            this_._trace('Recording started for ' + recordingState.id + '('
                                + recordingState.type + ') is ' + recordingState.start);
                        }

                        // recordingState.blobs.push(blob);
                        this_._putData(blob, recordingState);
                    },
                });

                this_.recordingStreams_[recordingState.id] = recordingState;
                recordingState.recorder.startRecording();

                this_._trace('Recording started: ' + recordingState.id);
            } else {
                // recording already setup for this stream
                recordingState = this_.recordingStreams_[stream.id];
                recordingState.totalTrackCount = stream.getTracks().length;
                if (recordingState.stream != null) {
                    // stream has been modified. need to apply newly additions for modified streams
                    var audioAdded = false;

                    stream.getTracks().forEach(function (track) {
                        var modifiedTrack = recordingState.stream.getTrackById(track.id);
                        if (modifiedTrack == null) {
                            recordingState.stream.addTrack(track);

                            if (track.kind == "audio") {
                                audioAdded = true;
                            }
                        }
                    });

                    if (audioAdded && this_.recordingDummyAudio_ != null) {
                        var silentAudioTrack = recordingState.stream.getTrackById(this_.recordingDummyAudio_.id);

                        if (silentAudioTrack != null) {
                            // remove scilent audio track
                            recordingState.stream.removeTrack(this_.recordingDummyAudio_);
                        }
                    }
                }
            }
        });
    }

    this_._stopRecording = function (recordingState, fromStop) {
        if (recordingState.ended != 0) {
            return;
        }

        recordingState.ended = 1;

        recordingState.recorder.stopRecording(function () {
            /*
            // Debug code to save the recording to disk
            var blob1 = new Blob(recordingState.blobs, {
                type: 'video/webm'
            });

            invokeSaveAsDialog(blob1);

            this_._trace('blob1 size ' + blob1.size);
            // end Debug
            */

            if (!recordingState.started) {
                // no time sliced blobs. this recorder only gives blobs at end only
                recordingState.started = true;
                this_._requestOpenStream(recordingState);
                var blob = recordingState.recorder.getBlob();
                if (blob != null) {
                    this_._trace('Falling back to single blob mode : ' + blob.size);
                    this_._putData(blob, recordingState);
                } else {
                    this_._trace('Falling back to single blob mode : ' + 0);
                }
            }

            recordingState.ended = 2;
            this_._trace('Recording stoped: ' + recordingState.id);

            if (this_.recordingStreams_ != null) {
                var hasActiveRecordings = false;

                for (var sid in this_.recordingStreams_) {
                    if (this_.recordingStreams_.hasOwnProperty(sid)) {
                        if (this_.recordingStreams_[sid].ended != 2) {
                            hasActiveRecordings = true;
                            break;
                        }
                    }
                }

                if (!hasActiveRecordings) {
                    setTimeout(function () {
                        // NOTE: This timeout must trigger irrespective of this object is live
                        // due to this, no event must be triggered within any function (or any 
                        // function called indirectly this function) of this timer. Also any
                        // global variables must not be accessed within this function (or any 
                        // function indirectly called).

                        this_._requestReleaseSession();
                        this_._trace('Recorder stopped');

                        this_.recordingStreams_ = null;

                        if (this_.recordingDummyAudio_ != null) {
                            this_.recordingDummyAudio_.stop();
                            this_.recordingDummyAudio_ = null;
                        }
                    }, 500);
                }
            }
        });
    }

    this_._requestOpenStream = function (recordingState) {
        this_.state_.storage.id += 1;

        var start = this_._localTimetoRemote(recordingState.start);
        var owner = 'external';

        var json = {
            id: ('' + WrsConst.PcRmsRequests.Create + ':' + this_.state_.storage.id),
            request: WrsConst.PcRmsRequests.Create,
            token: this_.state_.storage.token,
            file: '700_' + recordingState.id,
            type: 'video',
            startTime: start,
            owner: owner,
            codec: 'webm'
        }

        this_._sendToStorage(json);
        recordingState.open = 1;
    }

    this_._requestCloseStream = function (recordingState) {
        this_.state_.storage.id += 1;

        var json = {
            id: ('' + WrsConst.PcRmsRequests.Put + ':' + this_.state_.storage.id),
            request: WrsConst.PcRmsRequests.Put,
            token: this_.state_.storage.token,
            file: '700_' + recordingState.id,
            data: null
        }

        this_._sendToStorage(json);
        recordingState.open = 3;
    }

    this_._getTimestamp = function (time) {
        var timeStr = ('0000' + time.getFullYear()).slice(-4) + '-'
            + ('00' + (time.getMonth() + 1)).slice(-2) + '-'
            + ('00' + time.getDate()).slice(-2) + ' '
            + ('00' + time.getHours()).slice(-2) + ':'
            + ('00' + time.getMinutes()).slice(-2) + ':'
            + ('00' + time.getSeconds()).slice(-2) + '.'
            + ('000' + time.getMilliseconds()).slice(-3) + '000';

        return timeStr;
    }

    this_._localTimetoRemote = function (localTime) {
        var frag = new Date('' + localTime.replace(' ', 'T').slice(0, -3));
        var timeMs = frag.getTime() + this_.timeDiffMs_;
        var time = new Date(timeMs);

        var remoteTime = this_._getTimestamp(time);

        //this_._trace('Time base maping (dif=' + this_.timeDiffMs_ + ', frag=' + frag + ', ms=' + timeMs + ')'
        //    + localTime + ' => ' + remoteTime);

        return remoteTime;
    }

    this_._putData = function (blob, recordingState) {
        // stop if queue is growing
        if (this_.state_.storage.halt) {
            this_._trace('Ignoring upload block due to failed state');
            return;
        } else if (this_.state_.storage.queue.length > 3) {
            this_.state_.storage.halt = true;
            this_._trace('Recording failed due to upload queue full');
            this_.errorcb_.onerror('Recording stream failed');
            return;
        }

        var reader = new FileReader();
        var size = blob.size;
        reader.readAsDataURL(blob);
        reader.onloadend = function () {
            var dataUrl = reader.result;

            // remove the dataurl starting portion to get only the base64 encoded data part
            // dataUrl format is  'data:[<mediatype>][;base64],<base64Data>'
            var startPos = dataUrl.lastIndexOf(',', 100);
            
            if (startPos < 0) {
                startPos = 0; // not a proper dataURL. so we send entire thing
            } else {
                startPos += 1; // add sizeof ','
            }

            var start = this_._localTimetoRemote(recordingState.start);

            // Max msg size is 40 MB. This length needs to be devisable by 4 for generating
            // proper base64 decodable segments
            var maxlen = 40 * 1024 * 1024;

            var remaining = dataUrl.length - startPos;
            while (remaining > 0) {
                var len = (maxlen > remaining) ? remaining : maxlen;

                var base64data = dataUrl.substr(startPos, len);
                startPos += len;
                remaining -= len;

                this_.state_.storage.id += 1;

                var json = {
                    msg: {
                        id: ('' + WrsConst.PcRmsRequests.Put + ':' + this_.state_.storage.id),
                        request: WrsConst.PcRmsRequests.Put,
                        token: this_.state_.storage.token,
                        startTime: start,
                        file: '700_' + recordingState.id,
                        seq: this_.state_.storage.id,
                        data: base64data
                    },
                    state: recordingState
                }

                this_.state_.storage.queue.push(json);
            }
        }
    }

    this_._requestReleaseSession = function () {
        this_.state_.storage.halt = true;

        var needTime = (this_.state_.storage.socket == null
            || this_.state_.storage.socket.readyState != WebSocket.OPEN)
            && (this_.state_.storage.queue.length > this_.state_.storage.qp);

        if (needTime) {
            // Storage socket not connected yet. Wait for it to conect and upload and close
            this_._PushToStorage();
            setTimeout(function () { this_._requestReleaseSessionContinue(); }, 10000);
        } else {
            this_._requestReleaseSessionContinue();
        }
    }

    this_._requestReleaseSessionContinue = function () {
        if (this_.state_ == null)
            return;

        this_.state_.storage.address = ""; //  Prevent trying to reconnect if alrady disconnected
        this_._PushToStorage();

        if (this_.state_.storage.stimer != null) {
            this_._trace('Storage thread exit');

            clearInterval(this_.state_.storage.stimer);
            this_.state_.storage.stimer = null;
        }

        if (this_.state_.storage.queue.length > 0 && this_.state_.storage.queue.length > this_.state_.storage.qp) {
            // This would mean we will loose these recording blobs
            this_._trace('Recording ending with data available in upload queue');
        }

        if (this_.state_.storage.socket != null
            && this_.state_.storage.socket.readyState == WebSocket.OPEN) {
            if (this_.state_.storage.token != "") {
                this_.state_.storage.id += 1;

                var json = {
                    id: ('' + WrsConst.PcRmsRequests.Release + ':' + this_.state_.storage.id),
                    request: WrsConst.PcRmsRequests.Release,
                    token: this_.state_.storage.token
                }

                this_._sendToStorage(json);
                this_._trace('Storage release request sent');
            }

            this_.state_.storage.socket.close();
        }

        this_.state_.storage = {
            address: null,
            socket: null,
            token: "",
            sid: null,
            intent: null,
            id: 0,
            stimer: null,
            queue: [],
            qp: 0,
            rmap: {},
            halt: true
        };

        this_.state_.started = false;
    }
}

function WrsConferenceMixerInternal() {
    var this_ = this;

    // call base constructor
    WrsMixerInterface(this_);

    this_.pcs_ = [];

    this_.add = function (pc) {
        if (pc.mixStreams == undefined) {
            return false;
        }

        var added = this_.pcs_.some(function (p) {
            return (p === pc);
        });

        if (!added) {
            this_.pcs_.forEach(function (p) {
                p.mixStreams(pc);
            });

            this_.pcs_.push(pc);
        }

        return true;
    }

    this_.remove = function (pc) {
        return false;
    }
}

function WrsPlayerInterfaceImpl(context, destination, buffer, tracefn) {
    var this_ = this;

    // call base constructor
    WrsPlayerInterface(this_);

    this_.context_ = context;
    this_.dest_ = destination;
    this_._tracefn = tracefn;

    this_.source_ = null;
    this_.audio_ = null;

    this_.startT_ = 0;
    this_.offsetT_ = 0;

    this_.paused_ = false;
    this_.ended_ = false;
    this_.looped_ = false;

    this_.setLoop = function(loop) { 
        this_.looped_ = true;
        if (this_.source_ != null) {
            this_.source_.loop = this_.looped_;
        }
    }

    this_.pause = function() {
        this_._pause();
        this_.paused_ = true;
    }

    this_.resume = function() {
        this_._play();
        this_.paused_ = false;
    }

    this_.stop = function() { 
        this_._pause();
        this_.ended_ = true;

        this_._trace('Playback stopped by user');
    }

    this_.isPaused = function() { 
        return this_.paused_;
    }

    this_.isLooped = function() {
        return this_.looped_;
    }

    this_.getPosition = function() {
        if (this_.ended_) {
            return 100;
        } else if (this_.source_ == null || this_.context_ == null || this_.audio_ == null) {
            return 0;
        } else if (this.audio_.duration == 0) {
            return 0;
        } else if (this_.context_.state == "closed") {
            return 0;
        }

        var offt = (this_.context_.currentTime - this_.startT_) % this.audio_.duration;
        return ((offt / this.audio_.duration) * 100);
    }

    this_.getDuration = function() {
        if (this_.ended_) {
            return 0;
        } else if (this_.source_ == null || this_.audio_ == null) {
            return 0;
        }

        return this.audio_.duration;
    }

    this_._init = function(buf) {
        this_.source_ = null;
        this_.ended_ = false;
        this_.startT_ = 0;
        this_.offsetT_ = 0;

        if (this_.context_.state == "closed") {
            setTimeout(function() {
                this_._trace('Failed to start player. context closed');
                this_._onEnd();                
            }, 0);
        }

        this_.context_.decodeAudioData(buf, function(audio) {
            if (!audio) {
                this_._trace('Failed to decode audio data');
                this_._onEnd();
            } else  {
                this_.audio_ = audio;

                if (!this_.paused_) {
                    this_._play();
                }
            }
        } , function(e) {
            this_._trace('Failed to decode audio data');
            this_._onEnd();
        });

        this_._trace('Player iniatilized');
    }

    this_._play = function() {
        if (this_.source_ != null) {
            // already playing
            return;
        } else if (this_.audio_ == null) {
            // still loading audio
            return;
        } else if (this_.ended_) {
            // playback already ended
            return;
        } else if (this_.context_.state == "closed") {
            // context closed
            return;
        }

        this_.source_ = this_.context_.createBufferSource();

        var source = this_.source_;
        source.buffer = this_.audio_;
        
        if (!source.start) {
            source.start = source.noteOn;
        }

        if (!source.stop) {
            source.stop = source.noteOff;
        }
        
        source.loop = this_.looped_;

        source.connect(this_.dest_);
        source.start(0, this_.offsetT_);

        this_.startT_ = this_.context_.currentTime - this_.offsetT_;

        this_._trace('Playback resumed');

        source.onended = function() {
            if (this_.source_ != null) {
                this_.ended_ = true;
                this_.offsetT_ = 0;

                var source = this_.source_;
                this_.source_ = null;

                source.disconnect();
                source.stop(0);

                this_._trace('Playback ended');

                this_._onEnd();
            }
        }
    }

    this_._pause = function() {
        if (this_.source_ == null) {
            // already paused
            return;
        }

        var source = this_.source_;
        this_.source_ = null;

        source.disconnect();
        source.stop(0);

        this_.offsetT_ = (this_.context_.currentTime - this_.startT_) % this.audio_.duration;

        this_._trace('Playback paused');
    }

    this_._trace = function(msg) {
        this_._tracefn('AudioPlayer: ' + msg);
    }

    this_._onEnd = function() {
        try {
            this_.onEnd();
            this_._trace('Playback ended event triggered');
        } catch (ex) {
            this_._trace('Playback ended event triggered. Ignoring exception in user code (' + ex + ')');
        }
    }

    this_._init(buffer);
}

function WrsDtmfGeneratorImpl(context, destination, tracefn) {
    var this_ = this;

    this_.context_ = context;
    this_.dest_ = destination;
    this_._tracefn = tracefn;

    this_.queue_ = [ ];
    this_.toneParams_ = { };

    this_.osc1_ = null;
    this_.osc2_ = null;
    this_.filter_ = null;
    this_.timer_ = null;

    this_.send = function(tone) {
        this_.queue_.push(tone);
        this_._play();
    }

    this_.close = function() {
        if (this_.osc1_ != null) {
            this_.osc1_.stop(0);
        }

        if (this_.osc2_ != null) {
            this_.osc2_.stop(0);
        }

        if (this_.filter_ != null) {
            this_.filter_.disconnect();
        }

        if (this_.timer_ != null) {
            clearTimeout(this_.timer_);
            this_.timer_ = null;
        }

        this_.osc1_ = null;
        this_.osc2_ = null;
        this_.filter_ = null;
    }

    this_._init = function() {
        this_.toneParams_[WrsDtmfTones.NUM_1] = {f1: 697, f2: 1209}
        this_.toneParams_[WrsDtmfTones.NUM_2] = {f1: 697, f2: 1336}
        this_.toneParams_[WrsDtmfTones.NUM_3] = {f1: 697, f2: 1477}
        this_.toneParams_[WrsDtmfTones.NUM_4] = {f1: 770, f2: 1209}
        this_.toneParams_[WrsDtmfTones.NUM_5] = {f1: 770, f2: 1336}
        this_.toneParams_[WrsDtmfTones.NUM_6] = {f1: 770, f2: 1477}
        this_.toneParams_[WrsDtmfTones.NUM_7] = {f1: 852, f2: 1209}
        this_.toneParams_[WrsDtmfTones.NUM_8] = {f1: 852, f2: 1336}
        this_.toneParams_[WrsDtmfTones.NUM_9] = {f1: 852, f2: 1477}
        this_.toneParams_[WrsDtmfTones.Star]  = {f1: 941, f2: 1209}
        this_.toneParams_[WrsDtmfTones.NUM_0] = {f1: 941, f2: 1336}
        this_.toneParams_[WrsDtmfTones.Pound] = {f1: 941, f2: 1477}

        if (this_.context_.state == "closed") {
            this_._trace("Failed to initialize. Context is closed");
            return;
        }

        this_.osc1_ = this_.context_.createOscillator();
        this_.osc2_ = this_.context_.createOscillator();
        this_.osc1_.frequency.value = 697;
        this_.osc2_.frequency.value = 1209;

        this_.filter_ = this_.context_.createBiquadFilter();
        this_.filter_.type = "lowpass";
        this_.filter_.frequency = 8000;
    
        this_.osc1_.connect(this_.filter_);
        this_.osc2_.connect(this_.filter_);

        this_.osc1_.start(0);
        this_.osc2_.start(0);
    }

    this_._playOne = function(tone) {
        if (this_.timer_ != null) {
            return Promise.reject("concurrent invocations not allowed");
        }
        
        if (this_.osc1_ == null || this_.osc2_ == null) {
            this_._init();
        }

        if (this_.osc1_ == null || this_.osc2_ == null) {
            // initialization failed
            return Promise.reject("failed to initialize");
        }

        var params = this_.toneParams_[tone];
        if (params == null) {
            // invalid tone
            return Promise.reject("invalid tone symbol [" + tone + "]");
        }

        return new Promise(function(res, rej) {
            if (this_.osc1_ == null) {
                rej("closed");
                return;
            } else if (this_.context_.state == "closed") {
                rej("context closed");
                return;
            }

            this_.osc1_.frequency.value = params.f1;
            this_.osc2_.frequency.value = params.f2;
            this_.filter_.connect(this_.dest_);

            // wait for 100 ms and then disconnect
            this_.timer_ = setTimeout(function() {
                this_.filter_.disconnect();

                // wait for 50 ms silence (i.e. spacing)
                this_.timer_ = setTimeout(function() {
                    this_.timer_ = null;
                    res(true);
                }, 50);
            }, 100);
        });
    }

    this_._play = function() {
        if (this_.timer_ == null && this_.queue_.length != 0) {
            var tone = this_.queue_.shift();
            this_._playOne(tone).then(function() {
                this_._play();
            }).catch(function() {
                this_._play();
            });
        }
    }

    this_._trace = function(msg) {
        this_._tracefn('DtmfGenerator: ' + msg);
    }
}
