// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "SignalRConnector.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------
var connectCounter = 1;
var connectUrlCount = 0;
var pendingRequest = {};
var con;

//document ready 
$(document).ready(function () {

    //check if the signalr connector is enabled
    if (!isSignalrConnector) {
        log.LogDetails("Error", "SignalRConnector.ready()", "isSignalrConnector is not enabled", false);
        return;
    }

    //start dashboard signalr connection
    if (!jQuery.isEmptyObject(signalRConnectorUrls.dashboard) && signalRConnectorUrls.dashboard.urls.length > 0) {
        setTimeout(function () {
            ConnectToDashboard();
        }, 3000);
    }

    //start WebRTC signalr connection
    if (!jQuery.isEmptyObject(signalRConnectorUrls.webRTCMonitor) && signalRConnectorUrls.webRTCMonitor.urls.length > 0) {
        setTimeout(function () {
            let conn = new SignalRConnector(signalRConnectorUrls.webRTCMonitor.urls, signalRConnectorUrls.webRTCMonitor.protocol, "webrtc", {}, "TmcHub", true, 30000);
            //override the onReceived event to stop console logs
            conn.onReceived = function (obj) { };
            //connect is exposed outside to that hub events should be defined before the connect
            conn.connect();
            srConn.push(conn);
        }, 3000);
    }
});

function ConnectToDashboard() {
    try {
        let conn = new SignalRConnector(signalRConnectorUrls.dashboard.urls, signalRConnectorUrls.dashboard.protocol, "agentDashboard", {
            'agentId': global_AgentID,
            'agentProfile': global_UserProfileForAgent,
            'stationId': global_DeviceID,
            'tmacServer': _tmacServer,
            'isTmac': true
        }, "tmacDataServerHub", true, 30000);

        conn.onReconnected = function () {
            ProcessPendingRequest();
            if (isDashboardEnabled) {
                ProcessMiniDashboard(true, "");
            }
        };

        conn.onConnected = function (instance) {
            if (isDashboardEnabled) {
                RegisterMe(instance);
            }
            ProcessPendingRequest();
        };

        conn.hub.on('onRegistered', function (message, start, version) {
            try {
                log.LogDetails("Info", "SignalRConnector.SignalRConfiguration()", message + " - Start: " + start + ", Version: " + version, false);
                signalRVersion = version;
                ProcessMiniDashboard(start, "");
            } catch (ex) {
                log.LogDetails("Error", "SignalRConnector.onRegistered()", ex, false);
            }
        });

        conn.hub.on('onMiniDashboard', function (data) {
            try {
                $("#totalVoice").text(data[0].totalVoice);
                $("#totalCallback").text(data[0].totalCallback);
                $("#totalChat").text(data[0].totalChat);
                $("#totalFax").text(data[0].totalFax);
            } catch (ex) {
                log.LogDetails("Error", "SignalRConnector.onMiniDashboard()", ex, false);
            }
        });

        conn.hub.on('onUpdate', function (channel) {
            try {
                ProcessMiniDashboard(true, "");
            } catch (ex) {
                log.LogDetails("Error", "SignalRConnector.onUpdate()", ex, false);
            }
        });

        conn.hub.on('onGrammerCheck', function (data, obj) {
            try {
                GrammerCheckDone(data, obj);
            } catch (ex) {
                log.LogDetails("Error", "SignalRConnector.onGrammerCheck()", ex, false);
            }
        });

        conn.hub.on('onInteractionHistory', function (param, data) {
            try {
                document.getElementById('ui_history_frame' + param.InteractionID) ? document.getElementById('ui_history_frame' + param.InteractionID).contentWindow.ProcessHistoryData(data) : null;
                document.getElementById('interactionhistory_iframe') ? document.getElementById('interactionhistory_iframe').contentWindow.ProcessHistoryData(data) : null;
            } catch (ex) {
                log.LogDetails("Error", "SignalRConnector.onInteractionHistory", ex, false);
            }

        });
        //connect is exposed outside to that hub events should be defined before the connect
        conn.connect();
        srConn.push(conn);
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.ConnectToDashboard()", ex, false);
    }
}

function RegisterMe(instance) {
    try {
        log.LogDetails("Info", "SignalRConnector.RegisterMe()", "SignalR - Server ready", false);
        var conn = GetSRConnection("agentDashboard");
        if (conn && conn.connected) {
            globalAgentList.push(global_AgentID);
            if (globalAgentList.length && global_UserProfileForAgent) {
                conn.hub.invoke('RegisterMe', globalAgentList[0], global_UserProfileForAgent, conn.con.id);
                RemovePendingRequest("RM");
            } else {
                log.LogDetails("Error", "SignalRConnector.LoadDashboardData()", "Connection Id/Agent id/profile is emprty", false);
            }
        }
        else {
            log.LogDetails("Error", "RegisterMe", "srConn is not connected.", false);
            throw "con is undefined";
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.RegisterMe()", ex, false);
        pendingRequest.RM = function () {
            RegisterMe();
        };
    }
}

function ProcessMiniDashboard(start, interval) {
    try {
        var conn = GetSRConnection("agentDashboard");
        if (conn && conn.connected) {
            if (start) {
                if (interval === "") {
                    interval = $("#drp_dashboard_interval").data("kendoDropDownList").value();
                    log.LogDetails("Info", "SignalRConnector.ProcessMiniDashboard()", "Dashboard Interval: " + interval, false);
                }
                conn.hub.invoke('GetMiniDashboard', globalAgentList, conn.con.id, interval, globalChannelList);
                RemovePendingRequest("PMD");
            }
        }
        else {
            log.LogDetails("Error", "ProcessMiniDashboard", "srConn is not connected.", false);
            throw "con is undefined";
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.ProcessMiniDashboard()", ex, false);
        pendingRequest.PMD = function () {
            ProcessMiniDashboard(start, interval);
        };
    }
}

function OpenDashboard(channel) {
    try {
        //var param = "agentId=" + global_AgentID + "&profile=" + global_UserProfileForAgent + "&channel=" + channel + "&channelList=" + globalChannelList;
        if (dashboardUrl) {
            var param = "agentId=" + global_AgentID + "&profile=" + global_UserProfileForAgent + "&channel=" + channel + "&channelList=" + globalChannelList;
            param = ToEncodedString(param);
            var url = (IsValidURL(dashboardUrl) ? dashboardUrl : GetBaseUrl(global_connectedProxy) + dashboardUrl) + "?" + param;
            var h = screen.height;
            var w = screen.width;
            var d = window.open(url, "1", "menubar=no,resizable=yes,location=no,scrollbars=no,width=" + w + ",height=" + h);
            d.moveTo(0, 0);
        }
        else {
            log.LogDetails("Warning", "SignalRConnector.OpenDashboard()", "Big dashboard url is empty, please configure to open the dashboard", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.OpenDashboard()", ex, false);
    }
}

function CheckGrammer(text, obj) {
    try {
        var conn = GetSRConnection("agentDashboard");
        if (conn && conn.connected) {
            conn.hub.invoke('CheckGrammer', conn.con.id, text, obj);
            RemovePendingRequest("GC");
        }
        else {
            log.LogDetails("Error", "CheckGrammer", "srConn is not connected.", false);
            throw "con is undefined";
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.ConnectToServer()", ex, false);
        pendingRequest.GC = function () {
            CheckGrammer(text, obj);
        };
    }
}

function GetHistoryFromDataServer(params) {
    try {
        if (con && con.state === 1) {
            hub.invoke('GetInteractionHistory', con.id, params, params.noOfRecords, params.lastID);
            RemovePendingRequest("GHFDS");
            return;
        }
        else {
            throw "con is undefined";
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.GetHistoryFromDataServer()", ex, false);
        pendingRequest.GHFDS = function () {
            GetHistoryFromDataServer(params);
        };
    }
}

function ProcessPendingRequest() {
    try {
        //process pending request
        $.each(pendingRequest, function (i, v) {
            log.LogDetails("Info", "SignalRConnector.ProcessPendingRequest()", v, false);
            v();
        });
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.ProcessPendingRequest()", ex, false);
    }
}

function RemovePendingRequest(reqType) {
    try {
        if (pendingRequest && pendingRequest[reqType]) {
            log.LogDetails("Info", "SignalRConnector.RemovePendingRequest()", reqType, false);
            delete pendingRequest[reqType];
        }
    } catch (ex) {
        log.LogDetails("Error", "SignalRConnector.RemovePendingRequest()", ex, false);
    }

}