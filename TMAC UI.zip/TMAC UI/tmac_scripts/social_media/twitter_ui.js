﻿//----------------------------------------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
//----------------------------------------------------------------------------------------------------------------
var filename = "TwitterUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//----------------------------------------------------------------------------------------------------------------

var Twitter_tweet_data = [];
var Twitter_pm_data = [];

function TwitterIncomingTweetEvent(event) {
    try {
        Twitter_tweet_data.push(
            {
                intid: event.InteractionID,
                data: event.Item.Data
            }
        );

        var url = twitterUrl + "?intid=" + event.InteractionID;

        OpenIframeTab("twitter", url, "TwitterTweet", true);

        $("#divCustomerName" + event.InteractionID).find("i")[0].innerText = "";
        $("#divCustomerName" + event.InteractionID).find("i")[0].className = "uk-icon uk-icon-small uk-icon-twitter";	
    } catch (ex) {
        log.LogDetails("Error", "TwitterUI.TwitterIncomingTweetEvent()", ex, false);
    }
}

function TwitterIncomingMessageEvent(event) {
    try {
        Twitter_pm_data.push(
            {
                intid: event.InteractionID,
                data: event.Item.Data
            }
        );
        var url = twitterDMUrl + "?intid=" + event.InteractionID;

        OpenIframeTab("twitterdm", url, "TwitterDM", true);

    } catch (ex) {
        log.LogDetails("Error", "TwitterUI.TwitterIncomingMessageEvent()", ex, false);
    }
}