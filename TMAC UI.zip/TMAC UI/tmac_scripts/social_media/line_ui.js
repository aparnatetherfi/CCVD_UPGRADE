﻿//----------------------------------------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
//----------------------------------------------------------------------------------------------------------------
var filename = "LineUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//----------------------------------------------------------------------------------------------------------------

var Line_pm_data = [];

function LineIncomingMessageEvent(event) {
    try {

        Line_pm_data.push(
            {
                intid: intid,
                data: data
            }
        );

        var url = lineUrl + "?intid=" + event.InteractionID;
        OpenIframeTab("line", url, true);

        $("#divCustomerName" + event.InteractionID).find("i")[0].innerText = "";
        $("#divCustomerName" + event.InteractionID).find("i")[0].className = "uk-icon uk-icon-small uk-icon-comment";

    } catch (ex) {
        log.LogDetails("Error", "TwitterUI.LineIncomingMessageEvent()", ex, false);
    }
}