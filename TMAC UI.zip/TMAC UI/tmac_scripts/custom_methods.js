﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CustomMethods.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

$(function () {
    console.log('custom method js loaded');
});

function AgentLoginSuccessCustom() {
    try {
        //if siebel integration enabled, call siebel layer to update agent login
        if (isSiebel)
            CallbackSiebelObj.setAgentInfo(global_AgentID, global_LanID, global_DeviceID);
        else if (isCACS) {
            var data = {};
            data.agentID = global_AgentID;
            data.extension = global_DeviceID;
            var obj = {};
            obj.source = "cacs";
            obj.method = "OnLogin";
            obj.contentType = "application/json;charset=utf-8";
            InvokeRestCall(data, obj, restCallUrl.CACSDataProxyRestUrl + "/" + obj.method);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.AgentLoginSuccessCustom()", ex, false);
    }
}

function AgentLogoutSuccessCustom() {
    try {
        if (isCACS) {
            var data = {};
            data.agentID = global_AgentID;
            data.extension = global_DeviceID;
            var obj = {};
            obj.source = "cacs";
            obj.method = "OnLogout";
            obj.contentType = "application/json;charset=utf-8";
            InvokeRestCall(data, obj, restCallUrl.CACSDataProxyRestUrl + "/" + obj.method);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.AgentLogoutSuccessCustom()", ex, false);
    }
}

function ResizeCustom(type) {
    try {
        //if siebel integration enabled, then call chromium obj to expand and resize tmac
        switch (type) {
            case "max":
                if (isSiebel) CallbackSiebelObj.maximize();
                break;
            case "min":
                if (isSiebel) CallbackSiebelObj.minimize();
                break;
        }

    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.ResizeCustom()", ex, false);
    }
}

function HandleEventCustom(event) {
    try {
        //no need of processing WallboardRefreshEvent
        if (event.EventName !== "WallboardRefreshEvent") {
            //if siebel integration enabled, call siebel layer to handle events
            if (isSiebel) CallbackSiebelObj.showMessage(event.EventName, JSON.stringify(event));
        }
        if (voiceDataWindowType === "campaign" && event.InteractionID) {
            var campIframeWindow = document.getElementById("ui_custom_frame" + event.InteractionID);
            if (campIframeWindow) {
                campIframeWindow.contentWindow.UpdateCallStatus(event);
            }
        }

        // if meeting is configured send the events to frame
        if (typeof meetingFrameUrl !== "undefined" && meetingFrameUrl) {
            var frame = document.getElementById("meeting_iframe");
            var frameWindow = frame ? frame.contentWindow : null;
            if (frameWindow)
                InvokePostMessage(frameWindow, null, "tmacEvent", event, null);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.HandleEventCustom()", ex, false);
    }
}

function IncomingVoiceCallCustom(event, callbackTransfer) {
    try {
        // Initially will set 'triggerIServeLayer' to false when its Transfer or Conference 
        var data = {};
        data.InteractionID = event.InteractionID;
        data.UCID = event.UCID;
        if (event.IsAgentTransferedCall || event.IsAgentConferencedCal) {
            data.triggerIServeLayer = false;
        } else {
            data.triggerIServeLayer = true;
        }
        //check if ucid is existing in the custom table - for queuetime calculation
        if (isIServe) custom_getQueueTimeForUCID(event.InteractionID, event.UCID, "0");

        if (typeof FaceCompare !== "undefined") {
            FaceCompare.FaceCompares(global_AgentID, "Please proceed with call", "You are not authorized to take this call, please contact supervisor");
            FaceCompare.GetFacesCount(true);
        }

        //if this is not callback transfer then if isDynamicCRMEnabled
        if (!callbackTransfer && isDynamicCRMEnabled) DynamicsCRMStartVoicePopUpScreen(event, true);
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.IncomingVoiceCallCustom()", ex, false);
    }
}

function VoiceCallTransferInitiatedCustom(intid) {
    try {
        //insert into custom table, the ucid to recognise from iServe that it is a blind transfer
        if (isIServe) custom_UpdateUCIDOnBlindTransfer(intid, global_UCID[intid]);
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.VoiceCallTransferInitiatedCustom()", ex, false);
    }
}

function VoiceOutgoingCallCustom(event) {
    try {
        var data = {};
        data.InteractionID = event.InteractionID;
        data.UCID = event.UCID;
        data.triggerIServeLayer = true;

        if (isDynamicCRMEnabled) DynamicsCRMStartVoicePopUpScreen(event, false);
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.VoiceOutgoingCallCustom()", ex, false);
    }
}

function VoiceCallDisconnectedCustom(event) {
    try {
        var intid = event.InteractionID;
        if (GetTabReferenceObj(intid).type === 'voice') {
            if (GetTabReferenceObj(intid).direction === 'out') {
                if (isDynamicCRMEnabled) DynamicsCRMEndVoicePopUpScreen(event, false);
                else {
                    if (isDynamicCRMEnabled) DynamicsCRMEndVoicePopUpScreen(event, true);
                }
            }

            //if IVR transfer is enabled
            if (ivrTransferEnabled) {
                //Check if its TPIN transfer, if yes dont start ACW Timer. 
                if (!GetVoiceReferenceObj(intid).ivrTransferRef.TPINOTPDone) {
                    //Start the ACW Timer for iServe
                    if (isIServe) custom_UpdateEndOfCallACWStartTime(intid, global_UCID[global_activeTabId], global_LanID);
                }
                else
                    GetVoiceReferenceObj(intid).ivrTransferRef.TPINOTPDone = false;
            }

            //if ACW QMS CRM is enabled
            if (isACWQMSCRMEnabled) {
                var sDate = GetCurrentDate("YYYYMMDD");
                var sTime = GetCurrentTime("HHmmss");
                GetTabReferenceObj(intid).CRMWindowData.ACWStartTime = sDate + '_' + sTime;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.VoiceCallDisconnectedCustom()", ex, false);
    }
}

function TransferCallCustom(intid) {
    try {
        //Insert current time to custom data table to calculate the queuetime
        if (isIServe) custom_insertQueueTimeForUCID(intid, GetCurrentDateTime(), global_UCID[intid]);
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.TransferCallCustom()", ex, false);
    }
}

function TransferToIVRCustom(obj) {
    try {
        if (isIServe) {
            if (obj.type !== "feewaiver") custom_ClearCallDataForTpinTransfer(obj.intid, global_UCID[global_activeTabId]);
            //Insert current time to custom data table to calculate the queuetime
            custom_insertQueueTimeForUCID(obj.intid, GetCurrentDateTime(), global_UCID[obj.intid]);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.TransferToIVRCustom()", ex, false);
    }
}

function TransferToIVRDoneCustom(obj) {
    try {
        if (GetTabReferenceObj(obj.intid).direction === 'out' && (obj.type === "otp" || obj.type === "tpin")) {
            GetVoiceReferenceObj(obj.intid).ivrTransferRef.TPINOTPOut = true;
        }
        GetVoiceReferenceObj(obj.intid).ivrTransferRef.TPINOTPDone = true;
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.TransferToIVRDoneCustom()", ex, false);
    }
}

function TextChatDisconnectedCustom(event) {
    try {
        if (event.ConferenceType !== "silent") {
            if (event.Reason === "RemoteEndClosed") {
                if (isDynamicCRMEnabled) DynamicsCRMEndChatPopUpScreen(event);
                if (isNiceIntegration) custom_PushMessageToNICE(event.InteractionID, global_UCID[event.InteractionID]);
            }
            else if (event.Reason === "AgentChatDisconnected") {
                if (isDynamicCRMEnabled) DynamicsCRMEndChatPopUpScreen(event);
                if (isNiceIntegration) custom_PushMessageToNICE(event.InteractionID, global_UCID[event.InteractionID]);
            }
            else if (event.Reason === "AgentInitiatedCallback") {
                if (isDynamicCRMEnabled) DynamicsCRMEndChatPopUpScreen(event);
                if (isNiceIntegration) custom_PushMessageToNICE(event.InteractionID, global_UCID[event.InteractionID]);
            }
            else if (event.Reason === "CustomerInitiatedCallback") {
                if (isDynamicCRMEnabled) DynamicsCRMEndChatPopUpScreen(event);
                if (isNiceIntegration) custom_PushMessageToNICE(event.InteractionID, global_UCID[event.InteractionID]);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.TextChatDisconnectedCustom()", ex, false);
    }
}

function InvokeRestCallDoneCustom(userObject, resultData) {
    try {
        switch (userObject.source) {
            case "moxtra":
                ProcessMoxtraRestCallResponse(userObject, resultData);
                break;
            case "cacs":
                ProcessCACSRestCallResponse(userObject, resultData);
                break;
            default:
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.InvokeRestCallDoneCustom()", ex, false);
    }
}

function ProcessMoxtraCommands(jsonData) {
    try {
        switch (jsonData.command) {
            case "chatended":
                //get the item from global_ChatReference for moxtra
                var item = global_ChatReference.filter(function (chatRef) {
                    if (chatRef.customJson) return chatRef.customJson.binderid === jsonData.data;
                });
                //if item is there then end the chat from TMAC UI
                if (item && item.length > 0) {
                    if (!GetChatReferenceObj(item[0].intid).isDisconnected) {
                        EndChat(item[0].intid, "MoxtraEndedChat");
                    }
                    else {
                        log.LogDetails("Error", "CustomMethods.ProcessMoxtraCommands()", "Chat is disconnected by agent, skip post message chatended.", false);
                    }
                }
                else {
                    log.LogDetails("Error", "CustomMethods.ProcessMoxtraCommands()", "chat reference not found", false);
                }
                break;
            default:
                log.LogDetails("Warning", "CustomMethods.ProcessMoxtraCommands()", "case is not defined in switch", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.ProcessMoxtraCommands()", ex, false);
    }
}

function ChangeMoxtraURL(intid) {
    try {
        UIkit.modal.confirm('Are you sure to change the URL?', function () {
            var customChatConfig = customChatConfigs.filter(function (i) { return i.source === "moxtra"; })[0];
            var activeUrlIndex;
            $.each(customChatConfig.urls.moxtraUrls, function (i, val) {
                if (val.tmacServerName === customChatConfig.urls.activeUrl) {
                    activeUrlIndex = i;
                    return;
                }
            });
            activeUrlIndex = ++activeUrlIndex % customChatConfig.urls.moxtraUrls.length;
            var activeUrlObj = customChatConfig.urls.moxtraUrls[activeUrlIndex];
            customChatConfig.urls.activeUrl = activeUrlObj.tmacServerName;
            var url = GetChatReferenceObj(intid).customJson.agentUrl;
            url = url.replace(/^https?:\/\/[^/]+/, activeUrlObj.url);
            url = AddUrlParam(url, "reopen", "Y");
            GetChatReferenceObj(intid).customJson.agentUrl = url;
            $("#chat_chat_frame" + intid).attr("src", url);
            $("#activeUrlName" + intid).text(activeUrlObj.name);
            GetChatReferenceObj(intid).customJson.urlChanged = true;
        });
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.ChangeMoxtraURL()", ex, false);
    }
}

function ProcessMoxtraRestCallResponse(userObject, resultData) {
    try {
        switch (resultData.method) {
            case "leavechat":
                console.log("resultData", resultData);
                break;
            default:
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.ProcessMoxtraRestCallResponse()", ex, false);
    }
}

function ProcessCACSRestCallResponse(userObject, resultData) {
    try {
        log.LogDetails("Info", "CustomMethods.ProcessCACSRestCallResponse()", "Method: " + userObject.method + ", Response: " + resultData.d, false);
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.ProcessCACSRestCallResponse()", ex, false);
    }
}

function FormatOutgoingTextChat(text, type, isAppMessage) {
    var data = {
        isAppMessage: isAppMessage, //if the message to be sent as app message, for app messages only text is required
        text: text, //message,src etc
        type: type //image, audio, video, text, file :: for files type should be <file_filetype>
    };
    try {
        //message can be formatted here
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.FormatOutgoingTextChat()", ex, false);
    }
    return data;
}

function FormatSentTextChat(event, isTemplate) {
    try {
        //Message - string

        //IsAppMessage - bool
        //ConferenceType - string
        //IsRelayMessage - bool
        //IsOfflineMessage - bool
        //ChatIntId - string
        //DateTime - string
        //Result - bool
        //MessageId - string
        //EventId - string
        //isTemplate -bool :: TextChatMessageTemplateSentEvent
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.FormatSentTextChat()", ex, false);
    }
}

function FormatIncomingTextChat(isAppMessage, msgId, msg, mediaType, isReply, replyJson, attachment) {
    var data = {
        isAppMessage: isAppMessage, //received message is a app message flag
        messageId: msgId, //id of the message
        message: msg, //message,src etc
        mediaType: mediaType, //image, audio, video, text, file :: for files type will be <file_filetype>
        isReply: isReply, // is a reply to message falg
        replyJson: replyJson, //reply message json
        attachment: attachment ? attachment : null
    };
    try {
        //message can be formatted here
    } catch (ex) {
        log.LogDetails("Error", "CustomMethods.FormatIncomingTextChat()", ex, false);
    }
    return data;
}

// send call status to campaign manager iframe
function SendCallStatusToCamp(intid, type) {
    try {
        var campIframeWindow = document.getElementById("ui_custom_frame" + intid).contentWindow;
        campChildframeWindow = campIframeWindow.document.getElementById("campaign_iframe").contentWindow;
        campChildframeWindow.SendCallStatusToSurvey(type);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.SendCallStatusToSurvey()", ex, false);
    }

}

//calls campaign method and validates true or false
function IsCloseTabAllowedFromCampaign(intid) {
    try {
        var frameId = "ui_custom_frame" + intid;
        var campaignSelectorWindow = document.getElementById(frameId).contentWindow;
        var tmacCampaignWindow = campaignSelectorWindow.campaignChildWindow;
        var result = tmacCampaignWindow.ValidateRecordSubmission();
        if (!result.isRecordSubmitted) {
            log.LogDetails("Error", "CampUI.IsCloseTabAllowedFromCampaign()", result.message, true);
            return false;
        }
        return true;
    }
    catch (ex) {
        log.LogDetails("Error", "CampUI.IsCloseTab()", ex, false);
        return true;
    }
}

// Call campaign on force logout
function CampaignOnForceLogout() {
    try {
        $.each(global_InteractionTabs, function (i, val) {
            var intid = val.intid;
            // is the intid numeric
            if (!isNaN(intid)) {
                try {
                    // get campaign selector window
                    var campIframeWindow = document.getElementById("ui_custom_frame" + intid).contentWindow;
                    // get campaign window
                    campChildframeWindow = campIframeWindow.document.getElementById("campaign_iframe").contentWindow;
                    campChildframeWindow.OnClose();
                } catch (ex) {
                    //
                }
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "CampUI.CampaignOnForceLogout()", ex, false);
    }
}

function InsertTmacInteractionAction(intid, action, actionResult, details, loginInstanceId, sessionId, obj) {
    try {
        intid = intid ? intid : "";
        Custom_InvokeFunction("Custom_JsonFilesManager.dll", "Custom_JsonFilesManager.FileManager", "InsertTmacInteractionAction", [global_AgentID, intid, action, actionResult, details, loginInstanceId, sessionId], obj);

    } catch (ex) {
        log.LogDetails("Error", "CampUI.InsertTmacInteractionAction()", ex, false);
    }
}

var TmacCustomLogic = new function () {
    let _this = this;


    _eventHandler = {
        AgentStatusChangeEvent: function (e) {
            try {
                if (typeof faceApiIntegration !== "undefined") {
                    faceApiIntegration.onAgentStatusChange(e);
                }

                if (typeof tcisCon !== "undefined") tcisCon.sendAgentCurrentStatus();
            } catch (ex) {
                log.LogDetails("Error", "custom_methods.TmacCustomLogic.eventhandler.AgentStatusChangeEvent()", ex, false);
            }
        }
    };

    function _handleEvent(e) {
        if (typeof _eventHandler[e.EventName] === "function") {
            _eventHandler[e.EventName](e);
        }
    }

    _this.filesLoaded = [];

    _this.onAgentDataReceived = function (data) {
        try {
            let agentFeatures = data.AgentFeatures;
            let that = this;
            let features = {};
            $.each(agentFeatures, function (i, feature) {
                features[feature.Feature] = feature.IsEnabled;
            });
            if (features.IsCameraCaptureEnabled || features.IsScreenCaptureEnabled) {
                loadFile("tmac_scripts/snapshot_ui.js", "", function () { })
            }
            if (features.IsFaceAuthenticationEnabled || features.IsFaceCountCheckEnabled) {
                if (typeof FaceCompare === "undefined" && that.filesLoaded.indexOf("FaceCompare") < 0) {
                    loadFile("tmac_scripts/tmac_sdk/tmac_faceApi.js", "", function () {
                        tmac_faceApi.loadLibraries(function (str) {
                            loadFile("tmac_scripts/face_api_integration.js", "", function () {
                                if (features.IsFaceAuthenticationEnabled) {
                                    faceApiIntegration.isFaceAuthenticationEnabled = true;
                                    if (!features.IsFaceLivenessDetectionEnabled)
                                        faceApiIntegration.doFaceAuthentication();
                                }
                                if (features.IsFaceCountCheckEnabled) {
                                    faceApiIntegration.getFaceCountAndPredictionLoop.start();
                                }
                                if (features.IsFaceLivenessDetectionEnabled) {
                                    faceApiIntegration.IsFaceLivenessDetectionEnabled = true;
                                    setTimeout(function () {
                                        faceApiIntegration.testLivenessDetection({
                                            onSuccess: function (successCount, maxTries) {
                                                faceApiIntegration.doFaceAuthentication({
                                                    onError: function () {
                                                        ChangeStatus(global_DeviceID, "aux", 0);
                                                        faceApiIntegration.livenessDetectedSuccessful = false;
                                                    }
                                                });
                                            },
                                            onError: function (successCount, maxTries) {
                                                ChangeStatus(global_DeviceID, "aux", 0);
                                                faceApiIntegration.livenessDetectedSuccessful = false;
                                            }
                                        });
                                    }, 4000);
                                }
                            });
                            that.filesLoaded.push("FaceCompare");
                        }, function (err) {
                            console.error(err);
                        });
                    });
                }
            }
            if (features.IsTcisConnectionEnabled) {
                if (typeof tcisCon === "undefined" && that.filesLoaded.indexOf("tcisCon") < 0) {
                    loadFile("tmac_scripts/tcis_integration.js");
                    that.filesLoaded.push("tcisCon");
                }
            }
			if (features.IsTcieEnabled && that.filesLoaded.indexOf('tcie') < 0) {
				loadFile("tmac_scripts/TCIEIntegration.js");
				that.filesLoaded.push("tcie");
			}
        } catch (ex) {
            log.LogDetails("Error", "custom_methods.TmacCustomLogic.onAgentDataReceived()", ex, false);
        }
    }

    // add event listener to get tmac events
    window.addEventListener("TMACEvents", function (e) {
        _handleEvent(e.detail);
    });
};

function loadFile(url, attributes, callback) {
    try {
        let arr = url.split('.');
        // get extension of the url
        let ext = (arr.length > 1) ? arr[arr.length - 1] : "";
        ext = ext.split('?')[0];
        let html;
        if (ext === "css") {
            html = `<link rel="stylesheet" href="` + url + `" ` + attributes + ` />`;
            // append tag to document body
            $('body').append(html);
            return true;
        } else if (ext === "js" || ext === "") {
            var script = document.createElement('script');
            script.src = url;
            script.async = false;
            script.type = "text/javascript";
            script.onload = callback ? callback : console.log(url + " loaded dynamically");
            script.onerror = function (err) { console.error(err) };
            document.body.appendChild(script);
            return true;
        } else {
            return false;
        }

    } catch (ex) {
        console.error(ex);
    }
    return false;
}

(function () {
    try {
        $.each(loadFilesList, function (i, val) {
            let arr = val.split(',');
            let url = arr[0];
            let attributes = (arr.length > 1) ? arr[1] : "";
            loadFile(url, attributes);
        });
    } catch (e) {
        //
    }
})();


function tcis_confirmReleaseBlackout(event) {
    try {
        let data = JSON.parse(event.JsonData);
        let html = `<div style="height: 85vh;overflow-y: auto;">
				<b>Clear the blackout for agent ` + data.agentName + ` (` + data.agentId + `)</b>
				<p> Token: ` + data.token + `</p>
				<p><span class="material-icons notranslate">warning</span>`+ data.violation + ` </p>
				<hr class="uk-grid-divider">
				<div class="uk-grid uk-grid-divider">					
					<div class="uk-width-medium-1-1">
						<p class="uk-text-bold uk-margin-remove">Snapshot</p>
						<img src="` + data.snapshotUrl + `"/>
					</div>
				</div>
				<hr class="uk-grid-divider">
				<div class="uk-grid">
					<div class="uk-width-medium-1-1">
						<p class="uk-text-bold uk-margin-remove">Screenshot</p>
						<img src="` + data.screenshotUrl + `"/>
					</div>
				</div>				
			</div>`;
        UIkit.modal.confirm(html, function () {
            let eventData = {
                EventName: "GenericTMACEvent",
                SubEventName: "tcis_confirmReleaseBlackoutResponse",
                JsonData: JSON.stringify({
                    status: "approved",
                    token: data.token,
                    tmacServerId: _tmacServer
                })
            };
            tmac_AddEventToAgentSession(null, {}, data.agentId, eventData, true, data.tmacServerId);
        }, { labels: { 'Ok': 'Yes', 'Cancel': 'No' } });
    } catch (ex) {
        log.LogDetails("Error", "TcisIntegration.tcis_confirmReleaseBlackout()", ex, false);
    }
}


function tcis_displayAgentViolationPopup(event) {
}

function googleTranslateElementInit() {
    new google.translate.TranslateElement({ pageLanguage: 'en' }, 'google_translate_element');
}