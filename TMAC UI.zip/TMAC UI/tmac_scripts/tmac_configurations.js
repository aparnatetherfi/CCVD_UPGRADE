// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacConfigurations.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //need not add in versioning as this is invoked before CommonUI.
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
let tmacScripts = "tmac_scripts";
let startLoadingScripts = false;
let scriptsUrls = [];

var dynamicFiles = {
    signalRConnector: "signalr_connector.js",
    facebookUi: "social_media/facebook_ui.js",
    twitterUi: "social_media/twitter_ui.js",
    lineUi: "social_media/line_ui.js",
    textchatUi: "tmac_text_chat_ui.js",
    faxUi: "fax_ui.js",
    smsUi: "sms_ui.js",
    dynamicCrm: "dynamic_crm.js",
    dynamicXrm: "dynamic_xrm.js",
    iServe: "iserve_commands.js",
    fileUtilities: "file_utilities.js",
    agentChat: "agent_chat.js",
    customerChat: "customer_chat.js",
    voiceBioUi: "voice_bio_ui.js",
    interactionHistory: "interacton_history.js",
    campUi: "camp_ui.js",
    pomUi: "pom_ui.js",
    facetouchUi: "facetouch_ui.js",
    snapShotUi: "snapshot_ui.js",
    cobrowseJs: "tetherfi_av_kit/tetherfi-tmac-cobrowse.js",
    cobrowseCss: "tetherfi-cobrowse.min.css"
};

dynamicApiFiles = {
    facebookApi: "tmac_sdk/tmac_facebookApi.js",
    textchatApi: "tmac_sdk/tmac_textChatApi.js",
    smsApi: "tmac_sdk/tmac_smsApi.js",
    faxApi: "tmac_sdk/tmac_faxApi.js",
    adapter: "tetherfi_av_kit/adapter.min.js",
    // WebRtcPeerConnectionApi: "tetherfi_av_kit/WebRtcPeerConnectionApi_debug.js",
    // WebRtcPeerConnectionImpl: "tetherfi_av_kit/WebRtcPeerConnectionImpl_debug.js",     //  ReviewCodeLine: debug files. Comment these and uncomment the below two while releasing
    WebRtcPeerConnectionApi: "tetherfi_av_kit/WebRtcPeerConnectionApi.js",
    WebRtcPeerConnectionImpl: "tetherfi_av_kit/WebRtcPeerConnectionImpl.js",
    RecordRTC: "tetherfi_av_kit/RecordRTC.js",
    WhammyInWebWorker: "tetherfi_av_kit/WhammyInWebWorker.js",
    WebRtcConnector: "tetherfi_av_kit/WebRtcConnector.js",
    //WebRtcGetStats: "tetherfi_av_kit/WebRTCGetStats.js", [depricated]
    collector: "tetherfi_av_kit/collector.min.js"
};

var dynamicPluginFiles = {
    tour: "tour.js",
    sanitize: "sanitizeHTML/sanitize.js",
    highlightTextarea: "js/jquery.highlighttextarea.min.js",
    tiffJs: "tiffreader/tiff.min.js",
    printThis: "printThis/printThis.js",
    pdfKit: "pdf.kit/pdf.js",
    pdfWorker: "pdf.kit/pdf.worker.js",
    pdfRender: "pdf.kit/pdf.render.js",
    drawJs: "pdf.kit/draw.js",
    agentNotes: "notes/notes.min.js",
    emojioneCss: "emoji/emojione.min.css",
    emojioneareaCss: "emoji/emojionearea.min.css",
    emojioneJs: "emoji/emojione.min.js",
    jqueryTextcomplete: "emoji/jquery.textcomplete.js",
    emojioneareaJs: "emoji/emojionearea.min.js",
    faceTouchMonitor: "facetouch/facetouch.js"
};

$(function () {
    try {
        console.log("Tmac configurations js loaded");
        //for single page login set the height to max and remove the loader
        if (isSinglePageLogin) {
			let loginPageUrl = "Login.aspx";
			let queryString = location.href.match(/\?(.*)/g);
			
            $("#login_iframe").attr("src",  (queryString) ? "Login.aspx" +queryString : "Login.aspx");
            //resize to configured in global vars
            window.resizeTo(CalculateTMACWindowWidth(), CalculateTMACWindowHeight());
            //dock to the right
            window.moveTo(screen.width, screen.height);
            $("#login_iframe").height($(window).height());
            $(".an-loader").addClass("uk-display-none");
        }
        else {
            $("#login_iframe").remove();
        }
    } catch (ex) {
        console.error(ex);
    }
});

function LoadConfigurations() {
    try {

        $("#favicon").attr("href", "assets/img/" + favionIcon + ".png");
        //var logo_height = (parseInt(tmac_header_footer_height.substring(0, 2)) - 5) + "px";
        //header a tag height
        $("#header_main .uk-navbar .uk-navbar-nav > li > a").css("height", tmac_header_footer_height);
        //header a element line height
        $("#header_main .uk-navbar .uk-navbar-nav > li > a").css("line-height", tmac_header_footer_height);
        //header logo element height
        $(".main_logo_top").css("height", tmac_header_footer_height);
        //header logo element line height
        $(".main_logo_top").css("line-height", tmac_header_footer_height);
        //header logo element a tag height
        $(".main_logo_top > a").css("height", tmac_header_footer_height);
        //header logo element a tag line height
        $(".main_logo_top > a").css("line-height", tmac_header_footer_height);
        //header logo element img tag max height
        //$(".main_logo_top>a img").css("max-height", logo_height);
        //main header height
        $("#header_main").css("height", tmac_header_footer_height);
        //body padding top for header
        $("body").css("padding-top", tmac_header_footer_height);
        //sidebar top, bottom
        $("#sidebar_main").css("top", tmac_header_footer_height);
        $("#sidebar_main").css("bottom", tmac_header_footer_height);
        //footer line height
        $("#footer").css("line-height", tmac_header_footer_height);
        //footer uk-grid height
        $("#footer .uk-grid").css("height", tmac_header_footer_height);
        //sidebar secondary height
        $("#sidebar_secondary").css("top", tmac_header_footer_height);
        //enable/disable features
        $("#sidebar_main_toggle").toggle(isFullTMAC);
        //enable/disable tmac screen toggle 
        //$("#tmac_screen_toggle").toggle(isTmacScreenToggle);
        //$("#full_screen_toggle").toggle(isTmacScreenToggle);

        //full tmac configurations
        if (isFullTMAC) {
            $("#sidebar_main_toggle").removeClass("uk-hidden-small");
            $("#side_agent_info_panel").toggle(true);
            $("#div_wallboardGrid_side").toggle(isWallboard);
            if (openLeftSidePanel) $("#bodyfullscreen").addClass("sidebar_main_open");
            $("#div-user-block").remove();
            if (isTour) LoadCustomJs(tmacScripts, dynamicPluginFiles.tour);
        }
        else {
            $("#div_wallboardGrid_main").toggle(isWallboard);
        }

        if (isSignalrConnector) {
            //LoadCustomJs("assets", dynamicPluginFiles.signalRServer);
            LoadCustomJs(tmacScripts, dynamicFiles.signalRConnector);
        }

        if (isDashboardEnabled && !isFullTMAC) {
            $("#dashboard_interval_grid").toggle(true);
            $("#dashboard_grid").toggle(true);
            $(".mini-dashboard").addClass("uk-width-small-1-" + globalChannelList.length);
            $.each(globalChannelList, function (i, val) {
                $(".mini-dashboard-" + val.toLowerCase()).removeClass("uk-display-none");
            });
        }

        if (isFbEnabled) {
            LoadCustomJs(tmacScripts, dynamicApiFiles.facebookApi);
            LoadCustomJs(tmacScripts, dynamicFiles.facebookUi);
        }

        if (isTwitterEnabled) {
            LoadCustomJs(tmacScripts, dynamicFiles.twitterUi);
        }

        if (isLineEnabled) {
            LoadCustomJs(tmacScripts, dynamicFiles.lineUi);
        }

        if (isChatEnabled) {
            if (isSanitizeHtml) LoadCustomJs("components", dynamicPluginFiles.sanitize);
            if (isGrammerCheck) LoadCustomJs("assets", dynamicPluginFiles.highlightTextarea);
            LoadCustomJs(tmacScripts, dynamicApiFiles.textchatApi);
            LoadCustomJs(tmacScripts, dynamicFiles.textchatUi);
            if (isEmojiEnabled) {
                LoadCustomCss("components", dynamicPluginFiles.emojioneCss);
                LoadCustomCss("components", dynamicPluginFiles.emojioneareaCss);

                LoadCustomJs("components", dynamicPluginFiles.emojioneJs, function () {
                    console.log(dynamicPluginFiles.emojioneJs + " is loaded dynamically");
                    emojione.imagePathPNG = './components/emoji/emoji/';
                });
                LoadCustomJs("components", dynamicPluginFiles.jqueryTextcomplete);
                LoadCustomJs("components", dynamicPluginFiles.emojioneareaJs);
            }
        }

        if (isFaxEnabled) {
            LoadCustomJs(tmacScripts, dynamicApiFiles.faxApi);
            LoadCustomJs("components", dynamicPluginFiles.tiffJs);
            LoadCustomJs(tmacScripts, dynamicFiles.faxUi);
            if (isPrintFax)
                LoadCustomJs("components", dynamicPluginFiles.printThis);
        }


        if (isSMSEnabled) {
            LoadCustomJs(tmacScripts, dynamicApiFiles.smsApi);
            LoadCustomJs(tmacScripts, dynamicFiles.smsUi);
        }

        //  VP: Jul 13,' 20: Moved from TMAC_UI.js to here. 
        //  If chat or SMS enabled then get all the templates
        if (isChatEnabled || isSMSEnabled) {
            //load chat templates in an interval of config
            LoadAllChatTemplates();
        }

        //load iserver command js if enabled
        if (isIServe) {
            LoadCustomJs(tmacScripts, dynamicFiles.iServe);
        }

        //load dynamic crm js if enabled
        if (isDynamicCRMEnabled) {
            LoadCustomJs(tmacScripts, dynamicFiles.dynamicCrm);
        }

        //load dynamic xrm js if enabled
        if (isDynamicXRMEnabled) {
            LoadCustomJs(tmacScripts, dynamicFiles.dynamicXrm);
        }

        //enable scripts and features for RM
        if (isPDFAndImageEditingAllowed) {
            LoadCustomJs("components", dynamicPluginFiles.pdfKit);
            LoadCustomJs("components", dynamicPluginFiles.pdfWorker);
            LoadCustomJs("components", dynamicPluginFiles.pdfRender);
            LoadCustomJs("components", dynamicPluginFiles.drawJs);
        }

        if (isAttachement || isCamera || isVoiceNote) {
            LoadCustomJs(tmacScripts, dynamicFiles.fileUtilities);
        }

        if (isAVEnabled) {
            LoadCustomJs(tmacScripts, dynamicApiFiles.adapter);
            LoadCustomJs(tmacScripts, dynamicApiFiles.WebRtcPeerConnectionApi);
            LoadCustomJs(tmacScripts, dynamicApiFiles.WebRtcPeerConnectionImpl);
            LoadCustomJs(tmacScripts, dynamicApiFiles.WebRtcConnector);
            LoadCustomJs(tmacScripts, dynamicApiFiles.collector);
            // load the following js file only if ui recording is enabled
            if (webRTCApiConfig.getRecordingOptions.enabled) {
                LoadCustomJs(tmacScripts, dynamicApiFiles.RecordRTC);
                LoadCustomJs(tmacScripts, dynamicApiFiles.WhammyInWebWorker);
            }
        }

        if (isAgentChat) {
            //enable agent list for agent chat
            $("#agentListCard").toggle(true);
            LoadCustomJs(tmacScripts, dynamicFiles.agentChat);
            $("#sidebar_secondary_toggle").removeClass("uk-hidden-small uk-hidden-medium uk-hidden-large");
        }

        if (isAgentNotes) {
            LoadCustomJs("components", dynamicPluginFiles.agentNotes);
            $('#btnAgentNotes').removeClass("uk-display-none-important");
        }
        else {
            $('#btnAgentNotes').remove();
        }

        if (isSupervisor) {
            //to enable agent chat ui
            if (!isAgentChat) {
                LoadCustomJs(tmacScripts, dynamicFiles.agentChat);
            }
        }

        // if (isCustomerChat) {
        //     //enable customer list for customer chat
        //     $("#customerListCard").toggle(true);
        //     LoadCustomJs(tmacScripts, dynamicFiles.customerChat);
        //     $("#sidebar_secondary_toggle").removeClass("uk-hidden-small uk-hidden-medium uk-hidden-large");
        // }

        //configurations for Voice bio
        if (isVoiceBio) {
            $("#fontsCSS").attr("href", "assets/css/fonts/verdana_vb.css");
            LoadCustomJs(tmacScripts, dynamicFiles.voiceBioUi);
            $(".card-user-block").addClass("voice-bio-card");
            $("#style_switcher_toggle").remove();
            $("#tmac_utils").remove();
            $("#tmac_help").removeClass("uk-display-none");
            $("header").remove();
            $("footer").remove();
            $("body").css("padding-top", "0px");
        }

        if (isInteractionHistory) {
            LoadCustomJs(tmacScripts, dynamicFiles.interactionHistory);
        }

        if (isVoiceDataWindow) {
            if (voiceDataWindowType === "campaign")
                LoadCustomJs(tmacScripts, dynamicFiles.campUi);
        }

        //configuration for POM
        if (isPOM) {
            LoadCustomJs(tmacScripts, dynamicFiles.pomUi);
            if (isCACS) {
                $("#btn_change_status").css("width", "150px");
            }
        }

        //load the facetouch monitor js if enabled
        if (typeof enableFaceTouchMonitor !== "undefined" && enableFaceTouchMonitor) {
            LoadCustomJs("components", dynamicPluginFiles.faceTouchMonitor);
            LoadCustomJs(tmacScripts, dynamicFiles.facetouchUi);
        }

        //enable/disable blind transfer button
        if (isBlindTransfer) {
            $("#btndialogblindtransfercall").removeClass("uk-display-none-important");
        }

        if (coBrowse.Enabled) {
            LoadCustomCss("assets/css", dynamicFiles.cobrowseCss);
            LoadCustomJs(tmacScripts, dynamicFiles.cobrowseJs);
        }

        // to enable google translator for page
        if (enableGoogleTranslate) {
            $("#g_translate").removeClass("uk-display-none");
            $("body").addClass("top-0");
            setTimeout(function () {
                $(".goog-te-combo").addClass("md-input");
            }, 3000);
            $(".material-icons").each(function (index) {
                $(this).addClass("notranslate");
            });
        }

        //now load all the scripts together
        startLoadingScripts = true;
        LoadCustomJs("", "");
    } catch (ex) {
        console.error(ex);
    }
}

function LoadCustomHTML(folderName, fileName, loadTo) {
    try {
        var url = "";
        if (folderName !== "")
            url = folderName + "/" + fileName;
        else
            url = fileName;
        $("#" + loadTo).load(url, function () {
            console.log(fileName + " loaded dynamically");
        });
    } catch (ex) {
        console.error(ex);
    }
}

function LoadCustomCss(folderName, fileName) {
    try {
        var url = folderName + "/" + fileName;
        var link = document.createElement('link');
        link.href = url;
        link.rel = "stylesheet";
        link.onload = console.log(fileName + " loaded dynamically");
        document.head.appendChild(link);
    } catch (ex) {
        console.error(ex);
    }
}

function LoadCustomJs(folderName, fileName, callback) {
    try {
        var url = folderName + "/" + fileName + "?v=2";
        if (startLoadingScripts) {
            scriptsUrls.forEach(function (item, i, array) {
                var script = document.createElement('script');
                script.src = item.url;
                script.async = false;
                script.type = "text/javascript";
                script.onload = item.callback ? item.callback : console.log(item.fileName + " loaded dynamically");
                document.body.appendChild(script);
                if (i === array.length - 1) {
                    DynamicScriptsLoaded();
                }
            });
        }
        else {
            scriptsUrls.push({ fileName: fileName, url: url, callback: callback });
        }
    } catch (ex) {
        console.error(ex);
    }
}