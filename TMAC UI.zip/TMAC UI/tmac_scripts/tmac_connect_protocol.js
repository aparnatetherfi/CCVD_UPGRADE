﻿var version_tmac_connect_protocol = "4.1.2.15";

//this is the first document.ready to load
$(document).ready(function () {
  console.log("tmac connect protocols loaded");
});

$.holdReady(true);

function getQueryStringValue(key) {
  return unescape(
    window.location.search.replace(
      new RegExp(
        "^(?:.*[&\\?]" +
        escape(key).replace(/[\.\+\*]/g, "\\$&") +
        "(?:\\=([^&]*))?)?.*$",
        "i"
      ),
      "$1"
    )
  );
}

var tmacconnectprotocol = "asmx"; //asmx , ws, rest, signalr
var protocol = getQueryStringValue("protocol");

if (protocol !== "") {
  if (protocol === "ws" ||
    // protocol === "webapi" ||
    protocol === "asmx") {
    window.tmacconnectprotocol = protocol;
    // tmac_send_protocol_to_popup = true;
  }
}
loadingCompleted = true;
$.holdReady(false);

var tmacProxyList = [];

// signalr protocol
var tmac_signalr_protocol = "webSockets";
