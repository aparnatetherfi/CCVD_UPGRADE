﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Logger.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

var Logger = function () {
    this.logType = {
        Success: "Success",
        Info: "Info",
        Warning: "Warning",
        Error: "Error"
    }
}
/*
    In-herit the Logger and add more features to this Object.
*/
Logger.prototype = {
    LogDetails: function (logtype, method, message, showpopup) {
        let $userDevice = "[" + global_AgentID + " - " + global_DeviceID + "]";
        let $messageWithUser = $userDevice + " - " + message;
        let $log = this;
        let $notify = this;
        let formatedtxt = $log.FormatLog(logtype, method, $messageWithUser);
        if (logtype === undefined || logtype === null || logtype == "") logtype = "Info";
        if (method.indexOf("AddMessageAlerts") < 0 && !showpopup && logtype == "Error")
            console.error(formatedtxt);
        else
            console.log(formatedtxt);
        if (showpopup) {
            switch (logtype) {
                case this.logType.Success:
                    //$notify.ShowNotify('[ ' + method + ' ] ::' + message, "success", null, "top-center");
                    $notify.ShowNotify(message, "success", null, "top-center");
                    break;
                case this.logType.Info:
                    $notify.ShowNotify(message, "info", null, "top-center");
                    break;
                case this.logType.Warning:
                    $notify.ShowNotify(message, "warning", null, "top-center");
                    break;
                case this.logType.Error:
                    $notify.ShowNotify(message, "danger", null, "top-center");
                    break;
                default:
                    $notify.ShowNotify(message, "", null, "top-center");
                    break;
            }
            AddMessageAlerts(logtype.toLowerCase() == "error" ? "danger" : logtype.toLowerCase(), message);
        }
        /**
         * Remote Logging:  based on window.remoteLogging
         */
        let config = window.remoteLogging;
        let $that = this;
        switch (logtype) {
            case this.logType.Success:
                if (config.Success) $that.RemoteLogging(method, $messageWithUser, logtype);
                break;
            case this.logType.Info:
                if (config.Info) $that.RemoteLogging(method, $messageWithUser, logtype);
                break;
            case this.logType.Warning:
                if (config.Warning) $that.RemoteLogging(method, $messageWithUser, logtype);
                break;
            case this.logType.Error:
                if (config.Error) $that.RemoteLogging(method, $messageWithUser, logtype);
                break;
            default:
                $that.RemoteLogging(method, $messageWithUser, logtype);
                break;
        }
    },
    /*
        system current date and time
    */
    systemDateTime: function () {
        var currentdate = new Date();
        var datetime = currentdate.getDate() + "/" +
            (currentdate.getMonth() + 1) + "/" +
            currentdate.getFullYear() + " " +
            currentdate.getHours() + ":" +
            currentdate.getMinutes() + ":" +
            currentdate.getSeconds();

        return datetime;
    },
    /*
        Format the log message
    */
    FormatLog: function (type, method, message) {
        var $log = this;
        return $log.systemDateTime() + ' [' + type + '] [' + method + '] :: ' + message;
    },
    ShowNotify: function (message, status, group, pos) {
        try {
            var thisNotify = UIkit.notify({
                message: message ? message + '<a href="#" class="notify-action">X</a>' : '',
                status: status ? status : '',
                timeout: notifyTimeout ? notifyTimeout : 3000,
                group: group ? group : null,
                pos: pos ? pos : 'top-center',
                onClose: function () {
                    $body.find('.md-fab-wrapper').css('margin-bottom', '');
                    // clear notify timeout (sometimes callback is fired more than once)
                    clearTimeout(thisNotify.timeout);
                }
            });
            if ((($window.width() < 768) && ((thisNotify.options.pos == 'bottom-right') || (thisNotify.options.pos == 'bottom-left') ||
                (thisNotify.options.pos == 'bottom-center'))) || (thisNotify.options.pos == 'bottom-right')) {
                var thisNotify_height = $(thisNotify.element).outerHeight();
                var spacer = $window.width() < 768 ? -6 : 8;
                $body.find('.md-fab-wrapper').css('margin-bottom', thisNotify_height + spacer);
            }
        } catch (e) {
            console.log(e);
        }
    },

    /**
     * Ajax Errors
     * @param {} xhr 
     * @param {} exception 
     * @param {} settings 
     * @returns {} 
     */
    OnAjaxError: function (xhr, exception, settings) {
        try {
            //responseText = jQuery.parseJSON(xhr.responseText);
            var message = //"Exception : " + exception + "\n" +
                "Url : " + settings.url + " [" + settings.type + "]" + "\n" +
                "Status : " + xhr.statusText + " [" + xhr.status + "]" + "\n" +
                "ContentType : " + settings.contentType + "\n" +
                "Message : " + xhr.responseText;
            console.log(message, this.logType.Error);
            /**
             * Remote Logging:  based on window.remoteLogging
             */
            var config = window.remoteLogging;
            var $that = this;
            if (config.Error) $that.RemoteLogging(settings.url, message, this.logType.Error);
        } catch (e) {
            console.log(xhr.responseText);
        }
    },

    /**
     * Remote logging all the Client Errors
     * @returns {} 
     */
    RemoteLogging: function (method, message, logtype) {
        var $that = this;
        var messagetoLog = "";
        messagetoLog = 'Method : ' + method;
        messagetoLog += ' :: Message : ' + message;
        try {
            var jsonData = {
                'JsonObject': JSON.stringify(messagetoLog),
                'LogType': logtype
            };

            if (window.tmacconnectprotocol === "ws") {
                InvokeWSProxyMethod(null, null, jsonData, "LogClientLogs", 60000);
                return;
            }
            else if (window.tmacconnectprotocol === "signalr") {
                InvokeSignalrProxyMethod(null, null, jsonData, "LogClientLogs");
                return;
            }

            if (!global_connectedProxy) {
                return;
            }

            var url = global_connectedProxy + "LogClientLogs";
            $.ajax({
                url: url,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(jsonData),
                dataType: 'json',
                async: true,
                success: function (response) {
                    if (response.StatusCode !== "0") {
                        //$that.LogDetails($that.logType.Info, "RemoteLogging", response.Status, false);
                    } else {
                        //$that.LogDetails($that.logType.Error, "RemoteLogging", response.Status, false);
                    }
                },
                error: function (response) {
                    console.error("[RemoteLogging] :: [AjaxError] :: " + response.responseText);
                }
            });
        } catch (exception) {
            console.error("[RemoteLogging] :: " + exception.message);
        }
    }
};
//----------------------------------------------------------------------------------