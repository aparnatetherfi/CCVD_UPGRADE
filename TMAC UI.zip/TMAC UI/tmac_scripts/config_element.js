// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
try {
    let filename = "ConfigElement.js";
    var file_version = "4.1.2.15";
    var changedBy = "Vishal Pinto";
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------

const AppConfigs = {
    Local: {},
    Remote: {},
    URLs: {}
};

var ConfigElement = function () { };

ConfigElement.prototype = {

    /**
     * Loads the config and links from local JSON file
     */
    LoadLocal: function () {
        try {
            var hasFailed = false;

            //  Load links configs
            $.ajax({
                dataType: "json",
                url: "configs/links.json",
                cache: false,
                async: false,
                success: function (json) {
                    AppConfigs.URLs = json;
                    console.info("%c [config_element.LoadLocal] : Links loaded.", "background: green; color: white");
                },
                error: function (response) {
                    console.error("%c [config_element.LoadLocal] : Error occurred while fetching links.json. Format could be wrong.", "background: red; color: white");
                    hasFailed = true;
                }
            });
            if (hasFailed) return false;

            //  load other local configs 
            $.ajax({
                dataType: "json",
                url: "configs/ui-local.json",
                cache: false,
                async: false,
                success: function (json) {
                    AppConfigs.Local = json;
                    console.info("%c [config_element.LoadLocal] : Local configs loaded.", "background: green; color: white");
                },
                error: function (response) {
                    console.error("%c [config_element.LoadLocal] : Error occurred while fetching ui-local.json. Format could be wrong.", "background: red; color: white");
                    hasFailed = true;
                }
            });
            if (hasFailed) return false;

            //  assign these local configs to existing configs
            return this.AssignOldConfigs("local");
        } catch (e) {
            console.log("%c [config_element.LoadLocal]: " + e, "background: red; color: white")
        }
        return false;
    },

    /**
     * Loads the configs from TMAC Server
     * @param {*} json : JSON configs from TMAC server
     * @param {*} status : nature of request. 0 means new login, 1 means existing logic.
     */
    LoadRemote: function (json, status) {
        try {
            //  For dev purpose only. If this key exists, configs which  will be loaded from TMAC server will be loaded from local.
            //  This should not go to onsite. DEV PURPOSES ONLY
            if (isConfigSourceLocal) {
                console.info("%c [config_element.LoadRemote]: Remote configs will be loaded locally. DEV MODE ON.", "background: blue; color: white");

                $.ajax({
                    dataType: "json",
                    url: "configs/ui-remote.json",
                    cache: false,
                    async: false,
                    success: function (json) {
                        AppConfigs.Remote = json;
                        log.LogDetails("Info", "config_element.LoadRemote", "Remote configs loaded.", false);
                    },
                    error: function (response) {
                        log.LogDetails("Error", "config_element.LoadRemote", "Remote configs JSON in local path is not valid.", false);
                        return false;
                    }
                });
            }
            else {
                if (json == null || json.length === 0) {
                    log.LogDetails("Info", "config_element.LoadRemote", "Remote configs JSON is not valid.", false);
                    return false;
                }
                AppConfigs.Remote = json;
            }
            return this.AssignOldConfigs("remote");
        } catch (e) {
            log.LogDetails("Error", "config_element.LoadRemote", e, false);
        }
        return false;
    },

    /**
     * Assigns the configs from JSON to old global vars
     * @param {*} type : "local" or "remote"
     */
    AssignOldConfigs: function (type) {
        try {
            if (type === "local") {

                {
                    //  Links assignment
                    // Main
                    supportDocUrl = AppConfigs.URLs.Main.SupportDoc;
                    supervisorLink = AppConfigs.URLs.Main.Supervisor;
                    workbenchLink = AppConfigs.URLs.Main.Workbench;
                    meetingFrameUrl = AppConfigs.URLs.Main.TMeet;
                    dashboardUrl = AppConfigs.URLs.Main.Dashboard;

                    // Proxy
                    tmacconnectprotocol = AppConfigs.URLs.Proxy.Protocol;
                    tmacProxyList = AppConfigs.URLs.Proxy.Links;
                    tmac_signalr_protocol = AppConfigs.URLs.Proxy.SignalRProtocol;

                    //  local configs assignment
                    // Login
                    isSinglePageLogin = AppConfigs.Local.Login.SinglePageEnabled;
                    isLoginMode = AppConfigs.Local.Login.Modes.Enabled;
                    loginMode = AppConfigs.Local.Login.Modes.Type;
                    disableLanId = AppConfigs.Local.Login.LanIdDisabled;
                    showNotificationDeniedAlert = AppConfigs.Local.Login.ShowNotificationDeniedAlert;
                    isAgentIdOnInvalidLanId = AppConfigs.Local.Login.PromptAgentIdOnInvalidLanID;
                    isStationAvailable = AppConfigs.Local.Login.StationEnabled;
                    isDomainList = AppConfigs.Local.Login.DomainListEnabled;
                    isLoginWithPassword = AppConfigs.Local.Login.LoginWithPasswordEnabled;

                    //  UISettings
                    isApplication_window_size_type_pixel = AppConfigs.Local.UISettings.WindowSize.IsTypeInPixel;
                    Application_window_width = AppConfigs.Local.UISettings.WindowSize.Width;
                    Application_window_height = AppConfigs.Local.UISettings.WindowSize.Height;
                    tmac_header_footer_height = AppConfigs.Local.UISettings.HeaderFooterHeight;

                    //  Main
                    isLogoutOnClose = AppConfigs.Local.Main.LogoutOnWindowClose;

                    // AppSettings
                    remoteLogging = AppConfigs.Local.AppSettings.RemoteLogging;
                    notifyTimeout = AppConfigs.Local.AppSettings.NotifyTimeout;
                    favionIcon = AppConfigs.Local.AppSettings.FaviconName;
                    registerPostMessages = AppConfigs.Local.AppSettings.RegisterPostMessages;
                    retryAjaxFail = AppConfigs.Local.AppSettings.RetryOnAjaxFail;
                    isDispatchTMACEvents = AppConfigs.Local.AppSettings.DispatchTMACEvents;
                    loadFilesList = AppConfigs.Local.AppSettings.FilesListToLoad;

                    // VoiceBio
                    isVoiceBio = AppConfigs.Local.VoiceBio.Enabled;
                    retryLogin = AppConfigs.Local.VoiceBio.RetryLogin;

                    // POM
                    isPOM = AppConfigs.Local.POM.Enabled;
                    isCACS = AppConfigs.Local.POM.CACSEnabled;

                }

                console.info("%c [config_element.AssignOldConfigs]: Local configs are assigned to existing globalvars successfully.", "background: green; color: white");
                return true;
            }

            if (type === "remote") {

                {
                    // UISettings
                    labelOnTitle = AppConfigs.Remote.UISettings.ShowLabelOnTitle;
                    titleName = AppConfigs.Remote.UISettings.TitleName;
                    isFullTMAC = AppConfigs.Remote.UISettings.FullTMACEnabled;
                    isDisableResize = !AppConfigs.Remote.UISettings.ResizeEnabled;
                    kendo_window_width = AppConfigs.Remote.UISettings.KendoWindowWidth;
                    modalOnDialog = AppConfigs.Remote.UISettings.ShowDialogAsModal;
                    isExpandCollapseOnIframes = AppConfigs.Remote.UISettings.ExpandOnIframes;
                    agentStationOnMain = AppConfigs.Remote.UISettings.Landing.ShowStationId;
                    agentStatusOnMain = AppConfigs.Remote.UISettings.Landing.ShowStatus;
                    agentProfileOnMain = AppConfigs.Remote.UISettings.Landing.ShowAgentProfile;

                    // Main
                    showNotificationDeniedAlert = AppConfigs.Remote.Main.ShowNotificationDeniedAlert;
                    notificationDuration = AppConfigs.Remote.Main.NotificationDuration;
                    openLeftSidePanel = AppConfigs.Remote.Main.ShowLeftPanelAfterLogin;
                    isCustomMainTab = AppConfigs.Remote.Main.CustomMainTabEnabled;
                    isPushNotification = AppConfigs.Remote.Main.PushNotificationEnabled;
                    isLoadAgentAux = AppConfigs.Remote.Main.LoadAuxByTeam;
                    initialStatus = AppConfigs.Remote.Main.InitialStatus;
                    popBroadcast = AppConfigs.Remote.Main.PopUpBroadcast;
                    logoutAux = AppConfigs.Remote.Main.LogoutAUX;
                    isDisableStatusOnCall = AppConfigs.Remote.Main.StatusChangeOnCallDisabled;
                    isCloseTabsOnTSC = AppConfigs.Remote.Main.CloseTabsOnStatusChange.Enabled;
                    skipCloseTabType = AppConfigs.Remote.Main.CloseTabsOnStatusChange.SkipOnTypes;
                    skipCloseTabStatus = AppConfigs.Remote.Main.CloseTabsOnStatusChange.SkipOnStatus;
                    closeTabLastStatus = AppConfigs.Remote.Main.CloseTabsOnStatusChange.CloseTabLastStatus;
                    isEnableCloseTabOnDisconnect = AppConfigs.Remote.Main.CloseTabOnDisconnectAllowed;
                    isCloseLoginPage = AppConfigs.Remote.Main.CloseLoginPageAfterLogin;
                    allowLogoutOnOpenTabs = AppConfigs.Remote.Main.LogoutOnOpenTabsAllowed;

                    // Features
                    isAgentNotes = AppConfigs.Remote.Features.AgentNotes;
                    enableGoogleTranslate = AppConfigs.Remote.Features.GoogleTranslate.Enabled;
                    isReminder = AppConfigs.Remote.Features.Reminders.Enabled;
                    isSupervisor = AppConfigs.Remote.Features.Supervisor.Enabled;
                    isAgentChat = AppConfigs.Remote.Features.AgentChat.Enabled;
                    isAgentAVChat = AppConfigs.Remote.Features.AgentChat.AVEnabled;
                    isSpeedDialTab = AppConfigs.Remote.Features.SpeedDial;
                    isWorkCodeWithTeam = AppConfigs.Remote.Features.WorkCodes.LoadBasedOnTeam;
                    isWorkCodeWithGroup = AppConfigs.Remote.Features.WorkCodes.GroupingEnabled;
                    maxWorkCodeSelectedItems = AppConfigs.Remote.Features.WorkCodes.SelectionLimit;
                    workCodeLabel = AppConfigs.Remote.Features.WorkCodes.Label;
                    isWorkCode.fax = AppConfigs.Remote.Features.WorkCodes.Channels.Fax;
                    isBlindTransfer = AppConfigs.Remote.Features.TransferAndConference.BlindTransferAllowed;
                    isFavouriteSkillTab = AppConfigs.Remote.Features.TransferAndConference.FavouriteSkillTabEnabled;
                    isCommentOnConfirmaion = AppConfigs.Remote.Features.TransferAndConference.CommentOnConfirmationAllowed;
                    consultTransferOnSkill = AppConfigs.Remote.Features.TransferAndConference.ConsultTransferOnSkill;
                    disableAgentBlindTransfer = AppConfigs.Remote.Features.TransferAndConference.AgentBlindTransferDisabled;
                    allowedStatus = AppConfigs.Remote.Features.TransferAndConference.StatusEligibility;
                    transferListSkillFilterPrefix = AppConfigs.Remote.Features.TransferAndConference.TransferListSkillFilterPrefix;
                    commentOnTransfer = AppConfigs.Remote.Features.TransferAndConference.CommentOnTransfer;
                    filterAccessRoleList = AppConfigs.Remote.Features.TransferAndConference.SkipAccessRole;
                    favouriteSkillTabName = AppConfigs.Remote.Features.TransferAndConference.FavouriteSkillTabName;
                    speedDialTabName = AppConfigs.Remote.Features.TransferAndConference.SpeedDialTabName;
                    favouriteSkillTransferTo = AppConfigs.Remote.Features.TransferAndConference.FavouriteTargetTransfer;
                    enableFaceTouchMonitor = AppConfigs.Remote.Features.FaceTouchMonitor.Enabled;
                    isWallboard = AppConfigs.Remote.Features.Wallboard.Enabled;
                    isServiceLevel = AppConfigs.Remote.Features.Wallboard.ShowServiceLevel;
                    ciqThresholdValue = AppConfigs.Remote.Features.Wallboard.CIQThresholdForBlink;
                    serviceLevelFields = AppConfigs.Remote.Features.Wallboard.ServiceLevels;
                    isWorkbench = AppConfigs.Remote.Features.Workbench.Enabled;
                    isInteractionHistory = AppConfigs.Remote.Features.InteractionHistory.Enabled;
                    noOfRecords = AppConfigs.Remote.Features.InteractionHistory.RecordsCount;
                    isMultiHistory = AppConfigs.Remote.Features.InteractionHistory.MultiHistory;
                    multiHistoryInstanceNames = AppConfigs.Remote.Features.InteractionHistory.MultiHistoryInstanceNames;
                    loadHistoryOnEvent = AppConfigs.Remote.Features.InteractionHistory.LoadOnEvent;
                    isDashboardEnabled = AppConfigs.Remote.Features.Dashboard.Enabled;
                    globalChannelList = AppConfigs.Remote.Features.Dashboard.GlobalChannelList;
                    defaultDashboardInterval = AppConfigs.Remote.Features.Dashboard.DefaultInterval;
                    dashboardInterval = AppConfigs.Remote.Features.Dashboard.Intervals;

                    // AppSettings
                    extraLogs = AppConfigs.Remote.AppSettings.ExtraLogs;
                    isSignalrConnector = AppConfigs.Remote.AppSettings.SignalrConnectorEnabled;

                    // Channel
                    isChatEnabled = AppConfigs.Remote.Channel.TextChat.Enabled;
                    isPWebChat = AppConfigs.Remote.Channel.TextChat.pWebChatEnabled;
                    isChatAuthenticationPanel = AppConfigs.Remote.Channel.TextChat.Authentication.PanelEnabled;
                    chatAuthenticationLabels = AppConfigs.Remote.Channel.TextChat.Authentication.Labels;
                    isGrammerCheck = AppConfigs.Remote.Channel.TextChat.GrammerCheckEnabled;
                    isImmediateCallbackBtn = AppConfigs.Remote.Channel.TextChat.ImmediateCallbackAllowed;
                    isScheduledCallbackBtn = AppConfigs.Remote.Channel.TextChat.ScheduledCallbackAllowed;
                    isSanitizeHtml = AppConfigs.Remote.Channel.TextChat.SanitizeHtmlEnabled;
                    isChatTransfer = AppConfigs.Remote.Channel.TextChat.TransferAllowed;
                    isConference = AppConfigs.Remote.Channel.TextChat.ConferenceAllowed;
                    isSignature = AppConfigs.Remote.Channel.TextChat.SignatureAllowed;
                    isSnapshot = AppConfigs.Remote.Channel.TextChat.Snapshot.Allowed;
                    isEmojiEnabled = AppConfigs.Remote.Channel.TextChat.EmojiAllowed;
                    isUserLabel = AppConfigs.Remote.Channel.TextChat.ShowUserLabel;
                    isCamera = AppConfigs.Remote.Channel.TextChat.CameraCaptureAllowed;
                    isVoiceNote = AppConfigs.Remote.Channel.TextChat.VoiceNoteAllowed;
                    isWhiteboard = AppConfigs.Remote.Channel.TextChat.WhiteBoard.Allowed;
                    isPDFAndImageEditingAllowed = AppConfigs.Remote.Channel.TextChat.PDFAndImageEditing.Allowed;
                    drawStrokeStyle = AppConfigs.Remote.Channel.TextChat.PDFAndImageEditing.DrawStrokeStyle;
                    drawStrokeSize = AppConfigs.Remote.Channel.TextChat.PDFAndImageEditing.DrawStrokeSize;
                    isAttachement = AppConfigs.Remote.Channel.TextChat.Attachment.Allowed;
                    maxAttachFileSize = AppConfigs.Remote.Channel.TextChat.Attachment.SizeLimit;
                    imageFormats = AppConfigs.Remote.Channel.TextChat.Attachment.Formats.Image;
                    videoFormats = AppConfigs.Remote.Channel.TextChat.Attachment.Formats.Video;
                    audioFormats = AppConfigs.Remote.Channel.TextChat.Attachment.Formats.Audio;
                    fileFormats = AppConfigs.Remote.Channel.TextChat.Attachment.Formats.File;
                    screenShareEnabled = AppConfigs.Remote.Channel.TextChat.ScreenShareAllowed;
                    coBrowse.Enabled = AppConfigs.Remote.Channel.TextChat.CoBrowse.Allowed;
                    coBrowse.MousePointerCapture = AppConfigs.Remote.Channel.TextChat.CoBrowse.MousePointerCapture;
                    isReplyOnChat = AppConfigs.Remote.Channel.TextChat.ReplyOnChatAllowed;
                    isExpandCollapseOnVideoChat = AppConfigs.Remote.Channel.TextChat.MaximizeWindowOnAVCall;
                    isVaChatHistoryAccordion = AppConfigs.Remote.Channel.TextChat.VAHistory.Enabled;
                    chatHistoryName = AppConfigs.Remote.Channel.TextChat.VAHistory.DisplayName;
                    vaChatHistoryCountry = AppConfigs.Remote.Channel.TextChat.VAHistory.CountryFilter;
                    isHyperlinkWithTag = AppConfigs.Remote.Channel.TextChat.HyperLinks.Allowed;
                    sendAllLinksToCustomer = AppConfigs.Remote.Channel.TextChat.HyperLinks.SendAllHyperLinksOnChatEnd;
                    isAppMessage = AppConfigs.Remote.Channel.TextChat.SendAsAppMessage;
                    isChatTemplatesBtn = AppConfigs.Remote.Channel.TextChat.Template.ButtonEnabled;
                    chatTemplateFilter = AppConfigs.Remote.Channel.TextChat.Template.Filter;
                    isTemplateTimeFilter = AppConfigs.Remote.Channel.TextChat.Template.FilterByTime;
                    chatTemplatesUpdateThreshold = AppConfigs.Remote.Channel.TextChat.Template.UpdateThreshold;
                    chatBoxType = AppConfigs.Remote.Channel.TextChat.ChatBoxType;
                    disconnectChatLabel = AppConfigs.Remote.Channel.TextChat.DisconnectChatLabel;
                    isCustomTextChat = AppConfigs.Remote.Channel.TextChat.CustomTextChat.Enabled;
                    customChatConfigs = AppConfigs.Remote.Channel.TextChat.CustomTextChat.Configs;
                    interactionConversion.Enabled = AppConfigs.Remote.Channel.TextChat.InteractionConversion.Allowed;
                    interactionConversion.Channels = AppConfigs.Remote.Channel.TextChat.InteractionConversion.Channels;
                    interactionConversion.On = AppConfigs.Remote.Channel.TextChat.InteractionConversion.On;
                    isAVEnabled = AppConfigs.Remote.Channel.TextChat.AV.Enabled;
                    videoCallType = AppConfigs.Remote.Channel.TextChat.AV.UIType;
                    isAudioEscalate = AppConfigs.Remote.Channel.TextChat.AV.Escalate.Audio;
                    isVideoEscalate = AppConfigs.Remote.Channel.TextChat.AV.Escalate.Video;
                    escalateToAVTimeout = AppConfigs.Remote.Channel.TextChat.AV.Escalate.Timeout;
                    avPopupConfig = AppConfigs.Remote.Channel.TextChat.AV.PopUp;
                    sendWebRTCInfo = AppConfigs.Remote.Channel.TextChat.AV.SendWebRTCInfo;
                    webRTCApiConfig.webRTCConfig = AppConfigs.Remote.Channel.TextChat.AV.WebRTCConfig;
                    webRTCApiConfig.getMediaConstraints = AppConfigs.Remote.Channel.TextChat.AV.MediaConstraints;
                    webRTCApiConfig.getOfferOptions = AppConfigs.Remote.Channel.TextChat.AV.OfferOptions;
                    webRTCApiConfig.getRecordingOptions = AppConfigs.Remote.Channel.TextChat.AV.RecordingOptions;
                    webRTCApiConfig.AudioLevelCheck = AppConfigs.Remote.Channel.TextChat.AV.AudioLevelCheck;
                    webRTCApiConfig.getConnectionBandwidthUpperLimit = AppConfigs.Remote.Channel.TextChat.AV.ConnectionBandwidthUpperLimit;
                    webRTCApiConfig.getAudioTrackBandwidthUpperLimit = AppConfigs.Remote.Channel.TextChat.AV.AudioTrackBandwidthUpperLimit;
                    webRTCApiConfig.getVideoTrackBandwidthUpperLimit = AppConfigs.Remote.Channel.TextChat.AV.VideoTrackBandwidthUpperLimit;
                    webRTCApiConfig.audioLevelCheck = AppConfigs.Remote.Channel.TextChat.AV.AudioLevelCheck;
                    webRTCApiConfig.isAudioMixerEnabled = AppConfigs.Remote.Channel.TextChat.AV.AudioMixerEnabled;

                    global_outboundName = AppConfigs.Remote.Channel.Voice.OutboundStatusName;
                    ivrTransferEnabled = AppConfigs.Remote.Channel.Voice.IVR.Transfer.Allowed;
                    ivrTransferMenus = AppConfigs.Remote.Channel.Voice.IVR.Transfer.Menu;
                    isIvrMenuEnabled = AppConfigs.Remote.Channel.Voice.IVR.MenuEnabled;
                    isEnableVoiceOnSingleChat = AppConfigs.Remote.Channel.Voice.IVR.VoiceOnSingleChatEnabled;
                    internalNumberStartsWith = AppConfigs.Remote.Channel.Voice.IVR.InternalNumberStartsWith;
                    customDialCallPrefix = AppConfigs.Remote.Channel.Voice.IVR.CustomDialCallPrefix;
                    closeOutboundTab = AppConfigs.Remote.Channel.Voice.IVR.CloseOutboundTabEnabled;
                    isVoiceDataWindow = AppConfigs.Remote.Channel.Voice.IVR.VoiceDataWindow.Enabled;
                    voiceDataWindowType = AppConfigs.Remote.Channel.Voice.IVR.VoiceDataWindow.Type;
                    vipMapping = AppConfigs.Remote.Channel.Voice.IVR.VIPMappingEnabled;
                    isVoiceAuthenticationPanel = AppConfigs.Remote.Channel.Voice.IVR.Authentication.PanelEnabled;
                    voiceAuthenticationLabels = AppConfigs.Remote.Channel.Voice.IVR.Authentication.Labels;

                    isCallback = AppConfigs.Remote.Channel.Voice.Callback.Enabled;
                    trimDigitsBeforeMakeCall = AppConfigs.Remote.Channel.Voice.Callback.TrimDigitsBeforeCall;
                    isCallerIDTextBoxReadonly = AppConfigs.Remote.Channel.Voice.Callback.IsCallerIDTextBoxReadonly;
                    isLanguageTruncateEnabled = AppConfigs.Remote.Channel.Voice.Callback.LanguageTruncateEnabled;
                    dCallbackType = AppConfigs.Remote.Channel.Voice.Callback.dCallbackType;
                    callbackExtensionRange = AppConfigs.Remote.Channel.Voice.Callback.ExtensionRange;
                    callbackVDNListStart = AppConfigs.Remote.Channel.Voice.Callback.VDNListStartsWith;
                    callbackVDNListEnd = AppConfigs.Remote.Channel.Voice.Callback.VDNListEndsWith;
                    isCustomDialPrefixPrefNumber = AppConfigs.Remote.Channel.Voice.Callback.AppendCustomDialPrefixPrefNumber;
                    callbackOptions = AppConfigs.Remote.Channel.Voice.Callback.Options;

                    retryInterval = AppConfigs.Remote.Channel.Voice.VoiceBio.RetryInterval;
                    isManualLanId = AppConfigs.Remote.Channel.Voice.VoiceBio.ManualLanIdEnabled;
                    voiceBioNoficationLimit = AppConfigs.Remote.Channel.Voice.VoiceBio.NotificationLimit;
                    defaultSnoozeTimeout = AppConfigs.Remote.Channel.Voice.VoiceBio.DefaultSnoozeTimeout;

                    isFaxEnabled = AppConfigs.Remote.Channel.Fax.Enabled;
                    isPrintFax = AppConfigs.Remote.Channel.Fax.PrintAllowed;
                    internationFaxPrefix = AppConfigs.Remote.Channel.Fax.InternationalPrefix;
                    isSendFaxToGroup = AppConfigs.Remote.Channel.Fax.SendFaxToGroupAllowed;
                    isSendMultipleFaxItems = AppConfigs.Remote.Channel.Fax.SendMultipleItemsAllowed;
                    isfaxCoverPage = AppConfigs.Remote.Channel.Fax.CoverPage.Enabled;
                    coverPageType = AppConfigs.Remote.Channel.Fax.CoverPage.Type;
                    maxFaxLineRecipents = AppConfigs.Remote.Channel.Fax.MaxFaxLineRecipents;
                    maxFaxLineNumberLength = AppConfigs.Remote.Channel.Fax.MaxFaxLineNumberLength;
                    maxFileUploads = AppConfigs.Remote.Channel.Fax.MaxFileUploads;
                    maxFileUploadSize = AppConfigs.Remote.Channel.Fax.MaxFileUploadSize;
                    maxMultipleFaxItems = AppConfigs.Remote.Channel.Fax.MaxMultipleFaxItems;
                    restrictFirstFaxItem = AppConfigs.Remote.Channel.Fax.RestrictFirstFaxItem;

                    isSMSEnabled = AppConfigs.Remote.Channel.SMS.Enabled;
                    smsDnisList = AppConfigs.Remote.Channel.SMS.DNISList;
                    maxSmsLineRecipents = AppConfigs.Remote.Channel.SMS.MaxSmsLineRecipents;
                    maxSmsLineNumberLength = AppConfigs.Remote.Channel.SMS.MaxSmsLineNumberLength;

                    isFbEnabled = AppConfigs.Remote.Channel.FB.Enabled;
                    isTwitterEnabled = AppConfigs.Remote.Channel.Twitter.Enabled;
                    isLineEnabled = AppConfigs.Remote.Channel.Line.Enabled;

                    // CRM
                    isIServe = AppConfigs.Remote.CRM.iServe.Enabled;
                    iServeUrl = AppConfigs.Remote.CRM.iServe.URL;
                    isNiceIntegration = AppConfigs.Remote.CRM.Nice.Enabled;
                    isDynamicCRMEnabled = AppConfigs.Remote.CRM.DynamicCRM.Enabled;
                    isDynamicXRMEnabled = AppConfigs.Remote.CRM.DynamicXRM.Enabled;
                    isSiebel = AppConfigs.Remote.CRM.Siebel.Enabled;

                    // POM
                    isPOMCallDashboard = AppConfigs.Remote.POM.CallDashboardEnabled;
                    isPOMCmpaignDashboard = AppConfigs.Remote.POM.CampaignDashboardEnabled;
                    isPOMCallbackDashboard = AppConfigs.Remote.POM.CallbackDashboardEnabled;
                    pomDNDType = AppConfigs.Remote.POM.DNDTypes;
                    pomLoginFlag = AppConfigs.Remote.POM.LoginFlag;
                    pomSaleScreenList = AppConfigs.Remote.POM.SaleScreenList;
                    pomInboundWrapupCodes = AppConfigs.Remote.POM.InboundWrapupCodes;
                    isPreviewAutoDial = AppConfigs.Remote.POM.PreviewAutoDialEnabled;
                    trimNumberLength = AppConfigs.Remote.POM.TrimNumberLength;
                    limitPOMCallbackDate = AppConfigs.Remote.POM.LimitPOMCallbackDate;

                    // URLs
                    tmac_face_compare_serviceurl = AppConfigs.Remote.URLs.FaceCompare;
                    FileServerUrl.Smm = AppConfigs.Remote.URLs.Channel.FileServer.SMM;
                    FileServerUrl.MediaProxy = AppConfigs.Remote.URLs.Channel.FileServer.MediaProxy;
                    webRTCApiConfig.webRTCConfig.iceServers = AppConfigs.Remote.URLs.IceServers;
                    campSelectorUrl = AppConfigs.Remote.URLs.Channel.Campaign.Selector;
                    campServiceUrl = AppConfigs.Remote.URLs.Channel.Campaign.Service;
                    lineUrl = AppConfigs.Remote.URLs.Channel.SocialMedia.Line;
                    twitterUrl = AppConfigs.Remote.URLs.Channel.SocialMedia.Twitter;
                    twitterDMUrl = AppConfigs.Remote.URLs.Channel.SocialMedia.TwitterDM;
                    whiteboardUrl = AppConfigs.Remote.URLs.Channel.TextChat.WhiteBoard;
                    ihEmailPreviewUrl = AppConfigs.Remote.URLs.InteractionHistory.PreviewEmail;
                    signalRConnectorUrls.dashboard = AppConfigs.Remote.URLs.SignalRConnector.Dashboard;
                    signalRConnectorUrls.webRTCMonitor = AppConfigs.Remote.URLs.SignalRConnector.WebRTCMonitor;
                    restCallUrl = AppConfigs.Remote.URLs.Custom.RestCall;

                    // Custom
                    isVaChatHistoryBtn = AppConfigs.Remote.Custom.ShowEntireVAChatHistory;
                    isBargeIn = AppConfigs.Remote.Custom.BargeInEnabled;
                    segmentMapping = AppConfigs.Remote.Custom.SegmentMapping;
                    isCRMCallbackEnd = AppConfigs.Remote.Custom.CRM.OnCallbackEndEnabled;
                    isACWQMSCRMEnabled = AppConfigs.Remote.Custom.CRM.ACWQMSCRMEnabled;
                    customCRMUrl = AppConfigs.Remote.Custom.CRM.CustomURL;
                    isCSATSurvey = AppConfigs.Remote.Custom.CSATSurveyEnabled;

                }

                console.info("%c [config_element.AssignOldConfigs]: Remote configs are assigned to existing globalvars successfully.", "background: green; color: white");
                return true;
            }
        } catch (e) {
            console.error("%c [config_element.AssignOldConfigs]: " + e, "background: red; color: white")
        }
        return false;
    }
};