
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
try {
    let filename = "EventDataHandler.js";
    var file_version = "4.0.11.12";
    var changedBy = "Vishal Pinto";
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------

/**
 * Handles Events actions
 * @param {*} event 
 */
function HandleEventActions(event) {
    try {
        //  TestMe
        if (AppConfigs.Remote.Features.EventActions.Enabled)
            ExecuteEventActions(event)

        //  If this is the interaction closing event, let's remove all events of this interaction from store
        if (event.EventName === "InteractionClosedEvent")
            delete global_AllEvents[event.InteractionID];
    } catch (e) {
        log.LogDetails("Error", "EventDataHandler.HandleEvent().AddToAllEvents", e, false);
    }
}

/**
 *  Execute actions on events
 * @param {*} eventData 
 */
function ExecuteEventActions(eventData) {
    try {
        //  Get action to execute for this event
        let eventAction = AppConfigs.Remote.Features.EventActions.On[eventData.EventName];
        if (eventAction == null || eventAction.URL == null || eventAction.URL.length === 0)
            return;

        //  Get event source. If event is non-interaction based, it will be 0, else interaction ID
        let intId = 0;
        if (eventAction.Type === "generic")
            intId = 0;
        else
            if (eventAction.Type === "interaction")
                intId = eventData.InteractionID;

        //  If no filters are there, its true. We can proceed with action execution. This is for overall, condition/filter result
        let result = eventAction.Filters.length === 0;
        //  Contains individual filter result
        let filterResults = [];
        $.each(eventAction.Filters, function (i, val) {
            //  Resolve the variable name and get value
            let exp1 = fetchValueFromEvents(intId, val.Variable);
            //  Get condition/filter result and store for individual 
            filterResults.push({
                value: executeCondition(exp1, val.Operator, val.Value),
                betweenOperator: val.BetweenOperator
            });
        });
        //  If there is only one filter, this is the overall result
        if (filterResults.length === 1) {
            result = filterResults[0].value;
        }
        else
            //  If there are more than one, Find the result of overall conditions
            if (filterResults.length > 1) {
                for (var j = 0; j < filterResults.length - 1; j++) {
                    //  If there is not between operator, cannot overall result. Assign current result as overall result
                    if (filterResults[j].betweenOperator == null || filterResults[j].betweenOperator.length === 0) {
                        result = filterResults[j].value;
                        break;
                    }
                    //  If current value is true, and next operator is "or", no use in continuing. Similarly, if it is false, and operator is "and" 
                    if ((filterResults[j].betweenOperator.toLowerCase() == "or" && filterResults[j].value) ||
                        (filterResults[j].betweenOperator.toLowerCase() == "and" && !filterResults[j].value)) {
                        result = filterResults[j].value;
                        break;
                    }

                    //  Execute condition between current value and next value and store it in next value
                    filterResults[j + 1].value =
                        executeCondition(filterResults[j].value, filterResults[j].betweenOperator, filterResults[j + 1].value);
                    //  Store this value as overall result
                    result = filterResults[j + 1].value;
                }
            }

        //  If result doesn't satisfy, return
        if (!result) return;
        log.LogDetails("Info", "EventDataHandler.ExecuteEventActions()", "Executing action for event [" + eventData.EventName + "].", false);

        let url = eventAction.URL + "?";
        // Get URL params
        $.each(eventAction.Data, function (key, location) {
            try {
                let val = fetchValueFromEvents(intId, location);
                url += key + "=" + val + "&";
            } catch (e) {
                log.LogDetails("Error", "EventDataHandler.ExecuteEventActions().eventAction.Data.each()", e, false);
            }
        });

        // Open the target app. Default is window
        let openedIn = "";
        switch (eventAction.DisplayType) {
            case "iframe":
                openedIn = "iFrame";
                break;
            case "window":
            default:
                openedIn = "window";
                window.open(url, "_blank", "menubar=no,resizable=0,location=no,scrollbars=no,width=" + screen.width / 2 + ",height=" + screen.height).moveTo(0, 0);
        }

        log.LogDetails("Info", "EventDataHandler.ExecuteEventActions()", "Executed action for event [" + eventData.EventName + "], URL [" + url + "], display type [" + openedIn + "].", false);
    } catch (e) {
        log.LogDetails("Error", "EventDataHandler.ExecuteEventActions()", e, false);
    }
}

/**
 *  Executes the condition
 * @param {*} exp1 : Expression 1
 * @param {*} op : Operator
 * @param {*} exp2 : Expression 2
 */
function executeCondition(exp1, op, exp2) {
    try {
        switch (op.toLowerCase()) {
            case "eq":
                return exp1 == exp2;
            case "ne":
                return exp1 != exp2;
            case "lt":
                return exp1 < exp2;
            case "lte":
                return exp1 <= exp2;
            case "gt":
                return exp1 > exp2;
            case "gte":
                return exp1 >= exp2;
            case "and":
                return exp1 && exp2;
            case "or":
                return exp1 || exp2;
        }
    } catch (e) {
        log.LogDetails("Error", "EventDataHandler.executeCondition()", e, false);
    }
}

/**
 * Resolves and fetches value from Local Events store
 * @param {*} interactionId : Interaction ID of the event. 0 if it is non-interaction event
 * @param {*} fullPropertyName : Full property name
 */
function fetchValueFromEvents(interactionId, fullPropertyName) {
    let val = null;
    try {
        // Select event store
        let source = global_AllEvents[interactionId];
        let splits = fullPropertyName.split('.');

        // Find specific event data
        for (i = source.length - 1; i >= 0; i--) {
            if (source[i].EventName === splits[0]) {
                val = JSON.parse(JSON.stringify(source[i]));
                break;
            }
        }
        //  Remove event name from property
        splits.splice(0, 1);
        // Resolve object value
        val = fetchValueFromObject(val, splits.join("."));

        if (val == null) val = "";
    }
    catch (e) {
        log.LogDetails("Error", "EventDataHandler.fetchValueFromEvents()", e, false);
        val = "";
    }
    return val;
}

/**
 *  Resolves property name and fetches value 
 * @param {*} obj : source
 * @param {*} fullPropertyName : Full property name (For e.g., "AgentStatusChangeEvent.Source") 
 */
function fetchValueFromObject(obj, fullPropertyName) {
    try {
        var splits = fullPropertyName.split('.');

        $.each(splits, function (i, val) {
            obj = obj[val];
        });
    } catch (e) {
        log.LogDetails("Error", "EventHandler.fetchValueFromObject()", e, false);
    }
    return obj;
}