var global_AssemblyVersion = "TMAC :3.2.01.10";
//  --------------------------------------------------------------------------
// All Application UI level Settings goes here
//  --------------------------------------------------------------------------
//login and mainscreen in same page
var isSinglePageLogin = false;
var isLoginMode = false;
var loginMode = "pbx";//pbx,nonpbx
var disableLanId = false;
var isCloseLoginPage = false;
var isTmacWindowFocus = false;
var showNotificationDeniedAlert = false;
var notificationType = "";
var notificationList = [];
var checkForTmacFocus = true; // true - if tmac focus is to be checked to display notification
var notificationDuration = 5; // in seconds
var isApplication_window_size_type_pixel = false;  //true if the application window size is to be set in pixel
var Application_window_width = 100; //percentage - [42 - voice bio | 28 - dbs sg live chat | 40 - uob]
var Application_window_height = 100; //percentage - [28 - voice bio | 100 - dbs sg live chat | 100 - uob]
//is tmac full screen
var isFullTMAC = false;
//is tmac tour
var isTour = false;
//show/hide the left panel after login
var openLeftSidePanel = false;
//is the main tab is custom
var isCustomMainTab = false;
//display station id
var agentStationOnMain = true;
//agent status on main
var agentStatusOnMain = false;
//agent profile on main
var agentProfileOnMain = true;
//is agent chat
var isAgentChat = false;
//is customer chat
var isCustomerChat = false;
//dummy chat list
var dummyCustomerList = [];
//s wallbaord
var isWallboard = true;
//is remiders
var isReminder = false;
//initially isReminderThreadStarted is false
var isReminderThreadStarted = false;
//store the reminder list in this variable for the thread loop
var globalReminderList;
//interaction history
var isInteractionHistory = false;
//is custom customer journey
var isCustomerJourney = true;
//get interaction history source
var interactionHistorySource = "local"; //local, signalr
//customer journey iframe
var ih_iframe_url = "../../TMAC_Agent_Utils/UI/InteractionHistory.html";
//load history on event
var loadHistoryOnEvent = true;
var quotesList = [];
// Below two variables are used for to store current window width and Height
//  based on these variables, we can set the CRM window width and position.
var Application_Window_Current_Width = 0;
var Application_Window_Current_Height = 0;
// Set the active tab id to this variable
var global_activeTabId;
// Connect array for ucid
var global_connectUCID = [];
//added by sirajuddin for CBG integration
var global_connectedProxy = "";
//open tabs array
var global_openTabs = [];
//open tabs ucid array
var global_openTabsUCID = [];
var global_tabCount = 0;
var global_QueueTimeColor = [];
var global_UCID = [];
var global_OutboundUCID;
var global_ConnectionHandle;
//Global Variable to check if the voice call received has a callback already registered
var global_voiceCallHasCallback = false;
var global_TextChatScheduleCallbackID;
var global_ExistingCallbackForCustomerTabId = 2000; // global variable for interaction id when a customer has a callback tab when he initiates a chat
var global_AgentForcedLogoffEventFlag = false;
var global_InteractionTabs = [];
//dialog width pixel/percentage
var kendo_window_width = {};
kendo_window_width.add_reminder = "600px";
kendo_window_width.barge_in_dialog = "600px";
kendo_window_width.make_call_dialog = "600px";
kendo_window_width.transfer_dialog = "600px";
kendo_window_width.conference_dialog = "600px";
kendo_window_width.confirm_dialog = "600px";
kendo_window_width.callback_dialog = "225px";
kendo_window_width.pom_callback_dialog = "600px";
kendo_window_width.va_history = "400px";
kendo_window_width.chat_template_dialog = "600px";
kendo_window_width.start_chat = "600px";
//extra configs
//tmac header and footer height - note: no px only digit
var tmac_header_footer_height = "30px";
//aux status to enable logout
var logoutAux = "Logout";
//disable status on call
var isDisableStatusOnCall = true;
//to show push notification
var isPushNotification = false;
//disabled window resize
var isDisableResize = false;
//recent alerts
var recentAlerts = [];
//notify timeout
var notifyTimeout = 3000;
//agent forced logoff
var isLoggingOff = false;
//if the agent logged out
var isLogoutDone = false;
//flag to close all tabs on tmac ui status change, TSC - Tmac Status Change
var isCloseTabsOnTSC = false;
//to skip close tab on these tab types for status change
var skipCloseTabType = [];
//to skip close tab on these staus for status change
var skipCloseTabStatus = [];
//to check last status of agent before auto close tab
var closeTabLastStatus = "";
//text chat transfer tmac server
var destTmacServerName = "";
//favorite list on transfer
var favListGridItemSelect = "";
//text chat transfer favorite list
var favListGridItemSelectForChat = "";
//tmac disconnect by handle type
var disconnectByHandleType = "";
//tmac agent to agent chat obj
var tmacAgentChatObj = [];
var ApplicationConfigurationSettings = {
    EnableRemoteLogging: {
        Success: true,
        Info: true,
        Warning: true,
        Error: true
    }
}
var favionIcon = "favicon";
//enable/disable agent id for invalid lan id
var isAgentIdOnInvalidLanId = true;
//dummy station use lanid
var isStationAvailable = true;
//show domain list
var isDomainList = true;
//show login with password
var isLoginWithPassword = true;
//aux based on team
var isLoadAgentAux = false;
//label on title
var labelOnTitle = true;
var titleName = "TMAC";
var signalRVersion;
var global_AUXCodes;
var global_Intents;
var global_AgentList = [];
var global_FavouriteSkills;
var global_SpeedDial;
var global_WorkCodeList;
var global_TeamID;
var global_TeamName;
var global_AgentName;
var global_UserProfileForAgent;
var global_ChannelCount = [];
var global_Password;
var global_CallType = "";
var global_transferIntID;
var global_conferenceIntID;
//active tab interaction id
var global_activeTabInteractionID;
//agent status timer counter
var statusTimeCounter = 0;
//agent status obj
var global_LastAgentStat;
var global_agentCamera;
//tmac reload flag
var global_ReloadDone;
//timeout function
var global_timeoutFunctions = [];
var global_LoginRedisplay;
//marquee text reference
var marqueeText = "";
//active tab id for tabstrip select/active event
var active_tab_id = "";
//main tabtrip element
var tabstrip;
//make call tabstrip element
var tabstrip_call;
//trasnfer call tabstrip element
var tabstrip_transfer;
var logout_button_clicked = false;
var call_log_out = false;
//support doc url
var supportDocUrl = "docs/pdf.pdf";
//barge-in enabled
var isBargeIn = false;
//supervisor enabled
var isSupervisor = true;
//supervisor link
var supervisorLink = "../../SupervisorModule";
//toggle tmac screen
var isTmacScreenToggle = true;
//auto timer for time taken
var autoTimerForTimeTaken = true;
//enable/disable blind transfer button
var isBlindTransfer = true;
//favourite skill list in call transfer window
var isFavouriteSkillTab = true;
//favouriteskill list grid tab name
var favouriteSkillTabName = "Skill List"; //Blind Transfer, Skill List
//favouriteSkill transfer to - skill/vdn
var favouriteSkillTransferTo = "skill";
//speed dial list tab in call transfer window
var isSpeedDialTab = true;   //true
//speeddial list grid tab name
var speedDialTabName = "Speed Dial List"; //Consult Transfer, Speed Dial List
//to show/hide speed dial for textchat
var isSpeedDialOnTextChat = false;
//consult transfer on skill
var consultTransferOnSkill = {
    "Voice": false,
    "TextChat": false
};
//to allow transfer/conference in specified status
var allowedStatus = {
    "Voice": ["Available"],
    "TextChat": []
};
//calls in queue threshold value for blinking for wallboard
var ciqThresholdValue = 5;
//modal on dialog
var modalOnDialog = true;
//initial status on load
var initialStatus = "NotReady";
//workbench configuration
var isWorkbench = false;
//workbench link
var workbenchLink = "";
//to print etra logs in console and UI log
var extraLogs = {
    "TMACEventNames": true,
    "TMACEventObjects": true,
    "VoiceBioEvents": false
};
//type of agent logged in
var agentType = "";
//expand/collapse on iframes
var isExpandCollapseOnIframes = {
    "Supervisor": false,
    "Workbench": false
};
//Enable close tab on disconnect for realtime channel
var isEnableCloseTabOnDisconnect = {
    "Voice": false,
    "TextChat": true
};
//popup broadcast message on login and change
var popBroadcast = false;
//load workcodes with team
var isWorkCodeWithTeam = false;
//load workcodes with groups
var isWorkCodeWithGroup = false;
//workcode config key
//key value should be always lowercase | value :: "voice": { enable: false, mandatoryComplete: false }
var isWorkCode = {};
//total number of work code can be selected
var maxWorkCodeSelectedItems = 0;
//workcode label name
var workCodeLabel = "";
//logout agent on close window
var isLogoutOnClose = false;
//to allow agent to logout on open tabs
var allowLogoutOnOpenTabs = false;
//register post messages
var registerPostMessages = false;
//signalr connector enable
var isSignalrConnector = false;
//signalr connector url
var signalRConnectorUrls = [];
//rest call urls
var restCallUrl = {};
//  --------------------------------------------------------------------------

//-------------------------------CHANNEL CONFIGURATIONS-----------------------
var isFbEnabled = false;
var isChatEnabled = false;
var isFaxEnabled = false;
var isSMSEnabled = false;
//  --------------------------------------------------------------------------

//---------------------------------------FAX----------------------------------
var global_FaxReference = [];
var faxLineNumbers = [];
var faxInteractionId;
//allow print fax
var isPrintFax = true;
//max number of faxline recipents
var maxFaxLineRecipents = 3;
//max length of faxline number
var maxFaxLineNumberLength = 20;
//max files can be uploaded
var maxFileUploads = 1;
//max file upload size
var maxFileUploadSize = 10; //in MB
//international fax prefix
var internationFaxPrefix = "00";
//  --------------------------------------------------------------------------

//---------------------------------------SMS----------------------------------
//sms dnis list
var smsDnisList = [];
//max number of sms recipents
var maxSmsLineRecipents = 1;
//max length of sms number
var maxSmsLineNumberLength = 8;

//  --------------------------------------------------------------------------

//----------------------------------------CRM---------------------------------
var isIServe = false;
var iServeUrl = "";
var QMSPopUpURL = "";
var callbackPopUpURL = "";
var ACWPopUpURL = "";
var isNiceIntegration = false;
var isDynamicCRMEnabled = false;
//system generated callback CRM end pop up flag
var isCRMCallbackEnd = false;
//default is false, value is set from db config after login success
var isCRMEnabled = false;
//ACW QMS CRM Enabled
var isACWQMSCRMEnabled = false;
var agentCRMName;
var MSDChatAcceptPopUpURL = "";
var MSDChatClosePopUpURL = "";
var MSDCallbackAcceptPopUpURL = "";
var MSDCallbackClosePopUpURL = "";
var MSDInboundVoicePopUpURL = "";
var MSDOutboundVoicePopUpURL = "";
//text chat vdn list
var textChatVDNList;
//dbs ibg dnis list
var IBGDNISList;
//siebel integration
var isSiebel = false;
//  --------------------------------------------------------------------------


//----------------------------------------VOICE-------------------------------
//voice reference
var global_VoiceReference = [];
//name of outbound in db
var global_outboundName = "Call Outbound";
//is voice authentication panel enabled
var isVoiceAuthenticationPanel = false;
//authentication label names
var voiceAuthenticationLabels = {
    label1: "Verified Status",
    label2: "TPIN lock status"
};
//show/hide IVR transfer button
var ivrTransferEnabled = false;
var ivrTransferRef = {};
//ivr transfer menus
//prototype - { text: "NRIC/CC+OTP", type: "nv", value: "otp", icon: "lock" } :: type: nv - not verified, v_nv - verified + not verified
var ivrTransferMenus = [];
//show/hide IVR menus
var isIvrMenuEnabled = false;
//dynamic voice data obj
var voiceObj = {
    "Caller ID": "txtCallerID, custom-width-50",
    "DNIS": "txtDNIS, custom-width-50"
};
//customer segment mapping
var segmentMapping = [];
//VIP customer mapping
var vipMapping = false;
//is voice service data window
var isVoiceDataWindow = false;
//type of voice data window
var voiceDataWindowType = "campaign";
//campaign manager selector url
var campSelectorUrl = "";
//campaign manger servic url for campui.js
var campServiceUrl = "";
//enable voice if a single chat going on
var isEnableVoiceOnSingleChat = false;
//internal Number Startswith
var internalNumberStartsWith = "";
//prefix to be added before dialing out
var customDialCallPrefix = "";
//close outbound tab
var closeOutboundTab = false;
//  -------------------------------------------------------------------------------------------


//----------------------------------------TEXT CHAT/AUDIO-VIDEO CHAT---------------------------
//CSAT survey
var isCSATSurvey = false;
//Sanitize Html
var isSanitizeHtml = false;
//is grammer check
var isGrammerCheck = false;
//chat session reference
var global_ChatReference = []; //intid, isAgent, isCustomer, isTyping, isBlink, isActive isDisconnected, hyperLinks[]
//is PWeb Chat
var isPWebChat = true;
//dynamic chat data obj
var chatObj = {};
//is chat authentication panel enabled
var isChatAuthenticationPanel = true;
//authentication label names
var chatAuthenticationLabels = {
    label1: "Authentication Status",
    label2: "Authentication Level"
};
//temp intid for chat template
var tempIntIdForChatTemplate;
//chat templates array
var allChatTemplates = [];
//text chat greeting text
var global_TextChatGreetingText;
//text chat callback id
var global_TextChatCallbackID;
//immedialte callback button
var isImmediateCallbackBtn = false;
//scheduled callback button
var isScheduledCallbackBtn = false;
//video call enabled
var isAVEnabled = false;
//video call on tab/window
var videoCallType = "tab";
//audio escalate button
var isAudioEscalate = false;
//video escalate button
var isVideoEscalate = false;
//text chat transfer
var isChatTransfer = false;
//conference button
var isConference = false;
//chat history name
var chatHistoryName = "Chatbot History";
//va chat history
var isVaChatHistoryBtn = false;
//va chat history accordion
var isVaChatHistoryAccordion = false;
//custom load va chat history based on country
var vaChatHistoryCountry = "";
//chat attachment
var isAttachement = false;
//is user/customer name label on chatbox
var isUserLabel = true;
//chat whiteboard
var isWhiteboard = false;
//whiteboard url
var whiteboardUrl = "";
//open camera button
var isCamera = false;
//voice note
var isVoiceNote = false;
//pdf editor required
var isPdfEditor = false;
//is hyperlink in tag to customer
var isHyperlinkWithTag = true;
//to send all links to customer at the end of chat
var sendAllLinksToCustomer = false;
global_endTextChatNotification = [];
//send messages as app message
var isAppMessage = false;
//is reply button on chat box
var isReplyOnChat = false;
//for uploaded files
var files = {};
//facebook reference
var global_FbReference = [];
//image formats for text chat
var imageFormats = [];
//audio formats for text chat
var audioFormats = [];
//video formats for text chat
var videoFormats = [];
//file formats for text chat
var fileFormats = [];
//attachement max size
var maxAttachFileSize = "10";
//Used to check if the image has been edited and saved by the user
var isEditedImage = false;
//Used to check if the image is currently being edited for canvas resizing
var editingImage = false;
//image or pdf edit
var editFileType = "";
//draw stroke style
var drawStrokeStyle = "#000";
//draw stroke size
var drawStrokeSize = "12";
//is form filling
var isFormFilling = false;
//co browsing pages
var forms = [];
var avConn = null;
//expand/collapse on video chat
var isExpandCollapseOnVideoChat = true;
//filter type for auto complete chat template
var chatTemplateFilter = "startswith"; //startswith, endswith and contains
//To provide comment on textchat transfer/conference accept/reject
var isCommentOnConfirmaion = false;
//chatbox type
var chatBoxType = "inline"; //inline, outline
//filter template based on time stamp
var isTemplateTimeFilter = false;
//disconnect chat label
var disconnectChatLabel = "Chat";
//chat template button
var isChatTemplatesBtn = true;
//custom textchat
var isCustomTextChat = false;
//custom chat config
var customChatConfigs = [];
//  --------------------------------------------------------------------------


//----------------------------------------CALLBACK----------------------------
var isCallback = false;
var hasGetDataEventDetails = false;
var isTextChatCallback = false;
//trim before makecall
var trimDigitsBeforeMakeCall = "";
//readonly Caller ID textbox in callback tab
var isCallerIDTextBoxReadonly = false;
//callback set data for VDN as per language
var isLanguageTruncateEnabled = false;
var dCallbackType = "";
var callbackExtensionRange = "";
var callbackVDNListStart = "";
var callbackVDNListEnd = "";
//prefix to be added before dialing out for preferred contact number
var isCustomDialPrefixPrefNumber = false;
//callback tab status options
var callbackOptions = [];
//  --------------------------------------------------------------------------


//----------------------------------------DASHBOARD---------------------------
//is dashboard enabled
var isDashboardEnabled = false;
//channel list for dashboard
var globalChannelList = [];
//dashboard interval 
var dashboardInterval = [{
    text: "12Hrs",
    value: "12"
},
{
    text: "24Hrs",
    value: "24"
},
{
    text: "36Hrs",
    value: "36"
},
{
    text: "48Hrs",
    value: "48"
},
{
    text: "60Hrs",
    value: "60"
},
{
    text: "72Hrs",
    value: "72"
}
];
//default dashboard interval
var defaultDashboardInterval = "72";
//dashboard reconnect interval
var dashboardUrl = "";
//global agent list dashboard
var globalAgentList = [];
//  --------------------------------------------------------------------------

//----------------------------------------Voice Bio---------------------------
var isVoiceBio = false;
//retry login flag
var retryLogin = true;
//retry interval
var retryInterval = 5000;
//enter manual lan id
var isManualLanId = true;
//voice bio reference
var global_VBReference = [];
//voice bio notification limit
var voiceBioNoficationLimit = {
    notEnrolled: 0,
    enrolled: 0,
    enoughAudio: 0,
    authenticated: 0,
    notAuthenticated: 0,
    rejectedTwice: 0
};
//  --------------------------------------------------------------------------


//---------------------------------------POM----------------------------------
var isPOM = true;
var isCACS = false;
var isPOMCallDashboard = true;
var isPOMCmpaignDashboard = true;
var isPOMCallbackDashboard = true;
var pomCustomerInfoConfig = {};
var global_POMReference = [];
var pomActiveCallInteractionID = "";
var pomRedialNumber = "";
var pomDNDType = ["TS_NSP", "TS_DONOTCALL", "TS_INBOUND_DNC", "TS_INBOUND_SALE", "TS_NOT_INTERESTED", "TS_SALEOTH"];
var pomLoginFlag = false;
var pomSaleScreenList = [
    { text: "ACQ VA Sales", value: "../../Telesales_UI/ACQVASales.html?SessionID=" },
    { text: "Card Activation Submission", value: "../../Telesales_UI/CardActivationSubmission.html?SessionID=" },
    { text: "CCPL CPPL CCFT", value: "../../Telesales_UI/CCPL_CPPL_CCFT_Sales.html?SessionID=" },
    { text: "CE AF RET Sales Submission", value: "../../Telesales_UI/CEAFRETSalesSubmission.html?SessionID=" },
    { text: "CPFT Team Submission", value: "../../Telesales_UI/CPFTTeamSubmission.html?SessionID=" },
    { text: "CS Sales", value: "../../Telesales_UI/CSSales.html?SessionID=" },
    { text: "DCP Sales", value: "../../Telesales_UI/DCPSales.html?SessionID=" },
    { text: "GI Sales", value: "../../Telesales_UI/GISales.html?SessionID=" },
    { text: "Online ACQ VA Sales", value: "../../Telesales_UI/OnlineACQVASales.html?SessionID=" },
    { text: "Smart Pay Sales", value: "../../Telesales_UI/SmartPaySales.html?SessionID=" }
];
var pomInboundWrapupCodes = [
    { "codeID": "0", "codeValue": "TS_NOCUSTOMER" } //this item is for no NRIC found/no NRIC search, so always codeID should be '0'
    { "codeID": "1", "codeValue": "TS_DONOTCALL" },
    { "codeID": "2", "codeValue": "TS_INBOUND_DNC" },
    { "codeID": "3", "codeValue": "TS_INBOUND_SALE" },
    { "codeID": "4", "codeValue": "TS_NOT_INTERESTED" },
    { "codeID": "5", "codeValue": "TS_NSP" },
    { "codeID": "6", "codeValue": "TS_SALEOTH" },
];
var isPreviewAutoDial = false;
var trimNumberLength = "8";
var limitPOMCallbackDate = false;