﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.2.01.31";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        var objType;
        var appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            var splitVal = val.split(',');
            var value = splitVal[0];
            var className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        var objType;
        var appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            var splitVal = val.split(',');
            var value = splitVal[0] + intid;
            var className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value, className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        var t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        var intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //incoming call event data
                    if (eventName === "IncomingCallEvent") {
                        try {
                            $('#txtCallerID' + intid).val(data.PhoneNumber);
                            $("#txtCallerID" + intid).attr("title", data.PhoneNumber);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IncomingCallEvent", ex, false);
                        }
                    }
                    //uui event data 
                    else if (eventName === "UUIDataEvent") {
                        try {
                            var name = $.trim(data.CallerName);
                            var CIF = $.trim(data.CIF);
                            var language = $.trim(data.Language);
                            var id = $.trim(data.NRIC);
                            var segmentCode = $.trim(data.Segment);
                            var segment = "";
                            var otherData = data.OtherData;
                            //var vipFlag = "";
                            var errorCode = "";
                            var authType = data.AuthType;
                            var verificationIcon = "error";
                            var verificationIconType = "danger";
                            var verificationText = "N/A";
                            var verificationType = "N/A";

                            if (language === "E") {
                                language = "English";
                            }
                            else if (language === "M") {
                                language = "Mandarin";
                            }

                            segment = segmentCode ? segmentMapping.filter(function (n) { return n.key === segmentCode; })[0].value : "";

                            if (otherData) {
                                //vipFlag = $.trim(otherData.substring(0, 1));
                                //vipMapper = vipMapping.filter(function (n) { return n.key === vipFlag; })[0];
                                //vipMapper ? HandleIMs(intid, vipMapper.message, vipMapper.type, "", false) : "";
                                errorCode = otherData.substring(2, otherData.length - 2).trim();
                            }
                            $("#txtName" + intid).val(name);
                            $("#txtName" + intid).attr("title", name);

                            $("#txtCIF" + intid).val(CIF);
                            $("#txtCIF" + intid).attr("title", CIF);

                            $("#txtID" + intid).val(id);
                            $("#txtID" + intid).attr("title", id);

                            if (id) {
                                var idLength = id.trim().length;
                                var label = "";
                                switch (idLength) {
                                    case 9:
                                        label = "NRIC";
                                        break;
                                    case 10:
                                        label = "Account Number";
                                        break;
                                    case 15:
                                    case 16:
                                        label = "Card Number";
                                        break;
                                    default:
                                }
                                $("#txtID" + intid).siblings("label")[0].innerText = label;
                            }
                            $("#txtLanguage" + intid).val(language);
                            $("#txtLanguage" + intid).attr("title", language);

                            $("#txtSegment" + intid).val(segment);
                            $("#txtSegment" + intid).attr("title", segment);

                            $("#txtErrorCode" + intid).val(errorCode ? errorCode.split("-")[0] : "");
                            $("#txtErrorCode" + intid).attr("title", errorCode ? errorCode.split("-")[0] : "");

                            errorCode ? errorCode.split("-")[1].toLowerCase() === "s" ?
                                $("#txtErrorCode" + intid).addClass("uk-text-success") :
                                $("#txtErrorCode" + intid).addClass("uk-text-danger") : null;


                            if (authType) {
                                var isIdentified = authType.IsIdentified;
                                var isVerified = authType.IsVerified;
                                verificationType = authType.VerificationType;
                                verificationIcon = isVerified ? "verified_user" : "error";
                                verificationIconType = isVerified ? "success" : "danger";
                                if (isVerified && isIdentified) {
                                    verificationText = "Verified | Identified";
                                }
                                else if (!isVerified && isIdentified) {
                                    verificationText = "Not Verified | Identified";
                                }
                                else if (!isVerified && !isIdentified) {
                                    verificationText = "Not Verified | Not identified";
                                }
                            }

                            $('#verifiedStatus' + data.InteractionID).html(
                                "<span class='uk-text-" + verificationIconType + " uk-text-bold uk-text-small'>" +
                                "<i class='material-icons uk-text-" + verificationIconType + "'>" + verificationIcon + "</i> " +
                                verificationText +
                                "</span>");

                            $('#tpinlockStatus' + data.InteractionID).html(
                                "<span class='uk-text-" + verificationIconType + " uk-text-bold uk-text-small'>" +
                                "<i class='material-icons uk-text-" + verificationIconType + "'>info</i> " +
                                verificationType +
                                "</span>");

                            //hide all not verifed menus from Ivr transfer
                            if (isVerified) $("#ivrTransferMenus" + intid).find("li[type=nv]").addClass("uk-display-none");
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - UUIDataEvent", ex, false);
                        }
                    }
                    //ivr data event
                    else if (eventName === "IVRDataEvent") {
                        try {
                            var ivrLastMenus = "";
                            var queueTime = data.QueueTime;
                            var DNIS = data.DNIS;
                            var colorCode = GetColorCode(GetTimeInSeconds(queueTime));
                            if (isIvrMenuEnabled && (data.LastMenu !== "null" || data.LastMenu !== null)) {
                                ivrLastMenus =
                                    "<li><span>" + (data.LastMenu ? data.LastMenu : "NA") + "</span></li>" +
                                    "<li><span>" + (data.LastMenu_2 ? data.LastMenu_2 : "NA") + "</span></li>" +
                                    "<li><span>" + (data.LastMenu_3 ? data.LastMenu_3 : "NA") + "</span></li>" +
                                    "<li><span>" + (data.LastMenu_4 ? data.LastMenu_4 : "NA") + "</span></li>";
                                $("#divLast4IVR" + intid).html(ivrLastMenus);
                            }
                            $("#txtQueueTime" + intid).val(queueTime + " seconds");
                            $("#txtQueueTime" + intid).attr("title", queueTime + " seconds");
                            $("#txtQueueTime" + intid).css("color", colorCode);

                            $("#txtDNIS" + intid).val(DNIS);
                            $("#txtDNIS" + intid).attr("title", DNIS);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IVRDataEvent", ex, false);
                        }
                    }
                    //caller intent event
                    else if (eventName === "CallerIntentEvent") {
                        try {
                            $("#txtIntent" + intid).val(data.IntentName);
                            $("#txtIntent" + intid).attr("title", data.IntentName);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - CallerIntentEvent", ex, false);
                        }
                    }
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {
                    var parse = JSON.parse(data.JsonData);
                    var tcVerificationStatus = "NA";
                    var tcVerificationType = "NA";
                    var tcName = parse.customerName ? parse.customerName : "";
                    var cif = parse.cif ? parse.cif : "";
                    var cc = parse.cc ? parse.cc : "";
                    var nric = parse.nric ? parse.nric : "";
                    var tcLanguage = "English";
                    var customerSegment = parse.custSegment ? segmentMapping.filter(function (n) { return n.key === parse.custSegment; })[0].value : "";
                    var regNo = parse.mobile ? parse.mobile : "";
                    var intent = parse.Intent ? parse.Intent : "";
                    var tcQueueTime = data.QueueTime;
                    var tcErrorCode = parse.errorCode ? parse.errorCode : "";
                    var idLabel = "CC/NRIC";

                    // Bind user data controls
                    GetChatReferenceObj(intid).customerName = tcName;
                    if (tcName) $("#divTabHeader" + intid).text(tcName);

                    $("#tc_name" + intid).val(tcName);
                    $("#tc_name" + intid).attr("title", tcName);

                    $("#tc_cif" + intid).val(cif);
                    $("#tc_cif" + intid).attr("title", cif);

                    if (cc) {
                        idLabel = "CC";
                        $("#tc_id" + intid).val(cc);
                        $("#tc_id" + intid).attr("title", cc);
                        tcVerificationType = "CC+OTP";
                    }
                    else if (nric) {
                        idLabel = "NRIC";
                        $("#tc_id" + intid).val(nric);
                        $("#tc_id" + intid).attr("title", nric);
                        tcVerificationType = "NRIC+OTP";
                    }
                    $("#tc_id" + intid).siblings("label")[0].innerText = idLabel;

                    $("#tc_language" + intid).val(tcLanguage);
                    $("#tc_language" + intid).attr("title", tcLanguage);

                    $("#tc_customerSegment" + intid).val(customerSegment);
                    $("#tc_customerSegment" + intid).attr("title", customerSegment);

                    $("#tc_regNo" + intid).val(regNo);
                    $("#tc_regNo" + intid).attr("title", regNo);

                    $("#tc_intent" + intid).val(intent);
                    $("#tc_intent" + intid).attr("title", intent);

                    $("#tc_chatQueueTime" + intid).val(tcQueueTime + " seconds");
                    $("#tc_chatQueueTime" + intid).attr("title", tcQueueTime + " seconds");
                    $("#tc_chatQueueTime" + intid).css("color", GetColorCode(tcQueueTime));

                    $("#tc_errorCode" + intid).val(tcErrorCode);
                    $("#tc_errorCode" + intid).attr("title", tcErrorCode);

                    var authTypeIcon = "error";
                    var authTypeIconType = "danger";

                    if (tcVerificationType !== "NA") {
                        tcVerificationStatus = "Verified";
                        authTypeIcon = "done";
                        authTypeIconType = "success";
                    }

                    //should be changed because now for all status we are appening "error" icon and "success" color
                    //should be dynamic based on the server response/ since its a new change server is responding with 
                    //only status text not the type [refer 'setUUIData' function in tmac_ui.js]
                    $('#textCallStatus' + intid)
                        .html(
                            "<span class='uk-text-" + authTypeIconType + " uk-text-bold uk-text-small'>" +
                            "<i class='material-icons uk-text-" + authTypeIconType + "'>" + authTypeIcon + "</i> " +
                            tcVerificationStatus +
                            "</span>");

                    $('#textChatAuthType' + intid)
                        .html(
                            "<span class='uk-text-" + authTypeIconType + " uk-text-bold uk-text-small'>" +
                            "<i class='material-icons uk-text-" + authTypeIconType + "'>" + authTypeIcon + "</i> " +
                            tcVerificationType +
                            "</span>");

                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function HandleCallback(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        custom_getTextChatData(event.InteractionID, parse.cif, event.TextChatSessionID);
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.HandleCallback()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}