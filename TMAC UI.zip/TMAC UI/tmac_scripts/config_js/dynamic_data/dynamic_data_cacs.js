﻿// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.2.01.31";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0];
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0] + intid;
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value, className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //incoming call event data
                    if (eventName === "IncomingCallEvent") {
                        try {
                            $('#txtCallerID' + intid).val(data.PhoneNumber);
                            $("#txtDNIS" + intid).val(data.VDNName);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IncomingCallEvent", ex, false);
                        }
                    }
                    //uui event data 
                    else if (eventName === "UUIDataEvent") {
                        let language = "";
                        if (!(/\s/.test(data.Language)))
                            if (data.Language === 1) {
                                language = "English";
                            }
                            else {
                                language = "Mandarin";
                            }
                        $("#txtLanguage" + intid).val(language);
                        $("#txtNRIC" + intid).val("");
                        // isVerifed or Identified ?
                        try {
                            if (data.AuthType.AuthCode === "A" || data.AuthType.AuthCode === "B" ||
                                data.AuthType.AuthCode === "C" || data.AuthType.AuthCode === "D") {
                                //TPIN Verified
                                $('#verifiedStatus' + data.InteractionID).html(
                                    "<span class='uk-text-success uk-text-bold uk-text-small'>" +
                                    "<i class='material-icons uk-text-success'>done</i>" +
                                    " TPIN Verified" +
                                    "</span>");
                            } else if (data.AuthType.AuthCode === "F" || data.AuthType.AuthCode === "G" || data.AuthType.AuthCode === "H") {
                                //Identified
                                $('#verifiedStatus' + data.InteractionID).html(
                                    "<span class='uk-text-warning uk-text-bold uk-text-small'>" +
                                    "<i class='material-icons uk-text-warning'>error</i>" +
                                    " Identified" +
                                    "</span>");
                            } else if (data.AuthType.AuthCode === "E") {
                                //Unidentified (REGISTERED HP USED)
                                $('#verifiedStatus' + data.InteractionID).html(
                                    "<span class='uk-text-danger uk-text-bold uk-text-small'>" +
                                    "<i class='material-icons uk-text-danger'>error</i>" +
                                    " Unidentified (REGISTERED HP USED)" +
                                    "</span>");
                            } else {
                                $('#verifiedStatus' + data.InteractionID).html(
                                    "<span class='uk-text-danger uk-text-bold uk-text-small'>" +
                                    "<i class='material-icons uk-text-danger'>error</i>" +
                                    " Not Identified" +
                                    "</span>");
                            }

                            var trimmedValueTPINStatus = $.trim(data.OtherData);
                            //TPIN lock Status [A,B,C] is the 22nd char in OtherData variable
                            trimmedValueTPINStatus = trimmedValueTPINStatus.substring(trimmedValueTPINStatus.length, trimmedValueTPINStatus.length - 1);
                            if (trimmedValueTPINStatus !== "") {
                                if (trimmedValueTPINStatus === "A") {
                                    //TPIN lock Status is Just Locked
                                    $('#tpinlockStatus' + data.InteractionID).html(
                                        "<span class='uk-text-danger uk-text-bold uk-text-small'>" +
                                        "<i class='material-icons uk-text-danger'>error</i>" +
                                        " TPIN JUST Locked" +
                                        "</span>");
                                } else if (trimmedValueTPINStatus === "B") {
                                    //TPIN lock Status is PREV Locked
                                    $('#tpinlockStatus' + data.InteractionID).html(
                                        "<span class='uk-text-danger uk-text-bold uk-text-small'>" +
                                        "<i class='material-icons uk-text-danger'>error</i>" +
                                        " TPIN PREV Locked" +
                                        "</span>");
                                } else if (trimmedValueTPINStatus === "C") {
                                    //TPIN lock Status is SYS GEN TPIN
                                    $('#tpinlockStatus' + data.InteractionID).html(
                                        "<span class='uk-text-success uk-text-bold uk-text-small'>" +
                                        "<i class='material-icons uk-text-success'>done</i>" +
                                        " SYS GEN TPIN" +
                                        "</span>");
                                } else {
                                    $('#tpinlockStatus' + data.InteractionID).html(
                                        "<span class='uk-text-danger uk-text-bold uk-text-small'>" +
                                        "<i class='material-icons uk-text-danger'>error</i>" +
                                        " N/A" +
                                        "</span>");
                                }
                            }
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - UUIDataEvent", ex, false);
                        }
                    }
                    //ivr data event
                    else if (eventName === "IVRDataEvent") {
                        try {
                            let ivrLastMenus = "";
                            let queueTime = data.QueueTime;
                            let colorCode = GetColorCode(GetTimeInSeconds(queueTime));
                            if (isIvrMenuEnabled && (data.LastMenu !== "null" || data.LastMenu !== null)) {
                                ivrLastMenus =
                                    "<li><span>" + data.LastMenu + "</span></li>" +
                                    "<li><span>" + data.LastMenu_2 + "</span></li>" +
                                    "<li><span>" + data.LastMenu_3 + "</span></li>" +
                                    "<li><span>" + data.LastMenu_4 + "</span></li>";

                                $("#divLast4IVR" + intid).html(ivrLastMenus);
                            }
                            $("#txtQueueTime" + intid).val(queueTime + " seconds");
                            $("#txtQueueTime" + intid).css("color", colorCode);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IVRDataEvent", ex, false);
                        }
                    }
                    //caller intent event
                    else if (eventName === "CallerIntentEvent") {
                        try {
                            $("#txtIntent" + intid).val(data.IntentName);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - CallerIntentEvent", ex, false);
                        }
                    }
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {
                    //No Chat Channel
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function HandleCallback(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var arr = [];
        arr = parse.eCin.split('/');
        var cin = arr[0]; // Customer CIN
        custom_getTextChatData(event.InteractionID, cin, event.TextChatSessionID);
        //Update VASessionID in custom table for BIP
        custom_UpdateVasessionIdForTextChat(event.InteractionID, event.TextChatSessionID, event.VAChatSessionID);
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.HandleCallback()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}