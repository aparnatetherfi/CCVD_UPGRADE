﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.2.01.31";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0];
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0] + intid;
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value, className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //No Voice Channel
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {

                    $("#hfTextChatUCID" + intid).val(data.TextChatServerSessionID);
                    let parse = JSON.parse(data.JsonData);

                    let authType = parse.pAuthType; // customer authtype
                    let callStatus = parse.pVerificationType; // customer call status

                    let scName = parse.pName;
                    let userId = parse.pUserId;
                    let cif = parse.pCIF;
                    let regNo = parse.pMobileNumber;
                    let gender = parse.pGender;
                    let DOB = parse.pDOB;
                    let nationality = parse.pNationality;
                    let channel = parse.pChannel;
                    let intent = parse.pIntent;
                    let lang = parse.pLang;
                    let chatBotSid = parse.pChatBotSid;
                    let customerTag = parse.pCustomerTag;
                    let PIBissueDate = parse.pPIBissueDate;
                    let OTPPref = parse.pOTPPref;
                    let tokenSerialNumber = parse.pTokenSerialNumber;
                    let invalidLogonAttempt = parse.pInvalidLogonAttempt;
                    let custIdStatus = parse.pCustIdStatus;
                    let tokenActivated = parse.pTokenActivated;
                    let tokenStatus = parse.pTokenStatus;
                    let failedTwoFACount = parse.pFailedTwoFACount;
                    let firstLogiDate = parse.pFirstLogiDate;
                    let firstLoginTime = parse.pfirstLoginTime;
                    let lastLoginDate = parse.plastLoginDate;
                    let lastLoginTime = parse.plastLoginTime;
                    let leadID = parse.pLeadID;
                    let applicationID = parse.pApplicationID;
                    let onboardingStatus = parse.pOnboardingStatus;
                    let queueTime = data.QueueTime;

                    // Bind user data controls
                    GetChatReferenceObj(intid).customerName = scName;
                    $("#divTabHeader" + intid).text(scName.replace(/ +/g, ""));

                    $("#tc_scName" + intid).val(scName);
                    $("#tc_scName" + intid).attr("title", scName);

                    $("#tc_userId" + intid).val(userId);
                    $("#tc_userId" + intid).attr("title", userId);

                    $("#tc_cif" + intid).val(cif);
                    $("#tc_cif" + intid).attr("title", cif);

                    $("#tc_regNo" + intid).val(regNo);
                    $("#tc_regNo" + intid).attr("title", regNo);

                    $("#tc_gender" + intid).val(gender);
                    $("#tc_gender" + intid).attr("title", gender);

                    $("#tc_DOB" + intid).val(DOB);
                    $("#tc_DOB" + intid).attr("title", DOB);

                    $("#tc_nationality" + intid).val(nationality);
                    $("#tc_nationality" + intid).attr("title", nationality);

                    $("#tc_channel" + intid).val(channel);
                    $("#tc_channel" + intid).attr("title", channel);

                    $("#tc_intent" + intid).val(intent);
                    $("#tc_intent" + intid).attr("title", intent);

                    $("#tc_lang" + intid).val(lang);
                    $("#tc_lang" + intid).attr("title", lang);

                    $("#tc_customerTag" + intid).val(customerTag);
                    $("#tc_customerTag" + intid).attr("title", customerTag);

                    $("#tc_PIBissueDate" + intid).val(PIBissueDate);
                    $("#tc_PIBissueDate" + intid).attr("title", PIBissueDate);

                    $("#tc_OTPPref" + intid).val(OTPPref);
                    $("#tc_OTPPref" + intid).attr("title", OTPPref);

                    $("#tc_tokenSerialNumber" + intid).val(tokenSerialNumber);
                    $("#tc_tokenSerialNumber" + intid).attr("title", tokenSerialNumber);

                    $("#tc_invalidLogonAttempt" + intid).val(invalidLogonAttempt);
                    $("#tc_invalidLogonAttempt" + intid).attr("title", invalidLogonAttempt);

                    $("#tc_custIdStatus" + intid).val(custIdStatus);
                    $("#tc_custIdStatus" + intid).attr("title", custIdStatus);

                    $("#tc_tokenActivated" + intid).val(tokenActivated);
                    $("#tc_tokenActivated" + intid).attr("title", tokenActivated);

                    $("#tc_tokenStatus" + intid).val(tokenStatus);
                    $("#tc_tokenStatus" + intid).attr("title", tokenStatus);

                    $("#tc_failedTwoFACount" + intid).val(failedTwoFACount);
                    $("#tc_failedTwoFACount" + intid).attr("title", failedTwoFACount);

                    $("#tc_firstLogiDateTime" + intid).val(firstLogiDate);
                    $("#tc_firstLogiDateTime" + intid).attr("title", firstLogiDate);

                    $("#tc_lastLoginDateTime" + intid).val(lastLoginDate);
                    $("#tc_lastLoginDateTime" + intid).attr("title", lastLoginDate);

                    $("#tc_leadID" + intid).val(leadID);
                    $("#tc_leadID" + intid).attr("title", leadID);

                    $("#tc_applicationID" + intid).val(applicationID);
                    $("#tc_applicationID" + intid).attr("title", applicationID);

                    $("#tc_onboardingStatus" + intid).val(onboardingStatus);
                    $("#tc_onboardingStatus" + intid).attr("title", onboardingStatus);

                    $("#tc_chatQueueTime" + intid).val(queueTime + " seconds");
                    $("#tc_chatQueueTime" + intid).attr("title", queueTime + " seconds");

                    let colorCode = GetColorCode(queueTime);
                    $("#tc_chatQueueTime" + intid).css("color", colorCode);
                    $("#tc_chatQueueTime" + intid).attr("title", colorCode);

                    let callStatusIcon = "error";
                    let callStatusIconType = "danger";
                    let authTypeIcon = "error";
                    let authTypeIconType = "danger";

                    if (callStatus === "UserID+PWD" || callStatus === "Mobile+OTP") {
                        callStatusIcon = "done";
                        callStatusIconType = "success";
                    }
                    if (authType === "Verified") {
                        authTypeIcon = "done";
                        authTypeIconType = "success";
                    }

                    //should be changed because now for all status we are appening "error" icon and "success" color
                    //should be dynamic based on the server response/ since its a new change server is responding with 
                    //only status text not the type [refer 'setUUIData' function in tmac_ui.js]
                    $('#textCallStatus' + intid)
                        .html(
                            "<span class='uk-text-" + callStatusIconType + " uk-text-bold uk-text-small'>" +
                            "<i class='material-icons uk-text-" + callStatusIconType + "'>" + callStatusIcon + "</i> " +
                            callStatus +
                            "</span>");

                    $('#textChatAuthType' + intid)
                        .html(
                            "<span class='uk-text-" + callStatusIconType + " uk-text-bold uk-text-small'>" +
                            "<i class='material-icons uk-text-" + authTypeIconType + "'>" + authTypeIcon + "</i> " +
                            authType +
                            "</span>");

                    GetTabReferenceObj(intid).OtherData.VAChatSessionID = chatBotSid;
                    GetTabReferenceObj(intid).OtherData.CIF = cif;

                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}