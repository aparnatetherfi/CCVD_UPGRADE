﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.2.01.31";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0];
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0] + intid;
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value, className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //incoming call event data 
                    if (eventName === "IncomingCallEvent") {
                        try {

                            let callTypeValue = data.CallType;
                            let callType = "";
                            if (callTypeValue === "1") {
                                callType = "ACD";
                            }
                            else if (callTypeValue === "2") {
                                if (data.IsAgentTransferedCall) {
                                    callType = "Agent Transfer";
                                }
                                else if (data.IsAgentConferencedCall) {
                                    callType = "Agent Conference";
                                }
                                else {
                                    callType = "Agent";
                                }
                            }
                            $('#txtCallerID' + intid).val(data.PhoneNumber);
                            $("#txtCallType" + intid).val(callType);
                            $("#txtVDNName" + intid).val(data.VDNName);

                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IncomingCallEvent", ex, false);
                        }
                    }
                    //uui event data 
                    else if (eventName === "UUIDataEvent") {
                        try {

                            let language = "";
                            if (!(/\s/.test(data.Language)))
                                if (data.Language === 1) {
                                    language = "English";
                                }
                                else {
                                    language = "Mandarin";
                                }
                            $("#txtLanguage" + intid).val(language);

                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - UUIDataEvent", ex, false);
                        }
                    }
                    //ivr data event
                    else if (eventName === "IVRDataEvent") {
                        try {

                            let ivrLastMenus = "";
                            let queueTime = data.QueueTime;
                            let colorCode = GetColorCode(GetTimeInSeconds(queueTime));
                            if (isIvrMenuEnabled && (data.LastMenu !== "null" || data.LastMenu !== null)) {
                                ivrLastMenus =
                                    "<li><span>" + data.LastMenu + "</span></li>" +
                                    "<li><span>" + data.LastMenu_2 + "</span></li>" +
                                    "<li><span>" + data.LastMenu_3 + "</span></li>" +
                                    "<li><span>" + data.LastMenu_4 + "</span></li>";

                                $("#divLast4IVR" + intid).html(ivrLastMenus);
                            }
                            $("#txtQueueTime" + intid).val(queueTime + " seconds");
                            $("#txtQueueTime" + intid).css("color", colorCode);

                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - IVRDataEvent", ex, false);
                        }
                    }
                    //caller intent event
                    else if (eventName === "CallerIntentEvent") {
                        try {
                            $("#txtIntent" + intid).val(data.IntentName);
                        } catch (ex) {
                            log.LogDetails("Error", "DynamicData.AssignDynamicValues() - CallerIntentEvent", ex, false);
                        }
                    }
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }

            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {
                    //No Chat Channel
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}