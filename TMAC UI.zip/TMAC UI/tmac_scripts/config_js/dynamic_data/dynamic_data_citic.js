﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.2.01.31";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0];
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        let objType;
        let appendId;
        if (type === "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0] + intid;
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value, className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //No Voice Channel
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {
                    let parse = JSON.parse(data.JsonData);
                    let scName = parse.customerName;
                    let userId = parse.customerId;
                    let cif = parse.kyc;
                    let regNo = parse.phone;
                    let gender = parse.gender;
                    let DOB = parse.age;
                    let queueTime = data.QueueTime;

                    // Bind user data controls
                    GetChatReferenceObj(intid).customerName = scName;
                    $("#divTabHeader" + intid).text(scName.replace(/ +/g, ""));

                    $("#tc_scName" + intid).val(scName);
                    $("#tc_scName" + intid).attr("title", scName);

                    $("#tc_userId" + intid).val(userId);
                    $("#tc_userId" + intid).attr("title", userId);

                    $("#tc_cif" + intid).val(cif);
                    $("#tc_cif" + intid).attr("title", cif);

                    $("#tc_regNo" + intid).val(regNo);
                    $("#tc_regNo" + intid).attr("title", regNo);

                    $("#tc_gender" + intid).val(gender);
                    $("#tc_gender" + intid).attr("title", gender);

                    $("#tc_DOB" + intid).val(DOB);
                    $("#tc_DOB" + intid).attr("title", DOB);


                    $("#tc_chatQueueTime" + intid).val(queueTime + " seconds");
                    $("#tc_chatQueueTime" + intid).attr("title", queueTime + " seconds");

                    let colorCode = GetColorCode(queueTime);
                    $("#tc_chatQueueTime" + intid).css("color", colorCode);
                    $("#tc_chatQueueTime" + intid).attr("title", colorCode);
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}