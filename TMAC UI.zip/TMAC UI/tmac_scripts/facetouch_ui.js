﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "FacetouchUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

var ft_monitor = null;

$(function () {
    global_AgentFeatures.forEach(function (item) {
        if (item.Feature === "IsFaceTouchMonitorEnabled" && item.IsEnabled) {

            log.LogDetails("Info", "FacetouchUI()", "IsFaceTouchMonitorEnabled - Init", false);

            ft_monitor = new FT_Monitor(document.getElementById('ft_container'));

            //TODO :: for enhancement
			/*
				var props = {
					numClasses: 3, //number of classes to classify
					imageSize: 227,//webcam Image size. Must be 227
					topK: 10, //k value for KNN
					counterThreshold: 5,
					gestureConfidence: 0.95,
					storageKey: "knnClassifier"
				};

				ft_monitor = new FT_Monitor(document.getElementById('ft_container'), props);

				ft_monitor.onBindPage = function (obj) {
					fileName = 'ft_' + global_AgentID + '.json';
					Custom_InvokeFunction("Custom_JsonFilesManager.dll", "Custom_JsonFilesManager.FileManager", "GetJson", [fileName], obj);
				};

				ft_monitor.onSave = function (jsonModel) {
					SaveFTJsonFile(jsonModel);
					return true;
				};

				ft_monitor.onPunch = function () {
					src = "sound/punch.wav";
					audio = new Audio(src);

					audio.play();
					console.log(" Punching you, do not touch your face, risk of covid-19");
					if (window.log) {
						UIkit.notify.closeAll();
						log.LogDetails("Error", "CustomCommand.Custom_InvokeFunction()", "Do not touch your face, risk of covid-19", true);
					}
				};

				ft_monitor.onGetFacetouchJson = function (jsonData, object) {
					if (!jsonData) {
						$("#enrollFaceTouchMonitor").removeClass("uk-display-none");
						$("#facetouch_enroll_dialog").data("kendoWindow").center().open();
						return;
					}
					$("#btnFaceTouchEnroll").removeClass("uk-display-none-important");
					faceTouchJson = jsonData;
				};

				ft_monitor.createFacetouchUI = function (instance, index) {
					var div = document.createElement("div");
					instance._container.appendChild(div);
					div.style.marginTop = "10px";

					var infoText = document.createElement("span");

					if (instance.isTrainingButtonsNeeded) {
						var divSave = document.createElement("div");
						var saveButton = document.createElement("button");
						saveButton.innerHTML = "<i class='material-icons notranslate'>save</i>";
						saveButton.classList += "md-fab md-fab-success md-fab-wave-light waves-effect waves-button waves-light";
						saveButton.style.position = "absolute";
						saveButton.style.right = "15px";
						saveButton.style.bottom = "15px";
						saveButton.addEventListener("mousedown", function () {
							return instance.save();
						});
						divSave.appendChild(saveButton);
						instance._container.appendChild(divSave);

						var button = document.createElement("button");
						if (index == 0) {
							button.innerText = "Business as Usual";
							button.classList += "md-btn-primary";
						}
						if (index == 1) {
							button.innerText = "Face Touch Alert";
							button.classList += "md-btn-danger";
						}
						if (index == 2) {
							button.innerText = "Other/ Safe";
							button.classList += "md-btn-primary";
						}

						button.classList += " md-btn md-btn-small md-btn-wave-light waves-effect waves-button waves-light";
						div.appendChild(button);

						// listen for mouse events when clicking the button
						button.addEventListener("mousedown", function () {
							return instance.training = index;
						});
						button.addEventListener("mouseup", function () {
							return instance.training = -1;
						});

						infoText.innerText = " No examples added";

					}
					else {
						var infoText1 = document.createElement("span");
						div.appendChild(infoText1);
						if (index == 0) infoText1.innerText = "Business as Usual";
						if (index == 1) infoText1.innerText = "Face Touch Alert";
						if (index == 2) infoText1.innerText = "Other/ Safe";
						infoText.innerText += " Examples added. Results will follow";
					}
					// Create info text
					div.appendChild(infoText);
					instance.infoTexts.push(infoText);
				}
			 */
        }
    });
});

function OpenFTEnrollPopup() {
    try {
        $("#facetouch_enroll_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "FacetouchUI.OpenFTEnrollPopup()", ex, false);
    }
}

function SaveFTJsonFile(json) {
    try {
        SaveJsonFileInServer(json, global_AgentID);
    } catch (ex) {
        log.LogDetails("Error", "FacetouchUI.SaveFTJsonFile()", ex, false);
    }
}

function SaveJsonFileInServer(json, agentId) {
    try {
        var obj = {
            callbackFunction: "SaveJsonFileDone"
        };

        Custom_InvokeFunction("Custom_JsonFilesManager.dll", "Custom_JsonFilesManager.FileManager", "SaveJson", ["ft_" + agentId + ".json", json], obj);
    } catch (ex) {
        log.LogDetails("Error", "FacetouchUI.SaveJsonFileInServer()", ex, false);
    }
}

function SaveJsonFileDone(response, object) {
    try {
        $("#facetouch_enroll_dialog").data("kendoWindow").close();
        $("#enrollFaceTouchMonitor").addClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "FacetouchUI.SaveJsonFileDone()", ex, false);
    }
}

function GetAgentFaceTouchJsonDone(jsonData, object) {
    try {
        if (!jsonData) {
            $("#enrollFaceTouchMonitor").removeClass("uk-display-none");
            $("#facetouch_enroll_dialog").data("kendoWindow").center().open();
            return;
        }
        $("#btnFaceTouchEnroll").removeClass("uk-display-none-important");
        faceTouchJson = jsonData;
    } catch (ex) {
        log.LogDetails("Error", "FacetouchUI.GetAgentFaceTouchJsonDone()", ex, false);
    }
}