//Tetherfi Multimedia Agent Client
//JavaScript SDK
//TMAC events (common events and voice events)
//Author - Chirag
//Last updated date - 01/06/2020

var version_tmac_face_sdk = "4.0.11.12";

try {
    AddSDKVersion("tmac_faceApi", version_tmac_face_sdk);
} catch (e) {
    //
}

var faceAuthorized = false;

var tmac_faceApi = new function () {

    //http://10.133.146.72:55444/detect
    //https://demo.tetherfilabs.com:5001/compare
    try {
        var _this = this;
        _this.faceCompareServiceUrl = typeof tmac_face_compare_serviceurl !== "undefined" ? tmac_face_compare_serviceurl : "";
        //video tag id from html which is being displayed at the left side of the screen
        _this.count = 0; //global variable
        _this.data = []; //global array for displaying notification logic in the ui for face count
        _this.isKey = false; //global variable to check whether to go for face comparision or not after face count
        _this.cocoModel = null;
        _this.onLoad = function () { };
        _this.loaded = false;
        _this.loadlModelPromise = null; //loading coco ssd model from internet for object detection. URL of model and JS is referred in html

        _this.loadLibraries = function (onload, onerror) {
            try {
                let status = {
                    predictionLibLaded: false,
                    faceApiLoaded: false
                }
                //below once the coco model is loading we are detecting the video frame by passing the model and video element in Promise

                //below is the Promise to load the tinyfacedetector and expression models from models1 folder in a tmac folder, once loaded starting video
                Promise.all([
                    cocoSsd.load(),
                    faceapi.nets.tinyFaceDetector.loadFromUri('components/faceCompare/models'),
                    //faceapi.nets.ssdMobilenetv1.loadFromUri('components/faceCompare/models'),
                    //faceapi.nets.faceLandmark68Net.loadFromUri('components/faceCompare/models'),
                    //faceapi.nets.faceRecognitionNet.loadFromUri('components/faceCompare/models'),
                    faceapi.nets.faceExpressionNet.loadFromUri('components/faceCompare/models'),
                ]).then(function (values) {
                    try {
                        _this.cocoModel = values[0];
                        console.log("face api models loaded");
                        _this.loaded = true;
                        onload();
                    } catch (ex) {
                        console.error(ex);
                    }
                }).catch(error => {
                    onerror(error);
                });

            } catch (ex) {
                console.error(ex);
            }
            return _this;

        };
        //below method is to start video streaming

        //Facecompare accepts filename which can be empty string, successmsg - which has to be displayed on ui, errorMsg - which has to be display on UI.. This calls the backend service which is python service
        _this.faceCompares = function (video, refImage, onSuccess, onError) {
            try {
                //below canvas is created, converted to base64 string of the video element and saved to the proxy upload folder as png
                let canvas = document.createElement('canvas'), context = canvas.getContext('2d');
                let width = canvas.width = video.clientWidth;
                let height = canvas.height = video.clientHeight;
                context.drawImage(video, 0, 0, width, height);
                let Sourcebase64data = canvas.toDataURL("image/jpeg");
                sendImageToChatBox = false;
                let ppdata = refImage;
                let pptype = "url";

                if (refImage.indexOf("http") >= 0) {
                    pptype = "url";
                    ppdata = refImage.substring(refImage.lastIndexOf('/') + 1);
                }
                else {
                    pptype = "base64";
                    ppdata = refImage.split(',')[1];
                }

                // prepare the request data
                var dataJson = {};
                dataJson.snaptype = "base64";
                dataJson.snapdata = Sourcebase64data.split(',')[1];
                dataJson.pptype = pptype;
                dataJson.ppdata = ppdata;
                dataJson.agentId = global_AgentID;

                // if the service url is provided, then only call the service
                if (_this.faceCompareServiceUrl) {
                    // send the request to proxy to call the python service
                    tmac_RestRequest(function (result, object) {
                        try {
                            onSuccess(JSON.parse(result));
                        } catch (e) {
                            onError(result);
                        }
                    }, null, global_AgentID, JSON.stringify(dataJson), _this.faceCompareServiceUrl, "post");
                }
                else {
                    console.warn("tmac_faceApi: tmac_face_compare_serviceurl is not priovided");
                    onError(null);
                }
            } catch (ex) {
                console.error(ex);
            }
        };

        _this.getFaceExpressions = async function (video, threshold, callback) {
            try {
                threshold = (threshold) ? threshold : 0.4;
                var emotions = {
                    happy: 0,
                    neutral: 0,
                    sad: 0,
                    surprised: 0,
                    angry: 0,
                    disgusted: 0,
                    fearful: 0
                }
                //let displaySize = { width: video.clientWidth, height: video.clientHeight };
                const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions({ scoreThreshold: threshold })).withFaceExpressions();
                //const resizedDetections = faceapi.resizeResults(detections, displaySize);
                //below is the logic to display the count of expression from the objet of objects.. if the prev express and current expression is same, counter is not incremented.
                var min = Infinity, max = -Infinity, x;
                if (detections.length === 1) {
                    var input = detections[0].expressions;
                    let maxKey;
                    for (x in input) {
                        if (input[x] < min) {
                            min = input[x];
                        }
                        if (input[x] > max) {
                            max = input[x];
                            maxKey = x;
                        }
                    }

                    if (typeof emotions[maxKey] === "number") {
                        emotions[maxKey]++;
                    }
                    callback(emotions);
                } else {
                    callback(emotions);
                }
            } catch (ex) {
                console.error(ex);
            }
        };

        _this.getFaceCount = async function (video, threshold, onSuccess, onError) {
            try {
                threshold = threshold ? threshold : 0.4;
                const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions({ scoreThreshold: threshold }));
                return detections.length;
            } catch (ex) {
                console.error(ex);
            }
        };

        _this.getPredictions = function (video, threshold, onSuccess) {
            try {
                threshold = (typeof threshold === "number") ? threshold : 0.51;
                _this.cocoModel.detect(video).then(predictions => {
                    //console.log(JSON.stringify(predictions, null, 4));
                    let items = {
                        person: 0,
                        phone: 0
                    };
                    let text = "";
                    for (var i in predictions) {
                        if (predictions[i].score >= threshold) {
                            //items[predictions[i].class] = (typeof items[predictions[i].class] === "number") ? items[predictions[i].class]++ : 1;
                            if (predictions[i].class === "person") items.person++;
                            if (predictions[i].class.indexOf('phone') >= 0) items.phone++;
                            text += predictions[i].class + ", ";
                        }
                    }
                    onSuccess(items, text);
                });
            } catch (ex) {
                console.error(ex);
            }
        };
    } catch (ex) {
        console.error(ex);
    }
};










