﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//TMAC connectors (to connect to tmac proxy)
//Author - Mohammed Sirajuddin

var version_tmac_connectors = "4.1.2.15";

var sdk_versions = [];

document.addEventListener("DOMContentLoaded", function (event) {
    TmacConnectorLoaded();
});

//on load of this document
function TmacConnectorLoaded() {
    console.log("TMAC Connect Protocol: " + window.tmacconnectprotocol);
    try {
        if (window.tmacconnectprotocol === "signalr") {
            TmacProxySignalrConnect();
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.TmacConnectorLoaded() :: " + ex);
    }
}

//proxy command objects for tmac proxy connect
var proxyCommandObjects = [];
//proxy command id for tmac proxy connect
var proxyCommandId = 0;

//----------Signalr connector----------
//signalr conector referece array
var srConn = [];

//to initiate signalr connection
function SignalRConnector(urls, protocol, type, queryString, hub, isLogging, timeout) {
    try {
        console.log("SignalRConnector() :: " + type + ", " + hub + ", " + isLogging + ", " + timeout);
        //if the urls are empty then return
        if (!urls || urls.length <= 0) {
            console.error("[" + type + "] :: Url list is empty!");
            return null;
        }
        //current instance
        var this_ = this;
        //to check connect is called
        this_.tryConnect = false;
        //connection protocol
        this_.protocol = protocol ? protocol : ["webSockets", "longPolling", "serverSentEvents", "foreverFrame"];
        //type of the connection where this signalr is used for
        this_.type = type;
        //force close flag
        this_.forceClose = false;
        //is the connection success flag
        this_.connected = false;
        //connection url list
        this_.urls = urls;
        //store the postion of url in list connected to
        this_.connectUrlCount = 0;
        //connection retry count
        this_.retryCount = 1;
        //max retry count
        this_.maxRetry = typeof tmac_signalr_maxretry !== "undefined" ? tmac_signalr_maxretry : 60;
        //create the signalr connection
        this_.con = $.hubConnection(urls[this_.connectUrlCount]);
        //method to set new url for connection
        this_.setUrls = function (urls) {
            //add the urls to list
            this_.urls = urls;
            //change the signalr connection to new url
            this_.con = $.hubConnection(urls[0]);
        };
        //signalr logging is required
        this_.con.logging = isLogging ? isLogging : false;
        //query string for the connection to pass to server during the connection
        this_.con.qs = queryString ? queryString : null;
        //create the signalr hub proxy
        this_.hub = this_.con.createHubProxy(hub);
        //log the details
        this_.log = function (type, message) {
            message = new Date() + " :: " + message;
            switch (type) {
                case "log":
                    console.log(message);
                    break;
                case "info":
                    console.info(message);
                    break;
                case "warn":
                    console.warn(message);
                    break;
                case "error":
                    console.error(message);
                    break;
                default:
                    console.log(message);
            }
        };
        //signalr instance starting callback
        this_.onStarting = function () {
            this_.log("info", "SignalR :: [" + type + "] :: starting");
        };
        //signalr instance connected callback
        this_.onConnected = function (instance) { };
        //signalr instance received callback
        this_.onReceived = function (obj) {
            this_.log("info", "SignalR :: [" + type + "] :: received");
        };
        //signalr instance connectionSlow callback
        this_.onConnectionSlow = function () {
            this_.log("warn", "SignalR :: [" + type + "] :: We are currently experiencing difficulties with the connection!");
        };
        //signalr instance error callback
        this_.onError = function (error) {
            this_.log("error", "SignalR :: [" + type + "] :: " + error);
        };
        //signalr instance reconnecting callback
        this_.onReconnecting = function () {
            this_.log("info", "SignalR :: [" + type + "] :: reconnecting");
        };
        //signalr instance reconnected callback
        this_.onReconnected = function () {
            this_.log("info", "SignalR :: [" + type + "] :: reconnected");
        };
        //signalr instance disconnected callback
        this_.onDisconnected = function (obj) { };
        //on signalr starting
        this_.con.starting(function () {
            this_.onStarting();
        });
        //on signalr recevied
        this_.con.received(function (obj) {
            this_.onReceived(obj);
        });
        //on signalr connection slow
        this_.con.connectionSlow(function () {
            this_.onConnectionSlow();
        });
        //on signalr error
        this_.con.error(function (error) {
            this_.onError(error);
        });
        //on signalr reconnecting
        this_.con.reconnecting(function () {
            this_.connected = false;
            this_.onReconnecting();
        });
        //on signalr reconnected
        this_.con.reconnected(function () {
            this_.connected = true;
            this_.onReconnected();
        });
        //on signalr disconnected
        this_.con.disconnected(function (obj) {
            this_.log("info", "SignalR :: [" + type + "] :: disconnected: " + this_.con.url);
            this_.connected = false;
            this_.tryConnect = false;
            //if closed forcefully then don't try to reconnect on disconnected
            if (!this_.forceClose) {
                //check if the connect url count is greater or equal to the length of provided urls
                //if so the reset the connect url count else increase the connect url count
                if (this_.connectUrlCount >= this_.urls.length - 1) {
                    this_.connectUrlCount = 0;
                }
                else
                    this_.connectUrlCount++;
                //change the signalr connection url
                this_.con.url = this_.urls[this_.connectUrlCount] + "/signalr";
                this_.log("info", "SignalR :: [" + type + "] :: try manual connecting after " + this_.retryCount + " seconds : " + this_.con.url);
                //try to connect on an interval of 1,2,3,4,5... seconds
                setTimeout(function () {
                    this_.connect();
                }, this_.retryCount * 1000); // Re-start connection
                //if not connected in a cylce increase the retry count
                this_.retryCount++;
                //close the browser/reload after a min of retrying
                //if (this_.retryCount >= this_.maxRetry) {
                //    window.close();
                //    location.reload();
                //}
            }
            else {
                this_.log("info", "SignalR :: [" + type + "] :: disconnected, manual retry is disabled!");
            }
            this_.onDisconnected(obj);
        });
        //connect method
        this_.connect = function () {
            //if no connect try, then try to connect or if forceClose is true do not connect
            if (!this_.tryConnect && !this_.forceClose) {
                this_.tryConnect = true;
                this_.con.start({ transport: this_.protocol }).done(function () {
                    this_.log("info", "SignalR :: [" + type + "] :: connected, url = " + this_.con.url + ", transport = " + this_.con.transport.name + ", connectionId= " + this_.con.id);
                    //to specify the disconnect time for the signalr to try auto connect to the same url
                    this_.con.disconnectTimeout = timeout ? timeout : 30000;
                    this_.connected = true;
                    this_.onConnected(this_);
                    this_.retryCount = 0;
                });
            }
            else {
                this_.log("warn", "SignalR :: [" + type + "] :: could not connect to the server, tryConnect=" + this_.tryConnect + ", forceClose=" + this_.forceClose);
            }
        };
        //to close close
        this_.close = function (force) {
            this_.log("info", "SignalR :: [" + type + "] :: stop the connection.");
            this_.forceClose = force;
            this_.tryConnect = false;
            this_.con.stop();
        };
    } catch (ex) {
        console.error("Exception in SignalRConnector() :: " + ex);
    }
}

//to get the signalr referece
function GetSRConnection(type) {
    try {
        let con = srConn.filter(function (c) { return c.type === type; });
        if (con.length > 0) {
            return con[0];
        }
    } catch (ex) {
        console.error("Exception in GetSRConnection() :: " + ex);
    }
    return null;
}

//to connect to signalr server for tmac proxy
function TmacProxySignalrConnect() {
    try {
        var qs = {
            deviceId: global_DeviceID ? global_DeviceID : "",
            lanId: global_LanID ? global_LanID : "",
            agentId: global_AgentID ? global_AgentID : "",
            agentSessionKey: global_AgentSessionKey ? global_AgentSessionKey : "",
            tmacServer: _tmacServer ? _tmacServer : ""
        };

        var conn = new SignalRConnector(tmacProxyList, tmac_signalr_protocol, "TmacProxy", qs, "TmacProxyHub", true, 10000);
        if (conn) {
            srConn.push(conn);
            conn.hub.on('onTmacProxyCommandDone', function (commandId, methodName, resultData) {
                try {
                    console.log("[TmacProxy] :: onTmacProxyCommandDone: [" + methodName + "]");
                    ProxySetConnectivityStatus(1, 'signalr', "onevent");
                    var obj = GetMethodObjectRef(commandId);
                    if (obj) {
                        window["tmac_" + methodName + "Done"](obj.callbackFunction, obj.userObject, obj.inputData, resultData);
                    }
                    else {
                        window["tmac_" + methodName + "Done"](null, null, null, resultData);
                    }
                    RemoveMethodObject(obj);
                } catch (ex) {
                    console.error(methodName + " :: " + ex);
                }
            });
            conn.hub.on('onTMACEvents', function (evt) {
                HandleEvent(evt);
            });
            conn.onConnected = function (instance) {
                try {
                    if (global_AgentSessionKey) {
                        ProxySetConnectivityStatus(1, 'signalr', "onconnected");
                        GetEvent();
                        //InvokeGetEvents();
                    }
                    //trim 'signalr' from the url
                    global_connectedProxy = instance.con.url.substr(0, instance.con.url.length - 7);
                    ProxyConnectionSuccessEvent(global_connectedProxy);
                } catch (e) {
                    //
                }
            };
            conn.onDisconnected = function () {
                if (global_AgentSessionKey) {
                    _getEventFlag = false;
                    ProxySetConnectivityStatus(2, 'signalr', "ondisconnected");
                }
            };
            conn.onReconnecting = function () {
                if (global_AgentSessionKey) {
                    _getEventFlag = false;
                    ProxySetConnectivityStatus(0, 'signalr', "onreconnecting");
                }
            };
            conn.onConnectionSlow = function () {
                if (global_AgentSessionKey) {
                    ProxySetConnectivityStatus(0, 'signalr', "onconnectionslow");
                }
            };
            conn.onReconnected = function () {
                if (global_AgentSessionKey) {
                    ProxySetConnectivityStatus(1, 'signalr', "onreconnected");
                    GetEvent();
                    //InvokeGetEvents();
                }
            };
            conn.onReceived = function (obj) { };
            conn.connect();
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.TmacProxySignalrConnect() :: " + ex);
    }
}

let _getEventFlag = false;
function InvokeGetEvents() {
    try {
        //check if the get event started already
        if (!_getEventFlag) {
            console.log("TmacConnectors.InvokeGetEvent: start");
            //set timeout to make sure the UI is loaded completely
            setTimeout(function () {
                _getEventFlag = true;
                var conn = GetSRConnection("TmacProxy");
                conn.hub.invoke("GetEvents", conn.con.id, global_DeviceID, global_AgentSessionKey, global_AgentID, global_LanID, _tmacServer);
            }, 2000);
        }
        else {
            console.warn("TmacConnectors.InvokeGetEvent: already invoked!");
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeGetEvent() :: " + ex);
    }
}

//to invoke tmac proxy commands 
function InvokeSignalrProxyMethod(callbackFunction, userObject, inputData, methodName) {
    try {
        console.log("[TmacProxy] :: InvokeSignalrProxyMethod: [" + methodName + "]");
        var conn = GetSRConnection("TmacProxy");
        proxyCommandId++;
        SaveMethodObject(proxyCommandId, methodName, callbackFunction, userObject, inputData);
        if (conn && conn.connected) {
            conn.hub.invoke("TmacProxyCommand", conn.con.id, proxyCommandId, methodName, JSON.stringify(inputData));
        }
        else {
            //remove the saved method object reference before retry
            RemoveMethodObject(GetMethodObjectRef(proxyCommandId));
            //try to get invoke the method again after 1s. This may be intial method call before connecting to signalr tmac proxy
            setTimeout(function () {
                InvokeSignalrProxyMethod(callbackFunction, userObject, inputData, methodName);
            }, 1000);
            console.warn("[TmacProxy] :: [" + methodName + "] :: srConn is undefined");
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeSignalrProxyMethod() :: " + ex);
    }
}

//----------------------------------------------------------------------------------------------------------------

//----------Web Socket connector----------
//websocket object
var wsConn = null;
//websocket url list
var webSocketUrlList = [];
//websocket url list in string format
var webSocketUrlListString = "";
//websocket retry id
var webSocketLastTryId = -1;
//websocket connected url
var webSocketConnectedUrl = "";
//websocket opened flag
var isWebSocketOpen = false;
//websocket auto connect flag
var isWebSocketAutoConnect = false;
//websocket auth code
var webSocektAuthCode = "";

function TmacProxyWebSocketConnect(retry) {
    try {
        if (!global_successfullyLoggedInData.webSocektAuthCode) {
            webSocektAuthCode = document.getElementById("hfAuthKey").value;
            global_successfullyLoggedInData.webSocektAuthCode = webSocektAuthCode;
        } else {
            webSocektAuthCode = global_successfullyLoggedInData.webSocektAuthCode;
        }

        if (!global_successfullyLoggedInData.webSocketUrlListString) {
            webSocketUrlListString = document.getElementById("hfTmacConnectUrl").value;
            global_successfullyLoggedInData.webSocketUrlListString = webSocketUrlListString;
        } else {
            webSocketUrlListString = global_successfullyLoggedInData.webSocketUrlListString;
        }

        if (!webSocketUrlListString) return;

        webSocketUrlList = webSocketUrlListString.split(',');

        if (webSocketUrlList.length <= 0) return;

        if (retry) {
            if (webSocketUrlList.length > webSocketLastTryId + 1) {
                webSocketLastTryId++;
                webSocketConnectedUrl = webSocketUrlList[webSocketLastTryId];
                //reset webSocketLastTryId if it has reached the max
                if (webSocketLastTryId >= webSocketUrlList.length)
                    webSocketLastTryId = -1;
            } else {
                webSocketLastTryId = -1;
            }
        } else {
            //assign the first url
            webSocketConnectedUrl = webSocketUrlList[0];
        }

        console.log("Trying to connect:" + webSocketConnectedUrl);

        wsConn = new WebSocket(webSocketConnectedUrl);
        //setup websocket callbacks
        wsConn.addEventListener("message", OnWebSocketMessage, false);
        wsConn.onopen = function (event) {
            isWebSocketOpen = true;
            ProxySetConnectivityStatus(1, 'ws', "onopen");
            //call get event to restart get event thread
            ProxyUpdateAgentDetails();
        };
        wsConn.onerror = function (error) {
            ProxySetConnectivityStatus(2, 'ws', "onerror");
            if (wsConn.readyState === 1) {
                console.log('ws normal error: ' + error.type);
            }
        };
        wsConn.onclose = function (event) {
            tmac_ws_websock_isopen = false;
            ProxySetConnectivityStatus(2, 'ws', "onclose");
            if (event.code === 3001) {
                //
            } else {
                console.log('ws connection error: ' + event.code);
                //retry connecting
                setTimeout(function () {
                    TmacProxyWebSocketConnect(true);
                }, 4000);
            }
        };
    } catch (ex) {
        console.error("Exception in TmacConnectors.TmacProxyWebSocketConnect: " + ex);
    }
}

//to invoke websocket proxy method
function InvokeWSProxyMethod(callbackFunction, userObject, userInput, methodName, timeout, waitForSocketCount) {
    try {
        //check if the socket is open
        if (!isWebSocketOpen) {
            if (!waitForSocketCount) waitForSocketCount = 0;

            //wait only 20 seconds
            if (waitForSocketCount > 5) return;

            //wait for a while and call the method again
            setTimeout(function () {
                waitForSocketCount = waitForSocketCount + 1;
                InvokeWSProxyMethod(callbackFunction, userObject, userInput, methodName, timeout, waitForSocketCount);
            }, 4000);
            return;
        }

        var msg = {};
        msg.Data = userInput;
        msg.Command = methodName;
        msg.AuthCode = webSocektAuthCode;
        msg.CommandID = proxyCommandId++;

        if (proxyCommandId > 10000) proxyCommandId = 0;

        SaveMethodObject(proxyCommandId, methodName, callbackFunction, userObject, inputData);

        try {
            wsConn.send(JSON.stringify(msg));
            ProxySetConnectivityStatus(0, 'ws', "onsend");
        } catch (e) {
            ProxySetConnectivityStatus(2, 'ws', "onsenderror");
            if (methodname === "Logout") {
                window.global_LogoutCommandSend = false;
            }
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeWSProxyMethod() :: " + ex);
    }
}

//on websocket message received
function OnWebSocketMessage(event) {
    try {
        var resultData = JSON.parse(event.data);
        if (resultData.Command === "UnautherizedEvent") {
            //not autherized
            UnautherizedEvent();
        }
        else if (resultData.Command === "TmacServerConnectionStatus") {
            if (resultData.Data.EventName === "TmacServerConnectionFailed") {
                alert("Tmac connection failed. Please wait while we reconnect you");
            }
            if (resultData.Data.EventName === "TmacServerConnectionSuccess") {
                //reset the session key
                if (obj.Data.Data && obj.Data.Data)
                    global_AgentSessionKey = obj.Data.Data;

                //recover interactions
                try {
                    tmac_RecoverInteractions(null, null, global_AgentID, JSON.stringify(tmac_events_interaction_recovery_data));

                } catch (e) {
                    //
                }
                alert("Tmac connection established. Please use hard phone to control ongoing calls");
            }
            if (resultData.Data.EventName === "TmacServerConnectionAborted") {
                alert("Critical error. Please logout and login");
                window.close();
            }
        }
        ProxySetConnectivityStatus(1, 'ws', "onevent");
        var obj = GetMethodObjectRef(resultData.CommandID);
        if (obj) {
            window["tmac_" + resultData.Command + "Done"](obj.callbackFunction, obj.userObject, obj.inputData, resultData.Data);
        }
        else {
            window["tmac_" + resultData.Command + "Done"](null, null, null, resultData.Data);
        }
        RemoveMethodObject(obj);
    } catch (ex) {
        console.error("Exception in TmacConnectors.OnWebSocketMessage() :: " + ex);
    }
}

//to update the agent details in server (websocket)
function ProxyUpdateAgentDetails() {
    try {
        if (location.href.indexOf("mainscreen") >= 0) {
            var data = {};
            data.lanId = global_LanID;
            data.stationid = global_DeviceID;
            data.agentid = global_AgentID;
            data.sessionkey = global_AgentSessionKey;
            InvokeWSProxyMethod(null, null, data, "UpdateAgentDetails");
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.ProxyUpdateAgentDetails() :: " + ex);
    }
}

//unauthorized event
function UnautherizedEvent(event) {
    alert(event.ResultMessage);
}

//----------------------------------------------------------------------------------------------------------------

//----------AJAX/Rest connector-----------
//ajax url count
var ajaxUrlCount = 0;
var tmac_asmx_url_count = 0;
//ajax retry attempts
var ajaxAttempts = 0;
//ajax retry reference 
var ajaxRetryRef = [];
//ajax retry max count
var ajaxRetryCount = 3;
//error callback method name
var commandErrorCallback = "";

//to invoke ajax proxy method
function InvokeAJAXProxyMethod(dataValue, url, timeout, callbackFunction, userObject, inputData, methodName) {
    try {
        $.ajax({
            type: "POST",
            url: url,
            data: dataValue,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                try {
                    ajaxAttempts = 0;
                    ProxySetConnectivityStatus(1, global_TmacSignalRUrl ? 'signalr' : 'ajax', "onresponse");
                    global_connectedProxy = tmacProxyList[ajaxUrlCount];
                    ProxyConnectionSuccessEvent(global_connectedProxy);
                } catch (e) {
                    //
                }
                var resultData;
                if (window.tmacconnectprotocol === "webapi") {
                    resultData = JSON.parse(msg).Data;
                }
                else if (window.tmacconnectprotocol === "rest") {
                    resultData = msg;
                }
                else {
                    resultData = msg.d;
                }
                try {
                    window["tmac_" + methodName + "Done"](callbackFunction, userObject, inputData, resultData);
                    RemoveAjaxRetryMethod(methodName);
                } catch (e) {
                    //
                }
            },
            error: function (xhr, status, error) {

                try {
                    AjaxError(xhr, callbackFunction, userObject, inputData, methodName);
                } catch (e) {
                    //
                }

                try {
                    if (methodName === "GetEvent") {
                        ProxySetConnectivityStatus(2, global_TmacSignalRUrl ? 'signalr' : 'ajax', "onrequesterror");
                    }
                } catch (e) {
                    //
                }

                try {
                    if (!(xhr.status >= 200 && xhr.status < 400)) {
                        // increment tmac proxy url count
                        tmac_asmx_url_count = (tmac_asmx_url_count + 1) % tmac_asmx_url_list.length;
                        ajaxUrlCount = (ajaxUrlCount + 1) % tmac_asmx_url_list.length;
                        
                        //2016-12-09 call below bethod after an interval (continuous calling might cause browser hung)
                        ajaxAttempts++;
                        setTimeout(function () {
                            tmac_command(callbackFunction, userObject, inputData, methodName);
                        }, ajaxAttempts * 1000);
                        return;
                    }

                    window[commandErrorCallback](error, userObject);
                } catch (e) {
                    //
                }

                try {
                    if (methodName === "GetEvent") {
                        ProxySetConnectivityStatus(2, global_TmacSignalRUrl ? 'signalr' : 'ajax', "onrequesterror");
                        window["tmac_" + methodName + "Done"](callbackFunction, userObject, inputData, null);
                    }
                } catch (e) {
                    //
                }
            },
            timeout: timeout
        });
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeAJAXProxyMethod() :: " + ex);
    }
}

//to remove the retry method for ajax call
function RemoveAjaxRetryMethod(methodName) {
    try {
        if (ajaxRetryRef.indexOf(methodName) >= 0)
            ajaxRetryRef = ajaxRetryRef.filter(function (i) { return i !== methodName; });
    } catch (ex) {
        console.error("Exception in TmacConnectors.RemoveAjaxRetryMethod() :: " + ex);
    }
}

//to invoke rest methods using url
function InvokeRestMethod(callbackFunction, userObject, inputData, url) {
    try {
        var timeout = 60000;
        var dataValue = JSON.stringify(inputData);
        var httpType = "POST";

        $.ajax({
            type: httpType,
            url: url,
            data: dataValue,
            contentType: userObject.contentType,
            dataType: "json",
            success: function (msg) {
                var resultData = msg;
                try {
                    callbackFunction(true, userObject, inputData, resultData);
                } catch (e) {
                    //
                }
            },
            error: function (xhr, status, error) {
                console.error("ResponseText: " + xhr.responseText + ", URL: " + url);
                callbackFunction(false, userObject, inputData, null);
            },
            timeout: timeout
        });
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeRestMethod() :: " + ex);
    }
}

//----------------------------------------------------------------------------------------------------------------

//----------Common Methods----------------

function InvokeTMACProxy(callbackFunction, userObject, inputData, methodName) {
    try {
        var timeout = 60000;
        var dataValue = null;
        var url = null;

        var ignoreServerNameMethods = ["GetAgentSessionsList", "GetAgentStatus", "GetLoggedInAgentList", "GetTmacServerId"];
        if (!(methodName.substring(0, 10) === "EMM_Email_") &&
            ignoreServerNameMethods.indexOf(methodName) < 0) {
            inputData.tmacServer = _tmacServer;
        }

        if (window.tmacconnectprotocol === "ws") {
            // set the connectivity status
            ProxySetConnectivityStatus(0, "ws", "onrequest");
            InvokeWSProxyMethod(callbackFunction, userObject, inputData, methodName, timeout);
            return;
        }
        else if (window.tmacconnectprotocol === "signalr") {
            // set the connectivity status
            ProxySetConnectivityStatus(0, "signalr", "onrequest");
            InvokeSignalrProxyMethod(callbackFunction, userObject, inputData, methodName);
            return;
        }

        // VP: Jul 9, 20: Not used
        // else if (window.tmacconnectprotocol === "webapi") {
        //     ProxySetConnectivityStatus(0, global_TmacSignalRUrl ? "signalr" : "ajax", "onrequest");
        //     var commandJson = {};
        //     commandJson.Data = inputData;
        //     commandJson.Command = methodName;
        //     commandJson.CommandID = "0";
        //     commandJson.AuthCode = tmac_authcode;

        //     dataValue = JSON.stringify(commandJson);
        //     url = window.tamc_webapi_url;

        //     InvokeAJAXProxyMethod(dataValue, url, timeout, callbackFunction, userObject, inputData, methodName);
        // }
        else {
            // set the connectivity status
            ProxySetConnectivityStatus(0, global_TmacSignalRUrl ? "signalr" : "ajax", "onrequest");
            dataValue = JSON.stringify(inputData);
            url = tmacProxyList[ajaxUrlCount] + methodName;

            InvokeAJAXProxyMethod(dataValue, url, timeout, callbackFunction, userObject, inputData, methodName);
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.InvokeTMACProxy() :: " + ex);
    }
}

//to save tmac proxy commands objects
function SaveMethodObject(commandId, methodName, callbackFunction, userObject, inputData) {
    try {
        var obj = {
            commandId: commandId,
            methodName: methodName,
            callbackFunction: callbackFunction,
            userObject: userObject,
            inputData: inputData
        };

        if (!GetMethodObjectRef(obj.commandId)) {
            proxyCommandObjects.push(obj);
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.SaveMethodObject() :: " + ex);
    }
}

//to get the saved tmac proxy commands objects
function GetMethodObjectRef(commandId) {
    try {
        for (var i = 0; i < proxyCommandObjects.length; i++) {
            if (proxyCommandObjects[i] && proxyCommandObjects[i].commandId === parseInt(commandId))
                return proxyCommandObjects[i];
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.GetMethodObjectRef() :: " + ex);
    }
}

//to remove tmac proxy commands objects
function RemoveMethodObject(obj) {
    try {
        var index = proxyCommandObjects.indexOf(obj);
        proxyCommandObjects.splice(index, 1);
    } catch (ex) {
        console.error("Exception in TmacConnectors.RemoveMethodObject() :: " + ex);
    }
}

//to set the connectivity status in tmac ui
function ProxySetConnectivityStatus(stat, source, type) {
    try {
        SetConnectivityStatus(stat, source, type);
    } catch (ex) {
        //
    }
}

//to store all SDK versions
function AddSDKVersion(file, version) {
    try {
        var val = file + ": " + version;
        if (sdk_versions) {
            if (sdk_versions.indexOf(val) < 0) {
                sdk_versions.push(val);
            }
        }
    } catch (ex) {
        console.error("Exception in TmacConnectors.AddSDKVersion() :: " + ex);
    }
}

function ToEncodedString(ostr) {
    try {
        ostr = ostr.replace(/\s+/g, '');
        var x, nstr = '',
            len = ostr.length;
        for (x = 0; x < len; ++x) {
            nstr += (255 - ostr.charCodeAt(x)).toString(36).toUpperCase();
        }
        return nstr;
    } catch (ex) {
        console.error("Exception in TmacConnectors.ToEncodedString() :: " + ex);
    }
}

function FromEncodedString(ostr) {
    try {
        var x, nstr = '', len = ostr.length;
        for (x = 0; x < len; x += 2) {
            nstr += String.fromCharCode(255 - parseInt(ostr.substr(x, 2), 36));
        };
        return nstr;
    } catch (ex) {
        console.error("Exception in TmacConnectors.FromEncodedString() :: " + ex);
    }
    return ostr;
}

//----------------------------------------------------------------------------------------------------------------
try {
    AddSDKVersion("tmac_connectors", version_tmac_connectors);
} catch (e) {
    //
}