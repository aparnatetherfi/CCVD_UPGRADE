﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//TMAC commands (all tmac proxy commands)
//Author - Weerathungage Sumudu Saman

var version_tmac_commands = "4.1.2.15";

try {
    AddSDKVersion("tmac_commands", version_tmac_commands);
} catch (e) {
    //
}

var global_DeviceID;
var global_LanID;
var global_AgentID;
var global_AgentSessionKey;
var global_successfullyLoggedInData = {};
var global_LogoutCommandSend = false;
var global_CurrentStatus = "";
var global_AgentSkills;
var global_TmacSignalRUrl = "";
var global_Password = "";
var global_LoginJsonData = "";

var _isAgentLoggedIn = true;
var _tmacServer = "";
var _startEventPolling = false;
var _tryReconnecting = false;

//----------------------------------------------------------------------------------------------------------------

function command(data, method, object, timeout) {
    InvokeTMACProxy(method + "Done", object, data, method);
}

function tmac_command(callbackfunction, userobject, data, methodname) {
    InvokeTMACProxy(callbackfunction, userobject, data, methodname);
}

function tmac_RestCall(callbackfunction, userobject, data, url) {
    InvokeRestMethod(callbackfunction, userobject, data, url);
}

//----------------------------------------------------------------------------------------------------------------

function tmac_GetUserDomainList(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetUserDomainList");
}

function tmac_GetUserDomainListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_AnswerCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "AnswerCall");
}

function tmac_AnswerCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_AssignWorkItemToAgent(callbackfunction, userobject, agentid, channel, workitemid) {
    var data = {};
    data.agentid = agentid;  //String
    data.channel = channel;  //String
    data.workitemid = workitemid;  //String
    tmac_command(callbackfunction, userobject, data, "AssignWorkItemToAgent");
}

function tmac_AssignWorkItemToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_AssignWorkItemToAgentByGlobalKey(callbackfunction, userobject, agentid, globalKey) {
    var data = {};
    data.agentid = agentid;  //String
    data.globalKey = globalKey;  //Int32
    tmac_command(callbackfunction, userobject, data, "AssignWorkItemToAgentByGlobalKey");
}

function tmac_AssignWorkItemToAgentByGlobalKeyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ChangeStatus(callbackfunction, userobject, deviceid, statustype, statuscode) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.statustype = statustype;  //String
    data.statuscode = statuscode;  //String
    tmac_command(callbackfunction, userobject, data, "ChangeStatus");
}

function tmac_ChangeStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (resultdata.Status === "not logged in") {
            //set _isAgentLoggedIn to false
            _isAgentLoggedIn = false;
        }
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ChangeTmacServer(callbackfunction, userobject, url) {
    var data = {};
    data.url = url;  //String
    tmac_command(callbackfunction, userobject, data, "ChangeTmacServer");
}

function tmac_ChangeTmacServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_CloseTab(callbackfunction, userobject, deviceid, interactionid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "CloseTab");
}

function tmac_CloseTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ConferenceCall(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceCall");
}

function tmac_ConferenceCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ConferenceCancel(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceCancel");
}

function tmac_ConferenceCancelDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ConferenceComplete(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceComplete");
}

function tmac_ConferenceCompleteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_CopyAgentSessionsFromRemoteServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "CopyAgentSessionsFromRemoteServer");
}

function tmac_CopyAgentSessionsFromRemoteServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_CreateAgentReminder(callbackfunction, userobject, deviceid, agentid, reminddate, remindtime, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.reminddate = reminddate;  //String
    data.remindtime = remindtime;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "CreateAgentReminder");
}

function tmac_CreateAgentReminderDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Custom_InvokeFunction(callbackfunction, userobject, moduleName, className, funcitonName, parameters) {
    var data = {};
    data.moduleName = moduleName;  //String
    data.className = className;  //String
    data.funcitonName = funcitonName;  //String
    data.parameters = parameters;  //String[]
    tmac_command(callbackfunction, userobject, data, "Custom_InvokeFunction");
}

function tmac_Custom_InvokeFunctionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ExternalConnect_GenericCommand(callbackfunction, userobject, moduleName, className, funcitonName, parameters) {
    var data = {};
    data.moduleName = moduleName;  //String
    data.className = className;  //String
    data.funcitonName = funcitonName;  //String
    data.parameters = parameters;  //String[]
    tmac_command(callbackfunction, userobject, data, "ExternalConnect_GenericCommand");
}

function tmac_ExternalConnect_GenericCommandDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Custom_InvokeFunction_SecondServer(callbackfunction, userobject, moduleName, className, funcitonName, parameters) {
    var data = {};
    data.moduleName = moduleName;  //String
    data.className = className;  //String
    data.funcitonName = funcitonName;  //String
    data.parameters = parameters;  //String[]
    tmac_command(callbackfunction, userobject, data, "Custom_InvokeFunction_SecondServer");
}

function tmac_Custom_InvokeFunction_SecondServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_DisconnectCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectCall");
}

function tmac_DisconnectCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_DisconnectCallByHandle(callbackfunction, userobject, deviceid, connectionhandle) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.connectionhandle = connectionhandle;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectCallByHandle");
}

function tmac_DisconnectCallByHandleDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_DisconnectStation(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectStation");
}

function tmac_DisconnectStationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Equals(callbackfunction, userobject, obj) {
    var data = {};
    data.obj = obj;  //Object
    tmac_command(callbackfunction, userobject, data, "Equals");
}

function tmac_EqualsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Boolean
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_External_SendEmail(callbackfunction, userobject, mailbox, subject, body, mailTo, mailCc, mailBcc, mailFrom, outEmailSessionId, attachmentFileList) {
    var data = {};
    data.mailbox = mailbox;  //String
    data.subject = subject;  //String
    data.body = body;  //String
    data.mailTo = mailTo;  //String
    data.mailCc = mailCc;  //String
    data.mailBcc = mailBcc;  //String
    data.mailFrom = mailFrom;  //String
    data.outEmailSessionId = outEmailSessionId;  //String
    data.attachmentFileList = attachmentFileList;  //String
    tmac_command(callbackfunction, userobject, data, "External_SendEmail");
}

function tmac_External_SendEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Facebook_Feed_GetAssignedAgent(callbackfunction, userobject, feedid, feedJson, autoRoute) {
    var data = {};
    data.feedid = feedid;  //String
    data.feedJson = feedJson;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Facebook_Feed_GetAssignedAgent");
}

function tmac_Facebook_Feed_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Facebook_Feed_RouteToAgent(callbackfunction, userobject, feedid, feedJson, agentid) {
    var data = {};
    data.feedid = feedid;  //String
    data.feedJson = feedJson;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Facebook_Feed_RouteToAgent");
}

function tmac_Facebook_Feed_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Facebook_PM_GetAssignedAgent(callbackfunction, userobject, pmId, pmJson, autoRoute) {
    var data = {};
    data.pmId = pmId;  //String
    data.pmJson = pmJson;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Facebook_PM_GetAssignedAgent");
}

function tmac_Facebook_PM_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Facebook_PM_RouteToAgent(callbackfunction, userobject, feedid, pmJson, agentid) {
    var data = {};
    data.feedid = feedid;  //String
    data.pmJson = pmJson;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Facebook_PM_RouteToAgent");
}

function tmac_Facebook_PM_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_FB_CommentOnPost(callbackfunction, userobject, deviceid, interactionid, postid, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.postid = postid;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "FB_CommentOnPost");
}

function tmac_FB_CommentOnPostDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_FB_ReplyToComment(callbackfunction, userobject, deviceid, interactionid, commentid, postid, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.commentid = commentid;  //String
    data.postid = postid;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "FB_ReplyToComment");
}

function tmac_FB_ReplyToCommentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_FB_ReplyToConversation(callbackfunction, userobject, deviceid, interactionid, postid, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.postid = postid;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "FB_ReplyToConversation");
}

function tmac_FB_ReplyToConversationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentList(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetAgentList");
}

function tmac_GetAgentListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentListStaffed(callbackfunction, userobject, sync) {
    var data = {};
    //data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "GetAgentListStaffedAll");
}

function tmac_GetAgentListStaffedAllDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1 {AgentModel:  TmacServer}
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_GetAgentReminders(callbackfunction, userobject, deviceid, agentid, status, reminddatetimeStart, reminddatetimeEnd, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.status = status;  //String
    data.reminddatetimeStart = reminddatetimeStart;  //String
    data.reminddatetimeEnd = reminddatetimeEnd;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "GetAgentReminders");
}

function tmac_GetAgentRemindersDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentStatus(callbackfunction, userobject, deviceid, agentid, destTmacServerName) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    if (destTmacServerName) data.tmacServer = destTmacServerName;
    tmac_command(callbackfunction, userobject, data, "GetAgentStatus");
}

function tmac_GetAgentStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        //assign the status to global reference
        if (resultdata && resultdata.ResultCode > 0) {
            global_CurrentStatus = resultdata.ResultMessage;
        }

        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_GetAllMethodNames(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetAllMethodNames");
}

function tmac_GetAllMethodNamesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAutoSuggestResponseTemplates(callbackfunction, userobject, deviceid, interactionid, message, intent, channel) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.message = message;  //String
    data.intent = intent;  //String
    data.channel = channel;  //String
    tmac_command(callbackfunction, userobject, data, "GetAutoSuggestResponseTemplates");
}

function tmac_GetAutoSuggestResponseTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = TextResponseTemplate
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAutoSuggestTemplateIntents(callbackfunction, userobject, channel) {
    var data = {};
    data.channel = channel;  //String
    tmac_command(callbackfunction, userobject, data, "GetAutoSuggestTemplateIntents");
}

function tmac_GetAutoSuggestTemplateIntentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetEmailQueue(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetEmailQueue");
}

function tmac_GetEmailQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Dictionary`2
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetEmailServerStatus(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetEmailServerStatus");
}

function tmac_GetEmailServerStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetEmailSkills(callbackfunction, userobject, type) {
    var data = {};
    data.type = type;  //String
    tmac_command(callbackfunction, userobject, data, "GetEmailSkills");
}

function tmac_GetEmailSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetEvent(callbackfunction, userobject, deviceid, sessionkey, sync) {
    //check if TMAC signalr connector is there then do not poll
    if (global_TmacSignalRUrl) {
        checkForSignalRServer();
        return;
    }

    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionkey = sessionkey;  //String
    data.sync = sync;  //Boolean
    data.agentid = global_AgentID;  //String
    data.lanid = global_LanID;  //String

    //init the method name
    let method = "GetEvent";

    // check if the login is with password then add password
    if (global_Password) {
        data.password = FromEncodedString(global_Password);
        method = "GetEventwithPassword";
    }

    // check if the login is with json then add json data
    if (global_LoginJsonData) {
        data.password = "";
        data.jsondata = global_LoginJsonData;
        method = "GetEventwithJson";
    }

    // set the event polling to true
    _startEventPolling = true;

    //if agent logged in then only call server else return the callback
    if (_isAgentLoggedIn) {
        tmac_command(callbackfunction, userobject, data, method);
    }
    else {
        tmac_GetEventDone(callbackfunction, null, null, null);
    }
}

function checkForSignalRServer() {
    try {
        console.log("checkForSignalRServer: SignalR connection to server for events");
        // define the query string
        let qs = {
            deviceId: global_DeviceID ? global_DeviceID : "",
            agentSessionKey: global_AgentSessionKey ? global_AgentSessionKey : ""
        };
        let conn = new SignalRConnector([global_TmacSignalRUrl], tmac_signalr_protocol, "TmacServer", qs, "TMACServerHub", true, 10000);
        //connect is exposed outside to that hub events should be defined before the connect
        if (conn) {
            srConn.push(conn);
            conn.hub.on('onRegistered', function () { });
            conn.hub.on('onTMACEvents', function (evt) {
                ProxySetConnectivityStatus(1, 'signalr', "onevent");
                // handle the events
                tmac_GetEventDone(null, {}, null, [evt]);
            });
            conn.onConnected = function (instance) {
                ProxySetConnectivityStatus(1, 'signalr', "onconnected");
                console.log("checkForSignalRServer: onConnected");
                // set the flag to false to retry after next down scenario
                _tryReconnecting = false;
            };
            conn.onDisconnected = function () {
                ProxySetConnectivityStatus(2, 'signalr', "ondisconnected");
                console.log("checkForSignalRServer: onDisconnected");
                // check that flag to get the tmac server
                if (!_tryReconnecting && !global_LogoutCommandSend) {
                    // set the flag to true so that it will not call on every disconnect
                    _tryReconnecting = true;
                    // connect to proxy and get the new tmac url
                    tmac_GetTMACServerOnSocketFail(function (result, obj) {
                        // handle the events
                        tmac_GetEventDone(null, {}, null, result);
                    }, null);
                }
            };
            conn.onReconnecting = function () {
                ProxySetConnectivityStatus(0, 'signalr', "onreconnecting");
                console.log("checkForSignalRServer: onReconnecting");
            };
            conn.onConnectionSlow = function () {
                ProxySetConnectivityStatus(0, 'signalr', "onconnectionslow");
                setTimeout(function () {
                    ProxySetConnectivityStatus(1, 'signalr', "onconnectionslow");
                }, 1000);
                console.log("checkForSignalRServer: onConnectionSlow");
            };
            conn.onReconnected = function () {
                ProxySetConnectivityStatus(1, 'signalr', "onreconnected");
                console.log("checkForSignalRServer: onReconnected");
            };
            conn.onReceived = function (obj) { };
            conn.onError = function (error) {
                ProxySetConnectivityStatus(2, 'signalr', "onerror");
                //TODO:: fallback to GetEvent loop if needed ?
            };
            conn.connect();
        }
    } catch (e) {
        //
    }
}

function tmac_GetEventDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (userobject) {
            userobject.pollEvents = _startEventPolling;
        }
        else {
            userobject = {
                pollEvents: _startEventPolling
            };
        }

        //process the events
        window["GetEventDone"](resultdata, userobject);

        //send the ACK for required events
        if (resultdata && resultdata.length > 0) {
            //loop the events and check ACK required
            resultdata.forEach(function (evt) {
                //if ACK required send the ACK
                if (evt.ACK && evt.ACK.IsRequired) {
                    console.log("tmac_GetEventDone: EventAcknowledgement required - " + evt.EventName + " - " + evt.ACK.Id);
                    sendACK({ channel: evt.ACK.Channel, id: evt.ACK.Id, source: evt.ACK.Source }, {});
                }
            });
        }
    }
    catch (e) {
        //
    }
}

function tmac_GetEventwithPasswordDone(callbackfunction, userobject, inputdata, resultdata) {
    tmac_GetEventDone(callbackfunction, userobject, inputdata, resultdata);
}

function tmac_GetEventwithJsonDone(callbackfunction, userobject, inputdata, resultdata) {
    tmac_GetEventDone(callbackfunction, userobject, inputdata, resultdata);
}

function sendACK(data, userObj) {
    //assign data for obj for retry
    userObj.data = data;
    //add a retry count property if not there
    if (!userObj._retryCount) {
        userObj._retryCount = 0;
    }
    tmac_EventAcknowledgement(function (result, object) {
        //check for response data
        if (result) {
            console.log("sendACK: EventAcknowledgement response received: " + result.ResultCode);
            //retry for failed case only
            if (result.ResultCode === 0) {
                //failed try again after 2s for max 3 retry 
                if (object._retryCount < 3) {
                    setTimeout(function (dt) {
                        console.warn("sendACK [" + object._retryCount + "]: Trying after 2s..");
                        //increment the retry if faild
                        dt._retryCount++;
                        //send the ack again
                        sendACK(dt.data, dt);
                    }, 2000, object);
                }
                else {
                    object._retryCount = 0;
                }
            }
        }
    }, userObj, data.channel, data.id, data.source);
}

function tmac_GetEventAsync(callbackfunction, userobject, deviceid, sessionkey, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionkey = sessionkey;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "GetEventAsync");
}

function tmac_GetEventAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetFavouriteSkills(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetFavouriteSkills");
}

function tmac_GetFavouriteSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetHashCode(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetHashCode");
}

function tmac_GetHashCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetJSSdk(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetJSSdk");
}

function tmac_GetJSSdkDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetLoggedInAgentList(callbackfunction, userobject, tmacServer) {
    var data = {};
    data.tmacServer = tmacServer;
    tmac_command(callbackfunction, userobject, data, "GetLoggedInAgentList");
}

function tmac_GetLoggedInAgentListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetLoggedInAgentList_SecondServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetLoggedInAgentList_SecondServer");
}

function tmac_GetLoggedInAgentList_SecondServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetMetaData(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetMetaData");
}

function tmac_GetMetaDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetQueueStatus(callbackfunction, userobject, deviceid, skillid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.skillid = skillid;  //String
    tmac_command(callbackfunction, userobject, data, "GetQueueStatus");
}

function tmac_GetQueueStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetQueueStatusForSkill(callbackfunction, userobject, vdn) {
    var data = {};
    data.vdn = vdn;  //String
    tmac_command(callbackfunction, userobject, data, "GetQueueStatusForSkill");
}

function tmac_GetQueueStatusForSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = WallboardSkillModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetSpeedDialNumber(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetSpeedDialNumber");
}

function tmac_GetSpeedDialNumberDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetSpeedDialNumberForAgent(callbackfunction, userobject, agentId) {
    var data = {};
    data.agentId = agentId;  //String
    tmac_command(callbackfunction, userobject, data, "GetSpeedDialNumberForAgent");
}

function tmac_GetSpeedDialNumberForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetTMACServerProfile(callbackfunction, userobject, lanId, stationid, agentid) {
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "GetTMACServerProfile");
}

function tmac_GetTMACServerProfileDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetTmacWallboardSkill(callbackfunction, userobject, skill) {
    var data = {};
    data.skill = skill;  //String
    tmac_command(callbackfunction, userobject, data, "GetTmacWallboardSkill");
}

function tmac_GetTmacWallboardSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = WallboardSkillModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetTmacWallboardSkills(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetTmacWallboardSkills");
}

function tmac_GetTmacWallboardSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetType(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetType");
}

function tmac_GetTypeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Type
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_HoldCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "HoldCall");
}

function tmac_HoldCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadAUXCodes(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "LoadAUXCodes");
}

function tmac_LoadAUXCodesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadAUXCodesForAgent(callbackfunction, userobject) {
    var data = {};
    data.agentid = global_AgentID;
    tmac_command(callbackfunction, userobject, data, "LoadAUXCodesForAgent");
}

function tmac_LoadAUXCodesForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadCallWorkCodes(callbackfunction, userobject, deviceid, teamid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.teamid = teamid;  //String
    tmac_command(callbackfunction, userobject, data, "LoadCallWorkCodes");
}

function tmac_LoadCallWorkCodesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadIntents(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "LoadIntents");
}

function tmac_LoadIntentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadInteractionHistoryOnDemand(callbackfunction, userobject, deviceid, interactionid, cif, nric, phonenumber) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.cif = cif;  //String
    data.nric = nric;  //String
    data.phonenumber = phonenumber;  //String
    tmac_command(callbackfunction, userobject, data, "LoadInteractionHistoryOnDemand");
}

function tmac_LoadInteractionHistoryOnDemandDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LoadMoreHistory(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "LoadMoreHistory");
}

function tmac_LoadMoreHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Login(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload) {
    //assign to the global variables
    global_LanID = lanId;
    global_DeviceID = stationId;
    global_AgentID = agentLoginId;
    global_Password = "";
    global_LoginJsonData = "";

    loginToServer(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload, "", "");
}

function tmac_LoginWithPassword(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload, password) {
    //assign to the global variables
    global_LanID = lanId;
    global_DeviceID = stationId;
    global_AgentID = agentLoginId;
    global_Password = password ? ToEncodedString(password) : "";
    global_LoginJsonData = "";

    loginToServer(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload, password, "");
}

function tmac_LoginWithJson(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload, password, jsonData) {
    //assign to the global variables
    global_LanID = lanId;
    global_DeviceID = stationId;
    global_AgentID = agentLoginId;
    global_Password = password ? ToEncodedString(password) : "";
    global_LoginJsonData = jsonData;

    loginToServer(callbackfunction, userobject, lanId, stationId, agentLoginId, sync, syncSessionKey, forceReload, password, jsonData);
}

function loginToServer(callbackfunction, userobject, lanId, stationid, agentloginid, sync, syncSessionKey, forceReload, password, jsonData) {
    try {
        jsonData = JSON.parse(jsonData);
        jsonData.source = "sdk";
        jsonData = JSON.stringify(jsonData);
    } catch (ex) {
        jsonData = JSON.stringify({
            source: "sdk"
        });
    }
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentloginid = agentloginid;  //String
    data.sync = sync;  //Boolean
    data.syncSessionKey = syncSessionKey;  //String
    data.forceReload = forceReload;  //Boolean
    data.jsonData = jsonData;  //String

    //add items to userobject for relogin reference
    if (userobject) {
        userobject._lanId = global_LanID;
        userobject._stationId = global_DeviceID;
        userobject._agentLoginId = global_AgentID;
        userobject._password = global_Password;
        userobject._jsonData = global_LoginJsonData;
    }
    else {
        userobject = {
            _lanId: global_LanID,
            _stationId: global_DeviceID,
            _agentLoginId: global_AgentID,
            _password: global_Password,
            _jsonData: global_LoginJsonData
        };
    }

    //init the method name
    let method = "Login";

    // check if password is provided
    if (password) {
        data.password = password; //String
        method = "LoginWithPassword";
    }

    tmac_command(callbackfunction, userobject, data, method);
}

function tmac_LoginDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (resultdata.ResultCode > 0) {
            //set _isAgentLoggedIn to true
            _isAgentLoggedIn = true;
            _tmacServer = resultdata.TmacServerName;
            global_TmacSignalRUrl = resultdata.TmacSignalRUrl ? resultdata.TmacSignalRUrl : "";
        }

        //close the signalr connection on this event
        if (resultdata.ResultCode === 1 || resultdata.ResultCode === 2 && window.tmacconnectprotocol === "signalr") {
            GetSRConnection("TmacProxy").close(true);
        }
    } catch (e) {
        //
    }

    try {
        //_tmacServer
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
        //
    }
}

function tmac_LoginWithPasswordDone(callbackfunction, userobject, inputdata, resultdata) {
    tmac_LoginDone(callbackfunction, userobject, inputdata, resultdata);
}

function tmac_LoginWithJsonDone(callbackfunction, userobject, inputdata, resultdata) {
    tmac_LoginDone(callbackfunction, userobject, inputdata, resultdata);
}


function tmac_Logout(callbackfunction, userobject, deviceid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Logout");
}

function tmac_LogoutDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (resultdata.ResultCode === 0) {
            //set _isAgentLoggedIn to false
            _isAgentLoggedIn = false;
        }

        //close the signalr connection on this event
        if (resultdata.ResultCode === 0 && window.tmacconnectprotocol === "signalr") {
            GetSRConnection("TmacProxy").close(true);
        }
    } catch (e) {
        //
    }

    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
        //
    }
}


function tmac_LogoutAsync(callbackfunction, userobject, deviceid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "LogoutAsync");
}

function tmac_LogoutAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_MakeCall(callbackfunction, userobject, deviceid, number, existingInteractionId) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.existingInteractionId = existingInteractionId;  //String
    tmac_command(callbackfunction, userobject, data, "MakeCall");
}

function tmac_MakeCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_MakeCallWithUUI(callbackfunction, userobject, number, uui) {
    var data = {
        deviceId: global_DeviceID,  //String
        number: number,  //String
        uui: uui  //String
    };
    tmac_command(callbackfunction, userobject, data, "MakeCallWithUUI");
}

function tmac_MakeCallWithUUIDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_Manage_RemoveAgentSession(callbackfunction, userobject, deviceid, agentid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Manage_RemoveAgentSession");
}

function tmac_Manage_RemoveAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_OpenIntent(callbackfunction, userobject, deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.intent = intent;  //String
    tmac_command(callbackfunction, userobject, data, "OpenIntent");
}

function tmac_OpenIntentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ReloadData(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ReloadData");
}

function tmac_ReloadDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ReLoadEmailTemplates(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ReLoadEmailTemplates");
}

function tmac_ReLoadEmailTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ReLoadInteractionHistory(callbackfunction, userobject, deviceid, interactionid, nric, phoneNumber, email) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.nric = nric;  //String
    data.phoneNumber = phoneNumber;  //String
    data.email = email;  //String
    tmac_command(callbackfunction, userobject, data, "ReLoadInteractionHistory");
}

function tmac_ReLoadInteractionHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ReloadTab(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ReloadTab");
}

function tmac_ReloadTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_RemoveAgentSession(callbackfunction, userobject, agent, device) {
    var data = {};
    data.agent = agent;  //String
    data.device = device;  //String
    tmac_command(callbackfunction, userobject, data, "RemoveAgentSession");
}

function tmac_RemoveAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_RemoveCallWorkCode(callbackfunction, userobject, deviceid, interactionid, code) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.code = code;  //String
    tmac_command(callbackfunction, userobject, data, "RemoveCallWorkCode");
}

function tmac_RemoveCallWorkCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_RestartMainVoiceProcess(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "RestartMainVoiceProcess");
}

function tmac_RestartMainVoiceProcessDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SelectTab(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "SelectTab");
}

function tmac_SelectTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SendAgentNotification(callbackfunction, userobject, deviceid, message, pop) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.message = message;  //String
    data.pop = pop;  //Boolean
    tmac_command(callbackfunction, userobject, data, "SendAgentNotification");
}

function tmac_SendAgentNotificationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SendCommandToVoiceProcess(callbackfunction, userobject, deviceid, command, jsonData) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.command = command;  //String
    data.jsonData = jsonData;  //String
    tmac_command(callbackfunction, userobject, data, "SendCommandToVoiceProcess");
}

function tmac_SendCommandToVoiceProcessDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SetCallWorkCode(callbackfunction, userobject, deviceid, interactionid, code) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.code = code;  //String
    tmac_command(callbackfunction, userobject, data, "SetCallWorkCode");
}

function tmac_SetCallWorkCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SetMaxEmailConversationsInMemory(callbackfunction, userobject, maxCount) {
    var data = {};
    data.maxCount = maxCount;  //Int32
    tmac_command(callbackfunction, userobject, data, "SetMaxEmailConversationsInMemory");
}

function tmac_SetMaxEmailConversationsInMemoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_Compose(callbackfunction, userobject, deviceid, number, fromnumber, sourceinteractionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.fromnumber = fromnumber;  //String
    data.sourceinteractionid = sourceinteractionid;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_Compose");
}

function tmac_SMS_ComposeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_GetAssignedAgent(callbackfunction, userobject, sessionid, from, to, message, autoRoute) {
    var data = {};
    data.sessionid = sessionid;  //String
    data.from = from;  //String
    data.to = to;  //String
    data.message = message;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "SMS_GetAssignedAgent");
}

function tmac_SMS_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_RouteToAgent(callbackfunction, userobject, sessionid, from, to, message, agentid) {
    var data = {};
    data.sessionid = sessionid;  //String
    data.from = from;  //String
    data.to = to;  //String
    data.message = message;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_RouteToAgent");
}

function tmac_SMS_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_SendMessage(callbackfunction, userobject, deviceid, interactionid, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_SendMessage");
}

function tmac_SMS_SendMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_StartEmailServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "StartEmailServer");
}

function tmac_StartEmailServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_StopEmailServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "StopEmailServer");
}

function tmac_StopEmailServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_test(callbackfunction, userobject, deviceid, number, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //Int32
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "test");
}

function tmac_testDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ToString(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ToString");
}

function tmac_ToStringDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_TransferCall(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "TransferCall");
}

function tmac_TransferCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_TransferCancel(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferCancel");
}

function tmac_TransferCancelDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_TransferComplete(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferComplete");
}

function tmac_TransferCompleteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_TransferToIVR(callbackfunction, userobject, deviceid, interactionid, type, languageid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.type = type;  //String
    data.languageid = languageid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferToIVR");
}

function tmac_TransferToIVRDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_UnHoldCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "UnHoldCall");
}

function tmac_UnHoldCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SendDTMF(callbackfunction, userobject, interactionId, dtmf) {
    var data = {
        deviceId: global_DeviceID,  //String
        interactionId: interactionId,  //String
        dtmf: dtmf  //String
    };
    tmac_command(callbackfunction, userobject, data, "SendDTMF");
}

function tmac_SendDTMFDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_UpdateAgentReminder(callbackfunction, userobject, deviceid, agentid, id, status, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.id = id;  //String
    data.status = status;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "UpdateAgentReminder");
}

function tmac_UpdateAgentReminderDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_UpdateIntent(callbackfunction, userobject, deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.intent = intent;  //String
    tmac_command(callbackfunction, userobject, data, "UpdateIntent");
}

function tmac_UpdateIntentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_UpdateInteractionHistory(callbackfunction, userobject, channel, session, nric, email, chat, clid, cif, text, direction, agent, grpId, subtype, updateServiceHisoty, serviceHisoryDescription, addIntentIfRequired, forceAddIntent, intentName, loadCCL) {
    var data = {};
    data.channel = channel;  //String
    data.session = session;  //String
    data.nric = nric;  //String
    data.email = email;  //String
    data.chat = chat;  //String
    data.clid = clid;  //String
    data.cif = cif;  //String
    data.text = text;  //String
    data.direction = direction;  //String
    data.agent = agent;  //String
    data.grpId = grpId;  //String
    data.subtype = subtype;  //String
    data.updateServiceHisoty = updateServiceHisoty;  //Boolean
    data.serviceHisoryDescription = serviceHisoryDescription;  //String
    data.addIntentIfRequired = addIntentIfRequired;  //Boolean
    data.forceAddIntent = forceAddIntent;  //Boolean
    data.intentName = intentName;  //String
    data.loadCCL = loadCCL;  //Boolean
    tmac_command(callbackfunction, userobject, data, "UpdateInteractionHistory");
}

function tmac_UpdateInteractionHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_WorkQueueUpdated(callbackfunction, userobject, queueServerID, channel, skill) {
    var data = {};
    data.queueServerID = queueServerID;  //String
    data.channel = channel;  //String
    data.skill = skill;  //String
    tmac_command(callbackfunction, userobject, data, "WorkQueueUpdated");
}

function tmac_WorkQueueUpdatedDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetTMACVersion(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetTMACVersion");
}

function tmac_GetTMACVersionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_GetClientConnectionData(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetClientConnectionData");
}

function tmac_GetClientConnectionDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetLanID(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetLanID");
}

function tmac_GetLanIDDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetCrmUrl(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetCrmUrl");
}

function tmac_GetCrmUrlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        //window[callbackfunction](resultdata, userobject);

        if (resultdata != "") {
            window.cutomer_data_window_url = resultdata;
        }
    }
    catch (e) {
    }
}


function tmac_SetCrmUrl(callbackfunction, userobject, url) {
    var data = {};
    data.url = url;
    tmac_command(callbackfunction, userobject, data, "SetCrmUrl");
}

function tmac_SetCrmUrlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        //window[callbackfunction](resultdata, userobject);

        if (resultdata != "") {
            window.cutomer_data_window_url = resultdata;
            //alertMessageDialog("CRM URL set to:" + resultdata, "success");
            return;
        }
    }
    catch (e) {
    }

    //alertMessageDialog("CRM URL set failed.", "error");
}


function tmac_TransferBlind(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "TransferBlind");
}

function tmac_TransferBlindDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ConferenceBlind(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceBlind");
}

function tmac_ConferenceBlindDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_ChangeNumber(callbackfunction, userobject, deviceid, interactionid, newNumber) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.newNumber = newNumber;  //String
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_ChangeNumber");
}

function tmac_SmsSurvey_ChangeNumberDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_SupressSurvey(callbackfunction, userobject, deviceid, interactionid, supress, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.supress = supress;  //bool
    data.comment = comment;  //bool
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SupressSurvey");
}

function tmac_SmsSurvey_SupressSurveyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_SendManualSurvey(callbackfunction, userobject, deviceid, interactionid, templateID) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.templateID = templateID;  //int
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SendManualSurvey");
}

function tmac_SmsSurvey_SendManualSurveyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_SetSMSSurveySubscriptionStatus(callbackfunction, userobject, deviceid, mobileNo, stat, reason) {
    var data = {};
    data.deviceid = deviceid; //String
    //data.interactionid = interactionid; //String
    data.mobileNo = mobileNo; //String
    data.stat = stat; //Bool
    data.reason = reason; //String

    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SetSMSSurveySubscriptionStatus");
}

function tmac_SmsSurvey_SetSMSSurveySubscriptionStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_GetSMSSurveySubscriptionStatus(callbackfunction, userobject, mobileNo) {
    var data = {};
    data.mobileNo = mobileNo; //String

    tmac_command(callbackfunction, userobject, data, "SmsSurvey_GetSMSSurveySubscriptionStatus");
}

function tmac_SmsSurvey_GetSMSSurveySubscriptionStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = bool
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_GetSMSTemplateGroups(callbackfunction, userobject, deptId) {
    var data = {};
    data.deptId = deptId; //String

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplateGroups");
}

function tmac_SMS_GetSMSTemplateGroupsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_GetSMSTemplateDepartments(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplateDepartments");
}

function tmac_SMS_GetSMSTemplateDepartmentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_GetSMSTemplates(callbackfunction, userobject, groupID) {
    var data = {};
    data.groupID = groupID;//string

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplates");
}

function tmac_SMS_GetSMSTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplate> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Voice_SendMessage(callbackfunction, userobject, deviceid, interactionid, mobile, message) {
    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string
    data.mobile = mobile; //string
    data.message = message; //string

    tmac_command(callbackfunction, userobject, data, "Voice_SendMessage");
}

function tmac_Voice_SendMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_RecoverInteractions(callbackfunction, userobject, agentid, jsonData) {
    var data = {};
    data.agentid = agentid; //string
    data.jsonData = jsonData; //string

    tmac_command(callbackfunction, userobject, data, "RecoverInteractions");
}

function tmac_RecoverInteractionsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Voice_Conference_Mute(callbackfunction, userobject, deviceid, interactionid, muteStation, fromStation, mute) {

    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string
    data.muteStation = muteStation; //string
    data.fromStation = fromStation; //string
    data.mute = mute; //bool


    tmac_command(callbackfunction, userobject, data, "Voice_Conference_Mute");
}

function tmac_Voice_Conference_MuteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Voice_Get_ConferenceParties(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string

    tmac_command(callbackfunction, userobject, data, "Voice_Get_ConferenceParties");
}

function tmac_Voice_Get_ConferencePartiesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<string>
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {
    }
}


function tmac_SendCommandToAgent(callbackfunction, userobject, fromIntId, toAgentId, toTmacServer, toIntId, name, message) {
    let data = {};
    data.fromAgentId = global_AgentID;
    data.fromTmacServer = _tmacServer;
    data.fromInteractionID = fromIntId;
    data.toAgentId = toAgentId;
    data.toTmacServer = toTmacServer;
    data.toInteractionID = toIntId;
    data.name = name;
    data.message = message;
    tmac_command(callbackfunction, userobject, data, "SendCommandToAgent");
}

function tmac_SendCommandToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SendIMToAgent(callbackfunction, userobject, agentid, message) {
    var data = {};

    data.agentid = global_AgentID;
    data.toagent = agentid;
    data.message = message; //string
    data.popup = false;
    tmac_command(callbackfunction, userobject, data, "SendIMToAgent");
}

function tmac_SendIMToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SendIM(callbackfunction, userobject, toagent, tointeraction, totmacserver, message) {
    var data = {};
    data.fromagentid = global_AgentID;
    data.fromagentname = global_AgentName;
    data.toagent = toagent;
    data.tointeraction = tointeraction;
    data.totmacserver = totmacserver;
    data.message = message; //string
    data.popup = false;
    tmac_command(callbackfunction, userobject, data, "SendIM");
}

function tmac_SendIMDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_CreateDummyVoiceInteraction(callbackfunction, userobject) {
    var data = {};

    data.deviceid = global_DeviceID;

    tmac_command(callbackfunction, userobject, data, "CreateDummyVoiceInteraction");
}

function tmac_CreateDummyVoiceInteractionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentListForAgent(callbackfunction, userobject) {
    var data = {};
    data.agentid = global_AgentID;
    tmac_command(callbackfunction, userobject, data, "GetAgentListForAgent");
}

function tmac_GetAgentListForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Interaction_SaveComment(callbackfunction, userobject, interactionid, comment) {
    var data = {};

    data.deviceid = global_DeviceID;
    data.interactionid = interactionid;
    data.comment = comment; //string

    tmac_command(callbackfunction, userobject, data, "Interaction_SaveComment");
}

function tmac_Interaction_SaveCommentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentStatusFull(callbackfunction, userobject, agentid) {
    var data = {};
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "GetAgentStatusFull");
}

function tmac_GetAgentStatusFullDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = AgentModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_LogoutWithReason(callbackfunction, userobject, deviceid, reason) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.reason = reason;  //String

    tmac_command(callbackfunction, userobject, data, "LogoutWithReason");
}

function tmac_LogoutWithReasonDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentSessionsList(callbackfunction, userobject, teamid, supervisorid, agentid, interactionid, tmacServer) {
    var data = {};
    data.teamId = teamid;  //String
    data.supervisorId = supervisorid;  //String
    data.agentid = agentid;  //String
    data.interactionid = interactionid;  //String
    data.tmacServer = tmacServer;  //String  

    tmac_command(callbackfunction, userobject, data, "GetAgentSessionsList");
}

function tmac_GetAgentSessionsListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}


function tmac_InitiateCall(callbackfunction, userobject, deviceid, number, existingInteractionId, source, sourceid, tmacServer) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.existingInteractionId = existingInteractionId;  //String
    data.source = source;  //String
    data.sourceid = sourceid;  //String
    data.tmacServer = tmacServer;  //String
    tmac_command(callbackfunction, userobject, data, "InitiateCall");
}

function tmac_InitiateCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_AddEventToAgentSession(callbackfunction, userobject, agentid, ev, isPriority, agentTmacServer) {
    var data = {};
    data.agentid = agentid; //String
    data.ev = JSON.stringify(ev); //IUIEvent    
    data.isPriority = isPriority; //String    
    data.agentTmacServer = agentTmacServer; //String    

    tmac_command(callbackfunction, userobject, data, "AddEventToAgentSession");
}

function tmac_AddEventToAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetWorkItems(callbackfunction, userobject, channel, skills) {
    var data = {};
    data.channel = channel; //String
    data.skills = skills; //list    
    tmac_command(callbackfunction, userobject, data, "GetWorkItems");
}

function tmac_GetWorkItemsDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_PullQueueItem(callbackfunction, userobject, channel, itemid) {
    var data = {};
    data.deviceid = global_DeviceID; //String
    data.channel = channel; //String
    data.itemid = itemid; //list    
    tmac_command(callbackfunction, userobject, data, "PullQueueItem");
}

function tmac_PullQueueItemDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_StartTextChatFromAgent(callbackfunction, userobject, custId, agentId, salute, name, phone, email) {
    var data = {};
    data.custId = custId;
    data.agentid = agentId;
    data.salute = salute;
    data.name = name;
    data.phone = phone;
    data.email = email;
    tmac_command(callbackfunction, userobject, data, "StartTextChatFromAgent");
}

function tmac_StartTextChatFromAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SaveVideoData(callbackfunction, userobject, sessionid, intid, agentid, base64) {
    try {
        var data = {};
        data.sessionid = sessionid; //String
        data.intid = intid; //String    
        data.agentid = agentid; //String    
        data.base64 = base64; //String    
        tmac_command(callbackfunction, userobject, data, "SaveVideoData");
    } catch (e) {

    }
}


function tmac_GetQueueTimeColorCode(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetQueueTimeColorCode");
}

function tmac_GetQueueTimeColorCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    window[callbackfunction](resultdata, userobject);
}


function tmac_SendGenericCTICommand(callbackfunction, command, userobject, jsondata) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.command = command;
    data.jsonData = JSON.stringify(jsondata);

    tmac_command(callbackfunction, userobject, data, "SendGenericCTICommand");
}

function tmac_SendGenericCTICommandDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_GetMiniDashboard(callbackfunction, userobject, interval, channel) {
    let data = {};
    data.agentId = global_AgentID;
    data.interval = interval;
    data.channel = channel;
    tmac_command(callbackfunction, userobject, data, "GetMiniDashboard");
}

function tmac_GetMiniDashboardDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_GetVipData(callbackfunction, userobject, callerId, idType, idNo) {
    let data = {};
    data.callerId = callerId;
    data.idtype = idType;
    data.idno = idNo;
    tmac_command(callbackfunction, userobject, data, "GetVipData");
}

function tmac_GetVipDataDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_SaveVideoSnap(callbackfunction, userobject, sessionid, intid, nric, name, phone, email, base64, clid, cif, subChannel, groupId) {
    var data = {};
    data.sessionid = sessionid; //String
    data.intid = intid; //String    
    data.agentid = global_AgentID; //String    
    data.nric = nric; //String    
    data.name = name; //String    
    data.phone = phone; //String    
    data.email = email; //String    
    data.base64 = base64; //String    
    data.clid = clid; //String    
    data.cif = cif; //String    
    data.subChannel = subChannel; //String    
    data.groupId = groupId; //String    
    data.tmacServer = _tmacServer; //String    

    tmac_command(callbackfunction, userobject, data, "SaveVideoSnapWithCustInfo");
}

function tmac_SaveVideoSnapWithCustInfoDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        window[callbackfunction](resultdata, userobject, inputdata);
    }
    catch (e) { }
}


function tmac_LogClientLogsDone(callbackfunction, userobject, inputdata, resultdata) {
    //
}


function tmac_GetInteractionHistory(callbackfunction, userobject, cif, email, nric, phone, noOfRecords, lastId) {
    try {
        var data = {};
        data.cif = cif;
        data.email = email;
        data.nric = nric;
        data.phone = phone;
        data.noOfRecords = noOfRecords;
        data.lastID = lastId;

        tmac_command(callbackfunction, userobject, data, "GetInteractionHistory");
    } catch (e) { }
}

function tmac_GetInteractionHistoryDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject, inputdata);
        }
    }
    catch (e) { }
}


function tmac_UpdateTextInteractionData(callbackfunction, userobject, interactionid, custInfoJson) {
    try {
        var data = {};
        data.deviceid = global_DeviceID;
        data.interactionid = interactionid;
        data.custInfoJson = custInfoJson;

        tmac_command(callbackfunction, userobject, data, "UpdateTextInteractionData");
    } catch (e) { }
}

function tmac_UpdateTextInteractionDataDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        window[callbackfunction](resultdata, userobject, inputdata);
    }
    catch (e) { }
}


function tmac_GetTmacServerId(callbackfunction, userobject, lanid, agentid, deviceid) {
    try {
        var data = {};
        data.lanid = lanid;
        data.agentid = agentid;
        data.deviceid = deviceid;

        tmac_command(callbackfunction, userobject, data, "GetTmacServerId");
    } catch (e) { }
}

function tmac_GetTmacServerIdDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        if (typeof callbackfunction == "function")
            callbackfunction(resultdata, userobject, inputdata);
        else
            window[callbackfunction](resultdata, userobject, inputdata);
    }
    catch (e) { }
}


function tmac_SendInteractionTransferNotificationToServer(callbackfunction, userobject, channel, interactionid, toAgentId, toTmacServer, comment, otherData) {
    var data = {};
    data.channel = channel;  //String
    data.fromTmacServer = _tmacServer;  //String
    data.fromAgentId = global_AgentID;  //String
    data.fromAgentName = global_AgentName;  //String
    data.fromInteraction = interactionid;  //String
    data.toAgentId = toAgentId;  //String
    data.toTmacServer = toTmacServer;  //String
    data.comment = comment;  //String
    data.otherData = otherData;  //String

    tmac_command(callbackfunction, userobject, data, "SendInteractionTransferNotificationToServer");
}

function tmac_SendInteractionTransferNotificationToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_SendInteractionNotificationResponseToServer(callbackfunction, userobject, eventData, comment, response) {
    var data = {};
    data.channel = eventData.Channel;  //String
    data.fromTmacServer = _tmacServer;  //String
    data.fromAgentId = global_AgentID;  //String
    data.fromAgentName = global_AgentName;  //String
    data.toInteractionId = eventData.FromInteractionID;  //String
    data.toAgentId = eventData.FromAgentID;  //String
    data.toTmacServer = eventData.FromTmacServer;  //String
    data.comment = comment; //String
    data.response = response; //String
    data.otherData = eventData.OtherData;  //String

    tmac_command(callbackfunction, userobject, data, "SendInteractionNotificationResponseToServer");
}

function tmac_SendInteractionNotificationResponseToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_InteractionTransferToServer(callbackfunction, userobject, eventData) {

    var data = {};
    data.channel = eventData.Channel;  //String
    data.sourceDeviceId = global_DeviceID;  //String
    data.fromAgentId = global_AgentID;  //String
    data.interactionId = eventData.InteractionID;  //String
    data.toAgentId = eventData.FromAgentID;  //String
    data.toTmacServer = eventData.FromAgentTmacServer;  //String
    data.otherData = eventData.OtherData;  //String

    tmac_command(callbackfunction, userobject, data, "InteractionTransferToServer");
}

function tmac_InteractionTransferToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_TransferInteractionToQueue(callbackfunction, userobject, channel, interactionid, skillNumber, otherData) {

    var data = {};
    data.channel = channel;  //String
    data.deviceId = global_DeviceID;  //String
    data.interactionId = interactionid;  //String
    data.skillNumber = skillNumber;  //String
    data.otherData = otherData;  //String

    tmac_command(callbackfunction, userobject, data, "TransferInteractionToQueue");
}

function tmac_TransferInteractionToQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}

function tmac_ConvertInteraction(callbackfunction, userobject, interactionId, channel, skillNumber, otherData) {

    var data = {};
    data.channel = channel;  //String
    data.deviceId = global_DeviceID;  //String
    data.interactionId = interactionId;  //String
    data.skillNumber = skillNumber;  //String
    data.otherData = otherData;  //String

    tmac_command(callbackfunction, userobject, data, "ConvertInteraction");
}

function tmac_ConvertInteractionDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject, inputdata);
    } catch (e) {

    }
}

function tmac_CancelInteractionTransferNotification(callbackfunction, userobject, channel, interactionid, toAgentId, toTmacServer, comment) {
    var data = {};
    data.channel = channel;  //String
    data.fromAgentId = global_AgentID;  //String
    data.fromInteraction = interactionid;  //String
    data.toAgentId = toAgentId;  //String
    data.toTmacServer = toTmacServer;  //String
    data.comment = comment;  //String

    tmac_command(callbackfunction, userobject, data, "CancelInteractionTransferNotification");
}

function tmac_CancelInteractionTransferNotificationDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_RemoveFile(callbackfunction, userobject, filePath) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.agentId = global_AgentID;
    data.filePath = filePath;

    tmac_command(callbackfunction, userobject, data, "RemoveFile");
}

function tmac_RemoveFileDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {

    }
}


function tmac_GetDashboardColorCodes(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetDashboardColorCodes");
}

function tmac_GetDashboardColorCodesDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) { }
}


function tmac_GetInteractionHistoryCountByServer(callbackfunction, userobject, cif, email, nric, phone, instance) {
    var data = {};
    data.cif = cif;
    data.email = email;
    data.nric = nric;
    data.phone = phone;
    data.instance = instance;

    tmac_command(callbackfunction, userobject, data, "GetInteractionHistoryCountByServer");
}

function tmac_GetInteractionHistoryCountByServerDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
        //
    }
}


function tmac_GetInteractionHistoryByServer(callbackfunction, userobject, cif, email, nric, phone, noOfRecords, lastId, instance) {
    var data = {};
    data.cif = cif;
    data.email = email;
    data.nric = nric;
    data.phone = phone;
    data.noOfRecords = noOfRecords;
    data.lastID = lastId;
    data.instance = instance;

    tmac_command(callbackfunction, userobject, data, "GetInteractionHistoryByServer");
}

function tmac_GetInteractionHistoryByServerDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
        //
    }
}


function tmac_GetTMACServerOnSocketFail(callbackfunction, userobject) {
    var data = {
        deviceId: global_DeviceID,
        agentId: global_AgentID,
        lanId: global_LanID,
        password: FromEncodedString(global_Password),
        jsonData: global_LoginJsonData
    };

    tmac_command(callbackfunction, userobject, data, "GetTMACServerOnSocketFail");
}

function tmac_GetTMACServerOnSocketFailDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
        //
    }
}


function tmac_SaveAgentSnapshot(callbackfunction, userobject, snapshotData, screenshotData) {
    let inputdata = {
        snapshotData: snapshotData,
        screenshotData: screenshotData,
        agentId: global_AgentID
    };
    tmac_command(callbackfunction, userobject, inputdata, "SaveAgentSnapshot");
}

function tmac_SaveAgentSnapshotDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) { }
}


function tmac_EventAcknowledgement(callbackfunction, userobject, channel, itemId, source) {
    var data = {
        agentId: global_AgentID,
        channel: channel,
        itemId: itemId,
        source: source
    };

    tmac_command(callbackfunction, userobject, data, "EventAcknowledgement");
}

function tmac_EventAcknowledgementDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) { }
}


function tmac_SendAgentAVMessage(callbackfunction, userobject, toAgent, toTmacServer, type, message, jsonData) {
    var data = {};
    data.fromAgentId = global_AgentID;
    data.fromAgentName = global_AgentName;
    data.toAgent = toAgent;
    data.toTmacServer = toTmacServer;
    data.type = type;
    data.message = message;
    data.jsonData = jsonData;

    tmac_command(callbackfunction, userobject, data, "SendAgentAVMessage");
}

function tmac_SendAgentAVMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) { }
}


function tmac_UpdateMosDetails(callbackfunction, userobject, interactionId, mosDetails) {
    var data = {};
    data.agentId = global_AgentID;
    data.interactionId = interactionId;
    data.mosDetails = mosDetails;

    tmac_command(callbackfunction, userobject, data, "UpdateMosDetails");
}

function tmac_UpdateMosDetailsDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) { }
}


function tmac_RestRequest(callbackfunction, userobject, sessionId, searialisedData, url, method) {
    var data = {};
    data.sessionId = sessionId;
    data.searialisedData = searialisedData;
    data.url = url;
    data.method = method;

    tmac_command(callbackfunction, userobject, data, "RestRequest");
}

function tmac_RestRequestDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) { }
}


function tmac_SendAVControlMessage(callbackfunction, userobject, deviceid, interactionid, message, type) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.type = type;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "SendAVControlMessage");
}

function tmac_SendAVControlMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendActionMessage(callbackfunction, userobject, deviceid, interactionid, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "SendActionMessage");
}

function tmac_SendActionMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) { }
}


function tcis_InsertViolation(callbackfunction, userobject, eventname, agentid, campic, screenshot, screenvideo, agentstate, summary) {
    var violation = {};
    violation.EventName = eventname;
    violation.AgentId = agentid;
    violation.CamPicURL = campic;
    violation.ScreenShotURL = screenshot;
    violation.ScreenVideo = screenvideo;
    violation.AgentStatus = agentstate;
    violation.QRVideoURL = "";
    violation.ActionSummary = summary;
    violation.Threshold = 0;

    var data = {};
    data.violation = violation;
    tmac_command(callbackfunction, userobject, data, "TCIS_InsertViolation");
}

function tcis_InsertViolationDone(callbackfunction, resultdata, userobject, inputdata) {
    //resultdata = Int32
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject, inputdata)
        } else if (typeof window[callbackfunction] === "function") {
            window[callbackfunction](resultdata, userobject);
        }
    }
    catch (e) {
    }
}

function tmac_StoreWebRTCCommStats(stats,  callback, userObj) {
    try {
        var inputData = {};
        inputData.stats = stats;
        tmac_command(callback, userObj, inputData, "StoreWebRTCCommStats");
    } catch (ex) {

    }
}

function tmac_StoreWebRTCCommStatsDone(callback, resultData, userObject, inputData) {
    try {
        if (typeof callback === "function") {
            callback(resultData, userObject, inputData)
        } else if (typeof window[callback] === "function") {
            window[callback](resultData, userObject, inputData);
        }
    } catch (ex) {

    }
}