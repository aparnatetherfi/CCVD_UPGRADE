﻿//Tetherfi Multimedia Agent Client 
//JavaScript SDK
//Author - Mohammed Sirajuddin

var version_tmac_fax_sdk = "4.0.11.12";

try {
    AddSDKVersion("tmac_faxApi", version_tmac_fax_sdk);
} catch (e) {
    //
}

function tmac_GetFaxAddressBook(callbackfunction, userobject, faxLine) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.faxLine = faxLine;

    tmac_command(callbackfunction, userobject, data, "GetFaxAddressBook");
}

function tmac_GetFaxAddressBookDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_GetFaxRecipients(callbackfunction, userobject, addressBookId) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.adddressBookId = addressBookId;

    tmac_command(callbackfunction, userobject, data, "GetFaxRecipients");
}

function tmac_GetFaxRecipientsDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_GetFaxLineNumbers(callbackfunction, userobject) {
    let data = {};
    data.deviceId = global_DeviceID;
    tmac_command(callbackfunction, userobject, data, "GetFaxLineNumbers");
}

function tmac_GetFaxLineNumbersDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_GetFaxTemplateNames(callbackfunction, userobject) {
    let data = {};
    data.deviceId = global_DeviceID;
    tmac_command(callbackfunction, userobject, data, "GetFaxTemplateNames");
}

function tmac_GetFaxTemplateNamesDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_GetFaxTemplate(callbackfunction, userobject, name, type) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.name = name;
    data.type = type;
    tmac_command(callbackfunction, userobject, data, "GetFaxTemplate");
}

function tmac_GetFaxTemplateDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_SendFax(callbackfunction, userobject, interactionid, file, faxnumber, dnis, filename, type) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.interactionId = interactionid;
    data.file = file;
    data.faxNumber = faxnumber;
    data.DNIS = dnis;
    data.fileName = filename;
    data.type = type;
    tmac_command(callbackfunction, userobject, data, "SendFax");
}

function tmac_SendFaxDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_SendMultipleFaxItem(callbackfunction, userobject, interactionid, faxnumber, dnis, selectedItems) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.interactionId = interactionid;
    data.faxNumber = faxnumber;
    data.DNIS = dnis;
    data.selectedItems = selectedItems;
    tmac_command(callbackfunction, userobject, data, "SendMultipleFaxItem");
}

function tmac_SendMultipleFaxItemDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_DownloadFaxFile(callbackfunction, userobject, path, jobId, selectedItems) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.agentId = global_AgentID;
    data.path = path;
    data.jobId = jobId;
    tmac_command(callbackfunction, userobject, data, "DownloadFaxFile");
}

function tmac_DownloadFaxFileDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_ResendFax(callbackfunction, userobject, jobId, selectedItems) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.jobId = jobId;
    tmac_command(callbackfunction, userobject, data, "ResendFax");
}

function tmac_ResendFaxDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}


function tmac_UpdateFaxStatus(callbackfunction, userobject, interactionid, message) {
    try {
        let data = {};
        data.deviceId = global_DeviceID;
        data.interactionId = interactionid;
        data.message = message;
        tmac_command(callbackfunction, userobject, data, "UpdateFaxStatus");
    } catch (e) {

    }
}

function tmac_UpdateFaxStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        if (typeof callbackfunction === "function") {
            callbackfunction(resultdata, userobject);
        }
        else {
            window[callbackfunction](resultdata, userobject);
        }
    } catch (e) {
        //
    }
}

