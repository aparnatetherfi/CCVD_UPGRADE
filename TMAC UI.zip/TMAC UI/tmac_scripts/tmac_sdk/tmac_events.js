﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//TMAC events (common events and voice events)
//Author - Weerathungage Sumudu Saman
//Last updated date - 20/03/2019

var version_tmac_events_sdk = "4.1.2.15";

var tmac_events_interaction_recovery_data = [];

try {
    AddSDKVersion("tmac_events", version_tmac_events_sdk);
} catch (e) {
    //
}

function SaveRecoveryData(event) {
    try {
        //tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;

        if (tmac_events_interaction_recovery_data.filter(function (r) { return r.InteractionId === event.InteractionID; }).length === 0) {
            tmac_events_interaction_recovery_data.push(event.RecoveryData);
        }
        else {
            console.log("tmac_events: '" + event.InteractionID + "' is already added to 'tmac_events_interaction_recovery_data'");
        }
    } catch (e) {
        //
    }
}

function RemoveRecoveryData(event) {
    try {
        tmac_events_interaction_recovery_data = tmac_events_interaction_recovery_data.filter(function (r) { return r.InteractionId !== event.InteractionID; });
    } catch (e) {
        //
    }
}

function AgentNotificaitonEvent(event) {
    /* 
    string Type  - IM, Boradcast, Info
    string JsonData   - if Type=Info and  Message = LoadInteractionHistory then JsonData = HistoryLoaderParametersModel
    string FromAgentId  - Type=IM, from agent login id
    string FromAgentName  - Type=IM, from agent name
    string Message  - when Type = Info and Message = LoadInteractionHistory
    bool Broadcast  - is this a broadcast message or not
    bool Pop  - should this message popup or not at UI
    */

    tmacevent_AgentNotificaitonEvent(event);
}

function AgentStatusChangeEvent(event) {
    //string Status  - status of the agent
    if (event.Status === "not logged in") {
        //set _isAgentLoggedIn to false
        _isAgentLoggedIn = false;
    }
    global_CurrentStatus = event.Status;
    tmacevent_AgentStatusChangeEvent(event);
}

function AUXTimerEvent(event) {
    // string Type - TPIN

    tmacevent_AUXTimerEvent(event);
}

function CallConferenceCompletedEvent(event) {
    // string ConferenceType - consult, blind
    tmacevent_CallConferenceCompletedEvent(event);
}

function CallConferenceInitiatedEvent(event) {
    // string ConferenceType - consult, blind

    tmacevent_CallConferenceInitiatedEvent(event);
}

function CallConferenceLineDisconnectEvent(event) {
    // string ConferenceType - consult, blind   
    // bool IsMainLine - is this main line disconnect (customer line)

    tmacevent_CallConferenceLineDisconnectEvent(event);
}

function CallConferenceRemoteConnectedEvent(event) {
    // string ConferenceType - consult, blind    

    tmacevent_CallConferenceRemoteConnectedEvent(event);
}

function CallConnectedEvent(event) {
    tmacevent_CallConnectedEvent(event);
}

function CallDisconnectedEvent(event) {
    tmacevent_CallDisconnectedEvent(event);
}

function CallHoldEvent(event) {
    tmacevent_CallHoldEvent(event);
}

function CallHoldReconnectEvent(event) {
    tmacevent_CallHoldReconnectEvent(event);
}

function CallTransferInitiatedEvent(event) {
    tmacevent_CallTransferInitiatedEvent(event);
}

function AESStatusEvent(event) {
    //string Status - Failed, Reconnected

    tmacevent_AESStatusEvent(event);
}

function CallTransferLineDisconnectEvent(event) {
    // bool IsMainLine - is this main line disconnect (customer line)

    tmacevent_CallTransferLineDisconnectEvent(event);
}

function CallTransferRemoteConnectedEvent(event) {
    tmacevent_CallTransferRemoteConnectedEvent(event);
}

function CCLDataEvent(event) {

    /*string Email - customer email address 
    string RegisteredPhone - registered phone
    string CallerName - customer name
    string CIF - customer CIF
    string NRIC - CustomerIdentifier NRIC
    string Note - note about customer*/

    tmacevent_CCLDataEvent(event);
}

function IncomingCallEvent(event) {
    /*
    string PhoneNumber - caller number
    string UCID - call UCID
    string CalledDevice  - called device (VDN)
    string CallType  - call type (1 = acd,2 = extension)
    string UUI  - call UUI
    string VDNName - VDN name
    bool IsAgentTransferedCall - is this a transfered call
    bool IsAgentConferencedCall - is this a conferenced call
    string SourceAgentID - source agent id for transfered and conferenced calls
    string SourceAgentName - source agent name for transfered and conferenced calls
    string SourceTransferComment  - source agent comment for transfered and conferenced calls
    string Queue -  call queue extension number
    string QueueName - call queue name
    string SourceAgentInteractionId - source agent interaction id for transfered and conferenced calls
    InteractionRecoveryDataModel RecoveryData - interaction data used for reccovery*/

    /*InteractionRecoveryDataModel
    {
        int InteractionId 
        string InteractionType  
        string ConnectionHandle  
        string UUI  
        string PhoneNumber  
        string CallType 
        string CalledDevice  
    }*/


    //save recovery data
    SaveRecoveryData(event);

    tmacevent_IncomingCallEvent(event);
}

function IncomingCallUpdateEvent(event) {
    //same as   IncomingCallEvent 
}

function InteractionHistoryEvent(event) {
    tmacevent_InteractionHistoryEvent(event);
}

function MoreInteractionHistoryEvent(event) {

    // List<HistoryInteraction> History  - list of history items

    /*HistoryInteraction
    {
          string ID  - group max auto increment id
          int ItemID  - item auto increment ID
          string GroupID - group session id
          string Channel - channel (Voice, SMS, Chat, Email...)
          string Direction  - Direction of item (In,Out)
          string InteractionDate  - formatted interaction datetime (yyyy/mm/dd HH:mm:ss)
          string InteractionText - interaction text
          string LastServicedAgentName  - last serviced agent name
          string SessionID  - session id for this item
          string Intent - intent of this item
          string IntentStatus  - intent status (Open, Close)
          string AgentID  - Agent ID 
          string AgentName  - Agent name
          string GroupHeaderText  - formatted group headr text
          string DisplayText - formatted display text
          string CIF  - CIF for this item
          string EmailID  - email id for this item
          string PhoneNumber  - phone number for this item
          string ChannelSpecificIdentifier  - channel specific identifier (voice=phone, email=emailid...)

    }*/

    tmacevent_MoreInteractionHistoryEvent(event);
}

function InteractionHistoryOnDemandEvent(event) {
    // List<HistoryInteraction> History  - list of history items    
    tmacevent_InteractionHistoryOnDemandEvent(event);
}

function IVRDataEvent(event) {

    /*
    string LastMenu - last menu details from IVR (data tables)
    string LastMenu_2 - last menu details from IVR (data tables)
    string LastMenu_3 - last menu details from IVR (data tables)
    string LastMenu_4 -  last menu details from IVR (data tables)
    string DNIS - DNIS details from IVR (data tables)
    string QueueTime - calculated queue time
    string UUI - UUI data from IVR call tables or UUI from call event data
    string CustomData - //2016-09-30 custom data (for customer specific ivr data)
      */

    tmacevent_IVRDataEvent(event);
}

function OutgoingCallEvent(event) {

    // string PhoneNumber - phone number
    // bool IsExistingInteraction - this propert is used to inform the UI that this is a out voice event from and exising tab. Ui dont have to create a new tab.
    //InteractionRecoveryDataModel RecoveryData - interaction data used for reccovery

    /*InteractionRecoveryDataModel
    {
        int InteractionId 
        string InteractionType  
        string ConnectionHandle  
        string UUI  
        string PhoneNumber  
        string CallType 
        string CalledDevice  
    }*/


    //save recovery data
    SaveRecoveryData(event);

    tmacevent_OutgoingCallEvent(event);
}

function UUIDataEvent(event) {

    /*
    string CallerName - caller name in UUI
    AuthTypeModel AuthType - Authentication type in UUI
    string CIF - CIF in UUI
    string Language - language in UUI
    string NRIC  - NRIC in UUI
    string Segment  - Segment in  UUI
    string OtherData - Other data in UUI*/

    /*
    AuthTypeModel
    {
          string AuthCode - signle digit auth code (A,B,C...)
          bool IsIdentified- is this identified call
          bool IsVerified - is this a verified call
          string VerificationType - verification type (TPIN + PhoneCode...)
          bool IsTPINVerified - is this call TPIN verified
          string SiebelPIN -  SeibelPIN variable (Y,N)
          string SiebelTPIN - SeibelTPIN variable (Y,N)
    }*/

    tmacevent_UUIDataEvent(event);
}

function WallboardRefreshEvent(event) {
    //List<WallboardSkillModel> Skills - lisf of skills

    /*WallboardSkillModel
    {
          string SkillName - skill name
          string SkillID - skill id
          int AgentAvailable - available agent count
          int AgentsStaffed - staffed agent count
          int CallsInQueue - calls in queue
        
    }*/
    global_AgentSkills = event.Skills;
    tmacevent_WallboardRefreshEvent(event);
}

function CallerIntentEvent(event) {
    /*string IntentName - intent name
    string IntentStatus - intent status (Open,Close)*/
    tmacevent_CallerIntentEvent(event);
}

function ScreenPopEvent(event) {
    tmacevent_ScreenPopEvent(event);
}

function AgentForcedLogoffEvent(event) {
    try {
        //set _isAgentLoggedIn to false
        _isAgentLoggedIn = false;
        //close the signalr connection on this event
        if (window.tmacconnectprotocol === "signalr") {
            GetSRConnection("TmacProxy").close();
        }
    } catch (e) {
        //
    }
    /*
    string Type - Type of the force logoff - SessionKeyExpired, SessionNotFound, NotLoggedIntoACD
    string Reason - reason for the force logoff in detail
    */
    tmacevent_AgentForcedLogoffEvent(event);
}

function HoldTimerEvent(event) {
    /*
   int  HoldTimeSeconds - hold time in seconds
   string HoldTimeString - hold time as a formatted string (hh:mm:ss)
    */
    tmacevent_HoldTimerEvent(event);
}

function AgentReminderEvent(event) {
    // string Auto - 0=Agent requested for the list of remonders, 1 = server sends reminder list automatically
    // List<AgentReminder> Reminders -  list of reminders

    /*AgentReminder
    {
          string ID - reminder unique ID
          string AgentID - agent ID
          string Message  - reminder message
          string RemindDate - reminder date (yyyyMMdd)
          string RemindTime - reminder time (HHmmss)
          string Status - Status of the reminder (New, Completed)
    }*/

    tmacevent_AgentReminderEvent(event);
}

function CreateAgentReminderEvent(event) {
    /*ResultCode
    {
        > 0 Success
        else Error
    }*/

    tmacevent_CreateAgentReminderEvent(event);
}

function DeleteAgentReminderEvent(event) {
    /*ResultCode
    {
        > 0 Success
        else Error
    }*/

    tmacevent_DeleteAgentReminderEvent(event);
}

function UpdateAgentReminderEvent(event) {
    /*ResultCode
    {
        > 0 Success
        else Error
    }*/

    tmacevent_UpdateAgentReminderEvent(event);
}

function OutgoingCallUCIDEvent(event) {

    // string PhoneNumber -  UCID of the outbound call
    // bool IsExistingInteraction - this propert is used to inform the UI that this is a out voice event from and exising tab. Ui dont have to create a new tab.


    tmacevent_OutgoingCallUCIDEvent(event);
}

function VoiceCallInitiatingEvent(event) {

    /*
    string ConnectionHandle - connection handle of the call (this will be used to disconnect the call)
    string UCID - UCID of the call
    bool IsExistingInteraction - is this an existing interaction
    */
    tmacevent_VoiceCallInitiatingEvent(event);
}

function VoiceCallRecorderEvent(event) {
    // string UCID  - UCID for the recorded call

    tmacevent_VoiceCallRecorderEvent(event);
}

function AutoCloseTabEvent(event) {

    //int InteractionID - which tab should be auto clsoed

    tmacevent_AutoCloseTabEvent(event);
}

function GenericInteractionEvent(event) {

    // string  SessionID - session id of the generic interaction
    // GenericQueueItem Item - generic queue item (read from work queue)

    //save recovery data
    SaveRecoveryData(event);

    tmacevent_GenericInteractionEvent(event);
}

function InteractionHistoryReLoadEvent(event) {

    // List<HistoryInteraction> History  - list of history items

    tmacevent_InteractionHistoryReLoadEvent(event);
}

function SmsSurveyResultEvent(event) {

    // string Channel - sms survey channel (Voice, Chat...)
    // bool Success - survey sending success or not
    // int ResultCode - result code for survey
    // string TypeOfSurvey - type of survey (Auto, Manual, Stop)
    // string MobileNumber - mobile number used to send the survey

    /* ResultCode
       -100 	INVALID NUMBER
       -101	SURVEY DISABLED
       -102	SURVEY CONFIG NOT FOUND
       103		SURVEY STOP SUCCESS
       -103	SURVEY STOP INSERT FAILED
       -104	USER IN DONOT CALL LIST
       -105	ANOTHER SMS WAS SENT RECENTLY
       -108	INSERT TO SURVEY TABLE FAILED
       >1		SEND SUCCESS
       1		SEND SUCCESS
       -109	MESSAGE SENDING FAILED
       -107	TEMPLATE FOUND BUT EMPTY
       -106	TEMPLATE NOT FOUND
       -1		GENERIC ERROR
       */

    tmacevent_SmsSurveyResultEvent(event);
}

function SMSSendFailedEvent(event) {

    /*    
    string PhoneNumber { get; set; } //phone number tried to sending the message
    string Message { get; set; } //mesasge
    string Channel { get; set; } //channel (Voice,SMS)
     */

    tmacevent_SMSSendFailedEvent(event);
}

function InteractionClosedEvent(event) {
    //remove
    RemoveRecoveryData(event);
    tmacevent_InteractionClosedEvent(event);
}

function TmacServerConnectionSuccess(event) {
    //reset the session key
    if (event.ResultCode === 200) {

        if (event.Data)
            global_AgentSessionKey = event.Data;

        //reset tmac server
        if (event.ResultMessage)
            _tmacServer = event.ResultMessage;

        //recover interactions
        try {
            tmac_RecoverInteractions(null, null, global_AgentID, JSON.stringify(tmac_events_interaction_recovery_data));
        } catch (e) {
            //
        }

        //check if signalr connectivity is tmac is configured
        try {
            if (global_TmacSignalRUrl) {
                let conn = GetSRConnection("TmacServer");
                // check if the url is present
                if (conn && event.TmacSignalRUrl) {
                    console.log("TmacServerConnectionSuccess: try connecting to the new server URL");
                    // change the global url 
                    global_TmacSignalRUrl = event.TmacSignalRUrl;
                    // set the urls to signalr connector
                    conn.urls = [event.TmacSignalRUrl];
                    // change the query string to new session key
                    conn.con.qs = {
                        deviceId: global_DeviceID,
                        agentSessionKey: global_AgentSessionKey
                    };
                    // check if connected to existing url then disconnect and connect to new url
                    if (conn.connected) {
                        // set this flag to true so that it will not ask proxy for new URL on disconnect
                        _tryReconnecting = true;
                        // close the connection and mark forceClose false so that it will try connecting to new URL on disconnect
                        conn.close(false);
                    }
                }
                else {
                    console.log("TmacServerConnectionSuccess: no SignalR URL found, try manual GetEvent connection");
                }
            }
        } catch (e) {
            //
        }

        tmacevent_TmacServerConnectionSuccess(event);
    }
}

function TmacServerConnectionAborted(event) {
    alert("Critical error. Please logout and login");
    window.close();
}

function TmacServerConnectionExist(event) {
    if (!_startEventPolling) {
        GetSRConnection("TmacServer").close(true);
        global_TmacSignalRUrl = "";
        ProxySetConnectivityStatus(1, 'ajax', "onconnected");
        tmac_GetEvent(null, null, global_DeviceID, global_AgentSessionKey, false);
    }
}

function MakerEmailReplySentOutEvent(event) {
    email_MakerEmailReplySentOutEvent(event);
}

function VoiceBargeinEvent(event) {
    //         string SupervisorId 
    //         string SupervisorName 
    //         string SendCallToNumber 
    //         bool Active 

    voice_supervisor_bargin(event.InteractionID, event.SupervisorId, event.SupervisorName, event.SendCallToNumber, event.Active);
}

function MakeCallOnExistingTabFailed(event) {

    /*
    string ConnectionHandle - connection handle of the call (this will be used to disconnect the call)
    string UCID - UCID of the call
    bool IsExistingInteraction - is this an existing interaction
    */
    tmacevent_MakeCallOnExistingTabFailed(event);
}

function AnotherAgentTransferedCallToMeEvent(event) {
    tmacevent_AnotherAgentTransferedCallToMeEvent(event);
}

function AnotherAgentConferencedCallToMeEvent(event) {
    tmacevent_AnotherAgentConferencedCallToMeEvent(event);
}

function ForwadableEvent(event) {

    //    string ForwardServer { get; set; }
    //    string ForwardAgent { get; set; }
    //    string ForwardInteractionId { get; set; }
    //    IUIEvent Event { get; set; }

    tmac_AddEventToAgentSession(null, null, event.ForwardAgent, event.Event, true, event.ForwardServer);
}

function VBCallConnectedEvent(event) {
    tmacevent_VBCallConnectedEvent(event);
}

function VBCallDisconnected(event) {
    tmacevent_VBCallDisconnectedEvent(event);
}

function VBStatusEvent(event) {
    tmacevent_VBStatusEvent(event);
}

function VBNRICEvent(event) {
    tmacevent_VBNRICEvent(event);
}

function AgentCommandEvent(event) {
    /* 
    string Name  
    string Message
    string FromAgentId  
    string FromTmacServer
    string FromInteractionID 
    string ToAgentId 
    string ToTmacServer 
    string ToInteractionID 
    */

    tmacevent_AgentCommandEvent(event);
}

function FaxReceivedEvent(event) {
    tmacevent_FaxReceivedEvent(event);
}

function GenericCTIEvent(event) {
    tmacevent_GenericCTIEvent(event);
}

function GenericCallEvent(event) {
    tmacevent_GenericCallEvent(event);
}

function InteractionHistoryReadyEvent(event) {
    tmacevent_InteractionHistoryReadyEvent(event);
}

function TCM_DirectAgentNotifyEvent(event) {
    tmacevent_TCM_DirectAgentNotifyEvent(event);
}

function TCM_DirectAgentNotifyTimeoutEvent(event) {
    tmacevent_TCM_DirectAgentNotifyTimeoutEvent(event);
}

function GenericTMACEvent(event) {
    tmacevent_GenericTMACEvent(event);
}

function AgentTimedACWEvent(event) {
    tmac_AgentTimedACWEvent(event);
}

function InteractionTransferNotificationEvent(event) {
    tmacevent_InteractionTransferNotificationEvent(event);
}

function InteractionTransferResponseEvent(event) {
    tmacevent_InteractionTransferResponseEvent(event);
}

function AgentUIUpdateEvent(event) {
    tmac_AgentUIUpdateEvent(event);
}

function MediaServerEvent(event) {
    tmacevent_MediaServerEvent(event);
}

function MSStatusEvent(event) {
    //string Status - Failed, Reconnected

    tmacevent_MSStatusEvent(event);
}

function AgentAVMessageEvent(event) {
    tmacevent_AgentAVMessageEvent(event);
}

function AgentSettingsUpdatedEvent(event) {
    tmacevent_AgentSettingsUpdatedEvent(event);
}

function ParallonDataEvent(event) {
    tmacevent_ParallonDataEvent(event);
}

function ActionMessageReceivedEvent(event) {
    tmac_ActionMessageReceivedEvent(event);
}

function InteractionConvertedEvent(event) {
    tmac_InteractionConvertedEvent(event);
}

function TextChatMessageEvent(event) {
    tmacevent_TextChatMessageEvent(event);
}