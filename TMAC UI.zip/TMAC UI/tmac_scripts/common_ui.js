﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var file_versions = [];
var filename = "CommonUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//remote logger instance
var log = new Logger();
$(document).ready(function () {
    console.log('common ui loaded');
});
// ----------------------------------------------------------------------------------
// Get the Dynamic CRM Resilution and Position
// ----------------------------------------------------------------------------------
function DynamicsCRMScreenResolution_Width() {
    try {
        // Is my Tmac occupied max [more than 75% of the Screen ?], in this case , cRM window will take Fulll Width.	
        if ((Application_Window_Current_Width * 100) / screen.width > 75) return screen.width - 50;
        else return screen.width - Application_Window_Current_Width - 40;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Width()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Height() {
    try {
        //var height=(CalculateWindowHeight()*Application_window_height_Percentage)/100
        return Application_Window_Current_Height;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Height()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Position_Left() {
    try {
        //return DynamicsCRMScreenResolution_Width()+80;
        return Application_Window_Current_Width + 20;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Position_Left()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Position_Top() {
    return 0;
}

// ----------------------------------------------------------------------------------
// All the Coomon Utilities/Functions related to the TMAC Goes here ...
// ----------------------------------------------------------------------------------
function global_addVersions(file, version) {
    try {
        var val = file + ": " + version;
        if (file_versions) {
            if (file_versions.indexOf(val) < 0) {
                file_versions.push(val);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.global_addVersions()", ex, false);
    }
}

function ShowVersionDetails() {
    try {
        file_versions.sort();
        $("#version_table_tbody").html("");
        let innerHtml = "";
        let arraylenfgth = file_versions.length;
        let str = "<tr><td> " + global_AssemblyVersion.substr(0, global_AssemblyVersion.indexOf(":")) + "</td><td>" + global_AssemblyVersion.substr(global_AssemblyVersion.indexOf(":")) + "</td></tr>";
        for (var i = 0; i < arraylenfgth; i++) {
            $("#version_table_tbody").append("<tr><td>" + file_versions[i].substr(0, file_versions[i].indexOf(":")) + "</td><td>" + file_versions[i].substr(file_versions[i].indexOf(":") + 1) + "</td></tr>");
        }
        innerHtml = "<div class='uk-text-small custom-padding'>" +
            "<p><b>TMAC Server</b>:<br/>" + _tmacServer + "</p>" +
            "<p><b>TMAC Proxy</b>:<br/>" + global_connectedProxy + "</p>" +
            "<p><b>SignalR Server</b>:<br/><span id='signalRVersion'>" + (signalRVersion === undefined ? "NA" : signalRVersion) + "</span></p></div>";
        $("#div_version_info").html(innerHtml);
        UIkit.modal("#model_version_info").show();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.ShowVersionDetails()", ex, false);
    }
}
// ---------------------------------------------------------------------------------------
// This method will Convert current Widow width to pixel width based on Percentage we set
// ---------------------------------------------------------------------------------------
function CalculateTMACWindowWidth() {
    try {
        var current_screen_width = screen.width;
        if (isApplication_window_size_type_pixel === true) {
            Application_Window_Current_Width = Application_window_width;
        }
        else {
            Application_Window_Current_Width = (current_screen_width * Application_window_width) / 100;
        }
        return Application_Window_Current_Width;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CalculateTMACWindowWidth()", ex, false);
    }
}

// ---------------------------------------------------------------------------------------
// This method will Convert current window Height to pixel Height based on Percentage we set
// ---------------------------------------------------------------------------------------
function CalculateTMACWindowHeight() {
    try {
        var current_screen_height = screen.height;
        if (isApplication_window_size_type_pixel === true) {
            Application_Window_Current_Height = Application_window_height;
        }
        else {
            Application_Window_Current_Height = (current_screen_height * Application_window_height) / 100;
        }
        return Application_Window_Current_Height;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CalculateTMACWindowHeight()", ex, false);
    }
}

//-------------- Connectivity Status -------------------------
function SetConnectivityStatus(status, source, type) {
    try {
        // set the icon initially
        let icon = source === "signalr" ? "wifi_tethering" : "wifi";

        // check for error then change the icon
        if (status === 2) {
            icon = source === "signalr" ? "portable_wifi_off" : "wifi_off";
        }

        // set the icon
        $("#btn_network").find("i").text(icon);

        $("#btn_network").find("i").removeClass("uk-text-warning");
        $("#btn_network").find("i").removeClass("uk-text-success");

        if (status === 2) {
            if (isVoiceBio) {
                $("#favicon").attr("href", "assets/img/voice_bio_failed.png");
            }
            else {
                $("#btn_network").find("i").addClass("uk-text-danger");
                if (!$("#ui_tmac_logo").hasClass("blink_status")) {
                    $("#btn_network").find("i").text(icon);
                    $("#ui_tmac_logo").addClass("blink_status");
                }
            }
        }
        else {
            if (status === 0) {
                isVoiceBio ? document.getElementById("agentIcon").style.borderColor = "#ffa000" : $("#btn_network").find("i").addClass("uk-text-warning");
            }
            else if (status === 1) {
                isVoiceBio ? document.getElementById("agentIcon").style.borderColor = "#7cb342" : $("#btn_network").find("i").addClass("uk-text-success");
            }

            if ($("#ui_tmac_logo").hasClass("blink_status")) {
                $("#btn_network").find("i").text(icon);
                $("#ui_tmac_logo").removeClass("blink_status");
            }
        }

        if (source === "signalr" && type === "onconnectionslow" && status === 0) {
            log.LogDetails("Warning", "TMAC-Signalr", "We are currently experiencing difficulties with the connection!", true);
        }
        else if (source === "signalr" && type === "onreconnecting") {
            log.LogDetails("Warning", "TMAC-Signalr", "Reconnecting to the socket server...", true);
        }
        else if (source === "signalr" && type === "onreconnected") {
            log.LogDetails("Success", "TMAC-Signalr", "Reconnected to the socket server, enjoy seamless usage!", true);
        }
        else if (source === "signalr" && type === "ondisconnected") {
            log.LogDetails("Error", "TMAC-Signalr", "Disconnected from the socket server, please wait...", true);
        }
        else if (source === "ajax" && type === "onconnected") {
            log.LogDetails("Success", "TMAC-Signalr", "Connected to polling server, enjoy seamless usage!", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.SetConnectivityStatus()", ex, false);
    }
}

function FormatDate(date) {
    try {
        return CheckForDay(date);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FormatDate()", ex, false);
    }
}

function CheckForDay(date) {
    try {
        let dateTime = moment(new Date(date)).format("YYYYMMDD");
        let yesterday = moment(new Date()).add(-1, 'days').format("YYYYMMDD");
        let today = moment(new Date()).format("YYYYMMDD");
        let tomorrow = moment(new Date()).add(1, 'days').format("YYYYMMDD");
        switch (dateTime) {
            case yesterday:
                return "Yesterday at " + moment(date).format("hh:mma");
            case today:
                return "Today at " + moment(date).format("hh:mma");
            case tomorrow:
                return "Tomorrow at " + moment(date).format("hh:mma");
            default:
                return moment(new Date(date)).format("MMMM DD, YYYY") + " at " + moment(date).format("hh:mma");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CheckForDay()", ex + " - Original date is returned without formatting.", false);
        return date;
    }
}

function GetCurrentDateTime() {
    return GetCurrentDate("DD/MM/YYYY") + " " + GetCurrentTime("HH:mm:ss");
}

function GetCurrentDate(format) {
    try {
        return moment(new Date()).format(format);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetCurrentDate()", ex, false);
    }
}

function GetCurrentTime(format) {
    try {
        return moment(new Date()).format(format);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetCurrentTime()", ex, false);
    }
}

// ------------------------------------------------------------------------------------------
// Insert text inside Textbox at current Cursor Position
// ------------------------------------------------------------------------------------------
function InsertTextAtCurrentCursorPosition(textboxCntl, textToInsert) {
    try {
        var cursorPos = $("#" + textboxCntl).prop('selectionStart');
        var v = $("#" + textboxCntl).val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);
        $("#" + textboxCntl).val(textBefore + textToInsert + textAfter);
        $("#" + textboxCntl).focus();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.InsertTextAtCurrentCursorPosition()", ex, false);
    }
}

// --------------------------------------add a method to global timer loop-------------------------------------------------
function AddMethodToTimerLoop(deviceid, intid, methodName, data) {
    try {
        var object = {};
        object.data = data;
        object.methodName = methodName;
        object.deviceid = deviceid;
        object.intid = intid;
        global_timeoutFunctions.push(object);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.AddMethodToTimerLoop()", ex, false);
    }
}

//-------------------------------show notification alert--------------------------------------------
function ShowNotify(message, status, group, pos, noLog) {
    try {
        if (isVoiceBio && !$(".an-loader").hasClass("uk-display-none")) {
            $(".an-loader").addClass("uk-display-none");
        }
        var thisNotify = UIkit.notify({
            message: message ? message + '<a href="#" class="notify-action">X</a>' : '',
            status: status ? status : '',
            timeout: notifyTimeout ? notifyTimeout : 3000,
            group: group ? group : null,
            pos: pos ? pos : 'top-center',
            onClose: function () {
                $body.find('.md-fab-wrapper').css('margin-bottom', '');
                // clear notify timeout (sometimes callback is fired more than once)
                clearTimeout(thisNotify.timeout);
            }
        });
        if ((($window.width() < 768) && ((thisNotify.options.pos === 'bottom-right') || (thisNotify.options.pos === 'bottom-left') ||
            (thisNotify.options.pos === 'bottom-center'))) || (thisNotify.options.pos === 'bottom-right')) {
            var thisNotify_height = $(thisNotify.element).outerHeight();
            var spacer = $window.width() < 768 ? -6 : 8;
            $body.find('.md-fab-wrapper').css('margin-bottom', thisNotify_height + spacer);
        }
        if (isVoiceBio && !$(".uk-notify").hasClass("uk-notify-vb")) {
            $(".uk-notify").addClass("uk-notify-vb");
        }

        if (!noLog) {
            AddMessageAlerts(status, message);
            log.LogDetails(status === "danger" ? "Error" : status === "" ? "info" : status, "CommonUI.AddMessageAlerts()", message, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.ShowNotify()", ex, false);
    }
}

//-------------------------------add alerts to the array--------------------------------------------
function AddMessageAlerts(status, message) {
    try {
        //type of message success,warning, danger or primary
        var messagetype = "";
        var icon = "";
        switch (status) {
            case "success":
                messagetype = "uk-text-success";
                icon = "check_circle_outline";
                break;
            case "warning":
                messagetype = "uk-text-warning";
                icon = "warning";
                break;
            case "danger":
                messagetype = "uk-text-danger";
                icon = "error_outline";
                break;
            default:
                messagetype = "uk-text-primary";
                icon = "info";
                break;
        }

        ////creat the li of alert
        //var alertManagerHtml = '<li class="uk-text-bold ' + messagetype + '">' + message + " - " + GetCurrentDateTime() + '</li>';
        ////append to the array
        //recentAlerts.push(alertManagerHtml);
        //$("#btnrecentalerts i").text("notifications_active");
        //$("#btnrecentalerts i").addClass("wiggle");
        //let recentAlertCount = parseInt($("#recentAlertCount").text());
        //let count = ++recentAlertCount;
        //$("#recentAlertCount").text(count);

        let notificationCount = parseInt($("#notificationCount").text());
        let count = ++notificationCount;

        $("#recentAlertCount").text(count);

        var liTemplate = `<li class="clearable">
                              <div class="md-list-addon-element">
                                <i class="md-list-addon-icon material-icons notranslate ${messagetype}">${icon}</i>
                             </div>
                             <div class="md-list-content">
                                <span class="md-list-heading notification-message new">${message}</span>
                                <span class="notification-time uk-text-muted uk-text-truncate">${GetCurrentDateTime()}</span>
                             </div>
                         </li>`;

        $("#notification_list").prepend(liTemplate);
        if (!$("#header_notification i").hasClass("wiggle")) $("#header_notification i").addClass("wiggle");
        $("#header_notification i").text("notifications_active");
        $("#header_notification .uk-badge").text(count);
        $("#header_notification .uk-badge").removeClass("uk-display-none");
        $("#notificationActions").removeClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.AddMessageAlerts()", ex, false);
    }
}
function ClearNotificationCount() {
    $("#header_notification i").text("notifications");
    $("#header_notification i").removeClass("wiggle");
    $("#header_notification .uk-badge").text(0);
    $("#header_notification .uk-badge").addClass("uk-display-none");
}
function ClearNotifications() {
    $("li.clearable").remove();
    $("#notificationActions").addClass("uk-display-none");
}
function ReadNotifications() {
    //notification can come when its opened, so clear the count on read all click
    ClearNotificationCount();
    $(".notification-message").removeClass("new");
}
//disable load more button
function DisableLoadMoreButton(intId) {
    try {
        var loadmorebuttonid = "#loadMoreInteraction" + intId;
        $(loadmorebuttonid).addClass('uk-icon-spin icon-disabled');
        $(loadmorebuttonid).parent().css("cursor", "not-allowed");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableLoadMoreButton()", ex, false);
    }
}

//enable load more button
function EnableLoadMoreButton(intId) {
    try {
        var loadmorebuttonid = "#loadMoreInteraction" + intId;
        $(loadmorebuttonid).removeClass('uk-icon-spin icon-disabled');
        $(loadmorebuttonid).parent().css("cursor", "");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableLoadMoreButton()", ex, false);
    }
}

//-------------------------enable tab close button-----------------------------------
function EnableTabCloseButton(intid) {
    try {
        $('#divCloseButton' + intid).css("display", "inline");
        $('#btnCloseTab' + intid).css("display", "");
        $('#btnCloseTab' + intid).removeAttr('disabled', 'disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableTabCloseButton()", ex, false);
    }
}

//------------------------------------enable/disable callback dial buttons--------------------------------
function EnableCallbackDialButtons(intid) {
    //check if this is a callback tab. Then enable both PCN dial and CID buttons
    try {
        if (GetTabReferenceObj(intid).type.indexOf("callback") !== -1) {
            $('#btnDialCallerID' + intid).removeClass('disabled');
            $('#btnDialPCN' + intid).removeClass('disabled');
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableCallbackDialButtons()", ex, false);
    }
}

function DisableCallbackDialButtons(intid) {
    try {
        $('#btnDialCallerID' + intid).addClass('disabled');
        $('#btnDialPCN' + intid).addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackDialButtons()", ex, false);
    }
}

//------------------------------------enable/disable callback submit buttons--------------------------------
function DisableCallbackSubmitButtons(intid) {
    try {
        if (disableSubmitButton) {
            $('#btnSubmit' + intid).addClass('disabled');
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackSubmitButtons()", ex, false);
    }
}

function EnableCallbackSubmitButtons(intid) {
    try {
        $('#btnSubmit' + intid).removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackSubmitButtons()", ex, false);
    }
}

//------------------------------------enable/disable callback details buttons--------------------------------
function DisableCallbackDetailsButtons(intid) {
    try {
        $('#btnDetail' + intid).addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackDetailsButtons()", ex, false);
    }
}

function EnableCallbackDetailsButtons(intid) {
    try {
        $('#btnDetail' + intid).removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableCallbackDetailsButtons()", ex, false);
    }
}

//------------------------------------disable callback buttons--------------------------------
function DisableCallbackButtons(intid) {
    try {
        //disable callback dial buttons
        DisableCallbackDialButtons(intid);
        //disable callback submit button
        DisableCallbackSubmitButtons(intid);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackButtons()", ex, false);
    }
}
//---------------------------------------------- Enable/Disable Logout Button ------------------------------------------------------
function FadeOutButton(buttonId) {
    try {
        //  Sam: Aug 31, '20: Keep make call button enabled always, if required
        if (buttonId === ".btn-make-call" && AppConfigs.Remote.Channel.Voice.MakeCallAlwaysEnabled)
            return;

        if (buttonId === "#btn_change_status") {
            $(buttonId).parent().addClass("disable-aux");
        }
        else {
            $(buttonId).addClass('disabled');
            $(buttonId).parent().css("cursor", "not-allowed");
            $(buttonId).fadeTo("fast", 0.3);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FadeOutButton()", ex, false);
    }
}

function FadeInButton(buttonId) {
    try {
        if (buttonId === "#btn_change_status") {
            $(buttonId).parent().removeClass("disable-aux");
        }
        else {
            $(buttonId).removeClass('disabled');
            $(buttonId).parent().css("cursor", "");
            $(buttonId).fadeTo("fast", 1);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FadeInButton()", ex, false);
    }
}
//----------------------------------------------Enable/Disable Transfer to IVR Button ------------------------------------------------------
function DisableTransferToIVR(intId) {
    try {
        $('#btn_ddlTransferToIVR' + intId).addClass('disabled');
        $("#btn_ddlTransferToIVR" + intId).parent().css("pointer-events", "none");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableTransferToIVR()", ex, false);
    }
}

function EnableTransferToIVR(intId) {
    try {
        $('#btn_ddlTransferToIVR' + intId).removeClass('disabled');
        $("#btn_ddlTransferToIVR" + intId).parent().css("pointer-events", "");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableTransferToIVR()", ex, false);
    }
}

//----------------------------------------------Enable/Disable Transfer Button and dialog buttons------------------------------------------------------
function EnableButton(buttonId, item, type) {
    try {
        if (type === "tag")
            $(buttonId).html(item);
        else if (type === "icon")
            $(buttonId).html('<i class="material-icons notranslate sm-24 md-light">' + item + '</i>');
        $(buttonId).removeClass("disabled");
        $(buttonId).fadeTo("fast", 1);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableButton()", ex, false);
    }
}

function DisableButton(buttonId) {
    try {
        $(buttonId).addClass("disabled");
        //$(buttonId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        $(buttonId).html('<i class="material-icons notranslate sm-24 md-light uk-icon-spin">sync</i>');
        $(buttonId).fadeTo("fast", 0.5);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableButton()", ex, false);
    }
}

//----------------------------------------------Enable/Disable conf Button ------------------------------------------------------
function ShowKendoLoading(target) {
    var element = $(target);
    kendo.ui.progress(element, true);
}

function HideKendoLoading(target) {
    var element = $(target);
    kendo.ui.progress(element, false);
}

function PreviewAttachment(src) {
    $("#btn_refresh_cobrowse").addClass("uk-display-none");
    $("#imagePreviewImg").attr("src", src);
    UIkit.modal("#modal_previewImage").show();
}

function SecondsTimeSpanToMS(s) {
    try {
        var h = Math.floor(s / 3600); //Get whole hours
        s -= h * 3600;
        var m = Math.floor(s / 60); //Get remaining minutes
        s -= m * 60;
        return (m < 10 ? '0' + m : m) + ":" + (s < 10 ? '0' + s : s); //zero padding on minutes and seconds
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.SecondsTimeSpanToMS()", ex, false);
    }
}

//function to load url into an iframe
function LoadIFrame(iframeName, url) {
    try {
        var $iframe = $("#" + iframeName);
        if ($iframe.length) {
            $iframe.attr('src', url);
            return false;
        }
        return true;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.LoadIFrame()", ex, false);
    }
}

function CheckForForms(text, intid) {
    var html = text;
    try {
        if (IsFormExist(text)) {
            var nUrl = StartCobrSession(global_AgentName, $('#divCustomerName' + intid).text(), GetCobrowseUrl(text), intid);
            //html = '<a href=' + '"' + nUrl + '"' + '  target="_blank">Open Form</a>';
            html = '<a href="#" onclick="OpenFormFillingDialog(\'' + nUrl + '\');">Open Form</a>';
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForForms()", ex, false);
    }
    return html;
}

function IsFormExist(text) {
    var isExist = false;
    try {
        $.each(forms, function (i, val) {
            if (val.name === text)
                isExist = true;
            return;
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.IsFormExist()", ex, false);
    }
    return isExist;
}

function GetCobrowseUrl(name) {
    try {
        var obj = $.grep(forms, function (e) { return e.name === name; });
        var url = obj[0].url;
        return url;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetCobrowseUrl()", ex, false);
    }
}

function StartCobrSession(agentName, customerName, pageUrl, tmacSessionId) {
    try {
        var base = pageUrl + "#&togetherjs=" + tmacSessionId + "&cobruser=";
        OpenFormFillingDialog(encodeURI(base + global_AgentID));
        return encodeURI(base + global_AgentID);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.StartCobrSession()", ex, false);
    }
}

function OpenFormFillingDialog(url) {
    try {
        LoadIFrame("formFillingIframe", url);
        $("#from_filling_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenFormFillingDialog()", ex, false);
    }
}

function StartWhiteboardSession(intid) {
    try {
        UIkit.modal.confirm("Do you want to share whiteboard?",
            function () {
                let msg = "";
                let msgid = uuid();
                let obj = {};
                obj.id = msgid;
                obj.message = whiteboardUrl;
                obj.messageType = "whiteboard";
                obj.type = "new";
                msg = JSON.stringify(obj);
                SendTextChat(global_DeviceID, intid, msg, "", "", true);
                OpenWhiteBoard(whiteboardUrl);
            },
            function oncancel() { });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.StartWhiteboardSession()", ex, false);
    }
}

function OpenWhiteBoard(url) {
    try {
        LoadIFrame("whiteboardIframe", url);
        $("#whiteboard_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenWhiteBoard()", ex, false);
    }
}

function GetHtmlFromTemplate(templateId, intid, customData) {
    try {
        var t = $("#" + templateId).html(), //template divs
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                intid: intid,
                deviceid: global_DeviceID
            }; //add context data

        if (customData !== null) {
            $.each(customData, function (i, val) {
                context[i] = val;
            });
        }

        return n(context); //execute the template with handlebar and context
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetHtmlFromTemplate()", ex, false);
    }
}

var sort_by = function (field, reverse, primer) {
    try {
        var key = primer ?
            function (x) {
                return primer(x[field]);
            } :
            function (x) {
                return x[field];
            };

        reverse = !reverse ? 1 : -1;

        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        };
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.sort_by()", ex, false);
    }
};

function uuid() {
    try {
        //0f8fad5b-d9cb-469f-a165-70867728950e
        var x = document.getElementById("demo")
        var possible = "0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z";
        var guid = "";
        for (var i = 1; i <= 32; i++) {
            var randChar = possible.charAt(Math.floor(Math.random() * possible.length));
            guid += randChar;
            if (i === 8 || i === 12 || i === 16 || i === 20)
                guid += "-";
        }
        return guid;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.uuid()", ex, false);
    }
}

function isNullOrWhitespace(input) {
    try {
        return !input || !input.trim();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.isNullOrWhitespace()", ex, false);
        return false;
    }
}

function GetBaseUrl(url) {
    try {
        if (url) {
            var parts = url.split('://');

            if (parts.length > 1) {
                return parts[0] + '://' + parts[1].split('/')[0];
            } else {
                return parts[0].split('/')[0];
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetBaseUrl()", ex, false);
    }
}

function ToCamelCase(string) {
    try {
        return string[0].toUpperCase() + string.substr(1, string.length).trim();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetBaseUrl()", ex, false);
        return string;
    }
}

function AddSingleQuotes(str) {
    return '\'' + str + '\'';
}

function GetMilliseconds() {
    return moment(new Date()).valueOf();
}

function IsValidJson(text) {
    var isJson = false;
    try {
        var jParse = JSON.parse(text);
        if (typeof (jParse) === "object") {
            isJson = true;
        }
        else {
            isJson = false;
        }
    } catch (ex) {
        isJson = false;
    }
    return isJson;
}

function AddUrlParam(url, paramName, paramValue) {
    try {
        if (paramValue == null)
            paramValue = '';
        url = url.replace(/\?$/, '');
        var pattern = new RegExp('\\b(' + paramName + '=).*?(&|$)')
        if (url.search(pattern) >= 0) {
            return url.replace(pattern, '$1' + paramValue + '$2');
        }
        return url + (url.indexOf('?') > 0 ? '&' : '?') + paramName + '=' + paramValue;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.AddUrlParam()", ex, false);
    }
}

function RemoveParamFromUrl(key, sourceURL) {
    try {
        var rtn = sourceURL.split("?")[0],
            param,
            params_arr = [],
            queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
        if (queryString !== "") {
            params_arr = queryString.split("&");
            for (var i = params_arr.length - 1; i >= 0; i -= 1) {
                param = params_arr[i].split("=")[0];
                if (param === key) {
                    params_arr.splice(i, 1);
                }
            }
            rtn = rtn + "?" + params_arr.join("&");
        }
        return rtn;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.RemoveParamFromUrl()", ex, false);
    }
}

function GetUrl(href) {
    var l = document.createElement("a");
    l.href = href;
    return l;
}

function IsValidURL(str) {
    try {
        if (str.indexOf("localhost") >= 0) {
            return true;
        }
        var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
            '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
        return !!pattern.test(str);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.IsValidURL()", ex, false);
    }
    return false;
}

function OpenAgentNotes() {
    try {
        UIkit.modal("#notes_dialog").show();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.OpenAgentNotes()", ex, false);
    }
}

function mergeObjects(obj1, obj2) {
    try {
        var objs = [obj1, obj2],
            result = objs.reduce(function (r, o) {
                Object.keys(o).forEach(function (k) {
                    r[k] = o[k];
                });
                return r;
            }, {});
        return result;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.mergeObjects()", ex, false);
    }
    return {};
}

//function mergeObjects(obj1, obj2) {
//    var obj3 = {};

//    for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
//    for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }

//    return obj3;
//}

//to unload iframe
function UnloadIFrame(iframeName) {
    try {
        var $iframe = $("#" + iframeName);
        if ($iframe.length) {
            $iframe.attr('src', '');
            return false;
        }
        return true;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.UnloadIFrame()", ex, false);
    }
    return false;
}

//to check between condition
function between(x, min, max) {
    return x >= min && x <= max;
}

//to get unique token
function uniqueToken() {
    return Math.random()
        .toString(36)
        .substr(2, 35);
}