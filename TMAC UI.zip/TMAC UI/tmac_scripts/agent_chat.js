// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "AgentChat.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------
var $chatbox_wrapper = $('#chatbox_wrapper');

let agent_chat = {
    agentlist: function () {
        $("#loadagentlist").addClass("uk-icon-spin");
        agent_chat.load_agent_list();
    },
    agentChatRef: [],
    get_agent_chat_ref: function (agentId) {
        try {
            let ref = this.agentChatRef.filter(function (a) { return a.FromAgentId === agentId; });
            if (ref.length > 0) {
                return ref[0];
            }
        } catch (ex) {
            log.LogDetails("Error", "agent_chat.get_agent_chat_ref()", ex, false);
        }
        return null;
    },
    remove_agent_chat_ref: function (agentId) {
        try {
            for (var i = 0; i < this.agentChatRef.length; i++) {
                if (this.agentChatRef[i] && this.agentChatRef[i].FromAgentId === agentId) {
                    this.agentChatRef.splice(i, 1);
                    break;
                }
            }
        } catch (ex) {
            log.LogDetails("Error", "agent_chat.remove_agent_chat_ref()", ex, false);
        }
    },
    add_agent_chat_ref: function (data) {
        try {
            if (this.get_agent_chat_ref(data.FromAgentId)) {
                this.remove_agent_chat_ref(data.FromAgentId);
            }
            this.agentChatRef.push(data);
        } catch (ex) {
            log.LogDetails("Error", "agent_chat.remove_agent_chat_ref()", ex, false);
        }
    },
    load_agent_list: function () {
        try {
            tmac_GetAgentListStaffed(function (data, obj) {
                if (data !== null) {
                    //filter the agents for his team
                    data = data.filter(function (a) { return a.LoginID !== global_AgentID && a.TeamID === global_TeamID; });
                    agent_chat.agentlist_loaded(data, obj);
                }
            }, null, false);
        } catch (ex) {
            log.LogDetails("Error", "agent_chat.load_agent_list()", ex, false);
        }
    },
    agentlist_loaded: function (data, obj) {
        try {
            $("#loadagentlist").removeClass("uk-icon-spin");

            if (data.length > 1 || data.length === 1 && data[0].LoginID !== global_AgentID) {
                if ($("#noAgentLoggedLi").length > 0) {
                    $("#noAgentLoggedLi").remove();
                }

                $.each(data, function (i, val) {
                    if (val.LoginID !== global_AgentID) {
                        if ($("#chatboxes").find("[data-user-id='" + val.LoginID + "']").length === 0) {
                            agent_chat.add_agent_list(val);
                            agent_chat.add_agent_chat_ref({
                                FromTmacServer: val.TmacServer,
                                FromAgentId: val.LoginID,
                                FromAgentName: val.AgentName
                            });
                        }
                        else {
                            $("#" + val.LoginID + "_status").text(val.CurrentAgentStatus);
                            let statusColor =
                                (val.CurrentAgentStatus.indexOf("On Call") >= 0) ? "danger" :
                                    (val.CurrentAgentStatus === "Available") ? "success" :
                                        (val.CurrentAgentStatus === "ACW") ? "warning" : "info";

                            $("#" + val.LoginID + "_status_color").removeClass();
                            $("#" + val.LoginID + "_status_color").addClass("element-status element-status-" + statusColor);
                        }
                    }
                });
            } else {
                var li = "<li class='uk-pointer-events-none' id='noAgentLoggedLi'>No agents logged In</li>";
                $("#chatboxes").html(li);
            }

        } catch (ex) {
            console.log(ex);
        }
    },
    add_agent_list: function (data) {
        try {
            var t = $("#agent_list_template").html(), //template divs
                e = $("#chatboxes"), //to be appended to
                n = Handlebars.compile(t), //initialize handlebars for the template divs       
                context = {
                    agentid: data.LoginID,
                    agentname: data.AgentName,
                    agentprofile: data.Profile === "S" ? "Supervisor" : "Agent",
                    currentstatus: data.CurrentAgentStatus,
                    agentstatus:
                        (data.CurrentAgentStatus.indexOf("On Call") >= 0) ? "danger" :
                            (data.CurrentAgentStatus === "Available") ? "success" :
                                (data.CurrentAgentStatus === "ACW") ? "warning" : "info",
                    class: ""
                    //class: data.CurrentAgentStatus.indexOf("On Call") >= 0 ? "disable-agent" : ""
                }, //add context data
                s = n(context); //execute the template with handlebar and context
            e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
            //remove the class if enabled
            if (typeof isAgentAVChat !== "undefined" && isAgentAVChat) {
                $(".agent-chat-actions").removeClass("uk-display-none-important");
            }
        } catch (ex) {
            console.log(ex);
        }
    },
    chat_list: function () {
        // show chatbox
    },
    chatboxes: function () {
        var $this_root = this;

        // disable page scroll when scrolling chatbox content
        $chatbox_wrapper.on('mousewheel DOMMouseScroll', '.chatbox_content', function (e) {
            var e0 = e.originalEvent;
            var delta = e0.wheelDelta || -e0.detail;
            this.scrollTop += (delta < 0 ? 1 : -1) * 30;
            e.preventDefault();
        });

        // make chatbox active
        $chatbox_wrapper.on('click', '.chatbox', function (e) {
            e.preventDefault();
            $chatbox_wrapper.find('.cb_active').not($(this)).removeClass('cb_active');
            var $chatbox = $(this);
            if ($(e.target).closest('.chatbox_close').length || $(e.target).closest('.actions_dropdown').length) {
                return;
            }
            else if ($(e.target).closest('.chatbox_header').length) {
                if ($chatbox.hasClass('expanded')) {
                    $chatbox.removeClass('expanded cb_active');

                    //  VP: Jul 15, '20: Adding class to wrapper instead 
                    // $chatbox.addClass('minimizing');     
                    $chatbox.parent().addClass('minimizing');
                }
                else {
                    //  VP: Jul 15, '20: Adding class to wrapper instead 
                    // $chatbox.removeClass('minimizing');
                    $chatbox.parent().removeClass('minimizing');

                    $chatbox.addClass('expanded cb_active');
                    let user = $chatbox.attr('data-user-id');
                    if (!$("#unread" + user).hasClass("uk-display-none")) {
                        $("#unread" + user).addClass("uk-display-none");
                        $("#unread" + user).text(0);
                        $chatbox.find(".chatbox_header").removeClass("blink_IM");
                    }
                }
                return;
            }
            if (!$chatbox.hasClass('cb_active')) {
                $chatbox.addClass('cb_active');
                if (!$(e.target).closest('.actions_dropdown').length) {
                    $chatbox.find('.message_input').focus();
                }
            }
        });

        // make chatbox inactive
        $document.on('click', function (e) {
            if (!$(e.target).closest('.chatbox').length) {
                $chatbox_wrapper.find('.cb_active').removeClass('cb_active');
            }
        });

        // close chatbox
        $chatbox_wrapper.on('click', '.chatbox_close', function (e) {
            e.preventDefault();

            var $chatbox = $(this).closest('.chatbox').addClass('removing'),
                user = $chatbox.attr('data-user');
            setTimeout(function () {
                $('#chatboxes').children('li[data-user="' + user + '"]').removeClass('chatbox_active');
                $chatbox.remove();
            }, 280);
        });

        // send message
        $chatbox_wrapper.on('keyup', '.message_input', function (e) {
            var $this = $(this);
            e.preventDefault();
            var code = e.keyCode || e.which;
            if (code === 13 && $this.val() !== '') {
                var $chatbox = $(this).closest('.chatbox'),
                    $chatbox_content = $chatbox.find('.chatbox_content'),
                    conversation_template = Handlebars.compile($("#chatbox_conversation").html()),
                    messages_template = Handlebars.compile($("#chatbox_messages").html());
                if ($.trim($this.val()) !== "") {
                    tmacAgentChatObj.push({
                        agentId: $chatbox.attr('data-user-id'),
                        time: new Date().getTime(),
                        message: $this.val(),
                        type: "own"
                    });
                    var context = {
                        conversation: [{
                            own: true,
                            messages: [{
                                time: new Date().getTime(),
                                text: $this.val()
                            }]
                        }]
                    };

                    var conversation = conversation_template(context),
                        messages = messages_template(context.conversation[0]);

                    if (!$chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                    $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);

                    //get the agent info reference
                    var agentChatRef = $this_root.get_agent_chat_ref($chatbox.attr('data-user-id'));

                    //check if agent reference is there
                    if (agentChatRef) {
                        SendIM(agentChatRef.FromAgentId, "", agentChatRef.FromTmacServer, $this.val());
                    }
                    else {
                        log.LogDetails("Error", "agent_chat.SendIM()", "Send IM failed", false);
                    }

                    $(this).val('');
                }
            }
        });
    },
    chat_received: function (data, type) {
        try {
            type = type ? type : "other";
            if (data.mType !== undefined) {
                type = data.mType;
            }

            tmacAgentChatObj.push({
                agentId: data.FromAgentId,
                time: new Date().getTime(),
                message: data.Message,
                type: type
            });

            //get the agent reference from agent list
            let $that = $('li[data-user-id="' + data.FromAgentId + '"]');

            //if the agent not found in the list, then reload the list
            if ($that.length === 0) {
                //create the user list object
                let obj = {
                    LoginID: data.FromAgentId,
                    AgentName: data.FromAgentName,
                    Profile: "NA",
                    CurrentAgentStatus: "NA",
                    TmacServer: data.FromTmacServer
                };

                //append the user list object
                agent_chat.agentlist_loaded([obj]);

                //set a timer and wait until the agent list is loaded then show the chat
                var timer = setInterval(function (e) {
                    $that = $('li[data-user-id="' + data.FromAgentId + '"]');
                    if ($that.length > 0) {
                        //if the agent list is loaded then show the chat
                        agent_chat.show_received_chat($that, data, type);
                        //clear interval
                        clearInterval(timer);
                    }
                }, 500);
            }
            else {
                agent_chat.show_received_chat($that, data, type);
            }
        } catch (ex) {
            console.log(ex);
        }
    },
    show_received_chat: function ($that, data, type) {
        try {
            let isActive = $that.hasClass('chatbox_active');
            if (!isActive) {
                $that.trigger('click');
            } else {
                let msg = "";
                let context = {};
                let chatTranscriptObj = tmacAgentChatObj.sort(sort_by('time', true, parseInt));
                for (var i = 0; i < chatTranscriptObj.length; i++) {
                    if (type === "own") {
                        msg = data.Message;
                        context = {
                            conversation: [{
                                own: true,
                                messages: [{
                                    time: new Date().getTime(),
                                    text: msg
                                }]
                            }]
                        };
                        break;
                    }
                    else if (chatTranscriptObj[i].type === "other") {
                        msg = chatTranscriptObj[i].message;
                        context = {
                            conversation: [{
                                messages: [{
                                    time: new Date().getTime(),
                                    text: msg
                                }]
                            }]
                        };
                        break;
                    }
                }
                let conversation_template = Handlebars.compile($("#chatbox_conversation").html());
                let conversation = conversation_template(context),
                    messages_template = Handlebars.compile($("#chatbox_messages").html()),
                    messages = messages_template(context.conversation[0]);

                //let $chatbox = $chatbox_wrapper.children('.chatbox:first-child'),
                let $chatbox = $chatbox_wrapper.children('.chatbox[data-user-id=' + data.FromAgentId + ']'),
                    $chatbox_content = $chatbox.find('.chatbox_content');

                if (type === "own") {
                    if (!$chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                }
                else {
                    if ($chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                }
                if ($chatbox.hasClass("minimizing")) {
                    let currentCount = parseInt($("#unread" + data.FromAgentId).text());
                    $("#unread" + data.FromAgentId).removeClass("uk-display-none");
                    $("#unread" + data.FromAgentId).text(++currentCount);
                    $chatbox.find(".chatbox_header").addClass("blink_IM");
                }
                else {
                    $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);
                }
            }

            //show the notification for other agent message only
            if (type === "other") {
                ShowNotification(data.FromAgentName, data.Message);
            }
        } catch (ex) {
            //
        }
    },
    search_agent: function (e) {
        try {
            var searchingAgent = e.target.value.toLowerCase();
            $("#chatboxes").children().each(function (e) {
                var listElement = $(this);
                if (listElement.attr("data-user").toLowerCase().indexOf(searchingAgent) >= 0) {
                    listElement.removeClass("uk-display-none");
                } else {
                    listElement.addClass("uk-display-none");
                }
            });
        } catch (ex) {
            console.log(ex);
        }
    },
    display_agent_chat: function (agentId, agentName, message, tmacServer) {
        try {
            //create the user list object
            var obj = {
                FromAgentId: agentId,
                FromAgentName: agentName,
                Profile: "NA",
                CurrentAgentStatus: "NA",
                Message: message,
                FromTmacServer: tmacServer
            };

            //for self view after sending IM from supervisor
            agent_chat.chat_received(obj, "own");
        } catch (ex) {
            console.log(ex);
        }
    },
    start_audio: function (agentId, agentName) {

        // check if the agent in available state, then alert and return
        if (global_CurrentStatus === "Available") {
            log.LogDetails("Info", "agent_chat.start_audio()", "You are in Available, Please move to AUX to make an audio call", true);
            return;
        }

        agent_chat_av.request(agentId, agentName, WrcCallTypes.Audio);
    },
    start_video: function (agentId, agentName) {

        //check if the agent in available state, then alert and return
        if (global_CurrentStatus === "Available") {
            log.LogDetails("Info", "agent_chat.start_audio()", "You are in Available, Please move to AUX to make a video call", true);
            return;
        }

        agent_chat_av.request(agentId, agentName, WrcCallTypes.Video);
    },
    start_meeting: function (data) {
        // check if the agent in available state, then alert and return
        if (global_CurrentStatus === "Available") {
            log.LogDetails("Info", "agent_chat.start_audio()", "You are in Available, Please move to AUX to start a meeting", true);
            return;
        }
        // get the token
        let token = data.token;
        let splitToken = token.split('-');
        // send the meeting request
        agent_chat_av.sendMeetingRequest(splitToken[0], splitToken[1], "TmacServer" + splitToken[2]);
    }
};

let agent_chat_av = {
    _this: this,
    requestDialog: null,
    av_conn: [],
    req_ref: [],
    request: function (agentId, agentName, param) {

        // create a connection
        let conn = _this.startAVConnection(agentId, agentName, param);

        // start a call
        conn.startCall(param, null, {
            // on success callback
            onSuccess: function (paramType) {
                log.LogDetails("Success", "agent_chat.start_video()", `${ToCamelCase(paramType)} call request sent successfully to ${agentName}`, true);
            },
            // on timeout callback
            onTimeout: function (paramType) {
                log.LogDetails("Info", "agent_chat.start_video()", `${agentName} has not responsed to the ${paramType} request`, true);
            },
            // on error callback
            onError: function (paramType, err) {
                log.LogDetails("Error", "agent_chat.start_video()", `${ToCamelCase(paramType)} call request to ${agentName} failed: ${err}`, true);
            }
        });

        // add to the request reference
        this.req_ref.push(agentId);
    },
    sendRequest: function (agentId, agentName, param) {

        //init the request
        let _req = null;

        //init json data for conference agent list
        let jsonData = "";

        //check if already a call going on 
        if (this.getConnectedCount() > 0) {

            //TODO:: get confirmation on the request if conference call

            //create a conference request
            _req = {
                type: "request",
                param: param,
                mode: "conference"
            };

            //get the list of connected agents
            jsonData = JSON.stringify(this.getAllAgents());

        }
        else {
            //create a request message
            _req = {
                type: "request",
                param: param,
                mode: ""
            };
        }

        //send the request message to remote agent
        this.sendAVMessage(agentId, "request", JSON.stringify(_req), jsonData);

        //add to the request reference
        this.req_ref.push(agentId);

        log.LogDetails("Success", "agent_chat.sendRequest()", `${ToCamelCase(param)} call request sent successfully to ${agentName}`, true);

        //check after 10s whether the agent has responsed within, if not cancel the request
        setTimeout(function (x) {

            //check if the agent has responded in 10s
            if (_this.req_ref.indexOf(x.agentId) >= 0) {

                //create a response message to close the request
                let _res = {
                    type: "response",
                    param: x.param,
                    status: "no-answer"
                };

                //send the request message to remote agent
                _this.sendAVMessage(x.agentId, "response", JSON.stringify(_res), jsonData);

                //remove from the request reference
                _this.req_ref = _this.req_ref.filter(function (r) { return r !== x.agentId; });

                //alert the message
                log.LogDetails("Error", "agent_chat.sendRequest()", `${x.agentName} has not responsed to the request`, true);

            }

        }, 10000, { agentId: agentId, agentName: agentName, param: param });

    },
    sendMeetingRequest(agentId, token, tmacServer) {

        //create a request message
        let _req = {
            type: "m-request",
            param: "meeting",
            token: token
        };

        //send the request message to remote agent
        this.sendAVMessage(agentId, "m-request", JSON.stringify(_req), "", tmacServer);

    },
    startAVConnection: function (agentId, agentName, param) {
        try {

            // check if the type is number
            if (param === "" || isNaN(param)) {
                log.LogDetails("Error", "agent_chat_av.startAVConnection()", `type should be a number, type=${param}`, false);
                return;
            }

            //init the conn
            let conn = {};

            //create a session id
            let sessionId = "ac_" + moment(new Date()).format("YYYYMMDDHHmmssSSS") + "_" + agentId;

            //create the AV connection by calling AVChannel constructor
            conn = new AVChannel(
                agentId,
                global_AgentID,
                global_AgentName,
                sessionId,
                "voice"
            );

            //on connection connected
            conn.onConnected = function () {
                console.log('AgentAV: onConnected');
                $("#video_call_dialog").data("kendoWindow").center().open();
            };

            //on connection disconnected
            conn.onDisconnected = function () {

                // //get the agent info
                // let agentInfo = agent_chat.get_agent_chat_ref(agentId);

                // //get all the streams and clear the column
                // this._remoteStreams.forEach(function (stream) {

                //     //remove the video tag of the agent
                //     $("#vid_" + stream.id).remove();

                // });

                // //remove the style from the li
                // $('li[data-user-id="' + agentId + '"]').find('.md-list-addon-element').css("background", "");

                // //remove the created reference on end
                // _this.remove(agentId);

                // //TODO:: for audio and meeting create new dialog
                // //if this is the last agent to end close the video dialog
                // if (_this.getCount() === 0) {
                //     $("#video_call_dialog").data("kendoWindow").close();
                // }

                //alert the message
                log.LogDetails("Error", "agent_chat_av.onDisconnected()", `${agentName} got disconnected from ${this._audioonly ? 'audio' : 'video'} call`, true);

            };

            //on connection remote video added
            conn.onRemoteVideoAdded = function (stream, streamInfo) {
                console.log('AgentAV: onRemoteVideoAdded', streamInfo);

                // get the remote video container
                let videoGrid = document.getElementById('video_call_remote');

                // TODO:: to find the person talking from the stream
                // _this.start_audio_analyser(stream, that);

                // check if the stram is already added
                if (document.getElementById("vid_" + stream.id)) {
                    log.LogDetails("info", "agent_chat_av.startAVConnection()", "video stream is already added", false);
                    return;
                }

                // create a video tag
                let v = document.createElement('video');;

                // add id to the tag
                v.id = "vid_" + stream.id;

                // append to the div
                videoGrid.appendChild(v);

                //let rowsLength = table.rows.length;

                ////if there is no row create the row and col
                //if (rowsLength === 0) {

                //    //create new row
                //    let newRow = table.insertRow(-1);

                //    //create a new cell
                //    let newCol = newRow.insertCell(-1);

                //    //append the id
                //    newCol.id = "col_" + stream.id;

                //    //append the col
                //    newCol.appendChild(v);

                //}
                //else {

                //    //get the last row
                //    let row = table.rows[table.rows.length - 1];

                //    //get the cells of this selected row
                //    let col = row.cells;

                //    if (col.length % 3 === 0) {

                //        //create new row
                //        let newRow = table.insertRow(-1);

                //        //create a new cell
                //        let newCol = newRow.insertCell(-1);

                //        //append the id
                //        newCol.id = "col_" + stream.id;

                //        //append the col
                //        newCol.appendChild(v);

                //    }
                //    else {

                //        //create a new col
                //        let newCol = row.insertCell(-1);

                //        //append the id
                //        newCol.id = "col_" + stream.id;

                //        //append the col
                //        newCol.appendChild(v);

                //    }

                //}
                // set the video attributes
                v.setAttribute('autoplay', 'autoplay');
                v.setAttribute('muted', 'muted');
                v.setAttribute('playsinline', 'true');

                // add event listner to loadedmetadata event
                v.addEventListener('loadedmetadata', function () {
                    v.width = this.videoWidth;
                    v.height = this.videoHeight;
                    console.log('AgentAV: Remote video videoWidth: ' + this.videoWidth + 'px,  videoHeight: ' + this.videoHeight + 'px');
                });

                // set the stream to tag
                v.srcObject = stream;

                // on resize of tag
                v.onresize = function () {
                    console.log('AgentAV: Remote video size changed to ' + this.videoWidth + 'x' + this.videoHeight);
                };

                console.log('AgentAV: Added stream to video element ' + stream.id);
            };

            //on hold or unhold
            conn.onHoldUnhold = function (hold) {

                log.LogDetails("Info", "agent_chat_av.startAVConnection: onHoldUnhold - " + hold, false);

            };

            //to send the WebRTC messages
            conn.sendMessage = function (msg, type, sessionId) {

                //get the remote agent id from the session id
                let agentId = sessionId.split('_')[2];

                //send the av messages to remote agent
                _this.sendAVMessage(agentId, type, msg, "");

            };

            // on incoming call
            conn.onIncoming = function (paramType, response) {
                // check if the agent in available state, then alert and return
                if (global_CurrentStatus === "Available") {
                    response(true);
                    return;
                }

                // confirm the request
                _this.requestDialog = UIkit.modal.confirm(`Do you want to accept ${paramType} call from ${agentName}?`,
                    function () {
                        response(true);
                    },
                    function oncancel() {
                        response(false);
                    });
            };

            // on call failed
            conn.onFail = function (code, error) {
                // check the code
                if (code === WrcErrorCodes.Rejected) {
                    log.LogDetails("Error", "agent_chat_av.startAVConnection()", `${agentName} has rejected your request`, true);
                }
                else if (code === WrcErrorCodes.MediaFailed) {
                    log.LogDetails("Error", "agent_chat_av.startAVConnection()", error, true);
                }
                else if (code === WrcErrorCodes.RequestTimeout) {
                    _this.requestDialog.hide();
                    log.LogDetails("Error", "agent_chat_av.startAVConnection()", `You have missed a ${conn.getCallMode()} call from ${agentName}`, true);
                }
            };

            // on call end 
            conn.onEnd = function (reason) {
                // clear the av tags
                $('#video_call_remote').empty();

                //remove the style from the li
                $('li[data-user-id="' + agentId + '"]').find('.md-list-addon-element').css("background", "");

                //alert the message
                log.LogDetails("Info", "agent_chat.chat_received()", `${agentName} has ended the call`, true);

                //remove the created reference on end
                _this.remove(agentId);

                //TODO:: for audio and meeting create new dialog
                //if this is the last agent to end close the video dialog
                if (_this.getCount() === 0) {
                    $("#video_call_dialog").data("kendoWindow").close();
                }
            };

            // layout for the call
            conn._localVideo = "video_call_agent";

            //apply style to the li
            $('li[data-user-id="' + agentId + '"]').find('.md-list-addon-element').css("background", "#7cb342");

            //add to the av reference
            this.set(agentId, conn);

            return conn;
        } catch (ex) {
            log.LogDetails("Error", "agent_chat_av.startAVConnection()", ex, false);
        }
    },
    set: function (agentId, conn) {

        //check if already a connection created for the same agent
        if (this.get(agentId)) {
            // log.LogDetails("Info", "agent_chat_av.set()", `agent[${agentId}]reference already exist`, false);
            return;
        }

        //get the agent referece based on agent id from 'agent_chat' object
        let agent = agent_chat.get_agent_chat_ref(agentId);

        //if the agent not in reference, return
        if (!agent) {
            log.LogDetails("Error", "agent_chat_av.set()", `agent[${agentId}]reference not available`, false);
            return;
        }

        //{
        //    FromTmacServer: "",
        //    FromAgentId: "",
        //    FromAgentName: ""
        //}

        //add the agent info and connection to the reference
        this.av_conn.push({ agent: agent, conn: conn });

    },
    get: function (agentId) {

        //filter the agent referece based on agent id
        let filter = this.av_conn.filter(function (a) { return a.agent.FromAgentId === agentId; });

        //if there are any item then return the object
        if (filter.length > 0) {
            return filter[0];
        }

        //else return null
        return null;

    },
    getAll: function () {

        //return all the reference available
        return this.av_conn;

    },
    getCount: function () {

        //return the total count of connection available
        return this.av_conn.length;

    },
    getConnectedCount: function () {
        //return the total count of connected connections
        return this.av_conn.filter(function (a) { return a.conn.isConnected(); }).length;
    },
    getAllAgents: function () {

        //init the list
        let agents = [];

        //get the connected agent list
        this.av_conn.forEach(function (item) {

            //check if the agent is connected
            if (item.conn.isConnected()) {

                //add to the list
                agents.push(item.agent);

            }

        });

        //return the list
        return agents;

    },
    remove: function (agentId) {

        //remove the agent reference
        this.av_conn = this.av_conn.filter(function (a) { return a.agent.FromAgentId !== agentId; });

    },
    sendAVMessage: function (agentId, type, message, jsonData, tmacServer) {

        //get the agent reference
        let agent = agent_chat.get_agent_chat_ref(agentId);

        //check if agent reference available
        if (!agent && !tmacServer) {
            log.LogDetails("Error", "agent_chat_av.sendAVMessage()", `agent[${agentId}]reference not available`, false);
            return;
        }

        //send the message to remove agent
        tmac_SendAgentAVMessage(function (res, obj) { }, null, agentId, tmacServer ? tmacServer : agent.FromTmacServer, type, message, jsonData);

    },
    avMessageReceived: function (event) {

        console.log(`%c avMessageReceived ${event.FromAgentId} - ${event.Type} `, "color: #fff; background: #1976d2");
        console.log(JSON.parse(event.Message));

        // check if the request, then create a connection
        if (event.Type === 'requestav') {
            // check if this agent details are available in the reference
            if (!agent_chat.get_agent_chat_ref(event.FromAgentId)) {
                // add to the reference
                agent_chat.agentlist_loaded([{
                    LoginID: event.FromAgentId,
                    AgentName: event.FromAgentName,
                    Profile: "NA",
                    CurrentAgentStatus: "NA",
                    TmacServer: event.FromTmacServer
                }]);
            }
            // start an av connection
            this.startAVConnection(event.FromAgentId, event.FromAgentName, WrcGetCallCode(JSON.parse(event.Message).param));
        }

        // process all the av messages
        _this.get(event.FromAgentId).conn.onMessage(event.Message);
    },
    startAudioAnalyser: function (stream, instance) {

        audioContext = new AudioContext();
        analyser = audioContext.createAnalyser();
        microphone = audioContext.createMediaStreamSource(stream);
        javascriptNode = audioContext.createScriptProcessor(2048, 1, 1);

        analyser.smoothingTimeConstant = 0.8;
        analyser.fftSize = 1024;

        microphone.connect(analyser);
        analyser.connect(javascriptNode);
        javascriptNode.connect(audioContext.destination);

        javascriptNode.onaudioprocess = function () {
            var array = new Uint8Array(analyser.frequencyBinCount);
            analyser.getByteFrequencyData(array);
            var values = 0;
            var length = array.length;
            for (var i = 0; i < length; i++) {
                values += (array[i]);
            }
            var average = values / length;
            // if (Math.round(average) > 20)
            console.log(instance.getSessionId() + " talking, at level=" + average);
        };
    }
};

let ac_av_icons = {
    mute_audio_icon: null,
    mute_video_icon: null,
    hungup_icon: null,
    //viewchange_icon: null,
    init: function () {
        this.mute_audio_icon = new this.icons_set("#mute-audio");
        this.mute_video_icon = new this.icons_set("#mute-video");
        this.hungup_icon = new this.icons_set("#hangup");
        //this.viewchange_icon = new this.icons_set("#view-change");

        //this reference inside function
        let _that = this;

        //on mute/unmute audio button click
        this.mute_audio_icon.element.onclick = function () {

            //check if muted
            let muted = _that.mute_audio_icon.toggle();

            //get all the reference and mute/unmute the stream
            agent_chat_av.getAll().forEach(function (item) {
                //check if connected
                if (item.conn.isConnected()) {
                    if (muted) {
                        //if muted then unmute
                        item.conn.unMute(true, false);
                    }
                    else {
                        //if unmuted then mute
                        item.conn.mute(true, false);
                    }
                }
            });
        };

        //on mute/unmute video button click
        this.mute_video_icon.element.onclick = function () {

            //check if muted
            let muted = _that.mute_video_icon.toggle();

            //get all the reference and mute/unmute the stream
            agent_chat_av.getAll().forEach(function (item) {
                //check if connected
                if (item.conn.isConnected()) {
                    if (muted) {
                        //if muted then unmute
                        item.conn.unMute(false, true);
                    }
                    else {
                        //if unmuted then mute
                        item.conn.mute(false, true);
                    }
                }
            });
        };

        //on hungup button click
        this.hungup_icon.element.onclick = function () {

            //get confirmation from agent to end
            UIkit.modal.confirm("Are you sure to end the call?",
                function () {

                    //get all the reference and end the stream
                    agent_chat_av.getAll().forEach(function (item) {
                        //chcek if connected
                        if (item.conn.isConnected()) {
                            //clear the connection elements
                            item.conn.endCall();
                        }

                        // clear the av tags
                        $('#video_call_remote').empty();

                        //remove the style from the li
                        $('li[data-user-id="' + item.agent.FromAgentId + '"]').find('.md-list-addon-element').css("background", "");

                        //remove the reference for the agent
                        agent_chat_av.remove(item.agent.FromAgentId);

                    });

                    //TODO:: for audio and meeting create new dialog
                    //since the agent end the chat, close the video dialog
                    $("#video_call_dialog").data("kendoWindow").close();
                });
        };

        //on view change button click
        //this.viewchange_icon.element.onclick = function () {

        //};
    },
    icons_set: function (iconSelector) {
        this.element = document.querySelector(iconSelector);
    }
};

ac_av_icons.icons_set.prototype.toggle = function () {
    let contains = false;
    if (this.element.classList.contains("on")) {
        contains = true;
        this.element.classList.remove("on");
    } else {
        contains = false;
        this.element.classList.add("on");
    }
    return contains;
};

$('#chatboxes').on('click', '> li', function (e) {

    // only continue if the target itself has been clicked, ingore click on more action
    if (e.target === $(".more-action-icon")[0]) return;

    var source = $("#chatbox_template").html();
    var $this = $(this),
        isActive = $this.hasClass('chatbox_active');
    var conv = [];
    var lastAdded = "";
    var agentId = $(this).attr('data-user-id');
    var chatTranscriptObj = tmacAgentChatObj.sort(sort_by('time', false, parseInt));
    $.each(chatTranscriptObj, function (i, val) {
        if (val.agentId === agentId) {
            if (val.type === "own") {
                if (lastAdded !== "own" || conv.length === 0)
                    conv.push({
                        own: true,
                        messages: [{
                            time: val.time,
                            text: val.message
                        }]
                    });
                else
                    conv[conv.length - 1].messages.push({
                        time: val.time,
                        text: val.message
                    });
            } else {
                if (lastAdded !== "other" || conv.length === 0)
                    conv.push({
                        //avatarUrl: 'assets/img/' + $(this).attr('data-user-avatar') + '.png',
                        avatarUrl: '',
                        messages: [{
                            time: val.time,
                            text: val.message
                        }]
                    });
                else
                    conv[conv.length - 1].messages.push({
                        time: val.time,
                        text: val.message
                    });
            }
            lastAdded = val.type;
        }
    });
    var template = Handlebars.compile(source);
    var messages_template = Handlebars.compile($("#chatbox_messages").html());
    if (!isActive) {
        $this.addClass('chatbox_active');
        var context = {
            username: $(this).attr('data-user'),
            agentid: $(this).attr('data-user-id'),
            conversation: conv
        };
        Handlebars.registerPartial("conversation", $("#chatbox_conversation").html());
        Handlebars.registerPartial("messages", $("#chatbox_messages").html());
        var html = template(context);
        $chatbox_wrapper.prepend(html);
        if (global_UserProfileForAgent === "A")
            $("#showDetailsBtn" + $(this).attr('data-user-id')).hide();
        var $chatbox = $chatbox_wrapper.children('.chatbox:first-child'),
            $chatbox_content = $chatbox.find('.chatbox_content');

        $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);

        //$chatbox_content.height($chatbox.closest('.chatbox').height() - $chatbox.find('.chatbox_header').height() - $chatbox.find('.chatbox_footer').height() );

        // message input autosize
        var $messageInput = $chatbox_wrapper.find('.message_input');
        autosize($messageInput);

        $messageInput.on('autosize:resized', function () {
            $chatbox.css({
                'padding-bottom': $messageInput.outerHeight()
            });
        });
        $chatbox.find(".chatbox_max").toggle();
        altair_secondary_sidebar.hide_sidebar();

        //remove the class if enabled
        if (typeof isAgentAVChat !== "undefined" && isAgentAVChat) {
            $(".agent-chat-actions").removeClass("uk-display-none-important");
        }
    }
});

/* handlebars helpers */
//  moment syntax example: moment(Date("2011-07-18T15:50:52")).format("MMMM YYYY")
//  usage: {{dateFormat creation_date format="MMMM YYYY"}}
Handlebars.registerHelper('dateFormat', function (context, block) {
    if (window.moment) {
        var f = block.hash.format || "MMM DD, YYYY hh:mm:ss A";
        return moment(context).format(f); //had to remove Date(context)
    } else {
        return context; //  moment plugin not available. return data as is.
    }
});

// extended "if" block helper
// usage {{#ifCond var1 '==' var2}}
Handlebars.registerHelper('ifCond', function (v1, operator, v2, options) {
    switch (operator) {
        case '==':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '===':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '!==':
            return (v1 !== v2) ? options.fn(this) : options.inverse(this);
        case '<':
            return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=':
            return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>':
            return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=':
            return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&':
            return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||':
            return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default:
            return options.inverse(this);
    }
});

/**
 * The {{#exists}} helper checks if a variable is defined.
 */
Handlebars.registerHelper('exists', function (variable, options) {
    if (typeof variable !== 'undefined') {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});

$(function () {
    $body.addClass('sidebar_secondary_persisten');

    //agent_chat.agentlist();
    //agent_chat.chat_list();

    agent_chat.chatboxes();

    $("#agent_list_search").on("keyup", function (e) {
        agent_chat.search_agent(e);
    });

    //add hover listner
    $("#video_call_dialog").hover(function () {
        $("#icons").addClass("active");
    }, function () {
        $("#icons").removeClass("active");
    });

    //check if agent av chat is enabled, then init the av icons
    if (typeof isAgentAVChat !== "undefined" && isAgentAVChat) {
        // init the av icons
        ac_av_icons.init();
        // set the local video draggable
        new DraggableElement(document.getElementById('video_call_agent'));
    }
});