// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "FaxUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

$(function () {
    FaxConfigurations();
    GetFaxLineNumbers();
    if (isPrintFax) {
        window.onafterprint = function (arg) {
            console.log(arg);
        };
    }
    GetFaxTemplateNames();
});

function OpenComposeFax() {
    try {
        //update the templates
        GetFaxTemplateNames();
        faxInteractionId = "";
        //create an initial faxitem
        CreateFaxItemGrid("fax_item_template", "faxItemContainer", faxItemId, "body");
        //if send fax to address book is enabled then show the dropdown
        if (isSendFaxToGroup) {
            $("#faxNumberGroupsContainer").removeClass("uk-display-none");
        }
        //create cover page selector
        if (isfaxCoverPage) {
            $("#coverPageContainer").html("");
            CreateFaxItemGrid("fax_item_template", "coverPageContainer", 0, "cover");
        }
        //open fax compose dialog
        $("#compose_fax_dialog").data("kendoWindow").center().open().element.closest(".k-window").css({
            top: 50
        });
        //enable the buttons incase if its disabled
        EnableButton("#btnSendFax", "Send", "tag");
        EnableButton("#btnAddFaxItem", "add", "icon");
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.OpenComposeFax()", ex, false);
    }
}

function FaxConfigurations() {
    try {
        //DNISList list dropdown
        $("#DNISList").kendoDropDownList();
        //FaxNumber selectize
        if (maxFaxLineRecipents > 1) {
            faxNumberSelect = $('#faxNumber').selectize({
                plugins: {
                    'remove_button': {
                        label: ''
                    }
                },
                maxItems: maxFaxLineRecipents,
                delimiter: ';',
                persist: false,
                create: function (input) {
                    if (input.length > maxFaxLineNumberLength) {
                        log.LogDetails("Error", "FaxUI.OpenComposeFax()", "Max fax number length is " + maxFaxLineNumberLength, true);
                        return false;
                    }

                    if (input.startsWith(internationFaxPrefix) && !isFaxInternationalEnabled) {
                        log.LogDetails("Error", "FaxUI.OpenComposeFax()", "You don't have previlage to send international fax", true);
                        return false;
                    }

                    if ((new RegExp('^[0-9]*$', 'i')).test(input)) {
                        return { value: input, text: input };
                    }

                    log.LogDetails("Error", "FaxUI.OpenComposeFax()", "Invalid fax number...", true);
                    return false;
                },
                onDropdownOpen: function ($dropdown) {
                    $dropdown
                        .hide()
                        .velocity('slideDown', {
                            begin: function () {
                                $dropdown.css({ 'margin-top': '0' });
                            },
                            duration: 200,
                            easing: easing_swiftOut
                        });
                },
                onDropdownClose: function ($dropdown) {
                    $dropdown
                        .show()
                        .velocity('slideUp', {
                            complete: function () {
                                $dropdown.css({ 'margin-top': '' });
                            },
                            duration: 200,
                            easing: easing_swiftOut
                        });
                }
            });
            $("#faxNumber").removeAttr("onkeypress");
        }
        else {
            $("#faxNumber").removeClass("uk-margin-small-top");
            $("#faxNumber").addClass("md-input label-fixed");
            $("#faxNumber").attr("maxlength", maxFaxLineNumberLength);
            altair_md.inputs("#compose_fax_dialog");
        }
        //if multiple items can be selected then enable
        if (isSendMultipleFaxItems) {
            ShowFaxAddOnButton();
        }
        //if fax cover page is enabled
        if (isfaxCoverPage) {
            $("#faxCoverPageContainer").removeClass("uk-display-none");
            //on change of cover page switch
            $('#cover_page_switch').change(function () {
                var coverPageRef = GetFaxAddOnReference(0);
                //clear the file if file is selected
                if (coverPageRef && coverPageRef.itemType === "file") {
                    $("#div_fax_upload_0 .k-icon.k-i-close.k-i-x").click();
                }
                //clear the template if template is selected
                else if (coverPageRef && coverPageRef.itemType === "template") {
                    $("#faxTemplates_0").data("kendoDropDownList").value("");
                    $("#faxTemplates_0").data("kendoDropDownList").text("Select a template...");
                }
                if (this.checked === true) {
                    addCoverPage = true;
                    $("#coverPageContainer").removeClass("uk-display-none");
                    if (coverPageType === "template") {
                        $("#div_fax_upload_0").addClass("uk-display-none");
                        $("#div_fax_templates_0").removeClass("uk-display-none");
                    }
                } else {
                    addCoverPage = false;
                    $("#coverPageContainer").addClass("uk-display-none");
                }
                TriggerResize();
            });
        }

        //if address book enabled
        if (isSendFaxToGroup) {
            //04-06-2019, if send fax to group is true then get register on select for dnis list
            //and get the associated fax group for the fax line and fax reciepients 
            $("#DNISList").data("kendoDropDownList").bind("select", function (arg) {
                GetFaxAddressBook(arg.dataItem);
            });
            //create kendo drop down list for number group
            $("#faxNumberGroups").kendoDropDownList({
                //optionLabel: "Select a group...",
                dataTextField: "AdddressBookName",
                dataValueField: "AdddressBookId",
                dataSource: [],
                select: function (e) {
                    GetFaxRecipients(e.dataItem.AdddressBookId);
                },
                enable: false
            });
            $("#faxNumberGroups").data("kendoDropDownList").text("Select an address book...");
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.FaxConfigurations()", ex, false);
    }
}

function ShowFaxAddOnButton() {
    try {
        $(".add-faxitem-btn-container").removeClass("uk-display-none");
        $(".add-faxitem-container").removeClass("uk-width-small-1-1");
        $(".add-faxitem-container").addClass("uk-width-small-5-6");
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.ShowFaxAddOnButton()", ex, false);
    }
}

function HideFaxAddOnButton() {
    try {
        $(".add-faxitem-btn-container").addClass("uk-display-none");
        $(".add-faxitem-container").removeClass("uk-width-small-5-6");
        $(".add-faxitem-container").addClass("uk-width-small-1-1");
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.HideFaxAddOnButton()", ex, false);
    }
}

function CreateFaxItemGrid(template, appender, id, type) {
    try {
        var fileTypeText = "";
        tempAddonTemplate = {};
        //get the body fileTypeText
        if (type === "body") {
            fileTypeText = "<strong>PDF</strong>, <strong>JPG</strong>, <strong>JPEG</strong> files";
        }
        //get the cover fileTypeText
        else {
            fileTypeText = "<strong>PDF</strong> file";
        }
        //get the template for faxitem
        var itemHtml = GetHtmlFromTemplate(template, "", { itemId: id, fileTypeText: fileTypeText });
        $("#" + appender).append(itemHtml);
        //if the type is body or type cover and coverPageType is dynamic or coverPageType is file create fileUploader
        if (type === "body" || (type === "cover" && coverPageType === "dynamic" || coverPageType === "file")) {
            //faxfile kendo uploads
            var uploader = $("#faxFiles_" + id).kendoUpload({
                async: {
                    saveUrl: global_connectedProxy + "UploadFaxFiles",
                    removeUrl: global_connectedProxy + "RemoveFaxFiles",
                    autoUpload: true
                },
                localization: {
                    select: "Select a file..."
                },
                validation: {
                    allowedExtensions: type === "body" ? [".pdf", ".jpg", ".jpeg"] : [".pdf"],
                    maxFileSize: maxFileUploadSize * 1024 * 1024
                },
                multiple: type === "body" && maxFileUploads > 1,
                upload: function (e) {
                    this.options.async.saveUrl = global_connectedProxy + "UploadFaxFiles";
                    var obj = {};
                    obj.id = id;
                    obj.agentId = global_AgentID;
                    e.data = obj;
                    DisableButton("#btnSendFax");
                    DisableButton("#btnAddFaxItem");
                    this.disable();
                },
                success: function (e) {
                    try {
                        var response = JSON.parse(e.XMLHttpRequest.statusText);
                        var result = JSON.parse(response);
                        //check if the faxAddonReference has items if not then return
                        if (faxAddonReference.length === 0) {
                            console.warn(e.operation + " - This can be on close of dialog");
                            return;
                        }
                        //get the uploaded item if there from the reference by id
                        var thisItem = GetFaxAddOnReference(!isNaN(result.id) ? parseInt(result.id) : result.id);
                        //if item is there then push/remove based on the type the result to the reference
                        if (thisItem) {
                            //if this is the success of upload then push the item to the reference
                            if (result.type === "save") {
                                thisItem.selectedItem.push(result.filePath);
                            }
                            //if this is the success of remove then remove from the reference
                            else if (result.type === "remove") {
                                thisItem.itemType = "";
                                thisItem.selectedItem.splice(thisItem.selectedItem.indexOf(result.filePath), 1);
                            }
                        }
                        else {
                            console.warn(e.operation + " - Item is not avaiable in reference: " + response);
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "FaxUI.CreateFaxItemGrid().success", ex, false);
                    }
                    this.enable();
                    EnableButton("#btnSendFax", "Send", "tag");
                    EnableButton("#btnAddFaxItem", "add", "icon");
                },
                error: function (e) {
                    //error
                    EnableButton("#btnSendFax", "Send", "tag");
                    EnableButton("#btnAddFaxItem", "add", "icon");
                    this.enable();
                },
                remove: function (e) {
                    this.options.async.saveUrl = global_connectedProxy + "RemoveFaxFiles";
                    var obj = {};
                    obj.id = id;
                    obj.agentId = global_AgentID;
                    e.data = obj;
                },
                progress: function (e) {
                    console.log(e.percentComplete);
                },
                complete: function (e) {
                    //$("#div_uk_progress_bar" + global_activeTabInteractionID).addClass("uk-display-none");
                },
                select: function (e) {
                    if (e.files.length > maxFileUploads || e.sender.getFiles().length >= maxFileUploads) {
                        log.LogDetails("Error", "FaxUI.CreateFaxItemGrid().kendoUpload()", "Max files allowed: " + maxFileUploads, true);
                        e.preventDefault(); // This cancels the upload for the file
                    }
                    var that = this;
                    setTimeout(function () {
                        GetFaxAddOnReference(id).itemType = "file";
                    }, 200, that, id);
                }
            }).data("kendoUpload");
            //add max file upload size text
            $(".maxFileSizeSpan").text(maxFileUploadSize);
        }
        //if the type is body or type is 'cover' && coverPageType is 'dynamic' or coverPageType is 'template' create template Dropdown
        if (type === "body" || (type === "cover" && coverPageType === "dynamic" || coverPageType === "template")) {
            var templates = [];
            //get the cover templates from faxTemplates for type 'cover'
            if (type === "cover") {
                templates = faxTemplates.filter(function (f) { return f.Type === "cover"; });
            }
            //get the cover templates from faxTemplates for type 'body'
            else if (type === "body") {
                templates = faxTemplates.filter(function (f) { return f.Type === "body"; });
            }
            //fax templates dropdown
            $("#faxTemplates_" + id).kendoDropDownList({
                dataTextField: "Name",
                dataValueField: "Type",
                dataSource: templates.length > 0 ? templates : [],
                select: function (arg) {
                    var item = arg.dataItem;
                    //OpenFaxTemplateEditor(id, item.Text, item.Value);
                    GetFaxTemplate(id, item.Name, item.Type);
                    //add the tempAddonTemplate
                    tempAddonTemplate.id = id;
                    tempAddonTemplate.name = item.Name;
                    tempAddonTemplate.value = item.Type;
                    //dont select the item to dropdown
                    arg.preventDefault();
                }
            });
            //add the init text in dropwdown
            $("#faxTemplates_" + id).data("kendoDropDownList").text("Select a template...");
        }
        //if the type is body or type is cover && coverPageType is dynamic 
        if (type === "body" || (type === "cover" && coverPageType === "dynamic")) {
            //on change event for fax item select
            $('input[type=radio][name=fax_compose_radio_' + id + ']').change(function () {
                //if the type is body then on change clear other than cover and first item
                if (type === "body") {
                    $.each(faxAddonReference, function (i, val) {
                        //except the cover, the first and the current one remove all
                        if (val.id !== 0 && val.id !== 1 && id !== val.id) {
                            //if the type is file then remove the item
                            if (val.itemType === "file") {
                                $("#div_fax_upload_" + val.id + " .k-icon.k-i-close.k-i-x").click();
                            }
                            RemoveAddOnFaxItem(val.id);
                        }
                    });
                }
                //clear the file if file is selected
                if (GetFaxAddOnReference(id).itemType === "file") {
                    $("#div_fax_upload_" + id + " .k-icon.k-i-close.k-i-x").click();
                }
                //clear the template if template is selected
                else if (GetFaxAddOnReference(id).itemType === "template") {
                    $("#faxTemplates_" + id).data("kendoDropDownList").value("");
                    $("#faxTemplates_" + id).data("kendoDropDownList").text("Select a template...");
                }
                //on click of upload radio button
                if (this.value === 'uploadFile') {
                    $("#div_fax_upload_" + id).toggle();
                    $("#div_fax_templates_" + id).toggle();
                }
                //on click of template radio button
                else if (this.value === 'selectTemplate') {
                    $("#div_fax_upload_" + id).toggle();
                    $("#div_fax_templates_" + id).toggle();
                }
                //clear faxAddOnReference for that item
                GetFaxAddOnReference(id).itemType = "";
                GetFaxAddOnReference(id).selectedItem = [];
                TriggerResize();
            });
        }
        //if the type is cover and the coverPageType is not dynamic then remove faxaddon
        if (type === "cover" && coverPageType !== "dynamic") {
            $("#fax_addon_select_container_" + id).remove();
        }
        //push the initial faxAddonReference
        faxAddonReference.push({ id: id, itemType: "", selectedItem: [] });
        //if the id is 0 i.e cover page or for the first item do not show remove item icon
        if (id === 0 || id === 1) {
            $("#removeAddOnFaxItemBtn_" + id).remove();
        }
        //if the type is body
        if (type === "body") {
            faxItemId++;
            //check if this item is reached to max multiple fax items then hide add on button 
            if (faxAddonReference.length - 1 === maxMultipleFaxItems) {
                HideFaxAddOnButton();
            }
            //if any type is restricted in restrictFirstFaxItem then do no allow then add new item if the first item is restricted
            if (restrictFirstFaxItem && faxAddonReference.length >= maxMultipleFaxItems) {
                var selectType = restrictFirstFaxItem === "file" ? "faxUploadRadio_" : "faxTemplateRadio_";
                $("#" + selectType + id).click();
                $("#fax_addon_select_container_" + id).remove();
            }
        }

        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.CreateFaxItemGrid()", ex, false);
    }
}

function RemoveAddOnFaxItem(itemId) {
    try {
        var item = GetFaxAddOnReference(itemId);
        if (item && item.itemType === "file") {
            $("#div_fax_upload_" + itemId + " .k-icon.k-i-close.k-i-x").click();
        }
        $("#fax_addon_container_" + itemId).remove();
        faxAddonReference = faxAddonReference.filter(function (i) { return i.id !== itemId; });
        if (faxAddonReference.length - 1 < maxMultipleFaxItems) {
            ShowFaxAddOnButton();
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.RemoveAddOnFaxItem()", ex, false);
    }
}

function GetFaxAddOnReference(itemId) {
    return faxAddonReference.filter(function (i) { return i.id === itemId; })[0];
}

function SendFaxToServer() {
    try {
        var DNIS = $("#DNISList").data("kendoDropDownList").value();
        var faxNumber = $("#faxNumber").val();

        if (DNIS === "") {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "Please select a fax line", true);
            return;
        }
        else if ($.trim(faxNumber) === "") {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "Please enter a fax number", true);
            return;
        }
        //check for single recipient whether isFaxInternationalEnabled
        else if (maxFaxLineRecipents === 1 &&
            faxNumber.startsWith(internationFaxPrefix) && !isFaxInternationalEnabled) {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "You don't have previlage to send international fax", true);
            return;
        }
        //check for multiple recipient whether isFaxInternationalEnabled
        else if (maxFaxLineRecipents > 1 &&
            faxNumber.split(';').filter(function (f) { return f.startsWith(internationFaxPrefix); }).length > 0 &&
            !isFaxInternationalEnabled) {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "You don't have previlage to send international fax", true);
            return;
        }
        //check for single recipient whether DNIS and faxNumber are same
        else if (maxFaxLineRecipents === 1 && DNIS === $.trim(faxNumber)) {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "Fax line and fax number can not be same", true);
            return;
        }
        //check for multiple recipient whether DNIS and faxNumbers are same
        else if (maxFaxLineRecipents > 1 && faxNumber.split(';').filter(function (f) { return f === DNIS; }).length > 0) {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", "Fax line and fax number can not be same", true);
            return;
        }

        var canSend = true;
        var errorMessage = "";

        //remove the cover page item reference from faxAddonReference if its not enabled
        if (!addCoverPage) {
            faxAddonReference = faxAddonReference.filter(function (f) { return f.id !== 0; });
        }

        //validate the items before send
        $.each(faxAddonReference, function (i, val) {
            //check if the cover page switch is selected and cover page is selected
            //if not then show the error message
            if (addCoverPage && val.id === 0 && val.selectedItem.length <= 0) {
                errorMessage = "Please select the cover page or deselect the checkbox";
                canSend = false;
                return;
            }
            //if the cover page is selected alone then allow to send
            else if (addCoverPage && val.id === 0 && val.selectedItem.length > 0) {
                canSend = true;
                return;
            }
            //check if the item is seleted if cover page is not selected
            if (val.id !== 0 && val.selectedItem.length <= 0) {
                canSend = false;
                errorMessage = "Please select an item";
                return;
            }
        });

        if (!canSend) {
            log.LogDetails("Error", "FaxUI.SendFaxToServer()", errorMessage, true);
            return;
        }

        SendMultipleFaxItem(faxInteractionId, faxNumber, DNIS, JSON.stringify(faxAddonReference));

        log.LogDetails("Info", "FaxUI.SendFaxToServer()", "We are processing your fax, please check the sent status", true);

        $("#compose_fax_dialog").data("kendoWindow").close();

    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SendFaxToServer()", ex, false);
    }
}

function NewFaxReceived(event) {
    try {
        var intid = event.InteractionID;
        var queueTimeColor = GetColorCode(event.QueueTime);
        //check the day in QueueTime
        var dCount = moment("2015-01-01").startOf('day').seconds(event.QueueTime).format("DD") - 1;
        //format the QueueTime to HH:mm:ss
        var fDate = moment("2015-01-01").startOf('day').seconds(event.QueueTime).format("HH:mm:ss");
        //if the QueueTime is more than a day, then add day to formatted QueueTime, add 0 prefix for number lessthen 10
        if (dCount) {
            fDate = ('0' + dCount).slice(-2) + ":" + fDate;
        }
        //update the QueueTime
        queueTimeInFormat = fDate;
        var headerTemplate = GetHtmlFromTemplate("tab_header_template", intid, { icon: "print" });
        var bodyTemplate = GetHtmlFromTemplate("fax_tab_template", intid, null);
        SaveTabReference("fax", intid, "new");
        AddTab(bodyTemplate, headerTemplate, intid, event.FaxNumber, true, true, false);
        if (isPrintFax) {
            $("#btnPrintFax" + intid).removeClass("uk-display-none");
        }

        //if reply to this dnis is not enabled then make the button red
        if (faxLineNumbers.indexOf(event.DNIS) < 0) {
            $("#btnReplyFax" + intid).removeClass("md-btn-facebook");
            $("#btnReplyFax" + intid).addClass("md-btn-danger");
        }

        //if isFaxOutEnabled is disabled then disable the button
        if (!isFaxOutEnabled) $("#btnReplyFax" + intid).addClass("disabled");

        //if isFaxPrintEnabled is disabled then disable the print button
        if (!isFaxPrintEnabled) $("#btnPrintFax" + intid).addClass("disabled");

        //Initialize the UIKit accordion for the created tab
        var accordion = UIkit.accordion($('#fax_accordion' + intid), {
            collapse: false,
            showfirst: false
        }),
            wrapper1 = accordion.find('[data-wrapper]').get(0), //0 as index of the content
            wrapper2 = accordion.find('[data-wrapper]').get(1); //1 as index of the content
        accordion.toggleItem(UIkit.$(wrapper1), true, false); // animated true and collapse true
        accordion.toggleItem(UIkit.$(wrapper2), true, false); // animated true and collapse true

        //show and append data workcodes if configured
        if (isWorkCode.fax && isWorkCode.fax.enable) BindWorkCodes(intid);

        var fileName = event.File.replace(/^.*[\\\/]/, '');
        $("#fileName" + intid).val(fileName);
        SaveFaxReference(intid, event, fileName);
        PreviewFax(event);
        $("#queueTime" + intid).val(queueTimeInFormat);
        $("#queueTime" + intid).css("color", queueTimeColor);
        setTimeout(function () { SetTabHeight(); });
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.NewFaxReceived()", ex, false);
    }
}

function PreviewFax(event) {
    try {
        var intid = event.InteractionID;
        var xhr = new XMLHttpRequest();
        xhr.responseType = 'arraybuffer';
        xhr.open('GET', event.File);
        xhr.onload = function (e) {
            $("#faxLoader" + intid).remove();
            var tiff = new Tiff({ buffer: xhr.response });
            var pageCount = 0;
            for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                tiff.setDirectory(i);
                var li = document.createElement("LI"),
                    canvas = tiff.toCanvas(),
                    tempCanvas = document.createElement('canvas'), //create a temp canvas
                    context = tempCanvas.getContext("2d"), //get the context of temp canvas
                    img = document.createElement('img'); //image tag to show

                //set temp canvas width to 1728
                tempCanvas.width = "1728";
                //set temp canvas height to 2200
                tempCanvas.height = "2200";
                //draw image of tiff extracted canvas to new temp canvas with req width/height
                context.drawImage(canvas, 0, 0, 1728, 2200);
                //get the temp canvas data URL and set to image
                img.src = tempCanvas.toDataURL();
                img.id = "file_" + intid + "_" + i;
                img.style.width = "100%";
                img.style.height = "100%";
                li.appendChild(img);
                $("#previewFax" + intid).append(li);
                ++pageCount;
            }
            GetFaxReferenceObj(intid).pageCount = pageCount;
            if (pageCount <= 1)
                $("#fax_uk_slider_" + intid).find(".uk-slidenav").remove();

            $("#pageCount" + intid).text(pageCount);
        };
        xhr.send();
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.PreviewFax()", ex, false);
    }
}

function ReplyToFax(intid) {
    try {
        //update the templates
        GetFaxTemplateNames();

        faxInteractionId = intid;

        var faxRef = GetFaxReferenceObj(intid), sessionID = faxRef.sessionId, DNIS = faxRef.DNIS, faxNumber = faxRef.faxNumber;

        if (faxLineNumbers.indexOf(DNIS) < 0) {
            log.LogDetails("Error", "FaxUI.ReplyToFax()", "Reply from Fax Line " + DNIS + " is disabled", true);
            return;
        }

        $("#DNISList").data("kendoDropDownList").value(DNIS);
        $("#DNISList").data("kendoDropDownList").readonly();


        //if send fax to address book is enabled then for reply we need to hide it
        if (isSendFaxToGroup) {
            $("#faxNumberGroupsContainer").addClass("uk-display-none");
        }

        if (maxFaxLineRecipents > 1) {
            faxNumberSelect[0].selectize.addOption({ value: faxNumber, text: faxNumber });
            faxNumberSelect[0].selectize.addItem(faxNumber);
        }
        else
            $("#faxNumber").val(faxNumber);

        //create an initial faxitem
        CreateFaxItemGrid("fax_item_template", "faxItemContainer", faxItemId, "body");
        //create cover page selector
        if (isfaxCoverPage) {
            $("#coverPageContainer").html("");
            CreateFaxItemGrid("fax_item_template", "coverPageContainer", 0, "cover");
        }

        $("#compose_fax_dialog").data("kendoWindow").center().open().element.closest(".k-window").css({
            top: 50
        });

        //enable the buttons incase if its disabled
        EnableButton("#btnSendFax", "Send", "tag");
        EnableButton("#btnAddFaxItem", "add", "icon");
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.ReplyToFax()", ex, false);
    }
}

function ForwardToFax(intid) {
    OpenFaxTransferDialog(intid);
}

function FaxTransferSuccess(data, obj) {
    try {
        var eventData = obj.eventData;
        log.LogDetails("Success", "FaxUI.FaxTransferSuccess()", "Fax transferred successfully to " + eventData.FromAgentName, true);
        setTimeout(function () {
            ForceCloseTab(eventData.InteractionID);
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.FaxTransferSuccess()", ex, false);
    }
}

function OpenFaxTransferDialog(intid) {
    try {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        FadeOutButton("#btndialogblindtransfercall");
        GetTmacWallboardSkills();
        DisableButton("#btnForwardFax" + intid);
        GetAgentListStaffed(intid, "transferCall", "#btnForwardFax" + intid, "forward");
        global_transferIntID = intid;
        //transfer type is changed to textchat
        global_CallType = "FaxTransfer";
        //disable transfer number textbox for chat as we need to select agent from grid
        $("#txtNumberTrans").attr("readonly", "readonly");
        //select the first agent list tab
        $("#tabstrip_transfer").data("kendoTabStrip").select(0);
        //check for the config to enable comments
        if (commentOnTransfer.Fax) {
            $("#transfer_comments").removeClass("uk-visibility-hidden");
        }
        $("#transfer_dialog").data("kendoWindow").title("Transfer Fax List");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatTransferDialog()", ex, false);
    }
}

function PrintFax(intid) {
    try {
        if (!isFaxPrintEnabled) {
            log.LogDetails("Error", "FaxUI.PrintFax()", "You don't have previlage to print the fax", true);
            return;
        }

        UIkit.modal.confirm('Are you sure, you want to print?',
            function () {
                UpdateFaxStatus(intid, "Completed");
                FadeOutButton("#btnPrintFax" + intid);
                //get the page count from fax reference
                var pageCount = GetFaxReferenceObj(intid).pageCount;
                //get the file name from fax reference
                var fileName = GetFaxReferenceObj(intid).fileName;
                //to store all the img id to print
                var fileIds = "";
                //get the img id's based on total count of page
                for (var i = 0; i < pageCount; i++) {
                    fileIds = fileIds + "#file_" + intid + "_" + i + ",";
                }
                //slice the last comma from the ids
                fileIds = fileIds.slice(0, -1);
                //print the img containers based on ids provided
                $(fileIds).printThis({
                    customCSS: false
                    //pageTitle: fileName // add title to print page
                });
                setTimeout(function () {
                    FadeInButton("#btnPrintFax" + intid);
                }, 1000);
            }, function () {
            });
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.PrintFax()", ex, false);
    }
}

function RotateFax(intid, type) {
    try {
        //get the page count from fax reference
        var pageCount = GetFaxReferenceObj(intid).pageCount;
        if (type === "left") {
            GetFaxReferenceObj(intid).currentAngle += 180;
        }
        else if (type === "right") {
            GetFaxReferenceObj(intid).currentAngle -= 180;
        }
        for (var i = 0; i < pageCount; i++) {
            $("#file_" + intid + "_" + i).css('transform', 'rotate(' + GetFaxReferenceObj(intid).currentAngle + 'deg)');
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.RotateFax()", ex, false);
    }
}

function AddFaxItem() {
    try {
        var canAdd = true;
        var limitFile = true;
        $.each(faxAddonReference, function (i, val) {
            if (val.id !== 0 && val.selectedItem.length <= 0) {
                canAdd = false;
                return;
            }
            if (val.id !== 0 && restrictFirstFaxItem && val.itemType === restrictFirstFaxItem.toLowerCase()) {
                limitFile = false;
                return;
            }
        });

        if (!canAdd) {
            log.LogDetails("Error", "FaxUI.AddFaxItem()", "Please select an item and add new item", true);
            return;
        }

        if (!limitFile) {
            log.LogDetails("Error", "FaxUI.AddFaxItem()", "Max item allowed exceeded", true);
            return;
        }

        CreateFaxItemGrid("fax_item_template", "faxItemContainer", faxItemId, "body");

    } catch (ex) {
        log.LogDetails("Error", "FaxUI.AddFaxItem()", ex, false);
    }
}

function OpenFaxTemplateEditor(id, template) {
    try {
        //if the template is there then only process else close and show error
        if (template) {
            tempSelectedAddonId = id;
            $("#fax_addon_id").val(id);
            //fade in submit button
            FadeInButton("#btnSaveAndSubmit");
            //remove the loader
            $("#faxTemplateLoader").addClass("uk-display-none");
            //show the template iframe
            $("#faxTemplateEditor").removeClass("uk-display-none");
            //append the template to the faxTemplateEditor iframe
            var doc = document.getElementById('faxTemplateEditor').contentWindow.document;
            //check if the frame is there
            if (doc) {
                doc.open();
                doc.write(template);
                // Adding keydown event listener for all text boxes to limit the new line count
                doc.querySelector('textarea').onkeydown = function (e) {
                    // If enter key is pressed
                    if (e.keyCode === 13) {
                        // Get max line attribute from the tag
                        var maxLine = this.getAttribute('max-line');
                        // Get line count attribute from the tag
                        var lineCount = this.getAttribute('line-count');
                        // Check whether tag has line-count attribute
                        if (lineCount) {
                            // convert text to integers
                            maxLine = parseInt(maxLine);
                            lineCount = parseInt(lineCount);
                            // if line count exceeds the max line
                            if (lineCount >= maxLine) {
                                // do not allow new line
                                e.preventDefault();
                                return false;
                            } else {
                                // Increment line count and allow new line
                                this.setAttribute('line-count', ++lineCount);
                                return true;
                            }
                        } else {
                            // Create line count attribute and initialize to 2
                            var att = document.createAttribute('line-count');
                            att.value = 2;
                            this.setAttributeNode(att);
                        }
                    }
                };
                doc.close();
            }
        }
        else {
            //clear the tempAddonTemplate reference
            tempAddonTemplate = {};
            //close the template editor dialog
            $("#fax_template_editor_dialog").data("kendoWindow").close();
            //show the error message
            log.LogDetails("Error", "FaxUI.OpenFaxTemplateEditor()", "Template is empty, Please try another template", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.OpenFaxTemplateEditor()", ex, false);
    }
}

function SendPullRequestDone(data, obj) {
    try {
        var isSuccess = false;
        if (data === 1) {
            isSuccess = true;
        }
        //return the response back to workbench iframe
        InvokePostMessage(
            obj.workbenchWindow,
            null,
            obj.callback,
            mergeObjects({ isSuccess: isSuccess }, obj.inputData),
            //{
            //    isSuccess: isSuccess,
            //    ...obj.inputData
            //},
            obj.userObject
        );
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SendPullRequestDone()", ex, false);
    }
}

function SaveAndSubmitTemplate() {
    try {

        UIkit.modal.confirm('Are you sure, you want to save and submit?',
            function () {
                var id = tempAddonTemplate.id;
                GetFaxAddOnReference(id).itemType = "template";
                if (GetFaxAddOnReference(id).selectedItem.length > 0) {
                    GetFaxAddOnReference(id).selectedItem = [];
                }
                //GetFaxAddOnReference(id).selectedItem.push($("#fax_template_editor").data("kendoEditor").value());
                //replace all the input tag with span tag and append its value
                $("#faxTemplateEditor").contents().find("html").find('input').each(function () {
                    $(this).replaceWith("<span>" + this.value + "</span>");
                });
                //replace all the textarea tag with span tag and append its value
                $("#faxTemplateEditor").contents().find("html").find('textarea').each(function () {
                    $(this).replaceWith("<span>" + this.value + "</span>");
                });
                //get the html to the reference
                GetFaxAddOnReference(id).selectedItem.push($("#faxTemplateEditor").contents().find("html")[0].outerHTML);
                //append the text in tempalate dropdown
                $("#faxTemplates_" + id).data("kendoDropDownList").text(tempAddonTemplate.name);
                $("#fax_template_editor_dialog").data("kendoWindow").close();
                //clear the tempAddonTemplate reference
                tempAddonTemplate = {};
                //clear the html content of faxTemplateEditor iframe
                var doc = document.getElementById('faxTemplateEditor').contentWindow.document;
                //check if the frame is there
                if (doc.length > 0) {
                    doc.open();
                    doc.write("");
                    doc.close();
                }
            }, function () {
            });
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SaveAndSubmitTemplate()", ex, false);
    }
}

function SaveFaxReference(intid, eventData, fileName) {
    try {
        //this is required ui as well as to send to server for transfer
        var faxRef = {};
        faxRef.intid = intid;
        faxRef.DNIS = eventData.DNIS;
        faxRef.faxNumber = eventData.FaxNumber;
        faxRef.sessionId = eventData.SessionID;
        faxRef.fileName = fileName;
        faxRef.skill = eventData.Skill;
        faxRef.queueTime = eventData.QueueTime;
        faxRef.filePath = eventData.FilePath;
        faxRef.tempFilePath = eventData.TempFilePath;
        faxRef.otherData = eventData.OtherData;

        faxRef.pageCount = 0;
        faxRef.currentAngle = 0;

        //push to the array for that interaction
        global_FaxReference.push(faxRef);
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SaveFaxReference()", ex, false);
    }
}

function GetFaxReferenceObj(intid) {
    try {
        for (var i = 0; i < global_FaxReference.length; i++) {
            if (global_FaxReference[i] !== undefined && global_FaxReference[i].intid === parseInt(intid))
                return global_FaxReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.GetFaxReferenceObj()", ex, false);
    }
}

function RemoveFaxReference(intid) {
    try {
        for (var i = 0; i < global_FaxReference.length; i++) {
            if (global_FaxReference[i] !== undefined && global_FaxReference[i].intid === parseInt(intid)) {
                global_FaxReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.RemoveFaxReference()", ex, false);
    }
}

function GetFaxTemplateRef(name) {
    try {
        for (var i = 0; i < faxTemplates.length; i++) {
            if (faxTemplates[i] !== undefined && faxTemplates[i].Name === name) {
                return faxTemplates[i];
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.GetFaxTemplateRef()", ex, false);
    }
}