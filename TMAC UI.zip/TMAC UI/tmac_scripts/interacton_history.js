// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "InteractionHistory.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

$(document).ready(function () {
    console.log('interaction history script loaded');
    // load the tempate
    $("#interaction_history_template").load("templates/InteractionHistory.html");

    //emoji path to initialize
    if (typeof emojione === "undefined") {
        LogThis("Warning", "IHScriptDocumentReady", "emojione script is not loaded, emoji disabled");
    }
});

function LogThis(type, method, msg, show) {
    try {
        if (show) {
            if (type.toLowerCase() === "error") {
                type = "danger";
            }
            ShowNotify(
                msg,
                type.toLowerCase(),
                null,
                "top-center"
            );
        }
        if (typeof window.console === "undefined") {
            return;
        }
        let m = "[" + new Date().toTimeString() + "] TMAC-IH" + (method ? "." + method : "") + ": " + msg;
        switch (type.toLowerCase()) {
            case "debug":
                if (console.debug) console.debug(m);
                else console.log(m);
                break;
            case "warning":
                console.warn(m);
                break;
            case "error":
            case "danger":
                console.error(m);
                break;
            default:
                console.log(m);
        }
    } catch (ex) {
        console.log(ex);
    }
}

function LoadInteractionHistory(cif, emailId, nric, phone, intId, myLastId) {
    try {
        //  ReviewCodeLine: VP : Jul 2, '20': Remove in the future. Not required anymore.
        // // check to enable openInNewTab
        // if (openInNewTab) {
        //     $("#openinnew_" + intId).removeClass("uk-display-none");
        // }
        // disable all the icons
        DisableIHIcons(intId);

        // set the initial data
        GetTabReferenceObj(intId).OtherData.multiHistoryRef = [];
        GetTabReferenceObj(intId).OtherData.interactionReference = [];

        // add the reference for home history
        GetTabReferenceObj(intId).OtherData.
            multiHistoryRef.push({
                active: true,
                instance: "home",
                data: [],
                isLoaded: false,
                lastId: 0,
                intId: intId,
                sort: "desc"
            });

        // check if isMultiHistory enabled, then create the swither and add reference
        if (isMultiHistory) {
            // show multi db labels
            $.each(multiHistoryInstanceNames, function (i, val) {
                GetTabReferenceObj(intId).OtherData.
                    multiHistoryRef.push({
                        active: false,
                        instance: val,
                        data: [],
                        isLoaded: false,
                        lastId: 0,
                        intId: intId,
                        sort: "desc"
                    });

                let igButton = '<button class="md-btn md-btn-wave disabled ig-button" onclick="GetInteractionHistoryByServer(' + AddSingleQuotes(val) + ', false, ' + AddSingleQuotes(intId) + ');" id="igButton_' + val + '_' + intId + '">' + val + ' <span class="uk-badge uk-badge-danger" id="badge_' + val + '_' + intId + '">0</span></button>';
                $("#instanceGroup_" + intId).append(igButton);

                let divNoData = '<div id="' + val + '_no_data_' + intId + '" class="no-ih-data uk-display-none"><i class="material-icons notranslate uk-text-muted">&#xE033;</i><br /><h1>No Data Available</h1></div>';
                let loader = '<div class="md-preloader md-preloader-warning" id="' + val + '_loader_' + intId + '"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="48" width="48" viewbox="0 0 75 75"><circle cx="37.5" cy="37.5" r="33.5" stroke-width="8" /></svg></div>';

                let divBody = '<div id="igHistory_' + val + '_' + intId + '" class="uk-display-none uk-animation-fade" style="padding-top : 10px;">' + loader + divNoData + '<div class="timeline timeline_small hierarchical_slide" id="' + val + '_timeline_' + intId + '" style="display:none;"></div></div>';

                $("#igHistory_" + intId).append(divBody);
            });
        }

        // check if any of the param is passed
        if (cif || emailId || nric || phone) {
            // create data to load history
            let obj = {};
            obj.CIF = cif; //cif
            obj.EmailID = emailId; //email
            obj.NRIC = nric; //nric
            obj.PhoneNumber = phone; //phone
            obj.myLastId = myLastId;
            obj.intId = intId;

            GetInteractionHistoryData(obj);
        }
        else {
            LogThis("Warning", "LoadInteractionHistory", "History parameters are empty/null, this can to load history with interaction");
        }
    } catch (ex) {
        LogThis("Error", "LoadInteractionHistory", ex);
    }
}

function GetInteractionHistoryData(historyParams) {
    try {
        let uObj = {
            instance: "home",
            intId: historyParams.intId
        };
        tmac_GetInteractionHistory("ProcessHistoryData", uObj, historyParams.CIF, historyParams.EmailID, historyParams.NRIC, historyParams.PhoneNumber, noOfRecords, historyParams.myLastId);

        //if multi history is enabled then get all the history count of instances
        if (isMultiHistory) {
            $.each(multiHistoryInstanceNames, function (i, val) {

                let muObj = {
                    instance: val,
                    intId: historyParams.intId
                };

                // call server and get the count of each instances
                tmac_GetInteractionHistoryCountByServer("ProcessHistoryCount", muObj, historyParams.CIF, historyParams.EmailID, historyParams.NRIC, historyParams.PhoneNumber, val);
            });
        }
    } catch (ex) {
        LogThis("Error", "GetInteractionHistoryData", ex);
    }
}

function GetInteractionHistoryByServer(instance, reload, intId) {
    try {
        //get the instace by instance name
        if (GetTabReferenceObj(intId).OtherData.multiHistoryRef.length > 0) {
            //set all reference of active to false
            $.grep(GetTabReferenceObj(intId).OtherData.multiHistoryRef, function (n, i) {
                n.active = false;
                $("#igHistory_" + n.instance + "_" + n.intId).addClass("uk-display-none");
            });
        }
        //get the instance
        let getInstance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (x) {
            return x.instance === instance;
        });
        //chcek if the instance data is present in the reference
        if (getInstance.length > 0) {
            //set active true
            getInstance[0].active = true;
            //check if the history is already loaded, if not load it
            if (!getInstance[0].isLoaded || reload) {
                //disable all the icons
                DisableIHIcons(intId);
                //get the history params
                let historyParams = GetHistoryParamById(intId);
                // create the  user object
                let muObj = {
                    instance: instance,
                    reload: reload,
                    intId: intId
                };
                // call the proxy and get the data
                tmac_GetInteractionHistoryByServer("ProcessHistoryData", muObj, historyParams.CIF, historyParams.EmailID, historyParams.NRIC, historyParams.PhoneNumber, noOfRecords, getInstance[0].lastId, getInstance[0].instance);
            }
            // add the sort style
            if (getInstance[0].sort) {
                if (getInstance[0].sort === "asc") {
                    $("#li_asc_" + intId)
                        .addClass("uk-active")
                        .siblings()
                        .removeClass("uk-active");
                }
                else if (getInstance[0].sort === "desc") {
                    $("#li_desc_" + intId)
                        .addClass("uk-active")
                        .siblings()
                        .removeClass("uk-active");
                }
            }
            $("#igHistory_" + instance + "_" + intId).removeClass("uk-display-none");
        }
        else {
            LogThis("Error", "GetInteractionHistoryByServer", "Cannot find the reference of instance: " + instance, false);
            EnableIHIcons(intId);
            $("#reload").removeClass("uk-icon-spin");
        }
    } catch (ex) {
        LogThis("Error", "GetInteractionHistoryByServer", ex);
    }
}

function ReloadInteractions(intId) {
    try {
        DisableIHIcons(intId);
        GetTabReferenceObj(intId).OtherData.interactionReference = [];

        //get the active history from ref
        let getInstance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (x) {
            return x.active === true;
        });

        if (getInstance.length > 0) {
            $("#" + getInstance[0].instance + "_timeline_" + getInstance[0].intId).html("");
            $("#" + getInstance[0].instance + "_timeline_" + getInstance[0].intId).addClass("uk-display-none");
            $("#" + getInstance[0].instance + "_loader_" + getInstance[0].intId).removeClass("uk-display-none");
            $("#" + getInstance[0].instance + "_no_data_" + getInstance[0].intId).addClass("uk-display-none");

            if (getInstance[0].instance !== "home") {
                getInstance[0].lastId = 0;
                GetInteractionHistoryByServer(getInstance[0].instance, true, getInstance[0].intId);
                //return so that next code block will not be executed
                return;
            }
            else {
                //for home tenant
                let ihParam = GetHistoryParamById(intId);
                let obj = {};
                obj.CIF = ihParam.CIF; //cif
                obj.EmailID = ihParam.EmailID; //email
                obj.NRIC = ihParam.NRIC; //nric
                obj.PhoneNumber = ihParam.PhoneNumber; //phone
                obj.myLastId = 0;
                obj.intId = ihParam.InteractionID;
                GetInteractionHistoryData(obj);
            }
        }
        else {
            LogThis("Error", "ReloadInteractions", "Cannot find the reference of any active instance", false);
        }
    } catch (ex) {
        LogThis("Error", "ReloadInteractions", ex);
    }
}

function LoadMoreInteractions(intId) {
    try {
        DisableIHIcons(intId);
        //get the active history from ref
        let getInstance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (x) {
            return x.active === true;
        });
        if (getInstance.length > 0) {
            if (getInstance[0].instance !== "home") {
                GetInteractionHistoryByServer(getInstance[0].instance, true, getInstance[0].intId);
                //return so that next code block will not be executed
                return;
            }
            else {
                //for home tenant
                let ihParam = GetHistoryParamById(intId);
                let obj = {};
                obj.CIF = ihParam.CIF; //cif
                obj.EmailID = ihParam.EmailID; //email
                obj.NRIC = ihParam.NRIC; //nric
                obj.PhoneNumber = ihParam.PhoneNumber; //phone
                obj.myLastId = getInstance[0].lastId;
                obj.intId = ihParam.InteractionID;
                GetInteractionHistoryData(obj);
            }
        }
        else {
            LogThis("Error", "LoadMoreInteractions", "Cannot find the reference of any active instance", false);
        }
    } catch (ex) {
        LogThis("Error", "LoadMoreInteractions", ex);
    }
}

function DisableIHIcons(intId) {
    $("#reload_" + intId).addClass("icon-disabled uk-icon-spin");
    $("#loadmore_" + intId).addClass("icon-disabled");
    $("#expand_" + intId).addClass("icon-disabled");
    $("#sorting_" + intId).addClass("icon-disabled");
    //  ReviewCodeLine: VP : Jul 2, '20': Remove in the future. Not required anymore.
    // $("#openinnew_" + intId).addClass("icon-disabled");
}

function EnableIHIcons(intId) {
    $("#reload_" + intId).removeClass("icon-disabled");
    $("#loadmore_" + intId).removeClass("icon-disabled");
    $("#expand_" + intId).removeClass("icon-disabled");
    $("#sorting_" + intId).removeClass("icon-disabled");
    //  ReviewCodeLine: VP : Jul 2, '20': Remove in the future. Not required anymore.
    // $("#openinnew_" + intId).removeClass("icon-disabled");
}

function GetIHData(data, method, callback, userObject) {
    try {
        tmac_command(callback, userObject, data, method);
    } catch (ex) {
        LogThis("Error", "GetIHData", ex);
    }
}

function ProcessHistoryData(resultData, userObject) {
    try {
        let intId = userObject.intId;
        let instance = userObject.instance;
        $("#ih-div-spinner_" + intId).addClass("uk-display-none");
        $("#reload_" + intId).removeClass("uk-icon-spin");
        if (resultData !== null && resultData.length > 0) {
            //if the history loaded is not for the home tenant then update the reference
            //get the instance and update the data reference
            let getInstance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (x) {
                return x.instance === instance;
            });
            if (getInstance.length > 0) {
                getInstance[0].isLoaded = true;
                getInstance[0].data = resultData;
                $("#" + instance + "_timeline_" + intId).removeClass("uk-display-none");
                $("#" + instance + "_loader_" + intId).addClass("uk-display-none");
                $("#" + instance + "_no_data_" + intId).addClass("uk-display-none");
            }
            else {
                LogThis("Error", "ReloadInteractions", "Cannot find the reference of any active instance: [" + instance + "]", false);
            }
            AddInteraction(resultData, instance, intId);
            //show the switcher if isMultiHistory is enabled
            if (isMultiHistory)
                $("#instanceGroup_" + intId).removeClass("uk-display-none");
        } else if (GetTabReferenceObj(intId).OtherData.interactionReference.length !== 0) {
            EnableIHIcons(intId);
            LogThis("Info", "ProcessHistoryData", "No more interactions  to load!", true);
        } else {
            LogThis("Warning", "ProcessHistoryData", "No interaction to display", false);

            //check for the instance, else show main no data
            if (instance) {
                $("#" + instance + "_no_data_" + intId).removeClass("uk-display-none");
                $("#" + instance + "_loader_" + intId).addClass("uk-display-none");
                EnableIHIcons(intId);
            }
            else {
                $("#no_data_" + intId).removeClass("uk-display-none");
            }
        }
    } catch (ex) {
        LogThis("Error", "ProcessHistoryData", ex);
    }
}

function ProcessHistoryCount(result, userObject) {
    try {
        if (!result) {
            result = 0;
        }
        let instance = userObject.instance;
        let intId = userObject.intId;
        let button = $("#igButton_" + instance + "_" + intId);
        if (button.find(".uk-badge").length > 0) {
            $("#badge_" + instance + "_" + intId).text(result);
        }
        if (result > 0) {
            button.removeClass("disabled");
        }
    } catch (ex) {
        LogThis("Error", "ProcessHistoryCount", ex);
    }
}

function AddInteractionReference(id, type, channel, agent, intId) {
    try {
        var obj = {};
        obj.id = id;
        obj.type = type;
        obj.channel = channel;
        obj.agent = agent;
        GetTabReferenceObj(intId).OtherData.interactionReference.push(obj);
    } catch (ex) {
        LogThis("Error", "AddInteractionReference", ex);
    }
}

function GetInteractionReference(id, intId) {
    try {
        if (!GetTabReferenceObj(intId) || !GetTabReferenceObj(intId).OtherData || !GetTabReferenceObj(intId).OtherData.interactionReference)
            return null;

        let item = GetTabReferenceObj(intId).OtherData.interactionReference.filter(function (r) { return r.id === id; });
        if (item.length > 0)
            return item[0];
    } catch (ex) {
        LogThis("Error", "GetInteractionReference", ex);
    }
    return null;
}

function AddInteraction(jsonData, instance, intId) {
    try {
        jsonData.sort(sort_by("ItemID", false, parseInt));
        //get the instance from map by name
        let getInstance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (x) {
            return x.instance === instance;
        });
        //check if item is present
        if (getInstance.length > 0) {
            //update the last id
            getInstance[0].lastId = jsonData[0].LastID;
        }
        //update the global lastId only for 'home' tenant
        if (instance === "home") {
            lastId = jsonData[0].LastID;
        }
        let show = true;
        if (jsonData)
            $.each(jsonData, function (i, val) {
                val.ID = instance + "_" + val.ID + "_" + intId;
                var id = val.ID;
                var channel = val.Channel;
                var agent = val.AgentName;
                let subType = val.SubType ? val.SubType : "";
                if (!GetInteractionReference(id, intId)) {
                    AddInteractionReference(id, "new", channel, agent, intId);
                } else {
                    GetInteractionReference(id, intId).type = "old";
                }
                var icon = "";
                var color = "";

                //switch through channels
                switch (channel.toLowerCase()) {
                    case "voice":
                        //create voice div
                        CreateVoiceDiv(val, instance, intId);
                        break;

                    case "chat":
                    case "audio":
                    case "video":
                    case "textchat":
                    case "audiochat":
                    case "videochat":
                        //create chat div
                        icon = '<i class="material-icons notranslate">chat</i>';
                        color = "md-bg-orange-700";

                        if (subType.toLowerCase() === "whatsapp") {
                            icon = '<i class="uk-icon uk-icon-whatsapp"></i>';
                            color = "md-bg-green-500";
                        }

                        if (subType.toLowerCase() === "wechat") {
                            icon = '<i class="uk-icon uk-icon-wechat"></i>';
                            color = "md-bg-green-600";
                        }

                        if (subType.toLowerCase() === "line") {
                            icon = '<i class="uk-icon uk-icon-comment"></i>';
                            color = "md-bg-green-800";
                        }

                        if (subType.toLowerCase() === "twitter") {
                            icon = '<i class="uk-icon uk-icon-twitter"></i>';
                            color = "md-bg-blue-500";
                        }

                        CreateChatDiv(val, "Chat", icon, color, instance, intId);
                        break;

                    case "fbprivate":
                        //create chat div
                        icon = '<i class="uk-icon uk-icon-facebook"></i>';
                        color = "md-bg-blue-700";
                        CreateChatDiv(val, "Fb Message", icon, color, instance, intId);
                        break;

                    case "fbpost":
                        //create chat div
                        icon = '<i class="uk-icon uk-icon-facebook-square"></i>';
                        color = "md-bg-blue-700";
                        CreateChatDiv(val, "Fb post", icon, color, instance, intId);
                        break;

                    case "sms":
                        //create chat div
                        icon = '<i class="material-icons notranslate">sms</i>';
                        color = "md-bg-red-700";
                        CreateChatDiv(val, "SMS", icon, color, instance, intId);
                        break;

                    case "email":
                        //create email div
                        icon = '<i class="material-icons notranslate">email</i>';
                        color = "md-bg-grey-700";
                        CreateEmailDiv(val, "Email", icon, color, instance, intId);
                        break;

                    case "fax":
                        //create email div
                        icon = '<i class="material-icons notranslate">print</i>';
                        color = "md-bg-grey-700";
                        CreateFaxDiv(val, "Fax", icon, color, instance, intId);
                        break;
                    case "line":
                        //create line private message div
                        icon = '<i class="fab fa-line fa-2x" style="color:white;margin-top: 3px;"></i>';
                        color = "#7cb342";
                        CreateLineDiv(val, "line", icon, color, instance, intId);
                        break;

                    case "twitter":
                        //create twitter tweet div
                        icon = '<i class="fab fa-twitter fa-2x" style="color: white;margin-top: 3px;"></i>';
                        color = "#1DA1F2 ";
                        CreateTwitterDiv(val, "twitter", icon, color, instance, intId);
                        break;

                    case "twitterdm":
                        //create twitter direct message div
                        icon = '<i class="fab fa-twitter-square fa-2x" style="color: white;margin-top: 3px;"></i>';
                        color = "#1DA1F2";
                        CreateTwitterDiv(val, "twitterdm", icon, color, instance, intId);
                        break;

                    default:
                        //$("#" + instance + "_no_data").removeClass("uk-display-none");
                        console.log("Channel: " + val.Channel + " is not defined in switch case");
                        break;
                }
            });
        $("#" + instance + "_timeline_" + intId).DescSortDivs();
        altair_helpers.hierarchical_slide("#" + instance + "_timeline_" + intId);
        $("#li_desc_" + intId).addClass("uk-active");
        if (show) {
            $("#" + instance + "_timeline_" + intId).show();
        }
        EnableIHIcons(intId);
    } catch (ex) {
        LogThis("Error", "AddInteraction", ex);
    }
}

function CreateVoiceDiv(obj, instance, intId) {
    try {
        var id = obj.ID;
        var itemId = obj.ItemID + "_" + id;
        var interactionText = obj.InteractionText;
        var interactionDate = obj.InteractionDate;
        var direction = obj.Direction;
        var phoneNo = obj.PhoneNumber;
        var intent = obj.Intent;
        var agentName = obj.AgentName;
        var lastServicedAgents = obj.LastServicedAgentName;
        var agentHandled = "";
        var phoneNoSpan = "";
        var intentSpan = "";
        var typeSpan = "";

        if (GetInteractionReference(id, intId).type === "new") {
            var dateSpan =
                '<span class="md-color-green-800">' + interactionDate + "</span>";
            var directionSpan = "";
            var mainSpan = "";
            var timelineIcon = "";
            if (direction === "In")
                directionSpan =
                    '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
            else
                directionSpan =
                    '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
            mainSpan =
                "<span>" +
                directionSpan +
                '&nbsp;Voice with <span class="uk-text-bold" id="serviceAgent_' +
                id +
                '">' +
                agentName +
                "</span></span> on " +
                dateSpan +
                '<span> with intent <span class="uk-text-primary">' +
                intent +
                "</span></span>";
            var timeline_item =
                '<div class="timeline_item" id="timeline_item' +
                id +
                '" data-sort=' +
                id +
                "></div>";
            timelineIcon =
                '<div class="timeline_icon md-bg-green-700" id="timelineicon' +
                id +
                '"><i class="material-icons notranslate">local_phone</i></div>';
            var timeline_date =
                '<div class="timeline_date" id="timeline_date' + id + '">&nbsp;</div>';
            var timeline_content =
                '<div class="timeline_content" id="timeline_content' + id + '"></div>';
            //$("#timeline").append(timeline_item);
            $("#" + instance + "_timeline_" + intId).append(timeline_item);
            var $timeline_item = $("#timeline_item" + id);
            $timeline_item.append(timelineIcon);
            $("#timelineicon" + id).click(function () {
                $("#timeline_content_addon" + id).toggle(function () { });
            });
            $timeline_item.append(timeline_date);
            $timeline_item.append(timeline_content);
            $("#timeline_content" + id).append(mainSpan);
            var timeline_content_addon =
                '<div class="timeline_content_addon" id="timeline_content_addon' +
                id +
                '" style="display:none;"></div>';
            $("#timeline_content" + id).append(timeline_content_addon);
            var ul_list_addon =
                '<ul class="md-list md-list-addon" id="list_addon' + id + '"><ul>';
            $("#timeline_content_addon" + id).append(ul_list_addon);
            var li_list_addon =
                '<li><div class="md-list-content" id="list_content' +
                id +
                '"></div></li>';
            $("#list_addon" + id).append(li_list_addon);
            agentHandled =
                '<span class="uk-text-small">Agent Handled: ' + lastServicedAgents + "</span>";
            interactionDatTime =
                '<span class="uk-text-small">Time: ' + interactionDate + "</span>";
            phoneNoSpan =
                '<span class="uk-text-small">PhoneNumber: ' + phoneNo + "</span>";
            intentSpan = '<span class="uk-text-small">Intent: ' + intent + "</span>";
            typeSpan =
                '<span class="uk-text-small">Type: ' + interactionText + "</span>";
        } else {
            $("#list_content" + id).append("<br/>");
            agentHandled =
                '<span class="uk-text-small">Handled by: ' + agentName + "</span>";
            interactionDatTime =
                '<span class="uk-text-small">Time: ' + interactionDate + "</span>";
            phoneNoSpan =
                '<span class="uk-text-small">PhoneNumber: ' + phoneNo + "</span>";
            intentSpan = '<span class="uk-text-small">Intent: ' + intent + "</span>";
            typeSpan =
                '<span class="uk-text-small">Type: ' + interactionText + "</span>";
        }
        $("#list_content" + id).append(agentHandled);
        $("#list_content" + id).append(interactionDatTime);
        $("#list_content" + id).append(phoneNoSpan);
        $("#list_content" + id).append(intentSpan);
        $("#list_content" + id).append(typeSpan);
    } catch (ex) {
        LogThis("Error", "CreateVoiceDiv", ex);
    }
}

function CreateChatDiv(obj, type, icon, color, instance, intId) {
    try {
        var id = obj.ID;
        var itemId = obj.ItemID + "_" + id;
        var interactionText = obj.InteractionText;
        var interactionDate = obj.InteractionDate;
        var agentName = obj.AgentName;
        var intent = obj.Intent;
        var user = obj.DisplayText.substring(0, 1);
        var sessionId = intId + "_" + obj.SessionID;
        var msgId = "";
        var mType = "";
        var isReply = false;
        var replyJson = {};

        try {
            if (type === "Chat" && IsValidJson(interactionText)) {
                let formattedMsg = JSON.parse(interactionText);
                interactionText = formattedMsg && formattedMsg.message ? formattedMsg.message : "";
                msgId = formattedMsg && formattedMsg.messageId ? formattedMsg.messageId : "";
                mType = formattedMsg && formattedMsg.type ? formattedMsg.type : "";
                isReply = formattedMsg && formattedMsg.replyId ? formattedMsg.replyId !== "" : false;
                replyJson = {};

                if (isReply) {
                    replyJson = {
                        replyType: "text",
                        replyId: formattedMsg.replyId,
                        replyText: $("#" + sessionId + "_" + formattedMsg.replyId)[0].innerText,
                        replyUser: $("#" + sessionId + "_" + formattedMsg.replyId).length > 0 ? $("#" + sessionId + "_" + formattedMsg.replyId).siblings(".u-label").children(".user-label")[0].innerText : "User"
                    };
                }
            }
        } catch (ex) {
            LogThis("Error", "CreateChatDiv - formattedMsg :: " + obj.InteractionText, ex);
        }

        if (obj.ItemType === 2) {
            if (GetInteractionReference(id, intId).type === "new") {
                //var direction = obj.Direction;
                var direction = "In";
                var dateSpan =
                    '<span class="md-color-green-800">' + interactionDate + "</span>";
                var directionSpan = "";
                var mainSpan = "";
                var timelineIcon = "";
                if (direction === "In")
                    directionSpan =
                        '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
                else
                    directionSpan =
                        '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
                mainSpan =
                    "<span>" +
                    directionSpan +
                    "&nbsp;" +
                    type +
                    ' with <span class="uk-text-bold" id="serviceAgent_' +
                    id +
                    '">' +
                    agentName +
                    "</span></span> on " +
                    dateSpan +
                    '<span> with intent <span class="uk-text-primary">' +
                    intent +
                    "</span></span>";
                var timeline_item =
                    '<div class="timeline_item" id="timeline_item' +
                    id +
                    '" data-sort=' +
                    id +
                    "></div>";
                timelineIcon =
                    '<div class="timeline_icon ' +
                    color +
                    '" id="timelineicon' +
                    id +
                    '">' +
                    icon +
                    "</div>";
                var timeline_date =
                    '<div class="timeline_date" id="timeline_date' +
                    id +
                    '">&nbsp;</div>';
                var timeline_content =
                    '<div class="timeline_content" id="timeline_content' +
                    id +
                    '"></div>';
                $("#" + instance + "_timeline_" + intId).append(timeline_item);
                var $timeline_item = $("#timeline_item" + id);
                $timeline_item.append(timelineIcon);
                $("#timelineicon" + id).click(function () {
                    $("#timeline_content_addon" + id).toggle(function () { });
                });
                //$("#timelineicon" + id).attr("data-uk-scrollspy", "{cls:'uk-animation-scale-up uk-invisible', delay:100, repeat: true}");
                $timeline_item.append(timeline_date);
                $timeline_item.append(timeline_content);
                $("#timeline_content" + id).append(mainSpan);
                var timeline_content_addon = '<div class="timeline_content_addon" id="timeline_content_addon' + id + '" style="display:none;"></div>';
                $("#timeline_content" + id).append(timeline_content_addon);
                var userTag =
                    '<span class="uk-text-bold"><span class="md-color-green-800">' +
                    type +
                    " received at </span><br/ ><span>" +
                    interactionDate +
                    "</span></span>";
                var blockquote =
                    '<blockquote class="blockquote_center" id="blockquote_connected' +
                    itemId +
                    '"><blockquote>';
                $("#timeline_content_addon" + id).append(blockquote);
                $("#blockquote_connected" + itemId).html("");
                $("#blockquote_connected" + itemId).append(userTag);
            }
        }
        else if (obj.ItemType === 1) {
            //dont show silent disconnect message
            if (obj.AgentID.indexOf("[S]") > 0) {
                return;
            }

            //show the end label based on the Interaction Text
            if (interactionText.indexOf("[Agent-EndTextChat]") >= 0) {
                ChatConnectionStatus(
                    "agentdisconnected",
                    id,
                    itemId,
                    agentName,
                    interactionDate
                );
            } else if (interactionText.indexOf("[RemoteEndClosed]") >= 0 || interactionText.indexOf("[RemoteEndDisconnected]") >= 0) {
                ChatConnectionStatus(
                    "disconnected",
                    id,
                    itemId,
                    agentName,
                    interactionDate
                );
            } else {
                AppendChatText(
                    user,
                    id,
                    itemId,
                    agentName,
                    interactionDate,
                    interactionText,
                    msgId,
                    isReply,
                    replyJson,
                    sessionId,
                    mType
                );
            }
        }
        else if (obj.ItemType === 0) {
            if (GetInteractionReference(id, intId).type === "old") {
                if (interactionText === "[RemoteUserConnected]" && GetInteractionReference(id, intId).agent !== agentName) {
                    //hide the silent barge in connected agent message
                    if (obj.AgentID.indexOf("[S]") > 0) {
                        return;
                    }

                    //dont change the agent name after transfer/conference 30-05-2019
                    //GetInteractionReference(id, intId).agent = agentName;
                    //if (obj.AgentID.indexOf("[W]") < 0 && obj.AgentID.indexOf("[C]") < 0) {
                    //    $("#serviceAgent_" + id).html(agentName);
                    //}

                    ChatConnectionStatus(
                        GetTheConnectionType(obj),
                        id,
                        itemId,
                        agentName,
                        interactionDate
                    );

                    return;
                }

                //dont show message for silent/whisper/conference connection
                if (obj.AgentID.indexOf("[S]") > 0 || obj.AgentID.indexOf("[W]") > 0 || obj.AgentID.indexOf("[C]") > 0) {
                    return;
                }

                if (interactionText.indexOf("[Agent-EndTextChat]") >= 0) {
                    ChatConnectionStatus(
                        "agentdisconnected",
                        id,
                        itemId,
                        agentName,
                        interactionDate
                    );
                } else {
                    AppendChatText(
                        user,
                        id,
                        itemId,
                        agentName,
                        interactionDate,
                        interactionText,
                        msgId,
                        isReply,
                        replyJson,
                        sessionId,
                        mType
                    );
                }
            }
        }
    } catch (ex) {
        LogThis("Error", "CreateChatDiv", ex);
    }
}

function GetTheConnectionType(obj) {
    try {
        if (obj.AgentID.indexOf("[S]") > 0) {
            return "silent";
        } else if (obj.AgentID.indexOf("[W]") > 0) {
            return "whisper";
        } else if (obj.AgentID.indexOf("[C]") > 0) {
            return "conference";
        } else {
            return "transfer";
        }
    } catch (ex) {
        LogThis("Error", "GetTheConnectionType", ex);
    }
}

function ChatConnectionStatus(type, id, itemId, agentName, interactionDate) {
    try {
        var userTag = "";
        var blockquote = "";
        var appendId = "";
        if (["transfer", "conference", "whisper", "silent"].indexOf(type) >= 0) {
            userTag =
                '<span class="uk-text-bold"><span class="md-color-green-800">Chat ' + type + ' connected to ' +
                agentName +
                " at </span><br/ ><span>" +
                interactionDate +
                "</span></span>";
            blockquote =
                '<blockquote class="blockquote_center" id="blockquote_connected' +
                itemId +
                '"><blockquote>';
            appendId = "#blockquote_connected" + itemId;
        } else if (type === "disconnected") {
            userTag =
                '<span class="uk-text-bold"><span class="md-color-red-800">Chat disconnected at </span><br/ ><span>' +
                interactionDate +
                "</span></span>";
            blockquote =
                '<blockquote class="blockquote_center" id="blockquote_disconnected' +
                itemId +
                '"><blockquote>';
            appendId = "#blockquote_disconnected" + itemId;
        } else if (type === "agentdisconnected") {
            userTag =
                '<span class="uk-text-bold"><span class="md-color-red-800">Chat disconnected by ' +
                agentName +
                " at </span><br/ ><span>" +
                interactionDate +
                "</span></span>";
            blockquote =
                '<blockquote class="blockquote_center" id="blockquote_connected' +
                itemId +
                '"><blockquote>';
            appendId = "#blockquote_connected" + itemId;
        }
        $("#timeline_content_addon" + id).append(blockquote);
        $(appendId).html("");
        $(appendId).append(userTag);
    } catch (ex) {
        LogThis("Error", "ChatConnectionStatus", ex);
    }
}

function AppendChatText(type, id, itemId, agentName, interactionDate, interactionText, msgId, isReply, replyJson, sessionId, messageType) {
    try {
        msgId = msgId ? msgId : IHuuid();
        var replyFor = "";
        if (isReply) {
            replyFor = "<span style='cursor: pointer;' onclick='GotoThisDivIH(\"" + id + "\",\"" + replyJson.replyId + "\",\"" + sessionId + "\");' class='uk-text-muted uk-pointer'>replied to <span class='" + (type === "A" ? "uk-text-warning" : "uk-text-primary") + "'>" + replyJson.replyUser + "</span> : " + replyJson.replyText + "</span>";
        }
        var userTag = "";
        var textTag = "";
        // filter the type and create the tags
        switch (messageType) {
            case "image":
                textTag = "<span id='" + sessionId + "_" + msgId + "'><img src='" + interactionText + "' /></span>";
                break;
            case "video":
                textTag = "<span id='" + sessionId + "_" + msgId + "'><video controls src='" + interactionText + "'></video></span>";
                break;
            case "audio":
                textTag = "<span id='" + sessionId + "_" + msgId + "'><audio preload='true' controls src='" + interactionText + "'></audio></span>";
                break;
            case "file":
                textTag = "<span id='" + sessionId + "_" + msgId + "'><div class='document-body'><a target='_blank' id='a_" + sessionId + "_" + msgId + "' class='document-filename' download='" + interactionText + "' href='" + interactionText + "'>'" + interactionText + "'</a></div></span>";
                break;
            default:
                textTag = "<span id='" + sessionId + "_" + msgId + "'>" + (typeof emojione !== "undefined" ? emojione.toImage(interactionText) : interactionText) + "</span>";
        }
        var datTag =
            '<span class="uk-text-small-10 uk-text-muted">' +
            interactionDate +
            "</span>";
        var blockquote = "";
        var appendId = "";

        if (type === "A") {
            userTag =
                '<span class="uk-text-bold uk-text-warning u-label"><span class="user-label">' +
                agentName + "</span> " + (replyFor ? replyFor + " " : "") +
                "</span>";
            blockquote =
                '<blockquote class="blockquote_right" id="blockquote_agent' +
                itemId +
                '"><blockquote>';
            appendId = "#blockquote_agent" + itemId;
        } else if (type === "C") {
            userTag = '<span class="uk-text-bold uk-text-primary u-label"><span class="user-label">Customer</span> ' + (replyFor ? replyFor + " " : "") + '</span>';
            blockquote =
                '<blockquote class="blockquote_left" id="blockquote_customer' +
                itemId +
                '"><blockquote>';
            appendId = "#blockquote_customer" + itemId;
        }
        $("#timeline_content_addon" + id).append(blockquote);
        $(appendId).html("");
        $(appendId).append(userTag);
        $(appendId).append("<br />");
        $(appendId).append(textTag);
        $(appendId).append("<br />");
        $(appendId).append(datTag);
    } catch (ex) {
        LogThis("Error", "AppendChatText", ex);
    }
}

function GotoThisDivIH(tId, replyId, sessionId) {
    try {
        //uk-animation-shake
        var id = $("#" + sessionId + "_" + replyId).parent()[0].id;
        //var offSetTop = $("#" + id).height() + 10;
        //$("#" + tId).scrollTo(id, 500, { offset: { top: -offSetTop } });
        setTimeout(function () {
            $("#" + id).addClass("uk-animation-shake");
            setTimeout(function () {
                $("#" + id).addClass("blink");
                $("#" + id).removeClass("uk-animation-shake");
                setTimeout(function () {
                    $("#" + id).removeClass("blink");
                }, 1000);
            }, 500);
        }, 250);
    } catch (ex) {
        LogThis("Error", "GotoThisDivIH", ex);
    }
}

function CreateTwitterDiv(obj, type, icon, color, instance, intId) {
    var id = obj.ID;
    var itemId = obj.ItemID + "_" + id;
    var interactionText = obj.InteractionText;
    var interactionDate = obj.InteractionDate;
    var agentName = obj.AgentName;
    var intent = obj.Intent;
    var user = obj.DisplayText.substring(0, 1);
    if (obj.ItemType === 2) {
        if (GetInteractionReference(id, intId).type === "new") {
            //var direction = obj.Direction;
            var direction = "In";
            var dateSpan =
                '<span class="uk-text-danger">' + interactionDate + "</span>";
            var directionSpan = "";
            var mainSpan = "";
            var timelineIcon = "";
            if (direction === "In")
                directionSpan =
                    '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
            else
                directionSpan =
                    '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
            mainSpan =
                "<span>" +
                directionSpan +
                "&nbsp;" +
                type +
                ' with <span class="uk-text-bold" id="serviceAgent_' +
                id +
                '">' +
                agentName +
                "</span></span> on " +
                dateSpan +
                '<span> with intent <span class="uk-text-primary">' +
                intent +
                "</span></span>";
            var timeline_item =
                '<div class="timeline_item" id="timeline_item' +
                id +
                '" data-sort=' +
                id +
                "></div>";
            timelineIcon =
                '<div class="timeline_icon" style="background-color:' +
                color +
                ';" id="timelineicon' +
                id +
                '">' +
                icon +
                "</div>";
            var timeline_date =
                '<div class="timeline_date" id="timeline_date' + id + '">&nbsp;</div>';
            var timeline_content =
                '<div class="timeline_content" id="timeline_content' + id + '"></div>';
            //$("#timeline").append(timeline_item);
            $("#" + instance + "_timeline_" + intId).append(timeline_item);
            var $timeline_item = $("#timeline_item" + id);
            $timeline_item.append(timelineIcon);
            $("#timelineicon" + id).click(function () {
                $("#timeline_content_addon" + id).toggle(function () { });
            });
            //$("#timelineicon" + id).attr("data-uk-scrollspy", "{cls:'uk-animation-scale-up uk-invisible', delay:100, repeat: true}");
            $timeline_item.append(timeline_date);
            $timeline_item.append(timeline_content);
            $("#timeline_content" + id).append(mainSpan);

            var timeline_content_addon =
                '<div class="timeline_content_addon" id="timeline_content_addon' +
                id +
                '" style="display:none;"></div>';
            $("#timeline_content" + id).append(timeline_content_addon);
            var userTag =
                '<span class="uk-text-bold"><span class="md-color-green-800">' +
                type +
                " received at </span><br/ ><span>" +
                interactionDate +
                "</span></span>";
            var blockquote =
                '<blockquote class="blockquote_center" id="blockquote_connected' +
                itemId +
                '"><blockquote>';
            $("#timeline_content_addon" + id).append(blockquote);
            $("#blockquote_connected" + itemId).html("");
            $("#blockquote_connected" + itemId).append(userTag);
        }
    } else if (obj.ItemType === 1) {
        AppendChatText(
            user,
            id,
            itemId,
            agentName,
            interactionDate,
            interactionText
        );
        ChatConnectionStatus(
            "disconnected",
            id,
            itemId,
            agentName,
            interactionDate
        );
    } else if (obj.ItemType === 0) {
        if (GetInteractionReference(id, intId).type === "old") {
            if (GetInteractionReference(id, intId).agent !== agentName) {
                //dont change the agent name after transfer/conference 30-05-2019
                //GetInteractionReference(id, intId).agent = agentName;
                //$("#serviceAgent_" + id).html(agentName);
                ChatConnectionStatus(
                    "transfer",
                    id,
                    itemId,
                    agentName,
                    interactionDate
                );
            }
            AppendChatText(
                user,
                id,
                itemId,
                agentName,
                interactionDate,
                interactionText
            );
        }
    }
}

function CreateLineDiv(obj, type, icon, color, instance, intId) {
    var id = obj.ID;
    var itemId = obj.ItemID + "_" + id;
    var interactionText = obj.InteractionText;
    var interactionDate = obj.InteractionDate;
    var agentName = obj.AgentName;
    var intent = obj.Intent;
    var user = obj.DisplayText.substring(0, 1);

    if (obj.ItemType === 2) {
        if (GetInteractionReference(id, intId).type === "new") {
            //var direction = obj.Direction;
            var direction = "In";
            var dateSpan =
                '<span class="uk-text-danger">' + interactionDate + "</span>";
            var directionSpan = "";
            var mainSpan = "";
            var timelineIcon = "";
            if (direction === "In")
                directionSpan =
                    '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
            else
                directionSpan =
                    '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
            mainSpan =
                "<span>" +
                directionSpan +
                "&nbsp;" +
                type +
                ' with <span class="uk-text-bold" id="serviceAgent_' +
                id +
                '">' +
                agentName +
                "</span></span> on " +
                dateSpan +
                '<span> with intent <span class="uk-text-primary">' +
                intent +
                "</span></span>";
            var timeline_item =
                '<div class="timeline_item" id="timeline_item' +
                id +
                '" data-sort=' +
                id +
                "></div>";
            timelineIcon =
                '<div class="timeline_icon" style="background-color:' +
                color +
                ';" id="timelineicon' +
                id +
                '">' +
                icon +
                "</div>";
            var timeline_date =
                '<div class="timeline_date" id="timeline_date' + id + '">&nbsp;</div>';
            var timeline_content =
                '<div class="timeline_content" id="timeline_content' + id + '"></div>';
            //$("#timeline").append(timeline_item);
            $("#" + instance + "_timeline_" + intId).append(timeline_item);
            var $timeline_item = $("#timeline_item" + id);
            $timeline_item.append(timelineIcon);
            $("#timelineicon" + id).click(function () {
                $("#timeline_content_addon" + id).toggle(function () { });
            });
            //$("#timelineicon" + id).attr("data-uk-scrollspy", "{cls:'uk-animation-scale-up uk-invisible', delay:100, repeat: true}");
            $timeline_item.append(timeline_date);
            $timeline_item.append(timeline_content);
            $("#timeline_content" + id).append(mainSpan);

            var timeline_content_addon =
                '<div class="timeline_content_addon" id="timeline_content_addon' +
                id +
                '" style="display:none;"></div>';
            $("#timeline_content" + id).append(timeline_content_addon);
            var userTag =
                '<span class="uk-text-bold"><span class="md-color-green-800">' +
                type +
                " received at </span><br/ ><span>" +
                interactionDate +
                "</span></span>";
            var blockquote =
                '<blockquote class="blockquote_center" id="blockquote_connected' +
                itemId +
                '"><blockquote>';
            $("#timeline_content_addon" + id).append(blockquote);
            $("#blockquote_connected" + itemId).html("");
            $("#blockquote_connected" + itemId).append(userTag);
        }
    } else if (obj.ItemType === 1) {
        AppendChatText(
            user,
            id,
            itemId,
            agentName,
            interactionDate,
            interactionText
        );
        ChatConnectionStatus(
            "disconnected",
            id,
            itemId,
            agentName,
            interactionDate
        );
    } else if (obj.ItemType === 0) {
        if (GetInteractionReference(id, intId).type === "old") {
            if (GetInteractionReference(id, intId).agent !== agentName) {
                //dont change the agent name after transfer/conference 30-05-2019
                //GetInteractionReference(id, intId).agent = agentName;
                //$("#serviceAgent_" + id).html(agentName);
                ChatConnectionStatus(
                    "transfer",
                    id,
                    itemId,
                    agentName,
                    interactionDate
                );
            }
            AppendChatText(
                user,
                id,
                itemId,
                agentName,
                interactionDate,
                interactionText
            );
        }
    }
}

function CreateEmailDiv(obj, type, icon, color, instance, intId) {
    try {
        var id = obj.ID;
        var itemId = obj.ItemID + "_" + id;
        var interactionText = obj.InteractionText;
        var interactionDate = obj.InteractionDate;
        var agentName = obj.AgentName;
        var intent = obj.Intent;
        var user = obj.DisplayText.substring(0, 1);
        if (obj.ItemType === 2) {
            if (GetInteractionReference(id, intId).type === "new") {
                var direction = obj.Direction;
                var dateSpan =
                    '<span class="uk-text-primary">' + interactionDate + "</span>";
                var directionSpan = "";
                var mainSpan = "";
                var timelineIcon = "";
                if (direction === "In")
                    directionSpan =
                        '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
                else
                    directionSpan =
                        '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
                mainSpan =
                    "<span>" +
                    directionSpan +
                    "&nbsp;" +
                    type +
                    ' with <span class="uk-text-bold" id="serviceAgent_' +
                    id +
                    '">' +
                    agentName +
                    "</span></span> on " +
                    dateSpan +
                    '<span> with intent <span class="uk-text-primary">' +
                    intent +
                    "</span></span>";
                var timeline_item =
                    '<div class="timeline_item" id="timeline_item' +
                    id +
                    '" data-sort=' +
                    id +
                    "></div>";
                timelineIcon =
                    '<div class="timeline_icon ' +
                    color +
                    '" id="timelineicon' +
                    id +
                    '">' +
                    icon +
                    "</div>";
                var timeline_date =
                    '<div class="timeline_date" id="timeline_date' +
                    id +
                    '">&nbsp;</div>';
                var timeline_content =
                    '<div class="timeline_content" id="timeline_content' +
                    id +
                    '"></div>';
                //$("#timeline").append(timeline_item);
                $("#" + instance + "_timeline_" + intId).append(timeline_item);
                var $timeline_item = $("#timeline_item" + id);
                $timeline_item.append(timelineIcon);
                $("#timelineicon" + id).click(function () {
                    $("#timeline_content_addon" + id).toggle(function () { });
                });
                //$("#timelineicon" + id).attr("data-uk-scrollspy", "{cls:'uk-animation-scale-up uk-invisible', delay:100, repeat: true}");
                $timeline_item.append(timeline_date);
                $timeline_item.append(timeline_content);
                $("#timeline_content" + id).append(mainSpan);
                var timeline_content_addon =
                    '<div class="timeline_content_addon" id="timeline_content_addon' +
                    id +
                    '" style="display:none;"></div>';
                $("#timeline_content" + id).append(timeline_content_addon);
                var userTag =
                    '<span class="uk-text-bold"><span class="md-color-green-800">Email received at </span><br/ ><a onclick="PreviewEmail(' +
                    obj.SessionID +
                    "," +
                    AddSingleQuotes(direction) +
                    ')">' +
                    interactionDate +
                    "</a></span>";
                var blockquote =
                    '<blockquote class="blockquote_center" id="blockquote_connected' +
                    itemId +
                    '"><blockquote>';
                $("#timeline_content_addon" + id).append(blockquote);
                $("#blockquote_connected" + itemId).html("");
                $("#blockquote_connected" + itemId).append(userTag);
            }
        } else if (obj.ItemType === 1) {
            AppendChatText(
                user,
                id,
                itemId,
                agentName,
                interactionDate,
                interactionText
            );
            ChatConnectionStatus(
                "disconnected",
                id,
                itemId,
                agentName,
                interactionDate
            );
        } else if (obj.ItemType === 0) {
            if (GetInteractionReference(id, intId).type === "old") {
                if (GetInteractionReference(id, intId).agent !== agentName) {
                    GetInteractionReference(id, intId).agent = agentName;
                    ChatConnectionStatus(
                        "transfer",
                        id,
                        itemId,
                        agentName,
                        interactionDate
                    );
                }
                AppendChatText(
                    user,
                    id,
                    itemId,
                    agentName,
                    interactionDate,
                    interactionText
                );
            }
        }
    } catch (ex) {
        LogThis("Error", "CreateEmailDiv", ex);
    }
}

function PreviewEmail(sessionId, direction) {
    window.open(
        ihEmailPreviewUrl + "sessionid=" + sessionId + "&direction=" + direction,
        "1",
        "toolbar=0, location=0, menubar=0, height=500, width=500"
    );
}

function CreateFaxDiv(obj, type, icon, color, instance, intId) {
    try {
        let id = obj.ID;
        let itemId = obj.ItemID + "_" + id;
        let interactionText = obj.InteractionText;
        let interactionDate = obj.InteractionDate;
        let agentName = obj.AgentName;
        let intent = obj.Intent;
        let user = obj.DisplayText.substring(0, 1);
        let faxNumber = obj.PhoneNumber;
        let url = obj.InteractionText;
        let direction = obj.Direction;
        if (obj.ItemType === 2) {
            if (GetInteractionReference(id, intId).type === "new") {
                var dateSpan =
                    '<span class="uk-text-primary">' + interactionDate + "</span>";
                var directionSpan = "";
                var mainSpan = "";
                var timelineIcon = "";
                if (direction === "In")
                    directionSpan =
                        '<span class="uk-badge uk-badge-primary">' + direction + "</span>";
                else
                    directionSpan =
                        '<span class="uk-badge uk-badge-danger">' + direction + "</span>";
                mainSpan =
                    "<span>" +
                    directionSpan +
                    "&nbsp;" +
                    type +
                    " (" +
                    faxNumber +
                    ') with <span class="uk-text-bold" id="serviceAgent_' +
                    id +
                    '">' +
                    agentName +
                    "</span></span> on " +
                    dateSpan +
                    '<span> with intent <span class="uk-text-primary">' +
                    intent +
                    "</span></span>";
                var timeline_item =
                    '<div class="timeline_item" id="timeline_item' +
                    id +
                    '" data-sort=' +
                    id +
                    "></div>";
                timelineIcon =
                    '<div class="timeline_icon ' +
                    color +
                    '" id="timelineicon' +
                    id +
                    '">' +
                    icon +
                    "</div>";
                var timeline_date =
                    '<div class="timeline_date" id="timeline_date' +
                    id +
                    '">&nbsp;</div>';
                var timeline_content =
                    '<div class="timeline_content" id="timeline_content' +
                    id +
                    '"></div>';
                //$("#timeline").append(timeline_item);
                $("#" + instance + "_timeline_" + intId).append(timeline_item);
                var $timeline_item = $("#timeline_item" + id);
                $timeline_item.append(timelineIcon);
                $("#timelineicon" + id).click(function () {
                    $("#timeline_content_addon" + id).toggle(function () { });
                });
                $timeline_item.append(timeline_date);
                $timeline_item.append(timeline_content);
                $("#timeline_content" + id).append(mainSpan);
                var timeline_content_addon =
                    '<div class="timeline_content_addon" id="timeline_content_addon' +
                    id +
                    '" style="display:none;"></div>';
                $("#timeline_content" + id).append(timeline_content_addon);
                var userTag =
                    '<span class="uk-text-bold"><span class="md-color-green-800">Fax' +
                    (direction === "In" ? " received " : " sent ") +
                    ' at </span><br/ >' +
                    '<a onclick="PreviewFax(' + AddSingleQuotes(url) + ', ' + AddSingleQuotes(intId) + ')">' +
                    interactionDate +
                    "</a></span>";
                var blockquote =
                    '<blockquote class="blockquote_center" id="blockquote_connected' +
                    itemId +
                    '"><blockquote>';
                $("#timeline_content_addon" + id).append(blockquote);
                $("#blockquote_connected" + itemId).html("");
                $("#blockquote_connected" + itemId).append(userTag);
            }
        } else if (obj.ItemType === 0) {
            if (GetInteractionReference(id, intId).type === "old") {
                if (GetInteractionReference(id, intId).agent !== agentName) {
                    GetInteractionReference(id, intId).agent = agentName;
                    ChatConnectionStatus(
                        "transfer",
                        id,
                        itemId,
                        agentName,
                        interactionDate
                    );
                }
                AppendFaxDiv(id, itemId, interactionDate, direction, interactionText);
            }
        }
    } catch (ex) {
        LogThis("Error", "CreateFaxDiv", ex);
    }
}

function AppendFaxDiv(id, itemId, interactionDate, direction, url) {
    try {
        let userTag = "";
        let blockquote = "";

        if (direction === "In") {
            userTag =
                '<span class="uk-text-bold"><span class="md-color-green-800">Fax received at </span><br/ >' +
                '<a onclick="PreviewFax(' + AddSingleQuotes(url) + ', ' + AddSingleQuotes(intId) + ')">' +
                interactionDate +
                "</a></span>";
        } else if (direction === "Out") {
            userTag =
                '<span class="uk-text-bold"><span class="md-color-green-800">Fax sent at </span><br/ >' +
                '<a onclick="PreviewFax(' + AddSingleQuotes(url) + ', ' + AddSingleQuotes(intId) + ')">' +
                interactionDate +
                "</a></span>";
        }
        blockquote =
            '<blockquote class="blockquote_center" id="blockquote_connected' +
            itemId +
            '"><blockquote>';
        $("#timeline_content_addon" + id).append(blockquote);
        $("#blockquote_connected" + itemId).html("");
        $("#blockquote_connected" + itemId).append(userTag);
    } catch (ex) {
        LogThis("Error", "AppendFaxDiv", ex);
    }
}

function PreviewFax(url, intId) {
    try {
        var filename = url.replace(/^.*[\\\/]/, "");
        $("#fileName_" + intId).text(filename);
        var height = $(window).height();
        var width = $(window).width();
        $("#previewFax_" + intId).html("");
        UIkit.modal("#fax_preview_window_" + intId).show();
        let xhr = new XMLHttpRequest();
        xhr.responseType = "arraybuffer";
        xhr.open("GET", url);
        xhr.onload = function (e) {
            let tiff = new Tiff({
                buffer: xhr.response
            });
            for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                tiff.setDirectory(i);
                var li = document.createElement("LI"),
                    canvas = tiff.toCanvas(),
                    tempCanvas = document.createElement("canvas"), //create a temp canvas
                    context = tempCanvas.getContext("2d"), //get the context of temp canvas
                    img = document.createElement("img"); //image tag to show

                //set temp canvas width to 1728
                tempCanvas.width = "1728";
                //set temp canvas height to 2200
                tempCanvas.height = "2200";
                //draw image of tiff extracted canvas to new temp canvas with req width/height
                context.drawImage(canvas, 0, 0, 1728, 2200);
                //get the temp canvas data URL and set to image
                img.src = tempCanvas.toDataURL();
                img.id = "file_" + intId + "_" + i;
                img.style.width = "100%";
                img.style.height = "100%";
                li.appendChild(img);

                $("#previewFax_" + intId).append(li);
            }
        };
        xhr.send();
    } catch (ex) {
        LogThis("Error", "PreviewFax", ex);
    }
}

//  ReviewCodeLine: VP : Jul 2, '20': Remove in the future. Not required anymore.
// function OpenInNewTab(intId) {
//     try {
//         // check if IH url is configured
//         if (!ih_iframe_url) {
//             LogThis("Warning", "OpenInNewTab", "Can not open interaction history in new tab - URL is not configured!", true);
//             return;
//         }
//         // get the history param from reference
//         let historyParams = GetHistoryParamById(intId);
//         // get thee URL
//         var url = (IsValidURL(ih_iframe_url) ? ih_iframe_url : GetBaseUrl(global_connectedProxy) + ih_iframe_url) + "?"
//             + "s=" + interactionHistorySource
//             + "&i=" + historyParams.InteractionID
//             + "&d=" + global_DeviceID
//             + "&sn=" + _tmacServer
//             + "&f=" + localStorage.getItem("font_family")
//             + "&hp=" + historyParams.CIF + "," + historyParams.EmailID + "," + historyParams.NRIC + "," + historyParams.PhoneNumber;
//         // open new iframe tab
//         OpenIframeTab("InteractionHistory", url);
//     } catch (ex) {
//         LogThis("Error", "OpenInNewTab", ex);
//     }
// }

jQuery.fn.AscSortDivs = function AscSortDivs() {
    $("> div", this[0])
        .sort(asc_sort)
        .appendTo(this[0]);

    function asc_sort(a, b) {
        return $(b).data("sort") < $(a).data("sort") ? 1 : -1;
    }
};

jQuery.fn.DescSortDivs = function DescSortDivs() {
    $("> div", this[0])
        .sort(dec_sort)
        .appendTo(this[0]);

    function dec_sort(a, b) {
        return $(b).data("sort") > $(a).data("sort") ? 1 : -1;
    }
};

function IHSortAsc(e, intId) {
    let instance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (r) { return r.active; });
    if (instance.length > 0) {
        $("#" + instance[0].instance + "_timeline_" + intId).AscSortDivs();
        instance[0].sort = "asc";
        altair_helpers.hierarchical_slide(".timeline");
        $(e)
            .addClass("uk-active")
            .siblings()
            .removeClass("uk-active");
    }
}

function IHSortDesc(e, intId) {
    let instance = GetTabReferenceObj(intId).OtherData.multiHistoryRef.filter(function (r) { return r.active; });
    if (instance.length > 0) {
        $("#" + instance[0].instance + "_timeline_" + intId).DescSortDivs();
        instance[0].sort = "desc";
        altair_helpers.hierarchical_slide(".timeline");
        $(e)
            .addClass("uk-active")
            .siblings()
            .removeClass("uk-active");
    }
}

function IHExpandAll(intId) {
    $(".timeline_content_addon").each(function () {
        var id = this.id;
        if ($("#" + id).css("display") === "none") $("#" + id).show(function () { });
    });
    $("#expand_" + intId).toggle(false);
    $("#collapse_" + intId).toggle(true);
}

function IHCollapsAll(intId) {
    $(".timeline_content_addon").each(function () {
        var id = this.id;
        if ($("#" + id).css("display") === "block") $("#" + id).hide(function () { });
    });
    $("#expand_" + intId).toggle(true);
    $("#collapse_" + intId).toggle(false);
}

function SetIHHeight() {
    try {
        setTimeout(function () {
            var totalHeight = $(window).height();
            $("#uk_grid").height(totalHeight - 10);
            $(".divStyle").height(totalHeight - 92);
        }, 200);
    } catch (ex) {
        LogThis("Error", "SetHeight", ex);
    }
}

function IsValidJson(text) {
    var isJson = false;
    try {
        var jParse = JSON.parse(text);
        if (typeof (jParse) === "object") {
            isJson = true;
        } else {
            isJson = false;
        }
    } catch (ex) {
        isJson = false;
    }
    return isJson;
}

function IHuuid() {
    return Date.now();
}
