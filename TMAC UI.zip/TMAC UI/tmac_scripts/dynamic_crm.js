﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CommandManager.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

$(document).ready(function () {
    console.log('dynamic crm loaded');
});

//Chat Start CRM Popup
function DynamicsCRMStartChatPopUpScreen(event) {
    try {
        console.log('Inside - DynamicsCRMStartChatPopUpScreen');
        if (isCRMEnabled) {
            return;
        }
        if (agentCRMName !== "MSD") {
            return;
        }

        var scName;
        if (event.screenName === null || event.screenName === '') {
            scName = event.screenName1;
        }
        else {
            scName = event.screenName;
        }

        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupURL = MSDChatAcceptPopUpURL;

        popupURL = popupURL.replace(/CIFIDTag/g, event.CIF); //replace CIF
        popupURL = popupURL.replace(/ChatSessionIDTag/g, event.TextChatSessionID); // replace ChatSessionID
        popupURL = popupURL.replace(/ChatIntentTag/g, event.Intent); // replace ChatIntent
        popupURL = popupURL.replace(/ChatSessionStartDateTag/g, date); // replace ChatSessionStartDate
        popupURL = popupURL.replace(/ChatSessionStartTimeTag/g, time); // replace ChatSessionStartTime
        popupURL = popupURL.replace(/AgentIdTag/g, global_LanID); // replace AgentId
        popupURL = popupURL.replace(/ActionFlagTag/g, '1'); // replace ActionFlagTag
        popupURL = popupURL.replace(/CustomerNameTag/g, scName); // replace Customer Name
        log.LogDetails(log.logType.Info, "DynamicsCRMStartChatPopUpScreen", "popup URL:[" + popupURL + "]", false);
        //assign CRM data
        GetTabReferenceObj(event.InteractionID).CRMWindowData.URL = popupURL;
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
            "MSDChat" + event.InteractionID,
            "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
            ",height=" + DynamicsCRMScreenResolution_Height() +
            ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
            ",left=" + DynamicsCRMScreenResolution_Position_Left());

        // alert indicatior for Incoming chat
        ShowNotification("You have new ", "Incoming Chat");
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMStartChatPopUpScreen()", ex, false);
    }
}

//Chat End CRM Popup
function DynamicsCRMEndChatPopUpScreen(event) {
    try {
        if (isCRMEnabled) {
            return;
        }
        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupURL;

        try {
            popupURL = GetTabReferenceObj(event.InteractionID).CRMWindowData.URL;
        }
        catch (e) {
            popupURL = MSDChatClosePopUpURL;
        }

        popupURL = popupURL.slice(0, -1); // remove last char
        popupURL += '2'; // add char, that you want to be placed instead of the earlier action flag
        popupURL += '&ChatSessionEndDate=ChatSessionEndDateTag';
        popupURL = popupURL.replace(/ChatSessionEndDateTag/g, date); //replace Chat End Date
        popupURL += '&ChatSessionEndTime=ChatSessionEndTimeTag';
        popupURL = popupURL.replace(/ChatSessionEndTimeTag/g, time); //replace Chat End Time	
        try {

            //change the URL
            GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle.location.href = popupURL;
        }
        catch (e) {
            GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
                "MSDChat" + event.InteractionID,
                "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
                ",height=" + DynamicsCRMScreenResolution_Height() +
                ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
                ",left=" + DynamicsCRMScreenResolution_Position_Left());
        }
        log.LogDetails("Info", "DynamicsCRMEndChatPopUpScreen", "popup URL:[" + popupURL + "]", false);
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMEndChatPopUpScreen()", ex, false);
    }
}

//Voice Start CRM Popup
function DynamicsCRMStartVoicePopUpScreen(event, isInboundCall) {
    try {
        console.log('Inside - DynamicsCRMStartVoicePopUpScreen');
        if (isCRMEnabled) {
            return;
        }

        if (agentCRMName !== "MSD") {
            return;
        }

        if (GetTabReferenceObj(event.InteractionID).OtherData.customMakeCallDone) {
            return;
        }

        if (isInboundCall) {
            //if it is a station to station call do not pop up crm
            if (event.CallType === "2") {
                return;
            }
        }

        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupURL = "";
        var callerId = "";
        var isInternalCallFlag = false;
        if (isInboundCall) {
            popupURL = MSDInboundVoicePopUpURL;
            popupURL = popupURL.replace(/UCIDTag/g, event.UCID); // replace UCID
            popupURL = popupURL.replace(/CallerIdTag/g, event.PhoneNumber); // replace CallerID
            callerId = event.PhoneNumber;
        }
        else {
            popupURL = MSDOutboundVoicePopUpURL;
            callerId = GetTabReferenceObj(event.InteractionID).OtherData.PhoneNumber;
            popupURL = popupURL.replace(/UCIDTag/g, event.PhoneNumber); // replace UCID
            popupURL = popupURL.replace(/CallerIdTag/g, callerId); // replace CallerID
        }

        isInternalCallFlag = isInternalCall(callerId);

        popupURL = popupURL.replace(/VoiceSessionStartDateTag/g, date); // replace VoiceCallStartDate
        popupURL = popupURL.replace(/VoiceSessionStartTimeTag/g, time); // replace VoiceCallStartTime
        popupURL = popupURL.replace(/AgentIdTag/g, global_LanID); // replace AgentId

        log.LogDetails(log.logType.Info, "DynamicsCRMStartVoicePopUpScreen", "popup URL:[" + popupURL + "]", false);
        //assign CRM data
        GetTabReferenceObj(event.InteractionID).CRMWindowData.URL = popupURL;
        if (!isInternalCallFlag) {
            GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
                "MSDVoice" + event.InteractionID,
                "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
                ",height=" + DynamicsCRMScreenResolution_Height() +
                ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
                ",left=" + DynamicsCRMScreenResolution_Position_Left());
        }

        // alert indicatior for Incoming voice call
        if (isInboundCall) {
            ShowNotification("You have new ", "Incoming Voice Call");
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMStartVoicePopUpScreen()", ex, false);
    }
}
//Voice End CRM Popup
function DynamicsCRMEndVoicePopUpScreen(event, isInboundCall) {
    try {
        console.log('Inside - DynamicsCRMEndVoicePopUpScreen');
        if (isCRMEnabled) {
            return;
        }

        if (GetTabReferenceObj(event.InteractionID).OtherData.customMakeCallDone) {
            return;
        }

        if (GetTabReferenceObj(event.InteractionID).OtherData.CallType === '2') {
            return;
        }

        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupURL;

        try {
            popupURL = GetTabReferenceObj(event.InteractionID).CRMWindowData.URL;
        }
        catch (e) {
            if (isInboundCall) {
                popupURL = MSDInboundVoicePopUpURL;
            }
            else {
                popupURL = MSDOutboundVoicePopUpURL;
            }
        }

        if (isInboundCall) {
            popupURL = popupURL.slice(0, -1); // remove last char
        }
        else {
            popupURL = popupURL.slice(0, -2); // remove last 2 char
        }

        popupURL += isInboundCall ? "8" : "12"; // add char, that you want to be placed instead of the earlier action flag
        popupURL += '&CallEndDate=VoiceSessionEndDateTag';
        popupURL = popupURL.replace(/VoiceSessionEndDateTag/g, date); //replace voice call End Date
        popupURL += '&CallEndTime=VoiceSessionEndTimeTag';
        popupURL = popupURL.replace(/VoiceSessionEndTimeTag/g, time); //replace voice call End Time

        log.LogDetails("Info", "DynamicsCRMEndVoicePopUpScreen", "popup URL:[" + popupURL + "]", false);

        try {

            //change the URL
            GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle.location.href = popupURL;

        }
        catch (e) {
            GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
                "MSDVoice" + event.InteractionID,
                "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
                ",height=" + DynamicsCRMScreenResolution_Height() +
                ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
                ",left=" + DynamicsCRMScreenResolution_Position_Left());
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMEndVoicePopUpScreen()", ex, false);
    }
}

//Callback Start CRM Popup
function DynamicsCRMStartCallbackPopUpScreen(intid, cif, ucid, chatsessionid) {
    try {
        if (isCRMEnabled) {
            return;
        }
        if (agentCRMName !== "MSD") {
            return;
        }

        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupUrl = MSDCallbackAcceptPopUpURL;

        popupUrl = popupUrl.replace(/CIFIDTag/g, cif); //replace CIF
        popupUrl = popupUrl.replace(/CallbackSessionIDTag/g, ucid); // replace Callback Session ID
        popupUrl = popupUrl.replace(/ParentChatSessionIDTag/g, chatsessionid); // replace VA Chat Session ID
        popupUrl = popupUrl.replace(/CallStartDateTag/g, date); // replace Callback Start Date
        popupUrl = popupUrl.replace(/CallStartTimeTag/g, time); // replace Callback Start Time
        popupUrl = popupUrl.replace(/CallBackType/g, 'CallbackType'); // replace Callback Type
        popupUrl = popupUrl.replace(/AgentIdTag/g, global_LanID); // replace AgentId
        popupUrl = popupUrl.replace(/IntentTag/g, ''); // replace IntentTag
        popupUrl = popupUrl.replace(/ActionFlagTag/g, '3'); // replace ActionFlagTag

        log.LogDetails(log.logType.Info, "DynamicsCRMStartCallbackPopUpScreen", "popup URL:[" + popupUrl + "]", false);

        GetTabReferenceObj(intid).CRMWindowData.URL = popupUrl;
        GetTabReferenceObj(intid).CRMWindowData.WindowHandle = window.open(popupUrl,
            "MSDCallback" + intid,
            "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
            ",height=" + DynamicsCRMScreenResolution_Height() +
            ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
            ",left=" + DynamicsCRMScreenResolution_Position_Left());

        // alert indicatior for Incoming chat
        ShowNotification("You have new ", "Callback");
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMStartCallbackPopUpScreen()", ex, false);
    }
}

//Callback Chat End CRM Popup
function DynamicsCRMEndCallbackPopUpScreen(intid, callOutcome, status) {
    try {
        if (isCRMEnabled) {
            return;
        }

        if (global_voiceCallHasCallback) {
            return;
        }
        var date = GetCurrentDate("YYYYMMDD");
        var time = GetCurrentTime("HHmmss");
        var popupUrl;

        try {
            popupUrl = GetTabReferenceObj(intid).CRMWindowData.URL;
        }
        catch (e) {
            popupUrl = MSDCallbackAcceptPopUpURL;
        }

        popupUrl = popupUrl.slice(0, -1); // remove last char
        popupUrl += '4'; // add char, that you want to be placed instead of the earlier action flag

        popupUrl += '&CallEndDate=CallEndDateTag';
        popupUrl = popupUrl.replace(/CallEndDateTag/g, date); //replace Callback End Time
        popupUrl += '&CallEndTime=CallEndTimeTag';
        popupUrl = popupUrl.replace(/CallEndTimeTag/g, time); //replace Callback End Time

        popupUrl += '&Calloutcome=CallOutcomeFlag';
        if (callOutcome === "Record Successfully updated") {
            popupUrl = popupUrl.replace(/CallOutcomeFlag/g, status); //replace status as closed
        }
        else if (callOutcome === "RescheduleRequest success") {
            popupUrl = popupUrl.replace(/CallOutcomeFlag/g, status); //replace status as callback
        }
        else {
            popupUrl = popupUrl.replace(/CallOutcomeFlag/g, "Unsuccessful"); //replace status as unsuccesful	
        }

        log.LogDetails(log.logType.Info, "DynamicsCRMEndCallbackPopUpScreen", "popup URL:[" + popupUrl + "]", false);

        try {

            //change the URL
            GetTabReferenceObj(intid).CRMWindowData.WindowHandle.location.href = popupUrl;
        }
        catch (e) {
            GetTabReferenceObj(intid).CRMWindowData.WindowHandle = window.open(popupUrl,
                "MSDCallback" + intid,
                "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
                ",height=" + DynamicsCRMScreenResolution_Height() +
                ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
                ",left=" + DynamicsCRMScreenResolution_Position_Left());
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMEndCallbackPopUpScreen()", ex, false);
    }
}

//QMS CRM popup
function QMSCRMPopup(event) {
    try {
        var intid = event.InteractionID;
        var dnis = event.DNIS;
        //check if DNIS is IBG DNIS
        if (dnis !== "" && IBGDNISList.indexOf(dnis) > -1) {
            //check if CRM is QMS
            if (agentCRMName === "QMS") {
                //check if agent is QMS Enabled
                if (isCRMEnabled) {
                    // do a QMS Pop up
                    var popupUrl = QMSPopUpURL.replace(/LANGUAGETAG/g, 'English'); //replace language
                    popupUrl = popupUrl.replace(/IVRSELECTTAG/g, event.LastMenu); // replace ivr tag
                    popupUrl = popupUrl.replace(/UCIDTAG/g, $('#hfUCID' + intid).val()); // replace ucid tag
                    popupUrl = popupUrl.replace(/CALLERIDTAG/g, $('#hfcallerID' + intid).val()); // replace caller id tag

                    GetTabReferenceObj(intid).CRMWindowData.URL = popupUrl;
                    GetTabReferenceObj(intid).CRMWindowData.CTITrackID = $('#hfUCID' + intid).val();
                    GetTabReferenceObj(intid).CRMWindowData.ACWFlag = true;
                    GetTabReferenceObj(intid).CRMWindowData.WindowHandle = window.open(popupUrl, "QMSURL", "menubar=no,location=no,scrollbars=no,width=1032,height=746");
                }
            }
        }
        else if (dnis && isCallbackNumber(dnis)) {
            // change status to ACW
            ChangeStatus(global_DeviceID, 'acw', '0');
            AddVoiceTab(intid, dnis, false, false, event);
            DisableCallbackDetailsButtons(intid);
            custom_getdetailsforUCID(intid, $('#hfCBUCID' + intid).val());
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.QMSCRMPopup()", ex, false);
    }
}

//ACW CRM popup
function ACWQMSCRMUpdate() {
    var date = GetCurrentDate("YYYYMMDD");
    var time = GetCurrentTime("HHmmss");
    try {
        for (i = 0; i < global_InteractionTabs.length; i++) {
            if (global_InteractionTabs[i].CRMWindowData.ACWFlag === true) {
                global_InteractionTabs[i].CRMWindowData.ACWEndTime = date + '_' + time;
                var popupUrl = ACWPopUpURL;
                var ucid = global_InteractionTabs[i].CRMWindowData.CTITrackID;
                popupUrl = popupUrl.replace(/UCIDTAG/g, ucid); //replace UCID
                popupUrl = popupUrl.replace(/ACWStartTag/g, global_InteractionTabs[i].CRMWindowData.ACWStartTime); //replace ACW Start Time
                popupUrl = popupUrl.replace(/ACWEndTag/g, global_InteractionTabs[i].CRMWindowData.ACWEndTime); //replace ACW End Time
                global_InteractionTabs[i].CRMWindowData.WindowHandle.location.href = popupUrl;
                return;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.ACWQMSCRMUpdate()", ex, false);
    }
}
