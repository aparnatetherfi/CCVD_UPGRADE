﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CommandManager.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------
// Load all intents from DB
// ----------------------------------------------------------------------------------

function LoadIntents() {
    try {
        var data = {};
        data.deviceid = global_DeviceID;
        //command(data, "LoadIntents");
        tmac_LoadIntents("LoadIntentsDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadIntents()", ex, false);
    }
}

function LoadIntentsDone(data) {
    try {
        global_Intents = data;
        if (global_Intents !== null) {
            //do nothing
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadIntentsDone()", ex, false);
    }
}
//-----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------
// Load the Aux codes from Database
// ----------------------------------------------------------------------------------

function LoadAUXCodes() {
    try {
        if (isLoadAgentAux)
            tmac_LoadAUXCodesForAgent("LoadAUXCodesDone", null);
        else
            tmac_LoadAUXCodes("LoadAUXCodesDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodes()", ex, false);
    }
}

function LoadAUXCodesDone(data) {
    try {
        global_AUXCodes = data;

        //tmac_ui.js
        AuxCodesLoaded();

    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodesDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Get the List of Staffed Agents from TMAC Server
// ----------------------------------------------------------------------------------
function GetAgentListStaffed(intid, dialogName, buttonName, icon) {
    try {
        var data = {};
        data.intid = intid;
        data.isLocal = true;
        data.dialogName = dialogName;
        data.buttonName = buttonName;
        data.icon = icon;
        tmac_GetAgentListStaffed("GetAgentListStaffedDone", data, false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentListStaffed()", ex, false);
    }
}

function GetAgentListStaffedDone(data, object) {
    try {
        global_AgentList = data.filter(function (d) { return d.LoginID !== global_AgentID; });
        AgentListLoaded(object, data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentListStaffedDone()", ex, false);
    }
}

function ReloadAgentList(type, buttonId) {
    try {
        var obj = {};
        obj.type = type;
        obj.buttonId = buttonId;
        DisableButton("#" + buttonId);
        ShowKendoLoading("#" + type);
        tmac_GetAgentListStaffed("ReloadAgentListDone", obj, false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.ReloadAgentList()", ex, false);
    }
}

function ReloadAgentListDone(data, object) {
    try {
        EnableButton("#" + object.buttonId, "refresh", "icon");
        LoadAgentListGrid(object.type, data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.ReloadAgentListDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// load the favoirute skill/vdn list from DB
// ----------------------------------------------------------------------------------
function GetFavouriteSkills() {
    try {
        var data = {};
        data.deviceid = global_DeviceID;
        //command(data, "GetFavouriteSkills");
        tmac_GetFavouriteSkills("GetFavouriteSkillsDone");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFavouriteSkills()", ex, false);
    }
}

function GetFavouriteSkillsDone(data) {
    try {
        global_FavouriteSkills = data;
        if (global_FavouriteSkills !== null) {
            //bind favourite list grid
            LoadFavListGrid();
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFavouriteSkillsDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// load speed dial numbers from the database
// ----------------------------------------------------------------------------------
function GetSpeedDialNumber() {
    var data = {};
    data.deviceid = global_DeviceID;
    tmac_GetSpeedDialNumber("GetSpeedDialNumberDone");
}

function GetSpeedDialNumberDone(data) {
    global_SpeedDial = data;
    if (global_SpeedDial !== null) {
        //bind speed dial list
        LoadSpeedDialGrid("speedDialMakeCallGrid", "txtMakeCallNumber");
        LoadSpeedDialGrid("speedDialGrid", "txtNumberTrans");
    }
}

// ----------------------------------------------------------------------------------
// Login to TMAC
// ----------------------------------------------------------------------------------

function Login(lanId, stationId, agentLoginId, forceReload, password, jsonData) {
    tmac_LoginWithJson("LoginDone", {}, lanId, stationId, agentLoginId, false, "", forceReload, password, jsonData);
}

function LoginDone(data, obj, nofaceauth) {
    try {
        if (data !== null) {
            if (data.ResultCode > 0) {
                // SAM 2020-07-28 Customer
                try {
                    if (nofaceauth != true && AppConfigs.Local.Login.faceAuthenticateOnLogin) {
                        //data.Data.AgentFeatures.forEach(function (item) 
                        for (var i = 0; i < data.Data.AgentFeatures.length; i++) {
                            item = data.Data.AgentFeatures[i];
                            //check to send mos value for this interaction
                            if (item.Feature === "IsFaceAuthenticationEnabled") {
                                if (item.IsEnabled) {

                                    getFaceAuthResults(data, obj);
                                    return;
                                }
                            }
                        }
                    }
                }
                catch (exx) { }

                if (data.ResultCode === 3) {
                    if (isVoiceBio) {
                        Login(obj._lanId, obj._stationId, obj._agentLoginId, true, obj._password, obj._jsonData);
                    } else {
                        UIkit.modal.confirm('Another session detected. Do you want to take it over?',
                            function () {
                                Login(obj._lanId, obj._stationId, obj._agentLoginId, true, obj._password, obj._jsonData);
                            },
                            function oncancel() {
                                location.reload();
                            });
                    }
                    return;
                }
                //  Show TF authentication
                if (data.ResultCode === 4) {
                    //  Hide standard inputs and show custom
                    $(".stdLoginInput").addClass("uk-display-none");
                    $("#divCustomAuthentication").removeClass("uk-display-none");
                    $("#login_card").removeClass("blur-background");
                    $("#login_btn").removeClass("disabled");
                    $("#login_spinner").addClass("uk-display-none");
                    $("#div_station").css("display", "none");

                    if (JSON.parse(data.Data).customAuthType === "otp") {
                        $("#loginOtp").removeAttr("hidden");
                        $("#div_otp").removeClass("uk-display-none");
                        $("#login_btn").text("Submit");
                        ShowNotify("OTP has been sent to your phone number.", "success", null, "top-center");
                    }
                    return;
                }

                //inform the user about the session takeover. This message will show "Agent[123] is already logged in to station[44008].
                // You will takeover this session".
                //once clicked "OK" it will continue to login
                if (data.ErrorDetails !== "") {
                    if (isVoiceBio) {
                        LoginToTMAC(data, obj);
                    } else {
                        UIkit.modal.confirm(data.ErrorDetails,
                            function () {
                                LoginToTMAC(data, obj);
                            },
                            function oncancel() {
                                location.reload();
                            });
                    }
                    return;
                } else {
                    //  VP: Jul 9, '20: Set remote configs 
                    //  If it is single page sign in, load the configs to mainscreen env as well. Else, only this login iFrame configs will be loaded
                    let configElement = new ConfigElement();
                    let parent_configElement = new parent.ConfigElement();
                    let loadSuccess = false;
                    let parent_loadSuccess = false;
                    if (data.OtherData != null && data.OtherData.ItemOne !== "") {
                        loadSuccess = configElement.LoadRemote(JSON.parse(data.OtherData.ItemOne), 0);

                        if (isSinglePageLogin)
                            parent_loadSuccess = parent_configElement.LoadRemote(JSON.parse(data.OtherData.ItemOne), 0);

                    } else if (isConfigSourceLocal) {
                        loadSuccess = configElement.LoadRemote(null, 1);

                        if (isSinglePageLogin)
                            parent_loadSuccess = loadSuccess = parent_configElement.LoadRemote(null, 1);

                    } else
                        log.LogDetails("Error", "command_manager.LoginDone", "data.OtherData from Server is null.", false);

                    if (!loadSuccess || (isSinglePageLogin && !parent_loadSuccess)) {
                        ShowNotify("Remote Configurations failed to load.", "danger", null, "top-center");
                        return;
                    }

                    LoginToTMAC(data, obj);
                }
            } else if (data.ResultCode === -1) {
                ShowNotify("Station ID not provided", "danger", null, "top-center");
            } else if (data.ResultCode === -2) {
                ShowNotify("LAN ID not provided", "danger", null, "top-center");
            } else if (data.ResultCode === -3) {
                if (isVoiceBio)
                    ShowNotify("Invalid LAN ID detected. Please contact administrator for TMAC access.", "danger", null, "top-center");
                else
                    InvalidLanID();
            } else if (data.ResultCode === -4) {
                ShowNotify("Invalid Extension", "danger", null, "top-center");
            } else if (data.ResultCode === -5) {
                ShowNotify("Destination is in use. " + data.ErrorDetails, "danger", null, "top-center"); // This will show a message saying "Agent[123] is already logged in to station[234]"
            } else if (data.ResultCode === -6) {
                ShowNotify("Invalid Extension", "danger", null, "top-center");
            } else if (data.ResultCode === -7) {
                ShowNotify("Station Busy", "danger", null, "top-center");
            } else if (data.ResultCode === -8) {
                ShowNotify("Station not allowed", "danger", null, "top-center");
            } else if (data.ResultCode === -9) {
                ShowNotify("Station ID is in use. " + data.ErrorDetails, "danger", null, "top-center"); // This will show a message saying "Agent[123] is already logged into station[234]"
            } else if (data.ResultCode === -10) {
                ShowNotify("Agent login failed", "danger", null, "top-center");
            } else if (data.ResultCode === -15) {
                ShowNotify("Agent not logged in to any station, Please login to AIC", "danger", null, "top-center");
                if (isVoiceBio && retryLogin) {
                    CheckAgentStaffed();
                    $(".an-loader").removeClass("uk-display-none");
                }
            } else if (data.ResultCode === -5001) {
                ShowNotify(data.ResultMessage, "danger", null, "top-center");
            } else if (data.ResultCode === -17) {
                ShowNotify(data.ResultMessage, "danger", null, "top-center");
            } else
                //  If TF authentication initiation fails
                if (data.ResultCode === -18) {
                    ShowNotify(data.ResultMessage, "danger", null, "top-center");
                    return;
                }
                else {
                    //login failed
                    ShowNotify(data.ResultMessage, "danger", null, "top-center");
                }
            if (data.ResultCode < 0)
                EnableLogInButton();
        } else {
            ShowNotify("Server Error", "danger", null, "top-center");
            EnableLogInButton();
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoginDone()", ex, false);
    }
}

function LoginToTMAC(data, obj) {
    try {
        //global_LoginRedisplay = !obj.invalidLanId;
        var key = data.AgentSessionKey;
        key = key.substring(0, 5);
        global_successfullyLoggedInData = {};

        if (isVoiceBio) {
            global_successfullyLoggedInData.global_DeviceID = data.Data.StationID;
        }
        else {
            global_successfullyLoggedInData.global_DeviceID = global_DeviceID;
        }
        global_successfullyLoggedInData.global_AgentID = global_AgentID;
        global_successfullyLoggedInData.global_LanID = global_LanID;
        global_successfullyLoggedInData.global_Password = FromEncodedString(global_Password);
        global_successfullyLoggedInData.data = data;
        global_successfullyLoggedInData.tmacServer = _tmacServer;
        global_successfullyLoggedInData.global_TmacSignalRUrl = global_TmacSignalRUrl;
        global_successfullyLoggedInData.global_LoginJsonData = global_LoginJsonData;

        Application_Window_Current_Width = CalculateTMACWindowWidth();
        Application_Window_Current_Height = CalculateTMACWindowHeight();

        global_successfullyLoggedInData.Application_Window_width = Application_Window_Current_Width;
        global_successfullyLoggedInData.Application_Window_height = Application_Window_Current_Height;

        //store the TMAC data to local storage
        localStorage.setItem("TMACdata-" + global_DeviceID, JSON.stringify(global_successfullyLoggedInData));
        //store the device id as tab id for the session
        sessionStorage.setItem("deviceID", global_DeviceID);

        if (isVoiceBio) {
            DocumentReady();
            TriggerResize();
        }
        //for single page login set parent global_successfullyLoggedInData from this global_successfullyLoggedInData as parent is mainscreen and this is an iframe
        else if (isSinglePageLogin) {
            parent.global_successfullyLoggedInData = global_successfullyLoggedInData;
            parent.DocumentReady();
        } else {
            var amac = window.open("MainscreenUI.html?ID=" + ToEncodedString(global_DeviceID),
                key, "menubar=no,resizable=yes,location=no,scrollbars=no,width=" + Application_Window_Current_Width + ",height=" + Application_Window_Current_Height);

            if (isCACS) {
                amac.moveTo(screen.width, screen.height);
            }
            else {
                amac.moveTo(0, 0);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoginToTMAC()", ex, false);
    }
    return;
}

function EnableLogInButton() {
    $("#login_spinner").addClass("uk-display-none");
    $("#login_card").removeClass("blur-background");
    $("#login_btn").removeClass("disabled");
}

// ----------------------------------------------------------------------------------
// After successfully login, get the data
// ----------------------------------------------------------------------------------

function GetSuccessfullyLoggedInData() {
    var data = global_successfullyLoggedInData;
    if (!jQuery.isEmptyObject(data)) {
        setTimeout(CloseLoginPage, 5000);
        return data;
    }
    return null;
}

// ----------------------------------------------------------------------------------
// Close the TMAC Window
// ----------------------------------------------------------------------------------
function CloseLoginPage() {
    EnableLogInButton();
    $("#login_card").addClass("uk-display-none");
    $("#login_spinner").addClass("uk-display-none");
    $("#login_card").removeClass("blur-background");
    if (isCloseLoginPage) window.close();
}

// ----------------------------------------------------------------------------------
// After succesfully login
// ----------------------------------------------------------------------------------
function SuccessfullyLoggedIn(loginData) {
    try {
        let data = loginData.data;
        if (data.EventName === "LoginReload") {
            global_ReloadDone = true;
            //SIP Dialer - Check for Callback Call - Changed by Mukesh - 8th Aug, 2016
            //SIP Dialer - Callback Extensions now will be range eg. 1000-1500
            var str = callbackExtensionRange;
            var indices = 0;
            for (var i = 0; i < str.length; i++) {
                if (str[i] === "-") {
                    indices = i;
                }
            }
            callbackVDNListStart = str.substring(0, indices);
            callbackVDNListEnd = str.substring((indices + 1), str.length);
        } else {
            global_ReloadDone = false;
        }

        //set the status couter to zero
        statusTimeCounter = 0;

        //get the agent profile data
        let agentData = data.Data;

        //add lanId, password and AgentSessionKey to pass in AssignAgentData since for agent setting updated we do not get these
        //to make it as common method we are adding only login done
        agentData.LanID = loginData.global_LanID;
        agentData.Password = loginData.global_Password;
        agentData.AgentSessionKey = data.AgentSessionKey;

        //assign the agent data
        AssignAgentData(agentData, false);

        //assign the _tmacServer value
        _tmacServer = loginData.tmacServer;

        // set the Curent TMAC window Resolution.
        Application_Window_Current_Width = loginData.Application_Window_width;
        Application_Window_Current_Height = loginData.Application_Window_height;

        //load tmac files
        LoadConfigurations();

        //load initial global data
        setTimeout(function () {
            LoadIntents();
            LoadAUXCodes();
            LoadAgentListGrids();
            GetFavouriteSkills();
            GetSpeedDialNumber();
            InitConversionSkillsGrid();
        }, 1000);

        //show home page (wallboard,status,timer,etc)
        AgentLoginSuccess();

        //Get Color Code
        GetQueueTimeColorCode();

        //load work codes
        if (!$.isEmptyObject(isWorkCode)) LoadCallWorkCodes();

        //show the outbound call icon when agent is logged in with station id
        if (global_LanID.indexOf(global_DeviceID) < 0 || agentType === "MS Agent") {
            $(".make-call-li").removeClass("uk-display-none");
        }

        //get dashboard if medium is through tmac server
        if (isDashboardEnabled && !isSignalrConnector) {
            GetMiniDashboard(defaultDashboardInterval, globalChannelList, null);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SuccessfullyLoggedIn()", ex, false);
    }
}
// ----------------------------------------------------------------------------------
// Logout of TMAC
// ----------------------------------------------------------------------------------

function Logout(deviceid) {
    try {
        var data = {};
        data.deviceid = deviceid;
        global_LogoutCommandSend = true;
        tmac_Logout("LogoutDone", null, deviceid, false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.Logout()", ex, false);
    }
}

function LogoutDone(data) {
    if (data.ResultCode === 0) {
        //clear local storage TMACdata
        localStorage.removeItem("TMACdata-" + FromEncodedString(getQueryStringValue("ID")));
        //for single page login remove the session storage 'deviceID'
        if (isSinglePageLogin) {
            sessionStorage.removeItem("deviceID");
        }
        //go back to login page
        AgentLogoutSuccessCustom();
        DispatchEvent("TMACEvents", {
            EventName: "AgentLogoutSuccess"
        });
        window.close();
        if (isSinglePageLogin) location.reload();
    } else {
        //logout failed
        global_LogoutCommandSend = false;
        log.LogDetails("Error", "CommandManager.LogoutDone()", "Logout Failed", true);
    }
}

// ----------------------------------------------------------------------------------
// GetEvent List - Polling to TMAC Server
// ----------------------------------------------------------------------------------

function DynamicScriptsLoaded() {
    //start event processing after 1 seconds as the UI is loaded dynamically
    if (window.tmacconnectprotocol !== "signalr") {
        setTimeout(function () {
            GetEvent();
        }, 2000);
    }
}

function GetEvent() {
    tmac_GetEvent(null, null, global_DeviceID, global_AgentSessionKey, false)
}

function GetEventDone(data, obj) {
    try {
        if (data !== null) {
            //eventHandler.js
            HandleEvent(data);
        }

        //perform generic actions
        PerformInfiniteActions();

        //if the agent is logged out then stop polling until window close
        if (obj.pollEvents && !global_LogoutCommandSend && !global_AgentForcedLogoffEventFlag) {
            //set timer for next event poll
            setTimeout(GetEvent, 600);
            //GetEvent();
        }
    } catch (ex) {
        //
    }
}

// ----------------------------------------------------------------------------------
// Change Agent Status
// ----------------------------------------------------------------------------------

function ChangeStatus(deviceid, statustype, statuscode) {
    var old = $('#divAuxStatus').text();
    $('#divAuxStatusType').text("");
    $('#divAuxStatus').text("Please wait");
    $('#divAuxStatus').addClass("loading");
    if (agentStatusOnMain) {
        $('#agentStatus').text("Please wait");
        $('#agentStatus').addClass("loading");
    }
    tmac_ChangeStatus("ChangeStatusDone", { currentStatus: old }, deviceid, statustype, statuscode);
}

function ChangeStatusDone(data, obj) {
    if (data.EventName === "AgentStatusChangeEvent") {
        //ChangeStatus success
        //bind new status to status control
        AgentStatusChange(data);
    } else {
        //change the ui status
        $('#divAuxStatus').text(obj.currentStatus);
        $('#divAuxStatus').removeClass("loading");
        if (agentStatusOnMain) {
            $("#agentStatus").text(obj.currentStatus);
            $('#agentStatus').removeClass("loading");
        }
        //ChangeStatus failed
        log.LogDetails("Error", "CommandManager.ChangeStatusDone()", "Change Status Failed", true);
    }
}

// ----------------------------------------------------------------------------------
// Answer Incoming Voice Call
// ----------------------------------------------------------------------------------
function AnswerCall(deviceId, intId) {
    //check for the tab reference
    if (GetTabReferenceObj(intId)) {
        //get the type of tab
        let tabType = GetTabReferenceObj(intId).type;
        //for voice and if the subtype is webrtc
        if (tabType === "voice" && GetVoiceReferenceObj(intId).subType === "webrtc") {
            //set the process media messages flag to true
            GetVoiceReferenceObj(intId).processMediaMessages = true;
            //process all the cached media messages
            ProcessMediaMessages(intId);
            return;
        }
    }
    $("#btnAnswer" + intId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
    tmac_AnswerCall("AnswerCallDone", intId, deviceId, intId);
}

function AnswerCallDone(data, intId) {
    if (data.ResultCode === 0) {
        //AnswerCall success
    } else {
        //AnswerCall failed
        log.LogDetails("Error", "CommandManager.AnswerCallDone()", "Answer Call Failed", true);
    }
    $("#btnAnswer" + intId).html('<i class="material-icons notranslate">call</i>');
}

// ----------------------------------------------------------------------------------
// Disconnect Voice Call
// ----------------------------------------------------------------------------------

function DisconnectCall(deviceid, intId) {
    $("#btnDrop" + intId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
    tmac_DisconnectCall("DisconnectCallDone", intId, deviceid, intId);
}

function DisconnectCallDone(data, intId) {
    if (data.ResultCode === 0) {
        //DisconnectCall success
        if (isPOM) POMDisconnectCallDone();
    } else {
        //DisconnectCall failed
        ShowNotify("Disconnect Failed", "danger", null, "top-center");
    }
    $("#btnDrop" + intId).html('<i class="material-icons notranslate">call_end</i>');
}

// ----------------------------------------------------------------------------------
// Hold Voice Call
// ----------------------------------------------------------------------------------

function HoldCall(deviceid, intId, obj) {
    //check for the tab reference
    if (GetTabReferenceObj(intId)) {
        //get the type of tab
        let tabType = GetTabReferenceObj(intId).type;
        //for voice and if the subtype is webrtc
        if (tabType === "voice" && GetVoiceReferenceObj(intId).subType === "webrtc") {
            //call webrtc hold call
            HoldMSCall(intId);
            return;
        }
    }

    if (obj === null) {
        $("#btnHold" + intId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        obj = {};
        obj.intid = intId;
        obj.chatoncall = false;
        obj.buttonId = "#btndialogtransfercall";
        obj.icon = "swap_horiz";
    }
    tmac_HoldCall("HoldCallDone", obj, deviceid, intId);
}

function HoldCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //HoldCall success
        if (obj.chatoncall) {
            tmac_InitiateCall("InitiateCallDone", obj, obj.deviceid, obj.number, obj.intid, obj.source, obj.sourceid, "");
        }
    } else {
        //HoldCall failed
        ShowNotify("Hold Call Failed", "danger", null, "top-center");
    }
    if (!obj.chatoncall) {
        $("#btnHold" + obj.intid).html('<i class="material-icons notranslate">phone_paused</i>');
        $("#btnUnHold" + obj.intid).html('<i class="material-icons notranslate">phone_in_talk</i>');
    }
}

// ----------------------------------------------------------------------------------
// Unhold Voice Call
// ----------------------------------------------------------------------------------

function UnHoldCall(deviceid, intId, obj) {
    //check for the tab reference
    if (GetTabReferenceObj(intId)) {
        //get the type of tab
        let tabType = GetTabReferenceObj(intId).type;
        //for voice and if the subtype is webrtc
        if (tabType === "voice" && GetVoiceReferenceObj(intId).subType === "webrtc") {
            //call webrtc hold call
            UnHoldMSCall(intId);
            return;
        }
    }

    if (obj === null) {
        $("#btnUnHold" + intId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        obj = {};
        obj.intid = intId;
        obj.chatoncall = false;
    }
    tmac_UnHoldCall("UnHoldCallDone", obj, deviceid, intId);
}

function UnHoldCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //UnHoldCall success
    } else {
        //UnHoldCall failed
        ShowNotify("UnHold Call Failed", "danger", null, "top-center");
    }
    if (!obj.chatoncall) {
        $("#btnUnHold" + obj.intid).html('<i class="material-icons notranslate">phone_in_talk</i>');
        $("#btnHold" + obj.intid).html('<i class="material-icons notranslate">phone_paused</i>');
    }
}

// ----------------------------------------------------------------------------------
// Transfer Voice Call
// ----------------------------------------------------------------------------------

function TransferCallCommand(deviceid, interactionid, number, comment, obj) {
    tmac_TransferCall("TransferCallCommandDone", obj, deviceid, interactionid, number, comment);
}

function TransferCallCommandDone(data, obj) {
    if (data.ResultCode === 0) {
        //TransferCall success
        //if the type is text chat no confirm dialog
        if (obj.type !== "TextChatTransfer") {
            OpenConfirmDialog(obj.type);
        } else {
            //if the type is TextChatTransfer close the transfer dialog here else it will be closed in OpenConfirmDialog
            CloseTransferDialog();
            GetChatReferenceObj(obj.intId).isTransfer = true;
        }
    } else {
        //TransferCall failed
        ShowNotify("Transfer Call Failed", "danger", null, "top-center");
    }
    //get the icon type
    let iconType = obj.icon === "BT" ? "tag" : "icon";
    EnableButton(obj.buttonId, obj.icon, iconType);
}

function TransferBlind(deviceid, interactionid, number, comment, obj) {
    tmac_TransferBlind("TransferBlindDone", obj, deviceid, interactionid, number, comment);
}

function TransferBlindDone(data, obj) {
    if (data.ResultCode === 0) {
        //TransferBlind success
    } else {
        //TransferBlind failed
        ShowNotify("Transfer Call Blind Failed", "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "tag");
}

// ----------------------------------------------------------------------------------
// Cancel Voice Call Transfer
// ----------------------------------------------------------------------------------

function TransferCancelCommand(deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;

    tmac_TransferCancel("TransferCancelCommandDone", data, deviceid, interactionid);
}

function TransferCancelCommandDone(data, object) {
    if (data.ResultCode === 0) {
        //TransferCancel success
        var obj = {};
        obj.intid = object.interactionid;
        obj.chatoncall = false;
        try {
            //check if it is a callback transfer, if yes disable the dial and submit button
            if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferInit) {
                DisableCallbackButtons(object.interactionid);
                $('#divCloseButton' + object.interactionid).css("visibility", "visible");
                $('#btnCloseTab' + object.interactionid).removeAttr('disabled', 'disabled');
            }
        } catch (ex) {
            //
        }
    } else {
        //TransferCancel failed
        ShowNotify("Transfer Cancel Failed", "danger", null, "top-center");
        //hide the confirm window
        HideConfirmDialog();
    }
}

// ----------------------------------------------------------------------------------
// Complete the Voice Call Transfer
// ----------------------------------------------------------------------------------

function TransferCompleteCommand(deviceid, interactionid) {
    try {
        var data = {};
        data.deviceid = deviceid;
        data.interactionid = interactionid;
        TransferCallCustom(interactionid);
        tmac_TransferComplete("TransferCompleteCommandDone", data, deviceid, interactionid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.TransferCompleteCommand()", ex, false);
    }
}

function TransferCompleteCommandDone(data, object) {
    if (data.ResultCode === 0) {
        try {
            //check if it is a callback transfer, if yes disable the dial and submit button
            if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferInit) {
                //update custom table 
                custom_UpdateCustomTableForCallbackTransfer(GetTabReferenceObj(object.interactionid).OtherData.srno, object.interactionid);
                //disable callback buttons
                DisableCallbackButtons(object.interactionid);
                //Update CRM
                //DynamicsCRMEndCallbackPopUpScreen(object.interactionid, "Record Successfully updated", "Closed");
                GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferComplete = true;
            }
            if (isPOM) {
                POMTransferCompleteDone(data, object);
            }
        } catch (ex) {
            //
        }
        //TransferComplete success
        ShowNotify("Transfer Completed", "success", null, "top-center");
    } else {
        //TransferComplete failed
        ShowNotify("Transfer Complete Failed", "danger", null, "top-center");
        //hide the confirm window
        HideConfirmDialog();
    }
}

// ----------------------------------------------------------------------------------
// Conference Voice Call
// ----------------------------------------------------------------------------------

function ConferenceCall(deviceid, interactionid, number, comment, obj) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.number = number;
    data.comment = comment;
    tmac_ConferenceCall("ConferenceCallDone", obj, deviceid, interactionid, number, comment);
}

function ConferenceCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //ConferenceCallDone success
        OpenConfirmDialog(obj.type);
    } else {
        //ConferenceCallDone failed
        ShowNotify("Conference Call Failed", "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Cancel Voice Call Conference
// ----------------------------------------------------------------------------------

function ConferenceCancel(deviceid, interactionid) {
    tmac_ConferenceCancel("ConferenceCancelDone", { intId: interactionid }, deviceid, interactionid);
}

function ConferenceCancelDone(data, obj) {
    if (data.ResultCode === 0) {
        //ConferenceCancel success
        // get the voice reference for the current conferencing interaction
        let vRef = GetVoiceReferenceObj(obj.intId);
        // check the subtype
        if (vRef && vRef.subType === "webrtc") {
            //hide the confirm window
            HideConfirmDialog();
        }
    } else {
        //ConferenceCancel failed
        ShowNotify("Conference Cancel Failed", "danger", null, "top-center");
        //hide the confirm window
        HideConfirmDialog();
    }
}

// ----------------------------------------------------------------------------------
// Complete Voice Call Conference
// ----------------------------------------------------------------------------------

function ConferenceCompleteCommand(deviceid, interactionid) {
    tmac_ConferenceComplete("ConferenceCompleteCommandDone", { intId: interactionid }, deviceid, interactionid);
}

function ConferenceCompleteCommandDone(data, obj) {
    if (data.ResultCode === 0) {
        //ConferenceComplete success
    } else {
        //ConferenceComplete failed
        ShowNotify("Conference Complete Failed", "danger", null, "top-center");
        //hide the confirm window
        HideConfirmDialog();
    }
}

// ----------------------------------------------------------------------------------
// Dial a call from TMAC
// ----------------------------------------------------------------------------------

function MakeCall(deviceid, number, value, intid) {
    log.LogDetails("Info", "Inside CommandManager.MakeCall()", "", false);
    var data = {};

    var hasWhiteSpaces;
    var regex;
    var regexChars;
    var hasSpecialChars;
    var hasChars;
    var isNotANumber;
    var source;
    var sourceid;
    var customNumberToDial = number.trim();
    data.deviceid = deviceid;
    if (value === "customMakeCallCallerId") {
        disconnectByHandleType = "callback";
        customNumberToDial = number.trim();
        if (customNumberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        } else if (customNumberToDial === global_DeviceID || customNumberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(customNumberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(customNumberToDial);
        hasChars = regexChars.test(customNumberToDial);
        isNotANumber = isNaN(customNumberToDial);
        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }

        if (isCustomDialPrefixRegMobNumber) {
            if (trimDigitsBeforeMakeCall !== "") {
                customNumberToDial = customNumberToDial.substring(trimDigitsBeforeMakeCall);
            }
            number = customDialCallPrefix + customNumberToDial;
        }
        else {
            number = customNumberToDial;
        }
        source = "custom";
        sourceid = "";
    } else if (value === "customMakeCallPreferredNo") {
        disconnectByHandleType = "callback";
        customNumberToDial = number.trim();
        if (customNumberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        } else if (customNumberToDial === global_DeviceID || customNumberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(customNumberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(customNumberToDial);
        hasChars = regexChars.test(customNumberToDial);
        isNotANumber = isNaN(customNumberToDial);
        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }
        if (isCustomDialPrefixPrefNumber) {
            number = customDialCallPrefix + customNumberToDial;
        }
        else {
            number = customNumberToDial;
        }
        number = customNumberToDial;
        source = "custom";
        sourceid = "";
    } else {
        disconnectByHandleType = "makecall";
        var numberToDial = $("#txtMakeCallNumber").val();
        numberToDial = numberToDial.trim();

        if (numberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        } else if (numberToDial === global_DeviceID || numberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(numberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(numberToDial);
        hasChars = regexChars.test(numberToDial);
        isNotANumber = isNaN(numberToDial);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }

        if (value === "makecall") {
            DisableButton("#btndialogmakecall");
        }

        number = numberToDial;
        intid = "";

        var val = document.getElementById('makeCallCb');
        source = "t";
        if (val.checked) {
            sourceid = "N";
        } else {
            sourceid = "Y";
        }
    }
    var obj = {};
    obj.intid = intid;
    obj.buttonId = "#btndialogmakecall";
    try {
        if (!GetChatReferenceObj(global_activeTabInteractionID).isDisconnected) {
            obj = {};
            obj.intid = "";
            obj.buttonId = "#btndialogmakecall";
            obj.deviceid = deviceid;
            obj.number = number;
            obj.source = source;
            obj.sourceid = sourceid;
            obj.chatoncall = true;
            HoldCall(global_DeviceID, global_activeTabInteractionID, obj);
            return;
        }
    } catch (e) {
        //
    }

    //command(data, "MakeCall", intid);
    tmac_InitiateCall("InitiateCallDone", obj, deviceid, number, intid, source, sourceid, "");
}

function InitiateCallDone(data, obj) {
    try {
        if (data.ResultCode === 0) {
            //MakeCall success
        } else {
            //MakeCall failed
            ShowNotify("Make Call failed: " + data.ResultMessage, "danger", null, "top-center");
            if (obj.intid !== "") {
                ChangeTabReferenceStatus(obj.intid, 'MakeCallFailed');
                //check if this is a callback tab. then enable dial buttons
                EnableCallbackDialButtons(obj.intid);
            }
        }
        if (obj.buttonId !== "") {
            EnableButton(obj.buttonId, "call", "icon");
        }
        if ((data === null || data.ResultCode !== 0) && obj.chatoncall) {
            //unhold chat if error on init voice call
            UnHoldCall(obj.deviceid, obj.intid, obj)
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InitiateCallDone()", ex, false);
    }
}

function MakeCallDone(data, obj) {
    try {
        if (data.ResultCode === 0) {
            //MakeCall success
        } else {
            //MakeCall failed
            ShowNotify("Make Call failed: " + data.ResultMessage, "danger", null, "top-center");
            ChangeTabReferenceStatus(obj.intId, 'MakeCallFailed');
            //check if this is a callback tab. then enable dial buttons
            EnableCallbackDialButtons(obj.intId);
        }
        if (obj.buttonId !== "") {
            EnableButton(obj.buttonId, "call", "icon");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.MakeCallDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Get Agent Status
// ----------------------------------------------------------------------------------
function GetAgentStatus(deviceid, agentid, object, destTmacServerName) {
    tmac_GetAgentStatus("GetAgentStatusDone", object, deviceid, agentid, destTmacServerName);
}

function GetAgentStatusDone(data, object) {
    if (data && data.ResultCode === 1) {
        //GetAgentStatus success
        GetGridAgentStatusDone(object, data.ResultMessage);
    } else {
        //GetAgentStatus failed
    }

    if (object.txtBox[0].id !== "txtNumberTrans") {
        EnableButton("#btndialogmakecall", "call", "icon");
        EnableButton("#btnConfMCall", "call_split", "icon");
    } else {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        EnableButton("#btndialogblindtransfercall", "BT", "tag");
    }

    //check if blind transfer should be disabled for any channel based on config
    if (global_CallType === "Transfer" && disableAgentBlindTransfer.Voice ||
        global_CallType === "TextChatTransfer" && disableAgentBlindTransfer.TextChat ||
        global_CallType === "FaxTransfer" && disableAgentBlindTransfer.Fax) {
        FadeOutButton("#btndialogblindtransfercall");
    }
}

function GetAgentStatusFull(agentid, object) {
    tmac_GetAgentStatusFull("GetAgentStatusFullDone", object, agentid);
}

function GetAgentStatusFullDone(data, object) {
    //GetAgentStatusFull Done
}

// ----------------------------------------------------------------------------------
// Get Queue Status
// ----------------------------------------------------------------------------------

function GetQueueStatus(deviceid, skillid, object) {
    var data = {};
    data.skillid = skillid;
    data.rowid = object;
    tmac_GetQueueStatus("GetQueueStatusDone", data, deviceid, skillid);
}

function GetQueueStatusDone(data, object) {
    if (data.EventName === "QueueStatusEvent") {
        //GetAgentStatus success
        GetQueueStatusSuccess(data, object);
    } else {
        //GetAgentStatus failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Transfer Call to IVR for TPIN Verification/OTP - Blind Transfer
// ----------------------------------------------------------------------------------

function TransferToIVR(deviceid, interactionid, type, languageid) {
    var intid = interactionid;
    var obj = {};
    obj.intid = intid;
    obj.type = type;
    TransferToIVRCustom(obj);
    tmac_TransferToIVR("TransferToIVRDone", obj, deviceid, intid, type, languageid);
}

function TransferToIVRDone(data, obj) {
    if (data.ResultCode === 0) {
        TransferToIVRDoneCustom(obj);
    } else {
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Close Tab
// ----------------------------------------------------------------------------------

function CloseTab(intId, ignoreAlert) {
    if (GetTabReferenceObj(intId)) {
        var isCompletionCode = CheckForCompletionCode(intId, ignoreAlert);
        if (isCompletionCode) {
            ConfirmTabClose(intId, function (intId) {
                $("#btnCloseTab" + intId + " i").removeAttr('class');
                $("#btnCloseTab" + intId + " i").addClass('uk-icon-spinner uk-icon-spin');
                $("#btnCloseTab" + intId + " i").attr('disabled', false);

                var data = {};
                data.deviceid = global_DeviceID;
                data.interactionid = intId;
                //inform the server
                tmac_CloseTab("CloseTabDone", data, global_DeviceID, intId, false);
            });
        }
    }
}

function ForceCloseTab(intid) {
    var data = {};
    data.deviceid = global_DeviceID;
    data.interactionid = intid;
    //inform the server
    tmac_CloseTab("CloseTabDone", data, global_DeviceID, intid, false);
}

function CloseTabDone(data, object) {
    try {
        if (data.ResultCode === 0) {
            //CloseTab success
            CloseUITab(object.interactionid);
            DispatchEvent("TMACEvents", {
                EventName: "CloseTabDone",
                Data: object
            });
        } else {
            //CloseTab failed
        }
        $("#btnCloseTab" + object.interactionid + " i").removeAttr('class');
        $("#btnCloseTab" + object.interactionid + " i").addClass('k-icon k-font-icon k-i-x');
        $("#btnCloseTab" + object.interactionid + " i").attr('disabled', false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.CloseTabDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Select Tab
// ----------------------------------------------------------------------------------

function SelectTab(deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;

    try {
        //inform the server if it is a not a callback tab
        if (GetTabReferenceObj(interactionid).type !== 'callback') {
            tmac_SelectTab("SelectTabDone", null, deviceid, interactionid);
        }
    } catch (ex) {
        //
    }
}

function SelectTabDone(data) {
    if (data.ResultCode === 0) {
        //SelectTab success

    } else {
        //SelectTab failed
    }
}

// ----------------------------------------------------------------------------------
// Open Intent
// ----------------------------------------------------------------------------------

function OpenIntent(deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.intent = intent;

    tmac_OpenIntent("OpenIntentDone", null, deviceid, interactionid, intent);
}

function OpenIntentDone(data) {
    if (data.ResultCode == 1) {
        //OpenIntent success
    } else {
        //OpenIntent failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}


// ----------------------------------------------------------------------------------
// Update Intent
// ----------------------------------------------------------------------------------

function UpdateIntent(deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.intent = intent;

    tmac_UpdateIntent("UpdateIntentDone", null, deviceid, interactionid, intent);
}

function UpdateIntentDone(data) {
    if (data.ResultCode == 1) {
        //UpdateIntent success
    } else {
        //UpdateIntent failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Load More History - Voice/Chat
// ----------------------------------------------------------------------------------

function LoadMoreHistory(deviceid, interactionid) {
    DisableLoadMoreButton(interactionid);

    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    tmac_LoadMoreHistory("LoadMoreHistoryDone", null, deviceid, interactionid);
}

function LoadMoreHistoryDone(data) {
    if (data.ResultCode === 1) {
        //LoadMoreHistory success
    } else {
        //LoadMoreHistory failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Load Interaction History on Demand - Voice/Chat
// ----------------------------------------------------------------------------------
function LoadInteractionHistoryOnDemand(deviceid, interactionid, cif, nric, phonenumber) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.cif = cif;
    data.nric = nric;
    data.phonenumber = phonenumber;

    tmac_LoadInteractionHistoryOnDemand("LoadInteractionHistoryOnDemandDone", null, deviceid, interactionid, cif, nric, phonenumber);
}

function LoadInteractionHistoryOnDemandDone(data) {
    if (data.ResultCode === 0) {
        //LoadInteractionHistoryOnDemandDone success
    } else {
        //LoadInteractionHistoryOnDemandDone failed
    }
}

// ----------------------------------------------------------------------------------
// Send Text Chat Message
// ----------------------------------------------------------------------------------
function SendTextChat(deviceid, intId, text, type, msgid, isAppMessage) {
    var data = FormatOutgoingTextChat(text, type, isAppMessage);
    if (data.isAppMessage) {
        SendTextChatAsAppMessage(deviceid, intId, data.text);
    } else {
        SendTextChatFromTemplateWithType(intId, data.text, GetChatReferenceObj(intId).selectedTemplateId, data.type, msgid);
    }
    $("#btnTextChat_FreezeAutoResponse" + intId).css("display", "inline-block");

    GetChatReferenceObj(intId).lastMessageId++;
}

function SendTextChatAsAppMessage(deviceid, intId, text) {
    tmac_SendAppMessage("SendTextChatDone", null, deviceid, intId, text);
}

function SendCustomAppMessage(string) {
    tmac_SendAppMessage("SendCustomAppMessageDone", null, global_DeviceID, global_activeTabInteractionID, text);
}

function SendCustomAppMessageDone(data, obj) {
    //
}

function SendTextChatFromTemplateWithType(intId, text, templateId, type, msgid, obj) {
    // check if the template id append to the json here only
    if (templateId && isReplyOnChat) {
        let msg = JSON.parse(text);
        msg.templateId = templateId;
        text = JSON.stringify(msg);
        templateId = "";
    }
    tmac_SendTextChatFromTemplateWithType("SendTextChatDone", obj, intId, text, templateId, type, msgid);
}

function SendTextChatDone(data, object) {
    if (data === 1) {
        //success
    } else {
        //failed
        ShowNotify("Message Sending Failed", "danger", null, "top-center");
    }
    SetCareToPos(document.getElementById("textChatMessage" + object.interactionid), 0);
}

function SendAVControlMessage(deviceId, interactionId, message, type, sessionId) {
    tmac_SendAVControlMessage("SendAVControlMessageDone", null, deviceId, interactionId, message, type);

    //to send WebRTC signals
    if (sendWebRTCInfo.signals) {
        SendWebRTCInfo(interactionId, "webrtcsignals", "agent", message, sessionId);
    }
}

function SendAVControlMessageDone(data, object) {
    if (data.ResultCode === 1) {
        //success
    } else {
        //failed
        log.LogDetails("Error", "TmacTextChatUI.SendAVControlMessageDone()", data.ResultMessage, false);
    }
}

function SendActionMessage(deviceId, interactionId, message) {
    //  Sample message format
    /*
    
    {
        source: "agent",            //  Where it originated from
        options: {
            param: "link",
            url: "https://10.133.146.11:15012/cust_specific_cobrowse/parallon.html"
        },
        data: {
            interactionId: "1002"
        },
        status: "request",          //  When responding, change it to "response"
        type: "cobrowse",
        eventName: "ActionMessage",
        id: uuid()
    }
    
    */

    tmac_SendActionMessage("SendActionMessageDone", JSON.parse(message), deviceId, interactionId, message);
}

function SendActionMessageDone(data, object) {

    let msg = data.ResultCode === 1 ? "successful" : "failed";
    switch (object.type) {
        case "sign":
            log.LogDetails(data.ResultCode === 1 ? "Success" : "Error", "TmacTextChatUI.SendActionMessageDone()", "Signature " + object.status + " " + msg, true);
            EnableButton("#btnTextChat_Signature" + object.data.interactionId, "gesture", "icon");
            break;
        case "cobrowse":
            log.LogDetails(data.ResultCode === 1 ? "Success" : "Error", "TmacTextChatUI.SendActionMessageDone()", "Co-browse " + object.status + " " + msg, true);
            FadeInButton("#btnTextChat_CoBrowse" + object.data.interactionId);
            break;
        default:
    }

    //  Failed
    if (data.ResultCode !== 1) {
        log.LogDetails("Error", "TmacTextChatUI.SendActionMessageDone()", data.ResultMessage, false);
    }
}

function SendTextChatWithType(intid, text, type, msgid, obj) {
    tmac_SendTextChatWithType("SendTextChatWithTypeDone", obj, intid, text, type, msgid);
}

function SendTextChatWithTypeDone(result, object, data) {
    let msg = result ? "successful" : "failed";
    switch (data.type) {
        case "sign":
            log.LogDetails(result ? "Success" : "Error", "TmacTextChatUI.SendTextChatWithTypeDone()", "Signature request " + msg, true);
            EnableButton("#btnTextChat_Signature" + data.interactionid, "gesture", "icon");
            break;
        default:
    }
}

// ----------------------------------------------------------------------------------
// End Text Chat Message
// ----------------------------------------------------------------------------------

function EndTextChat(deviceid, intId, isCallback, reason) {
    try {
        var msg = $("#hfCsatUrl" + intId).val();
        var msgid = uuid();
        if (msg) {
            if (isAppMessage) {
                var obj = {};
                obj.id = msgid;
                obj.message = msg;
                obj.messageType = "text";
                obj.type = "new";
                msg = JSON.stringify(obj);
            }
            SendTextChat(deviceid, intId, msg, "", "", false);
            $("#hfCsatUrl" + intId).val("");
        }

        var data = {};
        try {
            data.isCallback = isCallback;
            data.intid = intId;
        } catch (e) {
            data.isCallback = false;
        }
        tmac_EndTextChatWithReason("EndTextChatDone", data, deviceid, intId, reason);
        //tmac_EndTextChat("EndTextChatDone", data, deviceid, intId);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.EndTextChat()", ex, false);
    }
}

function EndTextChatDone(data, object) {
    try {
        if (data === 1) {
            if (object.isCallback) {
                setTimeout(function () {
                    log.LogDetails("Info", "CommandManager.EndTextChatDone()", "Adding Delay for iserve close " + GetCurrentDateTime(), false);
                    CloseTab(global_TextChatCallbackID);
                }, 1000);
                log.LogDetails("Info", "CommandManager.EndTextChatDone()", "After delay" + GetCurrentDateTime(), false);
            }
        }
        else {
            EnableButton("#btnTextChat_Disconnect" + object.intid, "close", "icon");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.EndTextChatDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Agent Initiated Callback
// ----------------------------------------------------------------------------------

function RegisterTextChatCallback(deviceid, interactionid, preferrednumber, preferredtime) {

    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.preferrednumber = preferrednumber;
    data.preferredtime = '20150316101722';
    preferredtime = '20150316101722';

    tmac_RegisterTextChatCallback("RegisterTextChatCallbackDone", data, deviceid, interactionid, preferrednumber, preferredtime);
}

function RegisterTextChatCallbackDone(data, object) {
    if (data.ResultCode === 0) {
        //we have to change the status to acw before disconnecting the chat
        ChangeStatus(global_DeviceID, 'acw', '0');
        global_endTextChatNotification[object.interactionid] = true;
        EndTextChat(object.deviceid, object.interactionid, true, "AgentInitiatedCallback");
        ShowNotify("Agent Initiated Callback - Disconnecting Chat", "info", null, "top-center");
    } else {
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Send TextChat Transfer/Conference notification to remote agent
// ----------------------------------------------------------------------------------

function SendTextChatTransferNotification(deviceid, interactionid, remoteAgentId, comment, customData, TmacServer, obj) {
    tmac_SendTextChatTransferNotificationToServer("SendTextChatTransferNotificationDone", obj, interactionid, remoteAgentId, TmacServer, comment, customData);
}

function SendTextChatTransferNotificationDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            var type = "";
            //send success
            if (obj && obj.type === "TextChatConference") {
                type = "conference";
            }
            else {
                type = "transfer";
            }

            //save the notifiaciton sent
            AddTransferNotificationRef(obj.intId, type, obj.to, obj.toServer);

            ShowNotify("Chat " + type + " notification sent to remote agent. Please wait for response.", "info", null, "top-center");
        } else {
            //send failed
            obj = {};
            if (global_CallType === "TextChatTransfer") {
                obj.buttonId = "#btndialogtransfercall";
                obj.icon = "swap_horiz";
                obj.type = "TextChatTransfer";
            }
            else if (global_CallType === "TextChatConference") {
                obj.buttonId = "#btnConfMCall";
                obj.icon = "call_split";
                obj.type = "TextChatConference";
            }
            EnableButton(obj.buttonId, obj.icon, "icon");
            log.LogDetails("Error", "TmacTextChatUI.SendTextChatTransferNotificationDone()", data.ResultMessage, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendTextChatTransferNotificationDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Transfer Text Chat to Queue
// ----------------------------------------------------------------------------------

function TransferTextChatToQueue(deviceid, interactionId, skillNumber, isBlind, chatMode, obj) {
    tmac_TransferTextChatToQueue("TransferTextChatToQueueDone", obj, deviceid, interactionId, skillNumber, isBlind, chatMode);
}

function TransferTextChatToQueueDone(data, obj) {
    if (data.ResultCode >= 0) {
        //send success
        //ShowNotify("Text Chat Transfer to queue is complete", "info", null, "top-center");
        favListGridItemSelectForChat = "";
        CloseTransferDialog();
    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Transfer Text Chat to Server
// ----------------------------------------------------------------------------------

function TransferTextChatToServer(deviceid, sourceagentid, intid, number, comment, chatSessionId, agentid, lineid, toAgentTmacServer, confType, chatMode, obj) {
    tmac_TransferTextChatToServer("TransferTextChatToServerDone", obj, deviceid, chatSessionId, sourceagentid, intid, number, comment, agentid, lineid, toAgentTmacServer, confType, chatMode);
}

function TransferTextChatToServerDone(data, obj) {
    if (data.ResultCode >= 0) {
        //TransferCall success
        //if the type is text chat no confirm dialog
        if (obj.type === "TextChatTransfer") {
            //if the type is TextChatTransfer close the transfer dialog here else it will be closed in OpenConfirmDialog
            CloseTransferDialog();
            GetChatReferenceObj(obj.intId).isTransfer = true;
        }
        else if (obj.type === "TextChatConference") {
            //if the type is TextChatConference close the conference dialog
            CloseConfDialog();
            GetChatReferenceObj(obj.intId).isConference = true;
        }
        else {
            OpenConfirmDialog("transfer");
        }
    } else {
        //TransferCall failed
        log.LogDetails("Error", "TmacTextChatUI.TransferTextChatToServerDone()", data.ResultMessage === "Fail" ? "Text chat transfer failed" : data.ResultMessage, true);
    }
    EnableButton(obj.buttonId, obj.icon, obj.icon === "BT" ? "tag" : "icon");
}

// ----------------------------------------------------------------------------------
// Send text chat tranfer notification response to requested agent
// ----------------------------------------------------------------------------------

function SendTextChatTransferNotificationRespond(toTmacServer, originatedAgentId, originatedInteractionID, response, comment, customdata) {
    //tmac_SendTextChatTransferNotificationRespond("SendTextChatTransferNotificationRespondDone", null, deviceid, originatedAgentId, originatedInteractionID, response, comment, customdata);
    tmac_SendTextChatTransferNotificationResponseToServer("SendTextChatTransferNotificationRespondDone", null, toTmacServer, originatedAgentId, originatedInteractionID, response, comment, customdata);
    //remove the item from ref
    transferNotificationPop = transferNotificationPop.filter(function (t) { return t.from !== originatedAgentId; });
}

function SendTextChatTransferNotificationRespondDone(data) {
    if (data.ResultCode >= 0) {
        //send success

    } else {
        //send failed
        log.LogDetails("Error", "CommandManager.SendTextChatTransferNotificationRespondDone()", data.ResultMessage, data.ResultCode !== -103);
    }
}

// ----------------------------------------------------------------------------------
// TextChat Typing Status Notification
// ----------------------------------------------------------------------------------

function TextChatNotifyTypingStatusChange(deviceid, intid, stat) {
    tmac_TextChatNotifyTypingStateChange("TextChatNotifyTypingStatusChangeDone", null, deviceid, intid, stat);
}

function TextChatNotifyTypingStatusChangeDone(data) {
    if (data.ResultCode >= 0) {
        //send success

    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Get Agent List for BargeIn
// ----------------------------------------------------------------------------------

function GetTextChatAgentListForBargein(teamid, supervisorid) {
    //tmac_GetTextChatAgentListForBargein("GetTextChatAgentListForBargeinDone", null, teamid, supervisorid);
    tmac_GetTextChatAgentListForBargeinAll("GetTextChatAgentListForBargeinDone", null, teamid, supervisorid);
}

function GetTextChatAgentListForBargeinDone(data) {
    var $kendoGrid = $("#barge_in_grid").data('kendoGrid');
    $kendoGrid.dataSource.data(data);
}

// ----------------------------------------------------------------------------------
// Barge In to the selected conversation
// ----------------------------------------------------------------------------------

function TextChatBargeinToServer(AgentID, InteractionID, SupervisorAvayaLoginID, tmacServer) {
    var obj = {};
    obj.agentId = AgentID;
    tmac_TextChatBargeinToServer("TextChatBargeinToServerDone", obj, AgentID, InteractionID, SupervisorAvayaLoginID, tmacServer);
}

function TextChatBargeinToServerDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            $("#bargeinchatTranscript").html("");
            AddMessageToChatbox("", "", "Agent " + obj.agentId + " conversation", "divider", "", "bargeinchatTranscript", "", false, null, "");
            var transcript = data.Data.Transcript;
            if (transcript.length !== 0) {
                $.each(transcript, function (i, val) {
                    var msg = "";
                    var msgid = uuid();
                    var msgDateTime = val.DateTime;
                    if (isAppMessage) {
                        var jsonData = JSON.parse(val.Message);
                        msg = jsonData.message;
                        if (val.Type.toLowerCase() == "agent")
                            AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "bargeinchatTranscript", jsonData.messageType, false, null, "Agent");
                        else if (val.TypetoLowerCase() == "user")
                            AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "bargeinchatTranscript", jsonData.messageType, false, null, "Customer");
                    } else {
                        msg = val.Message;
                        if (val.Type.toLowerCase() == "agent")
                            AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "bargeinchatTranscript", "", false, null, "Agent");
                        else if (val.Type.toLowerCase() == "user")
                            AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "bargeinchatTranscript", "", false, null, "Customer");
                    }
                });
            }
            $("#barge_in_dialog").data("kendoWindow").close();
            $("#barge_in_display_dialog").data("kendoWindow").center().open();
        } else {
            //send failed
            log.LogDetails("Error", "CommandManager.TextChatBargeinToServerDone()", data.ResultMessage, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.TextChatBargeinToServerDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Disconnect the call via headset
// ----------------------------------------------------------------------------------

function DisconnectCallByHandle(deviceid, btnId, type) {
    var obj = {};
    obj.buttonId = "#" + btnId;
    obj.icon = "call_end";
    obj.type = type;
    DisableButton(obj.buttonId);
    tmac_DisconnectCallByHandle("DisconnectCallByHandleDone", obj, deviceid, global_ConnectionHandle);
}

function DisconnectCallByHandleDone(data, obj) {
    EnableButton(obj.buttonId, obj.icon, "icon");
    //if the disconnect by handle is from callback then interachange the drop buttons display
    //as each button has its own purpose
    if (obj.type == "callback") {
        var intId = obj.buttonId.substring(obj.buttonId.length - 4, obj.buttonId.length);
        //enable dial buttons
        EnableButton("#btnDialCallerID" + intId, "call", "icon");
        EnableButton("#btnDialPCN" + intId, "call", "icon");
        //show DisconnectCall button
        $("#btndisconnectDial" + intId).addClass("uk-display-none");
        //hide DisconnectCallByHandle button
        $("#btnDrop" + intId).removeClass("uk-display-none");
    }
    else
        $("#btndisconnectSpan").addClass("uk-display-none");
    global_ConnectionHandle = "";
    CloseMakeCallDialog();
}

function GetTmacWallboardSkills(obj) {
    try {
        tmac_GetTmacWallboardSkills("GetTmacWallboardSkillsDone", obj);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetTmacWallboardSkills()", ex, false);
    }
}

function GetTmacWallboardSkillsDone(data, obj) {
    try {
        var skillData = data;

        if (obj && obj.elementId) {
            //  If channel prefix is not configured, load 0 skills
            if (transferListSkillFilterPrefix[obj.channel] != null) {
                let prefixLen = transferListSkillFilterPrefix[obj.channel].length;
                //  Filter skills requiredof this channel only
                skillData = data.filter(function (s) { return s.SkillName.toLowerCase().slice(0, prefixLen) === transferListSkillFilterPrefix[obj.channel].toLowerCase(); });
            } else {
                skillData = [];
            }
            //  Load it in the kendo widget
            var $kendoWidget = $('#' + obj.elementId).data(obj.widget);
            $kendoWidget.dataSource.data(skillData);
        } else {
            if (global_CallType === "TextChatTransfer") {
                skillData = data.filter(function (s) { return s.SkillName.toLowerCase().slice(0, 2) === transferListSkillFilterPrefix.TextChat.toLowerCase(); });
            } else if (global_CallType === "Transfer") {
                skillData = data.filter(function (s) { return s.SkillName.toLowerCase().slice(0, 2) === transferListSkillFilterPrefix.Voice.toLowerCase(); });
            } else if (global_CallType === "FaxTransfer") {
                skillData = data.filter(function (s) { return s.SkillName.toLowerCase().slice(0, 3) === transferListSkillFilterPrefix.Fax.toLowerCase(); });
            }
            var $kendoDrpDwn = $('#transfer_skill_list').data('kendoDropDownList');
            $kendoDrpDwn.dataSource.data(skillData);
            $kendoDrpDwn.dataSource.sort({
                field: "SkillName",
                dir: "asc"
            });
            $kendoDrpDwn.text("Select skill..");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetTmacWallboardSkillsDone()", ex, false);
    }
}

function FreezeTextChatAutoResponse(deviceid, interactionid) {
    try {
        var obj = {};
        obj.intid = interactionid;
        tmac_FreezeTextChatAutoResponse("FreezeTextChatAutoResponseDone", obj, deviceid, interactionid);
        DisableButton("#btnTextChat_FreezeAutoResponse" + interactionid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.FreezeTextChatAutoResponse()", ex, false);
    }
}

function FreezeTextChatAutoResponseDone(data, obj) {
    try {
        EnableButton("#btnTextChat_FreezeAutoResponse" + obj.intid, "stop", "icon");
        $("#btnTextChat_FreezeAutoResponse" + obj.intid).hide();
        if (GetChatReferenceObj(obj.intid).chatMode === "text")
            log.LogDetails("Success", "CommandManager.FreezeTextChatAutoResponseDone()", "Chat auto response freeze successful", true);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.FreezeTextChatAutoResponseDone()", ex, false);
    }
}

//added on 2017-07-21
function GetAgentSessionsList(teamid, supervisorid, agentid, interactionid, tmacServer, object) {
    try {
        tmac_GetAgentSessionsList("GetAgentSessionsListDone", object, teamid, supervisorid, agentid, interactionid, tmacServer);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentSessionsList()", ex, false);
    }
}

function GetAgentSessionsListDone(resultdata, userobject) {
    try {
        AgentSessionsListLoaded(resultdata, userobject);
    } catch (ex) { }
}

//added on 2017-09-27
function GetLoggedInAgentList(tmacServer) {
    try {
        if (!tmacServer) tmacServer = _tmacServer;
        tmac_GetLoggedInAgentList("GetLoggedInAgentListDone", null, tmacServer);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetLoggedInAgentList()", ex, false);
    }
}

function GetLoggedInAgentListDone(resultData, userObject) {
    try {
        if (resultData !== null) {
            //filter the agents for his team
            resultData = resultData.filter(function (a) { return a.AgentLoginID !== global_AgentID && a.TeamID === global_TeamID; });
            agent_chat.agentlist_loaded(resultData, userObject);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetLoggedInAgentListDone()", ex, false);
    }
}

function InteractionSaveComment(interactionid, comment) {
    try {
        tmac_Interaction_SaveComment(null, null, interactionid, comment);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InteractionSaveComment()", ex, false);
    }
}

function SendIMToAgent(agentId, message) {
    try {
        tmac_SendIMToAgent(null, null, agentId, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgent()", ex, false);
    }
}


function SendIM(toagent, tointeraction, totmacserver, message) {
    try {
        var userobject = {};
        userobject.toagent = toagent;
        userobject.tointeraction = tointeraction;
        userobject.totmacserver = totmacserver;
        userobject.message = message;
        tmac_SendIM("SendIMDone", userobject, toagent, tointeraction, totmacserver, message)
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIm()", ex, false);
    }
}

function SendIMDone(resultdata, userobject, inputdata) {
    try {
        // Agent session not available
        if (resultdata === -480) {
            // Assuming the agent may have relogged in to another server, so try to get the server id of that agent
            tmac_GetTmacServerId("SendIMIfServerIdChanged", userobject, null, inputdata.toagent, null);
        }





    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendImDone()", ex, false);
    }
}

function SendIMIfServerIdChanged(resultobject, userobject, inputdata) {
    try {
        if (!resultobject) {

            log.LogDetails("Error", "CommandManager.SendIMIfServerIdChanged()", "Agent session not found", true);
            return;
        }
        var agentChatRef = agent_chat.get_agent_chat_ref(inputdata.agentid);

        if (agentChatRef && agentChatRef.FromTmacServer !== resultobject) {
            agentChatRef.FromTmacServer = resultobject;
            SendIM(agentChatRef.FromAgentId, "", agentChatRef.FromTmacServer, userobject.message);
        } else {
            log.LogDetails("Error", "CommandManager.SendIMIfServerIdChanged()", "Agent session not found", true);
        }
    } catch (e) {
        log.LogDetails("Error", "CommandManager.SendIMIfServerIdChanged()", ex, false);
    }
}

function SendIMToAgentFromSupervisor(toAgentId, AgentName, agentStatus, agentProfile, message) {
    try {
        var obj = {};
        obj.FromAgentId = toAgentId;
        obj.FromAgentName = AgentName;
        obj.UserProfileForAgent = agentProfile;
        obj.CurrentAgentStatus = agentStatus;
        obj.Message = message;
        obj.mType = "own";
        tmac_SendIMToAgent("SendIMToAgentFromSupervisorDone", obj, toAgentId, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgentFromSupervisor()", ex, false);
    }
}

function SendIMToAgentFromSupervisorDone(resultdata, userobject) {
    try {
        //open IM box
        agent_chat.chat_received(userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgentFromSupervisorDone()", ex, false);
    }
}

function SendCommandToAgent(obj, fromIntId, toAgentId, toTmacServer, toIntId, name, message) {
    try {
        tmac_SendCommandToAgent("SendCommandToAgentDone", obj, fromIntId, toAgentId, toTmacServer, toIntId, name, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendCommandToAgent()", ex, false);
    }
}

function SendCommandToAgentDone(resultdata, userobject) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendCommandToAgentDone()", ex, false);
    }
}

function LoadAgentReminders(status, startTime, endTime, message) {
    try {
        tmac_GetAgentReminders(null, null, global_DeviceID, global_AgentID, status, startTime, endTime, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAgentReminder()", ex, false);
    }
}

//CreateAgentReminder(string deviceid, string agentid, string reminddate, string remindtime,string message)
function CreateAgentReminder(reminddate, remindtime, message) {
    try {
        DisableButton("#btnSetReminder");
        tmac_CreateAgentReminder("CreateAgentReminderDone", null, global_DeviceID, global_AgentID, reminddate, remindtime, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.CreateAgentReminder()", ex, false);
    }
}

function CreateAgentReminderDone(resultdata, userobject) {
    try {
        EnableButton("#btnSetReminder", "add", "icon");
        $("#add_reminder_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.CreateAgentReminderDone()", ex, false);
    }
}

//UpdateAgentReminder(string deviceid, string agentid, string id, string status, string message)
function UpdateAgentReminder(id, status, message, obj) {
    try {
        tmac_UpdateAgentReminder("UpdateAgentReminderDone", obj, global_DeviceID, global_AgentID, id, status, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.UpdateAgentReminder()", ex, false);
    }
}

function UpdateAgentReminderDone(resultdata, userobject) {
    try {
        if (userobject !== null) {
            if (userobject.status == "delete") {
                EnableButton("#btnDeleteReminder", "delete", "icon");
            } else if (userobject.status == "edit") {
                $("#txtReminder").removeAttr("readonly", "readonly");
                EnableButton("#btnEditReminder", "mode_edit", "icon");
                $("#add_reminder_dialog").data("kendoWindow").close();
            }
            $("#btnDeleteReminder").addClass("disabled");
            $("#btnEditReminder").addClass("disabled");
            $("#btnClearSelectedReminder").addClass("disabled");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.UpdateAgentReminderDone()", ex, false);
    }
}

function GetCustomerList() {
    try {
        tmac_GetWorkItems("GetCustomerListDone", null, "textchat", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetCustomerList()", ex, false);
    }
}

function GetCustomerListDone(resultdata, userobject) {
    try {
        customer_chat.customerlistloaded(resultdata, userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetCustomerListDone()", ex, false);
    }
}

function GetUserDomainList() {
    try {
        tmac_GetUserDomainList("GetUserDomainListDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetUserDomainList()", ex, false);
    }
}

function GetUserDomainListDone(data, obj) {
    try {
        //remove loading indicator
        $('.k-i-arrow-60-down').removeClass('k-i-loading');
        if (data !== null)
            $("#domainList").data("kendoDropDownList").dataSource.data(data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetUserDomainListDone()", ex, false);
    }
}

function GetQueueTimeColorCode() {
    try {
        tmac_GetQueueTimeColorCode("GetQueueTimeColorCodeDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetQueueTimeColorCode()", ex, false);
    }
}

function GetQueueTimeColorCodeDone(data) {
    try {
        SetColorCodes(data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodesDone()", ex, false);
    }
}

function LoadCallWorkCodes(intid) {
    try {
        tmac_LoadCallWorkCodes("LoadCallWorkCodesDone", (intid ? { intid: intid } : null), global_DeviceID, isWorkCodeWithTeam ? global_TeamID : "");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadCallWorkCodes()", ex, false);
    }
}

function LoadCallWorkCodesDone(data, obj) {
    try {
        global_WorkCodeList = data;
        if (isWorkCodeWithGroup) {
            var workGroup = {};
            $.each(global_WorkCodeList, function (i, val) {
                if (val.ParentID == '0') {
                    workGroup[val.Code] = { i: val.Code, Name: val.Name, Pid: val.ParentID };
                }
            });
            for (i = 0; i < global_WorkCodeList.length; i++) {
                if (global_WorkCodeList[i].ParentID == '0') {
                    global_WorkCodeList.splice(i--, 1);
                } else {
                    global_WorkCodeList[i].ParentName = workGroup[global_WorkCodeList[i].ParentID].Name;
                }
            }
        }

        if (obj && obj.intid && $("#workcodes" + obj.intid).data("kendoMultiSelect")) {
            $("#workcodes" + obj.intid).data("kendoMultiSelect").dataSource.data(global_WorkCodeList);
            log.LogDetails("Success", "CommandManager.LoadCallWorkCodesDone()", "WorkCode list loaded successfully", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadCallWorkCodesDone()", ex, false);
    }
}

function SetCallWorkCode(intid, code) {
    try {
        tmac_SetCallWorkCode("SetCallWorkCodeDone", null, global_DeviceID, intid, code);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SetCallWorkCode()", ex, false);
    }
}

function SetCallWorkCodeDone(data) {
}

function RemoveCallWorkCode(intid, code) {
    try {
        tmac_RemoveCallWorkCode("RemoveCallWorkCodeDone", null, global_DeviceID, intid, code);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.RemoveCallWorkCode()", ex, false);
    }
}

function RemoveCallWorkCodeDone(data) {
}

function SendGenericCTICommand(commandName, userobject, data) {
    try {
        tmac_SendGenericCTICommand("SendGenericCTICommandDone", commandName, userobject, data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendGenericCTICommand()", ex, false);
    }
}

function SendGenericCTICommandDone(data, obj) {
    try {
        if (data === 0 ||
            obj.method === "GetConsultDestinationAgentsList" ||
            obj.method === "GetCallbackDestsForType" ||
            obj.method === "WrapUpCallContact" ||
            obj.method === "SetCustomerData" ||
            obj.method === "GetCustomerContact")
            window[obj.method + "Done"](data, obj);
        else
            log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", obj.method + " Failed", true);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", ex, false);
    }
}

function GetFaxLineNumbers() {
    try {
        tmac_GetFaxLineNumbers(function (data, obj) {
            try {
                faxLineNumbers = [];
                $.each(data, function (i, val) {
                    if (val.SendEnabled)
                        faxLineNumbers.push(val.FaxLine);
                });
                $('#DNISList').data('kendoDropDownList').dataSource.data(faxLineNumbers);
                $("#DNISList").data("kendoDropDownList").text("Select a fax line...");
            } catch (ex) {
                log.LogDetails("Error", "CommandManager.GetFaxLineNumbers():Callback", ex, false);
            }
        }, null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxLineNumbers()", ex, false);
    }
}

function GetFaxTemplateNames() {
    try {
        tmac_GetFaxTemplateNames(function (data, obj) {
            try {
                $.each(data, function (i, val) {
                    var item = faxTemplates.filter(function (t) { return t.Name === val.Name; });
                    //if the item is ACK template i.e. Type "0" and if the item already added to the list dont add
                    if (val.Type !== "0" && item.length === 0) {
                        faxTemplates.push({
                            Name: val.Name,
                            Type: val.Type === "1" ? "cover" : "body",
                            Template: ""
                        });
                    }
                });
            } catch (ex) {
                log.LogDetails("Error", "CommandManager.GetFaxTemplateNames():Callback", ex, false);
            }
        }, null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNames()", ex, false);
    }
}

function GetFaxTemplate(id, name, type) {
    try {
        //fade off the submit button
        FadeOutButton("#btnSaveAndSubmit");
        //hide the template iframe
        $("#faxTemplateEditor").addClass("uk-display-none");
        //show the loader
        $("#faxTemplateLoader").removeClass("uk-display-none");
        $("#fax_template_editor_dialog").data("kendoWindow").center().open();
        setTimeout(function () {
            TriggerResize();
        }, 200);
        //check if we had already cached the template then dont go to server
        var template = GetFaxTemplateRef(name) ? GetFaxTemplateRef(name).Template : null;
        if (template) {
            log.LogDetails("Info", "CommandManager.GetFaxTemplates()", "Loading template for [" + name + "] from local cache", false);
            GetFaxTemplateDone(GetFaxTemplateRef(name).Template, { id: id, name: name, cache: false });
        }
        else {
            tmac_GetFaxTemplate("GetFaxTemplateDone", { id: id, name: name, cache: true }, name, type);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplates()", ex, false);
    }
}

function GetFaxTemplateDone(template, obj) {
    try {
        var allInputs = template.match(/#input,[0-9]+,[0-9]+#/g);
        var allTextareas = template.match(/#textarea,[0-9]+,[0-9]+,[0-9]+,[0-9]+#/g);

        // Replace all input text to html tag
        $.each(allInputs, function (i, val) {
            // Get the input tag limitation values
            let inputSplit = val.replace(/#/g, '').split(',');
            template = template ? template.replace(val, '<input maxLength="' + inputSplit[1] + '" style="width:' + inputSplit[2] + '"px /> ') : "";
        });
        // replace all textarea text to html tag
        $.each(allTextareas, function (i, val) {
            //get the textarea tag limitation values
            let txtAreaSplit = val.replace(/#/g, '').split(',');
            //replace the text to html tag with input limitations
            template = template ? template.replace(val, '<textarea maxLength="' + txtAreaSplit[1] + '" rows="' + txtAreaSplit[2] + '" cols="' + txtAreaSplit[3] + '" max-line="' + txtAreaSplit[4] + '" ></textarea> ') : "";
        });

        OpenFaxTemplateEditor(obj.id, template);
        //check whether to cache the template or not 
        if (template && obj.cache) {
            GetFaxTemplateRef(obj.name).Template = template;
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateDone()", ex, false);
    }
}

function SendFax(intid, file, faxNumber, DNIS, fileName, type) {
    try {
        tmac_SendFax(function (result, obj) {
            var resultMessage = result.ResultMessage === "Success" ? "Fax initiated successfully" : "Fax initiation failed, Please try again later";
            log.LogDetails(result.ResultMessage, "CommandManager.SendFax():Callback", resultMessage, true);
        }, null, intid, file, faxNumber, DNIS, fileName, type);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNames()", ex, false);
    }
}

function SendMultipleFaxItem(intid, faxNumber, DNIS, selectedItems) {
    try {
        tmac_SendMultipleFaxItem(function (result, obj) {
            var resultMessage = result.ResultMessage === "Success" ? "Fax initiated successfully" : "Fax initiation failed, Please try again later";
            log.LogDetails(result.ResultMessage, "CommandManager.SendFaxWithTypeDone()", resultMessage, true);
        }, null, intid, faxNumber, DNIS, selectedItems);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendMultipleFaxItem()", ex, false);
    }
}

function PullQueueItem(obj, channel, itemid) {
    try {
        tmac_PullQueueItem("PullQueueItemDone", obj, channel, itemid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.PullQueueItem()", ex, false);
    }
}

function PullQueueItemDone(data, userObject) {
    try {
        log.LogDetails(data.ResultCode === 1 ? "Success" : "Error", "CommandManager.PullQueueItemDone()", data.ResultMessage, true);
        //info the supervisor about pull failure if this pull request is from supervisor
        if (userObject.isSupervisor) {
            //check if the supervisor indo is available
            if (userObject.supervisorInfo) {
                //get the supervisor agent id
                var sAgentId = userObject.supervisorInfo.agentId;
                //get the suprevisor server name
                var sTmacServer = userObject.supervisorInfo.tmacServer;
                //get the transfer data
                var transferData = userObject.transferData;
                //create event data
                var eventData = {
                    EventName: "GenericTMACEvent",
                    SubEventName: "AgentActionEvent",
                    JsonData: JSON.stringify({
                        Type: "WorkbenchAction",
                        Action: "PullQueueItemStatus",
                        isSuccess: data.ResultCode === 1,
                        TransferData: mergeObjects({
                            agentName: global_AgentName
                        }, transferData),
                        Message: data.ResultMessage
                    })
                };
                //call server to add event to the supervisor session
                tmac_AddEventToAgentSession(null, { userObject: userObject }, sAgentId, eventData, false, sTmacServer);
            }
            else {
                log.LogDetails("Error", "CommandManager.PullQueueItemDone()", "Supervisor info is not available to notify the supervisor", false);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.PullQueueItemDone()", ex, false);
    }
}

function ComposeSMS(fromNumber, toNumber, srcIntid, obj) {
    try {
        tmac_SMS_Compose("ComposeSMSDone", obj, global_DeviceID, toNumber, fromNumber, srcIntid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.ComposeSMS()", ex, false);
    }
}

function ComposeSMSDone(resultdata, userobject) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.ComposeSMSDone()", ex, false);
    }
}

function SendSMS(intid, msg, obj) {
    try {
        tmac_SMS_SendMessage("SendSMSDone", obj, global_DeviceID, intid, msg);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendSMS()", ex, false);
    }
}

function SendSMSDone(resultdata, userobject) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendSMSDone()", ex, false);
    }
}

function InvokeRestCall(data, obj, url) {
    try {
        tmac_RestCall(InvokeRestCallDone, obj, data, url);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InvokeRestCall()", ex, false);
    }
}

function InvokeRestCallDone(stat, userObject, userData, resultData) {
    try {
        if (stat) {
            InvokeRestCallDoneCustom(userObject, resultData);
        }
        else {
            log.LogDetails("Error", "CommandManager.InvokeRestCallDone()",
                "Rest call failed: source: " + userObject.source + ", method: " + userObject.method, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InvokeRestCallDone()", ex, false);
    }
}

function GetMiniDashboard(interval, channel, obj) {
    try {
        tmac_GetMiniDashboard("GetMiniDashboardDone", obj, interval, channel);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetMiniDashboard()", ex, false);
    }
}

function GetMiniDashboardDone(resultdata, userobject) {
    try {
        //$('.countUpMe').text("0");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetMiniDashboardDone()", ex, false);
    }
}

function GetVipData(callerId, idType, idNo, obj) {
    try {
        tmac_GetVipData("GetVipDataDone", obj, callerId, idType, idNo);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetVipData()", ex, false);
    }
}

function GetVipDataDone(resultdata, userobject) {
    try {
        ShowVIPMessage(resultdata, userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetVipDataDone()", ex, false);
    }
}

function SaveVideoSnap(sessionid, intid, nric, name, phone, email, base64, clid, cif, subChannel, groupId, obj) {
    try {
        //  If params are null, pass empty
        if (!nric)
            nric = "";
        if (!name)
            name = "";
        if (!phone)
            phone = "";
        if (!email)
            email = "";
        if (!clid)
            clid = "";
        if (!cif)
            cif = "";
        if (!groupId)
            groupId = "";

        tmac_SaveVideoSnap("SaveVideoSnapDone", obj, sessionid, intid, nric, name, phone, email, base64, clid, cif, subChannel, groupId);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SaveVideoSnap()", ex, false);
    }
}

function SaveVideoSnapDone(resultdata, userobject, inputdata) {
    try {
        AddMessageToChatbox(inputdata.intid, "", resultdata.ImageUrl, "agent", "", "divTxtChatTranscript", "image", false, {}, global_AgentName.split(" ")[0]);
        GetChatReferenceObj(inputdata.intid).avCallSnapshots.push(resultdata.ImageUrl);

        // 2020-07-08 SAM added this new method to save data to IH table
        var text = '<img src="' + resultdata.ImageUrl + '" style="height:300px;"/>';

        tmac_UpdateInteractionHistory(null, null, "TextChat", GetChatReferenceObj(inputdata.intid).sessionId,
            "", "", "", "", "", text, "Out", global_AgentID, GetChatReferenceObj(inputdata.intid).sessionId,
            "SnapShot", false, "", false, false, "", false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SaveVideoSnapDone()", ex, false);
    }
}

function GetInteractionHistory(obj, data) {
    try {
        tmac_GetInteractionHistory("GetInteractionHistoryDone", obj, data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetInteractionHistory()", ex, false);
    }
}

function GetInteractionHistoryDone(resultdata, userobject, inputdata) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetInteractionHistoryDone()", ex, false);
    }
}

function UpdateFaxStatus(intid, message) {
    try {
        var userobject = {};
        tmac_UpdateFaxStatus(function (result, obj) {
            log.LogDetails("Info", "CommandManager.UpdateFaxStatus()", "UpdateFaxStatus: " + result, false);
        }, userobject, intid, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.UpdateFaxStatus()", ex, false);
    }
}

function SendInteractionTransferNotificationToServer(userObject, channel, interactionid, toAgentId, toTmacServer, comment, otherData) {
    try {
        tmac_SendInteractionTransferNotificationToServer("SendInteractionTransferNotificationToServerDone", userObject, channel, interactionid, toAgentId, toTmacServer, comment, otherData);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendInteractionTransferNotificationToServer()", ex, false);
    }
}

function SendInteractionTransferNotificationToServerDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            var type = "";
            //send success
            if (obj && obj.type.toLowerCase().indexOf("conference") > 0) {
                type = "conference";
            }
            else
                type = "transfer";

            //save the notifiaciton sent
            AddTransferNotificationRef(obj.intId, type, obj.to, obj.toServer);

            ShowNotify(obj.channel + " " + type + " notification sent to remote agent. Please wait for response.", "info", null, "top-center");
        } else {
            //send failed
            obj = {};
            if (global_CallType.toLowerCase().indexOf("transfer") >= 0) {
                obj.buttonId = "#btndialogtransfercall";
                obj.icon = "swap_horiz";
            }
            else if (global_CallType.toLowerCase().indexOf("conference") >= 0) {
                obj.buttonId = "#btnConfMCall";
                obj.icon = "call_split";
            }
            EnableButton(obj.buttonId, obj.icon, "icon");
            log.LogDetails("Error", "TmacTextChatUI.SendTextChatTransferNotificationDone()", data.ResultMessage, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendInteractionTransferNotificationToServerDone()", ex, false);
    }
}

function SendInteractionNotificationResponseToServer(eventData, response) {
    try {
        var comment = $("#comment_on_confirmation").val().trim();
        tmac_SendInteractionNotificationResponseToServer("SendInteractionNotificationResponseToServerDone", null, eventData, comment, response);
        //remove the item from ref
        transferNotificationPop = transferNotificationPop.filter(function (t) { return t.from !== eventData.FromAgentID; });
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendInteractionNotificationResponseToServer()", ex, false);
    }
}

function SendInteractionNotificationResponseToServerDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            //send success
        } else {
            //send failed
            log.LogDetails("Error", "CommandManager.SendInteractionNotificationResponseToServerDone()", data.ResultMessage, data.ResultCode !== -103);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendInteractionNotificationResponseToServerDone()", ex, false);
    }
}

function InteractionTransferToServer(obj, eventData) {
    try {
        tmac_InteractionTransferToServer("InteractionTransferToServerDone", obj, eventData);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InteractionTransferToServer()", ex, false);
    }
}

function InteractionTransferToServerDone(data, obj) {
    try {
        if (data.ResultCode === 0) {
            if (obj.type.toLowerCase().indexOf("transfer") >= 0) {
                //close transfer list dialog
                CloseTransferDialog();
            }
            else if (obj.type.toLowerCase().indexOf("conference") >= 0) {
                //close conference list dialog
                CloseConfDialog();
            }

            //invoke to type success method
            window[obj.type + "Success"](data, obj);
        } else {
            log.LogDetails("Error",
                "TmacTextChatUI.InteractionTransferToServerDone()",
                data.ResultMessage,
                true);
        }
        EnableButton(obj.buttonId, obj.icon, obj.icon === "BT" ? "tag" : "icon");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InteractionTransferToServerDone()", ex, false);
    }
}

function TransferInteractionToQueue(userobject, channel, interactionId, skillNumber, otherData) {
    try {
        tmac_TransferInteractionToQueue("TransferInteractionToQueueDone", userobject, channel, interactionId, skillNumber, otherData);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.TransferInteractionToQueue()", ex, false);
    }
}

function TransferInteractionToQueueDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            favListGridItemSelect = "";
            CloseTransferDialog();
            ForceCloseTab(obj.intId);
            ShowNotify(data.ResultMessage, "success", null, "top-center");
        } else {
            //send failed
            ShowNotify(data.ResultMessage, "danger", null, "top-center");
        }
        EnableButton(obj.buttonId, obj.icon, "icon");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.TransferInteractionToQueueDone()", ex, false);
    }
}

function ConvertInteraction(userobject, interactionId, channel, skillNumber, otherData) {
    try {
        tmac_ConvertInteraction(function (data, obj, inputdata) { }, userobject, interactionId, channel, skillNumber, otherData);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.ConvertInteraction()", ex, false);
    }
}

function GetFaxAddressBook(faxLine) {
    try {
        if (faxNumberSelect) faxNumberSelect[0].selectize.clear();
        tmac_GetFaxAddressBook(function (data, obj) {
            try {
                var faxGrpDd = $('#faxNumberGroups').data('kendoDropDownList');
                faxGrpDd.dataSource.data(data);
                if (data.length > 0) {
                    faxGrpDd.enable();
                } else {
                    faxGrpDd.enable(false);
                }
                faxGrpDd.text("Select an address book...");
            } catch (ex) {
                log.LogDetails("Error", "CommandManager.GetFaxAddressBook():Callback", ex, false);
            }
        }, null, faxLine);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxLineNumbers()", ex, false);
    }
}

function GetFaxRecipients(adddressBookId) {
    try {
        tmac_GetFaxRecipients(function (data, obj) {
            try {
                //check whether the count of numbers in selected group does not cross max limit
                if (data.length <= maxFaxLineRecipents) {
                    //Clear Fax Numbers text box
                    faxNumberSelect[0].selectize.clear(true);
                    //Iterate through the slected group numbers
                    data.forEach(function (recipient) {
                        //Set the selected group numbers to Fax Numbers text box
                        faxNumberSelect[0].selectize.addOption({ value: recipient.FaxNumber, text: recipient.RecipientDisplay });
                        faxNumberSelect[0].selectize.addItem(recipient.FaxNumber, true);
                    });
                } else {
                    log.LogDetails("Error", "CommandManager.GetFaxLineNumbersDone()", "Fax Numbers exceeded the limit of " + maxFaxLineRecipents, true);
                }
            } catch (ex) {
                log.LogDetails("Error", "CommandManager.GetFaxRecipients():Callback", ex, false);
            }
        }, null, adddressBookId);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxLineNumbers()", ex, false);
    }
}

function StoreWebRTCCommStats(stats, obj, callback) {
    try {
        tmac_StoreWebRTCCommStats(stats, callback, obj)
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.StoreWebRTCCommStats()", ex, false);
    }
}