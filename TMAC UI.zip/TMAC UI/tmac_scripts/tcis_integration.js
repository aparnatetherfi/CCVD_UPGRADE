// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TCISIntegration.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //need not add in versioning as this is a utility component
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

var connConfig = {
    urls: [],
    protocol: null,
    type: 'TCIS_Integration',
    queryString: '',
    hub: '',
    isLogging: true,
    timeout: 10000
};

var tcisCon = new function (options) {
    let _this = this;

    _this.urls = ["http://localhost:55005/TCIS"];
    _this.hubName = "CustomApplicationHub";
    _this.qs = {};

    _this.connectCounter = 1;
    _this.connectUrlCount = 0;
    _this.pendingRequest = {};
    _this.con;
    // following will be set for last snapshot/screenshot/violation details to send release blackout request
    _this.lastSnapshotUrl = "";
    _this.lastScreenshotUrl = "";
    _this.lastViolation = "";

    _this.configure = function (config) {
        try {

            // _this.con = $.hubConnection(_this.urls[_this.connectUrlCount]);
            _this.con = new SignalRConnector(_this.urls, "webSockets", "tcisIntegration", {}, _this.hubName, true, 5000);
            _this.hub = _this.con ? _this.con.hub : {};
            _this.registerHubEvents(_this.con.hub);
            _this.con.connect();
            _this.con.onConnected = function (instance) {
                try {
                    _this.sendAgentCurrentStatus();
                } catch (e) {
                    //
                }
            };
            srConn.push(_this.con);
            if (_this.testingButtonsEnabled) {
                _loadTestingButtons();
            }
        } catch (ex) {
            log.LogDetails("Error", "TcisIntegration.SignalRConfiguration()", ex, false);
        }
    }

    /**
	 * Registers various hub events
	 * @param {any} hub
	 */
    _this.registerHubEvents = function (hub) {
        try {

			/**
			 * message : string - message to be displayed in tmac ui
			 * type : string (Error/Success/Warning/Info) red/green/orange/blue
			 */
            hub.on('ShowAlertMessage', function (message, type) {
                log.LogDetails(type, "TcisIntegration.ShowAlertMessage()", message, true);
            });

			/**
			 * name : string - status name to change
			 * type : string status code to change
			 */
            hub.on('ChangeStatus', function (statusName, statusCode) {
                try {
                    ChangeStatus(global_DeviceID, statusName, statusCode);
                } catch (ex) {
                    log.LogDetails("Error", "TcisIntegration.ChangeStatus", ex, false);
                }
            });

			/**
			 * data: {} - action data json string
			 */
            hub.on('NewAction', function (data) {
                try {
                    let action = JSON.parse(data);
                    if (action.ActionName) {
                        if (typeof _this.takeAction[action.ActionName] === "function") {
                            _this.takeAction[action.ActionName](action);
                        }
                    }
                } catch (ex) {
                    log.LogDetails("Error", "TcisIntegration.SignalRConfiguration.onAgentMachineDetailsReceived", ex, false);
                }
            });
        } catch (ex) {
            log.LogDetails("Error", "TcisIntegration.RegisterHubEvents()", ex, false);
        }
        return hub;
    }

    _this.takeAction = {
        transferCall: function (data) {
            let intid = global_activeTabInteractionID;
            let comment = "";
            let number = "10001";
            let obj = {};
            //TransferBlind(global_DeviceID, intid, number, comment, obj);
            DisconnectCall(global_DeviceID, intid);
            _this.sendAlertToAgent("TCIS transfered call to " + number, _getSupervisorId());
        },
        changeStatus: function (data) {
            let state = data.state ? data.state : "";
            let currentStatus = global_LastAgentStat ? global_LastAgentStat.Status : "";
            ChangeStatus(global_DeviceID, "aux", "0");
            _this.sendAlertToAgent("TCIS changed status to " + state, _getSupervisorId());
        },
        warning: function (data) {
            let types = [
                "Error",
                "Debug",
                "Success",
                "Info"
            ];
            if (data.message && data.message.text) {
                let type = (types.indexOf(data.message.type) >= 0) ? data.message.type : "Debug";
                log.LogDetails(type, "TcisIntegration.RegisterHubEvents()", data.message.text, true);
            }
        },
        logOff: function (data) {
            let currentStatus = global_LastAgentStat ? global_LastAgentStat.Status : "";
            if (currentStatus.toLowerCase() === "on call") {
                let intid = global_activeTabInteractionID;
                tmac_DisconnectCall(function (resultdata, userobject, inputdata) {
                    if (data.ResultCode === 0) {
                        //DisconnectCall success
                    } else {
                        //DisconnectCall failed
                    }
                    Logout(global_DeviceID);
                }, intid, global_DeviceID, "");
                //DisconnectCall(global_DeviceID, intid)
            } else {
                Logout(global_DeviceID)
            }
            _this.sendAlertToAgent("TCIS logged me out", _getSupervisorId());
        },
        getSupervisorApproval: function () {

        },
        getReleaseBlackOutConfirmation: function (data) {
            try {
                let token = data.blackOutToken;
                let supervisorId, tmacServerId;
                let eventData = {
                    EventName: "GenericTMACEvent",
                    SubEventName: "tcis_confirmReleaseBlackout",
                    JsonData: JSON.stringify({
                        agentName: global_AgentName,
                        agentId: global_AgentID,
                        token: token,
                        tmacServerId: _tmacServer,
                        snapshotUrl: _this.lastSnapshotUrl,
                        screenshotUrl: _this.lastScreenshotUrl,
                        violation: _this.lastViolation
                    })
                }
                try {
                    supervisorId = global_successfullyLoggedInData.data.Data.SupervisorID;
                } catch (ex) {
                    log.LogDetails(type, "TcisIntegration.releaseBlackOut()", ex, false);
                }
                tmac_GetTmacServerId(function (resultData) {
                    tmacServerId = resultData;
                    //call server to add event with priority true to the supervisor session
                    tmac_AddEventToAgentSession(null, {}, supervisorId, eventData, true, tmacServerId);
                }, "", "", global_AgentID, "");

            } catch (ex) {
                log.LogDetails("Error", "TcisIntegration.getReleaseBlackOutConfirmation()", ex, false);
            }
        }
    };

    function _getStatusString(status) {
        try {
            if (!status) {
                status = global_LastAgentStat ? global_LastAgentStat.Status.toLowerCase() : "";
            }
            if (status === "available") return "available";
            else if (status.indexOf('on call') >= 0) return "oncall";
            else if (status === "acw") return "acw";
            else if (status === "default") return "default";
            else if (status.indexOf('logout') >= 0) return "logout";
            else return "aux";
        } catch (ex) {
            //
        }
    }

    function _getSupervisorId() {
        try {
            return global_successfullyLoggedInData.data.Data.SupervisorID;
        } catch (ex) {
            return "";
        }
    }

    _this.EVENT_NAMES = {
        MULTIPLE_FACE_DETECTED: "MultipleFaceDetected",
        PHONE_DETECTED: "MobilePhoneDetected",
        NO_FACE_DETECTED: "NoFaceDetected",
        FACE_AUTHENCATION_FAILED: "AuthenticationFailureDetected",
        RELEASE_BLACKOUT: "releaseBlackOut",
        AGENT_STATUS_CHANGED: "onconnected"
    };

    _this.sendEventToService = function (eventName, snapshotUrl, screenshotUrl) {
        try {

            _this.hub.invoke('NotifyTCISSurveillance', JSON.stringify({
                EventName: eventName,
                AgentId: global_AgentID,
                ServerId: _tmacServer.replace('TmacServer', ''),
                ServerName: _tmacServer,
                CamPicURL: snapshotUrl ? snapshotUrl : "",
                ScreenShotURL: screenshotUrl ? screenshotUrl : "",
                AgentStatus: _getStatusString()
            }));
        } catch (ex) {
            log.LogDetails("Error", "TcisIntegration.sendEventToService()", ex, false);
        }
    };

    _this.sendAlertToAgent = function (message, agentId) {
        //get the details
        let data = {
            agentId: global_AgentID,
            agentName: global_AgentName,
            message: message
        };

        //create event data
        var eventData = {
            EventName: "GenericTMACEvent",
            SubEventName: "ShowAlertMessageEvent",
            JsonData: JSON.stringify(data)
        };

        //call server to add event to the supervisor session
        tmac_AddEventToAgentSession(null, {}, agentId, eventData, true, _tmacServer);
    };

    _this.sendAgentCurrentStatus = function () {
        _this.hub.invoke('NotifyTCISSurveillance', JSON.stringify({
            EventName: "onconnected",
            AgentId: global_AgentID,
            ServerId: _tmacServer.replace('TmacServer', ''),
            ServerName: _tmacServer,
            CamPicURL: "",
            ScreenShotURL: "",
            AgentStatus: _getStatusString()
        }));
    };

    _this.sendReleaseBlackoutRequest = function (token) {
        _this.hub.invoke('NotifyTCISSurveillance', JSON.stringify({
            EventName: "releaseBlackOut",
            AgentId: global_AgentID,
            ServerId: _tmacServer.replace('TmacServer', ''),
            ServerName: _tmacServer,
            CamPicURL: "",
            ScreenShotURL: "",
            AgentStatus: _getStatusString(),
            blackOutToken: token
        }));
    };

    _this.configure();

};

function ShowAlertMessageEvent(event) {
    try {
        //parse the json data
        let jsonData = JSON.parse(event.JsonData);
        let html = `<p><b>` + jsonData.agentName + `(` + jsonData.agentId + `)` + `</b></p><p>` + jsonData.message + `</p>`;
        //UIkit.modal.alert(html);
        log.LogDetails('Info', "TcisIntegration.ShowAlertMessageEvent()", html, true);
        AddMessageAlerts("", jsonData.agentName + "(" + jsonData.agentId + "): " + jsonData.message);

    } catch (ex) {
        log.LogDetails("Error", "TcisIntegration.ShowAlertMessageEvent()", ex, false);
    }

}

function sendMultipleFaceWithImages() {
    if (typeof tcisCon !== "undefined") {

        let snapshotImg = _snapShot.getSnapshot();
        let screenshotImg = _snapShot.getScreenshot();
        tmac_SaveAgentSnapshot(function (result, userobj, inputdata) {
            if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.multipleFaceDetected, true);
            tcisCon.sendMultipleFaceCount(2, result.SnapshotUrl, result.ScreenshotUrl);
        }, {}, snapshotImg, screenshotImg);
    }

}

function sendPhoneDetectedWithImages() {
    if (typeof tcisCon !== "undefined") {
        let snapshotImg = _snapShot.getSnapshot();
        let screenshotImg = _snapShot.getScreenshot();
        tmac_SaveAgentSnapshot(function (result, userobj, inputdata) {
            if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.phoneDetected, true);

            tcisCon.sendPhoneDetected(result.SnapshotUrl, result.ScreenshotUrl);

        }, {}, snapshotImg, screenshotImg);
    }

}

function sendAuthenticationFailureWithImages() {
    if (typeof tcisCon !== "undefined") {
        let snapshotImg = _snapShot.getSnapshot();
        let screenshotImg = _snapShot.getScreenshot();
        tmac_SaveAgentSnapshot(function (result, userobj, inputdata) {
            if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.faceAuthenticationError, true);
            tcisCon.sendAuthenticationFailureEvent(result.SnapshotUrl, result.ScreenshotUrl);
        }, {}, snapshotImg, screenshotImg);
    }

}

function sendNoFaceDetectedWithImages() {
    if (typeof tcisCon !== "undefined") {
        let snapshotImg = _snapShot.getSnapshot();
        let screenshotImg = _snapShot.getScreenshot();
        tmac_SaveAgentSnapshot(function (result, userobj, inputdata) {
            if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.noFaceDetected, true);
            tcisCon.sendNoFaceDetected(result.SnapshotUrl, result.ScreenshotUrl);
        }, {}, snapshotImg, screenshotImg);
    }

}

function tcis_confirmReleaseBlackoutResponse(event) {
    try {
        let data = JSON.parse(event.JsonData);
        if (data.status == "approved") {
            tcisCon.sendReleaseBlackoutRequest(data.token);
        }
    } catch (ex) {
        //
    }
}

