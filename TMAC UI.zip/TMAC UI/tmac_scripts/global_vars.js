﻿var global_AssemblyVersion = "TMAC :4.0.11.12";
//  --------------------------------------------------------------------------
// All Application UI level Settings goes here
//  --------------------------------------------------------------------------
var remoteLogging = {
    Success: true,
    Info: true,
    Warning: true,
    Error: true
};
//label on title
var labelOnTitle = true;
var titleName = "TMAC";
//login and mainscreen in same page
var isSinglePageLogin = false;
var isLoginMode = true;
var loginMode = "nonpbx";//pbx,nonpbx,ms,pbxms
var disableLanId = false;
var isCloseLoginPage = false;
var showNotificationDeniedAlert = true;
// in seconds
var notificationDuration = 5;
//true if the application window size is to be set in pixel
var isApplication_window_size_type_pixel = false;
//percentage - [650 - voice bio | 28 - dbs sg live chat | 40 - uob]
var Application_window_width = 100;
//percentage - [300 - voice bio | 100 - dbs sg live chat | 100 - uob]
var Application_window_height = 100;
//is tmac full screen
var isFullTMAC = false;
//show/hide the left panel after login
var openLeftSidePanel = true;
//is the main tab is custom
var isCustomMainTab = false;
//display station id
var agentStationOnMain = true;
//agent status on main
var agentStatusOnMain = true;
//agent profile on main
var agentProfileOnMain = true;
//is agent chat
var isAgentChat = true;
//to enable av
var isAgentAVChat = true;
//s wallbaord
var isWallboard = true;
//is remiders
var isReminder = false;
//interaction history
var isInteractionHistory = true;
//load history on event
var loadHistoryOnEvent = true;
//dialog width pixel/percentage
var kendo_window_width = {
    "add_reminder": "525px",
    "barge_in_dialog": "525px",
    "make_call_dialog": "525px",
    "transfer_dialog": "525px",
    "convert_dialog": "525px",
    "conference_dialog": "525px",
    "confirm_dialog": "525px",
    "callback_dialog": "225px",
    "pom_callback_dialog": "600px",
    "va_history": "400px",
    "chat_template_dialog": "525px",
    "start_chat_dialog": "525px",
    "compose_dialog": "525px",
    "fax_template_dialog": "800px",
    "modal_enroll_facetouch": "525px"
};
//extra configs
//tmac header and footer height
var tmac_header_footer_height = "30px";
//aux status to enable logout
var logoutAux = "logout";
//disable status on call
var isDisableStatusOnCall = false;
//to show push notification
var isPushNotification = true;
//disabled window resize
var isDisableResize = false;
//notify timeout
var notifyTimeout = 2000;
//flag to close all tabs on tmac ui status change, TSC - Tmac Status Change
var isCloseTabsOnTSC = true;
//to skip close tab on these tab types for status change
var skipCloseTabType = [];
//to skip close tab on these staus for status change
var skipCloseTabStatus = [];
//to check last status of agent before auto close tab
var closeTabLastStatus = "ACW";
//filter agent list based on access role
var filterAccessRoleList = ["chatbot"];
var favionIcon = "favicon";
//enable/disable agent id for invalid lan id
var isAgentIdOnInvalidLanId = true;
//dummy station use lanid
var isStationAvailable = true;
//show domain list
var isDomainList = false;
//show login with password
var isLoginWithPassword = false;
//aux based on team
var isLoadAgentAux = false;
//support doc url
var supportDocUrl = "docs/pdf.pdf";
//barge-in enabled
var isBargeIn = false;
//supervisor enabled
var isSupervisor = true;
//supervisor link
var supervisorLink = "../../../Supervisor";
//toggle tmac screen
//var isTmacScreenToggle = true; --depricated
//enable/disable blind transfer button
var isBlindTransfer = true;
//favourite skill list in call transfer window
var isFavouriteSkillTab = true;
//favouriteskill list grid tab name
var favouriteSkillTabName = "Skill List"; //Blind Transfer, Skill List
//favouriteSkill transfer to - skill/vdn
var favouriteSkillTransferTo = "skill";
//speeddial list grid tab name
var speedDialTabName = "Speed Dial List"; //Consult Transfer, Speed Dial List
//speed dial list tab in call transfer window
var isSpeedDialTab = {
    "Voice": true,
    "TextChat": true,
    "Fax": false
};
//consult transfer on skill
var consultTransferOnSkill = {
    "Voice": true,
    "TextChat": false,
    "Fax": false
};
//blind transfer on agent
var disableAgentBlindTransfer = {
    "Voice": false,
    "TextChat": false,
    "Fax": true
};
//to allow transfer/conference in specified status
var allowedStatus = {
    "Voice": ["Available"],
    "TextChat": [],
    "Fax": []
};
//skill filter type for each channel in interaction transfer window, not case sensitive
var transferListSkillFilterPrefix = {
    "Voice": "vo", //take first 2 char
    "TextChat": "ch", //take first 2 char
    "Fax": "fax", //take first 3 char
    "Generic": "gen" //take first 3 char
};
//calls in queue threshold value for blinking for wallboard
var ciqThresholdValue = 5;
//modal on dialog
var modalOnDialog = true;
//initial status on load
var initialStatus = "Default";
//workbench configuration
var isWorkbench = false;
//workbench link
var workbenchLink = "";
//to print etra logs in console and UI log
var extraLogs = {
    "TMACEventNames": true,
    "TMACEventObjects": true,
    "VoiceBioEvents": false
};
//expand/collapse on iframes
var isExpandCollapseOnIframes = {
    "Supervisor": true,
    "Workbench": false
};
//Enable close tab on disconnect for realtime channel
var isEnableCloseTabOnDisconnect = {
    "Voice": true,
    "TextChat": true
};
//popup broadcast message on login and change
var popBroadcast = false;
//load workcodes with team
var isWorkCodeWithTeam = false;
//load workcodes with groups
var isWorkCodeWithGroup = true;
//workcode config key
//key value should be always lowercase | value :: "voice": { enable: false, mandatoryComplete: false }
var isWorkCode = {
    "fax": { enable: true, mandatoryComplete: true }
};
//total number of work code can be selected
var maxWorkCodeSelectedItems = 1;
//workcode label name
var workCodeLabel = "Completion Code";
//logout agent on close window
var isLogoutOnClose = false;
//to allow agent to logout on open tabs
var allowLogoutOnOpenTabs = true;
//register post messages
var registerPostMessages = true;
//signalr connector enable
var isSignalrConnector = false;
//signalr connector url; protocol: "webSockets", "longPolling", "serverSentEvents", "foreverFrame"
var signalRConnectorUrls = {
    dashboard: { protocol: "", urls: [] },
    webRTCMonitor: { protocol: "", urls: [] }
};
//rest call urls
var restCallUrl = {};
//retry AJAX fail enabled :: override this variable "ajax_retry_count" to change AJAX retry count, default is 3.
var retryAjaxFail = false;
//to dispatch TMAC events to the window so that the child frames can listen it
var isDispatchTMACEvents = true;
//is agent notes enabled
var isAgentNotes = true;
//to enable comment on interaction
var commentOnTransfer = {
    "Voice": false,
    "TextChat": true,
    "Fax": true
};
var isServiceLevel = false;
var serviceLevelFields = [
    {
        field: "BCMSData.SLPercentage",
        title: "SL %",
        width: "45px",
        template: "<div style='background:#=BCMSData.SLPercentage.background#; color:#=BCMSData.SLPercentage.color#;'>#=BCMSData.SLPercentage.value#</div>"
    }
];
//configuration to enable facetouch monitor
var enableFaceTouchMonitor = false;
//meeting frame url
var meetingFrameUrl = "";
// to load custom files
var loadFilesList = [
    "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"
];
// enable google translate for page
var enableGoogleTranslate = true;

// VP: July 9, '20: As per Siraj, this needs to be removed in the future when TCIE is integrated
// tmac face compare service url
var tmac_face_compare_serviceurl = "";
//----------------------------------------------------------------------------

//-------------------------------CHANNEL CONFIGURATIONS-----------------------
var isFbEnabled = false;
var isChatEnabled = true;
var isFaxEnabled = false;
var isSMSEnabled = false;
var isTwitterEnabled = false;
var isLineEnabled = false;

//----------------------------------------------------------------------------

//---------------------------------------FAX----------------------------------
//allow print fax
var isPrintFax = true;
//max number of faxline recipents
var maxFaxLineRecipents = 10;
//max length of faxline number
var maxFaxLineNumberLength = 20;
//max files can be uploaded
var maxFileUploads = 1;
//max file upload size
var maxFileUploadSize = 10; //in MB
//international fax prefix
var internationFaxPrefix = "00";
//enable numbers group dropdown list
var isSendFaxToGroup = true;
//send multiple files
var isSendMultipleFaxItems = true;
//maximum multiple items
var maxMultipleFaxItems = 2;
//conver page configuration
var isfaxCoverPage = true;
//cover page type :: file, template, dynamic
var coverPageType = "dynamic";
//restrict first item type :: file, template
var restrictFirstFaxItem = "file";

//----------------------------------------------------------------------------

//---------------------------------------SMS----------------------------------
//sms dnis list
var smsDnisList = [];
//max number of sms recipents
var maxSmsLineRecipents = 1;
//max length of sms number
var maxSmsLineNumberLength = 8;

//----------------------------------------------------------------------------

//----------------------------------------CRM---------------------------------
var isIServe = false;
var iServeUrl = "";
var isNiceIntegration = false;
var isDynamicCRMEnabled = false;
var isDynamicXRMEnabled = false;
//system generated callback CRM end pop up flag
var isCRMCallbackEnd = false;
//ACW QMS CRM Enabled
var isACWQMSCRMEnabled = false;
//siebel integration
var isSiebel = false;
//custom CRM URL
var customCRMUrl = "";

//----------------------------------------------------------------------------

//----------------------------------------VOICE-------------------------------
//name of outbound in db
var global_outboundName = "8 - Call Outbound";
//is voice authentication panel enabled
var isVoiceAuthenticationPanel = true;
//authentication label names
var voiceAuthenticationLabels = {
    label1: "Verified Status",
    label2: "TPIN lock status"
};
//show/hide IVR transfer button
var ivrTransferEnabled = true;
//ivr transfer menus
//prototype - { text: "NRIC/CC+OTP", type: "nv", value: "otp", icon: "lock" } :: type: nv - not verified, v_nv - verified + not verified
var ivrTransferMenus = [{ text: "Accesscode+TPIN", type: "v_nv", value: "tpin", icon: "lock" }];
//show/hide IVR menus
var isIvrMenuEnabled = true;
//dynamic voice data obj
var voiceObj = {
    "Name": "txtName,, Siraj",
    "CIF": "txtCIF, custom-width-50, 1234567",
    "Language": "txtLanguage, custom-width-50, Malayalam",
    "Caller ID": "txtCallerID, custom-width-50,"
};
//customer segment mapping
var segmentMapping = [];
//VIP customer mapping
var vipMapping = false;
//is voice service data window
var isVoiceDataWindow = false;
//type of voice data window
var voiceDataWindowType = "";
//campaign manager selector url
var campSelectorUrl = "";
//campaign manger servic url for campui.js
var campServiceUrl = "";
//enable voice if a single chat going on
var isEnableVoiceOnSingleChat = false;
//internal Number Startswith
var internalNumberStartsWith = "";
//prefix to be added before dialing out
var customDialCallPrefix = "";
//close outbound tab
var closeOutboundTab = false;
//---------------------------------------------------------------------------------------------

//----------------------------------------TEXT CHAT/AUDIO-VIDEO CHAT---------------------------
//CSAT survey
var isCSATSurvey = false;
//Sanitize Html
var isSanitizeHtml = true;
//is grammer check
var isGrammerCheck = false;
//is PWeb Chat
var isPWebChat = true;
//dynamic chat data obj
var chatObj = {
    "Name": "tc_scName",
    "User ID": "tc_userId",
    "CIF": "tc_cif",
    "Mobile Number": "tc_regNo",
    "Gender": "tc_gender",
    "DOB": "tc_DOB",
    "Queue Time": "tc_chatQueueTime, custom-width-50"
};
//is chat authentication panel enabled
var isChatAuthenticationPanel = true;
//authentication label names
var chatAuthenticationLabels = {
    label1: "Authentication Level",
    label2: "Authentication Status"
};
//immedialte callback button
var isImmediateCallbackBtn = false;
//scheduled callback button
var isScheduledCallbackBtn = false;
//video call enabled
var isAVEnabled = true;
//video call on tab/window
var videoCallType = "tab";
//audio escalate button
var isAudioEscalate = true;
//video escalate button
var isVideoEscalate = true;
//co-browse button
var coBrowse = {
    Enabled: true,
    MousePointerCapture: false
};
//text chat transfer
var isChatTransfer = true;
//conference button
var isConference = true;
//  Conversion of interaction from one channel to another
var interactionConversion = {
    Enabled: true,
    Channels: [{
        Name: "Generic",
        Label: "Generic"
    }, {
        Name: "AudioVideo",
        Label: "Audio Video"
    }],
    On: ["oncall", "afterdisconnect"]                   //  "oncall", "afterdisconnect"
};
//chat history name
var chatHistoryName = "Chatbot History";
//va chat history
var isVaChatHistoryBtn = false;
//va chat history accordion
var isVaChatHistoryAccordion = true;
//custom load va chat history based on country
var vaChatHistoryCountry = "";
//chat video snapshot
var isSignature = false;
//chat video snapshot
var isSnapshot = false;
//chat attachment
var isAttachement = false;
//is user/customer name label on chatbox
var isUserLabel = true;
//open camera button
var isCamera = false;
//voice note
var isVoiceNote = false;
//pdf editor and Image required
var isPDFAndImageEditingAllowed = false;
//is hyperlink in tag to customer
var isHyperlinkWithTag = true;
//to send all links to customer at the end of chat
var sendAllLinksToCustomer = false;
//send messages as app message
var isAppMessage = false;
//is reply button on chat box
var isReplyOnChat = true;
//image formats for text chat
var imageFormats = [".JPG", ".JPEG", ".PNG"];
//audio formats for text chat
var audioFormats = [".WAV"];
//video formats for text chat
var videoFormats = [".MP4"];
//file formats for text chat
var fileFormats = [".DOC", ".DOCX", ".XLS", ".XLSX"];
//attachement max size in MB
var maxAttachFileSize = "10";
//draw stroke style
var drawStrokeStyle = "#000";
//draw stroke size
var drawStrokeSize = "12";
//expand/collapse on video chat
var isExpandCollapseOnVideoChat = false;
//filter type for auto complete chat template
var chatTemplateFilter = "startswith"; //startswith, endswith and contains
//To provide comment on fax/textchat transfer/conference accept/reject
var isCommentOnConfirmaion = true;
//chatbox type
var chatBoxType = "inline"; //inline, outline
//filter template based on time stamp
var isTemplateTimeFilter = true;
//disconnect chat label
var disconnectChatLabel = "Interaction";
//chat template button
var isChatTemplatesBtn = true;
//custom textchat
var isCustomTextChat = false;
//custom chat config
var customChatConfigs = [];
//send WebRTC info
var sendWebRTCInfo = {
    stats: false,
    signals: false,
    errors: false
};
//chat template update threshold in mins
var chatTemplatesUpdateThreshold = 0;
// to enable emoji feature for textchat
var isEmojiEnabled = false;
// escalte to AV time out
var escalateToAVTimeout = 30000;
var screenShareEnabled = true;
var avPopupConfig = {
    allowMaximize: true,
    allowMinimize: true,
    allowPip: true,
    defaultMode: "pip" // pip/min/max
};
var webRTCApiConfig = {
    "webRTCConfig": {
        "iceServers": [],
        "iceTransportPolicy": "all",
        "sdpSemantics": "plan-b"
    },
    "getMediaConstraints": {
        "type": "",
        "video": {
            "width": 640,
            "height": 480
        }
    },
    "getOfferOptions": {
        "offerToReceiveAudio": true,
        "offerToReceiveVideo": true,
        "iceRestart": true
    },
    "getRecordingOptions": {
        "enabled": false,
        "recordLocal": false
    },
    "audioLevelCheck": {
        "enabled": true,
        "threshold": 0.11
    },
    "getConnectionBandwidthUpperLimit": 1024,
    "getAudioTrackBandwidthUpperLimit": 16,
    "getVideoTrackBandwidthUpperLimit": 128,
    "isAudioMixerEnabled": true
};
//----------------------------------------------------------------------------

//----------------------------------------CALLBACK----------------------------
var isCallback = false;
//trim before makecall
var trimDigitsBeforeMakeCall = "";
//readonly Caller ID textbox in callback tab
var isCallerIDTextBoxReadonly = false;
//callback set data for VDN as per language
var isLanguageTruncateEnabled = false;
var dCallbackType = "";
var callbackExtensionRange = "";
var callbackVDNListStart = "";
var callbackVDNListEnd = "";
//prefix to be added before dialing out for preferred contact number
var isCustomDialPrefixPrefNumber = false;
//callback tab status options
var callbackOptions = [];

//----------------------------------------------------------------------------

//----------------------------------------DASHBOARD---------------------------
//is dashboard enabled
var isDashboardEnabled = false;
//channel list for dashboard
var globalChannelList = ["Voice", "Textchat", "Fax"];
//dashboard interval 
var dashboardInterval = [{
    text: "12Hrs",
    value: "12"
},
{
    text: "24Hrs",
    value: "24"
},
{
    text: "36Hrs",
    value: "36"
},
{
    text: "48Hrs",
    value: "48"
},
{
    text: "60Hrs",
    value: "60"
},
{
    text: "72Hrs",
    value: "72"
}
];
//default dashboard interval
var defaultDashboardInterval = "72";
//dashboard reconnect interval
var dashboardUrl = "";

//----------------------------------------------------------------------------

//----------------------------------------Voice Bio---------------------------
var isVoiceBio = false;
//retry login flag
var retryLogin = true;
//retry interval
var retryInterval = 5000;
//enter manual lan id
var isManualLanId = true;
//voice bio notification limit
var voiceBioNoficationLimit = {
    notEnrolled: 0,
    enrolled: 0,
    enoughAudio: 0,
    authenticated: 0,
    notAuthenticated: 0,
    rejectedTwice: 0
};
//default snooze time in minutes
var defaultSnoozeTimeout = 5;

//----------------------------------------------------------------------------

//---------------------------------------POM----------------------------------
var isPOM = false;
var isCACS = false;
var isPOMCallDashboard = false;
var isPOMCmpaignDashboard = false;
var isPOMCallbackDashboard = false;
var pomDNDType = [];
var pomLoginFlag = false;
var pomSaleScreenList = [];
var pomInboundWrapupCodes = [];
var isPreviewAutoDial = false;
var trimNumberLength = "";
var limitPOMCallbackDate = false;

//----------------------------------------------------------------------------

//---------------------------------------SOCIAL MEDIA-------------------------
var lineUrl = "";
var twitterUrl = "";
var twitterDMUrl = "";
var FileServerUrl = {
    Smm: "",
    MediaProxy: ""
};

//----------------------------------------------------------------------------

//---------------------------------------INTERACTION HISTORY----------------------------------
//email preview url
var ihEmailPreviewUrl = "";
//no of records to be fetched initially
var noOfRecords = 5;
//load ih from multiple instance
var isMultiHistory = false;
//multiple instance names ex: "[SG_CC", "TH_CC]" to be configured in TMAC http proxy under DataServerInstanceMap key
var multiHistoryInstanceNames = ["SG", "TH"];

//  --------------------------------------------------------------------------

//  Load all local configs and assign
new ConfigElement().LoadLocal();

//  --------------------------------------------------------------------------

//  VP : Jul 9, '20: For dev purpose only. If this key exists, configs which  will be loaded from TMAC server will be loaded from local.
//                   This should not go to onsite. DEV PURPOSES ONLY
var isConfigSourceLocal = false;