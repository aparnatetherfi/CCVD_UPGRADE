﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacTextChatUI.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

//private variable for this file
$(function () {
    //Create the chat template grid
    CreateChatTemplateGrid("", "chat");
    //Create the cobrowse template grid
    if (coBrowse.Enabled) {
        CreateChatTemplateGrid("", "cobrowse");
    }
    //check if the agent has audiochat channel with  count atleast 1
    var audioChatChannel = global_ChannelCount.filter(function (c) { return c.Channel.toLowerCase() === "audiochat"; });
    isAudioEscalate = audioChatChannel.length > 0 && audioChatChannel[0].Count > 0;
    //check if the agent has videochat channel with  count atleast 1
    var videoChatChannel = global_ChannelCount.filter(function (c) { return c.Channel.toLowerCase() === "videochat"; });
    isVideoEscalate = videoChatChannel.length > 0 && videoChatChannel[0].Count > 0;

    // if av enabled then do a camera/microphone check
    if (isAVEnabled) {
        // check for media permission on start
        setTimeout(function () {
            WrsUtils.getUserMedia({ audio: true, video: true })
                .then(function (stream) {
                    stream.getTracks().forEach(function (track) {
                        track.stop();
                    });
                })
                .catch(function (err) {
                    log.LogDetails("Error", "TmacTextChatUI.Ready()", `Camera/Microphone: ${err}`, true);
                })
        }, 2000);
    } else {
        //  VP: Jul 7, '20: Override and disable audio and video escalate
        isAudioEscalate = isVideoEscalate = false;
    }
});

function TextChatNewChatReceived(data) {
    try {
        //current interaction id
        let intid = data.InteractionID;
        //save the chat reference for session timer1
        SaveChatReference(intid);
        //update the chat routing type. If IsNonVoiceRouting is true then WQ else CM
        GetChatReferenceObj(intid).isNonVoiceRouting = data.IsNonVoiceRouting;
        //add chat tab
        AddChatTab(data);

        //Initialize the UIKit accordion for the created tab
        let accordion = UIkit.accordion($('#chat_accordion' + intid), {
            collapse: false,
            showfirst: false
        }),
            wrapper1 = accordion.find('[data-wrapper]').get(0), //0 as index of the content - customer info window
            wrapper2 = accordion.find('[data-wrapper]').get(2); //2 as index of the content - chat window
        //if isCustomTextChat is true then open interaction history accordion
        if (isCustomTextChat) {
            wrapper2 = accordion.find('[data-wrapper]').get(4); //4 as index of the content - interaction history window
        }
        accordion.toggleItem(UIkit.$(wrapper1), true, false); // animated true and collapse true
        accordion.toggleItem(UIkit.$(wrapper2), true, false); // animated true and collapse true
        ChangeChatColorInit("divTxtChatTranscript" + intid, "chat_colors" + intid);
        //blink the chat accordion header on incoming chat
        $("#chat_transcript_accordion" + intid).addClass("blink_chat");
        global_UCID[intid] = data.UCID;
        if (!isChatAuthenticationPanel)
            $("#div_authentication" + intid).remove();
        else {
            $("#auth_st_label" + intid).text(chatAuthenticationLabels.label1);
            $("#auth_lv_label" + intid).text(chatAuthenticationLabels.label2);
        }
        //set va chat history accordion name
        $("#va_history_accordion" + intid).text(chatHistoryName);
        if (!isVaChatHistoryAccordion) {
            $("#va_history_accordion" + intid).addClass("uk-display-none");
        }
        if (isCamera)
            $("#spanOpenCamera" + intid).css("display", "table-cell");
        if (isWhiteboard)
            $("#spanTextChatWhiteboard" + intid).css("display", "table-cell");
        if (isAttachement)
            $("#spanTextChatAttach" + intid).css("display", "table-cell");
        if (isVoiceNote)
            $("#spanTextChatSendVoice" + intid).css("display", "table-cell");
        if (!isPDFAndImageEditingAllowed)
            $("#btnEditPreview" + intid).addClass("uk-display-none");
        //show notification on !window focus
        ShowNotification("You have new", "Incoming Chat");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatNewChatReceived()", ex, false);
    }
}

//function AddChatTab(data) {
//    try {
//        //current interaction id
//        let intid = data.InteractionID;
//        //incoming phone number
//        let phonenumber = data.PhoneNumber;
//        //save the tab reference
//        SaveTabReference('chat', intid, 'new');
//        //add chat dynamic fields
//        AddDynamicFields("chat");
//        //tab header content
//        let headerTemplate = GetHtmlFromTemplate("tab_header_template", intid, { icon: "chat" });
//        //tab body content
//        let bodyTemplate = document.getElementById("chat_tab_body").innerHTML;
//        //let bodyTemplate = GetHtmlFromTemplate("chat_body_template", intid, "");
//        //variable chat active initially true
//        let tabActive = true;
//        //add a kendo tab
//        AddTab(bodyTemplate, headerTemplate, intid, phonenumber, tabActive, false, true);
//        //if isCustomTextChat is enabled then devide the window, move the controls
//        if (isCustomTextChat) {
//            $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-1 uk-width-medium-1-1");
//            $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-3 uk-width-medium-1-2");
//            $("#customChatDiv" + intid).removeClass("uk-display-none");
//            $("#chat_transcript_accordion" + intid).addClass("uk-display-none");
//            $("#chat_controls" + intid).appendTo("#custom_chat_controls" + intid);
//        }
//        //set the controls
//        HandleChatControls(intid, "incoming");
//        //assign the conftype to the reference
//        GetChatReferenceObj(intid).conferenceType = data.ConferenceType;
//        //create the initial interaction history grid
//        if (data.ConferenceType !== "silent") {
//            //load chat template grid
//            //CreateChatTemplateGrid("");
//            //Initialize the auto complete for the #textChatMessage text area
//            $("#textChatMessage" + intid).kendoAutoComplete({
//                dataSource: allChatTemplates,
//                filter: chatTemplateFilter,
//                noDataTemplate: false,
//                dataTextField: "Text",
//                dataValueField: "ID",
//                select: textChatMessageOnSelect
//            });
//            //initialise event lister for the message textarea
//            AddTypingEventListener(intid);
//            // if shift + enter is pressed, goes to new line [Since Alt+Enter will maximize the browser window, so we replaced with shift + Enter]
//            $("#textChatMessage" + intid).keypress(function (e) {
//                if (e.keyCode === 13 && !e.shiftKey) {
//                    SendChat(intid);
//                    // Remove the unnecessary character
//                    return false;
//                }
//                //append . and space event for grammer check
//                if (isGrammerCheck && (e.keyCode === 46 || e.keyCode === 32 || e.keyCode === 13 && e.shiftKey)) {
//                    GrammerCheck(intid);
//                }
//            });
//            //focus the textbox when clicking on chatbox area
//            //this will not allow the agent to select any text from inside chatbox area
//            //$("#div_chat_box_wrapper" + intid).click(function () {
//            //    $("#textChatMessage" + intid).focus();
//            //});
//            //store the chat interaction id in hidden variable
//            $("#textChatInteractionID").val(intid);
//            //variable set for chat disconnect message dialog display based on customer or agent disconnect
//            global_endTextChatNotification[intid] = false;

//            //show and append data workcodes if configured
//            if (isWorkCode.chat && isWorkCode.chat.enable) BindWorkCodes(intid);
//        }

//        //add a call timer/session timer  
//        AddCallTimer(intid, "chat", "#hdn_text_chat_starttime" + intid, "#text_chat_starttime" + intid,
//            "#text_chat_time_taken" + intid, "#text_chat_span_starttime" + intid, "#agent_time_taken" + intid,
//            "#agent_time_taken_span" + intid, "#hdn_agent_time_taken_start" + intid, "#hdn_agent_time_taken_end" + intid,
//            "#btnTextChat_FreezeAutoResponse" + intid, data.ConferenceType);
//    } catch (ex) {
//        log.LogDetails("Error", "TmacTextChatUI.AddChatTab()", ex, false);
//    }
//}

function AddChatTab(data) {
    try {
        //current interaction id
        let intid = data.InteractionID;
        //incoming phone number
        let phonenumber = data.PhoneNumber;
        //save the tab reference
        SaveTabReference('chat', intid, 'new');
        //add chat dynamic fields
        AddDynamicFields("chat");
        //tab header content
        let headerTemplate = GetHtmlFromTemplate("tab_header_template", intid, { icon: "chat" });
        //tab body content
        let bodyTemplate = document.getElementById("chat_tab_body").innerHTML;
        //let bodyTemplate = GetHtmlFromTemplate("chat_body_template", intid, "");
        //variable chat active initially true
        let tabActive = true;
        //add a kendo tab
        AddTab(bodyTemplate, headerTemplate, intid, phonenumber, tabActive, false, true);
        //if isCustomTextChat is enabled then devide the window, move the controls
        if (isCustomTextChat) {
            $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-1 uk-width-medium-1-1");
            $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-3 uk-width-medium-1-2");
            $("#customChatDiv" + intid).removeClass("uk-display-none");
            $("#chat_transcript_accordion" + intid).addClass("uk-display-none");
            $("#chat_controls" + intid).appendTo("#custom_chat_controls" + intid);
        }
        //set the controls
        HandleChatControls(intid, "incoming");
        //assign the conftype to the reference
        GetChatReferenceObj(intid).conferenceType = data.ConferenceType;
        //create the initial interaction history grid
        if (data.ConferenceType !== "silent") {
            //load chat template grid
            //CreateChatTemplateGrid("");
            //Initialize the auto complete for the #textChatMessage text area
            var autoCompleteEmoji = $("#textChatMessage" + intid).kendoAutoComplete({
                dataSource: allChatTemplates,
                filter: chatTemplateFilter,
                noDataTemplate: false,
                dataTextField: "Text",
                dataValueField: "ID",
                select: textChatMessageOnSelect
            }).data("kendoAutoComplete");
            if (isEmojiEnabled) {
                var emojiel = $("#textChatMessage" + intid).emojioneArea({
                    pickerPosition: "top",
                    useInternalCDN: false,
                    filters: {
                        smileys_people: { icon: "yum", title: "Smileys", emoji: "smiley smile laughing sweat_smile joy relaxed blush innocent wink relieved heart_eyes kissing_heart yum open_mouth stuck_out_tongue hugging partying_face disappointed pensive worried slight_frown fearful thinking pouting_cat clap pray thumbsup thumbsdoen v ok_hand hand_splayed wave muscle heart 100 " },
                        objects: false, // disable objects filter
                        symbols: false, // disable symbols filter
                        flags: false, // disable flags filter
                        travel_places: false,
                        activity: false,
                        food_drink: false,
                        animals_nature: false
                    },
                    tones: false,
                    autocomplete: false,
                    search: false,
                    hidePickerOnBlur: false,
                    events: {
                        keypress: function (editor, e) {
                            if (e.which === 13) {
                                e.preventDefault();
                                SendChat(intid);
                                $("#textChatMessage" + intid)[0].emojioneArea.setText("");
                            }
                            //append . and space event for grammer check
                            if (isGrammerCheck && (e.keyCode === 46 || e.keyCode === 32 || e.keyCode === 13 && e.shiftKey)) {
                                GrammerCheck(intid);
                            }
                        },
                        keyup: function (editor, e) {
                            if (!this.getText()) {
                                autoCompleteEmoji.close();
                            } else {
                                autoCompleteEmoji.search(this.getText());
                            }
                        },
                        "picker.show": function (editor) {
                            $('#chat_submit_box' + intid).css('overflow', 'visible');
                            // check if reply is opened
                            if (!$("#chat_reply_box" + intid).hasClass("show-reply-box"))
                                $("#chat_reply_box" + intid).css('display', 'none');
                        },
                        "picker.hide": function (editor) {
                            $('#chat_submit_box' + intid).css('overflow', '');
                            // check if reply is opened
                            if (!$("#chat_reply_box" + intid).hasClass("show-reply-box"))
                                $("#chat_reply_box" + intid).css('display', '');
                        }
                    }
                });
                $('.emojionearea .emojionearea-picker').css("height", "200px");
                $('.k-autocomplete-clearable .k-input').css('overflow', 'visible');
                $('span.my_textchat_area').css("cssText", 'overflow:visible !important');
                $('.emojionearea-editor').css('white-space', 'normal');
                $('.emojionearea-editor').css('word-break', "break-all");
                $('.emojionearea .emojionearea-editor').css('max-height', '3em');
                $('.emojionearea .emojionearea-editor').css('min-height', '2em');
            } else {
                // if shift + enter is pressed, goes to new line [Since Alt+Enter will maximize the browser window, so we replaced with shift + Enter]
                $("#textChatMessage" + intid).keypress(function (e) {
                    if (e.keyCode === 13 && !e.shiftKey) {
                        SendChat(intid);
                        // Remove the unnecessary character
                        return false;
                    }
                    //append . and space event for grammer check
                    if (isGrammerCheck && (e.keyCode === 46 || e.keyCode === 32 || e.keyCode === 13 && e.shiftKey)) {
                        GrammerCheck(intid);
                    }
                });
            }
            //initialise event lister for the message textarea
            AddTypingEventListener(intid);
            //store the chat interaction id in hidden variable
            $("#textChatInteractionID").val(intid);
            //variable set for chat disconnect message dialog display based on customer or agent disconnect
            global_endTextChatNotification[intid] = false;

            //show and append data workcodes if configured
            if (isWorkCode.chat && isWorkCode.chat.enable) BindWorkCodes(intid);
        }

        //add a call timer/session timer  
        AddCallTimer(intid, "chat", "#hdn_text_chat_starttime" + intid, "#text_chat_starttime" + intid,
            "#text_chat_time_taken" + intid, "#text_chat_span_starttime" + intid, "#agent_time_taken" + intid,
            "#agent_time_taken_span" + intid, "#hdn_agent_time_taken_start" + intid, "#hdn_agent_time_taken_end" + intid,
            "#btnTextChat_FreezeAutoResponse" + intid, data.ConferenceType);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddChatTab()", ex, false);
    }
}

function textChatMessageOnSelect(e) {
    try {
        var dataItem = this.dataItem(e.item.index());
        GetChatReferenceObj(global_activeTabInteractionID).selectedTemplateId = dataItem.ID;
    } catch (e) {
        log.LogDetails("Error", "TmacTextChatUI.textChatMessageOnSelect()", ex, false);
    }
}

//function AddTypingEventListener(intid) {
//    try {
//        //chat input textarea element
//        var element = $("#textChatMessage" + intid);
//        //on change of element
//        element.keyup(function () {
//            if (element.val() !== "") {
//                //typing...
//                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 0);
//            } else {
//                //not typing...
//                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
//            }
//        });
//        //on blur send not typing
//        element.blur(function () {
//            //not typing...
//            TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
//        });

//        $("#chat_submit_box" + intid + " span.k-icon.k-clear-value.k-i-close").click(function () {
//            //not typing...
//            TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
//            if (isGrammerCheck)
//                ClearHighlightTextarea(intid);
//        });

//    } catch (ex) {
//        log.LogDetails("Error", "TmacTextChatUI.AddTypingEventListener()", ex, false);
//    }
//}

function AddTypingEventListener(intid) {
    try {
        if (isEmojiEnabled) {
            //chat input textarea element
            var el = $("#textChatMessage" + intid);
            //on change of element
            el[0].emojioneArea.on("keyup", function (button, event) {
                if ($("#textChatMessage" + intid)[0].emojioneArea.getText() !== "") {
                    //typing...
                    TextChatNotifyTypingStatusChange(global_DeviceID, intid, 0);
                } else {
                    //not typing...
                    TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
                }
            });

            // attach event handler
            el[0].emojioneArea.on("blur", function (button, event) {
                //not typing...
                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
            });

        } else {
            //chat input textarea element
            var element = $("#textChatMessage" + intid);
            //on change of element
            element.keyup(function () {
                if (element.val() !== "") {
                    //typing...
                    TextChatNotifyTypingStatusChange(global_DeviceID, intid, 0);
                } else {
                    //not typing...
                    TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
                }
            });
            //on blur send not typing
            element.blur(function () {
                //not typing...
                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
            });
        }
        $("#chat_submit_box" + intid + " span.k-icon.k-clear-value.k-i-close").click(function () {
            //not typing...
            TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
            if (isGrammerCheck)
                ClearHighlightTextarea(intid);
        });

    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddTypingEventListener()", ex, false);
    }
}


function GrammerCheck(intid) {
    try {
        var text = $("#textChatMessage" + intid).val();
        var data = {};
        data.intid = intid;
        data.originalText = text;
        if ($.trim(text)) {
            text = SanitizeMessage(isAppMessage, text);
            if (text) CheckGrammer(text, data);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GrammerCheck()", ex, false);
    }
}

function GrammerCheckDone(data, obj) {
    try {
        if (GetChatReferenceObj(obj.intid) && !GetChatReferenceObj(obj.intid).isDisconnected) {
            if (data !== null) {
                ClearHighlightTextarea(obj.intid);
                $('#textChatMessage' + obj.intid).highlightTextarea({
                    ranges: [{
                        color: '#FFFF00',
                        ranges: data
                    }]
                });
                $("#textChatMessage" + obj.intid).focus();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GrammerCheckDone()", ex, false);
    }
}

function ClearHighlightTextarea(intid) {
    try {
        $('#textChatMessage' + intid).highlightTextarea('destroy');
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ClearHighlightTextarea()", ex, false);
    }
}

function SetSelectionRange(input, selectionStart, selectionEnd) {
    try {
        if (input.setSelectionRange) {
            input.focus();
            input.setSelectionRange(selectionStart, selectionEnd);
        } else if (input.createTextRange) {
            var range = input.createTextRange();
            range.collapse(true);
            range.moveEnd('character', selectionEnd);
            range.moveStart('character', selectionStart);
            range.select();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetSelectionRange()", ex, false);
    }
}

function SetCareToPos(input, values) {
    try {
        //var input = document.getElementById("textChatMessage" + intid);
        SetSelectionRange(input, values, values);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetCareToPos()", ex, false);
    }
}

function TextchatRemoteUserConnected(data) {
    try {
        var intid = data.InteractionID;
        var jsonData = null;
        var chatMode = "";
        try {
            GetChatReferenceObj(intid).sessionId = data.TextChatSessionID;
            $("#sessionid_span" + intid).text(data.TextChatSessionID + "|" + intid);
        } catch (e) {
            //
        }
        //remove the chat accordion blink once the chat is connected
        $("#chat_transcript_accordion" + intid).removeClass("blink_chat");
        //CSAT Survey Request
        if (isCSATSurvey)
            InitiateCsatSurvey(data);

        try {
            //set the chat mode
            chatMode = data.ChatMode;
            GetChatReferenceObj(intid).chatMode = chatMode;
        } catch (ex) {
            log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected() - ChatMode", ex, false);
        }

        if (isPWebChat) {
            AssignDynamicValues(data, "chat", "TextchatRemoteUserConnected");

            try {
                let parse = JSON.parse(data.JsonData);
                let channel = "textchat";

                //  VP: Jun 9, '20: Storing customer JSON
                //assign the jsonData to chat reference
                GetChatReferenceObj(intid).customJson = parse;

                if (!parse) {
                    try {
                        channel = data.TextChatIncomingEvent.RecoveryData.channel;
                    } catch (e) {
                        //
                    }
                }
                else {
                    channel = parse.pChannel ? parse.pChannel : "";
                }

                GetChatReferenceObj(intid).channel = channel ? channel : "textchat";

                // VP : Feb 27, '20: Change icons for social media interactions
                if (channel && channel.toLowerCase() === "whatsapp") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa-whatsapp";
                }
                else if (channel && channel.toLowerCase() === "wechat") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa - weixin";
                }
                else if (channel && channel.toLowerCase() === "line") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa-line";
                }
                else if (channel && channel.toLowerCase() === "twitter") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa-twitter";
                }
                else if (channel && channel.toLowerCase() === "viber") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa-viber";
                }
                else if (channel && channel.toLowerCase() === "telegram") {
                    $("#divCustomerName" + intid).find("i")[0].innerText = "";
                    $("#divCustomerName" + intid).find("i")[0].className = "fab fa-telegram";
                }
            } catch (e) {
                //
            }

            try {
                if (isAVEnabled && chatMode !== "text" && !data.RecoveryEvent) {
                    // check if the audio call then show the Ui
                    if (chatMode === 'audio') {
                        ShowAudioCallUI(intid, 'Incoming');
                    }
                    if (chatMode === 'video') {
                        ShowVideoCallUI(intid, "Incoming");
                        //avCallPopup.open(intid, 'Incoming');
                    }
                    //create a audio/video channel connection
                    StartAVConnection(intid, data.ConferenceType, WrcGetCallCode(chatMode));
                    //if this is transfer chat or conference chat
                    if (data.TextChatIncomingEvent.IsAgentConferenceChat) {
                        //get the conference type to join the call
                        var joinType = data.ConferenceType === "silent" ? "monitor" : data.ConferenceType === "whisper" ? "wisper" : "conference";
                        //join the call
                        avConn.join(chatMode, { mode: joinType });
                    }
                    //if this is a new chat/transferred chat
                    else {
                        //notify chat server to with avtstatus for chatMode
                        let msg = {
                            param: chatMode,
                            sessionid: GetChatReferenceObj(intid).sessionId
                        };

                        if (data.TextChatIncomingEvent.IsAgentTransferedChat) {
                            msg.source = "transfer";
                            msg.type = "requestav";
                        } else if (data.TextChatIncomingEvent.IsAgentConferenceChat) {
                            msg.source = "conference";
                            msg.type = "avtstatus";
                        } else {
                            msg.source = "direct";
                            msg.type = "requestav";
                        }
                        SendAVControlMessage(global_DeviceID, intid, JSON.stringify(msg), "avtstatus", msg.sessionid);
                    }
                }
            } catch (ex) {
                log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected() - AV control", ex, false);
            }
        }
        else if (isCustomTextChat) {
            //assign the customer info value
            AssignDynamicValues(data, "chat", "TextchatRemoteUserConnected");
            //get the json data
            jsonData = JSON.parse(data.JsonData);
            var customChatConfig = customChatConfigs.filter(function (i) { return i.source === jsonData.source; })[0];
            if (!customChatConfig) {
                log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected()", "customChatConfig is empty!", false);
                return;
            }
            var url = "";
            if (customChatConfig.source === "moxtra") {
                ProcessMoxtraUserConnected(data, jsonData, url);
            }
            //load the custom chat iframe
            LoadIFrame("chat_chat_frame" + data.InteractionID, url);
            //assign the jsonData to chat reference
            GetChatReferenceObj(data.InteractionID).customJson = jsonData;
        }
        else {
            jsonData = JSON.parse(data.JsonData);
            GetChatReferenceObj(intid).customerName = jsonData.eCustName;
            $('#divTabHeader' + intid).text(jsonData.eCustName);
            $("#textChatName" + intid).val(jsonData.eCustName);
            $("#textChatNRIC" + intid).val(jsonData.eKCIN);
            $("#textChatRegPhone" + intid).val(jsonData.eMobileNo);
            $("#textChatEmail" + intid).val(jsonData.eEmail);
        }

        //  Add SMM flag
        let chan = GetChatReferenceObj(intid).channel.toLowerCase();
        if (chan === "whatsapp" || chan === "wechat" || chan === "line" ||
            chan === "twitter" || chan === "viber" || chan === "telegram") {
            GetChatReferenceObj(intid).isSMM = true;
        } else {
            GetChatReferenceObj(intid).isSMM = false;
        }

        //set control visibility
        if (data.ConferenceType === "silent") {
            HandleChatControls(intid, "connectedSilent");
        }
        else if (data.ConferenceType === "whisper") {
            HandleChatControls(intid, "connectedWhisper");
        }
        else {
            HandleChatControls(intid, "connected");
        }

        try {
            var historyData = JSON.parse(data.ChatHistoryData);
            if (historyData.length !== 0) {
                $("#chat_divider" + intid).remove();
                $("#queueHistoryChatBox" + intid).show();
                CreateQueueHistoryChatBox(intid, historyData);
            }
        } catch (ex) {
            log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected() - Inside", ex, false);
        }

        //send greetings if this is a new chat not a transferred chat
        if (!data.TextChatIncomingEvent.IsAgentTransferedChat) {
            SendtextChatGreeting(intid);
        }

        //check if any active AV going on then disable AV buttons if enabled
        if (isAudioEscalate || isVideoEscalate) {
            CheckForActiveAV();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected()", ex, false);
    }
}

function ProcessMoxtraUserConnected(data, jsonData, url) {
    try {
        var urlConfig;
        $.each(customChatConfig.urls.moxtraUrls, function (i, val) {
            if (val.tmacServerName === _tmacServer) {
                urlConfig = val;
            }
        });
        if (!urlConfig) {
            log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected()", customChatConfig.source + "Moxtra url is not Configured for tmacServerName: " + _tmacServer, false);
            return;
        }
        customChatConfig.urls.activeUrl = _tmacServer;
        jsonData.agentUrl = jsonData.agentUrl.replace(/^https?:\/\/[^/]+/, urlConfig.url);
        let lanids = global_LanID.split('\\');
        let agentUserName = (lanids.length > 1) ? lanids[1] : lanids[0];
        //get url to load iframe
        url = RemoveParamFromUrl("clientId", jsonData.agentUrl);
        url = url +
            "&agentId=" + global_AgentID +
            // getting agentUserName from second part of Lan id
            "&agentUserName=" + agentUserName +
            "&agentName=" + global_AgentName +
            "&agentCode=" + global_AgentID;
        // getting agentComputerName from the first part of Lan Id				
        //"&agentComputerName=" + global_LanID.split('\\')[0];
        if (data.TextChatIncomingEvent.IsAgentTransferedChat) {
            url = url +
                "&requeueStatus=T" +
                "&transferAgentId=" + data.TextChatIncomingEvent.SourceAgentID;
        }
        else if (data.TextChatIncomingEvent.IsAgentConferenceChat) {
            url = url + "&requeueStatus=C";
        }
        if (data.TextChatIncomingEvent.RecoveryEvent) {
            url = url + "&reopen=Y";
        }
        //change the url for specific chat type
        if (customChatConfig &&
            data.TextChatIncomingEvent.IsAgentConferenceChat &&
            data.ConferenceType === "silent") {
            url = customChatConfig.urls.silentBargeIn + jsonData.binderid;
        }
        jsonData.agentUrl = url;
        jsonData.urlChanged = false;
        $("#activeUrlName" + intid).text(urlConfig.name);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ProcessMoxtraUserConnected()", ex, false);
    }
}

function TextChatAgentConnected(event) {
    try {
        let intid = event.InteractionID;
        //get conference agent info
        let agentInfo = JSON.parse(event.AgentInfoJson);
        //extra parameter for agent info
        let extraParam = JSON.parse(agentInfo.extraparam);
        if (extraParam.conferenceType === "conf" || extraParam.conferenceType === "whisper") {
            ShowNotify(event.AgentName + " connected to the chat", "info", null, "top-center");
        }
        //add the agent to conferenceAgentList
        GetChatReferenceObj(intid).conferenceAgentList.push({ agentId: event.AgentId, confereceType: event.ConferenceType });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatAgentConnected()", ex, false);
    }
}

function CreateQueueHistoryChatBox(intid, data) {
    try {
        $.each(data, function (i, val) {
            let msgDateTime = val.timestamp;
            let msgid = uuid();
            if (val.customer_input) {
                AddMessageToChatbox(intid, msgid, val.customer_input, "customer", msgDateTime, "queueHistoryChatBox", "", false, null, GetChatReferenceObj(intid).customerName);
            }
            else if (val.reply)
                AddMessageToChatbox(intid, msgid, val.reply, "agent", msgDateTime, "queueHistoryChatBox", "", false, null, "Chatbot");
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CreateQueueHistoryChatBox()", ex, false);
    }
}

function LoadVAChatHistoryDialog(intid) {
    try {
        $("#vaHistoryAccordion").hide();
        $("#vaHistoryNoData").show();
        $("#va_history_request_dialog").data("kendoWindow").center().open();
        custom_LoadVAChatHistory(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.LoadVAChatHistoryDialog()", ex, false);
    }
}

function LoadVAChatHistoryChatBox(event) {
    try {
        $("#vaHistoryAccordion").html("");
        var parse = JSON.parse(event.JsonData);
        var sessionList = [];
        if (parse.history.length !== 0) {
            $("#vaHistoryNoData").hide();
            $("#vaHistoryAccordion").show();
            $.each(parse.history, function (i, val) {
                var sessionId = val.SessionID;
                var appendId = sessionId.length >= 30 ? sessionId.substr(sessionId.length - 30, 30) : sessionId;
                var heading = '<h3 class="uk-accordion-title">...' + appendId + '</h3>';
                var content = '<div class="uk-accordion-content no-padding" id="div_' + sessionId + '"></div>';
                var chatBox = '<div class="chat_box touchscroll chat_box_colors_a va_chat_box" id="vaChatBox_' + sessionId + '"></div>';
                var msgid = uuid();
                var user = "";
                var labelName = "Chatbot";
                var msg = "";
                var msgDateTime = "";
                if (sessionList.indexOf(sessionId) < 0) {
                    sessionList.push(sessionId);
                    $("#vaHistoryAccordion").append(heading);
                    $("#vaHistoryAccordion").append(content);
                    $("#div_" + sessionId).append(chatBox);

                    if (val.RequestMessage) {
                        msg = val.RequestMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        user = "customer";
                    }
                    if (val.ReponseMessage) {
                        msg = val.ReponseMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        user = "agent";
                    }
                } else {
                    if (val.RequestMessage) {
                        msg = val.RequestMessage;
                        msgDateTime = val.RequestMessageDateTime;
                        user = "customer";
                    }
                    if (val.ReponseMessage) {
                        msg = val.ReponseMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        user = "agent";
                    }
                }

                //change the label to customer name if the message is from customer
                if (user === "customer") labelName = GetChatReferenceObj(global_activeTabInteractionID).customerName;

                //append message to VA chatbox
                msg ? AddMessageToChatbox("", msgid, isEmojiEnabled ? emojione.toImage(msg) : msg, user, msgDateTime, "vaChatBox_" + sessionId, "", false, null, labelName) : null;
            });
        }
        UIkit.accordion($("#vaHistoryAccordion"));
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.LoadVAChatHistoryChatBox()", ex, false);
    }
}

function TextChatDisconnected(intid, reason) {
    //chat ended
    try {
        GetTabReferenceObj(intid).isCloseTab = true;
        //if chat is disconnected and the tab is blinking, stop the blinking of tab
        if (GetChatReferenceObj(intid).isBlink) {
            $("#li_" + intid).removeClass("blink_chattab");
            GetChatReferenceObj(intid).isBlink = false;
        }
        //if customer is typing and chat disconnect the remove typing div
        if (GetChatReferenceObj(intid).isTyping)
            RemoveTypingDiv(intid);
        //trigger the end on chat disconnect - otherwise timer will be running even after the chat disconnect
        if ($("#hdn_agent_time_taken_end" + intid).val() === "") {
            $("#hdn_agent_time_taken_end" + intid).val(new Date());
        }
        //if auto timer then clear the timer to stop
        if (autoTimerForTimeTaken) {
            clearInterval(GetChatReferenceObj(intid).timeTakenToReply);
            clearInterval(GetTabReferenceObj(intid).tabTimer);
        }
        //if the chat is disconnected before answering remove the chat accordion header blink
        $("#chat_transcript_accordion" + intid).removeClass("blink_chat");
        //if chatCallbackScheduleEnabled is false then don't show callback schedule button 
        //disable the ui controls
        HandleChatControls(intid, "disconnected");
        //remove active tab color
        $("#li_" + intid).removeClass("li-on-call");
        //enable tab close button
        EnableTabCloseButton(intid);
        //if video/audio call is enabled and is going on then close the session
        if (isAVEnabled && GetChatReferenceObj(intid).chatMode !== "text") {
            CloseAVConnection(intid, "end");
        }
        //check for other chat and active AV buttons if enabled
        if (isAudioEscalate || isVideoEscalate) {
            CheckForActiveAV();
        }
        //close all the dialogs opened for chat
        CloseAllChatDialogs();
        ChangeTabReferenceStatus(intid, 'CallDisconnected');
        //add chat reference for the interaction isDisconnected true
        GetChatReferenceObj(intid).isDisconnected = true;
        //remove the notification sent reference if there
        RemoveTransferNotificationRef(intid);
        // hide the audio call UI
        HideAudioCallUI(intid);
        HideVideoCallUI(intid);
        avConn = null;
        cbConn = null;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatDisconnected()", ex, false);
    }
}

function TextChatAgentDisconnected(event) {
    try {
        var intid = event.InteractionID;
        if (event.ConferenceType === "" || event.ConferenceType === "conf" || event.ConferenceType === "whisper") {
            ShowNotify(event.AgentName + " disconnected the chat", "info", null, "top-center");
        }

        //remove the agent from conferenceAgentList
        GetChatReferenceObj(intid).conferenceAgentList = GetChatReferenceObj(intid).conferenceAgentList.filter(function (a) { return a.agentId !== event.AgentId; });

        // check if the chatmode is audio then remove the audio UI
        if (GetChatReferenceObj(intid).chatMode === 'audio') {
            RemoveAudioCallUser(intid, [intid, event.AgentId, event.AgentName]);
        }

        // check if avConnection is there
        if (avConn) {
            // get the stream details
            let streams = avConn.getStreamInfo();

            // get the user items
            let userItem = streams.remote.filter(function (s) {
                return s.user === event.AgentId;
            });

            // remove the UI for the user
            userItem.forEach(function (usr) {
                // remove the video element
                if (avConn.remoteVideo) avConn.remoteVideo.removeVideo(usr.stream.id);
            });
        }

    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatAgentDisconnected()", ex, false);
    }
}

function SendtextChatGreeting(intid) {
    try {
        //message
        if (global_TextChatGreetingText === "" || global_TextChatGreetingText === "undefined" || global_TextChatGreetingText === 0) {
            return;
        }
        if (isEmojiEnabled) {
            //if message is empty return
            $("#textChatMessage" + intid)[0].emojioneArea.setText(global_TextChatGreetingText);
        } else {
            //set the greeting mesage to the textarea
            $("#textChatMessage" + intid).val(global_TextChatGreetingText);
        }
        //send the greeting to chatbox and the server
        SendChat(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendtextChatGreeting()", ex, false);
    }
}

function SendChat(intId) {
    try {
        //if message is empty return
        let message = $("#textChatMessage" + intId).val();
        let messageId = "a_" + global_AgentID + "_" + GetChatReferenceObj(intId).lastMessageId;
        let agentName = global_AgentName.split(" ")[0];
        if (isEmojiEnabled) {
            $("#textChatMessage" + intId)[0].emojioneArea.hidePicker();
            //if message is empty return
            message = $("#textChatMessage" + intId)[0].emojioneArea.getText();
        } else {
            message = $("#textChatMessage" + intId).val();
        }
        //check if the message is empty or null
        if (message === null || message.trim().length === 0) {
            return;
        }

        //sanitize the message
        message = SanitizeMessage(isAppMessage, message);

        //if agent send chat while the customer is typing remove the customer typing div and add it after agent text
        if (GetChatReferenceObj(intId).isTyping) {
            RemoveTypingDiv(intId);
        }

        if (!GetChatReferenceObj(intId).isAgent) {
            //trigger the time agent replied to customer to know total time taken to reply to the customer
            $("#hdn_agent_time_taken_end" + intId).val(new Date());
            //if auto timer then clear the timer to stop
            if (autoTimerForTimeTaken) clearInterval(GetChatReferenceObj(intId).timeTakenToReply);
            GetChatReferenceObj(intId).isCustomer = false;
            GetChatReferenceObj(intId).isAgent = true;
        }
        //check for hyperlinks, if not configured it will return the same message
        message = CheckForHyperlinks(intId, message, true);

        //format the message
        var formattedMsg = FormatTextMessage(message, messageId, intId);

        ////to send msg as an app message
        // var  formattedMsg = ProcessAppMessages(message, messageId, "");

        //send text to server
        SendTextChat(global_DeviceID, intId,
            (isReplyOnChat && !GetChatReferenceObj(intId).isSMM ? JSON.stringify(formattedMsg) : formattedMsg.message),
            formattedMsg.type, formattedMsg.messageId, isAppMessage);

        //create the reply json if required
        var replyJson = {};
        var isReply = formattedMsg.replyId !== "";
        //if reply is enabled then create reply json
        if (isReply) {
            //create the reply json
            replyJson = {
                replyType: GetChatReferenceObj(intId).replyType,
                replyId: GetChatReferenceObj(intId).replyId,
                replyText: GetChatReferenceObj(intId).replyText,
                replyUser: GetChatReferenceObj(intId).replyUser
            };
        }

        //add the text in chatbox
        AddMessageToChatbox(intId, formattedMsg.messageId, isEmojiEnabled ? emojione.toImage(formattedMsg.message) : formattedMsg.message, "agent", "", "divTxtChatTranscript", formattedMsg.type, isReply, replyJson, agentName);

        //clear the template id reference
        GetChatReferenceObj(intId).selectedTemplateId = "";

        //check if grammer check enabled then clear the highlight
        if (isGrammerCheck) {
            ClearHighlightTextarea(intId);
            GrammerCheck(intId);
        }
        if (isEmojiEnabled) {
            $("#textChatMessage" + intId)[0].emojioneArea.setText("");
            $("#textChatMessage" + intId)[0].emojioneArea.setFocus();
        }
        else {
            //clear the textarea
            $("#textChatMessage" + intId).val("");
            //set focus to the textbox after sending the chat
            $("#textChatMessage" + intId).focus();
        }
        //add the customer typing div
        if (GetChatReferenceObj(intId).isTyping) {
            AddTypingDiv(intId);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendChat()", ex, false);
    }
}

function FormatTextMessage(msg, msgId, intId) {
    //  VP: Jun 1, '20: New JSON structure. Added attachment property
    var data = {
        messageId: msgId,
        type: "text",
        message: msg,
        replyId: "",
        templateId: "",
        attachment: null
    };
    try {
        //check if reply feature is enabled then create the json for reply message
        if (isReplyOnChat && !GetChatReferenceObj(intId).isSMM) {
            data.replyId = GetChatReferenceObj(intId).replyId ? GetChatReferenceObj(intId).replyId : "";
            return data;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.FormatTextMessage()", ex, false);
    }
    return data;
}

//function ProcessAppMessages(message, msgId, type) {
//    var data = {
//        isAppMessage: isAppMessage,
//        messageId: msgId,
//        type: type,
//        message: message
//    };

//    try {

//        //check if app messaging is enabled
//        if (!data.isAppMessage) {
//            return data;
//        }

//        check for co-browsing
//        data.text = isFormFilling ? CheckForForms(data.text, intid) : mdata.textsg;
//        var obj = {
//            id: msgId,
//            message: data.text,
//            messageType: "text"
//        };

//        if (data.isReply) {
//            obj.type = "reply";
//            obj.replyIdTextType =
//                GetChatReferenceObj(intid).replyId + "|" +
//                GetChatReferenceObj(intid).replyText + "|" +
//                GetChatReferenceObj(intid).replyType;
//        }
//        else
//            obj.type = "new";

//        data.replyJson.replyType = GetChatReferenceObj(intid).replyType;
//        data.replyJson.replyId = GetChatReferenceObj(intid).replyId;
//        data.replyJson.replyText = GetChatReferenceObj(intid).replyText;
//        data.replyJson.replyUser = GetChatReferenceObj(intid).replyUser;

//        data.text = JSON.stringify(obj);
//    } catch (ex) {
//        log.LogDetails("Error", "TmacTextChatUI.ProcessAppMessages()", ex, false);
//    }
//    return data;
//}

function TextChatMessageSent(event, displayMessage) {
    try {
        //show the message only for recovery event
        if ((event.RecoveryEvent && !event.IsAppMessage) || displayMessage) {
            //get the agent name
            let agentName = global_AgentName.split(" ")[0];
            let formattedMsg = IsValidJson(event.Message) ? JSON.parse(event.Message) : null;
            let intId = event.InteractionID;
            let msgId = formattedMsg ? formattedMsg.messageId : event.EventId;
            let type = formattedMsg ?
                (formattedMsg.type === "attachment" ? formattedMsg.attachment.type : formattedMsg.type) :
                "";
            let msg = formattedMsg ?
                (formattedMsg.type === "attachment" ? formattedMsg.attachment.src : formattedMsg.message) :
                event.Message;
            let dateTime = event.DateTime;
            let attachment = (formattedMsg && formattedMsg.attachment) ? formattedMsg.attachment : null;
            let isReply = formattedMsg && formattedMsg.replyId ? formattedMsg.replyId : false;
            let replyJson = {};
            //if this is a reply get the reply json
            if (isReply && $("#" + intId + "_" + formattedMsg.replyId).length > 0) {
                let replyType = "text";
                try {
                    switch ($("#" + intId + "_" + formattedMsg.replyId)[0].tagName.toLowerCase()) {
                        case "img":
                            replyType = "image";
                            break;
                        case "video":
                            replyType = "video";
                            break;
                        case "audio":
                            replyType = "audio";
                            break;
                        case "a":
                            replyType = "file";
                            break;
                    }
                } catch (e) { }

                //create the reply json
                replyJson = {
                    replyType: replyType,
                    replyId: formattedMsg.replyId,
                    replyText: replyType !== "text" ?
                        $("#" + intId + "_" + formattedMsg.replyId)[0].src :
                        (isEmojiEnabled ?
                            ImageToUnicode($("#" + intId + "_" + formattedMsg.replyId).html()) :
                            $("#" + intId + "_" + formattedMsg.replyId)[0].innerText),
                    // replyText: $("#" + intId + "_" + formattedMsg.replyId)[0].innerText,
                    //replyUser: formattedMsg.replyId.split("_")[0] === "a" ? "You" : GetChatReferenceObj(intId).customerName
                    replyUser: $("#" + intId + "_" + msg.replyId).length > 0 ? $("#" + intId + "_" + msg.replyId).siblings(".user-label")[0].innerText : "User"
                };
            }
            else {
                isReply = false;
            }
            //add message to text chatbox
            AddMessageToChatbox(intId, msgId, isEmojiEnabled ? emojione.toImage(msg) : msg, "agent", dateTime, "divTxtChatTranscript", type, isReply, replyJson, agentName, attachment);

            //apply the last message id
            if (formattedMsg) {
                let id = parseInt(msgId.split("_").pop());
                GetChatReferenceObj(intId).lastMessageId = ++id;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatMessageSent()", ex, false);
    }
}

function TextChatMessageReceived(confType, isAppMessage, message, messageId, intId, user) {
    try {
        let isConitnue = true;
        let labelName = "";
        let userType = "";

        //add the customer name for conference/barge-in
        if (user) {
            labelName = user;
            if (confType === "silent") {
                userType = "agent";
            }
            else
                userType = "conferenceAgent";
        }
        else {
            labelName = GetChatReferenceObj(intId).customerName;
            userType = "customer";
        }

        try {
            if (coBrowse.Enabled && isAppMessage) {
                cb_ReceiveCommand(JSON.parse(message), intId);
            }
        }
        catch (e) { }

        //check for the reply message etc
        var formattedMsg = FormatIncomingTextMessage(message, messageId, intId);

        //if the message received is not app message and in json format return.
        if (!isAppMessage && IsValidJson(message) && !formattedMsg.isValid) {
            isConitnue = false;
        }

        //sanitize the message if configured
        message = SanitizeMessage(isAppMessage, message);

        //process the message if the message is not empty after sanitize and isConitnue true
        if (message && isConitnue) {
            //if customer send chat sometimes i wont get not typing after typing so i need to hide and show again later if still typing
            if (GetChatReferenceObj(intId).isTyping) {
                RemoveTypingDiv(intId);
            }
            //if the chat tab is not active blink the chat tab
            if (!GetChatReferenceObj(intId).isActive) {
                $("#li_" + intId).addClass("blink_chattab");
                GetChatReferenceObj(intId).isBlink = true;
            }
            //time taken timer update
            if (!GetChatReferenceObj(intId).isCustomer) {
                //trigger customer message received time
                $("#hdn_agent_time_taken_start" + intId).val(new Date());
                //set the vlaue to null to start timer until agent replies 
                $("#hdn_agent_time_taken_end" + intId).val("");
                //if auto timer then clear the counter and start the timer
                if (autoTimerForTimeTaken) {
                    GetChatReferenceObj(intId).timeTakenCounter = 0;
                    clearInterval(GetChatReferenceObj(intId).timeTakenToReply);
                    StartChatTimeTakenTimer(intId, "#agent_time_taken_span" + intId);
                }
                GetChatReferenceObj(intId).isCustomer = true;
                GetChatReferenceObj(intId).isAgent = false;
            }

            //check for app message and format
            //var formattedAppMsg = HandleAppMessages(message, messageId);

            //format the message by custom method
            formattedMsg = FormatIncomingTextChat(isAppMessage, formattedMsg.messageId, formattedMsg.message, formattedMsg.type, formattedMsg.replyId !== "", formattedMsg.replyJson, formattedMsg.attachment);

            // check if the message is properly formatted
            if (formattedMsg.message === undefined || formattedMsg.message === null) {
                console.warn(`Unexpected message: ${message}`);
                return;
            }

            //check for hyperlinks, if not configured it will return the same message
            if (!formattedMsg.mediaType && formattedMsg.mediaType === "text")
                formattedMsg.message = CheckForHyperlinks(intId, formattedMsg.message, false);

            //add the message to the chatbox
            AddMessageToChatbox(intId, formattedMsg.messageId, isEmojiEnabled ? emojione.toImage(formattedMsg.message) : formattedMsg.message, userType, "", "divTxtChatTranscript", formattedMsg.mediaType === "attachment" ? formattedMsg.attachment.type : formattedMsg.mediaType, formattedMsg.isReply, formattedMsg.replyJson, labelName, formattedMsg.attachment ? formattedMsg.attachment : null);

            //show notifications for not app message
            ShowNotification((labelName ? labelName : "You have new message"), formattedMsg.message);

            //hide the freeze button if enabled
            $("#btnTextChat_FreezeAutoResponse" + intId).hide();

            //add the customer typing div if already typing
            if (GetChatReferenceObj(intId).isTyping) {
                AddTypingDiv(intId);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatMessageReceived()", ex, false);
    }
}

function FormatIncomingTextMessage(msg, msgId, intId) {
    var data = {
        messageId: msgId,
        type: "text",
        message: msg,
        replyId: "",
        replyJson: {},
        isValid: false
    };
    try {

        //check if reply feature is enabled then create the json for reply message
        if (IsValidJson(msg)) {
            msg = JSON.parse(msg);
            //check if the message is from SMM
            let isFromSMM = msg._id ? true : false;
            //if the message is from SMM format the message accrodingly
            if (isFromSMM) {
                data.messageId = msg._id;
                data.replyId = "";
                data.isValid = true;
                data.type = typeof msg.msg === "object" ? msg.msg.type : "text";

                if (typeof msg.msg === "object") {
                    //  If attachment
                    data.attachment = {
                        src: msg.msg.content.url,
                        type: msg.msg.type,
                        name: ""
                    };
                    //  When caption for image is implemented, this can be changed
                    data.message = "";
                } else {
                    data.message = msg.msg;
                    data.attachment = null;
                }
                data.message = typeof msg.msg === "object" ? msg.msg.content.url : msg.msg;
            }
            else {
                data.messageId = msg.messageId;
                data.type = msg.type === "attachment" ? msg.attachment.type : msg.type;
                data.message = msg.message;
                data.replyId = msg.replyId;
                data.attachment = msg.attachment ? msg.attachment : null;
                data.isValid = true;
                if (data.replyId) {
                    let replyType = "text";
                    try {
                        switch ($("#" + intId + "_" + msg.replyId)[0].tagName.toLowerCase()) {
                            case "img":
                                replyType = "image";
                                break;
                            case "video":
                                replyType = "video";
                                break;
                            case "audio":
                                replyType = "audio";
                                break;
                            case "a":
                                replyType = "file";
                                break;
                        }
                    } catch (e) { }
                    //create the reply json
                    data.replyJson = {
                        replyType: replyType,
                        replyId: msg.replyId,
                        replyText: replyType === "text" ? $("#" + intId + "_" + msg.replyId)[0].innerText : $("#" + intId + "_" + msg.replyId)[0].src,
                        //replyUser: msg.replyId.split("_")[0] === "a" ? "You" : GetChatReferenceObj(intId).customerName
                        //replyUser: $("#" + intId + "_" + msg.replyId).length > 0 ? $("#" + intId + "_" + msg.replyId).siblings(".user-label")[0].innerText : "User"
                        replyUser: CheckReplyUserName(intId, msg.replyId)
                    };
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.FormatIncomingTextMessage()", ex, false);
    }
    return data;
}

function SanitizeMessage(isAppMessage, message) {
    try {
        //check for html sanitize if appMessage then check only the text and if not appMessage just check the text
        if (isSanitizeHtml && ((isAppMessage && JSON.parse(message).messageType === "text") || !isAppMessage))
            if (typeof sanitizeHtml === "function") {
                return sanitizeHtml(message);
            }
            else {
                log.LogDetails("Warning", "TmacTextChatUI.SanitizeMessage()", "sanitizeHtml is not defined", false);
                return message;
            }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SanitizeMessage()", ex, false);
    }
    return message;
}

//function HandleAppMessages(message, msgid, isAppMessage) {
//    var data = {
//        text: message,
//        msgid: msgid,
//        type: "",
//        isReply: false,
//        replyJson: {}
//    };
//    try {
//        //if the message is not an app message then return default data
//        if (!isAppMessage) {
//            return data;
//        }

//        //parse the received json
//        var jsonMessage = JSON.parse(message);
//        if (jsonMessage.messageType && jsonMessage.messageType === "whiteboard") {
//            OpenWhiteBoard(jsonMessage.message);
//        }
//        else if (jsonMessage.messageType) {
//            if (jsonMessage.type === "reply") {
//                data.isReply = true;
//                data.replyJson.replyId = jsonMessage.replyIdTextType.split('|')[0];
//                data.replyJson.replyText = jsonMessage.replyIdTextType.split('|')[1];
//                data.replyJson.replyType = jsonMessage.replyIdTextType.split('|')[2];
//                if (jsonMessage.replyIdTextType.split('|')[0].split('_')[1] === "customer")
//                    data.replyJson.replyUser = "Customer";
//                else
//                    data.replyJson.replyUser = "You";
//            }
//            //append the id received
//            data.msgid = jsonMessage.id;
//            //get the type of message
//            data.type = jsonMessage.messageType;
//            //format the message if the type is file
//            if (data.type === "file") {
//                //define the file types
//                var fileTypes = ["doc", "docx", "pdf"];
//                //get the file type for json message
//                var fileType = GetFileExtension(jsonMessage.message.split('|')[1]);
//                //check if the file type is found in file types
//                if (fileTypes.indexOf(fileType) >= 0)
//                    data.type = "file";
//                else
//                    data.type = "others";
//            }
//            //get the message from json
//            data.text = jsonMessage.message;
//        }
//    } catch (ex) {
//        log.LogDetails("Error", "TmacTextChatUI.HandleAppMessages()", ex, false);
//    }
//    return data;
//}

/**
 * checks if reply box is agent or customer and gets the name accordingly from reply id.
 * @param {string} intId contains interaction id.
 * @param {string} msgId contains reply id.
 * @returns {string} retuens username of the given reply id.
 */
function CheckReplyUserName(intId, msgId) {
    let name = "User";
    try {
        if ($("#" + intId + "_" + msgId).length > 0) {
            if (msgId.split('_')[0] === "c") {
                name = $("#li_customer_text_" + intId + "_" + msgId).attr("username");
                if (name === undefined) {
                    name = $("#li_agent_text_" + intId + "_" + msgId).attr("username");
                    if (name === undefined) {
                        name = $("#" + intId + "_" + msgId).siblings(".user-label")[0].innerText;
                    }
                }
            } else if (msgId.split('_')[0] === "a") {
                name = $("#li_agent_text_" + intId + "_" + msgId).attr("username");
                if (name === undefined) {
                    name = $("#li_customer_text_" + intId + "_" + msgId).attr("username");
                    if (name === undefined) {
                        name = $("#" + intId + "_" + msgId).siblings(".user-label")[0].innerText;
                    }
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckReplyUserName()", ex, false);
        name = "User";
    }
    return name;
}

function AVControlMessageReceived(event) {
    try {
        let intid = event.InteractionID;
        let confereceType = GetChatReferenceObj(intid).conferenceType;
        let conferenceAgentList = GetChatReferenceObj(intid).conferenceAgentList;
        let chatMode = GetChatReferenceObj(intid).chatMode;
        // get all the conference agent list conference type and filter 
        let confList = conferenceAgentList.filter(function (a) { return a.conferenceType === "conf" || a.conferenceType === "silent" || a.conferenceType === "whisper"; });
        // parse the json
        let jsonMessage = JSON.parse(event.Message);

        //if the chatmode is text and this is a conference agent which connected later then ignore all AVControlMessage,
        //but if the first agent drops the chat and then the AVControlMessage should not be ignored.
        if (jsonMessage.to === undefined || jsonMessage.to != global_AgentID) {
            // if (chatMode === "text" &&
            if (event.Type === "requestav" &&
                conferenceAgentList.length > 0 &&
                (confereceType === "conf" || confereceType === "silent" || confereceType === "whisper" || confList.length > 0)) {
                log.LogDetails("Info", "TmacTextChatUI.AVControlMessageReceived()", "Ignore AVControlMessage: " + chatMode + " - " + confereceType, false);
                return;
            }
        }

        //to send WebRTC signals
        if (sendWebRTCInfo.signals) {
            SendWebRTCInfo(intid, "webrtcsignals", "customer", event.Message, GetChatReferenceObj(intid).sessionId);
        }

        if (event.Type === "requestav" || event.Type === "requestcb") {
            StartAVConnection(intid, "", WrcGetCallCode(JSON.parse(event.Message).param));
        }

        // else if (event.Type === "eventav") {
        //     console.log(JSON.parse(event.Message));
        //     let eventAv = JSON.parse(event.Message);
        //     let id = eventAv.id === '0' || eventAv.id === 'customer' ? '0' : eventAv.id;
        //     $(`#tc_ac_call_status_${intid}_${id}`).html(eventAv.event);
        // }

        // if (event.Type === "avtstatus") {
        //     // send ack
        //     let ack = { type: "ackav", originalType: "avtstatus", callId: jsonMessage.callId, originalSequence: '' };
        //     SendAVControlMessage(global_DeviceID, intid, JSON.stringify(ack), "ackav", GetChatReferenceObj(intid).sessionId);
        //     // user rejected the request
        //     if (jsonMessage.param === false || jsonMessage.param === "false") {
        //         if (isAudioEscalate) FadeInButton("#btnTextChat_AudioEscalate" + intid);
        //         if (isVideoEscalate) FadeInButton("#btnTextChat_VideoEscalate" + intid);
        //         if (coBrowse.Enabled) FadeInButton("#btnTextChat_CoBrowse" + intid);
        //         clearTimeout(escalateTimeoutInterval);
        //         log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived()", "Customer has declined your request", true);
        //         // hide the audio call UI
        //         HideAudioCallUI(intid);
        //         // hide the video call UI
        //         HideVideoCallUI(intid);
        //     }
        //     // check if legacy mode, if not send offer from TMAC
        //     else if (jsonMessage.hasOwnProperty('version') && jsonMessage.version === 2) {
        //         avConn.call();
        //     }
        // }
        // else if (event.Type === "requestav") {
        //     // ReviewCodeLine - to change to below when change is done in call-sdk side
        //     // let ack = { type: "ackav", originalType: "requestav", callId: jsonMessage.callId, originalSequence: '' };
        //     // send ack
        //     let ack = { type: "ack-requestav", originalType: "requestav", callId: jsonMessage.callId, originalSequence: '' };
        //     SendAVControlMessage(global_DeviceID, intid, JSON.stringify(ack), "ackav", GetChatReferenceObj(intid).sessionId);
        //     var param = JSON.parse(event.Message).param;
        //     var data = {};
        //     data.type = "avtstatus";
        //     data.sessionid = GetChatReferenceObj(intid).sessionId;
        //     if (param === 'audio') {
        //         ShowAudioCallUI(intid, "Incoming");
        //     }
        //     if (param === 'video') {
        //         ShowVideoCallUI(intid, "Incoming");
        //     }
        //     // create av connection
        //     AVCEscalate(intid, param);
        //     // check if we can accept the request from customer
        //     IsMediaAvailable(param, function () {
        //         UIkit.modal.confirm(ToCamelCase(param) + " call request by customer, Do you want to accept it?",
        //             function () {
        //                 data.param = param;
        //                 data.source = "escalate";
        //                 SendAVControlMessage(global_DeviceID, intid, JSON.stringify(data), data.type, data.sessionid);
        //                 // save stats in db
        //                 SendStatsValues(intid, "config", {
        //                     mediaReady: true
        //                 });
        //             },
        //             function oncancel() {
        //                 if (param === 'audio') {
        //                     HideAudioCallUI(intid);
        //                 }
        //                 HideVideoCallUI(intid);
        //                 data.param = "false";
        //                 SendAVControlMessage(global_DeviceID, intid, JSON.stringify(data), data.type, data.sessionid);
        //                 return;
        //             });
        //     }, function (errMsg) {
        //         log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived()", ToCamelCase(param) + " request, " + errMsg, true);
        //         data.param = "false";
        //         SendAVControlMessage(global_DeviceID, intid, JSON.stringify(data), data.type, data.sessionid);
        //         // save stats in db
        //         SendStatsValues(intid, "config", {
        //             mediaReady: false
        //         });
        //     });
        // }
        // else if (event.Type === "endav") {
        //     // get the param
        //     var param = JSON.parse(event.Message).param;
        //     // check for the param
        //     if (param === 'screenshare') {
        //         return;
        //     }
        //     else {
        //         // get the reason
        //         var reason = JSON.parse(event.Message).reason;
        //         HandleEndAV(intid, reason, "Info");
        //         // save stats in db
        //         SendStatsValues(intid, "mediasummary");
        //     }
        // }
        // if (event.Type === "requestcb") {
        //     let param = JSON.parse(event.Message).param;
        //     SendAVRequest(intid, "cbtstatus", param);
        // }
        // else if (event.Type === "endcb") {
        //     let reason = JSON.parse(event.Message).reason;
        //     //cobrowsePopup.removeEventListener("beforeunload", function () { OnCobrowsePopupClose("", "", ""); });
        //     //cobrowsePopup.close();
        //     //FadeInButton("#btnTextChat_CoBrowse" + intid);
        //     //HandleEndAV(intid, reason);
        // }

        // handle co-browse
        if (cbConn !== null &&
            (jsonMessage.intent === "cobrowse" ||
                jsonMessage.param === "cobrowse" ||
                jsonMessage.type === "endcb")) {
            cbConn.onMessage(event.Message);
        }
        // handle av
        else if (avConn !== null) {
            avConn.onMessage(event.Message);
        }
        else {
            log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived() :: [", event.Type + "] - conn is null", false);
        }

        // SAM 2020-08-17
        if (event.Type === 'SnapShotResponse') {
            snapshotReceivedFromRemote(JSON.parse(event.Message), intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived()", ex, false);
    }
}

function AddMessageToChatbox(intid, messageId, message, type, datetime, chatBoxDiv, attachType, isReply, replyJson, labelName, attachment) {
    try {
        //check if the message id is empty then create new id
        messageId = messageId ? messageId : uuid();
        //li tag
        let li = "";
        //html to append
        let html = "";
        //dateTime for the message
        let dateTime = !datetime ? FormatDate(new Date()) : datetime;
        let loader = '<span class="md-preloader" id="loader_' + intid + '_' + messageId + '"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="96" width="96" viewBox="0 0 75 75"><circle cx="37.5" cy="37.5" r="33.5" stroke-width="4"></circle></svg></span>';
        //let loader = GetHtmlFromTemplate("image_loader_template", intid, { messageId: messageId });
        //reply icon for every message
        let replyIcon = "";
        //is user/customer name required with the message
        let labelTag = "";
        //generate the agent message div
        if (type === "agent") {
            let li1 = "";
            let li2 = "";
            let chatReplyBox1 = "";
            let chatReplyBox2 = "";
            let replyHighlightDiv = "";
            //is user label required
            if (isUserLabel) {
                if (chatBoxType === "outline") {
                    labelTag = '<div class="uk-text-bold user-label uk-text-agent-label uk-text-muted">' + labelName + '</div>';
                }
                else {
                    labelTag = '<div class="uk-text-bold user-label uk-text-agent-label">' + labelName + '</div>';
                }
            }
            //is reply on chat required
            if (isReplyOnChat && replyJson !== null && !GetChatReferenceObj(intid).isSMM) {
                replyIcon = '<i class="uk-icon-mail-reply reply-icon" onclick="AddReplyBox(\'' + messageId + '\',\'' + intid + '\',\'' + labelName + '\',\'' + attachType + '\');"></i>';
            }
            //switch for the attachment type
            switch (attachType) {
                case "image":
                    //let imageTag = '<img onclick="PreviewAttachment(\'' + message + '\');" id="img_' + intid + '_' + messageId + '" class="attach_img uk-display-none" src="' + message + '"/>';
                    let imageTag = '<img onclick="PreviewAttachment(\'' + message + '\');" id="' + intid + '_' + messageId + '" class="attach_img uk-display-none" src="' + message + '"/>';
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_image_' + intid + '_' + messageId + '" class="attach_li">' + replyIcon;
                    li2 = '<div class="img-container">' + loader + imageTag + '</div><span class="chat_message_time attach_time_span">' + dateTime + '</span></li>';
                    break;
                case "audio":
                    //let audioTag = "<audio preload='true' id='aud_" + intid + '_' + messageId + "' controls src='" + message + "'></audio>";
                    let audioTag = "<audio preload='true' id='" + intid + '_' + messageId + "' controls src='" + message + "'></audio>";
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_audio_' + intid + '_' + messageId + '" class="audio_li">' + replyIcon;
                    li2 = '<span>' + audioTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "video":
                    //let videoTag = "<video id='vid_" + intid + '_' + messageId + "' class='videoTag' controls src='" + message + "'></video>";
                    let videoTag = "<video id='" + intid + '_' + messageId + "' class='videoTag' controls src='" + message + "'></video>";
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_video_' + intid + '_' + messageId + '" class="attach_li">' + replyIcon;
                    li2 = '<span>' + videoTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "others":
                    let splitMessage = message.split('|');//0-name, 1-src
                    let name = splitMessage[0];
                    let src = splitMessage[1];
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_file_' + intid + '_' + messageId + '" class="file_li">' + replyIcon;
                    //li2 = '<div class="document-body"><a id="file_' + intid + '_' + messageId + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a></div><span class="chat_message_time">' + dateTime + '</span></li>';
                    li2 = '<div class="document-body"><a target="_blank" id="' + intid + '_' + messageId + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a></div><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "file":
                    let splitFileMessage = message.split('|');//0-name, 1-src
                    let fileName = splitFileMessage[0];
                    let fileSrc = splitFileMessage[1];
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_file_' + intid + '_' + messageId + '" class="file_li">' + replyIcon;
                    //li2 = '<div class="document-body"><a id="file_' + intid + '_' + messageId + '" class="document-filename" download="' + fileName + '" href="' + fileSrc + '">' + fileName + '</a></div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-agent" onclick="PreviewFile(\'' + fileSrc + '\')"></i></li>';
                    li2 = '<div class="document-body"><a target="_blank" id="' + intid + '_' + messageId + '" class="document-filename" download="' + fileName + '" href="' + fileSrc + '">' + fileName + '</a></div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-agent" onclick="PreviewFile(\'' + fileSrc + '\')"></i></li>';
                    break;
                default:
                    let tag = "";
                    if (message.indexOf("\\ud83d\\") > -1) {
                        //tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="emoji_' + intid + '_' + messageId + '">';
                        tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="' + intid + '_' + messageId + '">';
                    }
                    else {
                        //tag = '<span class="chat-text-span" id="text_' + intid + '_' + messageId + '">' + message + '</span>';
                        tag = '<span class="chat-text-span" id="' + intid + '_' + messageId + '">' + message + '</span>';
                    }
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_text_' + intid + '_' + messageId + '">' + replyIcon;
                    li2 = tag + '<span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
            }
            //check if this message is reply for another message
            if (isReply) {
                chatReplyBox1 = '<div class="chat-reply-box" onclick="GotoThisDiv(\'' + replyJson.replyId + '\',\'' + intid + '\');"><span class="uk-text-bold uk-text-primary">' + replyJson.replyUser + '</span><br/><span class="uk-text-small uk-text-reply">';
                chatReplyBox2 = '</span></div>';
                switch (replyJson.replyType) {
                    case "text":
                        if (isEmojiEnabled) {
                            replyHighlightDiv = emojione.toImage(replyJson.replyText);
                        } else {
                            replyHighlightDiv = replyJson.replyText;
                        }
                        break;
                    case "image":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">photo_camera</i> Photo </span><span class="span-reply-img"><img class="reply-img-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "video":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">videocam</i> Video </span><span class="span-reply-img"><video class="reply-vid-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "audio":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">keyboard_voice</i> ' + replyJson.replyText;
                        break;
                    case "file":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">insert_drive_file</i> ' + replyJson.replyText;
                        break;
                }
                replyHighlightDiv = chatReplyBox1 + replyHighlightDiv + chatReplyBox2;
                li = li1 + replyHighlightDiv + li2;
            }
            else
                li = li1 + li2;
            if ($("#" + chatBoxDiv + intid).find("li:last").attr("user") === "agent" && $("#" + chatBoxDiv + intid).find("li:last").attr("username") === labelName) {
                $("#" + chatBoxDiv + intid).find("ul:last").append(li);
                if (chatBoxType === "outline") $("#" + chatBoxDiv + intid).find("ul:last").find(".uk-text-agent-label").addClass("uk-margin-right-15");
            }
            else {
                html = '<div class="chat_message_wrapper chat_message_right uk-animation-fade"><ul class="chat_message' + (chatBoxType === "outline" ? " outline" : "") + '" > ' + li + '</ul ></div > ';
            }
        }
        //generate the customer message div
        else if (type === "customer" || type === "conferenceAgent") {
            let li1 = "";
            let li2 = "";
            let chatReplyBox1 = "";
            let chatReplyBox2 = "";
            let replyHighlightDiv = "";
            if (isUserLabel) {
                labelName = labelName ? labelName : "Customer";
                if (chatBoxType === "outline")
                    labelTag = '<div class="uk-text-bold user-label uk-text-customer-label ' + (type === "customer" ? "uk-text-muted" : "uk-text-facebook") + '">' + labelName + '</div>';
                else
                    labelTag = '<div class="uk-text-bold user-label uk-text-customer-label ' + type + '">' + labelName + '</div>';
            }
            if (isReplyOnChat && replyJson !== null && !GetChatReferenceObj(intid).isSMM) {
                replyIcon = '<i class="uk-icon-mail-reply reply-icon" onclick="AddReplyBox(\'' + messageId + '\',\'' + intid + '\',\'' + labelName + '\',\'' + attachType + '\');"></i>';
            }

            //  VP: Jun 1,' 20: If there's attachment, form the link
            let attachmentLink = "";
            if (attachment != null) {
                if (attachment.src == null || Object.keys(attachment.src).length === 0 || attachment.src.length === 0) {
                    attachmentLink = FileServerUrl.MediaProxy + "/" + GetChatReferenceObj(intid).sessionId + "/" + attachment.name;
                } else {
                    attachmentLink = attachment.src;
                }
            }

            switch (attachType) {
                case "image":
                    //let imageTag = '<img onclick="PreviewAttachment(\'' + message + '\');" id="img_' + intid + '_' + messageId + '" class="attach_img uk-display-none" src="' + message + '"/>';
                    let imageTag = '<img onclick="PreviewAttachment(\'' + attachmentLink + '\');" id="' + intid + '_' + messageId + '" class="attach_img uk-display-none" src="' + attachmentLink + '"/>';
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_image_' + intid + '_' + messageId + '" class="attach_li">' + replyIcon;
                    li2 = '<div class="img-container">' + loader + imageTag + '</div><span class="chat_message_time attach_time_span">' + dateTime + '</span></li>';
                    break;
                case "audio":
                    //let audioTag = "<audio preload='true' id='aud_" + intid + '_' + messageId + "' controls src='" + message + "'></audio>";
                    let audioTag = "<audio preload='true' id='" + intid + '_' + messageId + "' controls src='" + attachmentLink + "'></audio>";
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_audio_' + intid + '_' + messageId + '" class="audio_li">' + replyIcon;
                    li2 = '<span>' + audioTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "video":
                    //let videoTag = "<video id='vid_" + intid + '_' + messageId + "' class='videoTag' controls src='" + message + "'></video>";
                    let videoTag = "<video id='" + intid + '_' + messageId + "' class='videoTag' controls src='" + attachmentLink + "'></video>";
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_video_' + intid + '_' + messageId + '" class="attach_li">' + replyIcon;
                    li2 = '<span>' + videoTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "others":
                    //let splitMessage = message.split('|');//0-name, 1-src
                    //let name = splitMessage[0];
                    //let src = splitMessage[1];
                    let name = attachment.name;
                    let src = attachmentLink;

                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_file_' + intid + '_' + messageId + '" class="file_li">' + replyIcon;
                    //li2 = '<div class="document-body"><a id="file_' + intid + '_' + messageId + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a></div><span class="chat_message_time">' + dateTime + '</span></li>';
                    li2 = '<div class="document-body"><a id="' + intid + '_' + messageId + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a></div><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "file":
                    //let splitFileMessage = message.split('|');//0-name, 1-src
                    //let fileName = splitFileMessage[0];
                    //let fileSrc = splitFileMessage[1];
                    let fileName = attachment.name;
                    let fileSrc = attachmentLink;

                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_file_' + intid + '_' + messageId + '" class="file_li">' + replyIcon;
                    //li2 = '<div class="document-body"><a id="file_' + intid + '_' + messageId + '" class="document-filename" download="' + fileName + '" href="' + fileSrc + '">' + fileName + '</a></div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-customer" onclick="PreviewFile(\'' + fileSrc + '\')"></i></li>';
                    li2 = '<div class="document-body"><a id="' + intid + '_' + messageId + '" class="document-filename" download="' + fileName + '" href="' + fileSrc + '">' + fileName + '</a></div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-customer" onclick="PreviewFile(\'' + fileSrc + '\')"></i></li>';
                    break;
                default:
                    let tag = "";
                    if (message.indexOf("\\ud83d\\") > -1) {
                        //tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="emoji_' + intid + '_' + messageId + '">';
                        tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="' + intid + '_' + messageId + '">';
                    }
                    else {
                        //tag = '<span class="chat-text-span" id="text_' + intid + '_' + messageId + '">' + message + '</span>';
                        tag = '<span class="chat-text-span" id="' + intid + '_' + messageId + '">' + message + '</span>';
                    }
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_text_' + intid + '_' + messageId + '">' + replyIcon;
                    li2 = tag + '<span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
            }

            if (isReply) {
                chatReplyBox1 = '<div class="chat-reply-box" onclick="GotoThisDiv(\'' + replyJson.replyId + '\',\'' + intid + '\');"><span class="uk-text-bold uk-text-primary">' + replyJson.replyUser + '</span><br/><span class="uk-text-small uk-text-reply">';
                chatReplyBox2 = '</span></div>';
                switch (replyJson.replyType) {
                    case "text":
                        if (isEmojiEnabled) {
                            replyHighlightDiv = emojione.toImage(replyJson.replyText);
                        } else {
                            replyHighlightDiv = replyJson.replyText;
                        }
                        break;
                    case "image":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">photo_camera</i> Photo </span><span class="span-reply-img"><img class="reply-img-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "video":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">videocam</i> Video </span><span class="span-reply-img"><video class="reply-vid-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "audio":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">keyboard_voice</i> ' + replyJson.replyText;
                        break;
                    case "file":
                        replyHighlightDiv = '<i class="material-icons notranslate md-color-white">insert_drive_file</i> ' + replyJson.replyText;
                        break;
                }
                replyHighlightDiv = chatReplyBox1 + replyHighlightDiv + chatReplyBox2;
                li = li1 + replyHighlightDiv + li2;
            }
            else
                li = li1 + li2;

            if ($("#" + chatBoxDiv + intid).find("li:last").attr("user") === type && $("#" + chatBoxDiv + intid).find("li:last").attr("username") === labelName) {
                $("#" + chatBoxDiv + intid).find("ul:last").append(li);
                if (chatBoxType === "outline") $("#" + chatBoxDiv + intid).find("ul:last").find(".uk-text-customer-label").addClass("uk-margin-left-15");
            }
            else {
                html = '<div class="chat_message_wrapper uk-animation-fade"><ul class="chat_message' + (chatBoxType === "outline" ? " outline" : "") + '">' + li + '</ul></div>';
            }
        }
        //generate the typing message div
        else if (type === "typing") {
            if (chatBoxType === "outline") {
                let userType = GetChatReferenceObj(intid).typingUser === GetChatReferenceObj(intid).customerName ? "customer" : "agent";
                labelTag = '<div class="uk-text-bold uk-typing-label ' + (userType === "customer" ? "uk-text-muted" : "uk-text-facebook") + '">' + GetChatReferenceObj(intid).typingUser + " typing..." + '</div>';
            }
            html =
                '<div class="chat_message_wrapper uk-animation-fade" id="typing_indicator' + intid + '">' +
                '<ul class="chat_message' + (chatBoxType === "outline" ? " outline" : "") + '">' +
                '<li user="typing" typing="' + GetChatReferenceObj(intid).typingUser + '" id="li_typing_' + intid + '_' + messageId + '" class="typing">' +
                '<div class="typing-css"><span></span><span></span><span></span><span></span><span></span></div>' +
                '</li>' +
                '</ul>' +
                '</div>';
        }
        //generate the divider for transfer chat
        else if (type === "divider") {
            html = "<div class='chat_divider uk-animation-fade'><li user='divider'><span class='uk-text-muted'>" + message + "</span></li></div>";
        }
        //generate the divider for transfered chat
        else if (type === "transconf") {
            html = "<div class='chat_divider transconf uk-animation-fade'><li user='divider'><span class='uk-text-facebook'>" + message + "</span></li></div>";
        }
        //generate the divider for transfered chat
        else if (type === "unread") {
            html =
                "<div class='chat_divider unread uk-margin uk-animation-fade' id='unread_divider" + intid + "'>" +
                "<li user='divider'><span class='uk-text-muted uk-text-bold'>" + message + "</span></li></div>";
        }
        //append the div to chat box
        if (html !== "") {
            $("#" + chatBoxDiv + intid).append(html);
            //add agent/customer name on chat box
            if (isUserLabel) {
                if (type === "agent") {
                    if (chatBoxType === "outline")
                        $(labelTag).insertBefore("#li_agent_text_" + intid + '_' + messageId);
                    else
                        $("#li_agent_text_" + intid + '_' + messageId).prepend(labelTag);
                }
                else if (type === "customer" || type === "conferenceAgent") {
                    if (chatBoxType === "outline")
                        $(labelTag).insertBefore("#li_customer_text_" + intid + '_' + messageId);
                    else
                        $("#li_customer_text_" + intid + '_' + messageId).prepend(labelTag);
                }
                else if (type === "typing" && chatBoxType === "outline") {
                    $(labelTag).insertBefore("#li_typing_" + intid + '_' + messageId);
                }
            }
        }

        //add animation to the li
        if (type === "agent")
            $("#li_agent_text_" + intid + '_' + messageId).addClass("uk-animation-scale-up");
        else if (type === "customer" || type === "conferenceAgent")
            $("#li_customer_text_" + intid + '_' + messageId).addClass("uk-animation-scale-up");

        //chat box div element
        let elem = document.getElementById(chatBoxDiv + intid);
        //scroll to top after appening the message div
        elem.scrollTop = elem.scrollHeight;
        //show the image after the image is loaded by removing the loader
        if (attachType === "image")
            // main image loaded ?
            $('#' + intid + '_' + messageId).on('load', function () {
                // hide/remove the loading image
                $('#loader_' + intid + '_' + messageId).hide();
                $('#' + intid + '_' + messageId).show();
                let elem = document.getElementById(chatBoxDiv + intid);
                //scroll to top after appening the message div
                elem.scrollTop = elem.scrollHeight;
            });
        //close reply box if is reply
        if (isReply && type === "agent")
            CloseReplyBox(intid);
        //some margin issue for reply fixed
        if (isReply && attachType !== "" && attachType !== "audio") {
            $("#" + chatBoxDiv + intid).find(".chat-reply-box:last").css("margin", "0 0 5px 0");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddMessageToChatbox()", ex, false);
    }
}

function AddReplyBox(msgId, intId, who, attachType) {
    try {
        //get the chat reference object
        let chatRefObj = GetChatReferenceObj(intId);
        //if the reference is null return
        if (!chatRefObj) {
            log.LogDetails("Error", "TmacTextChatUI.AddReplyBox()", "chatRefObj is undefined", false);
            return;
        }
        //check if the chat is disconnected then dont process
        if (!chatRefObj.isDisconnected) {
            $("#attachPrev" + intId).css("display", "none");
            if (attachType === "" || attachType === "text") {
                chatRefObj.replyType = "text";
                //chatRefObj.replyText = $("#text_" + intId + "_" + msgId).text();
                chatRefObj.replyText = isEmojiEnabled ? $("#" + intId + "_" + msgId).html() : $("#" + intId + "_" + msgId).text();
                //chatRefObj.replyId = $("#text_" + intId + "_" + msgId).closest("li")[0].id;
                if (isEmojiEnabled) {
                    $("#chat_reply_text" + intId).html(chatRefObj.replyText);
                } else {
                    $("#chat_reply_text" + intId).text(chatRefObj.replyText);
                }
            }
            else if (attachType === "image") {
                $("#attachPrev" + intId).css("display", "table-cell");
                chatRefObj.replyType = "image";
                //chatRefObj.replyText = $("#img_" + intId + "_" + msgId)[0].src;
                chatRefObj.replyText = $("#" + intId + "_" + msgId)[0].src;
                //chatRefObj.replyId = $("#img_" + intId + "_" + msgId).closest("li")[0].id;
                $("#chat_reply_text" + intId).html('<i class="material-icons notranslate">photo_camera</i> Photo');
                $("#attachPrev" + intId).html("<img class='reply-preview-img' src='" + chatRefObj.replyText + "'/>");
            }
            else if (attachType === "video") {
                $("#attachPrev" + intId).css("display", "table-cell");
                chatRefObj.replyType = "video";
                //chatRefObj.replyText = $("#vid_" + intId + "_" + msgId)[0].src;
                chatRefObj.replyText = $("#" + intId + "_" + msgId)[0].src;
                //chatRefObj.replyId = $("#vid_" + intId + "_" + msgId).closest("li")[0].id;
                $("#chat_reply_text" + intId).html('<i class="material-icons notranslate">videocam</i> ' + moment(document.getElementById(intId + "_" + msgId).duration, "ss.SS").format("mm:ss") + ' Video ');
                //$("#chat_reply_text" + intId).html('<i class="material-icons notranslate">videocam</i> ' + moment(document.getElementById("vid_" + intId + "_" + msgId).duration, "ss.SS").format("mm:ss") + ' Video ');
                $("#attachPrev" + intId).html("<video class='reply-preview-vid' src='" + chatRefObj.replyText + "'/>");
            }
            else if (attachType === "audio") {
                chatRefObj.replyType = "audio";
                //chatRefObj.replyText = moment(document.getElementById("aud_" + intId + "_" + msgId).duration, "ss.SS").format("mm:ss");
                chatRefObj.replyText = moment(document.getElementById(intId + "_" + msgId).duration, "ss.SS").format("mm:ss");
                //chatRefObj.replyId = "#" + $("#aud_" + intId + "_" + msgId).closest("li")[0].id;
                $("#chat_reply_text" + intId).html('<i class="material-icons notranslate">keyboard_voice</i> ' + moment(document.getElementById(intId + "_" + msgId).duration, "ss.SS").format("mm:ss") + ' Audio ');
                //$("#chat_reply_text" + intId).html('<i class="material-icons notranslate">keyboard_voice</i> ' + moment(document.getElementById("aud_" + intId + "_" + msgId).duration, "ss.SS").format("mm:ss"));
            }
            else if (attachType === "others" || attachType === "file") {
                chatRefObj.replyType = "file";
                //chatRefObj.replyText = $("#file_" + intId + "_" + msgId).text();
                chatRefObj.replyText = $("#" + intId + "_" + msgId).text();
                //chatRefObj.replyId = $("#file_" + intId + "_" + msgId).closest("li")[0].id;
                $("#chat_reply_text" + intId).html('<i class="material-icons notranslate">insert_drive_file</i> ' + chatRefObj.replyText);
            }
            $("#chat_reply_head" + intId).text(who);
            chatRefObj.replyId = msgId;
            chatRefObj.replyUser = who;
            //show the reply box
            $("#chat_reply_box" + intId).css("margin-top", "0px");
            $("#chat_reply_box" + intId).addClass("show-reply-box");
            $("#div_chat_box_wrapper" + intId).addClass("chat_box_wrapper_reply");
            if (isEmojiEnabled) {
                $("#textChatMessage" + intId)[0].emojioneArea.setFocus();
            }
            else {
                //focus the textbox
                $("#textChatMessage" + intId).focus();
                $("#textChatMessage" + intId).focus();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddReplyBox()", ex, false);
    }
}

function CloseReplyBox(intid) {
    GetChatReferenceObj(intid).replyText = "";
    GetChatReferenceObj(intid).replyUser = "";
    GetChatReferenceObj(intid).replyType = "";
    GetChatReferenceObj(intid).replyId = "";

    $("#chat_reply_box" + intid).css("margin-top", "-75px");
    $("#chat_reply_box" + intid).removeClass("show-reply-box");
    $("#div_chat_box_wrapper" + intid).removeClass("chat_box_wrapper_reply");
    $("#attachPrev" + intid).css("display", "none");
}

function GotoThisDiv(replyId, intId) {
    // Scroll
    var id = "#" + intId + "_" + replyId;
    //  VP : May 29, '20: Fixed this for video and audio tags.
    //id = "#" + $(id).parent()[0].id;
    id = "#" + $(id).parents().closest("li")[0].id;
    //  VP : May 29, '20: Giving 100px from top as offset. Support for multimedia
    //var offSetTop = $(id).height() + 10;
    var offSetTop = 90;
    $("#divTxtChatTranscript" + global_activeTabInteractionID).scrollTo(id, 500, { offset: { top: -offSetTop } });
    setTimeout(function () {
        $(id).addClass("uk-animation-shake");
        setTimeout(function () {
            $(id).removeClass("uk-animation-shake");
        }, 1000);
    }, 500);
}

function AddTypingDiv(intid) {
    try {
        if ($("#typing_indicator" + intid).length === 0) {
            //add typing div to the chat box
            AddMessageToChatbox(intid, uuid(), "", "typing", "", "divTxtChatTranscript", "", false, null, "");
            $("#typing_span" + intid).text(GetChatReferenceObj(intid).typingUser + " typing...");
        }
        else {
            if (chatBoxType === "outline" && $("#divTxtChatTranscript" + intid).find("li:last").attr("typing") !== GetChatReferenceObj(intid).typingUser) {
                $("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").text(GetChatReferenceObj(intid).typingUser + " typing...");
                //let userType = GetChatReferenceObj(intid).typingUser === GetChatReferenceObj(intid).customerName ? "customer" : "agent";
                //$("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").removeClass();
                //$("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").addClass("uk-text-bold uk-typing-label " + (userType == "customer" ? "uk-text-muted" : "uk-text-facebook"));
            }
            $("#typing_span" + intid).text(GetChatReferenceObj(intid).typingUser + " typing...");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddTypingDiv()", ex, false);
    }
}

function RemoveTypingDiv(intid) {
    try {
        //remove the typing div
        $("#typing_indicator" + intid).remove();
        $("#typing_span" + intid).text("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RemoveTypingDiv()", ex, false);
    }
}

function CheckForHyperlinks(intid, message, flag) {
    try {
        if (isHyperlinkWithTag) {
            var returnMessage = "";
            //new message array
            var newMessageArray = [];
            //split the message on 'space'
            var splitMessage = message.split(/ |\n/);
            //foreach split message
            $.each(splitMessage, function (i, val) {
                if (IsValidURL(val)) {
                    var replaceText = val.indexOf("http") >= 0 ? "<a target=_blank href=$1>$1</a>" : "<a target=_blank href=https://$1>$1</a>";
                    //if the link endsWith '/' the link creation has problem so trim the end '/'
                    if (val.endsWith("/")) {
                        val = val.substr(0, val.length - 1);
                    }
                    //generate the <a> tag for links
                    var hyperLink = val.replace(/\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.-]+[.][a-z]{2,4}\/)(?:(?:[^\s()<>.]+[.]?)+|((?:[^\s()<>]+|(?:([^\s()<>]+)))))+(?:((?:[^\s()<>]+|(?:([^\s()<>]+))))|[^\s`!()[]{};:'".,<>?«»“”‘’]))/gi, replaceText);
                    //if hyper links to be send at the end of chat then add to reference
                    if (flag) AddLinkToArray(intid, hyperLink);
                    newMessageArray.push(hyperLink);
                }
                else {
                    newMessageArray.push(val);
                }
            });
            //TODO:: Now the new line messages are also will be in same line with a space after the format
            //after checking the links in message we need to return the message back in input format
            $.each(newMessageArray, function (i, val) {
                returnMessage += val + " ";
            });
            return $.trim(returnMessage);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForHyperlinks()", ex, false);
    }
    //return message incase of any exception
    return message;
}

function AddLinkToArray(intid, val) {
    try {
        GetChatReferenceObj(intid).hyperLinks.push(val);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddLinkToArray()", ex, false);
    }
}

function TextChatWaitTimerEvent(event) {
    try {
        let intId = event.InteractionID;
        //check if this current chat is disconnected
        if (!GetChatReferenceObj(intId).isDisconnected && GetChatReferenceObj(intId).chatMode === "text") {
            GetChatReferenceObj(intId).isAgent = true;

            //get the message template to be sent to customer
            let message = event.AutoResponseTemplate;
            let messageId = "a_" + global_AgentID + "_" + GetChatReferenceObj(intId).lastMessageId;
            let agentName = global_AgentName.split(" ")[0];

            //format the message
            var formattedMsg = FormatTextMessage(message, messageId, intId);

            //send text to server
            SendTextChat(global_DeviceID, intId, isReplyOnChat ? JSON.stringify(formattedMsg) : formattedMsg.message, formattedMsg.type, formattedMsg.messageId, isAppMessage);

            //create the reply json if required
            var replyJson = {};
            var isReply = formattedMsg.replyId !== "";

            //if reply is enabled then create reply json
            if (isReply) {
                //create the reply json
                replyJson = {
                    replyType: GetChatReferenceObj(intId).replyType,
                    replyId: GetChatReferenceObj(intId).replyId,
                    replyText: GetChatReferenceObj(intId).replyText,
                    replyUser: GetChatReferenceObj(intId).replyUser
                };
            }

            //if agent send chat while the customer is typing remove the customer typing div and add it after agent text
            if (GetChatReferenceObj(intId).isTyping) {
                RemoveTypingDiv(intId);
            }

            //add the message div to the chatbox
            AddMessageToChatbox(intId, formattedMsg.messageId, formattedMsg.message, "agent", "", "divTxtChatTranscript", formattedMsg.type, isReply, replyJson, agentName);

            //if this is the final auto response then disconnect the chat
            if (event.IsFinal) {
                EndChat(intId, "Auto response timeout");
            }
            else {
                //add the customer typing div
                if (GetChatReferenceObj(intId).isTyping)
                    AddTypingDiv(intId);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatWaitTimerEvent()", ex, false);
    }
}

function EndChat(intid, reason) {
    try {
        if (!reason) {
            UIkit.modal.confirm('Are you sure to end this chat?',
                function () {
                    EndChatSession(intid, reason);
                });
        }
        else {
            EndChatSession(intid, reason);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.EndChat()", ex, false);
    }
}

function EndChatSession(intid, reason) {
    try {
        var message = "";
        //hyperlinks to server
        $.each(GetChatReferenceObj(intid).hyperLinks, function (i, val) {
            message += val + "\n";
        });
        //if message not empty
        if (message !== "" && sendAllLinksToCustomer) {
            console.log("Hyperlinks");
            console.log(GetChatReferenceObj(intid).hyperLinks);
            let msgid = uuid();
            if (isAppMessage) {
                var obj = {};
                obj.id = msgid;
                obj.message = message;
                obj.messageType = "text";
                obj.type = "new";
                message = JSON.stringify(obj);
            }
            //send the message to server
            SendTextChat(global_DeviceID, intid, "Below are the links shared during conversation \n" + message, "", msgid, false);
        }
        global_endTextChatNotification[intid] = true;
        DisableButton("#btnTextChat_Disconnect" + intid);
        //if video/audio call is enabled and is going on then close the session
        if (isAVEnabled && GetChatReferenceObj(intid).chatMode !== "text") {
            CloseAVConnection(intid, "end");
        }
        EndTextChat(global_DeviceID, intid, false, reason === undefined ? "AgentChatDisconnected" : reason);
        // // save stats in db
        // SendStatsValues(intid, "mediasummary");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.EndChatSession()", ex, false);
    }
}

function CloseAVConnection(intid, source) {
    try {
        // disable AV
        DisableAV(intid);
        // close the avConn
        if (avConn) {
            // check if the call is still connected, then drop av
            if (source === "end" && avConn.isConnected()) {
                avConn.dropCall();
            }
            // check the call type
            if (avConn.getCallType() === WrcCallTypes.Audio) {
                // hide audio call UI
                HideAudioCallUI(intid);
            }
            else {
                // hide the video call UI
                HideVideoCallUI(intid);
            }
        }
        // close the cbConn
        if (cbConn) {
            // check if the call is still connected, then drop av
            if (source === "end" && avConn.isConnected()) {
                avConn.dropCall();
            }
            cbConn.close();
            avCallPopup.close();
        }
        // check if any connection is there else enable the buttons back
        CheckForActiveAV();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CloseAVConnection()", ex, false);
    }
}

function submitTextChatCallbackRequest() {
    try {
        var number = $.trim($("#textChatPreferredNumber").val());
        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }

        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid Number, Please provide a valid number", "danger", null, "top-center");
            return;
        }
        //end current chat
        //EndTextChat(global_DeviceID, global_TextChatCallbackID, true);

        RegisterTextChatCallback(global_DeviceID, global_TextChatCallbackID, number, "");
        $("#callback_dialog").data("kendoWindow").close();
        //close the chat tab
        //CloseUITab(global_TextChatCallbackID, "");
        //CloseTab(global_DeviceID,global_TextChatCallbackID);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.submitTextChatCallbackRequest()", ex, false);
    }
}

function SubmitTextChatScheduleCallbackRequest() {
    try {
        var number = $.trim($("#textScheduleChatPreferredNumber").val());

        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#chatcallbackScheduleRequestDate").val()) === "") {
            ShowNotify("Callback date cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#chatcallbackScheduleRequestTime").val()) === "") {
            ShowNotify("Callback time cannot be empty", "danger", null, "top-center");
            return false;
        }

        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;

        if (!re.test($("#chatcallbackScheduleRequestTime").val())) {
            ShowNotify("Please enter a valid time", "danger", null, "top-center");
            return false;
        }

        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }

        //commandManager.js
        var intid = global_TextChatScheduleCallbackID;
        var startDate = $("#chatcallbackScheduleRequestDate").val();
        var yearone = startDate.substring(0, 4);
        var monthone = startDate.substring(5, 7);
        var dayone = startDate.substring(8, 10);
        var time = $("#chatcallbackScheduleRequestTime").val();
        var hour = time.split(":")[0];
        var min = time.split(":")[1];
        var newstartdate = new Date(yearone, monthone - 1, dayone, hour, min, "00");
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        var callbackDate = yearone + monthone + dayone;

        if (newstartdate < today) {
            ShowNotify("Callback datetime should be greater than today", "danger", null, "top-center");
            return false;
        }
        //removed from the new UI
        var lang = "EN";
        var segment = $("#textChatSegment" + intid).val();
        var subsegment = $("#textChatSubSegment" + intid).val();
        var intent = $("#textChatIntent" + intid).val();
        var custEntType = $("#hfTextChatCustEntType" + intid).val();

        //commandManager.js
        custom_submit('Callback',
            $("#hfTextChatUCID" + intid).val(),
            "",
            "",
            startDate,
            hour,
            min,
            lang + ":" + segment + ":" + subsegment + ":" + intent + ":" + custEntType,
            intid,
            $("#textScheduleChatPreferredNumber").val(),
            global_AgentID,
            $("#hfTextChatCIF" + intid).val(),
            callbackDate,
            hour + min + "00",
            dCallbackType,
            "");

        $("#schedule_callback_dialog").data("kendoWindow").close();

        // Reset the Value back to Empty;
        $("#textScheduleChatPreferredNumber").val("");
        $("#textChatPreferredNumber").val("");
        $("#chatcallbackScheduleRequestDate").val("");
        $("#chatcallbackScheduleRequestTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SubmitTextChatScheduleCallbackRequest()", ex, false);
    }
}

function OpenTextChatCallbackDialog(intid) {
    try {
        global_TextChatCallbackID = intid;
        $("#callback_dialog").data("kendoWindow").center().open();
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#textChatPreferredNumber").val(prefNumber);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatCallbackDialog()", ex, false);
    }
}

function OpenTextChatScheduleCallbackDialog(intid) {
    try {
        global_TextChatScheduleCallbackID = intid;
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#textScheduleChatPreferredNumber").val(prefNumber);
        $("#schedule_callback_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatScheduleCallbackDialog()", ex, false);
    }
}

function TextChatFailure(data) {
    //alert the error
    ShowNotify(data.ErrorDescription, "danger", null, "top-center");
}

function HandleChatControls(intid, type) {
    try {
        var chatControls = {
            answer: false,
            send: false,
            drop: false,
            transfer: false,
            conference: false,
            conversion: false,
            audioEscalate: false,
            videoEscalate: false,
            coBrowse: false,
            muteAudio: false,
            chatTemplate: false,
            callback: false,
            vaHistory: false,
            chatCallbackSchedule: false,
            signature: false,
            tabClose: false,
            screenShare: false
        };

        let focus = false;

        switch (type) {
            case "incoming":
                chatControls.answer = true;
                break;

            case "connectedSilent":
                chatControls.drop = true;
                break;

            case "connectedWhisper":
                chatControls.send = true;
                chatControls.drop = true;
                chatControls.chatTemplate = isChatTemplatesBtn;
                break;

            case "connected":
            case "handleEndAV":
                chatControls.send = true;
                chatControls.drop = true;
                chatControls.transfer = isChatTransfer;
                chatControls.conference = isConference;
                chatControls.conversion = interactionConversion.Enabled && interactionConversion.On.indexOf("oncall") > -1;
                chatControls.audioEscalate = isAudioEscalate;
                chatControls.videoEscalate = isVideoEscalate;
                chatControls.coBrowse = coBrowse.Enabled;
                chatControls.chatTemplate = isChatTemplatesBtn;
                chatControls.callback = isImmediateCallbackBtn;
                chatControls.vaHistory = isVaChatHistoryBtn;
                chatControls.signature = isSignature;
                chatControls.screenShare = screenShareEnabled;
                $("#v_connectivity_status_con" + intid).removeClass("blink-connection");
                focus = true;
                break;

            case "disconnected":
                chatControls.chatCallbackSchedule = isScheduledCallbackBtn;
                chatControls.conversion = interactionConversion.Enabled && interactionConversion.On.indexOf("afterdisconnect") > -1;
                chatControls.tabClose = isEnableCloseTabOnDisconnect.TextChat;
                break;

            case "handleAudioCall":
                chatControls.send = true;
                chatControls.drop = true;
                chatControls.transfer = isChatTransfer;
                chatControls.conference = isConference;
                chatControls.conversion = interactionConversion.Enabled && interactionConversion.On.indexOf("oncall") > -1;
                chatControls.coBrowse = coBrowse.Enabled;
                chatControls.muteAudio = true;
                chatControls.chatTemplate = isChatTemplatesBtn;
                chatControls.callback = isImmediateCallbackBtn;
                chatControls.vaHistory = isVaChatHistoryBtn;
                chatControls.signature = isSignature;
                chatControls.screenShare = screenShareEnabled;
                $("#v_connectivity_status_con" + intid).addClass("blink-connection");
                break;

            case "handleVideoCall":
                chatControls.send = true;
                chatControls.drop = true;
                chatControls.transfer = isChatTransfer;
                chatControls.conference = isConference;
                chatControls.conversion = interactionConversion.Enabled && interactionConversion.On.indexOf("oncall") > -1;
                chatControls.coBrowse = coBrowse.Enabled;
                chatControls.chatTemplate = isChatTemplatesBtn;
                chatControls.callback = isImmediateCallbackBtn;
                chatControls.vaHistory = isVaChatHistoryBtn;
                chatControls.signature = isSignature;
                chatControls.screenShare = screenShareEnabled;
                $("#v_connectivity_status_con" + intid).addClass("blink-connection");
                break;

            case "handleCoBrowse":
                chatControls.send = true;
                chatControls.drop = true;
                chatControls.transfer = isChatTransfer;
                chatControls.conference = isConference;
                chatControls.conversion = interactionConversion.Enabled && interactionConversion.On.indexOf("oncall") > -1;
                chatControls.audioEscalate = isAudioEscalate;
                chatControls.videoEscalate = isVideoEscalate;
                chatControls.chatTemplate = isChatTemplatesBtn;
                chatControls.callback = isImmediateCallbackBtn;
                chatControls.vaHistory = isVaChatHistoryBtn;
                chatControls.signature = isSignature;
                chatControls.screenShare = screenShareEnabled;
                $("#v_connectivity_status_con" + intid).addClass("blink-connection");
                break;

            default:
        }

        SetTextChatControlVisibility(intid, chatControls, focus);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HandleChatControls()", ex, false);
    }
}

function SetTextChatControlVisibility(intid, chatControls, focus) {
    try {
        $('#btnTextChat_Answer' + intid).toggle(chatControls.answer);
        $('#btnTextChat_Disconnect' + intid).toggle(chatControls.drop);
        $('#btnTextChat_Transfer' + intid).toggle(chatControls.transfer);
        $('#btnTextChat_Conference' + intid).toggle(chatControls.conference);
        $('#btnTextChat_Convert' + intid).toggle(chatControls.conversion);
        $('#btnTextChat_LoadVAChatHistory' + intid).toggle(chatControls.vaHistory);
        $('#btnTextChat_ChatTemplate' + intid).toggle(chatControls.chatTemplate);
        $('#btnTextChat_AudioEscalate' + intid).toggle(chatControls.audioEscalate);
        // $('#btnTextChat_AudioMute' + intid).toggle(chatControls.muteAudio);
        $('#btnTextChat_VideoEscalate' + intid).toggle(chatControls.videoEscalate);
        $('#btnTextChat_CoBrowse' + intid).toggle(chatControls.coBrowse);
        $('#btnTextChat_ScreenShare' + intid).toggle(chatControls.screenShare);

        $('#btnTextChat_Callback' + intid).toggle(chatControls.callback);
        $("#btnTextChat_CallbackSchedule" + intid).toggle(chatControls.chatCallbackSchedule);
        $("#btnTextChat_Signature" + intid).toggle(chatControls.signature);
        $("#btnTextChat_FreezeAutoResponse" + intid).toggle(false);

        if (!chatControls.send) {
            $("#textChatMessage" + intid).attr("readonly", "readonly");
            $('#chat_submit_box' + intid).css("pointer-events", "none");
            $('#chat_submit_box' + intid).css("opacity", "0.5");
        }
        else {
            if (focus) {
                setTimeout(function () {
                    if (isEmojiEnabled) {
                        $("#textChatMessage" + intid)[0].emojioneArea.setFocus();
                    }
                    else {
                        $("#textChatMessage" + intid).focus();
                        $("#textChatMessage" + intid).focus();
                    }
                }, 500);
            }
            $("#textChatMessage" + intid).removeAttr("readonly", "readonly");
            $('#chat_submit_box' + intid).css("pointer-events", "all");
            $('#chat_submit_box' + intid).css("opacity", "1");
        }

        if (chatControls.tabClose) {
            EnableTabCloseButton(intid);
        }

        // VP : Feb 27, '20: Disable for social media channels
        if (GetChatReferenceObj(intid).isSMM) {
            $('#btnTextChat_AudioEscalate' + intid).toggle(false);
            // $('#btnTextChat_AudioMute' + intid).toggle(false);
            $('#btnTextChat_VideoEscalate' + intid).toggle(false);
            $('#btnTextChat_CoBrowse' + intid).toggle(false);
            $('#btnTextChat_Callback' + intid).toggle(false);
            $("#btnTextChat_CallbackSchedule" + intid).toggle(false);
            $("#btnTextChat_Signature" + intid).toggle(false);
        }

    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetTextChatControlVisibility()", ex, false);
    }
}

function OpenTextChatTransferDialog(intid) {
    try {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        EnableButton("#btndialogblindtransfercall", "BT", "tag");
        GetTmacWallboardSkills();
        DisableButton("#btnTextChat_Transfer" + intid);
        GetAgentListStaffed(intid, "transferCall", "#btnTextChat_Transfer" + intid, "forward");
        global_transferIntID = intid;
        //transfer type is changed to textchat
        global_CallType = "TextChatTransfer";
        //disable transfer number textbox for chat as we need to select agent from grid
        $("#txtNumberTrans").attr("readonly", "readonly");
        //select the first agent list tab
        $("#tabstrip_transfer").data("kendoTabStrip").select(0);
        //check for the config to enable comments
        if (commentOnTransfer.TextChat) {
            $("#transfer_comments").removeClass("uk-visibility-hidden");
        }
        $("#transfer_dialog").data("kendoWindow").title("Transfer Chat List");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatTransferDialog()", ex, false);
    }
}

function OpenTextChatConfDialog(intid) {
    try {
        EnableButton("#btnConfMCall", "call_split", "icon");
        GetAgentListStaffed(intid, "conferenceCall", "#btnTextChat_Conference" + intid, "group");
        DisableButton("#btnTextChat_Conference" + intid);
        global_conferenceIntID = intid;
        global_CallType = "TextChatConference";
        //disable conference number textbox for chat as we need to select agent from grid
        $("#txtNumberConf").attr("readonly", "readonly");
        $("#conference_dialog").data("kendoWindow").title("Conference Chat List");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatTransferDialog()", ex, false);
    }
}

/**
 * Opens the interaction conversion dialog box to select channel and skill
 * @param {*} intid 
 */
function OpenTextChatConversionDialog(intid) {
    try {
        FadeOutButton("#btnDialogConvertInteraction");

        //  If channels options are not appended from configurations, append
        if ($("[name=convertToChannel]").length === 0) {
            let s = $("#convertInteractionChannels_template").html(),
                t = Handlebars.compile(s);

            //  Append all channels
            $.each(interactionConversion.Channels, function (i, val) {
                let context = {
                    Channel: val.Name,
                    Label: val.Label
                },
                    html = t(context);
                $("#convertInteractionChannels").append(html);
            });
            //  Check the first channel
            $("[name=convertToChannel]")[0].checked = true
            //  Add on click on channel, load skills of that channel
            $("[name=convertToChannel]").click(function () {
                GetTmacWallboardSkills({ elementId: "ConversionSkillsListGrid", widget: "kendoGrid", channel: $("[name=convertToChannel]:checked").val() });
            });
        }

        //  Clear grid
        $("#ConversionSkillsListGrid").data("kendoGrid").dataSource.data([]);
        $("#txtConvertComment").val("");

        GetTmacWallboardSkills({ elementId: "ConversionSkillsListGrid", widget: "kendoGrid", channel: $("[name=convertToChannel]:checked").val() });

        $("#convert_dialog").data("kendoWindow").title("Convert Chat");

        $("#convert_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatConversionDialog()", ex, false);
    }
}

/**
 * Executes command for interaction conversion
 */
function SubmitInteractionConversion() {
    try {
        let $grid = $("#ConversionSkillsListGrid").data("kendoGrid"); //grid ref
        let $cell = $grid.select(); // selected td
        let $row = $cell.closest('tr'); //selected tr

        if ($row === null || $row.length === 0) {
            log.LogDetails("Error", "TmacTextChatUI.ConvertInteraction()", "No skill selected.", true);
            return;
        }
        let skill = $grid.dataItem($row).SkillID;
        let channel = $("[name=convertToChannel]:checked").val();
        let otherData = {
            requestComment: $("#txtConvertComment").val(),
            customerData: JSON.stringify(GetChatReferenceObj(global_activeTabInteractionID).customJson),
            avCallSnapshots: GetChatReferenceObj(global_activeTabInteractionID).avCallSnapshots
        };

        ConvertInteraction(null, global_activeTabInteractionID, channel, skill, JSON.stringify(otherData));
        FadeOutButton("#btnTextChat_Convert" + global_activeTabInteractionID);
        $("#convert_dialog").data("kendoWindow").close();
    } catch (e) {
        log.LogDetails("Error", "TmacTextChatUI.ConvertInteraction()", e, false);
    }
}

function GetResponseFromAgent(event) {
    try {
        let otherData = JSON.parse(event.Data);
        let comment = "",
            s = $("#notification_confirm_template").html(),
            t = Handlebars.compile(s),
            context = {
                agent: event.FromAgentName,
                type: otherData.type === "conf" ? "conference" : "transfer",
                mode: otherData.mode + " chat",
                deviceid: global_DeviceID,
                isComment: event.Comment !== "" ? true : false,
                comment: event.Comment,
                showComment: isCommentOnConfirmaion
            },
            html = t(context);

        var tPop = UIkit.modal.confirm(html,
            function () {
                if (isCommentOnConfirmaion)
                    comment = $("#comment_on_confirmation").val().trim();
                SendTextChatTransferNotificationRespond(event.FromTmacServer, event.FromAgentID, event.FromInteractionID, "Accept", comment, event.Data);
            },
            function oncancel() {
                if (isCommentOnConfirmaion)
                    comment = $("#comment_on_confirmation").val().trim();
                SendTextChatTransferNotificationRespond(event.FromTmacServer, event.FromAgentID, event.FromInteractionID, "Reject", comment, event.Data);
            });

        var tRef = transferNotificationPop.filter(function (t) { return t.from === event.FromAgentID; });
        //add popup reference
        if (tRef.length === 0) {
            transferNotificationPop.push({ from: event.FromAgentID, tPop: tPop });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetResponseFromAgent()", ex, false);
    }
}

function OpenCoBrowseOptionsDialog(intid) {
    try {
        $("#coBrowseTextArea").val("");
        $("#coBrowseByTemplate").click();
        GetTemplatesForInteraction("cobrowse", intid);
        $("#cobrowse_options_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenCoBrowseOptionsDialog()", ex, false);
    }
}

function InitiateCobrowse() {
    try {
        let isValid = true;
        let errorMsg = "";
        let coBrowseOption = "self";

        if ($("[name=coBrowseMode]:checked").val() === "template") {
            let $grid = $("#cobrowse_template_grid").data("kendoGrid"); //grid ref
            let $cell = $grid.select(); // selected td
            let $row = $cell.closest('tr'); //selected tr

            if ($row === null || $row.length === 0) {
                isValid = false;
                errorMsg = "Please select a link from the templates.";
            } else {
                coBrowseOption = $grid.dataItem($row).Text;
            }
        } else
            if ($("[name=coBrowseMode]:checked").val() === "text") {
                if ($("#coBrowseTextArea").val().length === 0) {
                    isValid = false;
                    errorMsg = "Please enter a link in the text box.";
                } else {
                    coBrowseOption = $("#coBrowseTextArea").val();
                }
            }

        if (!isValid) {
            log.LogDetails("Error", "TmacTextChatUI.InitiateCobrowse()", errorMsg, true);
            return false;
        }

        FadeOutButton("#btnTextChat_CoBrowse" + global_activeTabInteractionID);

        //  VP : Jun 3, '20: Send sign request as action message
        var msg = {
            source: "agent",
            options: {
                param: coBrowseOption === "self" ? "customerCurrentPage" : "link",
                url: coBrowseOption === "self" ? null : coBrowseOption
            },
            data: {
                interactionId: global_activeTabInteractionID
            },
            status: "request",
            type: "cobrowse",
            eventName: "ActionMessage",
            id: uuid()
        };
        SendActionMessage(global_DeviceID, global_activeTabInteractionID, JSON.stringify(msg));

        //  Close modal
        $("#cobrowse_options_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitiateCobrowse()", ex, false);
    }
}

function OpenTextChatChatTemplatesDialog(intid) {
    try {
        //$("#ChatTemplatesDialog").dialog("open");
        //custom_LoadChatTemplates(intid);
        OpenChatTemplate(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatChatTemplatesDialog()", ex, false);
    }
}

function GetTextChatCallbackDetails(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        //get details based on the session id from the table
        custom_getdetailsforUCID(parse.srno, parse.sessionid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetTextChatCallbackDetails()", ex, false);
    }
}

function OpenBargeInDialog() {
    try {
        $("#barge_in_dialog").data("kendoWindow").center().open();
        GetTextChatAgentListForBargein("", "");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenBargeInDialog()", ex, false);
    }
}

function BargeInDisplay(txt, intid, AgentID, isCustomer) {
    try {
        let msgid = uuid();
        let msgDateTime = FormatDate(new Date());
        if (isCustomer) {
            AddMessageToChatbox("", msgid, txt, "customer", msgDateTime, "bargeinchatTranscript", "", false, null, "Customer");
        } else {
            AddMessageToChatbox("", msgid, txt, "agent", msgDateTime, "bargeinchatTranscript", "", false, null, "Agent");
        }
        var elem = document.getElementById('bargeinchatTranscript');
        elem.scrollTop = elem.scrollHeight;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.BargeInDisplay()", ex, false);
    }
}

function DisplayTextTranscript(event) {
    try {
        var intId = event.InteractionID;
        for (var i = 0; i < event.Transcript.length; i++) {
            let msgId = event.Transcript[i].Id;
            let msg = event.Transcript[i].Message;
            let agentId = event.Transcript[i].AgentID;
            let msgDateTime = event.Transcript[i].DateTime;
            let agentName = "";
            if (event.Transcript[i].Type.toLowerCase() === "agent") {
                agentName = event.Transcript[i].AgentName.split(" ")[0];
                FormatTranscriptAndAddToChatbox(intId, msgId, "agent", msg, msgDateTime, agentName);
                //AddMessageToChatbox(intId, msgId, msg, "agent", msgDateTime, "divTxtChatTranscript", "", false, null, agentName);
            }
            else if (event.Transcript[i].Type.toLowerCase() === "user") {
                let customerName = GetChatReferenceObj(intId).customerName;
                FormatTranscriptAndAddToChatbox(intId, msgId, "customer", msg, msgDateTime, customerName);
                //AddMessageToChatbox(intId, msgId, msg, "customer", msgDateTime, "divTxtChatTranscript", "", false, null, customerName);
            }
            else {
                agentName = event.Transcript[i].AgentName.split(" ")[0];
                FormatTranscriptAndAddToChatbox(intId, msgId, "transconf", msg + " <b>" + agentName + " : " + agentId + "</b>", "", "");
                //AddMessageToChatbox(intId, msgId, msg + " <b>" + agentName + " : " + agentid + "</b>", "transconf", "", "divTxtChatTranscript", "", false, null, "");
            }
        }
        FormatTranscriptAndAddToChatbox(intId, "", "divider", "Previous agent's conversation", "", "");
        //AddMessageToChatbox(intId, "", "Previous agent's conversation", "divider", "", "divTxtChatTranscript", "", false, null, "");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.DisplayTextTranscript()", ex, false);
    }
}

function FormatTranscriptAndAddToChatbox(intId, msgId, user, msg, msgDateTime, userName) {
    try {
        let formattedMsg = IsValidJson(msg) ? JSON.parse(msg) : null;
        msgId = formattedMsg ? formattedMsg.messageId : msgId;
        let type = formattedMsg ? formattedMsg.type : "";
        let message = formattedMsg ? formattedMsg.message : msg;
        let isReply = formattedMsg && formattedMsg.replyId ? formattedMsg.replyId : false;
        let replyJson = {};
        //if this is a reply get the reply json
        if (isReply && $("#" + intId + "_" + formattedMsg.replyId).length > 0) {
            //create the reply json
            replyJson = {
                replyType: "text",
                replyId: formattedMsg.replyId,
                replyText: isEmojiEnabled ? ImageToUnicode($("#" + intId + "_" + formattedMsg.replyId).html()) : $("#" + intId + "_" + formattedMsg.replyId)[0].innerText,
                //replyText: $("#" + intId + "_" + formattedMsg.replyId)[0].innerText,
                replyUser: $("#" + intId + "_" + formattedMsg.replyId).length > 0 ? $("#" + intId + "_" + formattedMsg.replyId).siblings(".user-label")[0].innerText : "User"
                //replyUser: userName
            };
        }
        else {
            isReply = false;
        }
        //add message to text chatbox
        AddMessageToChatbox(intId, msgId, isEmojiEnabled ? emojione.toImage(message) : message, user, msgDateTime, "divTxtChatTranscript", type, isReply, replyJson, userName);
        //AddMessageToChatbox(intId, msgId, message, user, msgDateTime, "divTxtChatTranscript", type, isReply, replyJson, userName);

        //apply the last message id
        if (formattedMsg && msgId.split("_")[0] === "a") {
            let id = parseInt(msgId.split("_").pop());
            GetChatReferenceObj(intId).lastMessageId = ++id;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.FormatTranscriptAndAddToChatbox()", ex, false);
    }
}

function LoadCIF(intid, ucid) {
    //customCommands.js
    custom_LoadCIF(intid, ucid);
}

function loadCIFValue(event) {
    var parse = JSON.parse(event.JsonData);
    //custom_UpdateInteractionHistory(parse.sessionid, "", "", "", "", parse.detail, "Callback-Start", "In", "Chat", parse.sessionid, "Callback", global_AgentID);
}

function loadUCIDChatToCallback(event) {
    var parse = JSON.parse(event.JsonData);
    custom_UpdateChatToCallback(event.InteractionID, parse.detail, parse.sessionid);

}

function updateUCIDChatToCallback(event) {
    //do nothing

}

function GetTextChatData(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var callbackExist = parse.detail;
        if (callbackExist) {
            hasGetDataEventDetails = true;
            global_voiceCallHasCallback = true;
            global_ExistingCallbackForCustomerTabId = global_ExistingCallbackForCustomerTabId + 1;
            custom_getdetailsforCIF(global_ExistingCallbackForCustomerTabId, parse.srno);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetTextChatData()", ex, false);
    }
}

function SubmitMultipleTextChatCallbackSchedule() {
    try {
        var number = $.trim($("#multipleCallbackSchedulePrefNumber").val());
        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#multipleCallbackScheduleDate").val()) === "") {
            ShowNotify("Callback date cannot be empty", "danger", null, "top-center");
            return false;
        }

        if ($("#multipleCallbackScheduleTime").val() === "") {
            ShowNotify("Callback time cannot be empty", "danger", null, "top-center");
            return false;
        }

        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;

        if (!re.test($("#multipleCallbackScheduleTime").val())) {
            ShowNotify("Please enter a valid time", "danger", null, "top-center");
            return false;
        }

        //commandManager.js
        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid Number, Please provide a valid number", "danger", null, "top-center");
            return;
        }

        var intid = global_activeTabInteractionID;
        var startDate = $("#multipleCallbackScheduleDate").val();
        var yearone = startDate.substring(0, 4);
        var monthone = startDate.substring(5, 7);
        var dayone = startDate.substring(8, 10);
        var time = $("#multipleCallbackScheduleTime").val().split(':');
        var hour = time[0];
        var min = time[1];
        var newstartdate = new Date(yearone, monthone - 1, dayone, hour, min, "00");
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        if (newstartdate < today) {
            ShowNotify("Callback datetime should be greater than today", "danger", null, "top-center");
            return false;
        }

        var callbackDate = yearone + monthone + dayone;
        var comments = $('#txtComments' + intid).val();
        //commandManager.js
        custom_submitMultipleScheduleCallback('Callback', $("#hfmultipleCallbackScheduleRequestSrno").val(), startDate, hour, min, intid,
            callbackDate, hour + min + "00", $("#hfmultipleCallbackScheduleRequestType").val(), $("#multipleCallbackSchedulePrefNumber").val(),
            $("#hfmultipleCallbackScheduleRowId").val(), comments);
        $("#schedule_multiple_callback_dialog").data("kendoWindow").close();
        // Reset the Value back to Empty;
        $("#multipleCallbackSchedulePrefNumber").val("");
        $("#hfmultipleCallbackScheduleRequestSrno").val("");
        $("#hfmultipleCallbackScheduleRequestType").val("");
        $("#hfmultipleCallbackScheduleRowId").val("");
        $("#textChatPreferredNumber").val("");
        $("#multipleCallbackScheduleDate").val("");
        $("#multipleCallbackScheduleTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SubmitMultipleTextChatCallbackSchedule()", ex, false);
    }
}

function OpenChatTemplate(intid) {
    try {
        GetTemplatesForInteraction("chat", intid);
        $("#chat_template_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenChatTemplate()", ex, false);
    }
}

function CloseAllChatDialogs() {
    try {
        $("#chat_template_dialog").data("kendoWindow").close();
        $("#close_callback_dialog").data("kendoWindow").close();
        $("#callback_detail_dialog").data("kendoWindow").close();
        $("#callback_dialog").data("kendoWindow").close();
        $("#va_history_request_dialog").data("kendoWindow").close();
        $("#schedule_multiple_callback_dialog").data("kendoWindow").close();
        $("#schedule_callback_dialog").data("kendoWindow").close();
        $("#confirm_dialog").data("kendoWindow").close();
        $("#conference_dialog").data("kendoWindow").close();
        $("#transfer_dialog").data("kendoWindow").close();
        $("#cobrowse_options_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CloseAllChatDialogs()", ex, false);
    }
}

function ChatTemplateDialogClose(arg) {
    try {
        var $kendoComboBox1 = $('#chat_dept_combobox').data('kendoComboBox');
        $kendoComboBox1.enable(false);
        $kendoComboBox1.value("");
        $kendoComboBox1.dataSource.data("");

        var $kendoComboBox2 = $('#chat_grp_combobox').data('kendoComboBox');
        $kendoComboBox2.enable(false);
        $kendoComboBox2.value("");
        $kendoComboBox2.dataSource.data("");

        $('#chat_template_grid').data('kendoGrid').dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ChatTemplateDialogClose()", ex, false);
    }
}

function TextChatCSATSurvey(event) {
    var parse = JSON.parse(event.JsonData);
    $("#hfCsatUrl" + event.InteractionID).val(parse.SurveyMsg);
}

function InitiateCsatSurvey(data) {
    try {
        var parse = JSON.parse(data.JsonData);
        var value = parse.eCin;
        var arr = [];
        arr = value.split('/');
        var cin = arr[0]; // Customer CIN
        var cinSuffix = arr[1]; // Customer CIN Suffix
        value = parse.eCustSeg;
        arr = value.split('/');
        var custSeg = arr[0]; // Customer segment
        var intent = parse.pTopic;
        var channel = parse.pChannel;
        var brand = parse.pBranding;
        custom_TextChatCsatSurvey(data.InteractionID, data.TextChatSessionID, custSeg, global_LanID, cin, cinSuffix, intent, channel, brand);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitiateCsatSurvey()", ex, false);
    }
}

function OpenNewChatWindow() {
    try {
        $("#start_chat_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenNewChatWindow()", ex, false);
    }
}

function InitNewChat() {
    try {
        var obj = {};
        obj.nric = $.trim($("#txtChatNRIC").val());
        obj.salute = $.trim($("#txtChatSalutation").val());
        obj.name = $.trim($("#txtChatName").val());
        obj.phone = $.trim($("#txtChatPhone").val());
        obj.email = $.trim($("#txtChatEmail").val());

        if (obj.name === "") {
            ShowNotify("Please provide customer name", "danger", null, "top-center");
            return;
        }
        else if (obj.name === "") {
            ShowNotify("Please provide customer name", "danger", null, "top-center");
            return;
        }

        tmac_StartTextChatFromAgent("InitNewChatDone", null, obj.nric, global_AgentID, obj.salute, obj.name, obj.phone, obj.email);
        let isExist = false;
        $.each(dummyCustomerList, function (i, val) {
            if (obj.nric === val.nric && obj.name === val.name) {
                isExist = true;
                return;
            }
        });
        if (!isExist) {
            dummyCustomerList.push(obj);
            customer_chat.get_customerlist();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitNewChat()", ex, false);
    }
}

function InitNewChatDone(data, obj) {
    try {
        $("#start_chat_dialog").data("kendoWindow").close();
        $("#txtChatNRIC").val("");
        $("#txtChatSalutation").val("");
        $("#txtChatName").val("");
        $("#txtChatPhone").val("");
        $("#txtChatEmail").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitNewChatDone()", ex, false);
    }
}

/**
 * Sends an AV request
 * @param {any} intid: Interaction ID
 * @param {any} type: Type
 * @param {any} param: Parameter
 * @param {any} option: Option
 */
function SendAVRequest(intid, param, option) {
    try {
        // start av connection
        StartAVConnection(intid, "", param);

        // av connection start call
        avConn.startCall(param, option,
            {
                // on success callback
                onSuccess: function (paramType) {
                    if (paramType == "video" || paramType == "audio") {
                        // fade out buttons
                        FadeOutButton("#btnTextChat_AudioEscalate" + intid);
                        FadeOutButton("#btnTextChat_VideoEscalate" + intid);
                        // show the audio call UI
                        if (paramType === 'audio') {
                            ShowAudioCallUI(intid, "Outgoing");
                        }
                        // show the video call UI
                        if (paramType === 'video') {
                            ShowVideoCallUI(intid, "Outgoing");
                        }
                    } else if (param === "cobrowse") {
                        FadeOutButton("#btnTextChat_CoBrowse" + intid);
                    }
                },
                // on timeout callback
                onTimeout: function (paramType) {
                    //show the reason
                    log.LogDetails("Info", "TmacTextChatUI.SendAVRequest()", "Escalate " + paramType + " request timed out", true);
                    //show the buttons
                    if (isAudioEscalate) FadeInButton("#btnTextChat_AudioEscalate" + intid);
                    if (isVideoEscalate) FadeInButton("#btnTextChat_VideoEscalate" + intid);
                    if (coBrowse.Enabled) FadeInButton("#btnTextChat_CoBrowse" + intid);
                    // hide the audio call UI
                    if (paramType === 'audio') {
                        // hide the audio call UI
                        HideAudioCallUI(intid);
                    } else if (paramType === "video") {
                        // hide the video call UI
                        HideVideoCallUI(intid);
                    }
                },
                // on error callback
                onError: function (err) {
                    log.LogDetails("Error", "TmacTextChatUI.SendAVRequest()", "Error in starting the call: " + err, true);
                }
            });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendAVRequest()", ex, false);
    }
}

function HandleAudioCall(intid, conferenceType) {
    try {
        //set chat mode
        GetChatReferenceObj(intid).chatMode = "audio";
        //change the icon to phone
        $("#divCustomerName" + intid + " i").html("phone");
        if (conferenceType !== "silent") {
            HandleChatControls(intid, "handleAudioCall");
        }
        // enable all the audio call buttons
        $('#btnTextChat_AudioMute' + intid).removeClass('disabled');
        $('#btnTextChat_AudioHold' + intid).removeClass('disabled');
        $('#btnTextChat_StartScreenshare' + intid).removeClass('disabled');
        $('#btnTextChat_AudioEnd' + intid).removeClass('disabled');
        // check for av calls
        CheckForActiveAV();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HandleAudioCall()", ex, false);
    }
}

function ShowAudioCallUI(intid, direction) {
    $("#tc_ac_direction" + intid).html(direction);
    // show audio call accordio
    $('#chat_audiocall_accordion' + intid).removeClass('uk-display-none');
    // expand accordion
    let accordion = UIkit.accordion($('#chat_accordion' + intid));
    let accordionItem = UIkit.$(accordion.find('[data-wrapper]').get(1));
    // check if expanded then toggle
    if ($(accordionItem[0]).attr('aria-expanded') === 'false') {
        accordion.toggleItem(accordionItem, true, false);
    }
}

function AddAudioCallUser(intid, stream, userInfo) {
    try {
        let id = userInfo.id;
        let user = userInfo.user;

        // check if the user exist then remove and add new coz it can come from different stream
        if ($(`#ac_user_${intid}_${id}`).length > 0) {
            $(`#ac_user_${intid}_${id}`).parent().remove();
        }

        // check if the ui is added for the stream id
        if ($(`#ac_${stream.id}`).length === 0) {
            let html = GetHtmlFromTemplate("dynamic_av_call_template", intid, { name: user, status: 'connecting...', id: id, streamId: stream.id });
            $('#tc_ac_userlist' + intid).append(html);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddAudioCallUser()", ex, false);
    }
}

function AddScreenshareForAudio(intid, stream, userInfo) {
    $("#tc_ac_screenshare" + intid).removeClass("uk-display-none");
    $("#tc_ac_screenshare_divider" + intid).removeClass("uk-display-none");
    $("#tc_ac_screenshare_user" + intid).text(userInfo.user);
    $('#btnTextChat_StartScreenshare' + intid).addClass('disabled');
    document.getElementById("tc_ac_screenshare_video" + intid).srcObject = stream;
}

function RemoveScreenshareForAudio(intid) {
    $("#tc_ac_screenshare" + intid).addClass("uk-display-none");
    $("#tc_ac_screenshare_divider" + intid).addClass("uk-display-none");
    $("#tc_ac_screenshare_user" + intid).text("");
    $('#btnTextChat_StartScreenshare' + intid).removeClass('disabled');
    document.getElementById("tc_ac_screenshare_video" + intid).srcObject = null;
}

function RemoveAudioCallUser(intid, userInfo) {
    try {
        let id = userInfo.id;

        // check if the stream is screenshare
        if (userInfo.type === "screenshare") {
            RemoveScreenshareForAudio(intid);
        }
        else {
            // check if the user exist then remove and add new coz it can come from different stream
            if ($(`#ac_user_${intid}_${id}`).length > 0) {
                $(`#ac_user_${intid}_${id}`).parent().remove();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RemoveAudioCallUser()", ex, false);
    }
}

function HideAudioCallUI(intid) {
    // show audio call accordio
    $('#chat_audiocall_accordion' + intid).addClass('uk-display-none');
    let accordion = UIkit.accordion($('#chat_accordion' + intid));
    let accordionItem = UIkit.$(accordion.find('[data-wrapper]').get(1));
    // check if expanded then toggle
    if ($(accordionItem[0]).attr('aria-expanded') === 'true') {
        accordion.toggleItem(accordionItem, true, false);
    }
    // disable all the audio call buttons
    $('#btnTextChat_AudioMute' + intid).addClass('disabled');
    $('#btnTextChat_AudioHold' + intid).addClass('disabled');
    $('#btnTextChat_StartScreenshare' + intid).addClass('disabled');
    $('#btnTextChat_AudioEnd' + intid).addClass('disabled');
    // clear the user list
    $('#tc_ac_userlist' + intid).empty();
    // clear the status 
    $("#tc_ac_status" + intid + ",.av_call_status").html('...');
    // toggle the screenshare buttons
    ToggleScreenshare(intid, WrcCallTypes.Audio, false);
}

function ShowVideoCallUI(intid, direction) {
    try {
        if (videoCallType === "window") {
            avCallPopup.open(intid);
        } else {
            $("#videoCallDiv" + intid).removeClass("uk-display-none");
            $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-1");
            $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-2");
            // scroll to top
            document.getElementById('div_' + intid).scrollTop = 0;
            //expand tmac on config
            if (isExpandCollapseOnVideoChat) {
                window.resizeTo(screen.width, screen.height);
            }
        }
    } catch (ex) {
    }
}

function HideVideoCallUI(intid) {
    try {
        if (videoCallType === "window") {
            avCallPopup.close();
        } else {
            $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-1");
            $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-2");
            $("#videoCallDiv" + intid).addClass("uk-display-none");
            $("#btnEndAV" + intid).addClass("disabled");
            $("#btnHoldAV" + intid).addClass("disabled");
            $("#btnHoldAV" + intid).removeClass("hold");
            $("#btnMuteAudio" + intid).addClass("disabled");
            $("#btnMuteAudio" + intid).removeClass("muted");
            $("#btnMuteVideo" + intid).addClass("disabled");
            $("#btnMuteVideo" + intid).addClass("muted");
            $("#btnStartScreenShare" + intid).addClass("disabled");
            $("#btnStopScreenShare" + intid).addClass("disabled");
            $(".av-call-popup-container").empty();
            //collapse tmac on config
            if (isExpandCollapseOnVideoChat) {
                ResizeWindow(false);
            }
        }
        // toggle the screenshare buttons
        ToggleScreenshare(intid, WrcCallTypes.Video, false);
    } catch (ex) {

    }
}

function HandleVideoCall(intid, conferenceType) {
    try {
        //change the icon to phone
        $("#divCustomerName" + intid + " i").html("video_call");

        // change the chatmode
        GetChatReferenceObj(intid).chatMode = "video";

        // for tab type video
        if (videoCallType === "tab") {
            $("#btnEndAV" + intid).removeClass("disabled");
            $("#btnHoldAV" + intid).removeClass("disabled");
            $("#btnMuteAudio" + intid).removeClass("disabled");
            $("#btnMuteVideo" + intid).removeClass("disabled");
            $("#btnStartScreenShare" + intid).removeClass("disabled");
            $("#btnStopScreenShare" + intid).removeClass("disabled");
        }
        else {
            // enable mute audio
            $("#btnAVMuteAudio").removeClass("disabled");
            // enable mute video
            $("#btnAVMuteVideo").removeClass("disabled");
        }

        //set text chat controls
        if (conferenceType !== "silent") {
            HandleChatControls(intid, "handleVideoCall");
        }

        // check for active av
        CheckForActiveAV();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HandleVideoCall()", ex, false);
    }
}

function HandleCoBrowse(intid, conferenceType) {
    try {
        // expand tmac on config
        if (isExpandCollapseOnVideoChat) {
            window.resizeTo(screen.width, screen.height);
        }

        $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-1");
        $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-3");
        $("#videoCallDiv" + intid).removeClass("uk-width-large-1-2");
        $("#videoCallDiv" + intid).addClass("uk-width-large-2-3");
        $("#videoCallDiv" + intid).removeClass("uk-display-none");

        //set text chat controls
        if (conferenceType !== "silent") {
            HandleChatControls(intid, "handleCoBrowse");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HandleCoBrowse()", ex, false);
    }
}

function StartAVConnection(intid, conferenceType, type) {
    try {

        // check if the type is number
        if (type === "" || isNaN(type)) {
            log.LogDetails("Error", "TmacTextChatUI.StartAVConnection()", `type should be a number, type=${type}`, false);
            return;
        }

        // create cobrowse conn
        if (type === WrcCallTypes.Screenshare && avConn !== null) {
            log.LogDetails("Info", "TmacTextChatUI.StartAVConnection()", "connection is already created, type=" + type, false);
            return;
        }

        // freeze the auto response
        FreezeTextChatAutoResponse(global_DeviceID, intid);

        // create conn object
        var conn = new Object();

        //create the AV connection by calling AVChannel constructor
        conn = new AVChannel(
            intid,
            global_AgentID,
            global_AgentName,
            GetChatReferenceObj(intid).sessionId,
            "textchat"
        );

        //on connection connected
        conn.onConnected = function () {
            console.log('AVChannel: onConnected');
            //connect to the signalling server if disconnected
            if (GetSRConnection("webrtc") && !GetSRConnection("webrtc").connected) {
                GetSRConnection("webrtc").connect();
            }
            // audio call
            if (type === WrcCallTypes.Audio) {
                HandleAudioCall(intid, conferenceType); //its a audio call
            }
            // video call
            else if (type === WrcCallTypes.Video) {
                HandleVideoCall(intid, conferenceType); //its a video call
            }
            // cobrowse call
            else if (type === WrcCallTypes.CoBrowse) {
                HandleCoBrowse(intid, conferenceType); //its a cobrowse
            }
            // if silent bargeIn then mute the call
            if (conferenceType === "silent") {
                this.mute(true, false);
            }
            // check if screenshare video is there, then disable screenshare button
            if (this.hasScreenshareStream()) {
                $(".btn-screenshare-start").addClass("disabled");
            }
            // show mos UI
            $("#v_connectivity_status_con" + intid).removeClass("uk-display-none");
            // save duration on connected
            GetChatReferenceObj(intid).stats.duration = moment();
        };

        // on connection reconnecting
        conn.onReconnecting = function () {
            console.log('AVChannel: onReconnecting');
        }

        // on connection reconnected
        conn.onReconnected = function () {
            console.log('AVChannel: onReconnected');
        }

        //on connection disconnected
        conn.onDisconnected = function () {
            console.log('AVChannel: onDisconnected');
        };

        // on voice activity 
        conn.onVoiceActivity = function (streamId, level) {
            // check the stream and level
            if (streamId === '' && level === 0) {
                $('.pulse-element-1, .pulse-element-2').css('font-size', '0px');
                return;
            }

            // for audio calls
            if (type === 1) {
                $(`#tc_ac_speaking_${intid}_${streamId} .pulse-element-1`).css('font-size', '5px');
                $(`#tc_ac_speaking_${intid}_${streamId} .pulse-element-2`).css('font-size', '5px');
            }
        }

        //on connection remote video added
        conn.onRemoteVideoAdded = function (stream, streamInfo) {
            console.log('onRemoteVideoAdded:', { stream, streamInfo });

            // check the call type
            if (type !== WrcCallTypes.CoBrowse) {
                if (isSnapshot && !$("#snapshotBtn_" + stream.id).length) {
                    let btn = '<a id="snapshotBtn_' + stream.id +
                        '" data-uk-tooltip="{cls:' + AddSingleQuotes("uk-tooltip-small") + ',pos:' + AddSingleQuotes("bottom")
                        + '}" href="javascript:void(0)" class="av_snapshot" title="Snapshot" onclick="TakeSnapshot('
                        + AddSingleQuotes(stream.id) + ',' + AddSingleQuotes(intid) + ');"><i class="material-icons notranslate">camera_alt</i></a>';
                    $("#div_" + stream.id).append(btn);
                }
                // check for the type
                if (type === WrcCallTypes.Audio) {
                    // handle audio call UI
                    AddAudioCallUser(intid, stream, streamInfo);
                }
                else {
                    // trigger resize
                    avCallPopup.resize();
                }
            }
        };

        //on connection remote video ended
        conn.onRemoteStreamEnded = function (stream, streamInfo) {
            console.log('onRemoteStreamEnded:', { stream, streamInfo });
            // check for the type
            if (type === WrcCallTypes.Audio) {
                // handle audio call UI
                RemoveAudioCallUser(intid, streamInfo);
            }
            else {
                // trigger resize
                avCallPopup.resize();
            }
        };

        //on screenshare connected
        conn.onScreenshareConnected = function (stream, streamInfo) {
            console.log('onScreenshareConnected:', { stream, streamInfo });
            // check for the type
            if (type === WrcCallTypes.Audio) {
                // handle audio call UI screenshare
                AddScreenshareForAudio(intid, stream, streamInfo);
            }
            else {
                $(".btn-screenshare-start").addClass("disabled");
                // trigger resize
                avCallPopup.resize();
            }
        }

        //on screenshare disconnected
        conn.onScreenshareDisconnected = function () {
            $('.screenshare-stream').remove();
            // check for the type
            if (type === WrcCallTypes.Audio) {
                // handle audio call UI screenshare
                RemoveScreenshareForAudio(intid);
            }
            else {
                $(".btn-screenshare-start").removeClass("disabled");
                // trigger resize
                avCallPopup.resize();
            }
        }

        //to send the WebRTC messages
        conn.sendMessage = function (msg, type, sessionId) {
            SendAVControlMessage(global_DeviceID, intid, msg, type, sessionId);
        };

        //the transport to send WebRTC stats
        conn.onCollectorStats = function (result) {
            //get the mos value form stats
            let mos = result.stats.audio.local.mos;

            //store the mos value in reference
            GetChatReferenceObj(intid).mos = mos;

            //show the 'mos' value
            ShowMOSValue(intid, mos);

            // check whether to send stats to TMC
            if (!sendWebRTCInfo.stats) {
                return true;
            }

            // check if webrtc TMC stats is integrated
            let sConn = GetSRConnection("webrtc");

            // check if webrtc stats monitor is available
            if (!sConn || !sConn.connected) {
                log.LogDetails("Error", "TmacTextChatUI.SendWebRTCInfo()", "srConn is not connected.", false);
                return true;
            }

            //send the stats to TMC
            sConn.hub.invoke("storeMetrics", result.stats, result.tagKeys, result.tagValues);
            return true;
        };

        // on screenshare start
        conn.onScreenshareStarted = function () {
            ToggleScreenshare(intid, type, true);
        };

        // on screenshare ended
        conn.onScreenshareEnded = function () {
            ToggleScreenshare(intid, type, false);
        };

        // on incoming call
        conn.onIncoming = function (paramType, response) {
            if (paramType === 'audio') {
                ShowAudioCallUI(intid, "Incoming");
            }
            if (paramType === 'video') {
                ShowVideoCallUI(intid, "Incoming");
            }
            avConfirmPop = UIkit.modal.confirm(ToCamelCase(paramType) + " call request by customer, Do you want to accept it?",
                function () {
                    response(true);
                },
                function oncancel() {
                    if (paramType === 'audio') {
                        HideAudioCallUI(intid);
                    }
                    if (paramType === 'video') {
                        HideVideoCallUI(intid);
                    }
                    response(false);
                });
        };

        // on call failed
        conn.onFail = function () {
            // enable buttons based on config
            if (isAudioEscalate) FadeInButton("#btnTextChat_AudioEscalate" + intid);
            if (isVideoEscalate) FadeInButton("#btnTextChat_VideoEscalate" + intid);
            if (coBrowse.Enabled) FadeInButton("#btnTextChat_CoBrowse" + intid);
            // show an alert
            log.LogDetails("Error", "TmacTextChatUI.StartAVConnection()", "Customer has declined your request", true);
            // hide the audio call UI
            HideAudioCallUI(intid);
            // hide the video call UI
            HideVideoCallUI(intid);
        };

        // on call end 
        conn.onEnd = function (reason) {
            if (avConfirmPop) avConfirmPop.hide();
            HandleEndAV(intid, reason, WrcGetCallMode(type));
        };

        // on user left 
        conn.onUserLeft = function (userId, reason) {
            // get the stream details
            let streams = this.getStreamInfo();

            // get the user items
            let userItem = streams.remote.filter(function (s) {
                return s.user === userId;
            });

            // remove the UI for the user
            userItem.forEach(function (usr) {
                // remove the video element
                if (this.remoteVideo) this.remoteVideo.removeVideo(usr.stream.id);
            });
        };

        // to send av stats
        conn.sendAVStats = function (stats) {
            avWebRTCCommStats.init();
            avWebRTCCommStats.add(stats, intid);
        };

        // on av stats
        conn.onAVStats = function (state) {
            $("#tc_ac_status" + intid + ",.av_call_status").html(state);
        };

        //on connection trace
        conn.onTrace = function (logMsg) {
            log.LogDetails("info", "TmacTextChatUI.StartAVConnection()", logMsg, false);
        };

        //om connection error
        conn.onError = function (errorMsg, errorCode) {
            log.LogDetails("error", "TmacTextChatUI.StartAVConnection()", errorMsg, false);
            //to send WebRTC errors
            if (sendWebRTCInfo.errors) {
                SendWebRTCInfo(intid, "webrtcerrors", "webrtc", errorMsg, GetChatReferenceObj(intid).sessionId);
            }
        };

        // create cobrowse conn
        if (type === WrcCallTypes.CoBrowse) {
            // remote video layout for the call
            conn._remoteVideo = new CobrowseLayout(intid);
            // assign the connection
            cbConn = conn;
        }
        // create av conn
        else {
            // local video layout for the call
            conn._localVideo = (videoCallType === "window") ? "av_sourceVideo" : "sourceVideo" + intid;
            // remote video layout for the call
            conn._remoteVideo = new VideoLayout(document.getElementById((videoCallType === "window") ? "av_remoteVideo" : "remoteVideo" + intid));
            // assign the connection
            avConn = conn;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.StartAVConnection()", ex, false);
    }
}

function HoldIPCall(intid, type) {
    try {
        intid = intid ? intid : avCallPopup.intid;
        let btn = "";

        if (type === "av") {
            btn = (videoCallType === "window") ? $("#btnAVHoldCall") : $("#btnHoldAV" + intid);
        }
        else {
            btn = $("#btnTextChat_AudioHold" + intid);
        }

        if (btn.hasClass("hold")) {
            btn.removeClass("hold");
            btn.removeClass("md-btn-danger");
            btn.addClass("md-btn-primary");
            btn.attr("title", "Hold Call");
            avConn.unHold();
        }
        else {
            btn.addClass("hold");
            btn.removeClass("md-btn-primary");
            btn.addClass("md-btn-danger");
            btn.attr("title", "Unhold Call");
            avConn.hold();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HoldIPCall()", ex, false);
    }
}

function MuteIPAudio(intid, type) {
    try {
        intid = intid ? intid : avCallPopup.intid;
        let btn = "";
        let msg = {};
        let value = "";

        if (type === "av")
            btn = (videoCallType === "window") ? $("#btnAVMuteAudio") : $("#btnMuteAudio" + intid);
        else
            btn = $("#btnTextChat_AudioMute" + intid);

        if (btn.hasClass("muted")) {
            btn.removeClass("muted");
            btn.removeClass("md-btn-danger");
            btn.addClass("md-btn-primary");
            btn.attr("title", "Mute Audio");
            avConn.unMute(true, false);
            value = "unmuteaudio";
            btn.html('<i class="material-icons">mic_off</i>');
        }
        else {
            btn.addClass("muted");
            btn.removeClass("md-btn-primary");
            btn.addClass("md-btn-danger");
            btn.attr("title", "UnMute Audio");
            btn.html('<i class="material-icons">mic</i>');
            avConn.mute(true, false);
            value = "muteaudio";
        }
        msg.type = "avcontrol";
        msg.source = "audio";
        msg.value = value;
        msg.sessionid = GetChatReferenceObj(intid).sessionId;

        SendAVControlMessage(global_DeviceID, intid, JSON.stringify(msg), "avcontrol", msg.sessionid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.MuteIPAudio()", ex, false);
    }
}

function MuteIPVideo(intid) {
    try {
        intid = (intid) ? intid : avCallPopup.intid;
        let msg = {};
        let value = "";
        let btn = (videoCallType === "window") ? $("#btnAVMuteVideo") : $("#btnMuteVideo" + intid);
        if (btn.hasClass("muted")) {
            btn.removeClass("muted");
            btn.removeClass("md-btn-danger");
            btn.addClass("md-btn-primary");
            btn.attr("title", "Mute Video");
            avConn.unMute(false, true);
            value = "unmutevideo";
        }
        else {
            btn.addClass("muted");
            btn.removeClass("md-btn-primary");
            btn.addClass("md-btn-danger");
            btn.attr("title", "UnMute Video");
            avConn.mute(false, true);
            value = "mutevideo";
        }

        msg.type = "avcontrol";
        msg.source = "video";
        msg.value = value;
        msg.sessionid = GetChatReferenceObj(intid).sessionId;

        SendAVControlMessage(global_DeviceID, intid, JSON.stringify(msg), "avcontrol", msg.sessionid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.MuteIPVideo()", ex, false);
    }
}

function DisableAV(intid) {
    try {
        // check the chat mode and change
        if (GetChatReferenceObj(intid).chatMode === "audio" || GetChatReferenceObj(intid).chatMode === "video") {
            GetChatReferenceObj(intid).chatMode = "text";
        }
        //make the tmac ibar and remove the video tags
        $("#chatDetailsDiv" + intid).removeClass();
        $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-1 uk-width-medium-1-1 uk-width-small-1-1");
        $("#videoCallDiv" + intid).addClass("uk-display-none");
        //collapse tmac on config
        if (isExpandCollapseOnVideoChat) {
            ResizeWindow(false);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.DisableAV()", ex, false);
    }
}

function CheckForActiveAV() {
    try {
        let disabledButton = false;
        let activeChatCount = 0;
        $.each(global_ChatReference, function (i, val) {
            if (!val.isDisconnected) {
                activeChatCount++;
                if (val.chatMode !== "text" || activeChatCount > 1)
                    disabledButton = true;
            }
        });

        $.each(global_ChatReference, function (i, val) {
            if (disabledButton) {
                $("#btnTextChat_AudioEscalate" + val.intid).addClass("disabled");
                $("#btnTextChat_VideoEscalate" + val.intid).addClass("disabled");
            }
            else {
                $("#btnTextChat_AudioEscalate" + val.intid).removeClass("disabled");
                $("#btnTextChat_VideoEscalate" + val.intid).removeClass("disabled");
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForActiveAV()", ex, false);
    }
}

function HandleEndAV(intid, reason, type) {
    try {
        log.LogDetails("Info", "TmacTextChatUI.HandleEndAV()", reason, true);

        // close the av connection
        CloseAVConnection(intid, "close");

        //if the conference type is silent we need not process this call controls
        if (GetChatReferenceObj(intid).conferenceType !== "silent") {
            if (isAudioEscalate) FadeInButton("#btnTextChat_AudioEscalate" + intid);
            if (isVideoEscalate) FadeInButton("#btnTextChat_VideoEscalate" + intid);
            // change the chat call controls
            HandleChatControls(intid, "handleEndAV");
        }
        // hide mos UI
        $("#v_connectivity_status_con" + intid).addClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.HandleEndAV()", ex, false);
    }
}

function TakeSnapshot(key, intid) {
    try {
        //  Sam: Aug 17, '20
        if (AppConfigs.Remote.Channel.TextChat.Snapshot.FromRemote) {
            SendActionMessage(global_DeviceID, global_activeTabInteractionID, '{"source":"agent","options":{},"data":{"interactionId":' + intid + '},"status":"request","type":"snapshot","eventName":"ActionMessage","id":"' +
                uuid() + '"}');
            return;
        }

        $("#snapIntid").val(intid);

        var video = document.getElementById("vid_" + key),
            width = video.videoWidth,
            height = video.videoHeight,
            canvas = document.querySelector("#snapshotPreview"),
            context = canvas.getContext('2d');

        canvas.width = width;
        canvas.height = height;

        context.fillRect(0, 0, width, height);
        context.drawImage(video, 0, 0, width, height);

        UIkit.modal("#modal_snapshot_preview").show();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TakeSnapshot()", ex, false);
    }
}

function CloseSSPDialog(type) {
    try {
        if (type === "submit") {
            let intid = $("#snapIntid").val(), canvas = document.querySelector("#snapshotPreview"), base64 = canvas.toDataURL();

            let customerData = GetChatReferenceObj(intid).customJson;
            if (customerData == null) customerData = {};

            SaveVideoSnap(GetChatReferenceObj(intid).sessionId, intid, customerData.pCIF, customerData.pName, customerData.pMobileNumber, "", base64, customerData.pMobileNumber, customerData.pCIF, GetChatReferenceObj(intid).chatMode, customerData.pChatBotSid, null);
        }
        UIkit.modal("#modal_snapshot_preview").hide();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CloseSSPDialog()", ex, false);
    }
}

function RequestSignature(intid) {
    try {
        //SendTextChatWithType(intid, "", "sign", "", null);

        //  VP : Jun 3, '20: Send sign request as action message
        var msg = {
            source: "agent",
            options: {},
            data: {
                interactionId: intid
            },
            status: "request",
            type: "sign",
            eventName: "ActionMessage",
            id: uuid()
        };
        SendActionMessage(global_DeviceID, intid, JSON.stringify(msg));

        DisableButton("#btnTextChat_Signature" + intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RequestSignature()", ex, false);
    }
}

function ImageToUnicode(text) {
    let actualtext = text;
    try {
        let regeximgtag = /<img.?alt="(.?)"[^\>]+>/g;
        console.log('text', text);
        let found = text.match(regeximgtag);
        if (found) {
            for (i = 0; i < found.length; i++) {
                let regexaltmatch = /alt=[\"\']([^\"\']+)/g;
                let regexaltreplace = /alt=[\"\']/g;
                let alt = found[i].match(regexaltmatch, "");
                console.log('found[i]', found[i]);
                let unicode = alt[0].replace(regexaltreplace, "");
                console.log('unicode', unicode);
                actualtext = actualtext.replace(found[i], unicode);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ImageToUnicode()", ex, false);
    }
    return actualtext
}

var avCallPopup = new function () {
    let _this = this;

    let _header = $("#avCallPopupHeader");
    let _selfVideoDiv = $("#av_sourceVideo").parent();

    _this.selfVideo = new function () {
        let _$this = this;

        // hide self video container
        _$this.hide = function () {
            _selfVideoDiv.addClass("uk-display-none");
        }

        _$this.show = function () {
            // show self video container
            _selfVideoDiv.removeClass("uk-display-none");
        }
    }

    // display popup control buttons based on configuration
    if (!avPopupConfig.allowMaximize) {
        $(".btn-popup-maximize").addClass("uk-display-none");
    }
    if (!avPopupConfig.allowMinimize) {
        $(".btn-popup-minimize").addClass("uk-display-none");
    }
    if (!avPopupConfig.allowPip) {
        $(".btn-popup-pip").addClass("uk-display-none");
    }

    // pop element
    _popupElement = $("#videoCallPopup");
    _this.position = { x: "10px", y: "10px" };
    _this.intid = "";
    _this.active = false;

    // to open popup
    _this.open = function (intid) {
        _this.intid = intid;
        _this.active = true;
        _this.unhide();

        // show popup mode as configured
        switch (avPopupConfig.defaultMode) {
            case "pip":
                _this.pip();
                break;
            case "max":
                _this.maximize();
                break;
            case "min":
                _this.minimize();
                break;
        }

        return _this;
    };

    // header object
    _this.header = new function () {
        let _thisHead = this;
        _thisHead.show = function (title, draggable) {
            _header.removeClass("uk-display-none");
            if (title) {
                _header.text(title);
            }
            if (draggable) {
                _this.drag.byHeader();
            } else {
                _this.drag.byBody();
            }
        }
        _thisHead.hide = function () {
            _header.addClass("uk-display-none");
            _this.drag.byBody();
        }
    }

    // close av call popup
    _this.close = function () {
        // set active false
        _this.active = false;
        // hide
        _this.hide();
        // reset av popup ui
        _this.clear();
        // hide av call minimized view
        $("#av_minimized").addClass('uk-display-none');
    };

    // hide av call popup
    _this.hide = function () {
        _popupElement.addClass("uk-display-none");
    }

    // unhide av call popup
    _this.unhide = function () {
        _popupElement.removeClass("uk-display-none");
    }

    // reset av call popup ui
    _this.clear = function () {
        // remove video container
        $(".av-call-popup-container").remove();
        // remove screenshare container
        $(".ss-vid-container").remove();
        // unmute audio and video buttons on popup close
        $("#btnAVMuteAudio")
            .removeClass("muted")
            .removeClass("md-btn-danger")
            .addClass("md-btn-primary")
            .attr("title", "Mute Audio");
        $("#btnAVMuteVideo")
            .removeClass("muted")
            .removeClass("md-btn-danger")
            .addClass("md-btn-primary")
            .attr("title", "Mute Video");
        // remove screenshare landscape and potrait view classes
        _popupElement.removeClass("with-screen-share-l").removeClass("with-screen-share-p");
        $("#av_remoteVideo").css({
            height: "100%",
            width: "100%"
        })
        // hide stop screen share button and display screenshare start button
        $(".btn-popup-screenshare-stop").addClass("uk-display-none");
        $(".btn-popup-screenshare").removeClass("uk-display-none");

        // hide popup header
        _this.header.hide();
        //show selfvideo
        _this.selfVideo.show();
    }

    // place av popup at center
    _this.center = function () {
        let x = window.innerWidth / 2;
        let y = window.innerHeight / 2;
        x -= _popupElement.width() / 2;
        y -= _popupElement.height() / 2;
        _popupElement.css({
            top: x + "px",
            left: y + "px"
        });
    };

    // move av popup position
    _this.moveTo = function (pos) {
        _popupElement.css({
            top: pos.y,
            left: pos.x
        });
    }

    // get av popup position
    _this.getPosition = function () {
        return {
            x: _popupElement.css("top"),
            y: _popupElement.css("left")
        }
    }

    // drag eleement
    _this.drag = new DraggableElement(document.getElementById("videoCallPopup"), document.getElementById("avCallPopupHeader"));

    // to resize
    _this.resize = function () {
        try {
            let container = $("#videoCallPopup .av-call-popup-container");
            let videosCount = $(".av-call-popup-container").children().length;
            container
                .removeClass("videos-1")
                .removeClass("videos-2-p")
                .removeClass("videos-2-l")
                .removeClass("videos-3")
                .removeClass("videos-4");
            if (videosCount == 1) {
                container.addClass("videos-1");
            } else if (videosCount == 2) {
                if (_popupElement.width() > _popupElement.height()) {
                    container.addClass("videos-2-l");
                } else {
                    container.addClass("videos-2-p");
                }
            } else if (videosCount == 3) {
                container.addClass("videos-3");
            } else if (videosCount == 4) {
                container.addClass("videos-4");
            }
        } catch (ex) {

        }
    }

    $("#page_content_inner").prepend(
        `<div class="uk-display-none uk-alert uk-alert-success" id="av_minimized" data-uk-alert="">
           click here to return to call window.
        </div>`);
    $("#av_minimized").click(function () {
        $("#av_minimized").addClass("uk-display-none");
        _this.unhide();
    });

    // to maximize
    _this.maximize = function () {
        _popupElement.css({
            "max-width": "100%",
            "max-height": "100%"
        });
        _popupElement.addClass("fullscreen");
        $(".btn-popup-maximize").addClass('uk-display-none');
        if (avPopupConfig.allowPip) {
            $(".btn-popup-pip").removeClass("uk-display-none");
        }

        _this.position = _this.getPosition();
        _this.moveTo({ x: "0px", y: "0px" });
        _this.drag.disable();
        _this.resize();
    }

    // pip
    _this.pip = function () {
        _popupElement.removeClass("fullscreen");
        $(".btn-popup-pip").addClass('uk-display-none');
        if (avPopupConfig.allowMaximize) {
            $(".btn-popup-maximize").removeClass("uk-display-none");
        }
        _this.moveTo({ x: "10px", y: "10px" });
        _this.drag.enable();
        _this.resize();
    }

    // to minimize
    _this.minimize = function () {
        $("#av_minimized").removeClass("uk-display-none");
        _this.hide();
    }

    // screen share logic
    _this.screenshare = new function () {
        try {
            let _thisSS = this;
            // start sharing screen
            _thisSS.start = function () {
                StartScreenshare();
            }
            // stop screen share logic
            _thisSS.stop = function () {
                StopScreenshare();
            }
        } catch (ex) {
            log.LogDetails("Error", "TmacTextChatUI.av_call_popup.screenshare()", ex, false);
        }
    }

    $(".btn-popup-maximize").click(function () {
        _this.maximize();
    });

    $(".btn-popup-pip").click(function () {
        _this.pip();
    });

    $(".btn-popup-minimize").click(function () {
        _this.minimize();
    });

    $(".btn-popup-screenshare").click(function () {
        _this.screenshare.start();
    });

    $(".btn-popup-screenshare-stop").click(function () {
        _this.screenshare.stop();
    });

    $(".btn-popup-end-call").click(function () {
        EndAvCall(_this.intid);
    });

    $(window).resize(function () {
        if (_popupElement.hasClass("fullscreen")) {
            _popupElement.css({
                "max-width": "100%",
                "max-height": "100%"
            });
        } else {
            _this.moveTo({ x: "10px", y: "10px" });
            _popupElement.css({
                "max-width": "400px",
                "max-height": "600px"
            });
        }
    });
}

function SendStatsValues(intid, type, data) {
    try {
        let chatRef = GetChatReferenceObj(intid);
        let sendValue = "";
        if (type === "config") {
            //  If media not ready, 0 else, 1
            if (data.mediaReady)
                sendValue += "1" + ",";
            else
                sendValue += "0" + ",";
            $.each(webRTCApiConfig.webRTCConfig.iceServers, function (i, val) {
                sendValue += val.urls + "|";
            });
            sendValue = sendValue.slice(0, sendValue.length - 1);
        } else if (type === "signalling") {
            let messageType = data.type;
            sendValue += messageType + ":";
            if (messageType === "requestav") {
                // send data as "requestav:0/1" (1-audio, 2-video, 3-screenshare, 4-cobrowse call by customer)
                switch (data.message.param) {
                    case "audio":
                        sendValue += "1" + ":" + data.message._statSource;
                        break;
                    case "video":
                        sendValue += "2" + ":" + data.message._statSource;
                        break;
                    case "screenshare":
                        sendValue += "3" + ":" + data.message._statSource;
                        break;
                    case "cobrowse":
                        sendValue += "4" + ":" + data.message._statSource;
                        break;
                }
                $("#tc_ac_status" + intid + ",.av_call_status").html(data.message._statSource === 's' ? 'requested' : 'request');
            }
            else if (messageType === "ackav") {
                sendValue += data.message.originalType + ":" + data.message._statSource;
            }
            else if (messageType === "ack-requestav") {
                sendValue = 'ackav:requestav:r';
            }
            else if (messageType === "avtstatus") {
                // send data as "avtstatus:0/1" (0-rejected, 1-acepted by customer)
                if (data.message.param === false || data.message.param === "false") {
                    sendValue += "0" + ":" + data.message._statSource;
                } else {
                    sendValue += "1" + ":" + data.message._statSource;
                }

                $("#tc_ac_status" + intid + ",.av_call_status").html(data.message._statSource === 's' ? 'accepted' : 'accept');
            }
            else if (messageType === "icestatus") {
                //  new: 1, checking: 2, connected: 3, completed: 4, failed: 5, disconnect: 6, closed: 7
                switch (data.message) {
                    case "new": sendValue += "1";
                        break;
                    case "checking": sendValue += "2";
                        break;
                    case "connected": sendValue += "3";
                        break;
                    case "completed": sendValue += "4";
                        break;
                    case "failed": sendValue += "5";
                        break;
                    case "disconnect": sendValue += "6";
                        break;
                    case "closed": sendValue += "7";
                        break;
                }

                $("#tc_ac_status" + intid + ",.av_call_status").html(data.message);
            }
            else if (messageType === "error") {
                sendValue += data.message.errorCode;

                $("#tc_ac_status" + intid + ",.av_call_status").html('error');
            }
            else {
                if (messageType === "offer") {
                    $("#tc_ac_status" + intid + ",.av_call_status").html(data.message._statSource === 's' ? 'calling' : 'incoming');
                }
                else if (messageType === "answer") {
                    $("#tc_ac_status" + intid + ",.av_call_status").html(data.message._statSource === 's' ? 'answering' : 'answered');
                }
                else if (messageType === "candidates") {
                    $("#tc_ac_status" + intid + ",.av_call_status").html('media connecting');
                }

                // webrtc messages, check if statSource available, ignore the rest
                if (data.message._statSource) {
                    sendValue += data.message._statSource;
                }
            }
        } else if (type === "mediasummary") {
            // calculate av call duration
            let duration = GetChatReferenceObj(intid).stats.duration;
            GetChatReferenceObj(intid).stats.duration = moment().diff(duration) / 1000;

            sendValue = chatRef.stats.duration;
            sendValue += "," + chatRef.stats.mos.min + "|" + chatRef.stats.mos.max;
            sendValue += "," + chatRef.stats.audioPacketsLost;
            sendValue += "," + chatRef.stats.videoPacketsLost;
            sendValue += "," + chatRef.stats.ASB.min + "|" + chatRef.stats.ASB.max;
            sendValue += "," + chatRef.stats.jitter.min + "|" + chatRef.stats.jitter.max;
            sendValue += "," + chatRef.stats.audioBytesSent;
            sendValue += "," + chatRef.stats.audioBytesReceived;
            sendValue += "," + chatRef.stats.videoBytesSent;
            sendValue += "," + chatRef.stats.videoBytesReceived;
        }

        let sessionid = GetChatReferenceObj(intid).sessionId;

        StoreWebRTCCommStats([{
            Data: sendValue,
            DataType: type,
            DateTime: new Date().toISOString(),
            SessionId: sessionid,
            Source: "agent"
        }
        ], {
            intid: intid
        }, function (resultObj, userObj, inputData) {
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendStatsValues()", ex, false);
    }
}

function StartScreenshare() {
    if (avConn) {
        avConn.startScreenshare();
    }
}

function StopScreenshare() {
    if (avConn) {
        avConn.stopScreenshare();
    }
}

function ToggleScreenshare(intid, type, enable) {
    try {
        if (enable) {
            if (type === WrcCallTypes.Audio) {
                // display stop screenshare button and hide start button
                $("#btnTextChat_StopScreenshare" + intid).removeClass("uk-display-none");
                $("#btnTextChat_StartScreenshare" + intid).addClass("uk-display-none");
            }
            else if (type === WrcCallTypes.Video) {
                // display stop screenshare button and hide start button
                $(".btn-screenshare-stop").removeClass("uk-display-none");
                $(".btn-screenshare-start").addClass("uk-display-none");
                // resize of window type
                if (videoCallType === "window") avCallPopup.resize();
            }
        }
        else {
            if (type === WrcCallTypes.Audio) {
                // display start button and hide stop button
                $("#btnTextChat_StopScreenshare" + intid).addClass("uk-display-none");
                $("#btnTextChat_StartScreenshare" + intid).removeClass("uk-display-none");
            } else if (type === WrcCallTypes.Video) {
                // display start button and hide stop button
                $(".btn-screenshare-stop").addClass("uk-display-none");
                $(".btn-screenshare-start").removeClass("uk-display-none");
                // resize of window type
                if (videoCallType === "window") avCallPopup.resize();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ToggleScreenshare()", ex, false);
    }
}

function EndAvCall(intid) {
    try {
        UIkit.modal.confirm('Are you sure to end the call?',
            function () {
                // get the chatmode
                let chatMode = GetChatReferenceObj(intid).chatMode;
                // drop the av call
                avConn.dropCall();
                // handle endav
                HandleEndAV(intid, msg.reason, chatMode);
                // check the mode
                if (chatMode === "audio") {
                    // hide the audio call end
                    HideAudioCallUI(intid);
                }
                else {
                    // hide the video call UI
                    HideVideoCallUI(intid);
                }
            });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.EndAvCall()", ex, false);
    }
}

function SendWebRTCInfo(intid, type, source, info, sessionId) {
    try {
        var conn = GetSRConnection("webrtc");
        if (conn && !conn.connected) {
            log.LogDetails("Error", "WebRTCConnector.SendWebRTCInfo()", "srConn is not connected.", false);
            return;
        }
        var packetsToSend = {};
        packetsToSend.AgentId = global_AgentID;
        packetsToSend.IntId = intid;
        packetsToSend.Source = source;
        packetsToSend.SessionId = sessionId;
        var details = [];
        packetsToSend.Type = type;

        try {
            details.push(JSON.parse(info));
        } catch (e) {
            details.push(info);
        }

        packetsToSend.Details = JSON.stringify(details);

        conn.hub.invoke('StoreCallStats', packetsToSend);

    } catch (ex) {
        log.LogDetails("Error", "WebRTCConnector.SendWebRTCInfo()", ex, false);
    }
}