﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "GlobalVarsStatic.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
//try {
//    global_addVersions(filename, file_version);
//} catch (ex) {
//    console.log(e);
//}
// ----------------------------------------------------------------------------------
var isTmacWindowFocus = false;
var notificationType = "";
var notificationList = [];
var checkForTmacFocus = true; // true - if tmac focus is to be checked to display notification
//initially isReminderThreadStarted is false
var isReminderThreadStarted = false;
//store the reminder list in this variable for the thread loop
var globalReminderList;
var quotesList = [];
// Below two variables are used for to store current window width and Height
//  based on these variables, we can set the CRM window width and position.
var Application_Window_Current_Width = 0;
var Application_Window_Current_Height = 0;
// Set the active tab id to this variable
var global_activeTabId;
// Connect array for ucid
var global_connectUCID = [];
//added by sirajuddin for CBG integration
var global_connectedProxy = "";
//open tabs array
var global_openTabs = [];
//open tabs ucid array
var global_openTabsUCID = [];
var global_tabCount = 0;
var global_QueueTimeColor = [];
var global_UCID = [];
var global_OutboundUCID;
var global_ConnectionHandle;
//Global Variable to check if the voice call received has a callback already registered
var global_voiceCallHasCallback = false;
var global_TextChatScheduleCallbackID;
var global_ExistingCallbackForCustomerTabId = 2000; // global variable for interaction id when a customer has a callback tab when he initiates a chat
var global_AgentForcedLogoffEventFlag = false;
var global_InteractionTabs = [];
//recent alerts
var recentAlerts = [];
//text chat transfer tmac server
var destTmacServerName = "";
//favorite list on transfer
var favListGridItemSelect = "";
//text chat transfer favorite list
var favListGridItemSelectForChat = "";
//tmac disconnect by handle type
var disconnectByHandleType = "";
//tmac agent to agent chat obj
var tmacAgentChatObj = [];
var signalRVersion;
var global_AUXCodes;
var global_Intents;
var global_AgentList = [];
var global_FavouriteSkills;
var global_SpeedDial;
var global_WorkCodeList;
var global_TeamID;
var global_TeamName;
var global_AgentName;
var global_UserProfileForAgent;
var global_ChannelCount = [];
var global_AgentFeatures = [];
var global_CallType = "";
var global_transferIntID;
var global_conferenceIntID;
//active tab interaction id
var global_activeTabInteractionID;
//agent status timer counter
var statusTimeCounter = 0;
//agent status obj
var global_LastAgentStat;
var global_agentCamera;
//tmac reload flag
var global_ReloadDone;
//timeout function
var global_timeoutFunctions = [];
var global_LoginRedisplay;
//marquee text reference
var marqueeText = "";
//active tab id for tabstrip select/active event
var active_tab_id = "";
//main tabtrip element
var tabstrip;
//make call tabstrip element
var tabstrip_call;
//trasnfer call tabstrip element
var tabstrip_transfer;
var logout_button_clicked = false;
var call_log_out = false;
//type of agent logged in
var agentType = "";
//transfer notification reference
var transferNotificationRef = [];
//filtered skill for skill list grid
var filterdSkills = [];
//color codes for dashboard
var dashboardColorCodes = [];
//facetouch monitor json
var faceTouchJson = {};
// Global store to hold the agent's events
var global_AllEvents = {};

//  ReviewCodeLine: VP: Jul 2, '20: Remove below 4 in the future. Not required anymore.
//is customer chat
var isCustomerChat = false;
//dummy chat list
var dummyCustomerList = [];
//is form filling
var isFormFilling = false;
//co browsing pages
var forms = [];
//chat whiteboard
var isWhiteboard = false;
//whiteboard url
var whiteboardUrl = "";
//  ReviewCodeLine: VP: Jul 2, '20: Need to implement fully. 
//is tmac tour
var isTour = false;

//---------------------------------------FAX----------------------------------
var global_FaxReference = [];
var faxLineNumbers = [];
var faxInteractionId;

//used for fax ui js
var faxNumberSelect = null;
var faxUploader = [];
var isFaxOutEnabled = false;
var isFaxInternationalEnabled = false;
var isFaxPrintEnabled = false;
var faxItemId = 1;
var faxAddonReference = [];
var faxTemplates = [];
var addCoverPage = false;
var tempAddonTemplate = {};

//---------------------------------------SMS----------------------------------
//used for sms ui js
var smsNumberSelect = null;
var _tempSmsMessage = "";

//----------------------------------------CRM---------------------------------
//  VP : Jul 21, '20: Since this is static, moved it here.
//default is false, value is set from db config after login success
var isCRMEnabled = false;
var QMSPopUpURL = "";
var callbackPopUpURL = "";
var ACWPopUpURL = "";
var agentCRMName;
var MSDChatAcceptPopUpURL = "";
var MSDChatClosePopUpURL = "";
var MSDCallbackAcceptPopUpURL = "";
var MSDCallbackClosePopUpURL = "";
var MSDInboundVoicePopUpURL = "";
var MSDOutboundVoicePopUpURL = "";
//text chat vdn list
var textChatVDNList;
//dbs ibg dnis list
var IBGDNISList;

//----------------------------------------VOICE-------------------------------
//voice reference
var global_VoiceReference = [];
var ivrTransferRef = {};
//WebRtc connection referece for voice interaction
var aConn = [];
//to enable/disable tones
var isToneEnabled = false;
//tone volume range
var toneRange = 50;
//tone audio
let _audio = new Audio();
//tone interval
let _audioInterval = null;
//to send mos value to server or not
let sendMosValue = false;
//  Interaction ID of the Dial pad
var dialPadInteractionId = 0;

//----------------------------------------TEXT CHAT/AUDIO-VIDEO CHAT---------------------------
//chat session reference
var global_ChatReference = [];
//temp intid for chat template
var tempIntIdForChatTemplate;
//chat templates array
var allChatTemplates = [];
//text chat greeting text
var global_TextChatGreetingText;
//text chat callback id
var global_TextChatCallbackID;
global_endTextChatNotification = [];
//audio/video connection object
var avConn = null;
//co-browse connection object
var cbConn = null;
//notification popup reference
var transferNotificationPop = [];
//Used to check if the image has been edited and saved by the user
var isEditedImage = false;
//Used to check if the image is currently being edited for canvas resizing
var editingImage = false;
//image or pdf edit
var editFileType = "";
//auto timer for time taken
var autoTimerForTimeTaken = true;
//for uploaded files
var files = {};
// av confirm popup
let avConfirmPop = null;
//  VP: Sep 18, '20: WebRTC Comm Stats store to send every interval
var avWebRTCCommStats = null;
//----------------------------------------FB----------------------------
//facebook reference
var global_FbReference = [];

//----------------------------------------CALLBACK----------------------------
var hasGetDataEventDetails = false;
var isTextChatCallback = false;

//----------------------------------------DASHBOARD---------------------------
//global agent list dashboard
var globalAgentList = [];

//----------------------------------------Voice Bio---------------------------
//voice bio reference
var global_VBReference = [];

//---------------------------------------POM----------------------------------
var pomCustomerInfoConfig = {};
var global_POMReference = [];
var pomActiveCallInteractionID = "";
var pomRedialNumber = "";

//  --------------------------------------------------------------------------

//---------------------------------------INTERACTION HISTORY----------------------------------
//to open history in new tab
// ReviewCodeLine: VP : Jul 2, '20': Remove below 4 in the future. Not required anymore.
var openInNewTab = false;
//customer journey iframe
var ih_iframe_url = "";
//is custom customer journey
var isCustomerJourney = false;
//get interaction history source [local, signalr]
var interactionHistorySource = "local";

//  --------------------------------------------------------------------------

