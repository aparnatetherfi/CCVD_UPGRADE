// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "serviceNowIntegration.js";
var file_version = "4.0.12.03";
var changedBy = "Chirag R";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

var serviceNowInt = new function () {

    var _this = this;
    function handleCommunicationEvent(context) {
        console.log("Communication from Topframe", context);
    }
    function initSuccess(snConfig) {
        console.log("openframe configuration", snConfig);
        AppConfigs.Remote.CRM.ServiceNow.snConfig = snConfig;
        //register for communication event from TopFrame
        openFrameAPI.subscribe(openFrameAPI.EVENTS.COMMUNICATION_EVENT,
            handleCommunicationEvent);
        openFrameAPI.setTitleIcon(AppConfigs.Remote.CRM.ServiceNow.config.titleIcon);
    }
    function initFailure(error) {
        console.log("OpenFrame init failed..", error);
    }
    window.onload = function () {
        AppConfigs.Remote.CRM.ServiceNow.config.subTitle = global_AgentName + ' (' + global_AgentID + ' - ' + global_DeviceID + ')';
        openFrameAPI.init(AppConfigs.Remote.CRM.ServiceNow.config, initSuccess, initFailure);
    }
    window.addEventListener("TMACEvents", function (e) {
        switch (e.detail.EventName) {
            case "IncomingCallEvent":
                // _this.openServiceNowForm("cti", "sysparm_caller_phone=" + "aaa");
                _this.openServiceNowForm("cti", "sysparm_caller_phone=" + e.detail.PhoneNumber);
                break;
            default: break;
        }
    });

    _this.show = function () {
        openFrameAPI.show();
    }

    _this.hide = function () {
        openFrameAPI.hide();
    }

    _this.isVisible = function (calback) {
        openFrameAPI.isVisible(function (isVisible) {
            if (isVisible) {
                console.log("Frame is visible");
            } else {
                console.log("Frame is not visible");
            }
            calback(isVisible);
        })
    }

    _this.setTitle = function (title) {
        openFrameAPI.setTitle(title);
    }

    _this.setSubTitle = function (subTitle) {
        openFrameAPI.setSubtitle(subTitle);
    }

    _this.setSize = function (size) {
        openFrameAPI.setSize(size);
    }

    _this.setTitleIcon = function (url, title, id) {
        openFrameAPI.setTitleIcon({
            imageURL: url,
            imageTitle: title,
            id: id
        });
    }

    /*[{
        imageURL:'https://mydomian.com/image/mute.png',
        imageTitle:'mute', 
        id:101
    }, {
        imageURL:'https://mydomian.com/image/hold.png',
        imageTitle:'hold', 
        id:102
    }]*/
    _this.setIcons = function (iconsList) {
        openFrameAPI.setIcons(iconsList);
    }

    _this.handleEvent = function (eventName, data) {

    }

    /*openFrameAPI.EVENTS = {
        COLLAPSE: "openframe_collapse"
        COMMUNICATION_EVENT: "openframe_communication"
        COMMUNICATION_FAILURE: "openframe_communication_failure"
        EXPAND: "openframe_expand"
        HEADER_ICON_CLICKED: "openframe_header_icon_clicked"
        ICON_CLICKED: "openframe_icon_clicked"
        OPENFRAME_BEFORE_DESTROY: "openframe_before_destroy"
        OPENFRAME_HIDDEN: "openframe_hidden"
        OPENFRAME_SHOWN: "openframe_shown"
        TITLE_ICON_CLICKED: "openframe_title_icon_clicked"
    }*/
    _this.subscribeEvents = function () {
        for (var key in openFrameAPI.EVENTS) {
            openFrameAPI.subscribe(openFrameAPI.EVENTS[key], function (e) {
                _this.handleEvent(openFrameAPI.EVENTS[key], e)
            });
            //console.log(openFrameAPI.EVENTS[key]);
        }
    }

    /* - example requests
        {
            entity:'customer_account', 
            query:'sys_id=447832786f0331003b3c498f5d3ee452', 
            'interaction_sys_id':'3be092313b711300758ce9b534efc4dd'
        }
        { 
            entity: 'cti', 
            query: 'sysparm_caller_phone=91345015' 
        }
    */
    _this.openServiceNowForm = function (entity, query, interactionId) {
        var data = {};
        data.entity = entity;
        data.query = query;
        if (interactionId) {
            data.interaction_sys_id = interactionId;
        }
        openFrameAPI.openServiceNowForm(data);
    }

    //  !!This API is not supported on Agent Workspace.
    _this.openServiceNowList = function (entity, query) {
        var data = {};
        data.entity = entity;
        data.query = query;
        openFrameAPI.openServiceNowList({ entity: 'case', query: 'active=true' });
    }

    _this.getOpenFrameVersion = function (entity, query) {
        var version = openFrameAPI.version();
        console.log("API version " + version);
        return version;
    }

    // : This API is not supported on Agent Workspace.
    _this.openCustomURL = function (url) {
        openFrameAPI.openCustomURL(url);
    }

    _this.setHeight = function (height) {
        openFrameAPI.setHeight(height);
    }


    _this.setWidth = function (width) {
        openFrameAPI.setWidth(width);
    }


    /*openFrameAPI.FRAME_MODE = {
        COLLAPSE: "collapse"
        EXPAND: "expand"
    }*/
    _this.collapse = function (collapse) {
        let mode = openFrameAPI.FRAME_MODE.EXPAND
        if (collapse) {
            mode = openFrameAPI.FRAME_MODE.COLLAPSE
        }
        openFrameAPI.setFrameMode(mode);
    }

    /*
    state Presence state of the agent.
        Default states:
            Available
            Away
            Offline
        You can also specify custom states.

    color	String	Presence indicator color on workspace.
        Supported colors:
            red
            orange
            grey
            green
    */
    _this.changeStatus = function (status, color) {
        openframeAPI.setPresenceIndicator(status, color);
    }

    /*
        In Agent Workspace, an interaction opens in a parent tab.
        Note: In the platform interface, no action is performed.
    */
    _this.openInteraction = function (interactionSysId) {
        openFrameAPI.openInteraction(interactionSysId);
    }
}
