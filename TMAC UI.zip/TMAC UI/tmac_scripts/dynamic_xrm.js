﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "dynamic_xrm.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

$(document).ready(function () {
    console.log('dynamic xrm loaded');
});

//Chat Start CRM Popup
function DynamicsXRMStartChatPopUpScreen(event) {
    try {
        console.log('Inside - DynamicsXRMStartChatPopUpScreen, text chat incoming');

        //var ApplicantGUID = 'AF7D160B-9B5F-4CAC-B0CC-FA18025C2737';//
        var ApplicantGUID = '0CFB6DAC-150F-4DAA-8ABC-310D41A46CA1';
        log.LogDetails("Info", "DynamicsXRMStartChatPopUpScreen", "ApplicantGUID:[" + ApplicantGUID + "]", false);

        var endpointURL = 'https://dxrmtid.sg.uobnet.com/main.aspx?etc=10028&navbar=off&extraqs=formid%3d544ed25f-3a22-4da3-ac54-e7efc2a6c590&id=%7bGUID%7d&pagetype=entityrecord';

        var xrmURL = endpointURL.replace('GUID', ApplicantGUID);

        log.LogDetails("Info", "DynamicsXRMStartChatPopUpScreen", "popup URL:[" + xrmURL + "]", false);
        
        window.open(xrmURL, "_blank", "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes")

    } catch (ex) {
        log.LogDetails("Error", "DynamicCRM.DynamicsCRMStartChatPopUpScreen()", ex, false);
    }
}

//function captured camera and store to XRM
function OnCameraCapturedPress()
{
    var imagename = 'imageXRM.jpg';

    log.LogDetails("Info", "DynamicsXRMStartChatPopUpScreen", "imagename:[" + imagename + "]", false);
    
    tmac_ExternalConnect_GenericCommand('OnCameraCaptureDone', null, 'XRM', 'dynamic_xrm', 'VideoCaptured', [imagename])
}

function OnCameraCaptureDone(data)
{
    log.LogDetails("Info", "OnCameraCaptureDone", "data:[" + data + "]", false);
    console.log(data);
    if (data == '0') {
        console.log('done camera captured');
    }
    else
    {
        console.log('something went wrong');
    }
        
}

