﻿// Register your Filename and version
// Whenever this file changed, Update the Version of the file.

var filename = "EventHandler.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

//handle events
function HandleEvent(event) {
    if (event.length > 0) {
        for (x = 0; x < event.length; x++) {
            try {
                // VP: Jul 21, '20: Except "WallboardRefreshEvent", store all events as per their interaction ID. If its a generic event, meaning not relating to an interaction, store by index 0 
                if (global_AllEvents[event[x].InteractionID] == null)
                    global_AllEvents[event[x].InteractionID] = [];

                if (event[x].EventName !== "WallboardRefreshEvent" || event[x].EventName === "GenericCTIEvent" && event[x].SubEventName !== "OnPOMPendingCallbacksList")
                    global_AllEvents[event[x].InteractionID].push(event[x]);
            } catch (e) {
                log.LogDetails("Error", "EventDataHandler.HandleEvent().AddToAllEvents", e, false);
            }

            try {
                if (event[x].EventName !== "WallboardRefreshEvent" || event[x].EventName === "GenericCTIEvent" && event[x].SubEventName !== "OnPOMPendingCallbacksList") {
                    if (extraLogs.TMACEventNames)
                        log.LogDetails("Info", "EventHandler.HandleEvent()", event[x].EventName, false);
                    if (extraLogs.TMACEventObjects)
                        log.LogDetails("Info", "EventHandler.HandleEvent()", JSON.stringify(event[x]), false);
                }
                try {
                    window[event[x].EventName](event[x]);
                } catch (e) {
                    //
                }

                HandleEventCustom(event[x]);
                DispatchEvent("TMACEvents", event[x]);
                //  VP: Jul 22, '20: Handle event action
                if (event[x].EventName !== "WallboardRefreshEvent") {
                    HandleEventActions(event[x]);
                }

            } catch (ex) { }
        }
    }
}

function DispatchEvent(eventName, eventData) {
    try {
        //if isDispatchTMACEvents is configured then create event and dispatch it
        if (isDispatchTMACEvents) {
            var evt;
            //check if the Event is supported by browser
            if (typeof Event === "function") {
                // Create the event.
                //event = new Event(eventName);
                //event.detail = event;
                evt = new CustomEvent(eventName, { detail: eventData });
            } else {
                // Create the event.
                evt = document.createEvent('Event');
                // Define the data.
                evt.detail = eventData;
                // Define that the event name is 'event.EventName'.
                evt.initEvent(eventName, true, true);
            }
            // target can be any Element or other EventTarget.
            window.dispatchEvent(evt);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.DispatchEvent()", ex, false);
    }
}


//agent forced log off event
function tmacevent_AgentForcedLogoffEvent(event) {
    try {
        log.LogDetails("Info", "EventHandler.tmacevent_AgentForcedLogoffEvent()", event.Reason, false);
        global_AgentForcedLogoffEventFlag = true;

        //clear local storage TMACdata
        localStorage.removeItem("TMACdata-" + FromEncodedString(getQueryStringValue("ID")));
        //for single page login remove the session storage 'deviceID'
        if (isSinglePageLogin) {
            sessionStorage.removeItem("deviceID");
        }

        if (isVoiceBio) ShowNotLoggedInScreen();

        //check if the logout command is sent
        if (!global_LogoutCommandSend) {
            if (event.Type === "SupervisorInitiatedLogout") {
                LogoffAlert("You are being logged out by the supervisor.", true, 3000);
            } else if (event.Type === "SessionNotFound") {
                LogoffAlert("You are logged out of TMAC as the network connectivity has been lost for an extended period of time. Please re-login!", true, 3000);
            } else {
                LogoffAlert("We are closing this window as you are logged in using another TMAC session!", true, 3000);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentForcedLogoffEvent()", ex, false);
    }
}

//connected to secondary server
function tmacevent_TmacServerConnectionSuccess(event) {
    try {

        //update all the logged in data

        //agent session key
        global_successfullyLoggedInData.data.AgentSessionKey = global_AgentSessionKey;

        //TmacServerName in data (login done event data) and data.Data (agent profile)
        global_successfullyLoggedInData.data.TmacServerName = _tmacServer;
        global_successfullyLoggedInData.data.Data.TmacServerName = _tmacServer;

        //TmacSignalRUrl in data (login done event data) and data.Data (agent profile)
        global_successfullyLoggedInData.data.TmacSignalRUrl = global_TmacSignalRUrl;
        global_successfullyLoggedInData.data.Data.TmacSignalRUrl = global_TmacSignalRUrl;

        //store the TMAC data to local storage, if refresh the page to load the updated data
        localStorage.setItem("TMACdata-" + global_DeviceID, JSON.stringify(global_successfullyLoggedInData));

        TmacServerConnectionSuccessEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TmacServerConnectionSuccess()", ex, false);
    }
}

//agent reminder event
function tmacevent_AgentReminderEvent(event) {
    try {
        if (event.Reminders !== null) {
            event.Reminders = ProcessReminderMessage(event.Reminders);
            globalReminderList = event.Reminders;
            StartReminderThread(event);
            LoadReminderEvent(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentReminderEvent()", ex, false);
    }
}

//create agent reminder event
function tmacevent_CreateAgentReminderEvent(event) {
    try {
        //ResultMessage
        if (event.ResultCode > 0) {
            log.LogDetails("Success", "EventHandler.tmacevent_CreateAgentReminderEvent()", "Reminder successfully created", true);
            LoadAgentReminders("", "", "", "");
        } else
            log.LogDetails("Error", "EventHandler.tmacevent_CreateAgentReminderEvent()", "Reminder creation failed", true);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CreateAgentReminderEvent()", ex, false);
    }
}

//delete agent reminder event
function tmacevent_DeleteAgentReminderEvent(event) {
    try {
        //ResultMessage
        if (event.ResultCode > 0) {
            log.LogDetails("Success", "EventHandler.tmacevent_CreateAgentReminderEvent()", "Reminder successfully deleted", true);
            LoadAgentReminders("", "", "", "");
        } else
            log.LogDetails("Error", "EventHandler.tmacevent_CreateAgentReminderEvent()", "Reminder deletion failed", true);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_DeleteAgentReminderEvent()", ex, false);
    }
}

//agent reminder updated event
function tmacevent_UpdateAgentReminderEvent(event) {
    try {
        //ResultMessage
        if (event.ResultCode > 0) {
            log.LogDetails("Success", "EventHandler.tmacevent_UpdateAgentReminderEvent()", "Reminder successfully updated", true);
            LoadAgentReminders("", "", "", "");
        } else {
            log.LogDetails("Error", "EventHandler.tmacevent_UpdateAgentReminderEvent()", "Reminder update failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_UpdateAgentReminderEvent()", ex, false);
    }
}

//change of agent boradcast messages
function tmacevent_AgentNotificaitonEvent(event) {
    try {
        switch (event.Type) {
            case "Broadcast":
                AgentNotification(event);
                break;
            case "IM":
                agent_chat.chat_received(event);
                break;
            case "InteractionIM":
                AgentNotification(event);
                break;
            case "Info":
                if (event.Message === "LoadInteractionHistory") {
                    var historyLoaderParams = event.JsonData;
                    ProcessInteractionHistoryEvent(JSON.parse(historyLoaderParams), false, "event");
                }
                break;
            case "ProfanityWordsViolation":
                ShowNotification("Profanity Alert", event.Message);
                ShowNotify(event.Message.replaceAll("\n", "<br/>"), "danger", null, "top-center", false);
                break;
            default:
                log.LogDetails("Info", "EventHandler.tmacevent_AgentNotificaitonEvent()", event.Type + " case is not defined..!", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentNotificaitonEvent()", ex, false);
    }
}

function tmacevent_InteractionHistoryReadyEvent(event) {
    try {
        ProcessInteractionHistoryEvent(event.HistoryParameters, false, "event");
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_InteractionHistoryReadyEvent()", ex, false);
    }
}

//agent status changed
function tmacevent_AgentStatusChangeEvent(event) {
    try {
        //update the status list with new status
        AgentStatusChange(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentStatusChangeEvent()", ex, false);
    }
}

//ivr transfer aux wait timer elapsed
function tmacevent_AUXTimerEvent(event) {
    try {
        //show aux timer expired dialog
        ShowNotify("Aux timer expired", "warning", null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AUXTimerEvent()", ex, false);
    }
}

//AES Status Event
function tmacevent_AESStatusEvent(event) {
    try {
        if (event.Status === "Failed") {
            log.LogDetails("Error", "EventHandler.tmacevent_AESStatusEvent()", "There has been a glitch at the AES level and hence your current tab might not work. " +
                "Kindly use your hardphone to complete the call", true);
        } else if (event.Status === "Reconnected") {
            log.LogDetails("Success", "EventHandler.tmacevent_AESStatusEvent()", "The AES level glitch has been resolved. Enjoy seamless TMAC usage!", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AESStatusEvent()", ex, false);
    }
}

//MS Status Event
function tmacevent_MSStatusEvent(event) {
    try {
        if (event.Status === "Failed") {
            //log.LogDetails("Error", "EventHandler.tmacevent_MSStatusEvent()", "There has been a glitch at the Media Server level and hence you will be moved to AUX status", true);
            log.LogDetails("Error", "EventHandler.tmacevent_MSStatusEvent()", "There has been a glitch at the Media Server level, please wait until its resolved!", true);
            //fail can happen after making call or during ringing, so clear the tone
            ClearTone();
            //apply the style
            $("#agent_type_li").addClass("not-ms-agent");
        } else if (event.Status === "Reconnected") {
            log.LogDetails("Success", "EventHandler.tmacevent_MSStatusEvent()", "The Media Server level glitch has been resolved. Enjoy seamless TMAC usage!", true);
            //remove the style
            $("#agent_type_li").removeClass("not-ms-agent");
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_MSStatusEvent()", ex, false);
    }
}

//incoming call
function tmacevent_IncomingCallEvent(event) {
    try {
        let subType = event.SubType ? event.SubType.toLowerCase() : "";
        switch (subType) {
            case "pom":
                POMIncomingVoiceCall(event);
                break;
            default:
                IncomingVoiceCall(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_IncomingCallEvent()", ex, false);
    }
}

//call connected event
function tmacevent_CallConnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallConnectedEvent(event);
                break;
            default:
                VoiceCallConnectedEvent(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallConnectedEvent()", ex, false);
    }
}

//call disconnected
function tmacevent_CallDisconnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallDisconnectedEvent(event);
                break;
            default:
                VoiceCallDisconnectedEvent(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallDisconnectedEvent()", ex, false);
    }
    //close the tab on outgoing call
    //CloseOutgoingVoiceTab(event);
}

//voice call initiating
function tmacevent_VoiceCallInitiatingEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid) ? GetTabReferenceObj(intid).type.toLowerCase() : "";
        switch (tabType) {
            case "pom":
                POMVoiceCallInitiating(event);
                break;
            default:
                VoiceCallInitiating(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_VoiceCallInitiatingEvent()", ex, false);
    }
}

//outgoing call created
function tmacevent_OutgoingCallEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid) ? GetTabReferenceObj(intid).type.toLowerCase() : "";
        switch (tabType) {
            case "pom":
                POMVoiceOutgoingCallEvent(event);
                break;
            default:
                VoiceOutgoingCallEvent(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_OutgoingCallEvent()", ex, false);
    }
}

//call transfer initiated
function tmacevent_CallTransferInitiatedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallTransferInitiatedEvent(event);
                break;
            default:
                VoiceCallTransferInitiatedEvent(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallTransferInitiatedEvent()", ex, false);
    }
}

//call transfer remote party answered the call
function tmacevent_CallTransferRemoteConnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallTransferRemoteConnected(event);
                break;
            default:
                //enable complete, cancel buttons on transfer window
                VoiceCallTransferRemoteConnected();
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallTransferRemoteConnectedEvent()", ex, false);
    }
}

//call transfered line disconnected
function tmacevent_CallTransferLineDisconnectEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallTransferLineDisconnectEvent(event);
                break;
            default:
                TransferLineDisconnected(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallTransferLineDisconnectEvent()", ex, false);
    }
}

//call conference initiated
function tmacevent_CallConferenceInitiatedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMConferenceInitiated(event);
                break;
            default:
                ConferenceInitiated(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallConferenceInitiatedEvent()", ex, false);
    }
}

//call conference remote party connected
function tmacevent_CallConferenceRemoteConnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMConferenceRemoteConnected(event);
                break;
            default:
                ConferenceRemoteConnected(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallConferenceRemoteConnectedEvent()", ex, false);
    }
}

//call conference completed
function tmacevent_CallConferenceCompletedEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMConferenceCompleted(event);
                break;
            default:
                ConferenceCompleted(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallConferenceCompletedEvent()", ex, false);
    }
}

//call conference line disconnect
function tmacevent_CallConferenceLineDisconnectEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMConferenceLineDisconnected(event);
                break;
            default:
                ConferenceLineDisconnected(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallConferenceLineDisconnectEvent()", ex, false);
    }
}

//call went onhold
function tmacevent_CallHoldEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallHoldEvent(event);
                break;
            default:
                SetCallControlStatus(event.InteractionID, false, false, false, true, false, false, false, false, false);
                ChangeTabReferenceStatus(event.InteractionID, 'CallHold');
                //get the voice reference
                let voiceRef = GetVoiceReferenceObj(intid);
                //check if the voice transfer and subtype is webrtc then call blind transfer
                if (voiceRef && voiceRef.subType === "webrtc") {
                    //get the session id
                    let sessionId = voiceRef.msSessionId;
                    //get the connection by sessionId
                    let getCon = GetAConnRef(sessionId);
                    //change the isHold reference to true
                    getCon.isHold = true;
                }
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallHoldEvent()", ex, false);
    }
}

//hold timer event
function tmacevent_HoldTimerEvent(event) {
    try {
        let callType = "";
        let type = "";
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        let formattedHoldTime = moment.utc(event.HoldTimeSeconds * 1000).format('HH:mm:ss');
        if (tabType === "voice") {
            callType = "Call";
        } else if (tabType === "chat") {
            callType = "Chat";
        }
        //show hold blink for the tab
        $("#li_" + intid).addClass("blink_hold");
        setTimeout(function () {
            //remove it once it blinked and add it on next alert
            $("#li_" + intid).removeClass("blink_hold");
        }, 5000);

        if (event.HoldTimeSeconds >= 60 && event.HoldTimeSeconds < 120)
            type = "";
        else if (event.HoldTimeSeconds >= 120 && event.HoldTimeSeconds < 180)
            type = "info";
        else if (event.HoldTimeSeconds >= 180 && event.HoldTimeSeconds < 240)
            type = "warning";
        else if (event.HoldTimeSeconds >= 240)
            type = "danger";
        ShowNotify(callType + " on hold for " + formattedHoldTime, type, null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_HoldTimerEvent()", ex, false);
    }
}

//call reconnected from hold
function tmacevent_CallHoldReconnectEvent(event) {
    try {
        let intid = event.InteractionID;
        let tabType = GetTabReferenceObj(intid).type.toLowerCase();
        switch (tabType) {
            case "pom":
                POMVoiceCallHoldReconnectEvent(event);
                break;
            default:
                SetCallControlStatus(event.InteractionID, false, true, true, true, true, true, false, true, true);
                ChangeTabReferenceStatus(event.InteractionID, 'CallConnected');
                //get the voice reference
                let voiceRef = GetVoiceReferenceObj(intid);
                //check if the voice transfer and subtype is webrtc then call blind transfer
                if (voiceRef && voiceRef.subType === "webrtc") {
                    //get the session id
                    let sessionId = voiceRef.msSessionId;
                    //get the connection by sessionId
                    let getCon = GetAConnRef(sessionId);
                    //change the isHold reference to true
                    getCon.isHold = false;
                }
        }
        //startBlinking(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CallHoldReconnectEvent()", ex, false);
    }
}

//outgoing call UCID
function tmacevent_OutgoingCallUCIDEvent(event) {
    if (isDynamicCRMEnabled) DynamicsCRMStartVoicePopUpScreen(event, false);
}

//ccl data recevied
function tmacevent_CCLDataEvent(event) {
    try {
        //bind data to customer details area
        SetCCLData(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_CCLDataEvent()", ex, false);
    }
}

//interaction history received
function tmacevent_InteractionHistoryEvent(event) {
    try {
        //bind interaction history to tab
        if (!isACWQMSCRMEnabled) {
            SetInteractionHistory(event);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_InteractionHistoryEvent()", ex, false);
    }
}

//more interaction history received
function tmacevent_MoreInteractionHistoryEvent(event) {
    //bind interaction history to tab
    SetInteractionHistoryMore(event);
}

//intercation historty on demand received
function tmacevent_InteractionHistoryOnDemandEvent(event) {
    SetInteractionHistory(event);
}

//IVR data received
function tmacevent_IVRDataEvent(event) {
    if (isCRMEnabled && isDynamicCRMEnabled)
        QMSCRMPopup(event);

    //bind ivr data to tab
    SetIVRData(event);
}

//UUI data recevied
function tmacevent_UUIDataEvent(event) {
    //bind UUI data to cusotmer details area
    SetUUIData(event);
}

//wallboard refresh
function tmacevent_WallboardRefreshEvent(event) {
    //refresh wallboard
    RefreshWallboard(event);
}

//Caller intent data
function tmacevent_CallerIntentEvent(event) {
    CallerIntentReceived(event);
}

//incoming Chat
function tmacevent_TextChatIncomingEvent(event) {
    //creat chat tab
    //amacTextChatUI.js
    TextChatNewChatReceived(event);

}

//textchat remote user connected
function tmacevent_TextChatRemoteUserConnectedEvent(event) {
    try {
        if (isCallback) {
            HandleCallback(event);
        }
        TextchatRemoteUserConnected(event);
        ChangeTabReferenceStatus(event.InteractionID, 'CallConnected');
        if (isDynamicCRMEnabled) DynamicsCRMStartChatPopUpScreen(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatRemoteUserConnectedEvent()", ex, false);
    }
}

//text chat disconnected
function tmacevent_TextChatDisconnectedEvent(event) {
    try {
        global_CallType = "";
        if (event.ConferenceType !== "silent") {
            if (event.Reason === "RemoteEndClosed") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " disconnected by Customer", true);
            } else if (event.Reason === "AgentChatDisconnected") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " disconnected by Agent", true);
            } else if (event.Reason === "AgentChatTransferCompleted") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " transferred to Agent successfully", true);
            } else if (event.Reason === "AgentInitiatedCallback") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " disconnected by Agent - Initiated Callback", true);
            } else if (event.Reason === "CustomerInitiatedCallback") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " disconnected by Customer - Initiated Callback", true);
            } else if (event.Reason === "QueueTransferCompleted") {
                log.LogDetails("Info", "EventHandler.tmacevent_TextChatDisconnectedEvent()", disconnectChatLabel + " transferred to Queue successfully", true);
            }
        }
        TextChatDisconnectedCustom(event);
        TextChatDisconnected(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatDisconnectedEvent()", ex, false);
    }
}

//text chat message sent
function tmacevent_TextChatMessageSentEvent(event) {
    try {
        FormatSentTextChat(event, false);
        TextChatMessageSent(event, false);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatMessageReceivedEvent()", ex, false);
    }
}

//text chat message sent
function tmacevent_TextChatMessageTemplateSentEvent(event) {
    try {
        FormatSentTextChat(event, true);
        TextChatMessageSent(event, true);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatMessageTemplateSentEvent()", ex, false);
    }
}

//text chat message received
function tmacevent_TextChatMessageReceivedEvent(event) {
    try {
        TextChatMessageReceived(event.ConferenceType, event.IsAppMessage, event.Message, event.EventId, event.InteractionID, "");
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatMessageReceivedEvent()", ex, false);
    }
}

//text chat av message received
function tmacevent_AVControlMessageReceivedEvent(event) {
    try {
        AVControlMessageReceived(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AVControlMessageReceivedEvent()", ex, false);
    }
}

//text chat failure 
function tmacevent_TextChatFailureEvent(event) {
    try {
        //event
        //tmac_text_chat_ui.js
        TextChatFailure(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatFailureEvent()", ex, false);
    }
}

//text chat transfer notification
function tmacevent_TextChatTransferNotificationEvent(event) {
    try {
        GetResponseFromAgent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatTransferNotificationEvent()", ex, false);
    }
}

//remote agent accpeted/rejected the text chat transfer requset
function tmacevent_TextChatTransferNotificationResponseEvent(event) {
    try {
        let intid = event.InteractionID;
        //to enable the transfer button

        var obj = {};
        if (global_CallType === "TextChatTransfer") {
            obj.buttonId = "#btndialogtransfercall";
            obj.icon = "swap_horiz";
            obj.type = "TextChatTransfer";
        } else if (global_CallType === "TextChatConference") {
            obj.buttonId = "#btnConfMCall";
            obj.icon = "call_split";
            obj.type = "TextChatConference";
        }
        obj.intId = intid;
        //check the response message
        if (event.Response === "Accept") {
            //accept
            //transfer the call to FromAgentID
            //if (event.IsNonVoiceRouting) {
            let agentid = event.FromAgentID,
                lineid = event.LineID,
                //eventData = event.EventData,
                otherData = JSON.parse(event.Data),
                chatMode = otherData.mode; //GetChatReferenceObj(intid).chatMode;
            TransferTextChatToServer(global_DeviceID, global_AgentID, intid, event.FromAgentID, "", global_UCID[intid], agentid, lineid, event.FromAgentTmacServer, otherData.type, chatMode, obj);
            //}
            //else {
            //    TransferCallCommand(global_DeviceID, intid, event.FromAgentID, "", obj);
            //}
        } else {
            let otherData = JSON.parse(event.Data);
            //reject
            log.LogDetails("Warning",
                "EventHandler.tmacevent_TextChatTransferNotificationResponseEvent()",
                event.FromAgentName + " has rejected your " + (otherData.type === "conf" ? "conference" : "transfer") + " request" + (event.Comment !== "" ? " with comment: " + event.Comment : ""),
                true);
            //enable the transfer button
            EnableButton(obj.buttonId, obj.icon, "icon");
        }
        //remove the notification sent reference
        RemoveTransferNotificationRef(intid);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatTransferNotificationResponseEvent()", ex, false);
    }
}

//callback popup
function tmacevent_ScreenPopEvent(event) {
    try {
        //load the popup
        PopUpScreen(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_ScreenPopEvent()", ex, false);
    }
}

//text chat user requested callback
function tmacevent_TextChatUserRequestedCallbackEvent(event) {
    try {
        //user requested for callback
        //put the agent to acw
        //disconnect the call
        if (event.Status === true) {
            ChangeStatus(global_DeviceID, 'acw', '0');
            global_endTextChatNotification[event.InteractionID] = true;
            EndTextChat(global_DeviceID, event.InteractionID, true, "CustomerInitiatedCallback");
        } else {
            ShowNotify("TextChatUserRequestedCallback register failed", "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatUserRequestedCallbackEvent()", ex, false);
    }
}

//text chat typing status
function tmacevent_TextChatTypingStateChangedEvent(event) {
    try {
        let intid = event.InteractionID;
        let typingUser = event.User;
        if (typingUser === "0")
            GetChatReferenceObj(intid).typingUser = GetChatReferenceObj(intid).customerName ? GetChatReferenceObj(intid).customerName : "Customer";
        else
            GetChatReferenceObj(intid).typingUser = event.AgentName;

        if (event.Status === 0) {
            GetChatReferenceObj(intid).isTyping = true;
            AddTypingDiv(intid);
        } else {
            GetChatReferenceObj(intid).isTyping = false;
            RemoveTypingDiv(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatTypingStateChangedEvent()", ex, false);
    }
}

//text chat user message for bargein
function tmacevent_TextChatUserMessageForBargeinEvent(event) {
    try {
        //amacUI.js
        BargeInDisplay(event.Message, event.InteractionID, event.AgentID, true);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatUserMessageForBargeinEvent()", ex, false);
    }
}

//text chat agent message for bargein
function tmacevent_TextChatAgentMessageForBargeinEvent(event) {
    try {
        //amacUI.js
        BargeInDisplay(event.Message, event.InteractionID, event.AgentID, false);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatAgentMessageForBargeinEvent()", ex, false);
    }
}

//text chat transcript for transfer
function tmacevent_TextChatTranscriptForTransferEvent(event) {
    try {
        // is a list of text chat transcript message
        //items - TextChatTranscriptAgentMessageForTransfer & TextChatTranscriptUserMessageForTransfer
        // Agent Msg - DateTime, AgentName, AgentID, Message
        // User Msg - DateTime, Message
        //amacTextChatUI.js
        DisplayTextTranscript(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatTranscriptForTransferEvent()", ex, false);
    }
}

//text chat agent connected
function tmac_TextChatAgentConnectedEvent(event) {
    try {
        TextChatAgentConnected(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmac_TextChatAgentConnectedEvent()", ex, false);
    }
}

//text chat agent disconnected
function tmac_TextChatAgentDisconnectedEvent(event) {
    try {
        TextChatAgentDisconnected(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmac_TextChatAgentDisconnectedEvent()", ex, false);
    }
}

//text chat agent message received
function tmac_TextChatAgentMessageReceivedEvent(event) {
    try {
        //tmac_text_chat_ui.js
        TextChatMessageReceived(event.ConferenceType, event.IsAppMessage, event.Message, event.EventId, event.InteractionID, event.AgentName);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmac_TextChatAgentMessageReceivedEvent()", ex, false);
    }
}

//Generic Interaction Event
function tmacevent_GenericInteractionEvent(event) {
    try {
        GenericInteraction(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_GenericInteractionEvent()", ex, false);
    }
}

//Voice Bio Call Connected Event
function tmacevent_VBCallConnectedEvent(event) {
    try {
        VoiceBioCallConnected(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_GenericInteractionEvent()", ex, false);
    }
}

//Voice Bio Call Disconnected Event
function tmacevent_VBCallDisconnectedEvent(event) {
    try {
        VoiceBioCallDisconnected(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_VBCallDisconnectedEvent()", ex, false);
    }
}

//Voice Bio Status Change Event
function tmacevent_VBStatusEvent(event) {
    try {
        VoiceBioStatusChange(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_VBStatusEvent()", ex, false);
    }
}

//Voice Bio NRIC Event
function tmacevent_VBNRICEvent(event) {
    try {
        VoiceBioNRICEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_VBNRICEvent()", ex, false);
    }
}

//New fax received event
function tmacevent_FaxReceivedEvent(event) {
    try {
        NewFaxReceived(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_FaxReceivedEvent()", ex, false);
    }
}

//Generic cti events
function tmacevent_GenericCTIEvent(event) {
    try {
        HandleGenericCTIEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_GenericCTIEvent()", ex, false);
    }
}

//Generic call events
function tmacevent_GenericCallEvent(event) {
    try {
        HandleGenericCallEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_GenericCallEvent()", ex, false);
    }
}

//Generic tmac events
function tmacevent_GenericTMACEvent(event) {
    try {
        HandleGenericTMACEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_GenericTMACEvent()", ex, false);
    }
}

//campaign direct agent notification
function tmacevent_TCM_DirectAgentNotifyEvent(event) {
    try {
        DirectAgentNotifyEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TCM_DirectAgentNotifyEvent()", ex, false);
    }
}

//campaign direct agent notify timeout
function tmacevent_TCM_DirectAgentNotifyTimeoutEvent(event) {
    try {
        DirectAgentNotifyTimeoutEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TCM_DirectAgentNotifyTimeoutEvent()", ex, false);
    }
}

//text chat user message wait timer
function tmacevent_TextChatUserMessageWaitTimerEvent(event) {
    try {
        TextChatWaitTimerEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_TextChatUserMessageWaitTimerEvent()", ex, false);
    }
}

//another agent transfered the call
function tmacevent_AnotherAgentTransferedCallToMeEvent(event) {
    //do nothing
}

//auto close tab
function tmacevent_AutoCloseTabEvent(event) {
    try {
        CloseUITab(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AutoCloseTabEvent()", ex, false);
    }
}

//interaction transfer notification event
function tmacevent_InteractionTransferNotificationEvent(event) {
    try {
        GetTransferResponseFromAgent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_InteractionTransferNotificationEvent()", ex, false);
    }
}

//interaction transfer notification response event
function tmacevent_InteractionTransferResponseEvent(event) {
    try {
        TransferResponseReceived(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_InteractionTransferNotificationEvent()", ex, false);
    }
}

//tmac agent event
function tmac_AgentUIUpdateEvent(event) {
    try {
        // check if there  is SubEventName else return
        if (!event.SubEventName) {
            return;
        }

        // get the data
        let data = event.JsonData;

        // switch the SubEventName
        switch (event.SubEventName) {
            case "AUXCodeUpdateEvent":
                global_AUXCodes = JSON.parse(data);
                RemoveNameFromList(global_AUXCodes, "Logout", 110);
                RemoveNameFromList(global_AUXCodes, "ACW", 111);
                LoadAuxDiv(global_AUXCodes, global_CurrentStatus.toLowerCase());
                log.LogDetails("Success", "EventHandler.tmac_AgentUIUpdateEvent()", "AUX Codes reloaded successfully", true);
                break;
            case "MSStatusEvent":
                if (data === "Failed") {
                    log.LogDetails("Error", "EventHandler.tmac_AgentUIUpdateEvent()", "There has been a glitch at the Media Server level and hence your current call will be dropped!", true);
                    //disable all the call controls
                    SetCallControlStatus(event.InteractionID, false, false, false, false, false, false, isEnableCloseTabOnDisconnect.Voice, false);
                    //fail can happen after making call or during ringing, so clear the tone
                    ClearTone();
                } else {
                    log.LogDetails("Success", "EventHandler.tmac_AgentUIUpdateEvent()", "The Media Server level glitch has been resolved", false);
                }
                break;
            case 'UIConfigsUpdateEvent':
                log.LogDetails("Info", "EventHandler.tmac_AgentUIUpdateEvent()", "TMAC Settings are modified. Re-login to load the changes", true);
                break;
            default:
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmac_AgentUIUpdateEvent()", ex, false);
    }
}

//tmac agent ACW timeout event
function tmac_AgentTimedACWEvent(event) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmac_AgentTimedACWEvent()", ex, false);
    }
}

//tmac agent command event
function tmacevent_AgentCommandEvent(event) {
    try {
        if (event) {
            switch (event.Name) {
                case "TransferNotificationExpired":
                    //check if the notification pop is opened for any agents then close it
                    let pop = transferNotificationPop.filter(function (a) { return a.from === event.FromAgentId; });
                    if (pop.length > 0) {
                        pop[0].tPop.hide();
                        transferNotificationPop = transferNotificationPop.filter(function (t) { return t.from !== event.FromAgentId; });
                    }
                    break;
                default:
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentCommandEvent()", ex, false);
    }
}

//tmac interaction close event
function tmacevent_InteractionClosedEvent(event) {
    try {
        CloseUITab(event.InteractionID, null);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_InteractionClosedEvent()", ex, false);
    }
}

//tmac media server event
function tmacevent_MediaServerEvent(event) {
    try {
        MediaServerEventReceived(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_MediaServerEvent()", ex, false);
    }
}

//tmac agent av message event
function tmacevent_AgentAVMessageEvent(event) {
    agent_chat_av.avMessageReceived(event);
}

//tmac agent setting updated event
function tmacevent_AgentSettingsUpdatedEvent(event) {
    try {
        let agentData = JSON.parse(event.JsonData);
        AssignAgentData(agentData, true);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.tmacevent_AgentSettingsUpdatedEvent()", ex, false);
    }
}

function tmac_ActionMessageReceivedEvent(event) {
    try {
        let message = JSON.parse(event.Message);
        switch (message.type.toLowerCase()) {
            case "sign":
                break;
            case "cobrowse":
                if (message.status === "reject")
                    log.LogDetails("Warning", "EventHandler.tmac_ActionMessageReceivedEvent()", "Co-browse request denied.", true);
                break;
            case "snapshot":
                var msg = JSON.parse(event.Message);
                snapshotReceivedFromRemote(msg, msg.data.interactionId);
                break;
            default:
        }
    } catch (e) {
        log.LogDetails("Error", "EventHandler.tmac_ActionMessageReceivedEvent()", e, false);
    }
}

function tmac_InteractionConvertedEvent(event) {
    try {
        //  If success, don't allow to convert again
        if (event.Status == 0) {
            FadeOutButton("#btnTextChat_Convert" + event.InteractionID);
            log.LogDetails("Success", "EventHandler.tmac_ActionMessageReceivedEvent()", "Interaction conversion successful.", true);
        } else {
            //  If fail, enable the button
            FadeInButton("#btnTextChat_Convert" + event.InteractionID);
            log.LogDetails("Error", "EventHandler.tmac_ActionMessageReceivedEvent()", "Interaction conversion failed.", true);
        }
    } catch (e) {
        log.LogDetails("Error", "EventHandler.tmac_ActionMessageReceivedEvent()", e, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
//Custom Events
//----------------------------------------------------------------------------------------------------------------
//load cif value
function Custom_LoadCIFEvent(event) {
    try {
        //amacTextChatUI.js
        loadCIFValue(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_LoadCIFEvent()", ex, false);
    }
}

//load ucid chat to callback
function Custom_LoadUCIDChatToCallbackEvent(event) {
    try {
        //amacTextChatUI.js
        loadUCIDChatToCallback(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_LoadUCIDChatToCallbackEvent()", ex, false);
    }
}

//update ucid chat to callback
function Custom_UpdateUCIDChatToCallbackEvent(event) {
    //amacTextChatUI.js
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_UpdateUCIDChatToCallbackEvent()", ex, false);
    }
}

//get va sessionid for callback
function Custom_GetVASessionIDForCallbackEvent(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        if (isDynamicCRMEnabled) DynamicsCRMStartCallbackPopUpScreen(event.InteractionID, parse.cif, parse.chatsessionid, parse.sessionid);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetVASessionIDForCallbackEvent()", ex, false);
    }
}

//get queue time color code
function Custom_GetQueueTimeColorCodeEvent(event) {
    try {
        SetColorCodes(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetQueueTimeColorCodeEvent()", ex, false);
    }
}

//get ucid for the current callerid
function Custom_GetTextChatDataEvent(event) {
    try {
        GetTextChatData(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetTextChatDataEvent()", ex, false);
    }
}

//get details for cif
function Custom_GetDetailsForCIFEvent(event) {
    try {
        SetUserData(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetDetailsForCIFEvent()", ex, false);
    }
}

//close request
function Custom_CloseRequestEvent(event) {
    try {
        CloseRequest(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_CloseRequestEvent()", ex, false);
    }
}

//submit schedule callback
function Custom_submitScheduleCallbackEvent(event) {
    try {
        ScheduleCallbackComplete(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_submitScheduleCallbackEvent()", ex, false);
    }
}

//update dial datetime for callback
function Custom_updateDialDateTimeForCallbackEvent(event) {
    //do nothing
}

//get details for sr no 
function Custom_GetDetailsForSrnoEvent(event) {
    try {
        SetUserData(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetDetailsForSrnoEvent()", ex, false);
    }
}

//update va sessionid for text chat 
function Custom_UpdateVasessionIdForTextChatEvent(event) {
    //do nothing
}

//iserver start
function Custom_iServerStartEvent(event) {
    try {
        if (isCRMEnabled === 0) {
            return;
        }
        if (agentCRMName !== "iServe") {
            return;
        }
        var url = iServeUrl + event.JsonData;
        window.open(url);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_iServerStartEvent()", ex, false);
    }
}

//queuetime for blind transfer call
function Custom_GetQueueTimeForUCIDEvent(event) {
    try {
        GetQueueTimeForUCID(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetQueueTimeForUCIDEvent()", ex, false);
    }
}

//text chat CSAT survey event
function Custom_TextChatCSATSurveyEvent(event) {
    try {
        TextChatCSATSurvey(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_TextChatCSATSurveyEvent()", ex, false);
    }
}

//callback status change
function Custom_ddlStatusChangeEvent(event) {
    try {
        //amacUI.js
        SetddlStatusChangeValues(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_ddlStatusChangeEvent()", ex, false);
    }
}

//callback submit click
function Custom_submitEvent(event) {
    try {
        //amacUI.js
        SetSubmitValues(event);
        custom_TextChatCallbackSubmit(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_submitEvent()", ex, false);
    }
}

//callback get details for grid
function Custom_GetDetailsEvent(event) {
    try {
        //amacUI.js
        SetCallbackDetailGridValues(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetDetailsEvent()", ex, false);
    }
}

//get vdn list
function Custom_GetVDNListEvent(event) {
    try {
        //amacUI.js
        GetVDNList(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetVDNListEvent()", ex, false);
    }
}

//get details for ucid
function Custom_GetDetailsForUCIDEvent(event) {
    try {
        //amacUI.js
        SetUserData(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetDetailsForUCIDEvent()", ex, false);
    }
}

//get popup url
function Custom_GetPopUpURLEvent(event) {
    try {
        //tmac_ui.js
        GetPopUpURL(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetPopUpURLEvent()", ex, false);
    }
}

//text chat callback received
function Custom_TextChatCallbackReceivedEvent(event) {
    try {
        //voice_ui.js
        TextChatCallBackEvent(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_TextChatCallbackReceivedEvent()", ex, false);
    }
}

//text chat callback received
function Custom_TextChatCallbackReceivedEvent1(event) {
    try {
        //amacTextChatUI.js
        GetTextChatCallbackDetails(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_TextChatCallbackReceivedEvent1()", ex, false);
    }
}

//load va chat history
function Custom_LoadVAChatHistoryEvent(event) {
    try {
        LoadVAChatHistoryChatBox(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_LoadVAChatHistoryEvent()", ex, false);
    }
}

//get ucid for the current callerid
function Custom_GetDataEvent(event) {
    try {
        //amacUI.js
        Getdata(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_GetDataEvent()", ex, false);
    }
}

//load chat templates
function Custom_LoadChatTemplatesEvent(event) {
    try {
        //amacTextChatUI.js
        loadChatTemplateGrid(event);
    } catch (ex) {
        log.LogDetails("Error", "EventHandler.Custom_LoadChatTemplatesEvent()", ex, false);
    }
}

function tmacevent_TextChatMessageEvent(event) {
    try {
        let data = JSON.parse(event.Data);
        let fobiddenWords = [];
        for (var k in data) {
            fobiddenWords.push(k);
        }
        let html = '<span class="has-profanity"><span class="material-icons">block</span><b>Message cannot be sent due to the following: <br/>' + fobiddenWords.join(', ') + ' </b></span>';
        let messageId = "li_agent_text_" + event.InteractionID + "_" + event.MessageId;
        $("#" + messageId).append(html);

        //chat box div element
        let elem = document.getElementById("divTxtChatTranscript" + event.InteractionID);
        //scroll to top after appening the message div
        elem.scrollTop = elem.scrollHeight;
    } catch (ex) {
        log.LogDetails("Error", "event_handler.tmacevent_TextChatMessageEvent()", ex, false);
    }
}