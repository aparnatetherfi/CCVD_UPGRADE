﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "MainUI.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

//before Page Unload
function beforePageUnload() {
    try {
        //  VP: Sep 21, '20: Send all AV WebRTC stats.
        avWebRTCCommStats.send(false);

        call_log_out = false;
        if (logout_button_clicked)
            call_log_out = false;
        else if (global_AgentForcedLogoffEventFlag)
            call_log_out = false;
        else {
            call_log_out = true;
            return 'Are you sure you want to Logout?';
        }
    } catch (ex) {
        //
    }
};

//page Unload
function onPageUnload() {
    try {
        //  VP: Sep 21, '20: Send all AV WebRTC stats.
        avWebRTCCommStats.send(true);

        if (call_log_out && isLogoutOnClose) {
            Logout(global_DeviceID);
        }
    } catch (ex) {
        //
    }
}

//register beforunload and unload during page ready
$(function () {
    $(window).bind('beforeunload', beforePageUnload);
    $(window).bind('unload', onPageUnload);
});

//document ready 
$(document).ready(function () {
    console.log('main ui loaded');
    //route to login page if mainscreem page is opned directly when isSinglePageLogin is false
    if (!isSinglePageLogin && !opener && !isVoiceBio) {
        $(".an-loader").addClass("uk-display-none");
        let message = "Single page login is not enabled, routing to Login page..";
        setTimeout(function () {
            UIkit.modal.blockUI('<div class=\'uk-text-center\'>' + message + '<br/><img class=\'uk-margin-top\' src=\'assets/img/spinners/spinner.gif\' alt=\'\'>');
            setTimeout(function () {
                location.replace("Login.aspx");
            }, 2000);
        }, 1000);
    }
    if (isVoiceBio) {
        let getAgentId = getQueryStringValue("agentid");
        if (getAgentId === "") {
            while (getAgentId === null || getAgentId === "") {
                getAgentId = prompt("Please enter agent id");
            }
        }
        Login("", "autodiscover", getAgentId, false, "", "");
    }
    else {
        DocumentReady();
        TriggerResize();
    }
});

function DocumentReady() {
    try {
        // get the color code for dashboard
        tmac_GetDashboardColorCodes(function (data, obj) {
            dashboardColorCodes = data;
        }, null);
        //resize the page content size according to the screensize
        SetHeight();
        //resize the tab size according to the screensize
        SetTabHeight();
        //get login data opener
        //if isVoiceBio get from same window
        //if isSinglePageLogin get from parent as login page is a iframe inside mainscreen
        //else get from opener as login window is opening mainscreen
        let loginData = GetLoginData();
        //let loginData = getSuccessfullyLoggedInData();
        if (loginData) {
            //  VP: Jul 9, '20: Set remote configs and assign to old global vars
            if (Object.keys(global_successfullyLoggedInData).length === 0) {
                let configElement = new ConfigElement();
                let loadSuccess = false;
                if (loginData.data.OtherData != null && loginData.data.OtherData.ItemOne !== "")
                    loadSuccess = configElement.LoadRemote(JSON.parse(loginData.data.OtherData.ItemOne), 1);
                else if (isConfigSourceLocal)
                    loadSuccess = configElement.LoadRemote(null, 1);
                else
                    log.LogDetails("Error", "MainUI.DocumentReady", "loginData.data.OtherData from local storage is null.", false);

                if (!loadSuccess) {
                    ShowNotify("Remote Configurations failed to load.", "danger", null, "top-center");
                    return;
                }
            }
            //  VP: Jul 22, '20: handle event for actions
            HandleEventActions(loginData.data);

            global_successfullyLoggedInData = loginData;
            //after successful login
            SuccessfullyLoggedIn(loginData);
            //initialise all the tabs
            LoadInitialTabs();
            //initialise all the kendo window dialogs
            LoadDialogUtils();
            //custom configurations
            Configurations();
            //initialise the wallboard
            LoadWallboardGrid();
            //initalise the remider grid if enabled
            LoadReminderGrid();
            //initialise utility functions
            UtilFunctions();
            //remove login iframe after login success
            if (isSinglePageLogin) {
                $("#login_iframe").remove();
            }
            //show main page content for animation effect
            $(".an-loader").addClass("uk-display-none");
            $("#header_main").removeClass("uk-display-none");
            $("#page_content").removeClass("uk-display-none");
            $("#footer").removeClass("uk-display-none");
            if (isFullTMAC)
                $("#sidebar_main").removeClass("uk-display-none");
            if (isVoiceBio) {
                ResizeWindow(true);
            }
            //set timer for status change
            SetTimer();
        }
        else if (!isSinglePageLogin) {
            $(".an-loader").addClass("uk-display-none");
            log.LogDetails("Error", "MainUI.DocumentReady()", "Login data not found, Please relogin!", true);
            setTimeout(function () {
                window.close();
                if (isSinglePageLogin) location.reload();
            }, 3000);
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.DocumentReady()", ex, false);
    }
}

function GetLoginData() {
    try {
        let id = FromEncodedString(getQueryStringValue("ID"));
        // check for single page login session tabID is there
        if (isSinglePageLogin && sessionStorage.getItem("deviceID")) {
            id = sessionStorage.getItem("deviceID");
        }
        // check the local storage for TMAC login data
        if (id && localStorage.getItem("TMACdata-" + id)) {
            setTimeout(opener ? opener.CloseLoginPage() : null, 5000);
            return JSON.parse(localStorage.getItem("TMACdata-" + id));
        }
        else {
            return isSinglePageLogin ? parent.GetSuccessfullyLoggedInData() : opener.GetSuccessfullyLoggedInData();
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.GetLoginData()", ex, false);
    }
}

//load the kendo tabs on page load
function LoadInitialTabs() {
    try {
        //initialise the main tabstrip
        tabstrip = $("#tabstrip").kendoTabStrip({
            animation: false,
            select: OnTabStripSelected,
            activate: OnTabStripActivate
        }).data("kendoTabStrip");
        //add the main tab to main tabstrip
        if (isCustomMainTab) {
            AddMainTab("main_tab_header", "custom_tab_body", "main", "Main", true);
        }
        else if (!isCustomMainTab && !isFullTMAC) {
            AddMainTab("main_tab_header", "main_tab_body", "main", "Main", true);
        }
        if (isDashboardEnabled && isFullTMAC) {
            AddMainTab("main_tab_header", "iframe_tab_body", "dashboard", "Dashboard", false);
            var param = "agentId=" + global_AgentID + "&profile=" +
                global_UserProfileForAgent + "&channel=" + "" + "&channelList=" + globalChannelList;
            param = ToEncodedString(param);
            LoadIFrame("ui_global_framedashboard", dashboardUrl + "?" + param);
        }
        if (isVoiceBio) $("#tabstrip").find(".k-tabstrip-items").addClass("uk-display-none");
        //initialise make call tabstrip
        tabstrip_call = $("#tabstrip_call").kendoTabStrip({
            animation: false,
            select: function (arg) {
                let tabName = $(arg.item).find("> .k-link").text().trim();
                if (tabName === "Agent List") {
                    $("#btnReloadMakeCallAgentList").show();
                }
                else {
                    $("#btnReloadMakeCallAgentList").hide();
                }
            }
        }).data("kendoTabStrip");
        //initialise transfer call tabstrip
        tabstrip_transfer = $("#tabstrip_transfer").kendoTabStrip({
            animation: false,
            select: function (arg) {
                let tabName = $(arg.item).find("> .k-link").text().trim();
                FadeInButton("#btndialogtransfercall");
                $('#txtNumberTrans').val("");
                EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
                EnableButton("#btndialogblindtransfercall", "BT", "tag");
                $("#transfer_skill_list_grid").hide();
                if (tabName === "Agent List") {
                    $("#txtNumberTrans").attr("placeholder", "Agent");
                    $("#transfer_skill_list_grid").show();
                    //check if blind transfer should be disabled for any channel based on config
                    if (global_CallType === "Transfer" && disableAgentBlindTransfer.Voice ||
                        global_CallType === "TextChatTransfer" && disableAgentBlindTransfer.TextChat ||
                        global_CallType === "FaxTransfer" && disableAgentBlindTransfer.Fax) {
                        FadeOutButton("#btndialogblindtransfercall");
                    }
                }
                else if (tabName === favouriteSkillTabName) {
                    if (global_CallType === "Transfer" && !consultTransferOnSkill.Voice ||
                        global_CallType === "TextChatTransfer" && !consultTransferOnSkill.TextChat ||
                        global_CallType === "FaxTransfer" && !consultTransferOnSkill.Fax) {
                        FadeOutButton("#btndialogtransfercall");
                    }
                    $("#txtNumberTrans").attr("placeholder", "Skill");
                }
                else if (tabName === speedDialTabName) {
                    $("#txtNumberTrans").attr("placeholder", "Agent");
                }
                RefreshTransCallagentListGrid();
            }
        }).data("kendoTabStrip");
    } catch (ex) {
        log.LogDetails("Error", "MainUI.LoadInitialTabs()", ex, false);
    }
}

//kendo main tab strip tab onactive event
function OnTabStripActivate(arg) {
    try {
        //get the interaction id from the tab id
        var intId = arg.contentElement.getAttribute("intid");
        //if the interaction is main the don't call SwapTabs
        if (!isNaN(intId)) {
            //assign the interaction id to global_activeTabInteractionID
            global_activeTabInteractionID = intId;
            //call select tab logic for hold and active
            if (isChatEnabled || isFaxEnabled || isFbEnabled)
                SelectTablogic(intId);
        }
        //trigger window resize on each tab active
        setTimeout(function () { TriggerResize(); }, 500);
    } catch (ex) {
        log.LogDetails("Error", "MainUI.OnTabStripActivate()", ex, false);
    }
}

function SelectTablogic(intId) {
    try {
        //if the chat is on going and a new voice tab in then hold the chat.
        //if the tab is newly created then skip and assign select tab reference to false
        if (GetTabReferenceObj(intId).type === "chat" && isChatEnabled) {
            if ((GetChatReferenceObj(active_tab_id) && !GetChatReferenceObj(active_tab_id).isDisconnected) ||
                (!GetTabReferenceObj(intId).firstSelect && (GetTabReferenceObj(intId).type !== "acallback") && (GetTabReferenceObj(intId).type !== "pcallback"))) {
                SelectTab(global_DeviceID, global_activeTabInteractionID);
                //if the chat is on going and a new voice tab in then hold the chat and make first select of other tab false
                if ((GetChatReferenceObj(active_tab_id) && !GetChatReferenceObj(active_tab_id).isDisconnected))
                    GetTabReferenceObj(intId).firstSelect = false;
            } else if (isCallback && !GetTabReferenceObj(intId).firstSelect && GetTabReferenceObj(intId).type === "acallback") {
                //custom callback select
                custom_AgentInitCallbackSelect(intId);
            } else {
                GetTabReferenceObj(intId).firstSelect = false;
            }
            if (isChatEnabled && (GetChatReferenceObj(intId) && !GetChatReferenceObj(intId).isDisconnected))
                active_tab_id = intId;
            else
                active_tab_id = "";
        }

        //This will select for newly arrived tab which is not a problem
        //only thing is select will be called even if no other tabs are active
        if (GetTabReferenceObj(intId).type === "fax" && isFaxEnabled ||
            GetTabReferenceObj(intId).type === "facebook" && isFbEnabled) {
            SelectTab(global_DeviceID, global_activeTabInteractionID);
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.SelectTablogic()", ex, false);
    }
}

//kendo main tab strip tab on select event
function OnTabStripSelected(arg) {
    try {
        //get the interaction id from the tab id
        var intId = arg.contentElement.getAttribute("intid");
        if (!isNaN(intId)) {
            if (isChatEnabled && (GetChatReferenceObj(intId) && !GetChatReferenceObj(intId).isDisconnected)) {
                if (GetChatReferenceObj(intId).isBlink) {
                    $("#li_" + intId).removeClass("blink_chattab");
                    GetChatReferenceObj(intId).isBlink = false;
                }
                GetChatReferenceObj(intId).isActive = true;
                if (intId !== active_tab_id && active_tab_id !== "" && GetChatReferenceObj(active_tab_id))
                    GetChatReferenceObj(active_tab_id).isActive = false;
            }
        }
        //if the tab selected is workbench then send a post message to reload items
        else if (intId === "workbench") {
            var workbenchIframe = document.getElementById("workbench_iframe");
            var workbenchWindow = workbenchIframe ? workbenchIframe.contentWindow : null;
            if (workbenchWindow) InvokePostMessage(workbenchWindow, null, "CommonUi.GetInitialData", null, null);
        }
        //expand the tmac if we select supervisor tab
        if (isExpandCollapseOnIframes.Supervisor || isExpandCollapseOnIframes.Workbench) {
            if (isSupervisor && intId === "supervisor") {
                window.resizeTo(screen.width, screen.height);
                ResizeCustom("min");
            }
            else if (isWorkbench && intId === "workbench") {
                window.resizeTo(screen.width, screen.height);
                ResizeCustom("min");
            }
            else if (isChatEnabled && GetChatReferenceObj(intId)) {
                ResizeWindow(false);
            }
        }
        else if (isChatEnabled && GetChatReferenceObj(intId)) {
            ResizeWindow(false);
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.OnTabStripSelected()", ex, false);
    }
}

//initialise all window dialogs
function LoadDialogUtils() {
    try {
        //dialog elements - title, elementId, width(global vars config), height
        let windowElements = {
            "add_reminder_dialog": "Set Reminder," + kendo_window_width.add_reminder + ", auto,,,false",
            "barge_in_dialog": "Textchat Barge-In," + kendo_window_width.barge_in_dialog + ", auto,,,false",
            "barge_in_display_dialog": "Barge-In Display," + kendo_window_width.barge_in_dialog + ", auto,,,false",
            "make_call_dialog": "Make Call," + kendo_window_width.make_call_dialog + ", auto,,,false",
            "transfer_dialog": "Transfer," + kendo_window_width.transfer_dialog + ", auto,,,false",
            "convert_dialog": "Transfer," + kendo_window_width.convert_dialog + ", auto,,,false",
            "pom_trans_conf_dialog": "Transfer," + kendo_window_width.transfer_dialog + ", auto,,,false",
            "conference_dialog": "Conference," + kendo_window_width.conference_dialog + ", auto,,,false",
            "confirm_dialog": "Confirm," + kendo_window_width.confirm_dialog + ", auto,,,false",
            "schedule_callback_dialog": "Schedule Callback," + kendo_window_width.callback_dialog + ", auto,,,false",
            "pom_schedule_callback_dialog": "Schedule Callback," + kendo_window_width.pom_callback_dialog + ", auto,,,false",
            "pom_edit_callback_dialog": "Update Callback," + kendo_window_width.pom_callback_dialog + ", auto,,,false",
            "schedule_multiple_callback_dialog": "Schedule Callback Request," + kendo_window_width.callback_dialog + ", auto,,,false",
            "callback_grid_dialog": "Callback Grid," + kendo_window_width.callback_dialog + ", auto,,,false",
            "callback_dialog": "Callback Request," + kendo_window_width.callback_dialog + ", auto,,,false",
            "callback_detail_dialog": "Callback Details," + kendo_window_width.callback_dialog + ", auto,,,false",
            "va_history_request_dialog": "VA History Details," + kendo_window_width.va_history + ", auto,,,false",
            "chat_template_dialog": "Chat Templates," + kendo_window_width.chat_template_dialog + ", auto,,,false",
            "close_callback_dialog": "Close/Re-schedule Callback," + kendo_window_width.callback_dialog + ", auto,,,false",
            //"video_call_dialog": "Video Call, 50%, 50%,, false,true",
            "video_call_dialog": "Video Call, 50%, 50%,, false,true",
            //NOTE: not used now but keep it, if needed
            //"from_filling_dialog": "Form Filling, 75%, 75%,,,false",
            "whiteboard_dialog": "Whiteboard, 90%, 65%,,,false",
            //"draw_together_dialog": "Draw Together, 75%, 75%,,,false",
            //"start_chat_dialog": "Start Chat," + kendo_window_width.start_chat_dialog + ", auto,,,false",
            "compose_fax_dialog": "Compose Fax," + kendo_window_width.compose_dialog + " auto,,,false",
            "compose_sms_dialog": "Compose SMS," + kendo_window_width.compose_dialog + ", auto,,,false",
            "fax_template_editor_dialog": "Fax Template Editor," + kendo_window_width.fax_template_dialog + ", auto,,,false",
            "facetouch_enroll_dialog": "Face Touch Monitor," + kendo_window_width.modal_enroll_facetouch + ", auto,,,false",
            "cobrowse_options_dialog": "Co-Browse," + kendo_window_width.compose_dialog + ", auto,,,false",
            "dialPadWindow": "Dial Pad," + kendo_window_width.dial_pad_window + ", auto,,false,false"
        };

        //to stop kendo window from closing on escape press
        kendo.ui.Window.fn._keydown = function (originalFn) {
            var KEY_ESC = 27;
            return function (e) {
                if (e.which !== KEY_ESC) {
                    originalFn.call(this, e);
                }
            };
        }(kendo.ui.Window.fn._keydown);

        //initialise each kendo dialog elements
        $.each(windowElements, function (i, val) {
            //dialog id
            let id = i;
            //dialog title
            let title = val.split(',')[0];
            //dialog width
            let width = val.split(',')[1];
            //dialog height
            let height = val.split(',')[2];
            //dialog max width
            let maxWidth = val.split(',')[3] ? parseInt(val.split(',')[3].trim()) : Infinity;
            //modal flag
            let modal = val.split(',')[4] ? val.split(',')[4].trim() === "true" : modalOnDialog;
            //resize flag
            let resize = val.split(',')[5] ? val.split(',')[5].trim() === "true" : false;
            //dynamic initialisation
            InitKendoWindow(id, title, width, height, maxWidth, modal, resize);
        });

        //bind make call dialog onclose event
        $("#make_call_dialog").data("kendoWindow").bind("close", function (arg) {
            var internalCallSelector = document.querySelector('#makeCallCb');
            internalCallSelector.checked = false;
            onSwitchChange(internalCallSelector);
        });

        //bind dial pad dialog onclose event
        $("#dialPadWindow").data("kendoWindow").bind("close", function (arg) {
            dialPadInteractionId = 0;
        });

        //remove the close the button of confirm box
        $("#confirm_dialog").closest(".k-window").find(".k-window-actions").html("");

        //bind chat template dialog onclose event
        $("#chat_template_dialog").data("kendoWindow").bind("close", function (arg) {
            ChatTemplateDialogClose(arg);
        });

        //bind barge in dialog onclose event
        $("#barge_in_dialog").data("kendoWindow").bind("close", function (arg) {
            $("#barge_in_grid").data("kendoGrid").dataSource.data([]);
        });

        //NOTE: not used now but keep it, if needed
        ////bind form filling dialog onclose event
        //$("#from_filling_dialog").data("kendoWindow").bind("close", function (arg) {
        //    LoadIFrame("formFillingIframe", "");
        //});
        //bind whiteboard dialog onclose event
        $("#whiteboard_dialog").data("kendoWindow").bind("close", function (arg) {
            LoadIFrame("whiteboardIframe", "");
        });
        ////bind whiteboard dialog onclose event
        //$("#draw_together_dialog").data("kendoWindow").bind("close", function (arg) {
        //    LoadIFrame("drawTogetherIframe", "");
        //});

        if (isFaxEnabled) {
            //bind fax compose dialog onclose event
            $("#compose_fax_dialog").data("kendoWindow").bind("close", function (arg) {
                $("#DNISList").data("kendoDropDownList").text("Select a Fax Line...");
                $("#DNISList").data("kendoDropDownList").enable(true);
                //if more than 1 recipents then clear selectize
                if (maxFaxLineRecipents > 1) {
                    faxNumberSelect[0].selectize.clear();
                }
                //else clear the single textbox
                else {
                    $("#faxNumber").val("");
                }
                $("#faxNumber").removeAttr("readonly", "readonly");
                //in a timeout clear the dynamic feilds
                setTimeout(function () {
                    $.each(faxAddonReference, function (i, val) {
                        RemoveAddOnFaxItem(val.id);
                    });
                    tempAddonTemplate = {};
                    faxItemId = 1;
                    //if coverpage is enabled then clear the coverpage content
                    if (isfaxCoverPage) {
                        addCoverPage = false;
                        var coverPageSwitch = document.querySelector('#cover_page_switch');
                        coverPageSwitch.checked = false;
                        onSwitchChange(coverPageSwitch);
                        $("#coverPageContainer").html("");
                    }
                }, 500);
                //show the send button if disabled
                EnableButton("#btnSendFax", "Send", "tag");
                //show the add item button if disabled
                FadeInButton("#btnAddFaxItem");
                //show the compose button when dialog is closed
                FadeInButton(".btn-compose-fax");
                //if multiple fax sending is enabled then clear it
                if (isSendFaxToGroup) {
                    $("#faxNumberGroups").data("kendoDropDownList").value("");
                    $("#faxNumberGroups").data("kendoDropDownList").text("Select an address book...");
                    $('#faxNumberGroups').data('kendoDropDownList').enable(false);
                }
            });

            //bind fax compose dialog onclose event
            $("#compose_fax_dialog").data("kendoWindow").bind("open", function (arg) {
                FadeOutButton(".btn-compose-fax");
            });
        }

        if (isSMSEnabled) {
            //bind sms compose dialog onclose event
            $("#compose_sms_dialog").data("kendoWindow").bind("close", function (arg) {
                $("#SmsDnisList").data("kendoDropDownList").text("Select a from number...");
                $("#SmsDnisList").data("kendoDropDownList").enable(true);
                if (maxSmsLineRecipents > 1)
                    smsNumberSelect[0].selectize.clear();
                else
                    $("#toSmsNumber").val("");
                $("#toSmsNumber").removeAttr("readonly", "readonly");

                var $kendoComboBox1 = $('#sms_dept_combobox').data('kendoComboBox');
                $kendoComboBox1.enable(false);
                $kendoComboBox1.value("");
                $kendoComboBox1.dataSource.data("");

                var $kendoComboBox2 = $('#sms_grp_combobox').data('kendoComboBox');
                $kendoComboBox2.enable(false);
                $kendoComboBox2.value("");
                $kendoComboBox2.dataSource.data("");
                FadeInButton(".btn-compose-sms");
                $('#sms_template_grid').data('kendoGrid').dataSource.data([]);
            });
            //bind sms compose dialog onopen event
            $("#compose_sms_dialog").data("kendoWindow").bind("open", function (arg) {
                FadeOutButton(".btn-compose-sms");
                EnableButton("#btnSendSMS", "Send", "tag");
                $('#sms_dept_combobox').data('kendoComboBox').enable();
            });
        }

        //if AV Enabled and the vidoe call type is popup configure buttons
        if (isAVEnabled && videoCallType === "window" || typeof isAgentAVChat !== "undefined" && isAgentAVChat) {
            //add aditional actions for video call dialog
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").html("");

            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_minimize_video" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');

            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_maximize_video" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');

            //TODO:: Experimental for small/restore video size
            //$("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_large_video" class="k-button k-bare k-button-icon k-window-action uk-display-none" aria-label="Custom"><span class="k-icon k-i-hyperlink-open-sm"></span></a>');
            //$("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_small_video" class="k-button k-bare k-button-icon k-window-action" aria-label="Custom"><span class="k-icon k-i-launch"></span></a>');
            ////bind custom events for video call dialog
            //$("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-hyperlink-open-sm").click(function (e) {
            //    $("#video_call_dialog").data("kendoWindow").wrapper.css({
            //        width: '50%',
            //        height: '50%'
            //    });
            //    $("#btnMuteAudio").show();
            //    $("#btnMuteVideo").show();

            //    $("#btn_large_video").hide();
            //    $("#btn_minimize_video").css("display", "inline-flex");
            //    $("#btn_maximize_video").css("display", "inline-flex");
            //    $("#btn_small_video").css("display", "inline-flex");
            //});
            //$("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-launch").click(function (e) {
            //    $("#video_call_dialog").data("kendoWindow").wrapper.css({
            //        width: '30%',
            //        height: '30%'
            //    });
            //    $("#btnMuteAudio").hide();
            //    $("#btnMuteVideo").hide();
            //    $("#btn_small_video").hide();
            //    $("#btn_minimize_video").hide();
            //    $("#btn_maximize_video").hide();
            //    $("#btn_large_video").css("display", "inline-flex");
            //});
            //$("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-window-maximize").click(function (e) {
            //    $("#btn_small_video").css("display", "none");
            //    //since k-i-window-restore button is a dyanmic one we need to event listner and show small button
            //    setTimeout(function () {
            //        $("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-window-restore").click(function (e) {
            //            $("#btn_small_video").css("display", "inline-flex");
            //        });
            //    }, 100);
            //});
            ////bind custom events for video call dialog
            //$("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-window-minimize").click(function (e) {
            //    $("#btn_small_video").css("display", "none");
            //     //since k-i-window-restore button is a dyanmic one we need to event listner and show small button
            //    setTimeout(function () {
            //        $("#video_call_dialog").data("kendoWindow").wrapper.find(".k-i-window-restore").click(function (e) {
            //            $("#btn_small_video").css("display", "inline-flex");
            //        });
            //    }, 100);
            //});
        }

        //NOTE: not used now but keep it, if needed
        //if (isFormFilling) {
        //    //add aditional actions for form filling dialog
        //    $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").html("");
        //    $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');
        //    $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');
        //    $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="Close"><span class="k-icon k-i-close"></span></a>');
        //}

        if (isWhiteboard) {
            //add aditional actions for whiteboard dialog
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").html("");
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="Close"><span class="k-icon k-i-close"></span></a>');
        }

        //bind set reminder dialog onclose event
        if (isReminder) {
            $("#add_reminder_dialog").data("kendoWindow").bind("close", function (arg) {
                if (arg.sender.title().split(' ')[0] === "Edit")
                    EnableButton("#btnDeleteReminder", "delete", "icon");
            });
        }

        if (coBrowse.Enabled) {
            // co-browse dialog onclose event
            $("#cobrowse_options_dialog").data("kendoWindow").bind("close", function (arg) {

                var $kendoComboBox1 = $('#cobrowse_dept_combobox').data('kendoComboBox');
                $kendoComboBox1.enable(false);
                $kendoComboBox1.value("");
                $kendoComboBox1.dataSource.data("");

                var $kendoComboBox2 = $('#cobrowse_grp_combobox').data('kendoComboBox');
                $kendoComboBox2.enable(false);
                $kendoComboBox2.value("");
                $kendoComboBox2.dataSource.data("");
                //FadeInButton(".btn-compose-sms");
                $('#cobrowse_template_grid').data('kendoGrid').dataSource.data([]);
            });
            //bind sms compose dialog onopen event
            $("#cobrowse_options_dialog").data("kendoWindow").bind("open", function (arg) {
                //FadeOutButton(".btn-compose-sms");
                //EnableButton("#btnSendSMS", "Send", "tag");
                $('#cobrowse_dept_combobox').data('kendoComboBox').enable();
            });

            //  Show applicable input modes for cobrowse options
            $("[name=coBrowseMode]").change(function (event) {
                if (event.currentTarget.value === "template") {
                    $("#divCobrowseTextArea").addClass("uk-display-none");
                    $("#divCobrowseTemplate").removeClass("uk-display-none");
                }
                else
                    if (event.currentTarget.value === "text") {
                        $("#divCobrowseTemplate").addClass("uk-display-none");
                        $("#divCobrowseTextArea").removeClass("uk-display-none");
                    } else
                        if (event.currentTarget.value === "CustCurrentPage") {
                            $("#divCobrowseTemplate").addClass("uk-display-none");
                            $("#divCobrowseTextArea").addClass("uk-display-none");
                        }
            });
        }

    } catch (ex) {
        log.LogDetails("Error", "MainUI.LoadDialogUtils", ex, false);
    }
}

//dynamic initialisation of kendo window dialogs
function InitKendoWindow(windowId, title, width, height, maxWidth, modal, resize) {
    try {
        $("#" + windowId).kendoWindow({
            modal: modal,
            title: title,
            width: width,
            height: height,
            visible: false,
            resizable: resize,
            maxWidth: maxWidth,
            open: OnKendoWindowOpen,
            actions: ["Close"]
        }).data("kendoWindow");
        altair_md.inputs($(windowId));
    } catch (ex) {
        log.LogDetails("Error", "MainUI.InitKendoWindow()", ex, false);
    }
}

//on close of kendo window dialog
function OnKendoWindowOpen() {
    TriggerResize();
}

//Intitalse utility functions
function UtilFunctions() {
    try {
        //theme switcher configs
        var $colors_li = $("#color_li");
        $colors_li.hide();
        $('#change_theme_color').change(function () {
            if (this.checked === true) {
                $colors_li.show();
            } else {
                $colors_li.hide();
            }
        });

        //transfer skill list dropdown 
        $("#transfer_skill_list").kendoDropDownList({
            dataTextField: "SkillName",
            dataValueField: "SkillID",
            select: OnSkillListChange
        });

        //callback schedule dialog callback time kendo masked textbox initialisation
        ConfigureMaskedTextBox("chatcallbackScheduleRequestTime", "00:00");

        //callback schedule dialog callback time kendo masked textbox initialisation
        //ConfigureMaskedTextBox("pomSCRequestTime", "00:00:00");

        //multiple callback schedule dialog callback time kendo masked textbox initialisation
        ConfigureMaskedTextBox("multipleCallbackScheduleTime", "00:00");

        //reminder time kendo masked textbox initialisation
        ConfigureMaskedTextBox("reminderTime", "00:00");

        if (isChatEnabled && isAttachement) {
            $("#attachFiles").kendoUpload({
                async: {
                    autoUpload: false,
                    saveUrl: "DummyURL"
                },
                multiple: false,
                upload: function (e) {
                    var obj = {};
                    e.data = obj;
                    //  VP : Mar 2, '20: Append data
                    if (GetChatReferenceObj(global_activeTabInteractionID).isSMM) {

                        // check if file server URL is configured
                        if (typeof FileServerUrl.Smm !== "string" || !FileServerUrl.Smm) {
                            log.LogDetails("Error", "MainUI.UtilFunctions()", "SMM File server URL [FileServerUrl.Smm] is not configured!", false);
                            return;
                        }

                        log.LogDetails("Info", "MainUI.UtilFunctions()", "Using Smm File Server for file upload.", false);

                        let customObj = {
                            intId: global_activeTabInteractionID
                        };
                        e.formData = new FormData();
                        e.formData.append("file", e.files[0].rawFile);
                        e.formData.append("interaction_id", uuid());
                        e.formData.append("organization_id", "prod");
                        e.formData.append("conv_id", GetChatReferenceObj(global_activeTabInteractionID).sessionId);
                        e.formData.append("uploaded_by", "system");
                        e.formData.append("other", JSON.stringify(customObj));

                        e.sender.options.async.withCredentials = false;
                        e.sender.options.async.saveUrl = FileServerUrl.Smm;
                    } else
                        if (FileServerUrl.MediaProxy.length !== 0) {
                            log.LogDetails("Info", "MainUI.UtilFunctions()", "Using Media Proxy File Server for file upload.", false);

                            let customObj = {
                                intId: global_activeTabInteractionID
                            };

                            e.formData = new FormData();
                            e.formData.append("file", e.files[0].rawFile);
                            e.formData.append("SessionId", GetChatReferenceObj(global_activeTabInteractionID).sessionId);
                            e.formData.append("other", JSON.stringify(customObj));

                            e.sender.options.async.withCredentials = false;
                            e.sender.options.async.saveUrl = FileServerUrl.MediaProxy + "/api/FileUpload/Post/";
                        } else {
                            log.LogDetails("Info", "MainUI.UtilFunctions()", "Using TMAC Proxy for file upload.", false);

                            e.sender.options.async.withCredentials = true;
                            e.sender.options.async.saveUrl = global_connectedProxy + "ChatFileUpload";
                        }
                },
                success: function (e) {
                    //  VP : Mar 2, '20: Check if SMM interaction
                    var currentIntId = global_activeTabInteractionID;
                    var isSmm = false;
                    var src = "";

                    //  VP: If e.files come as undefined, use "files" variable
                    if (!e.files) e.files = files;

                    //  SMM File Server
                    if (e.response && e.response.result && e.response.result.other) {
                        let otherData = JSON.parse(e.response.result.other);
                        currentIntId = otherData.intId;
                        isSmm = true;
                        src = e.response.result.downloadURL;
                    } else
                        //  Media proxy File server
                        if (e.response && e.response.other) {
                            if (e.response.statusCode !== 'Created') {
                                log.LogDetails("Error", "TmacTextChatUI.Ready()", "File upload failed.", false);
                            }
                            let otherData = JSON.parse(e.response.other);
                            currentIntId = otherData.intId;
                            src = e.response.url;
                        }
                        else {
                            src = e.XMLHttpRequest.statusText;
                        }

                    GetChatReferenceObj(currentIntId).isAgent = true;
                    $.each(e.files, function (i, val) {
                        let type = "";
                        let msgid = uuid();
                        let message = "";
                        let isReply = GetChatReferenceObj(currentIntId).replyText !== "" ? true : false;
                        let replyJson = {};

                        //  VP: Jun 1, '20: New JSON structure
                        let obj = {
                            messageId: msgid,
                            attachment: {
                                src: src,
                                type: "",
                                name: val.name ? val.name : ""
                            },
                            message: "",
                            replyId: GetChatReferenceObj(currentIntId).replyId ? GetChatReferenceObj(currentIntId).replyId : "",
                            type: "attachment"
                        };
                        if (toLowerCaseArray(imageFormats).indexOf(val.extension.toLowerCase()) >= 0) {
                            type = "image";

                        }
                        else if (toLowerCaseArray(audioFormats).indexOf(val.extension.toLowerCase()) >= 0) {
                            type = "audio";
                        }
                        else if (toLowerCaseArray(videoFormats).indexOf(val.extension.toLowerCase()) >= 0) {
                            type = "video";
                        }
                        else {
                            var fileType = GetFileExtension(val.extension);
                            if (toLowerCaseArray(fileFormats).indexOf(fileType.toLowerCase()) >= 0)
                                type = "file";
                            else
                                type = "others";


                            //  To add to chatbox
                            src = val.name + "|" + src;
                        }
                        obj.attachment.type = type;

                        //  VP : Mar 2, '20 : Sending SMM object
                        if (isSmm) {
                            obj = {
                                "_type": "attachment",
                                "_attachmentType": obj.type,
                                "_attachmentId": e.response.result.interaction_id,
                                "_attachmentPreviewId": "",
                                "_attachmentSize": e.response.result.size
                            };
                        }
                        message = JSON.stringify(obj);
                        SendTextChat(global_DeviceID, currentIntId, message, "", msgid, false);

                        replyJson.replyType = GetChatReferenceObj(currentIntId).replyType;
                        replyJson.replyId = GetChatReferenceObj(currentIntId).replyId;
                        replyJson.replyText = GetChatReferenceObj(currentIntId).replyText;
                        replyJson.replyUser = GetChatReferenceObj(currentIntId).replyUser;

                        AddMessageToChatbox(currentIntId, msgid, src, "agent", "", "divTxtChatTranscript", type, isReply, replyJson, global_AgentName.split(" ")[0]);
                    });
                    $("#attachFiles").data("kendoUpload").clearAllFiles();
                    //success
                },
                error: function (e) {
                    //error
                    var f = {};
                },
                remove: function (e) {
                    //remove
                },
                progress: function (e) {
                    $("#div_uk_progress_bar" + global_activeTabInteractionID).removeClass("uk-display-none");
                    $("#uk_progress_bar" + global_activeTabInteractionID).css("width", e.percentComplete + "%");
                    console.log(e.percentComplete);
                },
                complete: function (e) {
                    $("#div_uk_progress_bar" + global_activeTabInteractionID).addClass("uk-display-none");
                },
                select: function (e) {
                    $("#uk_progress_bar" + global_activeTabInteractionID).css("width", "0%");
                    files = {};
                    $.each(e.files, function () {
                        if (this.size > parseInt(maxAttachFileSize) * 1024 * 1024) {
                            let msg = this.name + ": File size is too large.";
                            log.LogDetails("Error", "MainUI.UtilFunctions().kendoUpload()", msg, true);
                            e.preventDefault(); // This cancels the upload for the file
                        }

                        if (this.extension === "") {
                            let msg = this.name + " is a invalid file";
                            log.LogDetails("Error", "MainUI.UtilFunctions().kendoUpload()", msg, true);
                            e.preventDefault(); // This cancels the upload for the file
                        }

                        if (imageFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_img = document.getElementById('img_screenshot' + global_activeTabInteractionID);
                                        if (clip_img !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'image/png' });
                                            var url = URL.createObjectURL(blob);
                                            clip_img.src = url;
                                            console.log("Image attach: " + url);
                                            ShowAttachment("image");
                                        }
                                    };
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else if (audioFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_audio = document.getElementById('aud_screenshot' + global_activeTabInteractionID);
                                        if (clip_audio !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'audio/x-mpeg-3' });
                                            var url = URL.createObjectURL(blob);
                                            clip_audio.src = url;
                                            console.log("Audio attach: " + url);
                                            ShowAttachment("audio");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else if (videoFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_video = document.getElementById('vid_screenshot' + global_activeTabInteractionID);
                                        if (clip_video !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'video/webm' });
                                            var url = URL.createObjectURL(blob);
                                            clip_video.src = url;
                                            console.log("Video attach: " + url);
                                            ShowAttachment("video");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                externalFileName = fileInfo.name;
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let file_preview = document.getElementById('file_preview' + global_activeTabInteractionID);
                                        if (file_preview !== null) {
                                            file_preview.href = this.result;
                                            $("#file_preview" + global_activeTabInteractionID).html('<span class="k-icon ' + GetIconByExtension(fileInfo.extension.toUpperCase()) + ' k-icon-48"></span><br/>' + fileInfo.name);
                                            ShowAttachment("file");
                                        }
                                    };
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                    });
                    files = e.files;
                }
            });
            $(".k-upload").addClass("uk-display-none");
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.UtilFunctions()", ex, false);
    }
}

//assign kendo masked feature to the textbox
function ConfigureMaskedTextBox(textBoxId, maskFormat) {
    try {
        $("#" + textBoxId).kendoMaskedTextBox({
            mask: maskFormat
        });
        $("#" + textBoxId).removeClass("k-textbox");
    } catch (ex) {
        log.LogDetails("Error", "MainUI.ConfigureMaskedTextBox() - " + textBoxId, ex, false);
    }
}

//TMAC UI configurations
function Configurations() {
    try {
        //get the config from local storage or config
        isPushNotification = localStorage.getItem("isPushNotification") || isPushNotification;

        //check from local storage the type is string
        if (typeof isPushNotification === "string") {
            isPushNotification = isPushNotification === "true";
        }

        //Push notification config
        var pushNotification = document.querySelector('#push_notification_enabled');
        if (isPushNotification) {
            pushNotification.checked = true;
            onSwitchChange(pushNotification);
        } else {
            pushNotification.checked = false;
            onSwitchChange(pushNotification);
        }

        $('#push_notification_enabled').change(function () {
            if (this.checked === true) {
                isPushNotification = true;
                localStorage.setItem("isPushNotification", true);
                GrandChromeNotification();
            } else {
                isPushNotification = false;
                localStorage.removeItem("isPushNotification");
            }
        });

        //for MS agent - do tone configuration
        if (agentType === "MS Agent") {
            //show the config
            $("#tone_switch").removeClass("uk-display-none");

            //range
            $("#tone_range").removeClass("uk-display-none");

            //get the config from local storage or config
            isToneEnabled = localStorage.getItem("isToneEnabled") || isToneEnabled;

            //get the tone volume range, if not set take default 0.5
            toneRange = localStorage.getItem("toneRange") || toneRange;

            //check from local storage the type is string
            if (typeof isToneEnabled === "string") {
                isToneEnabled = isToneEnabled === "true";
            }

            //get the html element
            var tone = document.querySelector('#tone_enabled');

            if (isToneEnabled) {
                tone.checked = true;
                onSwitchChange(tone);
            } else {
                tone.checked = false;
                onSwitchChange(tone);
            }

            $('#tone_enabled').change(function () {
                if (this.checked === true) {
                    isToneEnabled = true;
                    localStorage.setItem("isToneEnabled", true);
                } else {
                    isToneEnabled = false;
                    localStorage.removeItem("isToneEnabled");
                }
            });

            //check from local storage the type is string
            if (typeof toneRange === "string") {
                toneRange = parseInt(toneRange);
            }

            //set the range from config/localstorage
            document.getElementById("tone_range_elm").value = toneRange;

            //show the value in UI
            $("#tone_range_value").text(toneRange + "%");

            //listen to the change event
            document.getElementById("tone_range_elm").onchange = function (evt) {
                //get the value
                toneRange = parseInt(evt.target.value);
                //check if audio tag is created
                if (_audio) {
                    //change the volume range
                    _audio.volume = toneRange / 100;
                }
                //update the localstorge
                localStorage.setItem("toneRange", toneRange);
                //update the range in UI
                $("#tone_range_value").text(toneRange + "%");
            };
        }

        //utilities barg-in configs
        if (global_UserProfileForAgent && global_UserProfileForAgent.toLowerCase() === "s" && (isBargeIn || isSupervisor)) {
            //    Jul 15, '20: VP: isBargeIn and isSupervisor are made independent of each other
            if (isBargeIn) {
                $('#btnChatBargeIn').removeClass("uk-display-none-important");
                //create barge in grid
                CreateBargeInGrid([]);
            } else {
                $('#btnChatBargeIn').remove();
            }

            if (isSupervisor) {
                $('#btnSupervisor').removeClass("uk-display-none-important");
            } else {
                $('#btnSupervisor').remove();
            }
        } else {
            $('#btnChatBargeIn').remove();
            $('#btnSupervisor').remove();
        }

        if (isWorkbench) {
            $('#btnWorkbech').removeClass("uk-display-none-important");
        }
        else {
            $('#btnWorkbech').remove();
        }

        $("#div_marquee").click(function () {
            if ($.trim($("#marquee").text()) !== "")
                UIkit.modal.alert($("#marquee").text());
        });

        if (!isFullTMAC && isDashboardEnabled) {
            //dashboard interval dropdown
            $("#drp_dashboard_interval").kendoDropDownList({
                dataTextField: "text",
                dataValueField: "value",
                select: OnDashboardIntervalChange,
                dataSource: dashboardInterval
            });

            //set default select for dashboard dropdown
            $("#drp_dashboard_interval").data("kendoDropDownList").select(function (dataItem) {
                return dataItem.value === defaultDashboardInterval;
            });
        }

        if (typeof meetingFrameUrl !== "undefined" && meetingFrameUrl) {
            $('#btnTMACMeeting').removeClass("uk-display-none-important");
        }
        else {
            $('#btnTMACMeeting').remove();
        }

        if (typeof enableFaceTouchMonitor === "undefined" || !enableFaceTouchMonitor) {
            $('#btnFaceTouchEnroll').remove();
        }

    } catch (ex) {
        log.LogDetails("Error", "MainUI.Configurations()", ex, false);
    }
}

function onSwitchChange(el) {
    if (typeof Event === 'function' || !document.fireEvent) {
        var event = document.createEvent('HTMLEvents');
        event.initEvent('change', true, true);
        el.dispatchEvent(event);
    } else {
        el.fireEvent('onchange');
    }
}

//only number validation
function ValidateChar(event) {
    if (isNaN(String.fromCharCode(event.keyCode)) || $.trim(String.fromCharCode(event.keyCode)) === "")
        event.preventDefault();
}

function ResizeWindow(move) {
    //if not full tmac then only resize
    if (!isFullTMAC) {
        var Current_Width = CalculateTMACWindowWidth();
        var Current_Height = CalculateTMACWindowHeight();
        window.resizeTo(Current_Width, Current_Height);
    }

    if (move) {
        if (isVoiceBio || isCACS) {
            window.moveTo(screen.width, screen.height);
        }
        else {
            window.moveTo(0, 0);
        }
    }
}

var resizeTimer;
//window resize event
$(window).resize(function () {
    setTimeout(function () {
        SetHeight();
        SetTabHeight();
    }, 300);
    SetHeight();
    SetTabHeight();
    if (isDisableResize) {
        var Current_Width = CalculateTMACWindowWidth();
        var Current_Height = CalculateTMACWindowHeight();
        window.resizeTo(Current_Width, Current_Height);
    }

    if (editingImage && isPDFAndImageEditingAllowed) {
        var img = document.getElementById("img_screenshot_" + global_activeTabInteractionID);
        if (img !== null) {
            var canvas = document.getElementById("sketch");
            var canvasCon = canvas.getContext("2d");
            canvas.width = img.width;
            canvas.height = img.height;
            canvasCon.clearRect(0, 0, $("#sketch").width(), $("#sketch").height());
            var image = new Image();
            image.src = img.src;
            canvasCon.drawImage(image, 0, 0, img.width, img.height);
            drawInit();
        }
    }
});

//trigger the window resize event
function TriggerResize() {
    setTimeout(function () {
        $(window).trigger('resize');
    }, 100);
}

//set the height of the page content
function SetHeight() {
    try {
        setTimeout(function () {
            let totalHeight = $(window).height();
            let headerHeight = $("#header_main").height();
            let footerHeight = $("#footer").height();
            let mainContentHeight = totalHeight - headerHeight - footerHeight;
            $("#page_content").height(mainContentHeight);
            $("#page_content_inner").height(mainContentHeight);
            if (isFullTMAC && isReminder && isWallboard)
                $("#reminder_grid_side .k-grid-content").height(totalHeight - headerHeight - footerHeight - $("#wallboardGrid_side").height() - $("#side_agent_info").height() - 95);
            else if (isFullTMAC && isReminder && !isWallboard)
                $("#reminder_grid_side .k-grid-content").height(totalHeight - headerHeight - footerHeight - $("#side_agent_info").height() - 84);
            if (isSinglePageLogin) $(".login_iframe").height(totalHeight);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "MainUI.SetHeight()", ex, false);
    }
}

//set the tab height
function SetTabHeight() {
    try {
        setTimeout(function () {
            let tabCardHeight = $("#tab_card_content").height();
            let tabHeaderHeight = isVoiceBio ? 0 : $(".k-reset").height();
            let tabContentHeight = tabCardHeight - tabHeaderHeight - 10;
            let wallboardHeight = $("#wallboardGrid_main").height();
            let userBlockHeight = $(".has-user-block").height();
            $(".main_tabstrip").height(tabContentHeight);

            if (isFullTMAC)
                $(".custom-main-body").height(tabContentHeight);
            if (!isFullTMAC && isReminder && isWallboard)
                $("#reminder_grid .k-grid-content").height(tabContentHeight - wallboardHeight - userBlockHeight - 100);
            else if (!isFullTMAC && isReminder && !isWallboard)
                $("#reminder_grid .k-grid-content").height(tabContentHeight - userBlockHeight - 84);

            if (!isFullTMAC && isWallboard && !isReminder) {
                $("#wallboardGrid_main .k-grid-content").height(tabContentHeight - userBlockHeight - 45);
            }

            if (isPOM) {
                // g-grid, h-header, H-height
                let ghH = $("#campaign_details_grid").find(".k-grouping-header").height() || $("#pending_callbacks_grid").find(".k-grouping-header").height();
                let gH = tabContentHeight / 2 - (ghH === null ? 88 : 132);
                $("#campaign_details_grid .k-grid-content").height(gH - 100);
                $("#pending_callbacks_grid .k-grid-content").height(gH + 100);
            }
            $(".md-card-content.chatbox_content").css("height", $(window).height() - 255 - (isVaChatHistoryAccordion ? 35 : 0) - (isChatAuthenticationPanel ? 100 : 54));
            if (isCustomerJourney) $(".interaction-history-frame").css("height", $(window).height() - 210 - (isVaChatHistoryAccordion ? 35 : 0) - (isChatAuthenticationPanel ? 100 : 54) - (isCustomTextChat ? 154 : 0));
            $(".facebook-post").css("max-height", $(window).height() - 125);
            $(".facebook-customer-journey").css("height", $(window).height() - 125);
            if (isVoiceBio) $(".voice-bio-card").height($(window).height() - 10);
            if ($(".full_tab_iframe").length > 0) $(".full_tab_iframe").height(tabContentHeight);
            if (isFaxEnabled) $(".fax-loader").height($(window).height() - 235);
            if (isCustomTextChat) $(".chat_iframe").height(tabContentHeight - 52);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "MainUI.SetTabHeight()", ex, false);
    }
}