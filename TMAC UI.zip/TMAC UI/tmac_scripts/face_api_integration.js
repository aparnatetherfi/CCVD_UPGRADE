// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "face_api_integration.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //need not add in versioning as this is a utility component
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

function Timeout(fn, interval) {
    let _this = this;
    var id = (fn) ? setTimeout(() => {
        fn();
        _this.cleared = true;
    }, interval) : null;
    this.cleared = false;
    this.clear = function () {
        if (this.cleared) return;
        this.cleared = true;
        clearTimeout(id);
    };
}
var faceApiIntegration = new function () {
    try {

        let _this = this;
        // interval time for face count detection excluding library proccessing time
        _this.faceCountDetectTimer = 1000;
        // interval time for face authentication detection excluding library proccessing time
        _this.faceAuthenticationWaitTime = 2000;
        // enable/disable phone detection feature
        _this.isPhoneDetectionEnabled = true;
        // enable/disable face count detection feature
        _this.isGetFaceCountEnabled = false;
        // enable/disable face authentication feature
        _this.isFaceAuthenticationEnabled = false;
        // enable/disable no face detection processing
        _this.isNoFaceDetectionEnabled = false;
        // handle no face detection for every interval
        _this.noFaceDetectionIntervalTime = 5000;
        // handle phone detection for every interval
        _this.phoneDetectedIntervalTime = 5000;
        // handle phone detection for every interval
        _this.multipleFaceDetectionIntervalTime = 5000;
        // enable/disable default alerts on violations
        _this.showDefaultAlerts = true;
        _this.faceExpressionInterval = null;
        _this.isFaceExpressionRepeat = true;
        _this.testingButtonsEnabled = false;
        _this.noFaceDetected = false;
        _this.livenessDetectedSuccessful = false;
        _this.IsFaceLivenessDetectionEnabled = false;
        _this.violationConfig = {
            multipleFaceDetected: { message: "Violation: Multiple face detected" },
            phoneDetected: { message: "Violation: Phone detected" },
            noFaceDetected: { message: "Violation: No face detected" },
            faceAuthenticationFailed: { message: "Violation: Face authentication failed" },
            livenessDetectionFailed: { message: "Violation: Liveness detection failed" }
        }
        _this.VIOLATION_NAMES = {
            MULTIPLE_FACE_DETECTED: "multipleFaceDetected",
            PHONE_DETECTED: "phoneDetected",
            NO_FACE_DETECTED: "noFaceDetected",
            FACE_AUTHENCATION_FAILED: "faceAuthenticationFailed",
            LIVENESS_DETECTION_FAILED: "livenessDetectionFailed"
        };
        _this.sendNofaceDetectedTimeout = new Timeout();
        _this.sendPhoneDetectedTimeout = new Timeout();
        _this.sendMultipleFaceTimeout = new Timeout();
        _this.sendFaceAuthenticationTimeout = new Timeout();

        // flag to indecate phone is detected
        _this.phoneDetected = false;
        _this.videoConfig = {
            width: 640, height: 480
        };
        _this.video = null;
        _this.emotions = {
            types: {
                happy: 0,
                neutral: 0,
                sad: 0,
                surprised: 0,
                angry: 0,
                disgust: 0,
                fear: 0,
                totalPoints: 100
            },
            clearDisplay: function () {
                try {
                    _this.emotions.updateDisplay(_this.emotions.types);
                } catch (ex) {
                    log.LogDetails("Error", "face_compare.emotions.cleardisplay", ex, false);
                }
            },
            updateDisplay: function (values) {
                try {
                    $.each(values, function (key, val) {
                        $("#" + key).html(values[key]);
                    })
                } catch (ex) {
                    log.LogDetails("Error", "face_compare.emotions.updatedisplay", ex, false);
                }
            }
        };
        _this.textAlertMessages = {
            multipleFaceDetected: "Multiple face detected",
            noFaceDetected: "No face detected",
            phoneDetected: "Phone is detected",
            faceAuthenticationError: "Face authentication failed",
            faceAuthenticationSuccess: "Face authentication success",
            faceAuthOnlogin: {
                success: "Login: Authentication is success!!",
                fail: "Login: Authentication is failed. Please logout!"
            },
            faceAuthOnAvailable: {
                success: "Available: Your authentication is success, please proceed to take calls",
                fail: "Available: You are not authorized to take calls, please contact supervisor"
            },
            faceAuthOncall: {
                success: "Please proceed with call",
                fail: "On Call: You are not authorized to continue this, Please contact your supervisor"
            },
            faceAuthOnAcw: {
                success: "Your authentication is success, please proceed to wrap up and take next call",
                error: "You are not authorized to wrap this call, Please contact your supervisor"
            },
            multipleFaceCountOnAvailable: "Available: You are not authorized to take calls",
            noFaceOnAvailableOne: "Available: You might get call anytime, please be seated",
            noFaceOnAvailableTwo: "Available: Face not found!! Changing Agent Status to Default",
            multipleFaceCountOnCall: "On Call: You are not authorized to continue this call anymore",
            noFaceOnCall2: "On Call: Please be seated since you are on call with customer",
            multipleFaceCountOnAcw: "You are not authorized to wrap this call",
            noFaceOnAcw: "Please be seated and wrap this call"

        };
        _loadHtml = function () {
            try {
                let testingButtons = `
                <div class="uk-grid">
                    <div class="uk-width-1-1" style="padding: 10px;">
                        <center>
                            <a class="md-btn md-btn-primary md-btn-mini md-btn-wave-light waves-effect waves-button waves-light" title="multiple face detected" onclick="sendMultipleFaceWithImages()" href="javascript:void(0)">
					            <span class="material-icons notranslate md-color-white">people_alt</span>
				            </a>
				            <a class="md-btn md-btn-primary md-btn-mini md-btn-wave-light waves-effect waves-button waves-light" title="phone detected" onclick="sendPhoneDetectedWithImages()" href="javascript:void(0)">
					            <span class="material-icons notranslate md-color-white">stay_primary_portrait</span>
				            </a>
				            <a class="md-btn md-btn-primary md-btn-mini md-btn-wave-light waves-effect waves-button waves-light" title="no face detected" onclick="sendNoFaceDetectedWithImages()" href="javascript:void(0)">
					            <span class="material-icons notranslate md-color-white">cancel_presentation</span>
				            </a>
				            <a class="md-btn md-btn-primary md-btn-mini md-btn-wave-light waves-effect waves-button waves-light" title="agent not authenticated" onclick="sendAuthenticationFailureWithImages()" href="javascript:void(0)">
					            <span class="material-icons notranslate md-color-white">block</span>
				            </a>
                        </center>
                    </div>
                </div>
                `;
                var html = `
				<!-- added below on 6th apr for demo video -->
				<div class="md-card uk-width-1-1">
					<div class="md-card-content" id="videoId" style="position: relative;">
						<video id="face-compare-video" width="640" height="480" autoplay muted style="height: 225px;"></video>
						<div id="objects">...</div>
                        <div class="flex-container" style="width: fit-content;margin: auto;" id="fe_emotions">								
							<div title="Happy">
                                <img src="components/faceCompare/images/happy.png" width="40" alt="&#128522;">
                                <span id="happy" class="uk-badge">0</span>
                            </div>
							<div title="Sad">
                                <img src="components/faceCompare/images/sad.png" width="40"  alt="&#128524;">
                                <span id="sad" class="uk-badge">0</span>
                            </div>
							<div title="Neutral">
                                <img src="components/faceCompare/images/neutral.png" width="40"  alt="&#128528;">
                                <span id="neutral" class="uk-badge">0</span>
                            </div>
							<div title="Angry">
                                <img src="components/faceCompare/images/angry.png" width="40"  alt="&#128544;">
                                <span id="angry" class="uk-badge">0</span>
                            </div>
							<div title="Surprised">
                                <img src="components/faceCompare/images/surprised.png" width="40"  alt="&#129299;">
                                <span id="surprised" class="uk-badge">0</span>
                            </div>
                            <div title="Disgusted">
                                <img src="components/faceCompare/images/disgusted.png" width="40"  alt="&#129299;">
                                <span id="disgusted" class="uk-badge">0</span>
                            </div>
                            <div title="Fearful">
                                <img src="components/faceCompare/images/fearful.png" width="40"  alt="&#129299;">
                                <span id="fearful" class="uk-badge">0</span>
                            </div>
						</div>
                        ` + (_this.testingButtonsEnabled ? testingButtons : ``) + `						
							
					</div>
				</div>
				<!-- <button id="snap">Snap Photo</button> -->
				<!-- <canvas id="canvas" width="640" height="480"></canvas> -->
				<!-- added above on 6th apr for demo video -->
			`;
                if (!isFullTMAC && !isCustomMainTab) {
                    // $("#div_user_info_block")
                    $("#div_wallboardGrid_main")
                        .removeClass("uk-width-large-1-1 uk-width-medium-1-1")
                        .addClass("uk-width-large-1-2 uk-width-medium-1-2");
                    // $("#div_user_info_block").after(`
                    $("#div_wallboardGrid_main").after(`
					<div class="uk-width-large-1-2 uk-width-medium-1-2 uk-width-small-1-1 uk-grid-margin" >
						<div class="md-card md-card-primary uk-width-1-1 card-user-block">
							<div class="md-card-content no-padding">`
                        + html +
                        `</div>
						</div>
					</div>
				`);
                } else if (isFullTMAC) {
                    $("#agent_info_side").append(html);
                }

                $("#fe_emotions").css({
                    "padding-top": "10px",
                });
                $("#fe_emotions > div").css({
                    position: "relative",
                    display: "inline",
                    "padding-top": "18px",
                    width: "35px"
                });
                $("#fe_emotions > div > span").css({
                    position: "absolute",
                    right: "0",
                    top: "0",
                    "font-size": "15px"
                });
                $("#objects").css({
                    "text-align": "center",
                    "font-style": "italic",
                    "font-weight": "bold",
                    "font-size": "medium",
                    margin: "5px 10px",
                    "border-radius": "3px",
                    padding: "5px",
                    border: "1px solid rgb(33, 33, 33)"

                })
                _this.video = document.getElementById('face-compare-video');

                navigator.getUserMedia(
                    { video: _this.videoConfig ? _this.videoConfig : {} },
                    stream => _this.video.srcObject = stream,
                    err => console.error(err)
                )
            } catch (ex) {
                log.LogDetails("Error", "face_compare.loadHtml", ex, false);
            }
        };

        _this.initFaceAuthentication = function () {
            _this.video.addEventListener('play', () => {

            })
        };

        _this.doFaceAuthentication = function (options) {
            try {
                function onSuccess(data) {
                    try {
                        let faceAuthorized = false;
                        if (data.face_found_in_image === false) {
                            faceAuthorized = false;
                        }
                        if (data.is_picture_of_user === false) {
                            faceAuthorized = false;
                        }
                        else {
                            if (data.face_authenticated_percentage >= 80) {
                                faceAuthorized = true;
                            } else {
                                faceAuthorized = false;
                            }
                        }
                        if (faceAuthorized) {
                            if (_this.showDefaultAlerts) log.LogDetails("Success", "doFaceAuthentication", _this.textAlertMessages.faceAuthenticationSuccess, true);
                            if (typeof options.onSuccess === "function") options.onSuccess();
                        } else {
                            if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.faceAuthenticationError, true);
                            // handle face authentication failed violation
                            _handleViolation(_this.VIOLATION_NAMES.FACE_AUTHENCATION_FAILED, "", "");
                            if (typeof options.onError === "function") options.onError();
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "face_compare.doFaceAuthentication", ex, false);
                    }
                }
                function onError(err) {
                    try {
                        log.LogDetails("Error", "FaceCompare", err, false);
                        if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.faceAuthenticationError, true);
                        // handle face authentication failed violation
                        _handleViolation(_this.VIOLATION_NAMES.FACE_AUTHENCATION_FAILED, "", "");
                        if (typeof options.onError === "function") options.onError();
                    } catch (ex) {
                        log.LogDetails("Error", "face_compare.loadHtml.onerror", ex, false);
                    }
                }
                if (_this.video.paused) {
                    _this.video.addEventListener('play', function () {
                        tmac_faceApi.faceCompares(_this.video, $("#profilePic")[0].src, onSuccess, onError);
                    })
                } else {
                    tmac_faceApi.faceCompares(_this.video, $("#profilePic")[0].src, onSuccess, onError);
                }
            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.doFaceAuthentication", ex, false);
            }
        };

        _this.getFaceCountAndPredictionLoop = new function () {
            try {
                let _$this = this;
                let _timeoutObj = new Timeout();
                let _sendFaceAuthenticationTimeout = new Timeout();
                let _sendNofaceDetectedTimeout = new Timeout();
                let _sendMultipleFaceTimeout = new Timeout();

                _handleFaceCount = function (count) {
                    try {
                        // when no face is detected
                        if (!count || count === 0) {
                            // set face authentication timeout if no face is detected continuously
                            if (_sendFaceAuthenticationTimeout.cleared) {
                                _sendFaceAuthenticationTimeout = new Timeout(function () {
                                    _this.noFaceDetected = true;
                                }, _this.faceAuthenticationWaitTime);
                            }
                            // set no face detection timeout if no face is detected continuously
                            if (_sendNofaceDetectedTimeout.cleared) {
                                _sendNofaceDetectedTimeout = new Timeout(function () {
                                    // display alert if configured
                                    if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.noFaceDetected, true);
                                    // handle no face detected violation
                                    _handleViolation(_this.VIOLATION_NAMES.NO_FACE_DETECTED);
                                }, _this.noFaceDetectionIntervalTime);
                            }
                            // no need to send multiple face detected as single face is detected now
                            _sendMultipleFaceTimeout.clear();
                            return;
                        } else if (count == 1) {
                            if (_this.noFaceDetected) {
                                _this.doFaceAuthentication();
                            } else {
                                _sendFaceAuthenticationTimeout.clear();
                            }
                            // no need to send no face detected as detected face now
                            _sendNofaceDetectedTimeout.clear();
                            // no need to send multiple face detected as single face is detected now
                            _sendMultipleFaceTimeout.clear();
                            _this.noFaceDetected = false;
                        } else if (count > 1) {
                            // on multiple face
                            if (_sendMultipleFaceTimeout.cleared) {
                                _sendMultipleFaceTimeout = new Timeout(function () {
                                    // display alert if configured
                                    if (_this.showDefaultAlerts) log.LogDetails("Info", "Face Count", _this.textAlertMessages.multipleFaceDetected, true);
                                    _handleViolation(_this.VIOLATION_NAMES.MULTIPLE_FACE_DETECTED);
                                }, _this.multipleFaceDetectionIntervalTime);
                            }
                            // no need to send no face detected as detected face now
                            _sendNofaceDetectedTimeout.clear();
                            _this.noFaceDetected = false;
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.handleFaceCount", ex, false);
                    }
                };

                _onPhoneDetected = function (phone) {
                    try {
                        if (phone) {
                            // check if time out is set already
                            if (_this.sendPhoneDetectedTimeout.cleared) {
                                let snapshotImg = _snapShot.getSnapshot();
                                let screenshotImg = _snapShot.getScreenshot();
                                // set time out
                                _this.sendPhoneDetectedTimeout = new Timeout(function () {
                                    //display default message
                                    if (_this.showDefaultAlerts)
                                        log.LogDetails("Info", "faceApiIntegration.onPhoneDetected", _this.textAlertMessages.phoneDetected, true);
                                    _handleViolation(_this.VIOLATION_NAMES.PHONE_DETECTED, screenshotImg, snapshotImg);
                                }, _this.phoneDetectedIntervalTime);
                            }
                        } else {
                            _this.sendPhoneDetectedTimeout.clear()
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.onPhoneDetected", ex, false);
                    }
                }

                _handlePredictions = function (predictions, textCsv) {
                    try {
                        //console.log(JSON.stringify(predictions, null, 4));
                        _handleFaceCount(predictions.person);
                        let phone = predictions.phone || predictions['cell phone'];
                        _onPhoneDetected(phone);
                        if (textCsv) {
                            $("#objects").text(textCsv);
                        } else {
                            $("#objects").text("...");
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.handlePredictions", ex, false);
                    }
                };
                _$this.start = function (time) {
                    try {
                        // if api is not loaded then call start again after 1 second
                        if (!tmac_faceApi.loaded) {
                            setTimeout(_$this.start, 1000);
                            return;
                        }
                        _timeoutObj = new Timeout(function () {
                            try {
                                // call coco ssd library if phonedetection is enabled to detect both face count and phone
                                if (_this.isPhoneDetectionEnabled) {
                                    tmac_faceApi.getPredictions(_this.video, null, function (predictions, text) {
                                        // handle predictions
                                        _handlePredictions(predictions, text);
                                    });
                                } else {
                                    // call face api to detect only face count
                                    let faceCount = tmac_faceApi.getFaceCount(_this.video);
                                    _handleFaceCount(faceCount);
                                }
                                // call this function recursive
                                _$this.start(time);
                            } catch (e) {
                                log.LogDetails("Error", "faceApiIntegration.getFaceCountAndPredictionLoop._timeoutObj.start", ex, false);
                            }
                        }, (typeof time === "number") ? time : _this.faceCountDetectTimer)
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.getFaceCountAndPredictionLoop.start", ex, false);
                    }
                }
                // this function will stop get face count and phone detection
                _$this.stop = function () {
                    _timeoutObj.clear();
                }

            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.initFaceCountDetection", ex, false);
            }
        };

        // this function will call get expression again and again
        _this.getFaceExpressionLoop = new function () {
            let _$this = this;
            try {
                // timout object
                let _faceExpressionTimeout = new Timeout();
                // start get face expression loop - recursive function
                _$this.start = function (time) {
                    try {
                        // create timeout object
                        _faceExpressionTimeout = new Timeout(function () {
                            tmac_faceApi.getFaceExpressions(_this.video, null, function (emotions) {
                                // display values of each emotions
                                $.each(emotions, function (key, value) {
                                    let val = parseInt($("#" + key).text());
                                    value = (isNaN(val) ? 0 : val) + value
                                    //if (value == 0) {
                                    //    $("#" + key).removeClass('uk-badge-success');
                                    //} else {
                                    //    $("#" + key).addClass('uk-badge-success');
                                    //}
                                    $("#" + key).text(value);
                                })
                            })
                            // call this function recursive
                            _$this.start(time);

                        }, (typeof time === "number") ? time : 1000)
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.getFaceExpressionLoop.start", ex, false);
                    }
                }
                // stop get face expression loop
                _$this.stop = function () {
                    _faceExpressionTimeout.clear();
                }
            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.startGetFaceExpressions", ex, false);
            }
        };

        // handle violation
        _handleViolation = function (violation, screenshot, snapshot) {
            try {
                if (typeof _this.violationConfig[violation] !== "object") {
                    log.LogDetails("Error", "faceApiIntegration.initFaceCountDetection", "Violation config not found", false);
                    return;
                }
                let violationConfig = _this.violationConfig[violation];
                let getscreenrecord = violationConfig.getScreenshot ? violationConfig.getScreenshot : true;
                let getSnapshot = violationConfig.getSnapshot ? violationConfig.getSnapshot : true;
                let screenshotImg = "";
                let snapshotImg = "";

                if (getscreenrecord) {
                    screenshotImg = (screenshot) ? screenshot : _snapShot.getScreenshot();
                }
                if (getSnapshot) {
                    snapshotImg = (snapshot) ? snapshot : _snapShot.getSnapshot();
                }
                if (getscreenrecord || getSnapshot) {
                    _snapShot.saveAndGetUrls(function (result, userobj, inputdata) {
                        // send multiple face detected to tcis
                        _sendToTcis(violation, result.SnapshotUrl, result.ScreenshotUrl);
                    }, {}, snapshotImg, screenshotImg);
                } else {
                    _sendToTcis(violation, "", "");
                }
            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.initFaceCountDetection", ex, false);
            }
        }

        _sendToTcis = function (violation, snapshotUrl, screenshotUrl) {
            try {
                let eventName = violation;

                if (typeof tcisCon !== "undefined" && tcisCon.con.connected) {
                    tcisCon.lastSnapshotUrl = snapshotUrl;
                    tcisCon.lastScreenshotUrl = screenshotUrl;
                    tcisCon.lastViolation = _this.violationConfig[violation].message;
                    switch (violation) {
                        case _this.VIOLATION_NAMES.NO_FACE_DETECTED:
                            eventName = tcisCon.EVENT_NAMES.NO_FACE_DETECTED;
                            break;
                        case _this.VIOLATION_NAMES.MULTIPLE_FACE_DETECTED:
                            eventName = tcisCon.EVENT_NAMES.MULTIPLE_FACE_DETECTED;
                            break;
                        case _this.VIOLATION_NAMES.PHONE_DETECTED:
                            eventName = tcisCon.EVENT_NAMES.PHONE_DETECTED;
                            break;
                        case _this.VIOLATION_NAMES.FACE_AUTHENCATION_FAILED:
                            eventName = tcisCon.EVENT_NAMES.FACE_AUTHENCATION_FAILED;
                            break;
                    }

                    tcisCon.sendEventToService(eventName, snapshotUrl, screenshotUrl);
                } else {
                    tcis_InsertViolation(function (resultdata, userobj, inputdata) {
                        console.log(resultdata);
                    }, {}, eventName, global_AgentID, snapshotUrl, screenshotUrl, "", global_CurrentStatus, eventName)
                }
            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration._sendToTcis", ex, false);
            }
        }

        _this.testLivenessDetection = function (options) {
            try {
                let waitTime = 5000;
                let maxTries = 5;
                let noOfRequiredSuccess = 2;
                let emotionsList = [
                    "happy",
                    "sad",
                    "surprised",
                    "angry"
                ];

                let _triesCount = 0;
                let _successCount = 0;
                let _getEmotionTimeOut = new Timeout();
                let __timerTimeout = 0;
                let takeNewTest = true;
                let html = `
                    <span class="material-icons notranslate" id="lgt_popup_close">clear</span>
                    <div class="uk-grid uk-grid-divider">
					    <div class="uk-width-medium-1-1 uk-row-first">
                            <b>Liveness Detection</b>
                        </div>
                    </div>
                    <hr class="uk-grid-divider">
                    <div id="ldt_popupText" class="ldt-div-center"> Make smiling face</div>
                    <div id="ldt_emogimg" class="ldt-div-center"></div>
                    <p id='ldt_timer' class="ldt-div-center"></p>
                    <div class="uk-grid uk-grid-divider">
					    <div class="uk-width-medium-1-1 uk-row-first">
                            <div class="progressbar-wrapper">
                                <ul id="ldt_progress" class="progressbar">                           
                                </ul>
                            </div>
                        </div>
                    </div>
                    `;
                let popup = UIkit.modal.blockUI(html);
                $("#lgt_popup_close").click(function () {
                    popup.hide();
                    __done(_successCount, _triesCount);
                });
                for (i = 0; i < maxTries; i++) {
                    $("#ldt_progress").append("<li></li>");
                }
                __takeTest(emotionsList[getRandomInt(emotionsList.length)]);
                __showTimer(waitTime / 1000);
                function __takeTest(emotion) {
                    try {
                        if (_triesCount > maxTries || _successCount === noOfRequiredSuccess) {
                            let currentPgChild = $("#ldt_progress li:nth-child(" + _triesCount + ")");
                            if (!currentPgChild.hasClass("active")) {
                                currentPgChild.addClass('danger');
                            }
                            __done(_successCount, _triesCount);
                            return;
                        }
                        let popupTextElement = $("#ldt_popupText");
                        if (takeNewTest) {
                            let currentPgChild = $("#ldt_progress li:nth-child(" + _triesCount + ")");
                            if (!currentPgChild.hasClass("active")) {
                                currentPgChild.addClass('danger');
                            }
                            let emo = emotionsList[getRandomInt(emotionsList.length)];
                            popupTextElement.text("Make " + emo + " face ");
                            $("#ldt_emogimg").html("<img src='components/faceCompare/images/" + emo + ".png' />")
                            _triesCount += 1;
                            _getEmotionTimeOut = new Timeout(function () {
                                takeNewTest = true;
                            }, waitTime);
                            takeNewTest = false;
                            __showTimer(waitTime / 1000);
                            __takeTest(emo);
                        } else {
                            tmac_faceApi.getFaceExpressions(_this.video, 0.4, function (emotions) {
                                if (emotions[emotion] == 1) {
                                    _successCount += 1;
                                    _getEmotionTimeOut.clear();
                                    setTimeout(function () {
                                        takeNewTest = true;
                                        $("#ldt_progress li:nth-child(" + _triesCount + ")").addClass("active");
                                        __takeTest();
                                    }, 1000);
                                } else {
                                    setTimeout(function () {
                                        __takeTest(emotion);
                                    }, 500);
                                }
                            });
                        }
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.testLivlinessDetection.__takeTest", ex, false);
                    }
                }
                function __done(successCount, tries) {
                    try {
                        if (successCount >= noOfRequiredSuccess) {
                            _this.livenessDetectedSuccessful = true;
                            if (typeof options.onSuccess === "function") options.onSuccess(successCount, tries);
                        } else {
                            _handleViolation(_this.VIOLATION_NAMES.LIVENESS_DETECTION_FAILED);
                            if (typeof options.onError === "function") options.onError(successCount, tries);
                        }
                        setInterval(function () {
                            popup.hide();
                            _successCount = 0;
                            _triesCount = 0;
                        }, 1000);
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.testLivlinessDetection.__done", ex, false);
                    }
                }
                function __showTimer(seconds) {
                    try {
                        if (parseInt(seconds) <= 0) return;
                        clearTimeout(__timerTimeout);
                        $("#ldt_timer").text(seconds + " seconds left");
                        __timerTimeout = setTimeout(function () {
                            __showTimer(parseInt(seconds) - 1);
                        }, 1000);
                    } catch (ex) {
                        log.LogDetails("Error", "faceApiIntegration.testLivlinessDetection.__showTimer", ex, false);
                    }
                }

            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.testLivlinessDetection", ex, false);
            }
        }
        function getRandomInt(max) {
            return Math.floor(Math.random() * Math.floor(max));
        }
        _loadHtml();

        _this.load = function () {
            try {

            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.load", ex, false);
            }
        }

        _this.onAgentStatusChange = function (e) {
            try {
                let status = e.Status.toLowerCase();
                if (e.Status === "Available") {
                    // on status changed to available
                    if (_this.IsFaceLivenessDetectionEnabled && !_this.livenessDetectedSuccessful) {
                        // do liveness detection only if enabled and it is not successfull in previous detections
                        _this.testLivenessDetection({
                            onSuccess: function (successCount, maxTries) {
                                _this.doFaceAuthentication({
                                    onError: function () {
                                        ChangeStatus(global_DeviceID, "aux", 0);
                                        _this.livenessDetectedSuccessful = false;
                                    }
                                });
                            },
                            onError: function (successCount, maxTries) {
                                ChangeStatus(global_DeviceID, "aux", 0);
                            }
                        });
                    }
                    _this.emotions.clearDisplay();
                }
                if (status.indexOf("on call") >= 0) {
                    faceApiIntegration.doFaceAuthentication();
                    faceApiIntegration.getFaceExpressionLoop.start();
                } else {
                    faceApiIntegration.getFaceExpressionLoop.stop();
                }

            } catch (ex) {
                log.LogDetails("Error", "faceApiIntegration.onAgentStatusChange", ex, false);
            }
        }

    } catch (ex) {
        log.LogDetails("Error", "faceApiIntegration", ex, false);
    }
};