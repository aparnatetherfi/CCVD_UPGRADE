// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "SnapShotUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    //need not add in versioning as this is a utility component
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

// snapshot object
let _snapShot = new function () {
    let _this = this;
    _this.video = null;
    // enable/disable screenshot feature
    _this.isScreenshotEnabled = false;
    // this flag is to indicate whether screenshot permission is granted
    _this.hasScreenshotPermission = false;
    // enable/disable snapshot feature
    _this.isSnapshotEnabled = false;
    // this flag is to indicate whether snapshot permission is granted

    _this.hasSnapshotPermission = false;
    _this.snapShotAccessCounter = 1;

    _this.isLocationEnabled = false;
    _this.hasLocationPermission = false;
    _this.snapshotVideoConfig = { width: 320, height: 240 };
    _this.screenshotVideoConfig = { width: 320, height: 240 };
    _this.location = {
        longitude: "",
        latitude: ""
    };
    _this._userMedia = navigator.getUserMedia ||
        navigator.webkitGetUserMedia ||
        navigator.mozGetUserMedia ||
        navigator.msGetUserMedia,
        _this.getNotifyHtml = function (type, message, materialIcon) {
            let iconHtml = materialIcon ? `<i class="material-icons notranslate md-color-white">` + materialIcon + `</i>` : "";
            return (
                `<div class="uk-alert uk-alert-` + type + ` uk-animation-slide-top" data-uk-alert>           
                <span>` + iconHtml + ` ` + message + `</span>
             </div>`
            );
        };
    _this.getAgentVerifyPopupHtml = function (profileImage, snapshot, screenshot, ip, isSnapshotEnabled, isScreenshotEnabled, location) {
        let profileHtml = `<img src="` + profileImage + `" style="display: block;margin-left: auto;margin-right: auto;"/>`;
        let snapshotHtml = `<img src="` + snapshot + `"/>`;
        let screenshotHtml = `<img src="` + screenshot + `"/>`;
        let locationHtml = "";

        // if profile image is empty display error message
        if (!profileImage) {
            profileHtml = this.getNotifyHtml("warning", "Profile picture not added", "warning");
        }
        // if snapshot image is empty display error message
        if (!snapshot) {
            snapshotHtml = this.getNotifyHtml("warning", "Permission not allowed to access camera [Feature - " + (isSnapshotEnabled ? "enabled" : "disabled") + "]", "warning");
        }
        // if screenshot image url is empty display error message
        if (!screenshot) {
            screenshotHtml = this.getNotifyHtml("warning", "Permissoin not allowed to share screen [Feature - " + (isScreenshotEnabled ? "enabled" : "disabled") + "]", "warning");
        }

        if (location) {
            // check if leaflet is loaded or not
            if (L) {
                // create div to load map after showni popup
                locationHtml = `<div id="locationMap" style="height: 300px;"></div>`
            } else {
                // library is not loaded display latitude and longitude
                locationHtml = ` <p class="uk-text-primary uk-margin-remove"> Latitude: ` + location.latitude + `</p>
                                 <p class="uk-text-primary uk-margin-remove"> Longitude: ` + location.longitude + `</p>`;
            }

        } else {
            locationHtml = this.getNotifyHtml("warning", "Permission not allowed to access location", "warning");
        }

        return (
            `<div style="height: 85vh;overflow-y: auto;">
				<div class="uk-grid uk-grid-divider">
					<div class="uk-width-medium-1-2 uk-row-first">
						<p class="uk-text-bold uk-margin-remove">Profile Image</p>` + profileHtml + `
					</div>
					<div class="uk-width-medium-1-2">
						<p class="uk-text-bold uk-margin-remove">Snapshot</p>` + snapshotHtml + `
					</div>
				</div>
				<hr class="uk-grid-divider">
				<div class="uk-grid">
					<div class="uk-width-medium-1-1">
						<p class="uk-text-bold uk-margin-remove">Screenshot</p>` + screenshotHtml + `
					</div>
				</div>
				<hr class="uk-grid-divider">
				<div class="uk-grid">
					<div class="uk-width-medium-1-1">
						<font class="uk-text-bold uk-margin-remove">IP: </font>
						<font class="uk-text-primary uk-margin-remove">` + ip + `</font>
					</div>
				</div>
				<hr class="uk-grid-divider">
				<div class="uk-grid">
					<div class="uk-width-medium-1-1">
						<p class="uk-text-bold uk-margin-remove">Location: </p>` + locationHtml + `						
					</div>
				</div>
			</div>`
        );
    };
    _this.init = function () {
        try {
            //check if the feature is enabled
            global_AgentFeatures.forEach(function (item) {
                if (item.Feature === "IsCameraCaptureEnabled" && item.IsEnabled) {
                    _this.isSnapshotEnabled = true;
                }
                if (item.Feature === "IsScreenCaptureEnabled" && item.IsEnabled) {
                    _this.isScreenshotEnabled = true;
                }
                if (item.Feature === "IsLocationEnabled" && item.IsEnabled) {
                    _this.isLocationEnabled = true;
                }
            });
            //check if both the features are not enabled
            if (!_this.isSnapshotEnabled && !_this.isScreenshotEnabled) {
                log.LogDetails("Info", "SnapShotUI.init()", "IsCameraCapture and IsScreenCapture are not enabled!", false);
                return;
            }
            //if snapshot enabled, get the permission
            if (_this.isSnapshotEnabled && !_this.hasSnapshotPermission) {
                // create video element
                this.video = document.createElement("video");
                // make video hidden
                this.video.style.visibility = "hidden";
                // set video to autoplay
                this.video.autoplay = true;
                // append video to body
                document.body.append(this.video);
                // get webcam's video stream
                this._userMedia(
                    { video: _this.snapshotVideoConfig },
                    function (stream) {
                        stream.getVideoTracks()[0].onended = function () {
                            _this.hasSnapshotPermission = false;
                            log.LogDetails("Warning", "SnapShotUI.init()", "Please give access to the camera for supervisor", true);
                            setTimeout(function () {
                                _this.init();
                            }, 1000);
                        };
                        _this.hasSnapshotPermission = true;
                        _this.video.srcObject = stream;
                    },
                    function (err) {
                        //check if the feature is enabled, but the user has disabled
                        if (_this.isSnapshotEnabled) {
                            log.LogDetails("Warning", "SnapShotUI.init()", "Please give access to the camera for supervisor", true);
                            setTimeout(function () {
                                _this.snapShotAccessCounter++;
                                _this.init();
                            }, 4000);
                        }
                        _this.hasSnapshotPermission = false;
                        console.error("Error: [getUserMedia] " + err);
                    }
                );
            }
            // get geolocation
            navigator.geolocation.getCurrentPosition(
                // success
                function (location) {
                    // set location permission is allowed or not
                    _this.hasLocationPermission = true;
                    // get location from browser and save in root object
                    _this.location.latitude = location.coords.latitude;
                    _this.location.longitude = location.coords.longitude
                },
                function (error) {
                    //console.log(error)
                })
            //if snapshot enabled, get the permission
            if (_this.isScreenshotEnabled && !_this.hasScreenshotPermission) {
                // create video element
                this.video1 = document.createElement("video");
                // make video hidden
                this.video1.style.visibility = "hidden";
                // set video tag to autoplay
                this.video1.autoplay = true;
                // append video tag to body
                document.body.append(this.video1);
                // get screen recording stream
                navigator.mediaDevices
                    .getDisplayMedia({ video: _this.screenshotVideoConfig })
                    .then(function (stream) {
                        stream.getVideoTracks()[0].onended = function () {
                            _this.hasScreenshotPermission = false;
                            log.LogDetails("Warning", "SnapShotUI.init()", "Please share your screen for supervisor", true);
                            setTimeout(function () {
                                _this.init();
                            }, 1000);
                        };
                        _this.hasScreenshotPermission = true;
                        _this.video1.srcObject = stream;
                    })
                    .catch(err => {
                        //check if the feature is enabled, but the user has disabled
                        if (_this.isScreenshotEnabled) {
                            log.LogDetails("Warning", "SnapShotUI.init()", "Please share your screen for supervisor", true);
                            setTimeout(function () {
                                _this.init();
                            }, 2000);
                        }
                        _this.hasSnapshotPermission = false;
                        console.error("Error: [getDisplayMedia] " + err);
                    });
            }
        } catch (ex) {
            log.LogDetails("Error", "SnapShotUI.init()", ex, false);
        }
    };
    // get location data
    _this.GetLocation = function () {
        if (!this.hasLocationPermission) {
            return "";
        }
        return this.location;
    };
    // get snapshot from video
    _this.getSnapshot = function () {
        try {
            if (!this.hasSnapshotPermission) {
                return "";
            }
            //create canvas
            let canvas = document.createElement("canvas");
            // set width and height of canvas as same as snapshot video
            canvas.width = this.video.clientWidth;
            canvas.height = this.video.clientHeight;
            // get context of canvas, used to draw on canvas
            let ctx = canvas.getContext("2d");
            // draw snapshot video's current image on canvas
            ctx.drawImage(this.video, 0, 0, this.video.clientWidth, this.video.clientHeight);
            //return canvas base64 string having snapshot image
            return canvas.toDataURL();
        } catch (ex) {
            log.LogDetails("Error", "SnapShotUI.GetSnapshot()", ex, false);
        }
    };
    // get screenshot from video
    _this.getScreenshot = function () {
        try {
            if (!this.hasScreenshotPermission) {
                return "";
            }
            // create canvas
            let canvas = document.createElement("canvas");
            // set width and height of canvas as same as screenshot video
            canvas.width = this.video1.clientWidth;
            canvas.height = this.video1.clientHeight;
            // get context of canvas, used to draw on canvas
            let ctx = canvas.getContext("2d");
            // draw screenshot video's current image on canvas
            ctx.drawImage(this.video1, 0, 0, this.video1.clientWidth, this.video1.clientHeight);
            // return canvas base64 string having screenshot image
            return canvas.toDataURL();
        } catch (ex) {
            log.LogDetails("Error", "SnapShotUI.GetScreenshot()", ex, false);
        }
    };
    // save snapshot and screenshot images in server
    _this.saveImage = function (snapshotImg, screenshotImg, userobject) {
        try {
            // call tmac proxy to save images and get urls of saved images and ip
            tmac_SaveAgentSnapshot(function (resultData, userObject) {
                let data = {};
                if (resultData) {
                    data.status = "success";
                    // get agent profile picture data from login data
                    data.profileImageData = global_successfullyLoggedInData.data.Data.AgtAgentProfileModel ? global_successfullyLoggedInData.data.Data.AgtAgentProfileModel.ProfilePicture : "";
                    data.snapshotUrl = resultData.SnapshotUrl;
                    data.screenshotUrl = resultData.ScreenshotUrl;
                    data.ip = resultData.IP;
                    data.isSnapshotEnabled = _this.isSnapshotEnabled;
                    data.isScreenshotEnabled = _this.isScreenshotEnabled;
                    data.location = _this.GetLocation();
                } else {
                    data.status = "failed";
                }

                //create event data
                var eventData = {
                    EventName: "GenericTMACEvent",
                    SubEventName: "SnapShotReceivedEvent",
                    JsonData: JSON.stringify(data)
                };

                //call server to add event to the supervisor session
                tmac_AddEventToAgentSession(null, {}, userObject.supervisorId, eventData, true, userObject.supervisorTmacServer);

            }, userobject, snapshotImg, screenshotImg);
        } catch (ex) {
            log.LogDetails("Error", "SnapShotUI.SaveImage()", ex, false);
        }
    }

    _this.saveAndGetUrls = function (callback, userobj) {
        try {
            let snapshotImg = _snapShot.getSnapshot();
            let screenshotImg = _snapShot.getScreenshot();
            // save screenshot and snapshot and get urls
            tmac_SaveAgentSnapshot(function (result, obj, inputdata) {
                callback(result, obj, inputdata);
            }, userobj, snapshotImg, screenshotImg);
        } catch (ex) {
            log.LogDetails("Error", "SnapShotUI.saveAndGetUrls()", ex, false);
        }
    };
};

// ----------------------------------------------------------------------------------

// this function will be called from supervisor as postmessage
function SendSnapShotEvent(data) {
    try {
        // this agentid and tmac server id will be used by the other agent to send event back to this agent
        data.supervisorTmacServer = _tmacServer;
        data.supervisorId = global_AgentID;
        //create event data
        var eventData = {
            EventName: "GenericTMACEvent",
            SubEventName: "GetSnapShotEvent",
            JsonData: JSON.stringify(data)
        };
        //call server to add event to the agent session
        tmac_AddEventToAgentSession(null, {}, data.agentId, eventData, true, data.tmacServerId);
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.SendSnapShotEvent()", ex, false);
    }
}

// this function will be called when tmac ui get this event
function GetSnapShotEvent(event) {
    try {
        let JsonData = JSON.parse(event.JsonData);
        // get screenshot
        let screenshotImg = _snapShot.isScreenshotEnabled ? _snapShot.getScreenshot() : "";
        // get snapshot
        let snapshotImg = _snapShot.isSnapshotEnabled ? _snapShot.getSnapshot() : "";
        // call proxy method to save images and get urls and ip
        _snapShot.saveImage(snapshotImg, screenshotImg, JsonData);
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.GetSnapShotEvent()", ex, false);
    }
}

// this function will be called when tmac ui recives this event
function SnapShotReceivedEvent(event) {
    try {
        let JsonData = JSON.parse(event.JsonData);

        // get html text for popup modal
        let html = _snapShot.getAgentVerifyPopupHtml(
            JsonData.profileImageData,
            JsonData.snapshotUrl,
            JsonData.screenshotUrl,
            JsonData.ip,
            JsonData.isSnapshotEnabled,
            JsonData.isScreenshotEnabled,
            JsonData.location
        );
        UIkit.modal.alert(html);

        // check whether leaflet library is loaded
        if (typeof L !== "undefined" && L) {
            // load map container in div
            var mymap = L.map('locationMap').setView([JsonData.location.latitude, JsonData.location.longitude], 13);

            // add the OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap contributors</a>'
            }).addTo(mymap);
            // show a marker on the map
            L.marker({ lon: JsonData.location.longitude, lat: JsonData.location.latitude }).bindPopup('The center of the world').addTo(mymap);
        }

        // send a response to supervisor
        var supervisorIframe = document.getElementById("supervisor_iframe");
        var supervisorWindow = supervisorIframe ? supervisorIframe.contentWindow : null;
        if (supervisorWindow) {
            supervisorWindow.postMessage({
                functionName: "SendSnapShotEventDone",
                data: null,
                appData: null
            }, "*");
        }
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.SnapShotReceivedEvent()", ex, false);
    }
}

// ----------------------------------------------------------------------------------

//to send the capture permission given for screen capture and snap shot
function GetPermissionDetails(data) {
    try {
        // this agentid and tmac server id will be used by the other agent to send event back to this agent
        data.supervisorTmacServer = _tmacServer;
        data.supervisorId = global_AgentID;
        //create event data
        var eventData = {
            EventName: "GenericTMACEvent",
            SubEventName: "GetPermissionDetialsEvent",
            JsonData: JSON.stringify(data)
        };
        //call server to add event to the agent session
        tmac_AddEventToAgentSession(null, {}, data.agentId, eventData, true, data.tmacServerId);
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.GetPermissionDetails()", ex, false);
    }
}

// this function will be called when tmac ui get this event
function GetPermissionDetialsEvent(event) {
    try {
        //parse the json data
        let JsonData = JSON.parse(event.JsonData);

        //get the details
        let data = {
            agentId: global_AgentID,
            isSnapshotEnabled: _snapShot.isSnapshotEnabled,
            hasSnapshotPermission: _snapShot.hasSnapshotPermission,
            isScreenshotEnabled: _snapShot.isScreenshotEnabled,
            hasScreenshotPermission: _snapShot.hasScreenshotPermission,
            isLocationEnabled: _snapShot.isLocationEnabled,
            hasLocationPermission: _snapShot.hasLocationPermission
        };

        //create event data
        var eventData = {
            EventName: "GenericTMACEvent",
            SubEventName: "PermissionDetialsReceivedEvent",
            JsonData: JSON.stringify(data)
        };

        //call server to add event to the supervisor session
        tmac_AddEventToAgentSession(null, {}, JsonData.supervisorId, eventData, true, JsonData.supervisorTmacServer);
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.GetPermissionDetialsEvent()", ex, false);
    }
}

// this function will be called when tmac ui recives this event
function PermissionDetialsReceivedEvent(event) {
    try {
        //parse the json and post message to supervisor to show permission detials
        let jsonData = JSON.parse(event.JsonData);

        let snapshotHtml, shareScreenHtml, locationHtml;
        if (jsonData.isSnapshotEnabled) {
            snapshotHtml = _snapShot.getNotifyHtml("success", "Camera access granted", "done_outline");
            if (!jsonData.hasSnapshotPermission)
                snapshotHtml = _snapShot.getNotifyHtml("danger", "Camera access denied", "block");
        }
        else snapshotHtml = _snapShot.getNotifyHtml("warning", "Snapshot is disabled", "warning");

        if (jsonData.isScreenshotEnabled) {
            shareScreenHtml = _snapShot.getNotifyHtml("success", "Share screen access granted", "done_outline");
            if (!jsonData.hasScreenshotPermission)
                shareScreenHtml = _snapShot.getNotifyHtml("danger", "Share screen access denied", "block");
        }
        else shareScreenHtml = _snapShot.getNotifyHtml("warning", "Screen sharing is not enabled", "warning");

        if (jsonData.isLocationEnabled) {
            locationHtml = _snapShot.getNotifyHtml("success", "Location access granted", "done_outline");
            if (!jsonData.hasLocationPermission)
                locationHtml = _snapShot.getNotifyHtml("danger", "Location access denied", "block");
        } else locationHtml = _snapShot.getNotifyHtml("warning", "Location is not enabled", "warning");
        let popupHtml = `
			<div class="uk-grid">
				<div class="uk-width-medium-1-1 uk-row-first">` + snapshotHtml + shareScreenHtml + locationHtml + `</div>
			</div>`;
        UIkit.modal.alert(popupHtml);

        // send a response to supervisor
        var supervisorIframe = document.getElementById("supervisor_iframe");
        var supervisorWindow = supervisorIframe ? supervisorIframe.contentWindow : null;
        if (supervisorWindow) {
            supervisorWindow.postMessage({
                functionName: "GetPermissionDetailsDone",
                data: null,
                appData: null
            }, "*");
        }
    } catch (ex) {
        log.LogDetails("Error", "SnapShotUI.SnapShotReceivedEvent()", ex, false);
    }
}

// ----------------------------------------------------------------------------------

$(function () {
    _snapShot.init();
});
