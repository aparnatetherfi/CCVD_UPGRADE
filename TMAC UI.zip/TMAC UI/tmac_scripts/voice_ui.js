﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VoiceUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
//----------------------------------------------incoming voice call-------------------------------------------------------
function IncomingVoiceCall(event) {
    try {
        var intid = event.InteractionID;

        if (vipMapping) {
            GetVipData(event.PhoneNumber, "", "", { intId: intid });
        }

        var callbackTransfer = false;
        var callbackSrno = "";
        var srno = "";

        //Check if this is a callback transfer
        if (event.SourceTransferComment) {
            var str = "SRNO";
            var stringToFind = "?";
            var retVal = event.SourceTransferComment.indexOf(str);
            if (retVal >= 0) {
                callbackTransfer = true;
                var ret = event.SourceTransferComment.indexOf(stringToFind);
                callbackSrno = event.SourceTransferComment.substring(5, ret);
                event.SourceTransferComment = event.SourceTransferComment.substring(ret + 2, event.SourceTransferComment.length);
            }
            if (event.SourceTransferComment !== "") {
                ShowNotify('Call Transferred from ' + event.SourceAgentName + ':' + event.SourceTransferComment, "info", null, "top-center");
            }
        }

        //store the UCID globally
        global_UCID[intid] = event.UCID;

        //create a new voice tab
        AddVoiceTab(intid, event.PhoneNumber, callbackTransfer, false, event);

        //set voice references
        if (GetVoiceReferenceObj(intid)) {
            let isManualAnswer = typeof event.IsManualAnswer === "boolean" ? event.IsManualAnswer : false;
            GetVoiceReferenceObj(intid).isManualAnswer = isManualAnswer;
            GetVoiceReferenceObj(intid).processMediaMessages = typeof event.IsManualAnswer === "boolean" ? !isManualAnswer : false;
            GetTabReferenceObj(intid).direction = "in";
            GetVoiceReferenceObj(intid).ucid = event.UCID;

            //for ms agent show the session id and call status
            if (agentType === "MS Agent") {
                $("#v_session_id" + intid).removeClass("uk-display-none");
                $("#v_sessionid_span" + intid).text(event.UCID);
                $("#v_call_status_con" + intid).removeClass("uk-display-none");
                $("#v_connectivity_status_con" + intid).removeClass("uk-display-none");
            }
        }

        //show direction in tab
        $("#voice_call_direction" + intid).text("(IN) ");

        //assign dynamic values
        AssignDynamicValues(event, "voice", "IncomingCallEvent");

        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#voice_accordion' + intid), {
            collapse: false,
            showfirst: true
        });

        var containsPipe = event.UUI ? event.UUI.indexOf("|") : null;
        //If srno is present then its callback call else voice call
        if (event.UUI && !event.IsAgentTransferedCall && containsPipe !== -1) {
            //agent|40192|mukesh|66070|PWEB|1004764
            var splitValues = event.UUI.split("|");
            if (splitValues.length > 2) {
                srno = splitValues[5];
            }
            else {
                srno = splitValues[1];
            }
            if (srno !== "") {
                srno = srno.trim();
                //Store the SRNO  in the related Interaction ID field for further processing on Connect Event
                GetTabReferenceObj(intid).OtherData.srno = srno;
                $("#hdn_srno" + intid).val(srno);
                $("#hdn_transfer_type" + intid).val("Callback");
            }
        }
        else if (callbackTransfer) {
            GetTabReferenceObj(intid).OtherData.srno = callbackSrno;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferRec = true;
            $("#hdn_srno" + intid).val(callbackSrno);
            $("#hdn_transfer_type" + intid).val("Callback");
            callbackTransfer = false;
            //update callback table with the new agent id
            custom_UpdateAgentIdForCallbackTransfer(callbackSrno, intid);
        }
        //check for callback
        if (isCallbackNumber(event.PhoneNumber)) {
            if (srno !== "") {
                IsCallbackCall(intid, srno);
            }
        }
        else if (event.IsAgentTransferedCall) {
            if (callbackSrno !== "") {
                IsCallbackCall(intid, callbackSrno);
            }
        }
        else {
            custom_getData(intid, event.PhoneNumber);
        }
        //set hidden feilds for callback
        SetHiddenFieldCallback(event);

        //disable initially and enable after call answer
        DisableTransferToIVR(intid);

        //enable answer button disable drop,hold,trans,conf buttons
        SetCallControlStatus(intid, true, false, false, "disable", false, false, false, false);

        GetTabReferenceObj(intid).OtherData.CallType = event.CallType;
        if (isVoiceDataWindow && (event.SubType || isCRMEnabled)) {
            OpenVoiceDataWindow(event);
        }

        ShowNotification("You have new incoming call", event.PhoneNumber);

        IncomingVoiceCallCustom(event, callbackTransfer);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IncomingVoiceCall()", ex, false);
    }
}

function OpenVoiceDataWindow(event, frameId) {
    try {
        var intid = event.InteractionID;
        var urlObj = GetServiceWindowURL(event);
        var url = urlObj.url;
        if (urlObj.defaultUrl) {
            url = url + "?autosearch=1&intid=" + intid + "&room=" + phone + "&sourceWindow=voicetab";
        }

        //check if the type is campign, then show frame will handled by campaign selector else show the frame
        if (urlObj.type.toLowerCase() !== "campaign") {
            $("#custom_frame" + intid).removeClass("uk-display-none");
        }

        //if crm then enable scrolling
        if (urlObj.type.toLowerCase() === "crm") {
            $("#ui_custom_frame" + intid).attr("scrolling", "yes");
        }

        $("#custom_frame" + intid).text(urlObj.type);
        LoadIFrame(frameId ? frameId : "ui_custom_frame" + intid, url);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenVoiceDataWindow()", ex, false);
    }
}
//-------------------------------------------------- Check if the call is from Phantom Extension for Callback ---------------------------------------
function IsCallbackCall(intid, srno) {
    try {
        ChangeStatus(global_DeviceID, 'acw', '0');
        DisableCallbackDetailsButtons(event.InteractionID);
        custom_getdetailsforSrno(intid, srno);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IsCallbackCall()", ex, false);
    }
}

function VoiceCallInitiating(event) {
    try {
        global_ConnectionHandle = event.ConnectionHandle;
        //enable the disconnect by handle button
        $("#btndisconnectSpan").removeClass("uk-display-none");
        //if the disconnect by handle is from callback then interachange the drop buttons display
        //as each button has its own purpose
        if (disconnectByHandleType === "callback" && GetTabReferenceObj(global_activeTabInteractionID) !== undefined) {
            //hide DisconnectCall button
            $("#btnDrop" + global_activeTabInteractionID).addClass("uk-display-none");
            //show DisconnectCallByHandle button
            $("#btndisconnectDial" + global_activeTabInteractionID).removeClass("uk-display-none");
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallInitiating()", ex, false);
    }
}

//----------------------------------------------outgoing voice call-------------------------------------------------------
function VoiceOutgoingCallEvent(event) {
    try {
        var intid = event.InteractionID;
        var phoneNumber = event.PhoneNumber;
        //check if its already existing interaction : For Callback outbound dial
        if (!event.IsExistingInteraction) {
            //create a new tab
            AddVoiceTab(intid, phoneNumber, false, false, event);

            $("#voice_call_direction" + intid).text("(OUT) ");
            //Initialize the UIKit accordion for the created tab
            UIkit.accordion($('#voice_accordion' + intid), {
                collapse: false,
                showfirst: true
            });
            global_UCID[intid] = global_OutboundUCID;
            //set the call direction for this tab
            try {
                //set voice references for ms agent - processMediaMessages true as this is outgoing call event
                GetVoiceReferenceObj(intid).processMediaMessages = true;
                GetTabReferenceObj(intid).direction = "out";
                GetTabReferenceObj(intid).OtherData.PhoneNumber = phoneNumber;
                GetVoiceReferenceObj(intid).ucid = event.UCID;

                //for ms agent show the session id and call status
                if (agentType === "MS Agent") {
                    $("#v_sessionid_span" + intid).text(event.UCID);
                    $("#v_call_status_con" + intid).removeClass("uk-display-none");
                    $("#v_connectivity_status_con" + intid).removeClass("uk-display-none");

                    ChangeUICallStatus(intid, "dialing");
                }
            } catch (ex) {
                log.LogDetails("Error", "VoiceUI.VoiceOutgoingCallEvent() - Inside2", ex, false);
            }
        }
        //disable initially and enable after call answer
        DisableTransferToIVR(intid);
        //enable drop button & disable answer,hold,trans,conf buttons
        SetCallControlStatus(intid, false, true, false, "disable", false, false, false, false);
        CloseMakeCallDialog();
        $("#btndisconnectSpan").addClass("uk-display-none");
        if (disconnectByHandleType === "callback" && GetTabReferenceObj(intid) !== undefined) {
            $("#btnDrop" + intid).removeClass("uk-display-none");
            $("#btndisconnectDial" + intid).addClass("uk-display-none");
        }
        global_ConnectionHandle = "";
        var isInternalCallFlag = false;
        isInternalCallFlag = isInternalCall(event.PhoneNumber);
        if (isInternalCallFlag) {
            GetTabReferenceObj(intid).OtherData.CallType = "2";
        }
        VoiceOutgoingCallCustom(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceOutgoingCallEvent()", ex, false);
    }
}

function VoiceCallConnectedEvent(event) {
    try {
        //enable drop,hold,trans,conf buttons, disable answer button
        SetCallControlStatus(event.InteractionID, false, true, true, false, true, true, false, true, true);
        //enable transfer to ivr button
        EnableTransferToIVR(event.InteractionID);
        ChangeTabReferenceStatus(event.InteractionID, 'CallConnected');
        //SIP Dialer Changes - Update the assigned date and assigned time for the callback recieved
        if (GetTabReferenceObj(event.InteractionID).OtherData.srno !== null) {
            var srno = GetTabReferenceObj(event.InteractionID).OtherData.srno;
            custom_updateDataOnConnectForCallback(event.InteractionID, srno);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallConnectedEvent()", ex, false);
    }
}

function VoiceCallDisconnectedEvent(event) {
    try {
        var intId = event.InteractionID;
        GetTabReferenceObj(intId).isCloseTab = true;
        GetTabReferenceObj(intId).status = "CallDisconnected";
        global_CallType = "";
        //if the calltype is 2 then its not a acd call
        if (event.CallType === "2")
            SetCallControlStatus(intId, false, false, false, false, false, false, true, false, false);
        else
            SetCallControlStatus(intId, false, false, false, false, false, false, isEnableCloseTabOnDisconnect.Voice, false, false);
        //remove active for call tab
        $("#li_" + intId).removeClass("li-on-call");
        //close the tab for outbound calls if configured
        if (GetTabReferenceObj(intId).direction === "out" && closeOutboundTab) {
            CloseTab(intId);
        }
        //if IVR transfer is enabled, diable transfer to ivr button
        if (ivrTransferEnabled) DisableTransferToIVR(intId);

        //incoming callback - upon disconnect - enable dial and disable submit
        //incoming callback - upon dial and disconnect - enable dial and enable submit
        //incoming callback transfer - upon disconnect - enable dial and enable submit
        try {
            if (GetTabReferenceObj(intId).type.indexOf("callback") !== -1) {
                if (!GetTabReferenceObj(intId).OtherData.isCallbackTransferInit) {
                    if (GetTabReferenceObj(intId).OtherData.isCallbackTransferRec) {
                        EnableCallbackDialButtons(intId);
                        EnableCallbackSubmitButtons(intId);
                    }
                    else if (!GetTabReferenceObj(intId).OtherData.customMakeCallDone) {
                        EnableCallbackDialButtons(intId);
                        DisableCallbackSubmitButtons(intId);
                    }
                    else {
                        EnableCallbackDialButtons(intId);
                        EnableCallbackSubmitButtons(intId);
                    }
                }
                else {
                    if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferComplete) {
                        DisableCallbackDialButtons(intId);
                        DisableCallbackSubmitButtons(intId);
                    } else {
                        EnableCallbackDialButtons(intId);
                        EnableCallbackSubmitButtons(intId);
                    }
                }
            }
        }
        catch (ex) {
            log.LogDetails("Error", "EventHandler.VoiceCallDisconnectedEvent() - Inside2", ex, false);
        }

        //voice call disconnect custom method
        VoiceCallDisconnectedCustom(event);

        //for POM agent call POM disconnected
        if (isPOM) {
            POMInboundDisconnectEvent(event);
        }

        //if auto timer then clear the timer to stop
        if (autoTimerForTimeTaken) {
            clearInterval(GetTabReferenceObj(intId).tabTimer);
        }

        //  VP: Sep 11, '20: Close dialpad
        $("#dialPadWindow").data("kendoWindow").close();

        //close all the dialog boxes on disconnected
        CloseTransferDialog();
        CloseConfDialog();
        HideConfirmDialog();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallDisconnectedEvent()", ex, false);
    }
}

function VoiceCallTransferInitiatedEvent(event) {
    try {
        //enable complete, cancel buttons on transfer window
        TransferInitiated();
        //check if this is a blind transfer to agent, skip if the transfer is to queue
        if (favListGridItemSelect === "vdnTransfer") {
            var intId = global_transferIntID;
            //blind transfer to agent need to call 'TransferComplete' programmatically
            TransferComplete(global_DeviceID, intId);
            favListGridItemSelect = "";
            VoiceCallTransferInitiatedCustom(intId);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallTransferInitiatedEvent()", ex, false);
    }
}

function AddVoiceTab(intid, phoneNumber, isChatCallback, hasCallback, event) {
    try {
        var tabType = "";
        var callbacktabFlag = false;
        //AddDynamicFields("voice");
        // if phone number is a callback phantom extension, then use Callback Body
        //SIP Dialer - Check for Callback Call - Changed by Mukesh - 8th Aug, 2016
        if (isCallbackNumber(phoneNumber) || isChatCallback || hasCallback) {
            tabType = "phone_callback";
            callbacktabFlag = true;
            var callbackType = "";
            if (isChatCallback) {
                callbackType = "acallback";
            } else if (hasCallback) {
                callbackType = "pcallback";
            } else if (isCallbackNumber(phoneNumber)) {
                callbackType = "scallback";
            }
            SaveTabReference(callbackType, intid, "new");
            SaveVoiceReference(intid, "callback");
            GetTabReferenceObj(intid).OtherData.customMakeCallDone = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferInit = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferComplete = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferRec = false;
        } else {
            tabType = "phone";
            callbacktabFlag = false;
            SaveTabReference('voice', intid, 'new');
            SaveVoiceReference(intid, "voice");
        }
        //tab header content
        var headerTemplate = GetHtmlFromTemplate("tab_header_template", intid, { icon: tabType });
        //tab body content
        //custom object for dynamic tab
        var customObj = {};
        customObj.deviceid = global_DeviceID;
        //give red color for pom customer info
        if (isPOM) customObj.textcolor = "md-color-red-900";
        var bodyTemplate = GetHtmlFromTemplate("voice_tab_body_template", intid, customObj);
        //var bodyTemplate = document.getElementById(divBody).innerHTML;
        //add a kendo tab
        AddTab(bodyTemplate, headerTemplate, intid, phoneNumber, true, false, true);
        if (!callbacktabFlag) {
            //add dynamic feilds
            AddHandlebarDynamicFields("voice", intid);
            $("#VoiceTabData" + intid).toggle(true);
            $("#divCallbackBody" + intid).toggle(false);
            //show/hide voice authentication panel
            $("#div_verified_status" + intid).toggle(isVoiceAuthenticationPanel);
            $("#div_tpin_status" + intid).toggle(isVoiceAuthenticationPanel);
            if (isVoiceAuthenticationPanel) {
                $("#auth_vs_label" + intid).text(voiceAuthenticationLabels.label1);
                $("#auth_tp_label" + intid).text(voiceAuthenticationLabels.label2);
            }
            $("#ddlTransferToIVR" + intid).toggle(ivrTransferEnabled);
            //show/hide IVR transfer button            
            if (ivrTransferEnabled) {
                $.each(ivrTransferMenus, function (i, item) {
                    let ivrTransferLi =
                        '<li type="' + item.type + '">' +
                        '<a class="uk-dropdown-close" style="width:auto;" onclick="IVRTransfer(' + intid + ',\'' + item.value + '\');">' +
                        '<i class="uk-icon-' + item.icon + '"></i>' +
                        '&nbsp;' + item.text +
                        '</a>' +
                        '</li>';
                    $("#ivrTransferMenus" + intid).append(ivrTransferLi);
                });
            }
            //show/hide IVR menus
            $("#ivr_menus" + intid).toggle(isIvrMenuEnabled);
            if (isPOM) {
                POMInboundCallEvent(event);
            }
        }
        else {
            $("#VoiceTabData" + intid).toggle(false);
            $("#divCallbackBody" + intid).toggle(true);
            $("#div_verified_status" + intid).toggle(false);
            $("#div_tpin_status" + intid).toggle(false);
            $("#ddlTransferToIVR" + intid).toggle(false);
            $("#ddl_time" + intid).kendoMaskedTextBox({
                mask: "00:00"
            });
            $("#ddl_time" + intid).data("kendoMaskedTextBox").enable(false);
            $("#ddl_time" + intid).removeClass("k-textbox");
            //append callback option provided in global vars
            $.each(callbackOptions, function (i, item) {
                $("#ddl_status" + intid).append($('<option>', {
                    value: item,
                    text: item
                }));
            });

        }

        // Lets Assign the tabs here
        if (callbacktabFlag) CreatePendingCallbackGrid(intid);

        //show and append data workcodes if configured
        if (isWorkCode.voice && isWorkCode.voice.enable) BindWorkCodes(intid);

        // When call comes, store the start time in the hidden field
        AddCallTimer(intid, "voice", "#hdn_voice_call_starttime" + intid, "#voice_call_starttime" + intid,
            "#voice_call_time_taken" + intid, "#voice_call_span_starttime" + intid, "", "", "", "", "", "");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.AddVoiceTab()", ex, false);
    }
}

function TextChatCallBackEvent(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var interactionid = event.InteractionID;
        var data = {};
        event.UCID = parse.sessionid;
        event.PhoneNumber = "";
        event.CalledDevice = parse.sessionid;
        event.InteractionID = interactionid;
        var sessionid = parse.sessionid;

        //custom textchat callback
        custom_TextChatCallback(sessionid, parse.srno, interactionid);

        //amacTextChatUI.js
        LoadCIF(interactionid, event.UCID);
        custom_LoadUCIDChatToCallback(interactionid, parse.sessionid);

        //create a new tab
        AddVoiceTab(event.InteractionID, event.PhoneNumber, true, false, event);

        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#voice_accordion' + event.InteractionID), {
            collapse: false,
            showfirst: true
        });

        $("#hdn_transfer_type" + event.InteractionID).val("Callback");
        $("#hdn_srno" + event.InteractionID).val(parse.srno);
        isTextChatCallback = true;

        ChangeStatus(global_DeviceID, 'acw', '0');
        DisableCallbackDetailsButtons(event.InteractionID);
        custom_getdetailsforSrno(event.InteractionID, parse.srno);
        //custom_getdetailsforUCID(event.InteractionID, event.UCID);

        //enable answer button
        //disable drop,hold,trans,conf buttons
        SetHiddenFieldCallback(event);
        SetCallControlStatus(event.InteractionID, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TextChatCallBackEvent()", ex, false);
    }
}

function IVRTransfer(intid, type) {
    try {
        var languageid = $("#txtLanguage" + intid).val();
        TransferToIVR(global_DeviceID, intid, type.toLowerCase(), languageid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IVRTransfer()", ex, false);
    }
}

function TransferCall() {
    try {
        if (!CanSendNotification(global_transferIntID)) {
            return;
        }
        DisableButton("#btndialogtransfercall");
        var number = $("#txtNumberTrans").val();
        var comment = $("#txtCommentTrans").val();
        //get the interaction id
        var intId = global_transferIntID;
        var obj = {};
        obj.intId = intId;
        obj.to = number;
        obj.toServer = destTmacServerName;
        obj.buttonId = "#btndialogtransfercall";
        obj.icon = "swap_horiz";
        obj.type = "transfer";

        //check if agent is transferring call to himself
        if (number === global_AgentID) {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Transfer to self is not allowed!", "danger", null, "top-center");
            return;
        }
        if (!number) {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        var otherData = {};
        //check if this is a text chat transfer
        if (global_CallType === "TextChatTransfer") {
            //check if the transfer is queue
            if (favListGridItemSelect === "favItemSelect") {
                //transfer the text chat to queue
                TransferTextChatToQueue(global_DeviceID, intId, number, true, GetChatReferenceObj(intId).chatMode, obj);
            }
            //else is chat transfer to agent
            else {
                otherData.type = "transfer";
                otherData.mode = GetChatReferenceObj(intId).chatMode;
                //send the transfer notification
                SendTextChatTransferNotification(global_DeviceID, intId, number, comment, JSON.stringify(otherData), destTmacServerName, obj);
            }
        }
        //check if this is a fax transfer
        else if (global_CallType === "FaxTransfer") {
            //check if the transfer is queue
            if (favListGridItemSelect === "favItemSelect") {
                otherData = GetFaxReferenceObj(intId).otherData;
                TransferInteractionToQueue(obj, "fax", intId, number, otherData);
            }
            //else is fax transfer to agent
            else {
                obj.channel = "Fax";
                otherData = GetFaxReferenceObj(intId);
                otherData.type = "transfer";
                //send the trasnfer notification
                SendInteractionTransferNotificationToServer(obj, "fax", intId, number, destTmacServerName, comment, JSON.stringify(otherData));
            }
        }
        //else the transfer is voice to agent
        else {
            var val = $("#hdn_transfer_type" + intId).val();
            if (val === "Callback") {
                var srno = $("#hdn_srno" + intId).val();
                comment = "SRNO:" + srno + "? " + comment;
                GetTabReferenceObj(intId).OtherData.isCallbackTransferInit = true;
            }
            //commandManager.js
            TransferCallCommand(global_DeviceID, intId, number, comment, obj);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCall()", ex, false);
    }
}

function TransferCallBlind() {
    try {
        if (!CanSendNotification(global_transferIntID)) {
            return;
        }
        DisableButton("#btndialogblindtransfercall");
        //check if this is a text chat transfer
        //get the interaction id
        var intId = global_transferIntID;
        var number = $("#txtNumberTrans").val();
        var comment = $("#txtCommentTrans").val();
        var textChatFav = "";
        var lineid = "";
        var obj = {};
        obj.intId = intId;
        //set it to 'vdnTransfer' for blind transfer of call/chat to agent
        favListGridItemSelect = "vdnTransfer";
        obj.buttonId = "#btndialogblindtransfercall";
        obj.icon = "BT";
        obj.type = "transfer";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "tag");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        //if the transfer is chat then get the value of 'favListGridItemSelectForChat'
        if (global_CallType === "TextChatTransfer") {
            GetChatReferenceObj(intId).isTransfer = true;
            textChatFav = favListGridItemSelectForChat;
        }
        //if its chat transfer and is queue selected, transfer to queue
        if (textChatFav === "favItemSelect" && global_CallType === "TextChatTransfer") {
            //transfer the text chat to queue
            TransferTextChatToQueue(global_DeviceID, intId, number, true, GetChatReferenceObj(intId).chatMode, obj);
            //clear the value as this is a transfer to queue doest need to call transfer complete on tmacevent_CallTransferInitiatedEvent
            favListGridItemSelect = "";
            return;
        }
        //if its fax transfer and is queue selected, transfer to queue
        else if (favListGridItemSelect === "vdnTransfer" && global_CallType === "FaxTransfer") {
            obj.type = "FaxTransfer";
            obj.channel = "fax";
            otherData = GetFaxReferenceObj(intId).otherData;
            TransferInteractionToQueue(obj, "fax", intId, number, otherData);
            //clear the value as this is a transfer to queue doest need to call transfer complete
            favListGridItemSelect = "";
            return;
        }
        //text chat blind transfer for WQ routing
        else if (global_CallType === "TextChatTransfer" && GetChatReferenceObj(intId).isNonVoiceRouting) {
            obj.type = "TextChatTransfer";
            lineid = "wq";
        }
        //else the transfer is chat/voice to agent
        else {
            lineid = "blind";
        }

        if (global_CallType === "TextChatTransfer") {
            TransferTextChatToServer(global_DeviceID, global_AgentID, intId, number, "", global_UCID[intId], number, lineid, destTmacServerName, "transfer", GetChatReferenceObj(intId).chatMode, obj);
        }
        else {
            //check if the voice transfer and subtype is webrtc then call blind transfer
            if (GetVoiceReferenceObj(intId) && GetVoiceReferenceObj(intId).subType === "webrtc") {
                TransferBlind(global_DeviceID, intId, number, comment, obj);
            }
            else {
                TransferCallCommand(global_DeviceID, intId, number, comment, obj);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCallBlind()", ex, false);
    }
}

function CancelTransfer(cntrl) {
    try {
        if (global_CallType === "Transfer") {
            TransferCancel();
        } else {
            CancelConference();
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CancelTransfer()", ex, false);
    }
}

function TransferCancel() {
    try {
        //get the interaction id
        var intId = global_transferIntID;
        //commandManager.js
        TransferCancelCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCancel()", ex, false);
    }
}

function CompleteTransfer() {
    try {
        if (global_CallType === "Transfer") {
            TransferComplete();
        } else {
            // get the voice reference for the current conferencing interaction
            let vRef = GetVoiceReferenceObj(global_conferenceIntID);
            // check the subtype
            if (vRef && vRef.subType === "webrtc") {
                // for webrtc calls, mix the conference and close the confirm dialog
                HandleConferenceMixer(global_conferenceIntID);
            }
            ConferenceComplete();
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CompleteTransfer()", ex, false);
    }
}

function TransferComplete() {
    try {
        //get the interaction id
        var intId = global_transferIntID;
        //commandManager.js
        TransferCompleteCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferComplete()", ex, false);
    }
}

function TransferInitiated() {
    try {
        //enable complete, cancel buttons on transfer window
        //$('#btnTrCancel').toggle(true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferInitiated()", ex, false);
    }
}

function VoiceCallTransferRemoteConnected() {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallTransferRemoteConnected()", ex, false);
    }
}

function TransferLineDisconnected(data) {
    try {
        //hide the confirm window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        //disable answer button
        if (data.IsMainLine) //in connected state
            SetCallControlStatus(data.InteractionID, false, true, true, false, true, true, false, true);
        else //in hold state
            SetCallControlStatus(data.InteractionID, false, false, false, true, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferLineDisconnected()", ex, false);
    }
}

function CallConference() {
    try {
        if (!CanSendNotification(global_conferenceIntID)) {
            return;
        }
        DisableButton("#btnConfMCall");
        //get the interaction id
        var intId = global_conferenceIntID;
        var number = $("#txtNumberConf").val();
        var comment = "";
        var obj = {};
        obj.intId = intId;
        obj.to = number;
        obj.toServer = destTmacServerName;
        obj.buttonId = "#btnConfMCall";
        obj.icon = "call_split";
        obj.type = "conference";
        //commandManager.js
        if (number === "") {
            EnableButton("#btnConfMCall", "call", "icon");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        if (global_CallType === "TextChatConference") {
            obj.type = "TextChatConference";
            var otherData = {};
            otherData.type = "conf";
            otherData.mode = GetChatReferenceObj(intId).chatMode;
            SendTextChatTransferNotification(global_DeviceID, intId, number, comment, JSON.stringify(otherData), destTmacServerName, obj);
        }
        else {
            // get the voice reference for the current conferencing interaction
            let vRef = GetVoiceReferenceObj(intId);
            // check the subtype
            if (vRef && vRef.subType === "webrtc") {
                // hold the call before conference
                //HoldMSCall(intId);
            }
            ConferenceCall(global_DeviceID, intId, number, comment, obj);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CallConference()", ex, false);
    }
}

function CancelConference() {
    try {
        //get the interaction id
        var intId = global_conferenceIntID;
        //commandManager.js
        ConferenceCancel(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CancelConference()", ex, false);
    }
}

function ConferenceComplete() {
    try {
        //get the interaction id
        var intId = global_conferenceIntID;
        //commandManager.js
        ConferenceCompleteCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceComplete()", ex, false);
    }
}

function ConferenceInitiated() {
    try {
        //enable complete, cancel buttons on Conference window
        //$('#btnConfCancel').toggle(true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceInitiated()", ex, false);
    }
}

function ConferenceRemoteConnected() {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceRemoteConnected()", ex, false);
    }
}

function ConferenceLineDisconnected(data) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        //disable answer button
        SetCallControlStatus(data.InteractionID, false, true, true, false, true, true, false, true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceLineDisconnected()", ex, false);
    }
}

function ConferenceCompleted(data) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        // get the voice reference for the current conferencing interaction
        let vRef = GetVoiceReferenceObj(data.InteractionID);
        // check the subtype
        if (vRef && vRef.subType === "webrtc") {
            // hold the call before conference
            //UnHoldMSCall(data.InteractionID);
        }
        else {
            // disable answer button for CTI calls
            SetCallControlStatus(data.InteractionID, false, true, true, false, true, true, false, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceCompleted()", ex, false);
    }
}

function OpenTransferDialog(intid) {
    try {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        EnableButton("#btndialogblindtransfercall", "BT", "tag");
        GetTmacWallboardSkills();
        GetAgentListStaffed(intid, "transferCall", "#btnTrans" + intid, "swap_horiz");
        DisableButton("#btnTrans" + intid);
        global_transferIntID = intid;
        //transfer type changed to voice
        global_CallType = "Transfer";
        //remove read only for voice transfer
        $("#txtNumberTrans").removeAttr("readonly", "readonly");
        //select the first agent list tab
        $("#tabstrip_transfer").data("kendoTabStrip").select(0);
        //check for the config to enable comments
        if (commentOnTransfer.Voice) {
            $("#transfer_comments").removeClass("uk-visibility-hidden");
        }
        $("#transfer_dialog").data("kendoWindow").title("Transfer Call List");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenTransferDialog()", ex, false);
    }
}

function TransferCallEvent(event) {
    try {
        if (event.keyCode === 13) {
            TransferCall();
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCallEvent()", ex, false);
    }
}

function OpenConferenceDialog(intid) {
    try {
        GetAgentListStaffed(intid, "conferenceCall", "#btnConf" + intid, "group");
        DisableButton("#btnConf" + intid);
        global_conferenceIntID = intid;
        global_CallType = "Conference";
        $("#conference_dialog").data("kendoWindow").title("Conference Call List");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenConferenceDialog()", ex, false);
    }
}

function ConferenceCallEvent(event) {
    try {
        if (event.keyCode === 13) {
            conferenceCall();
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceCallEvent()", ex, false);
    }
}

function HideConfirmDialog() {
    try {
        $("#confirm_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.HideConfirmDialog()", ex, false);
    }
}

function CloseTransferDialog() {
    try {
        $("#transfer_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseTransferDialog()", ex, false);
    }
}

function CloseConfDialog() {
    try {
        $("#conference_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseConfDialog()", ex, false);
    }
}

function OpenConfirmDialog(type) {
    try {
        if (type === "transfer")
            CloseTransferDialog();
        else if (type === "conference")
            CloseConfDialog();
        else if (type === "pom")
            ClosePOMTransConfDialog();
        $("#confirm_dialog").data("kendoWindow").center().open();
        $('#btnDone').addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenConfirmDialog()", ex, false);
    }
}

function OpenMakeCallDialog() {
    try {
        if (isPOM && agentType === "AutoDialer") {
            POMMakeCall();
        }
        else {
            //ReviewCodeLine
            //DisableButton(".btn-make-call");
            GetAgentListStaffed("", "makeCall", "", "");
            global_CallType = "MakeCall";
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenMakeCallDialog()", ex, false);
    }
}

function MakeCallEvent(event) {
    try {
        if (event.keyCode === 13) {
            MakeCall(global_DeviceID, '', 'makecall');
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.MakeCallEvent()", ex, false);
    }
}

function CloseMakeCallDialog() {
    try {
        $("#make_call_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseMakeCallDialog()", ex, false);
    }
}

function OpenDialPad(intId) {
    try {
        //  To check if no other dial pad is open of other interaction
        if (dialPadInteractionId !== 0 && intId != dialPadInteractionId) {
            log.LogDetails("Info", "VoiceUI.OpenDialPad()", "Dial pad from other call is open. Close it and open again.", false);
            return;
        }

        $("#txtDialPad").val("");
        $("#dialPadWindow").data("kendoWindow").center().open();
        dialPadInteractionId = intId;
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenDialPad()", ex, false);
    }
}

function sendDtmfFromDialPad(tone) {
    try {
        if (aConn == null || aConn.length < 1) {
            log.LogDetails("Warn", "VoiceUI.sendDtmfFromDialPad()", "A Conn is null.", false);
            return;
        }
        //  Get session ID of this interaction
        let sessionId = GetVoiceReferenceObj(dialPadInteractionId).msSessionId;
        //  Get audio conn obj
        let callCon = GetAConnRef(sessionId);

        //  Send DTMF
        let played = callCon.conn.sendDtmf(tone);
        //  PLay DTMF tones to agent on success for ACK
        if (played) {
            if (tone === 100)
                tone = "STAR";
            else if (tone === 101)
                tone = "POUND";

            new Audio("assets/sound/dtmf/DTMF_" + tone + ".wav").play();
            if (tone === "STAR")
                tone = "*";
            else if (tone === "POUND")
                tone = "#";

            //  Show DTMF to textbox
            $("#txtDialPad").val($("#txtDialPad").val() + tone.toString());
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.sendDtmfFromDialPad()", ex, false);
    }
}

function GetQueueTimeForUCID(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        if (parse.cumulativequeuetime !== "0:0:0") {
            if (parse.dbQueueTime !== "0:0:0") {
                var colorCode = GetColorCode(parse.dbQueueTime);
                if (parse.blindTransferFlag) {
                    document.getElementById('txtQueueTime' + event.InteractionID).value = parse.cumulativequeuetime + "s / " + parse.diffTime + "s";
                }
                //document.getElementById('txtQueueTime' + event.InteractionID).style.backgroundColor = colorCode;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.GetQueueTimeForUCID()", ex, false);
    }
}

function SetCallControlStatus(intid, answer, drop, hold, unhold, trans, conf, tabClose, mute, dialPad) {
    try {
        if (answer === false) {
            $('#btnAnswer' + intid).addClass('disabled');
        } else {
            $('#btnAnswer' + intid).removeClass('disabled');
        }

        if (drop === false) {
            $('#btnDrop' + intid).addClass('disabled');
        } else {
            $('#btnDrop' + intid).removeClass('disabled');
        }

        if (trans === false) {
            $('#btnTrans' + intid).addClass('disabled');
        } else {
            $('#btnTrans' + intid).removeClass('disabled');
        }

        if (conf === false) {
            $('#btnConf' + intid).addClass('disabled');
        } else {
            $('#btnConf' + intid).removeClass('disabled');
        }

        if (!dialPad) {
            $('#btnDialPad' + intid).addClass('disabled');
        } else {
            $('#btnDialPad' + intid).removeClass('disabled');
        }

        if (tabClose === true) {
            if (global_CallType !== "Transfer") {
                EnableTabCloseButton(intid);
            }
        }

        //check for the subtype of interaction
        if (GetVoiceReferenceObj(intid) && GetVoiceReferenceObj(intid).subType === "webrtc") {
            //show the button if hidden
            if ($("#btnMute" + intid).hasClass("uk-display-none")) {
                $("#btnMute" + intid).removeClass("uk-display-none");
            }
            //check for mute
            if (mute === false) {
                $('#btnMute' + intid).addClass('disabled');
            } else {
                $('#btnMute' + intid).removeClass('disabled');
            }
        }

        //check if this is a callback tab. Then enable both PCN dial and CID buttons
        if (!answer && !drop && !hold && !unhold) {
            try {
                //var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferInit;
                var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferInit;
                if (val) {
                    EnableTabCloseButton(intid);
                    DisableCallbackSubmitButtons(intid);
                } else {
                    EnableCallbackDialButtons(intid);
                }
            } catch (ex) {
                log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside1", ex, false);
            }
        }

        //disable callback button
        try {
            $('#btnCallback' + intid).addClass('disabled');
        } catch (ex) {
            log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside2", ex, false);
        }

        try {
            if (!hold && !unhold) {
                $('#btnHold' + intid).css("display", "inline-block");
                $('#btnUnHold' + intid).css("display", "none");
                $('#btnHold' + intid).addClass('disabled');
            } else if (hold) {
                $('#btnHold' + intid).css("display", "inline-block");
                $('#btnUnHold' + intid).css("display", "none");
                $('#btnHold' + intid).removeClass('disabled');
            } else if (unhold !== "disable") {
                $('#btnUnHold' + intid).css("display", "inline-block");
                $('#btnHold' + intid).css("display", "none");
                $('#btnUnHold' + intid).removeClass('disabled');
            } else {
                $('#btnUnHold' + intid).css("display", "inline-block");
                $('#btnHold' + intid).css("display", "none");
                $('#btnUnHold' + intid).addClass('disabled');
            }
        } catch (ex) {
            log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside3", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetCallControlStatus()", ex, false);
    }
}

function SetIVRData(data) {
    try {
        if (data !== null) {
            AssignDynamicValues(data, "voice", "IVRDataEvent");
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetIVRData()", ex, false);
    }
}

function GetTimeInSeconds(queueTime) {
    try {
        var hms = queueTime;
        var a = hms.split(':');
        var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
        return seconds;
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.GetTimeInSeconds()", ex, false);
    }
}

function SetUUIData(data) {
    try {
        if (data !== null) {
            AssignDynamicValues(data, "voice", "UUIDataEvent");
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetUUIData()", ex, false);
    }
}

function ShowVIPMessage(data, obj) {
    try {
        var intid = obj.intId;
        var message = data[0].OtherData;
        HandleIMs(intid, message, "info", "", "", false);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ShowVIPMessage()", ex, false);
    }
}

function MediaServerEventReceived(event) {
    try {
        let intId = event.InteractionID;
        let sessionId = event.SessionID;

        log.LogDetails("Info", "VoiceUI.MediaServerEventReceived", "[" + event.Type + "] received - " + sessionId, false);

        //ReviewCodeLine
        console.log(`%c[${event.Type}]received - ${sessionId}`, "color: #fff; background: #1976d2");

        if (!GetVoiceReferenceObj(intId)) {
            log.LogDetails("Error", "VoiceUI.MediaServerEventReceived: voice tab doesn't exist, do not process", false);
            return;
        }

        //flag to check if the messages can be processed
        let startProcessing = GetVoiceReferenceObj(intId).processMediaMessages;

        if (event.Type === "call-received") {
            //start the av connection
            StartAudioConnection(intId, sessionId, "in");

            //get the connection by sessionId
            let getCon = GetAConnRef(sessionId);

            //check if the aConnection exist and send offer
            if (getCon && getCon.conn) {
                getCon.conn.startDirect(WrcCallTypes.Audio, 'in');
                StartTone("incoming", true);
            }

            ChangeUICallStatus(intId, sessionId, "incoming");
        }
        else if (event.Type === "offer") {
            //
        }
        else if (event.Type === "call-connecting") {
            //start the av connection
            StartAudioConnection(intId, sessionId, "out");

            //change the status
            ChangeUICallStatus(intId, sessionId, "ringing");

            //get the connection by sessionId
            let getCon = GetAConnRef(sessionId);

            //check if the aConnection exist and send offer
            if (getCon && getCon.conn) {
                getCon.conn.startDirect(WrcCallTypes.Audio);
                StartTone("ringing", true);
            }
        }
        else if (event.Type === "call-connected") {
            ChangeUICallStatus(intId, sessionId, "connected");
            ClearTone();
        }
        else if (event.Type === "eventav") {
            //parse the event message
            let evtMsg = JSON.parse(event.Message);

            //get the connection by sessionId
            let getCon = GetAConnRef(sessionId);

            //update the last event
            getCon.events.push(evtMsg.event);

            if (evtMsg.event) {
                //ReviewCodeLine
                console.log(`%c[eventav - ${evtMsg.event}]received - ${sessionId}`, "color: #fff; background: #f00");
                switch (evtMsg.event) {
                    case "connected":
                        //check if 'call-connected' came already
                        //else it can be initial establishment
                        if (getCon.events.indexOf("call-connected") >= 0) {
                            //connection success
                            ChangeUICallStatus(intId, sessionId, "connected");
                        }
                        break;
                    case "call-held":
                        //call hold success
                        ChangeUICallStatus(intId, sessionId, "onhold");
                        break;
                    case "call-resumed":
                        //call resume success
                        ChangeUICallStatus(intId, sessionId, "connected");
                        break;
                    case "disconnected":
                        ChangeUICallStatus(intId, sessionId, "disconnected");
                        break;
                    case "call-ended":
                        // check if the call-ended fromconference agent
                        if (GetVoiceReferenceObj(intId).msTransConfSessionId === sessionId) {
                            // hide the confirm dialog if opened
                            HideConfirmDialog();
                        }
                        StartTone("hung-up", false);
                        ChangeUICallStatus(intId, sessionId, "ended");
                        //close the connection
                        CloseAConn(sessionId);
                        break;
                    default:
                        break;
                }
            }
        }

        //to send WebRTC signals
        if (sendWebRTCInfo.signals) {
            SendWebRTCInfo(intId, "webrtcsignals", "customer", event.Message, sessionId);
        }

        //get the connection by sessionId
        let getCon = GetAConnRef(sessionId);

        //check if the aConnection exist
        if (getCon && getCon.conn) {
            //check if the messages can be processed by WebRTC API, if not add to the reference and process after answer call
            if (startProcessing) {
                //update the last event
                if (event.Type !== "eventav") getCon.events.push(event.Type);
                //send the AV sdk
                getCon.conn.onMessage(event.Message); //process video messages [answers, candidates etc.]
            }
            else {
                GetVoiceReferenceObj(intId).mediaMessageRef.push(event.Message);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.MediaServerEventReceived()", ex, false);
    }
}

function StartAudioConnection(intId, sessionId, direction) {
    try {
        //add the reference
        GetVoiceReferenceObj(intId).subType = "webrtc";

        //check if the direction is out and check if this is a consult transfer call
        //to indentify its a transfer call we just need to check if msSessionId for the interaction reference is already assigned
        if (direction === "out" && GetVoiceReferenceObj(intId).msSessionId) {
            //update the msTransConfSessionId
            GetVoiceReferenceObj(intId).msTransConfSessionId = sessionId;
            // set the line mode
            GetVoiceReferenceObj(intId).msLineMode = global_transferIntID ? "transfer" : "conference";
        }
        //new voice out call
        else {
            //update the msSessionId
            GetVoiceReferenceObj(intId).msSessionId = sessionId;
            // set the line mode
            GetVoiceReferenceObj(intId).msLineMode = "single";
        }

        var conn = {};

        //create the AV connection by calling AVChannel constructor
        conn = new AVChannel(
            intId,
            global_AgentID,
            global_AgentName,
            sessionId,
            "voice"
        );

        //on connection connected
        conn.onConnected = function () {
            log.LogDetails("info", "VoiceUI.StartAudioConnection()", "onConnected", false);
            //show the mute button and active it
            SetCallControlStatus(event.InteractionID, false, true, true, false, true, true, false, true, true);
        };

        //on connection disconnected
        conn.onDisconnected = function () {
            log.LogDetails("info", "VoiceUI.StartAudioConnection()", "onDisconnected", false);
            // check if the disconnect is for transfer/confernece call
            if (GetVoiceReferenceObj(intId).msTransConfSessionId === this.getSessionId()) {
                log.LogDetails("info", "VoiceUI.StartAudioConnection()", "disconnect received for transfer/conference call", false);
            }
            else {
                //get the connection by sessionId
                let getCon = GetAConnRef(this.getSessionId());
                //check if endav processed
                if (getCon && getCon.events.indexOf("endav") < 0) {
                    //call disconnect call in server
                    tmac_DisconnectCall(null, null, global_DeviceID, intId);
                    //change the call status to disconnected
                    ChangeUICallStatus(intId, this.getSessionId(), "disconnected");
                }
            }

            // close the connection but do not end the call
            CloseAConn(this.getSessionId());

            // clear tone of disconnect on dial or incoming
            ClearTone();
        };

        //on connection remote video added
        conn.onRemoteVideoAdded = function (stream, streamInfo) {
        };

        //on hold or unhold
        conn.onHoldUnhold = function (hold) {
            log.LogDetails("Info", "VoiceUI.StartAudioConnection: onHoldUnhold - " + hold, false);
        };

        //to send the WebRTC messages
        conn.sendMessage = function (msg, type, sessionId) {
            SendAVControlMessage(global_DeviceID, intId, msg, type, sessionId);
        };

        //the transport to send WebRTC stats
        conn.onCollectorStats = function (result) {
            // get the voice reference
            let voiceRef = GetVoiceReferenceObj(intId);

            // show mos and send stats for customer session only
            if (!voiceRef || this.getSessionId() !== GetVoiceReferenceObj(intId).msSessionId) {
                return true;
            }

            //get the mos value form stats
            let mos = result.stats.audio.local.mos;

            //store the mos value in reference
            GetVoiceReferenceObj(intId).mos = mos;

            //show the 'mos' value
            ShowMOSValue(intId, mos);

            // check whether to send stats to TMC
            if (!sendWebRTCInfo.stats) {
                return true;
            }

            // check if webrtc TMC stats is integrated
            let sConn = GetSRConnection("webrtc");

            // check if webrtc stats monitor is available
            if (!sConn || !sConn.connected) {
                console.warn("srConn[webrtc] is not created/connected - " + this.getSessionId());
                return true;
            }

            //send the stats to TMC
            sConn.hub.invoke("storeMetrics", result.stats, result.tagKeys, result.tagValues);
            return true;
        };

        // to send audio stats
        conn.sendAVStats = function (stats) {
            avWebRTCCommStats.init();
            avWebRTCCommStats.add(stats, intId);
        };

        //on connection trace
        conn.onTrace = function (msg) {
            log.LogDetails("Info", "VoiceUI.StartAudioConnection()", msg, false);
        };

        //on connection error
        conn.onError = function (errorMsg) {
            log.LogDetails("Error", "VoiceUI.StartAudioConnection()", errorMsg, false);
            //to send WebRTC errors
            if (sendWebRTCInfo.errors) {
                SendWebRTCInfo(intid, "webrtcerrors", "webrtc", errorMsg, sessionId);
            }
        };

        // create the av layout
        conn._remoteVideo = new VideoLayout(document.getElementById("remoteAudio" + intId));

        //add to the connection reference
        AddAConnRef(sessionId, intId, conn, direction);

    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.StartAudioConnection()", ex, false);
    }
}

function CloseAConn(sessionId) {
    try {
        //get the connection by session id
        let getConn = GetAConnRef(sessionId);
        //check if connection exist
        if (getConn && getConn.conn) {
            //close the aConn
            getConn.conn.close();
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseAConn()", ex, false);
    }
}

function ProcessMediaMessages(intId) {
    try {
        // check if the tab is created
        if (!GetVoiceReferenceObj(intId)) {
            log.LogDetails("Error", "VoiceUI.ProcessMediaMessages: voice tab doesn't exist, do not process", false);
            return;
        }

        //get the session id
        let sessionId = GetVoiceReferenceObj(intId).msSessionId;

        //get the connection by sessionId
        let getCon = GetAConnRef(sessionId);

        //check if the aConnection exist
        if (getCon && getCon.conn) {
            //loop the message references and process each
            GetVoiceReferenceObj(intId).mediaMessageRef.forEach(function (item) {
                getCon.conn.onMessage(item);
            });

            //clear the media messages reference after processing
            GetVoiceReferenceObj(intId).mediaMessageRef = [];
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ProcessMediaMessages()", ex, false);
    }
}

function AddAConnRef(sessionId, intId, conn, direction) {
    try {
        log.LogDetails("Info", "VoiceUI.AddAConnRef()", "add reference for " + sessionId, false);
        let aConnRef = {
            intId: intId,
            sessionId: sessionId,
            direction: direction,
            conn: conn,
            isHold: false,
            isMuted: false,
            events: []
        };
        aConn.push(aConnRef);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.AddAConnRef()", ex, false);
    }
}

function GetAConnRef(sessionId) {
    try {
        let ref = aConn.filter(function (v) { return v.sessionId === sessionId; });
        if (ref.length > 0) {
            return ref[0];
        }
        else {
            log.LogDetails("Info", "VoiceUI.GetAConnRef()", "reference for " + sessionId + " is null", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.GetAConnRef()", ex, false);
    }
    return null;
}

function RemoveAConnRef(intId) {
    try {
        log.LogDetails("Info", "VoiceUI.RemoveAConnRef()", "remove reference, intId=" + intId, false);
        aConn = aConn.filter(function (v) { return v.intId !== intId; });
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.RemoveAConnRef()", ex, false);
    }
}

function HoldMSCall(intId) {
    try {
        // get the voice reference
        let vRef = GetVoiceReferenceObj(intId);

        // check if the reference is available
        if (!vRef) {
            return;
        }

        //get the session id
        let sessionId = vRef.msSessionId;
        //get the connection by sessionId
        let getCon = GetAConnRef(sessionId);
        //check if the aConnection exist
        if (getCon && getCon.conn && !getCon.isHold) {
            getCon.conn.hold();
            getCon.isHold = true;
        }

        // check if there is a conference line then hold that line also
        let confSessionId = vRef.msLineMode === "conference" ? vRef.msTransConfSessionId : "";
        // check if the session is there
        if (!confSessionId) {
            return;
        }

        // get the connection reference
        let getConfCon = GetAConnRef(confSessionId);
        // check if the connection exist
        if (getConfCon && getConfCon.conn && !getConfCon.isHold) {
            getConfCon.conn.hold();
            getConfCon.isHold = true;
        }

    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.HoldMSCall()", ex, false);
    }
}

function UnHoldMSCall(intId) {
    try {
        // get the voice reference
        let vRef = GetVoiceReferenceObj(intId);

        // check if the reference is available
        if (!vRef) {
            return;
        }

        //get the session id
        let sessionId = vRef.msSessionId;
        //get the connection by sessionId
        let getCon = GetAConnRef(sessionId);
        //check if the aConnection exist
        if (getCon && getCon.conn && getCon.isHold) {
            getCon.conn.unHold();
            // getCon.isHold = false;
        }

        // check if there is a conference line then hold that line also
        let confSessionId = vRef.msLineMode === "conference" ? vRef.msTransConfSessionId : "";
        // check if the session is there
        if (!confSessionId) {
            return;
        }

        // get the connection reference
        let getConfCon = GetAConnRef(confSessionId);
        // check if the connection exist
        if (getConfCon && getConfCon.conn && getConfCon.isHold) {
            getConfCon.conn.unHold();
            // getConfCon.isHold = false;
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.UnHoldMSCall()", ex, false);
    }
}

function MuteUnMuteMSCall(intId) {
    try {
        // get the voice reference
        let vRef = GetVoiceReferenceObj(intId);

        // check if the reference is available
        if (!vRef) {
            return;
        }

        //get the session id
        let sessionId = vRef.msSessionId;
        //get the connection by sessionId
        let getCon = GetAConnRef(sessionId);

        //check if the aConnection exist
        if (getCon && getCon.conn) {
            // check if there is a conference line then hold that line also
            let confSessionId = vRef.msLineMode === "conference" ? vRef.msTransConfSessionId : "";
            // get the connection reference
            let getConfCon = GetAConnRef(confSessionId);
            //get the button reference
            let btn = "#btnMute" + intId;
            //check if muted, then unmute
            if ($(btn).hasClass("muted")) {
                $(btn).removeClass("muted");
                $(btn).removeClass("md-btn-success");
                $(btn).addClass("md-btn-danger");
                $(btn).attr("title", "Mute Call");
                // check if muted then unmute
                if (getCon.isMuted) {
                    getCon.conn.unMute(true, false);
                    getCon.isMuted = false;
                }
                // check if conference connection is there, then process for confernece line also
                if (getConfCon && getConfCon.conn && getConfCon.isMuted) {
                    getConfCon.conn.unMute(true, false);
                    getConfCon.isMuted = false;
                }
                ChangeUICallStatus(intId, sessionId, "connected");
            }
            //check if unmute, then mute
            else {
                $(btn).addClass("muted");
                $(btn).removeClass("md-btn-danger");
                $(btn).addClass("md-btn-success");
                $(btn).attr("title", "UnMute Call");
                // check if unmuted then mute
                if (!getCon.isMuted) {
                    getCon.conn.mute(true, false);
                    getCon.isMuted = true;
                }
                // check if conference connection is there, then process for confernece line also
                if (getConfCon && getConfCon.conn && !getConfCon.isMuted) {
                    getConfCon.conn.mute(true, false);
                    getConfCon.isMuted = true;
                }
                ChangeUICallStatus(intId, sessionId, "mute");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.MuteUnMuteMSCall()", ex, false);
    }
}

function ChangeUICallStatus(intId, sessionId, type) {
    try {

        //check if the interaction reference is there, if not return
        if (!GetVoiceReferenceObj(intId)) {
            return;
        }

        //get the session id
        let mainSessionId = GetVoiceReferenceObj(intId).msSessionId;

        //check if the session is same
        //this change call status can come for transfer call also, so we can ignore
        if (sessionId !== mainSessionId) {
            return;
        }

        $("#v_call_status" + intId).removeClass();
        $("#v_call_status" + intId).addClass("uk-badge");
        GetVoiceReferenceObj(intId).callStatus = type;
        let statusType = "";
        switch (type) {
            case "dialing":
                $("#v_call_status" + intId).text("Dialing...");
                $("#v_session_id" + intId).removeClass("uk-display-none");
                $("#v_call_status" + intId).removeClass("uk-display-none");
                break;
            case "incoming":
                $("#v_call_status" + intId).text("Incoming");
                statusType = " loading";
                break;
            case "ringing":
                $("#v_call_status" + intId).text("Ringing");
                statusType = "primary loading";
                break;
            case "connected":
                $("#v_call_status" + intId).text("Connected");
                $("#v_connectivity_status_con" + intId).addClass("blink-connection");
                statusType = "success";
                break;
            case "onhold":
                $("#v_call_status" + intId).text("On Hold");
                statusType = "warning";
                break;
            case "mute":
                $("#v_call_status" + intId).text("Muted");
                statusType = "warning";
                break;
            case "disconnected":
                $("#v_call_status" + intId).text("Disconnected");
                $("#v_connectivity_status_con" + intId).removeClass("blink-connection");
                ShowMOSValue(intId, -1);
                statusType = "danger";
                break;
            case "ended":
                $("#v_call_status" + intId).text("Ended");
                $("#v_connectivity_status_con" + intId).removeClass("blink-connection");
                ShowMOSValue(intId, -1);
                statusType = "danger";
                break;
            default:
                $("#v_call_status" + intId).text("NA");
        }

        if (statusType) {
            $("#v_call_status" + intId).addClass("uk-badge-" + statusType);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ChangeUICallStatus()", ex, false);
    }
}

function StartTone(type, isRepeat) {
    try {
        //if tone is disabled dont play
        if (!isToneEnabled) {
            return;
        }
        //clear if any interval
        clearInterval(_audioInterval);
        //start dial tone
        _audio = new Audio("assets/sound/" + type + ".mp3");
        //play once
        _audio.play();
        //if repeat then loop it
        if (isRepeat) {
            //start interval
            _audioInterval = setInterval(function (x) {
                x.play();
            }, 5000, _audio);
        }
        //set the volume 
        _audio.volume = toneRange / 100;
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.StartTone()", ex, false);
    }
}

function ClearTone() {
    try {
        if (_audio) {
            _audio.pause();
        }
        clearInterval(_audioInterval);
        _audioInterval = null;
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ClearTone()", ex, false);
    }
}

function HandleConferenceMixer(intId) {
    try {
        let vRef = GetVoiceReferenceObj(intId);

        if (!vRef) {
            log.LogDetails("Error", "VoiceUI.HandleConferenceMixer()", "Interaction reference not found, intId=" + intId, false);
            return;
        }
        // get the sessionIds
        let mainSessionId = vRef.msSessionId;
        let confSessionId = vRef.msTransConfSessionId;

        // get the session reference based on sessionIds
        let mainSession = GetAConnRef(mainSessionId);
        let confSession = GetAConnRef(confSessionId);

        // check if the referece is found, else return
        if (!mainSession || !confSession) {
            log.LogDetails("Error", "VoiceUI.HandleConferenceMixer()", "Session reference not found, mainSessionId=" + mainSessionId + ", confSessionId=" + confSessionId, false);
            return;
        }

        // add the conference peer connection to the conference
        mainSession.conn.addConference(confSession.conn._pc);

    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.HandleConferenceMixer()", ex, false);
    }
}