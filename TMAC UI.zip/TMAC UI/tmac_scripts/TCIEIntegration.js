// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TCIEIntegration.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

$(function () {
    console.log('TCIEIntegration js loaded');
});


var _tcieIntegration = new function () {
    try {
        let _this = this;
        let _config = {
            displayType: "iframe", //iframe/window
            width: 400,
            height: 400,
            tcieurl: AppConfigs.Remote.URLs.TCIE,
            title: "TCIE",
            monitorInterval: 2000
        };
        // this is reference to tcie window 
        let _tcieWindow;
        let _popup;
        window.onload = function () {
            try {
                openTcieWindow();
                listenToPostMessage();
            } catch (ex) {
                _log.error(ex);
            }
        };

        let openTcieWindow = function () {
            try {
                if (_config.displayType === "iframe") {
                    loadPopup();
                } else if (_config.displayType === "window") {
                    _tcieWindow = window.open(_config.tcieurl, _config.title, "height=" + _config.height + ",width=" + _config.width);
                    monitorWindow();
                }
            } catch (ex) {
                _log.error(ex);
            }
        };

        // this is recursive timeout function
        // keep checking whether tcie window is closed every 
        // reopen tcie window if it is closed
        let monitorWindow = function () {
            try {
                setTimeout(function () {
                    if (_tcieWindow.closed) {
                        openTcieWindow();
                    } else {
                        monitorWindow();
                    }
                }, _config.monitorInterval)
            } catch (ex) {
                _log.error(ex);
            }
        }

        // listen to post message
        let listenToPostMessage = function () {
            try {
                window.addEventListener("message", onPostMessage);
            } catch (ex) {
                _log.error(ex);
            }
        };

        // genric function to send post message
        // mthod is mandatory
        let sendPostMessage = function (method, data, callback) {
            try {
                // return if method is invalid
                if (!method || typeof method !== "string") {
                    return;
                }
                let jsonData = JSON.stringify({
                    source: "tmac",
                    function: method,
                    data: data,
                    callback: callback ? callback : "",
                });
                _tcieWindow.postMessage(jsonData, _config.tcieurl);
            } catch (ex) {
                _log.error(ex);
            }
        };

        // load ui popup
        let loadPopup = function () {
            try {
                let _html = `
                    <div id="tciePopup" class="uk-display-none draggable-element">
                        <div class="header uk-display-none" id="tciePopupHeader"> 
                        </div>
                        <div class="body">
                        <div>
                    </div>
                `;
                $(document.body).append(_html);

                // create kendo window
                $("#tciePopup").kendoWindow({
                    title: _config.title,
                    width: _config.width + "px",
                    height: _config.height + "px",
                    content: _config.tcieurl,
                    iframe: true
                });
                _popup = $("#tciePopup").data("kendoWindow")

                // open kendo window
                _popup.open();
                $("#tciePopup").css("padding", "0px");
                _tcieWindow = document.querySelector("#tciePopup > iframe").contentWindow;

                // hide default kendo window close button
                $("#tciePopup").parent().find(".k-window-action .k-i-close").parent().addClass("uk-display-none");

                // create new custom popup header button for popout 
                let popOut = $('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="Close"><span class="k-icon k-i-hyperlink-open"></span></a>');

                // on click of popout button
                popOut.click(function () {
                    // dispose kendo window object
                    _popup.destroy();

                    // remove popup html tags
                    $("#tciePopup").remove();

                    // change display type of tcie window 
                    _config.displayType = "window";
                    openTcieWindow();
                })

                // add button in kendo window header
                $("#tciePopup").parent().find(".k-window-actions").append(popOut);
            } catch (ex) {
                _log.error(ex);
            }
        };

        // callback for post message
        let onPostMessage = function (e) {
            try {
                if (!e.data) {
                    return;
                }
                _log.debug("onPostMessage" + e.data);
                if (typeof e.data === "string") {
                    jsonData = JSON.parse(e.data);
                } else if (typeof e.data === "object") {
                    jsonData = e.data;
                }
                if (jsonData.source === "tcie") {
                    switch (jsonData.function) {
                        case "TCIEData":
                            handleData(jsonData.data);
                            break;
                        case "GetUserData":
                            let data = GetUserData();
                            sendPostMessage(jsonData.callback, data);
                            break;
                        default:
                            break;
                    }
                }
            } catch (ex) {
                _log.error(ex);
            }
        };
        let GetUserData = function () {
            let profilePic = "";
            let agentFeatures = [];
            try {
                profilePic = global_successfullyLoggedInData.data.Data.AgtAgentProfileModel.ProfilePicture;
                agentFeatures = global_AgentFeatures;
            } catch (ex) {
                _log.error(ex);
            }
            return {
                profilePic: profilePic,
                features: agentFeatures,
            };
        };
        let handleData = function (data) {
            try {
            } catch (ex) {
                _log.error(ex);
            }
        };
    } catch (ex) {
        _log.error("exception in TCIE integration", ex);
    }
    // generic log 
    let _log = {
        debug: function (message) {
            console.log(message)
        },
        error: function (message) {
            console.error(message);
        },
    };
};
