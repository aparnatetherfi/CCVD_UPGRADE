﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacUI.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------
$(function () {
    console.log('tmac ui loaded');
    RegisterPostMessageListener();
    //log the file versions to server log after 2s
    setTimeout(function () {
        LogFileVersions();
    }, 2000);

    //  Disables refresh (F5, ctrl + r, ctrl + F5)
    if (AppConfigs.Local.Main && AppConfigs.Local.Main.RefreshDisabled) {
        $(window).keydown(function (event) {
            if (event.keyCode == 116 || (event.keyCode == 82 && event.ctrlKey) || (event.keyCode == 116 && event.ctrlKey)) {
                event.preventDefault();
                return false;
            }
        });
    }
    //  Disabled dev tools (F12, ctrl + shift + c, ctrl + shift + i)
    if (AppConfigs.Local.Main && AppConfigs.Local.Main.DevToolsDisabled) {
        $(window).keydown(function (event) {
            if (event.keyCode == 123 || (event.keyCode == 67 && event.ctrlKey && event.shiftKey) || (event.keyCode == 73 && event.ctrlKey && event.shiftKey)) {
                event.preventDefault();
                return false;
            }
        });
    }
});
// ----------------------------------------------------------------------------------
function RegisterPostMessageListener() {
    try {
        //if registerPostMessages then register to receive POST message
        if (registerPostMessages) {
            log.LogDetails("Info", "TmacUI.DocumentReady", "Register Post Message", false);
            if (window.addEventListener) {
                window.addEventListener('message', PostMessageReceived, false);
            } else {
                window.attachEvent('message', PostMessageReceived);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RegisterPostMessageListener()", ex, false);
    }
}

function PostMessageReceived(event) {
    try {
        //if event data is null then return
        if (!event.data) {
            return;
        }

        var jsonData = null;
        if (typeof event.data === "string") {
            jsonData = JSON.parse(event.data);
        } else if (typeof event.data === "object") {
            jsonData = event.data;
        }

        //get the source from jsonData
        var source = jsonData.source ? jsonData.source : customChatConfigs[0].source;

        switch (source.toLowerCase()) {
            case "moxtra":
                setTimeout(function () {
                    ProcessMoxtraCommands(jsonData);
                }, 500, jsonData);
                break;
            case "supervisor":
                var supervisorIframe = document.getElementById("supervisor_iframe");
                var supervisorWindow = supervisorIframe ? supervisorIframe.contentWindow : null;

                if (jsonData.functionName === "GetConnectedTmacServerName") {
                    if (supervisorWindow) {
                        supervisorWindow.postMessage({
                            functionName: jsonData.callbackFunctionName,
                            data: _tmacServer,
                            appData: jsonData.appData
                        }, "*");
                    }
                } else if (jsonData.functionName === "DisplayAgentChatWindow") {
                    var params = jsonData.functionParameters;
                    agent_chat.display_agent_chat(params.agentId, params.agentName, params.message, params.tmacServer);
                    //DisplayAgentChatWindow(params.agentId, params.agentName, params.message, params.tmacServer);
                } else if (jsonData.functionName === "sendSnapShotEvent" || jsonData.functionName === "SendSnapShotEvent") {
                    SendSnapShotEvent(jsonData.functionParameters);
                } else if (jsonData.functionName === "GetPermissionDetails") {
                    GetPermissionDetails(jsonData.functionParameters);
                }
                break;
            case "interactionhistory":
                let frameId = jsonData.userObject ? jsonData.userObject.frameId : "";
                var ihFrame = frameId ? document.getElementById(frameId) : document.getElementById("ui_history_frame" + (jsonData.userObject ? jsonData.userObject.intId : jsonData.intid));
                var ihWindow = (ihFrame) ? ihFrame.contentWindow : null;
                if (jsonData.userObject) {
                    if (jsonData.function === "GetHistoryParamById") {
                        let resultData = GetHistoryParamById(jsonData.userObject.intId);
                        if (resultData) resultData.myLastId = jsonData.data.myLastId;
                        if (ihWindow) {
                            InvokePostMessage(
                                ihWindow,
                                null,
                                jsonData.callback,
                                resultData,
                                jsonData.userObject
                            );
                        }
                    } else if (jsonData.function === "GetInteractionHistory") {
                        tmac_GetInteractionHistory(function (resultData, userObject) {
                            if (ihWindow) {
                                InvokePostMessage(
                                    ihWindow,
                                    null,
                                    jsonData.callback,
                                    resultData,
                                    jsonData.userObject
                                );
                            }
                        }, null, jsonData.data);
                    } else if (jsonData.functionName === "GetHistoryFromDataServer") {
                        GetHistoryFromDataServer(jsonData.data);
                    }
                }
                //for backward compatibility
                else {
                    if (jsonData.functionName === "GetHistoryParamById") {
                        let resultData = GetHistoryParamById(jsonData.intid);
                        if (resultData) resultData.myLastId = jsonData.myLastId;
                        if (ihWindow) {
                            ihWindow.postMessage({
                                functionName: jsonData.callbackFunctionName,
                                data: resultData
                            }, "*");
                        }
                    } else if (jsonData.functionName === "GetInteractionHistory") {
                        tmac_GetInteractionHistory(function (resultData, userObject) {
                            if (ihWindow) {
                                ihWindow.postMessage({
                                    functionName: userObject.callbackFunctionName,
                                    data: resultData
                                }, "*");
                            }
                        }, jsonData, jsonData.functionParameters);
                    } else if (jsonData.functionName === "GetHistoryFromDataServer") {
                        GetHistoryFromDataServer(jsonData.functionParameters);
                    }
                }
                break;
            case "workbench":
                //get the workbench iframe
                var workbenchIframe = document.getElementById("workbench_iframe");
                //if the iframe is not null get the content
                var workbenchWindow = workbenchIframe ? workbenchIframe.contentWindow : null;
                //return agent info on 'GetAgentInfo' request
                if (jsonData.function === "GetAgentInfo") {
                    InvokePostMessage(
                        workbenchWindow,
                        null,
                        jsonData.callback, {
                        agentId: global_AgentID, //agent id
                        agentName: global_AgentName, //agent name
                        deviceId: global_DeviceID, //device id
                        profile: global_UserProfileForAgent, //agent profile
                        skills: global_AgentSkills, //agent skill list
                        status: global_CurrentStatus, //current agent state
                        tmacServer: _tmacServer //agent tmac server
                    },
                        jsonData.userObject
                    );
                }
                //to put the item from work queue
                else if (jsonData.function === "PullQueueItem") {
                    var isSuccess = true;
                    //check if the agent status is available, if so then do not allow to pull the item
                    if (global_CurrentStatus && global_CurrentStatus === "Available") {
                        log.LogDetails("Warning", "TmacUI.PostMessageReceived().PullQueueItem", "Cannot pull fax item on Available status", true);
                        isSuccess = false;
                    } else {
                        isSuccess = true;
                        //send pull item request to server
                        PullQueueItem({ isSupervisor: false }, jsonData.data.channel, jsonData.data.itemId);
                    }
                    //return the response back to workbench iframe
                    InvokePostMessage(
                        workbenchWindow,
                        null,
                        jsonData.callback, {
                        isSuccess: isSuccess,
                        channel: jsonData.data.channel,
                        itemId: jsonData.data.itemId
                    },
                        jsonData.userObject
                    );
                }
                //to get get the current agent list in the server
                else if (jsonData.function === "GetAgentList") {
                    tmac_GetAgentListStaffed(function (data, obj) {
                        try {
                            //filter the self agent
                            data = data.filter(function (d) { return d.LoginID !== global_AgentID; });
                            //filter access role items
                            $.each(filterAccessRoleList, function (i, role) {
                                data = data.filter(function (d) { return role.toLowerCase() !== d.AgentProfile.AccessRole.toLowerCase(); });
                            });
                            //return the response back to workbench iframe
                            InvokePostMessage(workbenchWindow, null, jsonData.callback, data, obj);
                        } catch (ex) {
                            log.LogDetails("Error", "TmacUI.GetAgentListForWorkbench():GetAgentList:Callback", ex, false);
                        }
                    },
                        jsonData.userObject,
                        false);
                }
                //to get the current agent status
                else if (jsonData.function === "GetAgentStatus") {
                    tmac_GetAgentStatus(function (data, obj) {
                        try {
                            //return the response back to workbench iframe
                            InvokePostMessage(workbenchWindow, null, jsonData.callback, data.ResultMessage, obj);
                        } catch (ex) {
                            log.LogDetails("Error", "FaxUI.GetAgentListForWorkbench():GetAgentStatus:Callback", ex, false);
                        }
                    }, jsonData.userObject, "", jsonData.data.agentId, jsonData.data.tmacServer);
                }
                //send pull queue request to remote agent from supervisor
                else if (jsonData.function === "SendPullRequest") {
                    //create the event data
                    var eventData = {
                        EventName: "GenericTMACEvent",
                        SubEventName: "AgentActionEvent",
                        JsonData: JSON.stringify({
                            Type: "WorkbenchAction",
                            Action: "SendPullRequest",
                            TransferData: jsonData.data.transferData,
                            SupervisorInfo: {
                                agentId: jsonData.data.sAgentId,
                                agentName: jsonData.data.sAgentName,
                                tmacServer: jsonData.data.sTmacServer
                            }
                        })
                    };
                    //call server to add event to the agent session
                    tmac_AddEventToAgentSession("SendPullRequestDone", {
                        callback: jsonData.callback,
                        workbenchWindow: workbenchWindow,
                        inputData: jsonData.data.transferData
                    },
                        jsonData.data.agentId, eventData, true, jsonData.data.tmacServer);
                }
                //to download faxfile item from server
                else if (jsonData.function === "DownloadFaxFile") {
                    tmac_DownloadFaxFile(
                        function (data, obj) {
                            InvokePostMessage(
                                workbenchWindow,
                                null,
                                jsonData.callback,
                                data,
                                jsonData.userObject
                            );
                        },
                        null,
                        jsonData.data.path,
                        jsonData.data.jobId);
                }
                //to remove faxfile item from server
                else if (jsonData.function === "RemoveFaxFile") {
                    tmac_RemoveFile(null, null, jsonData.data.filePath);
                }
                //to log the workbench logs to client logger
                else if (jsonData.function === "LogDetails") {
                    log.LogDetails(jsonData.data.type, jsonData.data.method, jsonData.data.msg, jsonData.data.show);
                } else {
                    log.LogDetails("Warning", "TmacUI.PostMessageReceived()", "case is not defined in switch", false);
                }
                break;
            case "campaignselector":
                //to close tab after callback submit from campaign selector frame
                if (jsonData.function === "CloseTab") {
                    CloseTab(jsonData.data.interactionID, true);
                }
                break;
            case "meeting":
                //get the meeting iframe
                var frame = document.getElementById("meeting_iframe");
                //if the iframe is not null get the content
                var frameWindow = frame ? frame.contentWindow : null;
                //return agent info on 'GetAgentInfo' request
                if (jsonData.function === "getMyDetails") {
                    InvokePostMessage(
                        frameWindow,
                        null,
                        jsonData.callback, {
                        agentId: global_AgentID, //agent id
                        agentName: global_AgentName, //agent name
                        deviceId: global_DeviceID, //device id
                        status: global_CurrentStatus, //current agent state
                        tmacServer: _tmacServer //agent tmac server
                    },
                        jsonData.userObject
                    );
                } else if (jsonData.function === "sendMeetingRequest") {
                    //get the data
                    let data = jsonData.data;
                    agent_chat.start_meeting(data);
                } else if (jsonData.function === "sendAgentAVMessage") {
                    //send the message to remote agent
                    tmac_SendAgentAVMessage(function (res, obj) {

                        if (jsonData.callback) {

                            InvokePostMessage(
                                frameWindow,
                                null,
                                jsonData.callback,
                                res,
                                obj
                            );

                        }

                    }, jsonData.userObject, jsonData.data.agentId, jsonData.data.tmacServer, jsonData.data.type, jsonData.data.message, jsonData.data.jsonData);
                } else if (jsonData.function === "GetAgentList") {
                    tmac_GetAgentListStaffed(function (data, obj) {
                        try {
                            //filter the self agent
                            data = data.filter(function (d) { return d.LoginID !== global_AgentID; });
                            //filter access role items
                            $.each(filterAccessRoleList, function (i, role) {
                                data = data.filter(function (d) { return role.toLowerCase() !== d.AgentProfile.AccessRole.toLowerCase(); });
                            });
                            //return the response
                            InvokePostMessage(frameWindow, null, jsonData.callback, data, obj);
                        } catch (ex) {
                            log.LogDetails("Error", "TmacUI.GetAgentListForMeeting():GetAgentList:Callback", ex, false);
                        }
                    },
                        jsonData.userObject,
                        false);
                }
                break;
            default:
                log.LogDetails("Warning", "TmacUI.PostMessageReceived()", jsonData.function + " case is not defined", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.PostMessageReceived()", ex, false);
    }
}

function AddMainTab(divHeader, divBody, intid, tabName, isActive) {
    try {
        SaveTabReference(intid, intid, 'new');
        //tab header content
        var tempTabHeaderContent = document.getElementById(divHeader).innerHTML;
        //tab body content
        var tempTabContent = document.getElementById(divBody).innerHTML;
        //add a kendo tab
        AddTab(tempTabContent, tempTabHeaderContent, intid, tabName, isActive, false, false);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddMainTab()", ex, false);
    }
}

//add a kendo tab
function AddTab(tempTabContent, tempTabHeaderContent, intid, phonenumber, active, isClose, isRealTime) {
    try {
        //set interaction id for voice tab
        var tabContent = tempTabContent.replace(/_INTID/g, intid);
        //set interaction id for voice tab header
        var tabHeaderContent = tempTabHeaderContent.replace(/_INTID/g, intid);
        var lastIndex = tabstrip.items().length;
        //adding a kendo tab
        if (intid === "main")
            tabstrip.append({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            });
        //if dashboard and the first tab
        else if (intid === "dashboard" && lastIndex === 0)
            tabstrip.append({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            });
        else {
            tabstrip.insertAfter({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            }, tabstrip.items()[lastIndex - 1]);
        }
        //getting the item added to change the tab div id
        var item = tabstrip.contentElements[tabstrip.contentElements.length - 1];
        item.setAttribute("intid", intid);
        //changing tab body id for manual tab removal
        item.id = "div_" + intid;
        //add class to the tabstrib
        item.className += " main_tabstrip";
        //setting tab header id
        tabstrip.tabGroup.children().last().attr("id", "li_" + intid);
        //tab header reference to be changed as the body id changed
        tabstrip.tabGroup.children().last().attr('aria-controls', "div_" + intid);
        if (active || lastIndex === 0) {
            //index of the new added tab
            lastIndex = tabstrip.items().length;
            //set the newly added tab active
            tabstrip.select(lastIndex - 1);
        } else {
            if (!isNaN(intid) && GetTabReferenceObj(intid).type === "chat") {
                var bgColor = $(".k-tabstrip-items.k-reset").css("background-color");
                $("#li_" + intid).addClass("blink_chattab");
                GetChatReferenceObj(intid).isBlink = true;
            }
        }
        //to enable/disable close on load
        if (isClose) {
            EnableTabCloseButton(intid);
        }
        //Increase the global tab counter 
        global_tabCount++;
        global_openTabs[global_tabCount] = intid;
        if (!isNaN(intid)) {
            //bind the intent list for this tab
            BindIntentList(intid);
        }
        if (isRealTime) {
            //change on call tab
            $("#li_" + intid).addClass("li-on-call");
        }
        //set tab header details
        $('#divTabHeader' + intid).text(phonenumber);
        SetTabHeight();
        //Resize the window
        //ResizeWindow(false);
        try {
            $("#scrollTop" + intid).click(function () {
                $("#div_" + intid).animate({
                    scrollTop: 0
                }, 600);
                $(this).addClass("uk-display-none");
                return false;
            });
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddTab() - No Scroll button!", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddTab()", ex, false);
    }
}

function AddCallTimer(intid, type, $hdn_elm, $starttime_elm, $timetaken_elm, $span_starttime_elm, $chat_agent_timetaken_elm,
    $span_agent_timetaken_elm, $hdn_agent_time_taken_start, $hdn_agent_time_taken_end, $freeze_auto_resoponse, confType) {
    try {
        var timeTakeCounter = 0;
        //add timer
        var date = new Date();
        // When call comes, store the start time in the hidden field
        $($hdn_elm).val(date);
        try {
            date = moment(date).format("DD/MM/YYYY, HH:mm:ss");
            $($starttime_elm).html(date);
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddCallTimer() - Inside1", ex, false);
        }
        try {
            //if auto timer then on click is not required
            if (!autoTimerForTimeTaken) {
                $($timetaken_elm).click(function (e) {
                    try {
                        var callstartedAt = moment($($hdn_elm).val());
                        var callendAt = moment(new Date());
                        $($span_starttime_elm).text(moment().hour(0).minute(0).second(callendAt.diff(callstartedAt, 'seconds')).format('HH:mm:ss'));
                    } catch (ex) {
                        // 
                    }
                });
            } else {
                //change the title and start timer
                $($timetaken_elm).attr("title", "View time taken");
                GetTabReferenceObj(intid).tabTimer = setInterval(function () {
                    $($span_starttime_elm).text(moment().hour(0).minute(0).second(timeTakeCounter++).format('HH:mm:ss'));
                }, 1000);
            }
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddCallTimer() - Inside2", ex, false);
        }
        if (type === "chat") {
            //if auto timer then on click is not required
            if (!autoTimerForTimeTaken) {
                $($chat_agent_timetaken_elm).click(function (e) {
                    var callstartedAt = $($hdn_agent_time_taken_start).val() === "" ? moment($($hdn_elm).val()) : moment($($hdn_agent_time_taken_start).val());
                    var callendAt = $($hdn_agent_time_taken_end).val() === "" ? moment(new Date()) : moment($($hdn_agent_time_taken_end).val());
                    $($span_agent_timetaken_elm).text(moment().hour(0).minute(0).second(callendAt.diff(callstartedAt, 'seconds')).format('HH:mm:ss'));
                });
            } else {
                //if the conftype is silent then its a silent bargeIn so we need not to show this timer
                if (confType !== "silent") {
                    //change the title and start timer
                    $($chat_agent_timetaken_elm).attr("title", "View time taken");
                    StartChatTimeTakenTimer(intid, $span_agent_timetaken_elm);
                }
                //hide the timer if its a chat silent bargeIn
                else {
                    $("#div_agent_time_taken" + intid).hide();
                }
            }
            $($freeze_auto_resoponse).click(function (e) {
                FreezeTextChatAutoResponse(global_DeviceID, intid);
            });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddCallTimer()", ex, false);
    }
}

function StartChatTimeTakenTimer(intid, $span_agent_timetaken_elm) {
    try {
        GetChatReferenceObj(intid).timeTakenToReply = setInterval(function () {
            try {
                $($span_agent_timetaken_elm).text(moment().hour(0).minute(0).second(GetChatReferenceObj(intid).timeTakenCounter++).format('HH:mm:ss'));
            } catch (ex) {
                console.log(ex);
            }
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartChatTimeTakenTimer()", ex, false);
    }
}

function ConfirmTabClose(intId, callback) {
    try {
        if (intId === "meeting") {
            UIkit.modal.confirm("Are you sure to close meeting?",
                function () {
                    // inform the meeting frame about the close
                    //get the meeting iframe
                    var frame = document.getElementById("meeting_iframe");
                    //if the iframe is not null get the content
                    var frameWindow = frame ? frame.contentWindow : null;
                    // check for null
                    if (frameWindow) {
                        InvokePostMessage(
                            frameWindow,
                            null,
                            "tabCloseEvent",
                            null,
                            null
                        );
                    }
                    // close the tab
                    callback(intId);
                });
        } else {
            callback(intId);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ConfirmTabClose()", ex, false);
    }
    return true;
}

function CloseUITab(intid, module) {
    try {
        if (!GetTabReferenceObj(intid)) {
            return;
        }

        switch (GetTabReferenceObj(intid).type) {
            case "voice":
            case "callback":
                RemoveVoiceReference(intid);
                break;
            case "chat":
                RemoveChatReference(intid);
                break;
            case "fax":
                //try {
                //    tmac_RemoveFile(null, null, GetFaxReferenceObj(intid).tempFilePath);
                //} catch (e) {
                //    //
                //}
                RemoveFaxReference(intid);
                break;
            case "pom":
                RemovePOMReference(intid);
                break;
            case "sms":
                break;
            case "supervisor":
                UnloadIFrame("supervisor_iframe");
                break;
            case "workbench":
                UnloadIFrame("workbench_iframe");
                break;
            case "meeting":
                UnloadIFrame("meeting_iframe");
                break;
            default:
        }

        //previous tab
        var prevItem = tabstrip.select().prev();

        //next tab
        var nextItem = tabstrip.select().next();

        //destroy all the kendo elements inside the tab
        kendo.destroy("#div_" + intid);

        //remove the tab header
        $("#li_" + intid).empty();
        $("#li_" + intid).remove();

        //remove tab body
        $("#div_" + intid).empty();
        $("#div_" + intid).remove();

        //global tab count
        global_tabCount--;

        if (module) {
            ChangeStatus(global_DeviceID, 'available', '0');
        }

        //if the global_tabCount is less than 0 make it 0
        if (global_tabCount < 0)
            global_tabCount = 0;

        //issue is with kendo tab.. Need to get it fixed//
        if (global_tabCount <= 2 && parseInt($('.k-tabstrip-items.k-reset').css('margin-right')) > 0) {
            $('.k-tabstrip-items.k-reset').css('margin', '0px');
            $(".k-button.k-button-icon.k-bare.k-tabstrip-prev").remove();
            $(".k-button.k-button-icon.k-bare.k-tabstrip-next").remove();
        }

        if (nextItem.length) //if next tab is there then go to that tab else prev tab
            tabstrip.select(nextItem);
        else if (prevItem.length) //if previous tab is there then go to that tab else first tab
            tabstrip.select(prevItem);
        else
            tabstrip.select(tabstrip.tabGroup.children().first());

        //make the window ibar if the supervisor is closed
        if ((isExpandCollapseOnIframes.Supervisor || isExpandCollapseOnIframes.Workbench) && !isFullTMAC && intid === "supervisor") {
            ResizeWindow(isCACS ? true : false);
        }

        //get dashboard if medium is through tmac server
        if (isDashboardEnabled && !isSignalrConnector) {
            setTimeout(function () {
                GetMiniDashboard($("#drp_dashboard_interval").data("kendoDropDownList").value(), globalChannelList, null);
            }, 2000);
        }

        //remove the tab reference after removing the tab
        RemoveTabReference(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseUITab()", ex, false);
    }
}

function SetColorCodes(data) {
    try {
        if (data !== null) {
            global_QueueTimeColor = data;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetColorCodes()", ex, false);
    }
}

function GetColorCode(queueTime) {
    try {
        for (var i = 0; i < global_QueueTimeColor.length; i++) {
            if (queueTime >= global_QueueTimeColor[i].startTime && queueTime <= global_QueueTimeColor[i].endTime) {
                return global_QueueTimeColor[i].colorCode;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetColorCode()", ex, false);
    }
}

function SetInteractionHistory(data) {
    try {
        if (data !== null && isInteractionHistory) {
            //generate interaction history tree
            // load interaction on event can not enabled when history is with interaction
            loadHistoryOnEvent = false;
            // append the IH template
            $("#div_history" + data.InteractionID).append(GetHtmlFromTemplate("interaction_history_template", data.InteractionID));
            // to initialise the history UI
            LoadInteractionHistory("", "", "", "", data.InteractionID, "");
            // load the data
            ProcessHistoryData(data.History, { intId: data.InteractionID, instance: "home" });
            // set the reference to true
            GetTabReferenceObj(data.InteractionID).OtherData.isHistoryLoaded = true;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetInteractionHistory()", ex, false);
    }
}

function ProcessInteractionHistoryEvent(historyParams, forceLoad, source) {
    try {
        //check for POM do not load history on TMAC event but load for OnOutboundCallUUIData event
        if (isPOM && agentType === "AutoDialer" && source !== "pom") {
            log.LogDetails("Warning", "TmacUI.ProcessInteractionHistoryEvent()", "For POM/CACS load interaction history in OnOutboundCallUUIData event", false);
            return;
        }
        // set the history param to reference
        GetTabReferenceObj(historyParams.InteractionID).OtherData.historyParams = historyParams;
        // check the config to load history on demand or forceload else set param as not loaded
        if (loadHistoryOnEvent || forceLoad) {
            // if customer journey is enabled then load it in iframe else within TMAC
            if (isCustomerJourney) {
                OpenHistoryInFrame(historyParams, 0, forceLoad);
            } else if (isInteractionHistory) {
                // append the IH template
                $("#div_history" + historyParams.InteractionID).append(GetHtmlFromTemplate("interaction_history_template", historyParams.InteractionID));
                // load the data to IH element
                LoadInteractionHistory(historyParams.CIF, historyParams.EmailID, historyParams.NRIC, historyParams.PhoneNumber, historyParams.InteractionID, 0);
                // set the reference as loaded
                GetTabReferenceObj(historyParams.InteractionID).OtherData.isHistoryLoaded = true;
            } else {
                log.LogDetails("Warning", "TmacUI.ProcessInteractionHistoryEvent()", "both 'isInteractionHistory' and 'isCustomerJourney' are not configured!", false);
            }
        } else {
            GetTabReferenceObj(historyParams.InteractionID).OtherData.isHistoryLoaded = false;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ProcessInteractionHistoryEvent()", ex, false);
    }
}

// function OpenHistoryInFrame(historyParams, cnt) {
//     try {
//         if (cnt === undefined || cnt === null)
//             cnt = 0;

//         if (historyParams.Channel === "Email") {
//             //wait for sometime for tab to get generated
//             if (GetTabReferenceObj(historyParams.InteractionID) !== undefined) {
//                 loadHistoryFrame(historyParams);
//             } else {
//                 if (cnt < 10) {//10 max tries (10 seconds wait)
//                     setTimeout(function () {
//                         OpenHistoryInFrame(para, cnt + 1);
//                     }, 1000);
//                 }
//             }
//         } else {
//             LoadHistoryFrame(historyParams);
//         }
//     } catch (ex) {
//         log.LogDetails("Error", "TmacUI.OpenHistoryInFrame()", ex, false);
//     }
// }

// function LoadHistoryFrame(historyParams) {
//     try {
//         var url = (IsValidURL(ih_iframe_url) ? ih_iframe_url : GetBaseUrl(global_connectedProxy) + ih_iframe_url) + "?"
//             + "s=" + interactionHistorySource
//             + "&i=" + historyParams.InteractionID
//             + "&d=" + global_DeviceID
//             + "&sn=" + _tmacServer
//             + "&f=" + localStorage.getItem("font_family")
//             + "&hp=" + historyParams.CIF + "," + historyParams.EmailID + "," + historyParams.NRIC + "," + historyParams.PhoneNumber;

//         // save the reference as loaded
//         GetTabReferenceObj(historyParams.InteractionID).OtherData.isHistoryLoaded = true;
//         // load the ih frame
//         LoadIFrame("ui_history_frame" + historyParams.InteractionID, url);
//         //remove the local IH div
//         $("#div_history" + historyParams.InteractionID).remove();
//         // show the frame tag
//         $("#ui_history_frame" + historyParams.InteractionID).toggle(true);
//     } catch (ex) {
//         log.LogDetails("Error", "TmacUI.LoadHistoryFrame()", ex, false);
//     }
// }

function GetHistoryParamById(intid) {
    try {
        return GetTabReferenceObj(intid).OtherData.historyParams;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetHistoryParamById()", ex, false);
    }
    return null;
}

function LoadIHOnClick(intid) {
    try {
        //check if the history loaded on click
        var isHistoryLoaded = GetTabReferenceObj(intid).OtherData.isHistoryLoaded;
        if (!loadHistoryOnEvent && !isHistoryLoaded) {
            var historyParams = GetTabReferenceObj(intid).OtherData.historyParams;
            ProcessInteractionHistoryEvent(historyParams, true, "event");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadIHOnClick()", ex, false);
    }
}

function SetInteractionHistoryMore(data) {
    try {
        if (data !== null) {
            //generate interaction history tree
            AddMoreInteractions(data.History, data.InteractionID);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetInteractionHistoryMore()", ex, false);
    }
}

function SetCCLData(data) {
    try {
        if (data !== null) {
            if (data.CallerName !== "")
                var callerName = data.CallerName;
            //document.getElementById('txtName' + data.InteractionID).innerHTML = data.CallerName;
            //document.getElementById('txtNRIC' + data.InteractionID).innerHTML = data.NRIC;
            //document.getElementById('txtCIF' + data.InteractionID).innerHTML = data.CIF;
            //document.getElementById('divCustomerName' + data.InteractionID).innerHTML = callerName.substring(0, 7);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetCCLData()", ex, false);
    }
}

function RefreshWallboard(data) {
    try {
        if (data !== null && isWallboard) {
            let skill = [];
            if (isServiceLevel) {
                // loop the data
                data.Skills.forEach(function (element) {
                    // check if the BCMS data is there, if not put the default value as 'NA' and return
                    if (!element.BCMSData) {
                        element.BCMSData = { SLPercentage: 'NA' };
                        element.BCMSData.SLPercentage = { value: element.BCMSData.SLPercentage, color: 'black', background: 'white' };
                        return;
                    }
                    let tmacWallboardColorCodes = dashboardColorCodes.filter(function (d) {
                        if (d.DashboardName.toLowerCase() === 'tmacwallboard') {
                            return d;
                        }
                    });
                    // get the color code for the value
                    var filterdata = tmacWallboardColorCodes.filter(function (data) {
                        if (parseInt(data.EndRange) >= parseInt(element.BCMSData.SLPercentage) && parseInt(data.StartRange) <= parseInt(element.BCMSData.SLPercentage)) {
                            return data;
                        }
                    });
                    // if the data found for color code add to the element else add default color
                    if (filterdata.length > 0) {
                        element.BCMSData.SLPercentage = { value: element.BCMSData.SLPercentage, color: filterdata[0].FontColor, background: filterdata[0].BackgroundColor };
                    } else {
                        element.BCMSData.SLPercentage = { value: element.BCMSData.SLPercentage, color: 'black', background: 'white' };
                    }
                    skill.push(element);
                });
            } else {
                skill = data.Skills;
            }
            //bind wallboard data
            if (isFullTMAC) {
                $('#wallboardGrid_side').data('kendoGrid').dataSource.data(data.Skills);
                HideKendoLoading("#wallboardGrid_side");
            } else {
                $('#wallboardGrid_main').data('kendoGrid').dataSource.data(data.Skills);
                HideKendoLoading("#wallboardGrid_main");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RefreshWallboard()", ex, false);
    }
}

function AgentNotification(data) {
    try {
        if (data.Type === "InteractionIM") {
            HandleIMs(data.InteractionID, data.Message, "", "info", data.FromAgentName, true);
        } else if (data.Type === "Broadcast") {
            var message = data.Message;
            if (popBroadcast && !isNullOrWhitespace(message) && message !== marqueeText) {
                setTimeout(function () {
                    UIkit.modal.alert(message);
                }, 2000);
            }
            if (message === "....") {
                marqueeText = 'No broadcast to display';
            } else
                marqueeText = message;
            $("#marquee").text(marqueeText);

        } else if (data.Type === "ProfanityWordsViolation") {
            //  ReviewCodeLine: Show browser notification
            ShowNotification("", "Chat message has been blocked due to restricted word(s) usage. Please check TMAC.", "")

            //  Show modal alert to Supervisor with details
            UIkit.modal.alert(data.Message.replaceAll("\n", "<br>"));
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentNotification()", ex, false);
    }
}

function HandleIMs(intid, message, type, source, fromAgentName, showNotification) {
    try {
        var t = $("#InteractionIMTemplate").html(), //template divs
            e = $("#InteractionIM" + intid), //to be appended before/after/to
            n = Handlebars.compile(t), //initialize handlebars for the template divs     
            context = {
                message: message,
                type: type,
                intid: intid,
                source: source
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.prepend(s), $(window).resize(); //append the element, init altair_md.inputs and resize the window
        if (showNotification) ShowNotification("IM from " + fromAgentName, message);
        log.LogDetails("Info", "TmacUI.AgentNotification()", "IM from " + fromAgentName + ": " + message, showNotification);
        //$("#scrollTop" + data.InteractionID).removeClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.HandleIMs()", ex, false);
    }
}

function UkAlertCallback(source) {
    try {
        if (source) {
            switch (source) {
                case "transfertimeout":
                    let ref = GetTransferNotificationRef(global_activeTabInteractionID);
                    if (ref) {
                        //send the command to agent to remove the notification
                        SendCommandToAgent(null, "", ref.to, ref.toServer, "", "TransferNotificationExpired", JSON.stringify(ref));
                        EnableTransferConfButton();
                        //remove after the TTL if not removed by the notification response
                        RemoveTransferNotificationRef(global_activeTabInteractionID);
                    }
                    break;
                default:
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.UkAlertCallback()", ex, false);
    }
}

function AgentLoginSuccess() {
    try {
        //update agent login for customer layer
        AgentLoginSuccessCustom();
        //close the parent winodw (login window)
        if (opener && !isVoiceBio)
            opener.loginDone();
        //add agent id and station id to the document title
        if (labelOnTitle)
            document.title = titleName + " - A: " + global_AgentID + (opener ? opener.isStationAvailable ? ' / S: ' + global_DeviceID : "" : isStationAvailable ? ' / S: ' + global_DeviceID : "");
        else
            document.title = titleName + " - " + global_AgentID + (opener ? opener.isStationAvailable ? '/' + global_DeviceID : "" : isStationAvailable ? '/' + global_DeviceID : "");
        //set main tab agent details
        if (agentStationOnMain) {
            $("#agentname").text(global_AgentName + (opener ? opener.isStationAvailable ? "/" + global_DeviceID : "" : isStationAvailable ? "/" + global_DeviceID : ""));
        } else {
            $("#agentname").text(global_AgentName);
        }
        //set main and sidebar agent profile details
        if (global_UserProfileForAgent === "S") {
            if (isFullTMAC) $("#agentprofile_side").append("Supervisor" + (agentType ? "/" + agentType : ""));
            else if (agentProfileOnMain) $("#agentProfile").html("Supervisor" + (agentType ? "/" + agentType : ""));
        }
        if (global_UserProfileForAgent === "A") {
            if (isFullTMAC) $("#agentprofile_side").append("Agent" + (agentType ? "/" + agentType : ""));
            else if (agentProfileOnMain) $("#agentProfile").html("Agent" + (agentType ? "/" + agentType : ""));
        }
        //set sidebar agent details
        if (isFullTMAC) {
            //$("#agentid_side").text(global_AgentID);
            $("#agentname_side").text(global_AgentName);
            $("#agentstation_side").html("A: " + global_AgentID + " | S: " + global_DeviceID);
            setInterval(function () {
                var randomNumber = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
                $("#span_quotes").text(quotesList[randomNumber]);
            }, 10000);
            if (isTour) $("#welcome_sub_message").removeClass("uk-display-none");
        }


        //Disable the Logout Button
        FadeOutButton(".btn-logout");

        if (isCRMEnabled) {
            //get the list of callback, textchat VDN
            if (!global_ReloadDone) {
                custom_getVDNList(0, "callback");
            }
            custom_getVDNList(0, "textchat");
            custom_getVDNList(0, "ibgdnis");
            //Get Popup URLs
            custom_getPopUpURL(0, "callback");
            custom_getPopUpURL(0, "QMS");
            custom_getPopUpURL(0, "ACW");
            custom_getPopUpURL(0, "MSDChatAccept");
            custom_getPopUpURL(0, "MSDChatClose");
            custom_getPopUpURL(0, "MSDCallbackAccept");
            custom_getPopUpURL(0, "MSDCallbackClose");
            custom_getPopUpURL(0, "MSDInboundVoice");
            custom_getPopUpURL(0, "MSDOutboundVoice");
        }

        setInterval(function () {
            var date = new Date();
            date = moment(date).format("DD/MM/YYYY, HH:mm:ss");
            $("#ui_tmac_clock_span").text(date);
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentLoginSuccess()", ex, false);
    }
}

function AgentStatusChange(data) {
    try {
        //update the status list with new status
        if (data) {
            //reset the status timer
            if (data.Status.indexOf('On Call') < 0 || global_LastAgentStat && global_LastAgentStat.Status.indexOf('On Call') < 0) {
                statusTimeCounter = 0;
            }

            //if close tab on status is enabled, then close the tab
            if (isCloseTabsOnTSC) {
                CloseTabsOnStatusChange(data);
            }

            //set the last agent status. This value will be used after aux code loading is completed
            global_LastAgentStat = data;

            DivAuxStatReceivedFromServer(data.Status);
        } else {
            log.LogDetails("Error", "TmacUI.AgentStatusChange()", "data is null/undefined!", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentStatusChange()", ex, false);
    }
}

function CloseTabsOnStatusChange(data) {
    try {
        if (global_LastAgentStat &&
            (closeTabLastStatus.toLowerCase() === "acw" && global_LastAgentStat.Source !== "change" && global_LastAgentStat.Status.indexOf("ACW") >= 0 ||
                closeTabLastStatus.toLowerCase() === "on call" && global_LastAgentStat.Status.indexOf("On Call") < 0) ||
            data.Source === "change"
        ) {
            //if the new status is acw/error then skip
            if (!(data.Status.indexOf('On Call') >= 0 ||
                data.Status.indexOf('ACW') >= 0 ||
                data.Status.indexOf('Error') >= 0 ||
                skipCloseTabStatus.indexOf(data.Status) >= 0)) {
                //get tabs to close, execpt static tabs and configured tab types
                $.each(global_InteractionTabs, function (i, t) {
                    if (skipCloseTabType.indexOf(t.type) < 0 && !t.isStatic) {
                        RemoveGlobalTimeoutReference(t.intid);
                        setTimeout(function () {
                            CloseTab(t.intid, false);
                        }, 500);
                    }
                });
            }
            //if the status on call, in CM routing there is a change that ACW to On Call can come
            //that time close all inactive tab where the tab reference isCloseTab is tagged true.
            //currently this is only for voice and textchat channel
            else if (data.Status === "On Call") {
                //get tabs to close, close all inactive tabs for On Call status
                $.each(global_InteractionTabs, function (i, t) {
                    if (t.isCloseTab) {
                        RemoveGlobalTimeoutReference(t.intid);
                        setTimeout(function () {
                            CloseTab(t.intid, false);
                        }, 500);
                    }
                });
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseTabsOnStatusChange()", ex, false);
    }
}

function AuxCodesLoaded() {
    try {
        if (global_AUXCodes !== null) {
            //bind aux codes to dropdown list
            RemoveNameFromList(global_AUXCodes, "Logout", 110);
            RemoveNameFromList(global_AUXCodes, "ACW", 111);
            LoadAuxDiv(global_AUXCodes, initialStatus.toLowerCase());

            //disable logout button initially
            FadeOutButton(".btn-logout");
            //disable makecall button initially
            FadeOutButton(".btn-make-call");
            //just load agent status of not loaded on event
            tmac_GetAgentStatus(function (result) {
                if (result && result.ResultCode > 0) {
                    DivAuxStatReceivedFromServer(result.ResultMessage);
                }
            }, null, global_DeviceID, global_AgentID, _tmacServer);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AuxCodesLoaded()", ex, false);
    }
}

function RemoveNameFromList(nameList, name, value) {
    try {
        for (var i = nameList.length - 1; i >= 0; i--) {
            if (nameList[i].Name === name && nameList[i].Value === value) {
                nameList.splice(i, 1);
                return;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveNameFromList()", ex, false);
    }
}

function DivAuxStatReceivedFromServer(status) {
    try {
        if (status !== "") {
            var type = "warning";
            var iconType = "offline_bolt";
            if (status === "ACW" || status === "PendingNotReady") {
                iconType = "group_work";
            } else if (status === "Available" || status === "Preview" || status === "Ready" || status === "Idle") {
                type = "success";
                iconType = "check_circle";
            } else if (status.indexOf("Logout") >= 0) {
                type = "danger";
                iconType = "settings_power";
            }
            //status icon change
            $("#divAuxStatusType").html('<i class="material-icons notranslate md-20 uk-text-' + type + '">' + iconType + '</i> ');

            //change the ui status
            $('#divAuxStatus').text(status);
            $('#divAuxStatus').removeClass("loading");

            if (agentStatusOnMain) {
                $("#agentStatus").text(status);
                $('#agentStatus').removeClass("loading");
            }
            //process the agent status change
            ProcessAgentStatusChange(status);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DivAuxStatReceivedFromServer()", ex, false);
    }
}

function ProcessAgentStatusChange(status) {
    try {
        //if this is pom ui and if OnPOMLoginSuccess/OnPOMLoginFailed received then only enable status
        if (isPOM && pomLoginFlag) FadeInButton("#btn_change_status");
        status = status.toLowerCase();
        switch (status) {
            case initialStatus.toLowerCase():
                FadeOutButton(".btn-logout");
                FadeOutButton(".btn-make-call");
                break;

            case "not logged in":
                global_AgentForcedLogoffEventFlag = true;
                LogoffAlert("Agent Manually logged out from hardphone!", true, 3000);
                if (isVoiceBio) ShowNotLoggedInScreen();
                break;

            case "available":
            case "acw":
            case "pendingnotready":
                FadeOutButton(".btn-logout");
                FadeOutButton(".btn-make-call");
                break;

            case global_outboundName.toLowerCase():
                //if (!isPOM || isPOM && agentType === "ACD")
                FadeInButton(".btn-make-call");
                FadeOutButton(".btn-logout");
                break;

            case "logout":
                FadeInButton(".btn-logout");
                break;

            default:
                if (status.indexOf("on call") >= 0) {
                    //initially fadeout make call
                    FadeOutButton(".btn-make-call");

                    //if there is a only chat single dont disable make call button on change status to outbound 
                    if (status !== global_outboundName && global_ChatReference.length === 0) FadeOutButton(".btn-make-call");

                    //disable status change on call if configured
                    if (isDisableStatusOnCall) FadeOutButton("#btn_change_status");
                } else {
                    //make outbound call button enable if global_outboundName is empty
                    if (!global_outboundName && status.toLowerCase().indexOf("logout") < 0) {
                        FadeInButton(".btn-make-call");
                    }
                    //enable logout button based on the config, if the logoutAux is not there then enable by default
                    if (logoutAux) {
                        let logoutAuxSplit = logoutAux.split(',');
                        $.each(logoutAuxSplit, function (i, val) {
                            let logoutAuxCheck = global_AUXCodes && global_AUXCodes.filter(function (a) { return a.Name.toLowerCase() === status; });
                            if (logoutAuxCheck && logoutAuxCheck.length > 0 && logoutAuxCheck[0].Code === val) {
                                FadeInButton(".btn-logout");
                            }
                        });
                    }
                }
        }
        LoadAuxDiv(global_AUXCodes, status);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ProcessAgentStatusChange()", ex, false);
    }
}

function LoadAuxDiv(data, currentStat) {
    try {
        if (data === null || data === undefined) {
            return;
        }
        var count = data.length;
        var intI = count;
        if (intI !== 0) {
            var newdropDownString = "";
            // sort the array on values
            data.sort(function (a, b) {
                return a.Value - b.Value;
            });
            // put available on top after sorting which has value 112
            data.unshift(data.pop());
            $.each(data, function (k, arrayItem) {
                if (arrayItem.Display === 1) {
                    var type = "warning";
                    var iconType = "offline_bolt";
                    if (arrayItem.Name.toLowerCase() !== currentStat) {
                        if (arrayItem.Name === "ACW") {
                            iconType = "group_work";
                        } else if (arrayItem.Name === "Available") {
                            type = "success";
                            iconType = "check_circle";
                        } else if (arrayItem.Name.indexOf("Logout") >= 0) {
                            type = "danger";
                            iconType = "settings_power";
                        }
                        newdropDownString +=
                            '<li>' +
                            '<a class="uk-dropdown-close" href="#" onclick="return DivAuxCodeSelected(\'' + arrayItem.Value + '\',\'' + arrayItem.Name + '\');">' +
                            '<i class="material-icons notranslate md-20 uk-text-' + type + '">' + iconType + '</i> ' +
                            arrayItem.Name +
                            '</a>' +
                            '</li>';
                    }
                }
            });
            $("#auxstatuslist").html(newdropDownString);
        }
        return false;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadAuxDiv()", ex, false);
    }
}

function DivAuxCodeSelected(id, type) {
    try {
        var old = $('#divAuxStatus').text();
        if (isPOM && type.toLowerCase() === "available") {
            switch (old.toLowerCase()) {
                case "wrapup":
                case "pendingnotready":
                    log.LogDetails("Error", "TmacUI.DivAuxCodeSelected()", "Please complete the wrapup and go available", true);
                    return false;
                case "idle":
                    log.LogDetails("Error", "TmacUI.DivAuxCodeSelected()", "Not allowed to change status to available", true);
                    return false;
                default:
            }
        }

        if (old === "ACW" && isACWQMSCRMEnabled) {
            ACWQMSCRMUpdate();
        }

        //disable logout button initially
        FadeOutButton(".btn-logout");
        //disable makecall button initially
        FadeOutButton(".btn-make-call");

        switch (type.toLowerCase()) {
            case "acw":
                ChangeStatus(global_DeviceID, 'acw', id);
                break;
            case "available":
                ChangeStatus(global_DeviceID, 'available', id);
                break;
            case global_outboundName.toLowerCase():
                ChangeStatus(global_DeviceID, 'aux', id);
                if (isEnableVoiceOnSingleChat)
                    FadeInButton(".btn-make-call");
                break;
            default:
                //if isEnableVoiceOnSingleChat and global_outboundName empty then enable make call button and check for the limit later on
                if (!global_outboundName && isEnableVoiceOnSingleChat)
                    FadeInButton(".btn-make-call");
                ChangeStatus(global_DeviceID, 'aux', id);
                break;
        }
        //if the status on call disable make call button
        if (global_LastAgentStat && global_LastAgentStat.Status.indexOf("On Call") >= 0) {
            //if there is only a single chat dont disable make call button on change status to outbound
            if (type !== global_outboundName && global_ChatReference.length !== 1) {
                FadeOutButton(".btn-make-call");
            }
        } else {
            if (isCloseTabsOnTSC) {
                //get tabs to close, execpt static tabs and configured tab types
                $.each(global_InteractionTabs, function (i, t) {
                    if (skipCloseTabType.indexOf(t.type) < 0 && !t.isStatic) {
                        RemoveGlobalTimeoutReference(t.intid);
                        CloseTab(t.intid, true);
                    }
                });
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DivAuxCodeSelected()", ex, false);
    }
}

function GetUcidForAcwEndOfCall() {
    try {
        var globalUcid;
        // Lets store all the Connected UCID and INTID
        var global_connectUCID_final = [];
        var global_connectINIT_final = [];
        var array = [];

        $.each(array, function (n) {
            global_connectUCID_final[this.InteractionID] = this.UCID;
            global_connectINIT_final[this.InteractionID] = this.InteractionID;
        });
        // If its more that one tabs are opened
        if (global_tabCount > 1) {
            // Iterate with open tabs
            for (var i = 1; i <= global_tabCount; i++) {
                globalUcid = global_UCID[global_openTabs[i]];
                if (jQuery.inArray(globalUcid, global_connectUCID_final) !== -1) {
                    // lets match the interactionid
                    var intid = global_openTabs[i];
                    if (jQuery.inArray(intid, global_connectINIT_final) !== -1) {
                        global_openTabsUCID[i] = globalUcid;
                    } else {
                        global_openTabsUCID[i] = -1;
                    }
                } else {
                    global_openTabsUCID[i] = -1;
                }
            }
            return global_openTabsUCID;
        } else {
            globalUcid = global_UCID[global_activeTabId];
            if (jQuery.inArray(globalUcid, global_connectUCID_final) !== -1) {
                return globalUcid;
            } else {
                return -1;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetUcidForAcwEndOfCall()", ex, false);
    }
}

function LoadAgentListGrids() {
    //LoadAgentListGrid("makeCallagentListGrid", "txtMakeCallNumber");
    //LoadAgentListGrid("transCallagentListGrid", "txtNumberTrans");
    //LoadAgentListGrid("confCallagentListGrid", "txtNumberConf");
}

function AgentListLoaded(obj, gridData) {
    try {
        if (global_AgentList !== null) {
            //bind agent list to makecall, transfer, conference windows
            if (obj.dialogName === "makeCall") {
                //EnableButton(".btn-make-call", "call", "icon");
                $("#btndisconnectSpan").addClass("uk-display-none");
                $("#make_call_dialog").data("kendoWindow").center().open();
                //grid filter is not working with this approach of loading the grid data
                //$('#makeCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("makeCallagentListGrid", gridData);
                document.getElementById("txtMakeCallNumber").value = "";
                //reload the speeddial list grid
                $('#speedDialMakeCallGrid').data('kendoGrid').dataSource.read();
                //focus the textbox
                setTimeout(function () {
                    $("#txtMakeCallNumber").focus();
                }, 500);
            } else if (obj.dialogName === "transferCall") {
                EnableButton(obj.buttonName, obj.icon, "icon");
                //enable/disable favorite skill gird
                if (isFavouriteSkillTab) {
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).attr("style", "display:inline-block");
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).children(".k-link").text(favouriteSkillTabName);

                    if (global_CallType === "TextChatTransfer") {
                        if (GetChatReferenceObj(obj.intid).isNonVoiceRouting) {
                            $('#favListGrid').data("kendoGrid").hideColumn("VDN");
                        }
                        filterdSkills = global_FavouriteSkills.filter(function (s) { return s.Name.toLowerCase().slice(0, 2) === transferListSkillFilterPrefix.TextChat.toLowerCase(); });
                    } else if (global_CallType === "Transfer") {
                        filterdSkills = global_FavouriteSkills.filter(function (s) { return s.Name.toLowerCase().slice(0, 2) === transferListSkillFilterPrefix.Voice.toLowerCase(); });
                    } else if (global_CallType === "FaxTransfer") {
                        filterdSkills = global_FavouriteSkills.filter(function (s) { return s.Name.toLowerCase().slice(0, 3) === transferListSkillFilterPrefix.Fax.toLowerCase(); });
                    }
                } else
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).attr("style", "display:none");

                //enable/disable speed dial grid based on configuration
                if (global_CallType === "Transfer" && isSpeedDialTab.Voice ||
                    global_CallType === "TextChatTransfer" && isSpeedDialTab.TextChat ||
                    global_CallType === "FaxTransfer" && isSpeedDialTab.Fax) {
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).attr("style", "display:inline-block");
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).children(".k-link").text(speedDialTabName);
                } else {
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).attr("style", "display:none");
                }

                $("#transfer_dialog").data("kendoWindow").center().open();
                document.getElementById("txtNumberTrans").value = "";
                document.getElementById("txtCommentTrans").value = "";
                //grid filter is not working with this approach of loading the grid data
                //$('#transCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("transCallagentListGrid", gridData);
                //reload the favorite grid
                $('#favListGrid').data('kendoGrid').dataSource.data(filterdSkills);
                //focus the textbox
                setTimeout(function () {
                    $("#txtNumberTrans").focus();
                }, 500);
            } else if (obj.dialogName === "conferenceCall") {
                EnableButton(obj.buttonName, obj.icon, "icon");
                $("#conference_dialog").data("kendoWindow").center().open();
                document.getElementById("txtNumberConf").value = "";
                //grid filter is not working with this approach of loading the grid data
                //$('#confCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("confCallagentListGrid", gridData);
                //focus the textbox
                setTimeout(function () {
                    $("#txtNumberConf").focus();
                }, 500);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentListLoaded()", ex, false);
    }
}

function InitConversionSkillsGrid() {
    try {
        if (!interactionConversion.Enabled)
            return;

        $('#ConversionSkillsListGrid').kendoGrid({
            dataSource: {
                data: []
            },
            filterable: {
                mode: "row"
            },
            change: function (e) {
                FadeInButton("#btnDialogConvertInteraction");
            },
            dataBound: function (e) {
                FadeOutButton("#btnDialogConvertInteraction");
            },
            height: 250,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            resizable: true,
            columns: [{
                field: "SkillName",
                title: "Name",
                width: "100px",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "SkillID",
                title: "ID",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "AgentsStaffed",
                title: "Staff",
                filterable: false
            },
            {
                field: "AgentAvailable",
                title: "Avail",
                filterable: false
            },
            {
                field: "CallsInQueue",
                title: "CIQ",
                filterable: false
            }
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.InitConversionSkillsGrid()", ex, false);
    }
}

function CallbackTimer(data) {
    try {
        //remove object from the array
        RemoveGlobalTimeoutReference(data.intid);
        //eisable the callback Dial button
        DisableCallbackDialButtons(data.intid);
        //enable the callback submit button
        EnableCallbackSubmitButtons(data.intid);
        //For DBS HK prefix 9 and dial out, for DBS IN prefix 90 and dial out
        MakeCall(data.deviceid, data.number, 'customMakeCallCallerId', data.intid);
        //GetTabReferenceObj(data.intid).OtherData.customMakeCallDone = true;
        GetTabReferenceObj(data.intid).OtherData.customMakeCallDone = true;
        ChangeTabReferenceStatus(data.intid, 'MakeCall');
        //disable the close tab button
        $('#btnCloseTab' + data.intid).toggle(false);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CallbackTimer()", ex, false);
    }
}

function StartcallbackTimer(deviceid, intid, autoDialAfter, number) {
    try {
        // add 10 seconds to the current time for execution
        var dialTime = new Date();
        dialTime.setSeconds(dialTime.getSeconds() + autoDialAfter);
        var object = {};
        object.executeTime = dialTime;
        object.methodName = 'CallbackTimer';
        object.deviceid = deviceid;
        object.intid = intid;
        object.number = number;
        global_timeoutFunctions.push(object);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartcallbackTimer()", ex, false);
    }
}

function PerformInfiniteActions() {
    global_timeoutFunctions.forEach(ExecuteTimer);
}

function SetTimer() {
    try {
        setInterval(function () {
            try {
                $("#divTimer").text(moment().hour(0).minute(0).second(statusTimeCounter++).format('HH:mm:ss'));
            } catch (ex) {
                console.log(ex);
            }
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetTimer()", ex, false);
    }
}

function ExecuteTimer(value, index, ar) {
    try {
        var dte = new Date();
        //check if execution time is greater than current time
        if (value.methodName === "CallbackTimer") {
            if (dte > value.executeTime) {
                window[value.methodName](value);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ExecuteTimer()", ex, false);
    }
}

function BindIntentList(intid) {
    try {
        $('#ddlIntent' + intid).append('<option value="-100">How can I help you?</option>');
        $.each(global_Intents, function (i, val) {
            $('#ddlIntent' + intid).append('<option value="' + val + '">' + val + '</option>');
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.BindIntentList()", ex, false);
    }
}

function CallerIntentReceived(data) {
    try {
        AssignDynamicValues(data, "voice", "CallerIntentEvent");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CallerIntentReceived()", ex, false);
    }
}

function onIntentChange(intid) {
    try {
        var newintent = $('#ddlIntent' + intid).val();
        UpdateIntent(global_DeviceID, intid, newintent);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.onIntentChange()", ex, false);
    }
}

function OpenIntent(intid) {
    try {
        var newintent = $('#ddlIntent' + intid).val();
        OpenIntent(global_DeviceID, intid, newintent);
        $('#ddlIntent' + intid).attr('disabled', 'disabled');
        $('#imgIntent' + intid).attr('disabled', 'disabled');
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenIntent()", ex, false);
    }
}

function SetHiddenFieldCallback(event) {
    try {
        $('#hfUCID' + event.InteractionID).val(event.UCID);
        $('#hfcallerID' + event.InteractionID).val(event.PhoneNumber);
        $('#hfcalledDevice' + event.InteractionID).val(event.CalledDevice);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetHiddenFieldCallback()", ex, false);
    }
}

function SetddlStatusChangeValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        $('#startDate' + event.InteractionID).val(parse.date);
        $('#ddl_time' + event.InteractionID).val(parse.HH + ":" + parse.MM);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetddlStatusChangeValues()", ex, false);
    }
}

function SetSubmitValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult === "RescheduleRequest success") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully rescheduled", true);
        } else if (parse.submitResult === "Schedule success") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully scheduled", true);
        } else if (parse.submitResult === "Record Successfully updated") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully closed", true);
        } else {
            log.LogDetails("Warning", "TmacUI.SetSubmitValues()", parse.submitResult, true);
            return;
        }
        //Close the tab after displaying the result
        if (isTextChatCallback || isCRMCallbackEnd) {
            try {
                //Send Callback CRM pop up for reschedule and closed callbacks only
                if (parse.submitResult !== "Schedule success") {
                    //DynamicsCRMEndCallbackPopUpScreen(event.InteractionID, parse.submitResult, parse.status);
                }
            } catch (ex) {
                //
            }
            var sessionid = $('#hfUCID' + event.InteractionID).val();

            //get cif
            var cif = $('#hfCIF' + event.InteractionID).val();
        }
        if (parse.submitResult === "Record Successfully updated" ||
            parse.submitResult === "RescheduleRequest success" ||
            parse.submitResult === "Schedule success") {
            CloseTab(event.InteractionID);

            ChangeStatus(global_DeviceID, 'available', '0');
        }
        global_voiceCallHasCallback = false;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetSubmitValues()", ex, false);
    }
}

function SetUserData(event) {
    try {
        var intid = event.InteractionID;
        var parse = JSON.parse(event.JsonData);
        if (hasGetDataEventDetails) {
            //add the callback tab
            AddVoiceTab(intid, parse.detail.CALLERID ? parse.detail.CALLERID : intid, false, true, event);
            //disable all the controls
            SetCallControlStatus(intid, false, false, false, false, false, false, false, false);
            //Initialize the UIKit accordion for the created tab
            UIkit.accordion($('#voice_accordion' + intid), {
                collapse: false,
                showfirst: true
            });
            $('#callControlDiv' + intid).toggle(false);
            //disable callbak dial buttons
            DisableCallbackDialButtons(intid);
        }
        $('#lbl_CallerID' + intid).val(parse.detail.CALLERID);
        // set the Caller ID text box read only or not based on the Global Config file
        if (!isCallerIDTextBoxReadonly) {
            $('#lbl_CallerID' + intid).attr('readonly', true);
        }
        //change the tab header to show caller id
        //set tab header details
        $('#divTabHeader' + intid).text(parse.detail.CALLERID);
        $('#hfAgentID' + intid).val(parse.detail.ASSIGNED_TO);
        $('#lbl_PCN' + intid).val(parse.detail.PREFFERRED_CONTACTNO);
        if (parse.detail.AGENT_NAME !== "") {
            $('#lbl_assignedTo' + intid).val(parse.detail.AGENT_NAME);
        } else {
            $('#lbl_assignedTo' + intid).val(global_AgentID);
        }
        $('#lbl_RDT' + intid).val(parse.detail.requestDateTime);
        if (isCRMCallbackEnd || isLanguageTruncateEnabled) {
            //disable submit button until callback auto dial is done
            if (!hasGetDataEventDetails) {
                DisableCallbackSubmitButtons(intid);
            }
        }
        if (isLanguageTruncateEnabled) {
            if (parse.detail.TYPE_OF_INQUIRY !== "") {
                var typeOfEnquiry = parse.detail.TYPE_OF_INQUIRY;
                var typeOfEnquiryPrefix = typeOfEnquiry.substring(0, 1);
                typeOfEnquiry = typeOfEnquiry.substring(2, typeOfEnquiry.length);
                if (typeOfEnquiryPrefix === 'E') {
                    $('#lbl_typeofenquiry' + intid).val(typeOfEnquiry + " {English}");
                } else if (typeOfEnquiryPrefix === 'C') {
                    $('#lbl_typeofenquiry' + intid).val(typeOfEnquiry + " {Cantonese}");
                } else if (typeOfEnquiryPrefix === 'M') {
                    $('#lbl_typeofenquiry' + intid).val(typeOfEnquiry + " {Mandarin}");
                } else {
                    $('#lbl_typeofenquiry' + intid).val(typeOfEnquiry);
                }
            } else {
                $('#lbl_typeofenquiry' + intid).val(parse.detail.TYPE_OF_INQUIRY);
            }
        } else {
            $('#lbl_typeofenquiry' + intid).val(parse.detail.TYPE_OF_INQUIRY);
        }
        $('#lbl_CQWT' + intid).val(parse.detail.QUEUE_WAIT_TIME + " seconds");
        $('#lbl_NOCA' + intid).val(parse.detail.NO_CALLBACK_ATTEMPTS);
        if (parse.detail.NO_CALLBACK_ATTEMPTS === "" || parse.detail.NO_CALLBACK_ATTEMPTS === "0") {
            DisableCallbackDetailsButtons(intid);
        }
        $('#hfSRNO' + intid).val(parse.detail.SRNO);
        $('#hfCBUCID' + intid).val(parse.detail.UCID);
        $('#hfTYPE' + intid).val(parse.detail.TYPE);
        //CIF
        $('#hfCIF' + intid).val(parse.detail.CIF);
        $('#lbl_CIF' + intid).val(parse.detail.CIF);
        //Pending callback count
        $('#lbl_CallbackCount' + intid).val(parse.detail.CallbackCount);
        $('#lblCurrentStat' + intid).text(parse.detail.CALLBACK_STATUS);
        var autoDialAfter = parse.detail.autoDialAfter;
        var autoDialEnabled = parse.detail.autoDialEnabled;
        if (parse.detail.countValue > 2) {
            var select = document.getElementById('ddl_status' + intid);
            select.options[select.options.length] = new Option('Unsuccessful', 'Unsuccessful');
            try {
                $("select option[value='Callback']").remove();
            } catch (ex) {
                log.LogDetails("Error", "TmacUI.SetUserData() - Remove Callback Option", ex, false);
            }
        }
        var comments = parse.detail.COMMENTS;
        if (comments !== "") {
            $('#txtComments' + intid).val(parse.detail.COMMENTS);
        }
        if (isTextChatCallback || isCRMCallbackEnd) {
            LoadInteractionHistoryOnDemand(global_DeviceID, intid, parse.detail.CIF, '', parse.detail.CALLERID);
        }
        //if agent initiated callback or customer initiated callback, update dial date and dial time 
        //for that srno in callback requests table
        if (isTextChatCallback) {
            custom_updateDialDateTimeForCallback(intid, parse.detail.SRNO);
        }
        if (!hasGetDataEventDetails) {
            if (!isTextChatCallback) {
                try {
                    //var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferRec;
                    var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferRec;
                    if (val) {
                        //do nothing
                    } else if (autoDialEnabled) {
                        StartcallbackTimer(global_DeviceID, intid, autoDialAfter, parse.detail.PREFFERRED_CONTACTNO);
                    }
                } catch (ex) {
                    log.LogDetails("Error", "TmacUI.SetUserData() - Inside", ex, false);
                }
            } else {
                isTextChatCallback = false;
            }
        }
        hasGetDataEventDetails = false;
        //launch the CRM
        //intid,cif,ucid,chatsessionid
        if (parse.detail.CIF === null) {
            parse.detail.CIF = "";
        }
        if (global_voiceCallHasCallback) {
            //do nothing
        } else {
            custom_GetVASessionIDForCallback(intid, parse.detail.CIF, parse.detail.UCID, parse.detail.SRNO);
        }
        SetPendingCallbackGridValues(event);
        //disable the close tab button
        $('#btnCloseTab' + intid).toggle(false);
        //if (GetTabReferenceObj(intid).OtherData.isCallbackTransferRec) {
        if (GetTabReferenceObj(intid).OtherData.isCallbackTransferRec) {
            DisableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
        }
        $("#li_" + intid).removeClass("li-on-call");
        if (!disableSubmitButton)
            EnableCallbackSubmitButtons(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetUserData()", ex, false);
    }
}

function GetVDNList(event) {
    try {
        var parse = JSON.parse(event.JsonData);

        if (parse.modulename === "callback") {
            var str = parse.detail;
            //Changed by Mukesh - 8th Aug,2016
            //SIP Dialer - Callback Extensions now will be range eg. 1000-1500
            var indices = 0;
            for (var i = 0; i < str.length; i++) {
                if (str[i] === "-") {
                    indices = i;
                }
            }
        } else if (parse.modulename === "textchat") {
            textChatVDNList = parse.detail;
        } else if (parse.modulename === "ibgdnis") {
            IBGDNISList = parse.detail;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetVDNList()", ex, false);
    }
}

function GetPopUpURL(event) {
    try {
        var parse = JSON.parse(event.JsonData);

        if (parse.modulename === "callback") {
            callbackPopUpURL = parse.detail;
        } else if (parse.modulename === "QMS") {
            QMSPopUpURL = parse.detail;
        } else if (parse.modulename === "ACW") {
            ACWPopUpURL = parse.detail;
        }

        if (parse.modulename === "MSDChatAccept") {
            MSDChatAcceptPopUpURL = parse.detail;
        } else if (parse.modulename === "MSDChatClose") {
            MSDChatClosePopUpURL = parse.detail;
        } else if (parse.modulename === "MSDCallbackAccept") {
            MSDCallbackAcceptPopUpURL = parse.detail;
        } else if (parse.modulename === "MSDCallbackClose") {
            MSDCallbackClosePopUpURL = parse.detail;
        } else if (parse.modulename === "MSDInboundVoice") {
            MSDInboundVoicePopUpURL = parse.detail;
        } else if (parse.modulename === "MSDOutboundVoice") {
            MSDOutboundVoicePopUpURL = parse.detail;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetPopUpURL()", ex, false);
    }
}

function SetCallbackDetailGridValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        dataToBind = parse.detail;
        var $kendoGrid = $('#callback_detail_grid').data('kendoGrid');
        $kendoGrid.dataSource.data(dataToBind);
        $kendoGrid.refresh();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetCallbackDetailGridValues()", ex, false);
    }
}

function Getdata(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var srno = parse.srno;
        if (srno !== "") {
            hasGetDataEventDetails = true;
            var existingCallbackForCustomerTabId = existingCallbackForCustomerTabId + 1;
            custom_getdetailsforSrno(existingCallbackForCustomerTabId, srno);
        } else {
            //do nothing
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.Getdata()", ex, false);
    }
}

function SaveTabReference(type, intid, status) {
    try {
        var staticTabs = ["main", "supervisor", "workbench", "interactionhistory", "dashboard", "meeting"];
        var tabRef = {};
        tabRef.direction = 'in';
        tabRef.type = type; //voice, callback, chat, facebook, fax
        tabRef.intid = intid;
        tabRef.status = status;
        tabRef.CRMWindowData = {};
        tabRef.OtherData = {};
        tabRef.firstSelect = true;
        tabRef.isActive = false;
        tabRef.tabTimer = null;
        tabRef.isStatic = staticTabs.indexOf(type) >= 0;
        tabRef.isCloseTab = false;

        global_InteractionTabs.push(tabRef);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SaveTabReference()", ex, false);
    }
}

function RemoveTabReference(intid) {
    try {
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            if (global_InteractionTabs[i].intid === parseInt(intid) || (isNaN(intid) && global_InteractionTabs[i].intid === intid)) {
                global_InteractionTabs.splice(i, 1);
                break;
            }
        }
        disconnectByHandleType = "";
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveTabReference()", ex, false);
    }
}

function ChangeTabReferenceStatus(intid, status) {
    try {
        GetTabReferenceObj(intid).status = status;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ChangeTabReferenceStatus()", ex, false);
    }
}

function GetTabReferenceObj(intid) {
    try {
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            if (global_InteractionTabs[i] !== undefined && (global_InteractionTabs[i].intid === parseInt(intid) || (isNaN(intid) && global_InteractionTabs[i].intid === intid)))
                return global_InteractionTabs[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetTabReferenceObj()", ex, false);
    }
}

//------------------------------------------------------------------------
//TODO:: To move these chat releated methods to tmac_text_chat_ui js 
//currently there is a check for this in main_ui OnTabStripActivate and OnTabStripSelected methods
//need to optimise the check in above mentioned methods and move these 3 methods.
function SaveChatReference(intid) {
    try {
        var chatRef = {};
        //intid
        chatRef.intid = intid;
        //intid
        chatRef.sessionId = "";
        //agent
        chatRef.isAgent = "";
        //customer
        chatRef.isCustomer = "";
        //save the agent name
        chatRef.agentName = "";
        //save the customer name
        chatRef.customerName = "";
        //save the customer/agent name for label reference
        chatRef.labelName = "";
        //customer typing flag
        chatRef.isTyping = false;
        //typing user
        chatRef.typingUser = "";
        //chat disconnected flag
        chatRef.isDisconnected = false;
        //tab blink for chat session
        chatRef.isBlink = false;
        //chat active for the session
        chatRef.isActive = false;
        //chat transfer flag
        chatRef.isTransfer = false;
        //chat conference flag
        chatRef.isConference = false;
        //hyperlink array to send to the customer
        chatRef.hyperLinks = [];
        //for the reply text
        chatRef.replyText = "";
        //if for agent reply or for customer reply
        chatRef.replyUser = "";
        //text, image, photo, audio, files
        chatRef.replyType = "";
        //reply text span id
        chatRef.replyId = "";
        //selected template
        chatRef.selectedTemplateId = "";
        //chat timer time taken to reply
        chatRef.timeTakenToReply = null;
        //chat timer time taken to reply counter
        chatRef.timeTakenCounter = 0;
        //chat mode
        chatRef.chatMode = "";
        //routing type
        chatRef.isNonVoiceRouting = false;
        //custom textchat json
        chatRef.customJson = null;
        //chat type
        chatRef.chatType = "";
        //conference type
        chatRef.conferenceType = "";
        //conference agent list
        chatRef.conferenceAgentList = [];
        //last message Id
        chatRef.lastMessageId = 1;
        //channel
        chatRef.channel = "";
        //flag to check isSMM textchat
        chatRef.isSMM = false;
        //  MOS
        chatRef.mos = 0;

        chatRef.stats = {
            duration: "",
            mos: {
                min: 0,
                max: 0
            },
            packetsLost: "",
            // available send bandwidth
            ASB: {
                min: 0,
                max: 0
            },
            jitter: {
                min: 0,
                max: 0
            },
            // 
            ABS: "",
            ABR: "",
            VBS: "",
            VBR: ""
        }
        //  AV call snapshots
        chatRef.avCallSnapshots = [];
        //push to the array for that interaction
        global_ChatReference.push(chatRef);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SaveChatReference()", ex, false);
    }
}

function GetChatReferenceObj(intid) {
    try {
        let ref = global_ChatReference.filter(function (x) { return x.intid === parseInt(intid); });
        if (ref.length > 0) {
            return ref[0];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetChatReferenceObj()", ex, false);
    }
    return null;
}

function RemoveChatReference(intid) {
    try {
        global_ChatReference = global_ChatReference.filter(function (x) { return x.intid !== parseInt(intid); });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveChatReference()", ex, false);
    }
}

function SaveVoiceReference(intid, type) {
    try {
        var voiceRef = {};
        voiceRef.intid = intid;
        voiceRef.ucid = "";
        voiceRef.type = type;
        voiceRef.subType = "";
        voiceRef.direction = "";
        voiceRef.phoneNumber = "";
        voiceRef.ivrTransferRef = ivrTransferRef;
        voiceRef.callSource = "";
        voiceRef.callStatus = "";
        voiceRef.isManualAnswer = false;
        voiceRef.processMediaMessages = false;
        voiceRef.msSessionId = "";
        voiceRef.msTransConfSessionId = "";
        voiceRef.msLineMode = "";
        voiceRef.mos = 0;
        voiceRef.mediaMessageRef = [];
        voiceRef.otherData = {};
        global_VoiceReference.push(voiceRef);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SaveVoiceReference()", ex, false);
    }
}

function GetVoiceReferenceObj(intid) {
    try {
        let ref = global_VoiceReference.filter(function (x) { return x.intid === parseInt(intid); });
        if (ref.length > 0) {
            return ref[0];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetVoiceReferenceObj()", ex, false);
    }
    return null;
}

function RemoveVoiceReference(intid) {
    try {
        global_VoiceReference = global_VoiceReference.filter(function (x) { return x.intid !== parseInt(intid); });
        // remove the webrtc session reference if found
        RemoveAConnRef(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveVoiceReference()", ex, false);
    }
}
//------------------------------------------------------------------------

function CloseAllTabs() {
    try {
        var intid = "";
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            intid = global_InteractionTabs[i].intid;
            if (!isNaN(intid)) {
                RemoveGlobalTimeoutReference(intid);
                CloseTab(intid);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseAllTabs()", ex, false);
    }
}

function RemoveGlobalTimeoutReference(intid) {
    try {
        for (var i = 0; i < global_timeoutFunctions.length; i++) {
            if (global_timeoutFunctions[i].intid === parseInt(intid)) {
                global_timeoutFunctions.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveGlobalTimeoutReference()", ex, false);
    }
}

function CloseOutgoingVoiceTab(event) {
    //check if this is an voice out tab. Then close the tab
    try {
        if (GetTabReferenceObj(event.InteractionID).type === 'voice') {
            //if (GetTabReferenceObj(event.InteractionID).type == 'voice') {
            if (GetTabReferenceObj(event.InteractionID).direction === 'out') {
                CloseTab(event.InteractionID);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseOutgoingVoiceTab()", ex, false);
    }
}

function isCallbackNumber(number) {
    try {
        if (callbackVDNListStart && callbackVDNListEnd)
            if (number >= callbackVDNListStart && number <= callbackVDNListEnd) {
                return true;
            }
        return false;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.isCallbackNumber()", ex, false);
    }
}

function isInternalCall(callerid) {
    try {
        if (callerid !== "" && callerid !== null) {
            //if length is equal to 5, station number, then return true
            if (callerid.length === '5') {
                return true;
            }
            //if length is equal to 9, check if first digit is 7(internal dbs - configurable), 
            //if yes then return true else return false
            else if (callerid.length === '9') {
                var val = callerid.substring(0, 1);
                if (val === internalNumberStartsWith) {
                    return true;
                }
                return false;
            }
        } else {
            return false;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.isInternalCall()", ex, false);
    }
}

//function ShowRecentAlerts() {
//    try {
//        //clear the content first
//        $("#div_recent_alerts").html("");
//        //loop the recentAlerts
//        for (var i = recentAlerts.length; i >= 0; i--) {
//            //append each items
//            $("#div_recent_alerts").append(recentAlerts[i]);
//        }
//        //append no alert message
//        AppendNoAlerts();
//        //popup the modal
//        UIkit.modal("#recent_alerts_dialog").show();
//        $("#btnrecentalerts i").text("notifications");
//        $("#btnrecentalerts i").removeClass("wiggle");
//        $("#recentAlertCount").text(0);
//    } catch (ex) {
//        log.LogDetails("Error", "TmacUI.ShowRecentAlerts()", ex, false);
//    }
//}

//function ClearAlerts() {
//    try {
//        //clear the contents
//        $("#div_recent_alerts").html("");
//        //clear the array
//        recentAlerts = [];
//        //append no alert message
//        AppendNoAlerts();
//    } catch (ex) {
//        log.LogDetails("Error", "TmacUI.ClearAlerts()", ex, false);
//    }
//}

function AppendNoAlerts() {
    try {
        //if the list is empty append no alert message
        if (recentAlerts.length === 0) {
            var alertManagerHtml = '<span class="uk-text-bold uk-text-primary">No recent alerts</span>';
            $("#div_recent_alerts").append(alertManagerHtml);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AppendNoAlerts()", ex, false);
    }
}

function OnSkillListChange(arg) {
    try {
        //dataitem
        var dataItem = this.dataItem(arg.item);
        //slected item
        var selectedItem = dataItem.SkillID;
        if (selectedItem) {
            ShowKendoLoading("#transCallagentListGrid");
            setTimeout(function () {
                LoadAgentListGrid('transCallagentListGrid', global_AgentList);
            }, 500);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnSkillListChange()", ex, false);
    }
}

function RefreshTransCallagentListGrid(type) {
    try {
        $('#transfer_skill_list').data("kendoDropDownList").value("");
        $('#transfer_skill_list').data("kendoDropDownList").text("Select skill..");
        LoadAgentListGrid(type, global_AgentList);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RefreshTransCallagentListGrid()", ex, false);
    }
}

function OnConsultTransferTypeSelected(arg) {
    try {
        var type = this.dataItem(arg.item).value;
        var intid = "";
        if (type === "Agent") {
            $("#pomTxtNumberTrans").attr("disabled", "disabled");
            $("#pomTxtNumberTransConf").attr("placeholder", "Agent ID");
        } else {
            $("#pomTxtNumberTrans").removeAttr("disabled", "disabled");
            $("#pomTxtNumberTransConf").attr("placeholder", "Enter the number");
        }

        if (global_CallType === "Transfer")
            intid = global_transferIntID;
        else if (global_CallType === "Conference")
            intid = global_conferenceIntID;

        GetConsultDestinationAgentsList(intid, type);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnConsultTransferTypeSelected()", ex, false);
    }
}

function SetPendingCallbackGridValues(event) {
    try {
        var intId = event.InteractionID;
        var grid = '#pending_callback_grid' + intId;
        var parse = JSON.parse(event.JsonData);
        if (parse.cifData.length > 0) {
            var $kendoGrid = $(grid).data('kendoGrid');
            $kendoGrid.dataSource.data(parse.cifData);
            var functionname = "CloseMultipleRequest(" + intId + ")";
            var closeallbuttonid = "closeallcallback" + intId;
            $(grid + " .k-pager-info").after("<button href='javascript: void(0)' onclick='" + functionname + "' class='k-button' id=" +
                closeallbuttonid + " style='float: right; height: 30px;'>Close All</button>");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetPendingCallbackGridValues()", ex, false);
    }
}

function CloseCallback(intid, srno, rowid) {
    try {
        // call the server side code and close this record
        var comments = $('#txtComments' + intid).val();
        custom_closeRequest(intid, srno, comments);
        $("#close_callback_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseCallback()", ex, false);
    }
}

function ScheduleCallback(intid, srno, type, rowid) {
    try {
        // call the server side code and close this record
        // call popupp window for reschedule
        $("#hfmultipleCallbackScheduleRequestType").val(type);
        $("#close_callback_dialog").data("kendoWindow").close();
        $("#schedule_multiple_callback_dialog").data("kendoWindow").center().open();
        $("#hfmultipleCallbackScheduleRequestSrno").val(srno);
        $("#hfmultipleCallbackScheduleRowId").val(rowid);
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#multipleCallbackSchedulePrefNumber").val(prefNumber);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ScheduleCallback()", ex, false);
    }
}

function CloseMultipleRequest(intid) {
    try {
        var comments = $('#txtComments' + intid).val();
        var myGrid = $("#pending_callback_grid" + intid).data('kendoGrid');
        var gridData = myGrid.dataSource.data();
        var array = "";
        // iterate one by one rows
        for (var i = 0; i < gridData.length; i++) {
            // Do Close call back either one by one or just pass selRowIds single shot
            if (i === 0) {
                array = gridData[i].SRNO;
            } else {
                array = array + "," + gridData[i].SRNO;
            }
        }
        if (array.split(',').length > 0) {
            custom_closeRequest(intid, array, comments);
        } else {
            log.LogDetails("Error", "TmacUI.CloseMultipleRequest()", "Please select the callbacks to be closed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseMultipleRequest()", ex, false);
    }
}

function CloseRequest(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult === "Record Successfully updated") {
            log.LogDetails("info", "TmacUI.CloseRequest()", "Callback request successfully closed", true);
            var srno = parse.srnoSuccess;
            var srnoList = srno.split(",");
            var $grid = $("#pending_callback_grid" + event.InteractionID).data().kendoGrid;
            var dataItem = $grid.dataSource.data();
            for (var i = 0; i < srnoList.length; i++) {
                var rowid;
                for (var j = 0; j < dataItem.length; j++) {
                    if (dataItem[j].SRNO === srnoList[i]) {
                        rowid = j;
                        break;
                    }
                }
                var rowItem = $grid.dataSource.data()[rowid];
                rowItem.set('CALLBACK_STATUS', 'Closed');
            }
            //if  there is only one cllback request then disable closall button after closing the request
            if (srnoList.length === 1) {
                $('#closeallcallback' + event.InteractionID).toggle(false);
            }
        } else if (parse.submitResult === "Record update failed") {
            log.LogDetails("Error", "TmacUI.CloseRequest()", "Callback request failed to close", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseRequest()", ex, false);
    }
}

function ScheduleCallbackComplete(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult === "RescheduleRequest success") {
            log.LogDetails("info", "TmacUI.ScheduleCallbackComplete()", "Callback request successfully rescheduled", true);
            $("#btnscheduleCallback" + parse.srno).prop("disabled", true);
            $("#btnCloseCallback" + parse.srno).prop("disabled", true);
            var srno = parse.srno;
            var srnoList = srno.split(",");
            var $grid = $("#pending_callback_grid" + event.InteractionID).data().kendoGrid;
            var dataItem = $grid.dataSource.data();
            for (var i = 0; i < srnoList.length; i++) {
                var rowid;
                for (var j = 0; j < dataItem.length; j++) {
                    if (dataItem[j].SRNO === srnoList[i]) {
                        rowid = j;
                        break;
                    }
                }
                var rowItem = $grid.dataSource.data()[rowid];
                rowItem.set('CALLBACK_STATUS', 'Callback');
            }
        } else if (parse.submitResult === "RescheduleRequest failed") {
            log.LogDetails("Error", "TmacUI.CloseRequest()", "Callback request failed", true);
        } else {
            log.LogDetails("Warning", "TmacUI.ScheduleCallbackComplete()", parse.submitResult, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ScheduleCallbackComplete()", ex, false);
    }
}

function LoadReminderEvent(event) {
    try {
        var grid;
        if (isFullTMAC) {
            HideKendoLoading("#reminder_grid_side");
            grid = $('#reminder_grid_side').data('kendoGrid');
            grid.dataSource.data(event.Reminders);
            grid.dataSource.sort({ field: "ID", dir: "desc" });
        } else {
            HideKendoLoading("#reminder_grid");
            grid = $('#reminder_grid').data('kendoGrid');
            grid.dataSource.data(event.Reminders);
            grid.dataSource.sort({ field: "ID", dir: "desc" });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadReminderEvent()", ex, false);
    }
}

function OpenAddReminderDialog() {
    try {
        $("#add_reminder_dialog").data("kendoWindow").title("Set Reminder");
        ResetReminder();
        $("#btnUpdateReminder").toggle(false);
        $("#btnSetReminder").css("display", "inline-block");
        $("#add_reminder_dialog").data("kendoWindow").center().open();
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenAddRemiderDialog()", ex, false);
    }
}

function AddReminder() {
    try {
        var message = $("#txtReminder").val();
        var date = $("#reminderDate").val();
        var time = $("#reminderTime").val() + ":00";
        if ($.trim(message) === "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please enter the message", true);
            return;
        }
        if ($.trim(date) === "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please select a date", true);
            return;
        }
        if ($.trim(time) === "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please enter the time", true);
            return;
        }
        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/;
        if (!re.test(time)) {
            log.LogDetails("Error", "TmacUI.AddRemider()", "Please enter a valid time", true);
            return false;
        }
        var inputDateTime = moment(date + " " + time, "DD/MM/YYYY HH:mm:ss");
        var validateDate = inputDateTime.isBefore(moment(new Date()));
        if (validateDate) {
            log.LogDetails("Error", "TmacUI.AddRemider()", "Reminder datetime should be greater than today", true);
            return false;
        }
        var reminderDate = inputDateTime.format("YYYY") + inputDateTime.format("MM") + inputDateTime.format("DD");
        var reminderTime = inputDateTime.format("HH") + inputDateTime.format("mm") + inputDateTime.format("ss");
        //add remider to the server
        CreateAgentReminder(reminderDate, reminderTime, message);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddRemider()", ex, false);
    }
}

function ResetReminder() {
    try {
        $("#txtReminder").val("");
        $("#reminderDate").val("");
        $("#reminderTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ResetReminder()", ex, false);
    }
}

function OpenEditReminderDialog() {
    try {
        $("#add_reminder_dialog").data("kendoWindow").title("Edit Reminder");
        ResetReminder();
        $("#btnDeleteReminder").addClass("disabled");
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid");
        } else {
            $grid = $("#reminder_grid").data("kendoGrid");
        }
        var $cell = $grid.select();
        var $row = $cell.closest('tr'); //selected tr
        var rowData = $grid.dataItem($row); //selected row data
        $("#txtReminder").val(rowData.Message);
        $("#reminderDate").val(moment(rowData.RemindDate, "DD/MM/YYYY").format("DD/MM/YYYY"));
        $("#reminderTime").val(rowData.RemindTime);
        $("#txtReminder").attr("readonly", "readonly");
        $("#btnSetReminder").toggle(false);
        $("#btnUpdateReminder").css("display", "inline-block");
        $("#add_reminder_dialog").data("kendoWindow").center().open();
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenAddRemiderDialog()", ex, false);
    }
}

function EditReminder() {
    try {
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid");
        } else {
            $grid = $("#reminder_grid").data("kendoGrid");
        }
        var $cell = $grid.select();
        var $row = $cell.closest('tr'); //selected tr
        var rowData = $grid.dataItem($row); //selected row data
        var obj = {};
        obj.status = "edit";
        //**----TO DO-----**
        //Edit reminder is not present now
        //Server side change or delete and add new
        //**----TO DO-----**
        DisableButton("#btnEditReminder");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.EditRemider()", ex, false);
    }
}

function DeleteReminder() {
    try {
        UIkit.modal.confirm("Are you sure to delete this reminder?",
            function () {
                if (isFullTMAC) {
                    $grid = $("#reminder_grid_side").data("kendoGrid");
                } else {
                    $grid = $("#reminder_grid").data("kendoGrid");
                }
                var $cell = $grid.select();
                var $row = $cell.closest('tr'); //selected tr
                var rowData = $grid.dataItem($row); //selected row data
                var obj = {};
                obj.status = "delete";
                UpdateAgentReminder(rowData.ID, "delete", rowData.Message, obj);
                DisableButton("#btnDeleteReminder");
            },
            function oncancel() { });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DeleteRemider()", ex, false);
    }
}

function StartReminderThread(event) {
    try {
        //check for the reminders once then start the thread for every 1 min
        CheckForReminders(event.Reminders);
        //if the thread is not started and event.Auto !== 1 then start else leave
        if (!isReminderThreadStarted && event.Auto !== "1") {
            isReminderThreadStarted = true;
            //start the thread
            setInterval(function () {
                CheckForReminders();
            }, 60000);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartReminderThread()", ex, false);
    }
}

function CheckForReminders(reminders) {
    try {
        $.each(reminders, function (i, val) {
            if (val.Status === "New") {
                var dateTime = new Date(val.RemindDate + " " + val.RemindTime);
                var momentDateTime = moment(new Date(dateTime), "DD/MM/YYYY HH:mm").format("YYYYMMDDHHmm");
                var momentNowDateTime = moment(new Date(), "DD/MM/YYYY HH:mm").format("YYYYMMDDHHmm");
                if (parseInt(momentDateTime) <= parseInt(momentNowDateTime)) {
                    var type = "new";
                    if (parseInt(momentDateTime) < parseInt(momentNowDateTime)) {
                        type = "old";
                    }
                    ShowReminder(val.ID, val.Message, val.RemindDate + " " + val.RemindTime + ":00", type);
                    UpdateAgentReminder(val.ID, "Completed", "", null);
                }
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckForReminders()", ex, false);
    }
}

function ProcessReminderMessage(reminders) {
    try {
        var result = [];
        $.each(reminders, function (i, val) {
            var type = val.Type;
            var message = val.Message;
            if (type) {
                var isJsonMessage = IsValidJson(message);
                if (isJsonMessage) {
                    var json = JSON.parse(message);
                    switch (type) {
                        case "faxsendfailed":
                            var file = json.m_FilePath.split('\\').pop().split('/').pop();
                            val.Message = "Fax (" + file + ") send failed to " + json.m_To;
                            break;
                        default:
                            break;
                    }
                }
            }
            result.push(val);
        });
        return result;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ProcessReminderMessage()", ex, false);
    }
    return reminders;
}

function ShowReminder(id, message, dateTime, type) {
    try {
        var title = "";
        if (type === "new")
            title = "You have a new reminder: " + dateTime;
        else
            title = "You had a reminder @ " + dateTime;
        $("<div id='reminderWindow" + id + "' />").appendTo(document.body).kendoWindow({
            minWidth: 350,
            draggable: true,
            resizable: true,
            title: title,
            scrollable: false,
            modal: false,
            actions: ["Close"],
            deactivate: function () {
                this.destroy();
            }
        }).data("kendoWindow").center().open().content("<span class='onboarding_welcome_message'>" + message + "</span>");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ShowReminder()", ex, false);
    }
}

function ClearSelectedReminder() {
    try {
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid").clearSelection();
        } else {
            $grid = $("#reminder_grid").data("kendoGrid").clearSelection();
        }
        $("#btnClearSelectedReminder").addClass("disabled");
        $("#btnEditReminder").addClass("disabled");
        $("#btnDeleteReminder").addClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ClearSelected()", ex, false);
    }
}

function LoadChatUserList() {
    try {
        if (isAgentChat)
            agent_chat.agentlist();
        else
            customer_chat.get_customerlist();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadChatUserList()", ex, false);
    }
}

function GetMyLanId() {
    try {
        $.ajax({
            type: "POST",
            data: null,
            url: "Login.aspx/GetMyLanID",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (user) {
                //Login(user.d.split('\\')[1], "autodiscover", "", false, false, "");
                //Login("saman", "autodiscover", "", false, false, "");
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetMyLanId()", ex, false);
    }
}

function GetServiceWindowURL(event) {
    try {
        var obj = {};
        obj.defaultUrl = false;
        //campaign manager
        if (event.SubType && event.SubType.toLowerCase() === "camp") {
            //get the subtype data
            let subTypeData = JSON.parse(event.SubTypeData);
            //create the params
            let params = "fromAddr=" + subTypeData.fromAddress + "&agentID=" + global_AgentID + "&extension=" + global_DeviceID + "&ucid=" + event.UCID + "&skill=" + event.Queue + "&intid=" + event.InteractionID + "&ID=" + event.ID;
            //get the url from config
            let url = campSelectorUrl.endsWith("fromAddr=") ? campSelectorUrl.replace("fromAddr=", "") : campSelectorUrl;
            url = campSelectorUrl.endsWith("?") ? campSelectorUrl : campSelectorUrl + "?";
            obj.type = "Campaign";
            obj.url = url + params;
        } else if (isCRMEnabled && customCRMUrl) {
            obj.type = "CRM";
            obj.url = customCRMUrl;
        } else {
            obj.type = "Service Window";
            obj.url = "na";
        }
        return obj;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetServiceWindowURL()", ex, false);
    }
}

function OpenSupportDoc() {
    try {
        window.open(supportDocUrl, "_blank", "menubar=no,resizable=0,location=no,scrollbars=no,width=" + screen.width / 2 + ",height=" + screen.height).moveTo(0, 0);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenSupportDoc()", ex, false);
    }
}

function ToggleTmacScreen() {
    try {
        window.resizeTo(screen.width, screen.height);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ToggleTmacScreen()", ex, false);
    }
}

function ShowNotLoggedInScreen() {
    try {
        document.title = titleName;
        $("#loggedOutMessage").text("Agent session is not available in TMAC!");
        $(".an-loader").addClass("uk-display-none");
        $("#tab_card_content").addClass("uk-display-none");
        $("#logged_out_card_content").removeClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ShowNotLoggedInScreen()", ex, false);
    }
}

function OpenIframeTab(type, myUrl, tabName, allowMultiple, interactionId) {
    try {
        var icon = "";
        var url = "";
        var lType = type.toLowerCase();
        var id = interactionId ? interactionId : (allowMultiple ? lType + "_" + uuid() : lType);
        switch (lType) {
            case "supervisor":
                icon = "people";
                url = (IsValidURL(supervisorLink) ? supervisorLink : GetBaseUrl(global_connectedProxy) + supervisorLink) + "?supervisorid=" + global_AgentID + "&supervisornumber=" + global_DeviceID + "&teamid=" + global_TeamID;
                break;
            case "workbench":
                icon = "library_books";
                url = (IsValidURL(workbenchLink) ? workbenchLink : GetBaseUrl(global_connectedProxy) + workbenchLink) + "?agentId=" + global_AgentID + "&theme=" + localStorage.getItem("altair_theme") + "&font=" + localStorage.getItem("font_family");
                break;
            case "interactionhistory":
                icon = "list_alt";
                url = myUrl;
                break;

            case "twitter":
                icon = "chat";
                url = myUrl;
                break;

            case "twitterdm":
                icon = "chat";
                url = myUrl;
                break;

            case "line":
                icon = "chat";
                url = myUrl;
                break;

            case "meeting":
                icon = "meeting_room";
                url = myUrl;
                break;

            case "gen_video-audit":
                icon = "done_outline";
                url = myUrl;
                break;
        }

        if (!GetTabReferenceObj(lType) || allowMultiple) {
            SaveTabReference(lType, id, 'new');
            //tab header content
            var tempTabHeaderContent = GetHtmlFromTemplate("tab_header_template", id, { icon: icon });
            //tab body content
            var tempTabContent = GetHtmlFromTemplate("iframe_template", id, null);
            //add a kendo tab
            AddTab(tempTabContent, tempTabHeaderContent, id, tabName ? tabName : type, true, true, false);

            if (lType === "meeting") {
                let frame = document.getElementById(id + "_iframe");
                frame.sandbox = "allow-modals allow-scripts allow-same-origin";
                frame.allow = "microphone; camera; autoplay";
                frame.contentWindow.onbeforeunload = function () {
                    //
                };
            }

            //load the iframe
            LoadIFrame(id + "_iframe", url);

            switch (lType) {
                case "supervisor":
                    if (isExpandCollapseOnIframes.Supervisor) {
                        window.resizeTo(screen.width, screen.height);
                        ResizeCustom("max");
                    }
                    break;
                case "workbench":
                    if (isExpandCollapseOnIframes.Workbench) {
                        window.resizeTo(screen.width, screen.height);
                        ResizeCustom("max");
                    }
                    break;
                case "meeting":
                    window.resizeTo(screen.width, screen.height);
                    ResizeCustom("max");
                    break;
            }
        } else {
            log.LogDetails("Error", "TmacUI.OpenWorkbench()", type + " window is already opened", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenWorkbench()", ex, false);
    }
}

function PopUpScreen(event) {
    try {
        var ani = event.Params[0];
        var dnis = event.Params[1];
        if (ani === "10001") {
            window.open(event.URL, "Callback", "menubar=no,location=no,scrollbars=no");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.PopUpScreen()", ex, false);
    }
}

function BindWorkCodes(intid) {
    try {
        $("#lblWorkCode" + intid).text(workCodeLabel);
        $("#workcodes_div" + intid).removeClass("uk-display-none");
        let dataSource;
        if (isWorkCodeWithGroup) {
            dataSource = {
                data: global_WorkCodeList,
                group: { field: "ParentName" }
            };
        } else {
            dataSource = $.map(global_WorkCodeList, function (n) { return { "Name": n.Name, "Code": n.Code }; });
        }

        $("#workcodes" + intid).kendoMultiSelect({
            maxSelectedItems: maxWorkCodeSelectedItems, //only configured number or less items could be selected
            dataTextField: "Name",
            dataValueField: "Code",
            dataSource: dataSource,
            deselect: function (arg) {
                RemoveCallWorkCode(intid, arg.dataItem.Code);
            },
            select: function (arg) {
                SetCallWorkCode(intid, arg.dataItem.Code);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.BindWorkCodes()", ex, false);
    }
}

function CheckForCompletionCode(intid, ignoreAlert) {
    try {
        var tabType = GetTabReferenceObj(intid).type;
        var check = isWorkCode[tabType] && isWorkCode[tabType].enable && isWorkCode[tabType].mandatoryComplete;
        if (check && $("#workcodes" + intid).data("kendoMultiSelect") && $("#workcodes" + intid).data("kendoMultiSelect").value().length === 0) {
            //since the close tab is called from different place multiple time this message can be show
            //we need to ignore the alert for some cases
            if (!ignoreAlert) {
                log.LogDetails("Error", "TmacUI.CheckForCompletionCode()", "Please complete with completion code", true);
            }
            return false;
        }
        return true;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckForCompletionCode()", ex, false);
    }
}

function LoadAllChatTemplates() {
    try {
        tmac_SMS_GetSMSTemplateDepartments("GetAllChatTemplateDepartmentsDone", null);
        //reload the chat templates every config interval
        //if the threshold is 0 then no need to reload
        if (chatTemplatesUpdateThreshold > 0) {
            setTimeout(function () {
                LoadAllChatTemplates();
            }, chatTemplatesUpdateThreshold * 60000);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadAllChatTemplates()", ex, false);
    }
}

function GetAllChatTemplateDepartmentsDone(data) {
    try {
        $.each(data, function (i, val) {
            tmac_SMS_GetSMSTemplateGroups("GetAllChatTemplateGroupsDone", null, val.ID);
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetAllChatTemplateDepartmentsDone()", ex, false);
    }
}

function GetAllChatTemplateGroupsDone(data) {
    try {
        $.each(data, function (i, val) {
            tmac_SMS_GetSMSTemplates("GetAllChatTemplatesDone", null, val.ID);
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetAllChatTemplateGroupsDone()", ex, false);
    }
}

function GetAllChatTemplatesDone(data) {
    try {
        $.each(data, function (i, val) {
            if (val.Type && (val.Type.toLowerCase() === "chat" || val.Type.toLowerCase() === "textchat")) {
                //check if the item is already added to the list
                var item = allChatTemplates.filter(function (t) { return t.Name === val.Name; });
                //if item is not in the list filter it on the statTime and endTime and add to the list
                if (item.length === 0) {
                    if (isTemplateTimeFilter && val.StartTime && val.EndTime) {
                        let format = "HH:mm:ss",
                            time = moment(new Date(), format),
                            beforeTime = moment(val.StartTime, format),
                            afterTime = moment(val.EndTime, format);
                        //check if the template to be shown in this period of time
                        if (time.isBetween(beforeTime, afterTime))
                            allChatTemplates.push(val);
                    } else {
                        allChatTemplates.push(val);
                    }
                }
                //if item is alread there then just update it
                else {
                    allChatTemplates[0] = val;
                }
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetAllChatTemplatesDone()", ex, false);
    }
}

function GetTemplatesForInteraction(type, intid) {
    try {
        if (intid) tempIntIdForChatTemplate = intid;
        GetChatTemplateDepartments(type);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckForCompletionCode()", ex, false);
    }
}

function GetChatTemplateDepartments(type) {
    let obj = {
        type: type,
        channel: (type === "chat" || type === "cobrowse") ? "textchat" : type
    };
    tmac_SMS_GetSMSTemplateDepartments("GetChatTemplateDepartmentsDone", obj);
}

function GetChatTemplateDepartmentsDone(data, obj) {
    try {
        data = data.filter(function (d) { return d.Channel.toLowerCase() === obj.channel.toLowerCase(); });
        if (data.length > 0) {
            var $kendoComboBox = $("#" + obj.type + "_dept_combobox").data("kendoComboBox");
            $kendoComboBox.enable();
            $kendoComboBox.dataSource.data(data);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetChatTemplateDepartmentsDone()", ex, false);
    }
}

function CreateGridComboBoxes(type) {
    try {
        //chat template department dropdown
        $("#" + type + "_dept_combobox").kendoComboBox({
            dataTextField: "Name",
            dataValueField: "ID",
            placeholder: "Departments",
            filter: "contains",
            suggest: true,
            index: 1,
            enable: false,
            change: OnChatDeptChange,
            select: OnChatDeptSelect
        });

        $("#" + type + "_grp_combobox").kendoComboBox({
            dataTextField: "Name",
            dataValueField: "ID",
            placeholder: "Groups",
            filter: "contains",
            suggest: true,
            index: 1,
            enable: false,
            change: OnChatGrpChange,
            select: OnChatGrpSelect
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CreateGridComboBoxes()", ex, false);
    }
}

function OnChatDeptChange(arg) {
    try {
        var thisId = arg.sender.element[0].id;
        var type = thisId.split("_")[0];
        var $kendoComboBox = $("#" + type + "_grp_combobox").data("kendoComboBox");
        $kendoComboBox.enable(false);
        $kendoComboBox.value("");
        $kendoComboBox.dataSource.data("");

        $("#" + type + "_template_grid").data("kendoGrid").dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnChatDeptChange()", ex, false);
    }
}

function OnChatDeptSelect(arg) {
    try {
        var thisId = arg.sender.element[0].id;
        var type = thisId.split("_")[0];
        var dataItem = this.dataItem(arg.item);
        var deptId = dataItem.ID;
        tmac_SMS_GetSMSTemplateGroups("GetChatTemplateGroupsDone", { type: type }, deptId);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnChatDeptSelect()", ex, false);
    }
}

function GetChatTemplateGroupsDone(data, obj) {
    try {
        setTimeout(function () {
            var $kendoComboBox = $("#" + obj.type + "_grp_combobox").data("kendoComboBox");
            $kendoComboBox.enable();
            $kendoComboBox.dataSource.data(data);

            //  VP : May 22, '20: If co-browse, directly select co-browse group
            if (obj.type === "cobrowse") {
                let triggerNeeded = false;
                $kendoComboBox.select(function (dataItem) {
                    if (dataItem.Name.toLowerCase() === "cobrowse") {
                        triggerNeeded = true;
                        return true;
                    }
                });
                if (triggerNeeded)
                    $kendoComboBox.trigger("select")
            }
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetChatTemplateGroupsDone()", ex, false);
    }
}

function OnChatGrpChange(arg) {
    try {
        var thisId = arg.sender.element[0].id;
        var type = thisId.split("_")[0];
        $("#" + type + "_template_grid").data("kendoGrid").dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnChatGrpChange()", ex, false);
    }
}

function OnChatGrpSelect(arg) {
    try {
        var thisId = arg.sender.element[0].id;
        var type = thisId.split("_")[0];
        var dataItem = this.dataItem(arg.item);
        var grpId = dataItem.ID;
        if (grpId !== "Groups")
            tmac_SMS_GetSMSTemplates("GetChatTemplatesDone", { type: type }, grpId);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnChatGrpSelect()", ex, false);
    }
}

function GetChatTemplatesDone(data, obj) {
    try {
        var templates = [];
        $.each(data, function (i, val) {
            if (isTemplateTimeFilter && val.StartTime !== "" && val.StartTime !== null && val.EndTime !== "" && val.EndTime !== null) {
                let format = "HH:mm:ss",
                    time = moment(new Date(), format),
                    beforeTime = moment(val.StartTime, format),
                    afterTime = moment(val.EndTime, format);
                if (time.isBetween(beforeTime, afterTime))
                    templates.push({ ID: val.ID, Text: val.Text });
            } else {
                templates.push({ ID: val.ID, Text: val.Text });
            }
        });
        setTimeout(function () {
            $("#" + obj.type + "_template_grid").data("kendoGrid").dataSource.data(templates);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetChatTemplatesDone()", ex, false);
    }
}

function OnDashboardIntervalChange(arg) {
    try {
        if (isSignalrConnector)
            ProcessMiniDashboard(true, this.dataItem(arg.item).value);
        else
            GetMiniDashboard(this.dataItem(arg.item).value, globalChannelList, null);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnDashboardIntervalChange()", ex, false);
    }
}

function MiniDashboardEvent(event) {
    try {
        var jsonData = JSON.parse(event.JsonData)[0];
        if (jsonData) {
            $.each(jsonData, function (key, value) {
                if ($("#" + key).length > 0)
                    $("#" + key).text(value);
            });

            $('.countUpMe').each(function () {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).text()
                }, {
                    duration: 1000,
                    easing: 'swing',
                    step: function (now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.MiniDashboardEvent()", ex, false);
    }
}

function AgentLogout() {
    try {
        if (!allowLogoutOnOpenTabs && global_InteractionTabs.filter(function (t) { return !t.isStatic; }).length > 0) {
            log.LogDetails("Error", "CommandManager.Logout()", "Please close existing tabs before logout", true);
            return;
        }
        UIkit.modal.confirm('Please confirm your log-out',
            function () {
                LogoutConfirmed();
            });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentLogout()", ex, false);
    }
}

function LogoutConfirmed() {
    try {
        logout_button_clicked = true;
        Logout(global_DeviceID);
        CloseNotifications();
        LogoffAlert("Logging Out", false, 10000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LogoutConfirmed()", ex, false);
    }
}

function LogoffAlert(message, forcedlogoff, timer) {
    try {
        UIkit.modal.blockUI('<div class=\'uk-text-center\'>' + message + '<br/><img class=\'uk-margin-top\' src=\'assets/img/spinners/spinner.gif\' alt=\'\'>');
        setTimeout(function () {
            if (forcedlogoff) {
                window.close();
                if (isSinglePageLogin) location.reload();
            }
        }, timer);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LogoffAlert()", ex, false);
    }
}

function AjaxError(xhr, callbackFunction, userObject, inputData, methodName) {
    try {
        log.LogDetails("Error", "TmacUI.AjaxError()", "Response: " + xhr.responseText + ", MethodName: " + methodName + ", Status: " + xhr.status, false);

        if (retryAjaxFail) {
            if (xhr.status === 500) {
                setTimeout(function () {
                    if (ArrayItemCount(ajaxRetryRef, methodName) >= ajax_retry_count) {
                        console.warn("Method call retrying count exceeded for MethodName: " + methodName);
                        return;
                    }

                    ajaxRetryRef.push(methodName);

                    log.LogDetails("Info",
                        "TmacUI.AjaxError()",
                        "Retrying method call: " + methodName + ", Retry count: " + ArrayItemCount(ajaxRetryRef, methodName),
                        false);

                    tmac_command(callbackFunction, userObject, inputData, methodName);
                }, 500);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AjaxError()", ex, false);
    }
}

function ArrayItemCount(arrayName, item) {
    try {
        return arrayName.filter(function (i) { return i === item; }).length;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ArrayItemCount()", ex, false);
    }
    return 0;
}

function ProxyConnectionSuccessEvent(proxyName) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ProxyConnectionSuccessEvent()", ex, false);
    }
}

function GetSkillNameFromWallbaord(skillId) {
    try {
        var wallboardItems = $("#wallboardGrid_main").data("kendoGrid").dataItems();
        if (wallboardItems && wallboardItems.length > 0) {
            var item = wallboardItems.filter(function (i) { return i.SkillID === skillId; });
            if (item.length > 0) {
                item = item[0];
                return item.SkillName;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetSkillNameFromWallbaord()", ex, false);
    }
}

function LogFileVersions() {
    try {
        //log sdk versions
        log.LogDetails("Info", "TmacUI.LogFileVersions()", sdk_versions, false);

        //log file versions
        log.LogDetails("Info", "TmacUI.LogFileVersions()", file_versions, false);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LogFileVersions()", ex, false);
    }
}

function GetTransferResponseFromAgent(eventData) {
    try {
        var otherData = JSON.parse(eventData.OtherData),
            s = $("#notification_confirm_template").html(),
            t = Handlebars.compile(s),
            context = {
                agent: eventData.FromAgentName,
                type: otherData.type,
                mode: eventData.Channel,
                deviceid: global_DeviceID,
                isComment: eventData.Comment ? true : false,
                comment: eventData.Comment,
                showComment: isCommentOnConfirmaion
            },
            html = t(context);

        var tPop = UIkit.modal.confirm(html,
            function () {
                SendInteractionNotificationResponseToServer(eventData, "Accept");
            },
            function oncancel() {
                SendInteractionNotificationResponseToServer(eventData, "Reject");
            });
        var tRef = transferNotificationPop.filter(function (t) { return t.from === eventData.FromAgentID; });
        //add popup reference
        if (tRef.length === 0) {
            transferNotificationPop.push({ from: eventData.FromAgentID, tPop: tPop });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetTransferResponseFromAgent()", ex, false);
    }
}

function TransferResponseReceived(event) {
    try {
        var intid = event.InteractionID;
        //to enable the transfer button

        var obj = {};
        obj.eventData = event;
        if (global_CallType.toLowerCase().indexOf("transfer") >= 0) {
            obj.buttonId = "#btndialogtransfercall";
            obj.icon = "swap_horiz";
            obj.type = ToCamelCase(event.Channel) + "Transfer";
        } else if (global_CallType.toLowerCase().indexOf("conference") >= 0) {
            obj.buttonId = "#btnConfMCall";
            obj.icon = "call_split";
            obj.type = ToCamelCase(event.Channel) + "Conference";
        }

        //check the response message
        if (event.Response === "Accept") {
            //accept
            InteractionTransferToServer(obj, event);
        } else {
            var otherData = JSON.parse(event.OtherData);
            //reject
            log.LogDetails(
                "Warning",
                "TmacUI.TransferResponseReceived()",
                event.FromAgentName + " has rejected your " + otherData.type + " request" +
                (event.Comment !== "" ? " with comment: " + event.Comment : ""),
                true);

            //enable the transfer button
            EnableButton(obj.buttonId, obj.icon, "icon");
        }
        //remove the notification sent reference
        RemoveTransferNotificationRef(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.TransferResponseReceived()", ex, false);
    }
}

var transferNotifIntRef = [];

function AddTransferNotificationRef(intid, type, to, toServer) {
    try {
        var obj = {};
        obj.intid = intid;
        obj.type = type;
        obj.to = to;
        obj.from = global_AgentID;
        obj.toServer = toServer;
        obj.counter = 20;
        //TTL for the object is 1 min
        let startedOn = new Date();
        //obj.startedOn = startedOn.setMinutes(startedOn.getMinutes() + 1);
        obj.startedOn = startedOn.setSeconds(startedOn.getSeconds() + obj.counter);
        transferNotificationRef.push(obj);
        //interval obj
        var intObj = setInterval(function (x) {
            let notifRef = GetTransferNotificationRef(x.intid);
            if (notifRef) {
                $("#uk_alert_Transfer").text("Consult notification expires in " + notifRef.counter + " seconds");
                notifRef.counter--;
            }
            //get the expiry timeout
            let timerExpired = new Date().getTime() > x.startedOn;
            //check if the timer expired or reference is removed by the response from other agent
            if (timerExpired || !notifRef) {
                if (timerExpired) {
                    log.LogDetails("Info", "TmacUI.AddTransferNotificationRef()", "Transfer notification expired: timer expired", false);
                    //remove after the TTL if not removed by the notification response
                    RemoveTransferNotificationRef(x.intid);
                    //send the command to agent to remove the notification
                    SendCommandToAgent(null, "", x.to, x.toServer, "", "TransferNotificationExpired", JSON.stringify(x));
                    EnableTransferConfButton();
                }
                if (!notifRef) {
                    log.LogDetails("Info", "TmacUI.AddTransferNotificationRef()", "Transfer notification expired: remote party responsed", false);
                }
                //close the timer box
                $("#uk_alert_close_Transfer").click();
                //clear the interval reference
                clearInterval(intObj);
            }
        }, 1000, obj);

        HandleIMs("Transfer", "Consult notification expires in " + obj.counter + " seconds", "info", "transfertimeout", "", false);

        ////interval obj
        //var intObj = setInterval(function (x) {
        //    if (new Date().getTime() > x.startedOn) {
        //        //check if the reference is there
        //        if (GetTransferNotificationRef(x.intid) !== null) {
        //            //remove after the TTL if not removed by the notification response
        //            RemoveTransferNotificationRef(x.intid);
        //            //send the command to agent to remove the notification
        //            SendCommandToAgent(null, "", x.to, x.toServer, "", "TransferNotificationExpired", JSON.stringify(x));
        //            log.LogDetails("Info", "TmacUI.AddTransferNotificationRef()", "Transfer notification expired", false);
        //        }
        //        //clear the interval reference
        //        clearInterval(transferNotifIntRef.filter(function (t) { return t.to === x.to; })[0].intObj);
        //    }
        //}, 5000, obj);
        ////add reference of interval object
        //if (transferNotifIntRef.filter(function (t) { return t.to === to; }).length === 0) {
        //    transferNotifIntRef.push({ to: to, intObj: intObj });
        //}
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddTransferNotificationRef()", ex, false);
    }
}

function CanSendNotification(intid) {
    try {
        //get the notification reference, if there dont allow new notification
        var ref = GetTransferNotificationRef(intid);
        if (ref) {
            log.LogDetails("Warning", "TmacUI.TransferResponseReceived()", "Chat " + ref.type + " notification is already sent, Please wait for the response.", true);
            return false;
        } else {
            return true;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CanSendNotification()", ex, false);
    }
    return true;
}

function GetTransferNotificationRef(intid) {
    try {
        let ref = transferNotificationRef.filter(function (t) { return t.intid === parseInt(intid); });
        if (ref.length > 0) {
            return ref[0];
        }
        return null;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetTransferNotificationRef()", ex, false);
    }
}

function RemoveTransferNotificationRef(intid) {
    try {
        transferNotificationRef = transferNotificationRef.filter(function (t) { return t.intid !== parseInt(intid); });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveTransferNotificationRef()", ex, false);
    }
}

function AgentActionEvent(event) {
    try {
        //get the json data
        var jsonData = JSON.parse(event.JsonData);
        //check if the json data is null
        if (jsonData !== null) {
            //switch based on the 'Type'
            switch (jsonData.Type) {
                case "SupervisorAction":
                    log.LogDetails("Info", "TmacUI.AgentActionEvent().SupervisorAction", jsonData.Message, true);
                    //force close the tab
                    ForceCloseTab(event.InteractionID);
                    break;
                case "WorkbenchAction":
                    //if the action is SendPullRequest
                    if (jsonData.Action === "SendPullRequest") {
                        //get the supervisor info
                        var supervisorInfo = jsonData.SupervisorInfo;
                        //get the transfer data
                        var transferData = jsonData.TransferData;
                        log.LogDetails("Info", "TmacUI.AgentActionEvent().SupervisorAction",
                            "Supervisor '" + supervisorInfo.agentName + "' sent pull request for a " + transferData.channel + " item", true);
                        //pull queue item from server
                        PullQueueItem({ isSupervisor: true, transferData: transferData, supervisorInfo: supervisorInfo }, transferData.channel, transferData.itemID);
                    }
                    //if the action is PullRequestFailed
                    else if (jsonData.Action === "PullQueueItemStatus") {
                        //show the message based on the status
                        if (jsonData.isSuccess) {
                            log.LogDetails("Success", "TmacUI.AgentActionEvent()",
                                ToCamelCase(jsonData.TransferData.channel) +
                                " queue item transferred to agent (" + jsonData.TransferData.agentName + ") successfully",
                                true);
                        } else {
                            log.LogDetails(jsonData.isSuccess ? "Success" : "Error", "TmacUI.AgentActionEvent()", "Transfer failed: " + jsonData.Message, true);
                        }
                        //if the status is success the send reload workbench request
                        if (jsonData.isSuccess) {
                            //get the iframe by id
                            var workbenchIframe = document.getElementById("workbench_iframe");
                            //get the iframe content window
                            var workbenchWindow = workbenchIframe ? workbenchIframe.contentWindow : null;
                            //if the content is not null invoke post message
                            if (workbenchWindow) {
                                InvokePostMessage(workbenchWindow, null, "CommonUi.GetInitialData", null, null);
                            }
                        }
                    } else {
                        log.LogDetails("Error", "TmacUI.AgentActionEvent()", "Action '" + jsonData.Type + "' is not defined in '" + jsonData.Type + "' case", false);
                    }
                    break;
                default:
                    log.LogDetails("Error", "TmacUI.AgentActionEvent()", "Type '" + jsonData.Type + "' is not defined in case", false);
                    break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentActionEvent()", ex, false);
    }
}

function InvokePostMessage(frame, callback, method, data, userObject) {
    try {
        if (!frame) {
            log.LogDetails("Error", "TmacUI.InvokePostMessage()", "frame/window is null", false);
            return;
        }
        frame.postMessage({
            function: method,
            callback: callback,
            data: data,
            source: "tmac",
            userObject: userObject
        }, "*");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.InvokePostMessage()", ex, false);
    }
}

function EnableTransferConfButton() {
    try {
        //create the object to enable the button
        var obj = {
            buttonId: global_CallType === "TextChatTransfer" ? "#btndialogtransfercall" : global_CallType === "TextChatConference" ? "#btnConfMCall" : "",
            icon: global_CallType === "TextChatTransfer" ? "swap_horiz" : global_CallType === "TextChatConference" ? "call_split" : "",
            type: global_CallType === "TextChatTransfer" ? "TextChatTransfer" : global_CallType === "TextChatConference" ? "TextChatConference" : ""
        };
        //enable the transfer button
        if (obj.buttonId) {
            EnableButton(obj.buttonId, obj.icon, "icon");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.EnableTransferConfButton()", ex, false);
    }
}

function AssignAgentData(data, isUpdate) {
    try {
        isCRMEnabled = data.IsCRMEnabled === 1;
        global_TextChatGreetingText = data.TextChatGreetingText;
        agentCRMName = data.CRMName;

        //assign all the global variables
        global_DeviceID = data.StationID;
        global_AgentID = data.AgentID;
        global_AgentName = data.AgentName ? data.AgentName : "";

        //since lanId, password and agentSessionKey will not come for update agent setting do a dummy check
        global_LanID = data.LanID ? data.LanID : global_LanID;
        global_Password = data.Password ? data.Password : global_Password;
        global_AgentSessionKey = data.AgentSessionKey ? data.AgentSessionKey : global_AgentSessionKey;

        global_TeamID = data.TeamID === null ? "" : data.TeamID;
        global_TeamName = data.TeamName === null ? "" : data.TeamName;
        global_UserProfileForAgent = data.UserProfileForAgent ? data.UserProfileForAgent : "A";
        global_ChannelCount = data.AgentTabCounts ? data.AgentTabCounts : [];
        global_AgentFeatures = data.AgentFeatures ? data.AgentFeatures : [];

        //do not update global_TmacSignalRUrl for update event, as this key is used to check get event or signalr
        if (!isUpdate) {
            global_TmacSignalRUrl = data.TmacSignalRUrl ? data.TmacSignalRUrl : "";
        }

        global_LoginJsonData = data.LoginJsonData ? data.LoginJsonData : "";

        //check if the agent is MS agent
        if (data.IsMSAgent) {
            agentType = "MS Agent";
            $("#agentType").parent().attr("title", agentType);
            $("#agentType").text(agentType);
            $("#agent_type_li").removeClass("uk-display-none");
        }

        //reload agent features list
        LoadAgentFeaturesList();

        //load the profile picture
        $("#profilePic").attr("src", data.AgtAgentProfileModel && data.AgtAgentProfileModel.ProfilePicture ? data.AgtAgentProfileModel.ProfilePicture : "assets/img/agent.png");

        //custom logic to process agent data
        TmacCustomLogic.onAgentDataReceived(data);

        //set the data to successfully logged in data
        global_successfullyLoggedInData.data.Data = data;
        //store the TMAC data to local storage, if refresh the page to load the updated data
        localStorage.setItem("TMACdata-" + global_DeviceID, JSON.stringify(global_successfullyLoggedInData));

    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AssignAgentData()", ex, false);
    }
}

function LoadAgentFeaturesList() {

    //check if the global_AgentFeatures is not null
    if (global_AgentFeatures && global_AgentFeatures.length > 0) {

        //assign the sms out eabled flag
        let isSMSOutEnabled = false;

        global_AgentFeatures.forEach(function (item) {

            //check to send mos value for this interaction
            if (item.Feature === "IsGetMosEnabled") {
                sendMosValue = item.IsEnabled;
            }
            //check whether agent has IsFaxOutEnabled feature
            else if (item.Feature === "IsFaxOutEnabled") {
                isFaxOutEnabled = item.IsEnabled;
            }
            //check whether agent has isFaxInternationalEnabled feature
            else if (item.Feature === "IsFaxInternationalEnabled") {
                isFaxInternationalEnabled = item.IsEnabled;
            }
            //check whether agent has IsFaxPrintEnabled feature
            else if (item.Feature === "IsFaxPrintEnabled") {
                isFaxPrintEnabled = item.IsEnabled;
            }
            //check whether agent has IsSMSOutEnabled feature
            else if (item.Feature === "IsSMSOutEnabled") {
                isSMSOutEnabled = item.IsEnabled;
            }
            //check whether one way video is enabled 
            else if (item.Feature === "IsOneWayVideoEnabled" && avConfig && avConfig.getMediaConstraints) {
                avConfig.getMediaConstraints.type = "onewayvideo";
            }
        });

        //if isFaxOutEnabled is true then show compose fax button
        if (isFaxOutEnabled) $(".compose-fax-li").removeClass("uk-display-none");
        else $(".compose-fax-li").addClass("uk-display-none");

        //if isSMSOutEnabled is true then show compose sms button
        if (isSMSOutEnabled) $(".compose-sms-li").removeClass("uk-display-none");
        else $(".compose-sms-li").addClass("uk-display-none");
    } else {
        log.LogDetails("Error", "TmacUI.LoadAgentFeaturesList()", "global_AgentFeatures is null/empty", false);
    }
}

function OpenMeeting() {
    OpenIframeTab("meeting", meetingFrameUrl, "TMAC-Meeting", false);
}

function HostMeeting() {
    OpenIframeTab("meeting", meetingFrameUrl + "?type=new", "TMAC-Meeting", false);
    UIkit.modal("#model_tmac_meeting").hide();
}

function JoinMeeting() {
    OpenIframeTab("meeting", meetingFrameUrl + "?type=join", "TMAC-Meeting", false);
    UIkit.modal("#model_tmac_meeting").hide();
}

function ShowMOSValue(intId, mos) {
    try {
        let statusType = "";
        let mosChanged = false;

        if (between(mos, 0, 1)) {
            statusType = "danger";
            mosChanged = CheckIfMosChanged(statusType);
        } else if (between(mos, 1, 2)) {
            statusType = "warning";
            mosChanged = CheckIfMosChanged(statusType);
        } else if (between(mos, 2, 3)) {
            statusType = "primary";
            mosChanged = CheckIfMosChanged(statusType);
        } else if (between(mos, 3, 5)) {
            statusType = "success";
            mosChanged = CheckIfMosChanged(statusType);
        }

        $("#v_connectivity_status" + intId).removeClass();
        $("#v_connectivity_status" + intId).addClass("material-icons notranslate md-24" + (statusType ? " uk-text-" + statusType : ""));
        $("#v_mos_value" + intId).text(mos.toFixed(2));

        //check if Mos value changed and send the stat to server is enabled
        if (mosChanged && sendMosValue) {
            //send mos value to server
            tmac_UpdateMosDetails(null, null, intId, parseFloat(mos).toFixed(3) + ":" + moment(new Date()).format("YYYYMMDDHHmmss"));
        }

    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ShowMOSValue()", ex, false);
    }
}

let _lastMosStats = "";

function CheckIfMosChanged(status) {
    //check if the new status matches the current status
    if (_lastMosStats !== status) {
        _lastMosStats = status;
        return true;
    }
    return false;
}

// Video layout method
let VideoLayout = function (div) {
    try {
        var this_ = this;
        this_.main_div = null;

        let _existingContainers = document.getElementsByClassName("av-call-popup-container");
        if (_existingContainers.length > 0) {
            this_.main_div = _existingContainers[0];
        } else {
            this_.main_div = document.createElement("div");
            this_.main_div.className += "av-call-popup-container";
            div.appendChild(this_.main_div);
        }

        this_.addedStreams = {};

        this_.addVideo = function (stream, streamInfo) {
            let v = null;
            let d = null;

            // get the stream type
            let streamType = streamInfo.type || "";
            let user = streamInfo.user || "";

            if (this_.addedStreams[stream.id]) {
                v = this_.addedStreams[stream.id].video;
                d = this_.addedStreams[stream.id].tag;
            } else {
                let videoContainer = document.createElement("div");
                v = document.createElement('video');
                d = document.createElement('div');

                videoContainer.id = "vc_" + stream.id;
                v.id = "vid_" + stream.id;
                d.id = "div_" + stream.id;
                d.className = "av-snapshot";

                videoContainer.appendChild(v);
                videoContainer.appendChild(d);

                let userInfoEle = document.createElement("div");
                let userInfoText = document.createElement("div");

                userInfoText.className = "custom-padding";
                userInfoText.innerText = user + "-" + streamType;

                userInfoEle.className = "user-info";
                userInfoEle.id = "av_userinfo_" + stream.id;
                userInfoEle.appendChild(userInfoText);
                videoContainer.appendChild(userInfoEle);

                // if the stream is screenshare add the class
                if (streamType === "screenshare") {
                    videoContainer.className += "screenshare-stream";
                }

                this_.main_div.appendChild(videoContainer);

                this_.addedStreams[stream.id] = { video: v, tag: d };

                // TODO:: check this with Chirag
                // appen this video element in parent container if this is screenshare video
                // if (streamType === "screenshare") {
                //     var c = document.getElementById("videoCallPopup");
                //     let clsName = " with-screen-share-l";
                //     if (c.clientHeight > c.clientWidth) {
                //         clsName = " with-screen-share";
                //     }
                //     c.className += clsName;
                //     videoContainer.className += "ss-vid-container";
                //     c.prepend(videoContainer);
                // } else {
                //     this_.main_div.appendChild(videoContainer);
                // }
            }

            v.setAttribute('autoplay', 'autoplay');
            v.setAttribute('muted', 'muted');
            v.setAttribute('playsinline', 'true');

            // on video loaded
            v.addEventListener('loadedmetadata', function () {
                console.log('VideoLayout: Remote video videoWidth: ' + this.videoWidth + 'px,  videoHeight: ' + this.videoHeight + 'px');
            });

            // assign the stream
            v.srcObject = stream;

            // on video resize
            v.onresize = function () {
                console.log('VideoLayout: Remote video size changed to ' + this.videoWidth + 'x' + this.videoHeight);
            };

            console.log('VideoLayout: added stream to video element ' + stream.id);
        };

        this.removeVideo = function (stream) {
            if (this_.addedStreams[stream.id]) {
                // remove the stream from the list of added streams
                delete this_.addedStreams[stream.id];
                // check if the element is already removed
                if (document.getElementById("vc_" + stream.id)) {
                    document.getElementById("vc_" + stream.id).remove();
                }
            }
        };

        this_.clear = function () {
            this_.addedStreams = {};
            if (this_.main_div) this_.main_div.remove();
        };
    } catch (ex) {
        console.error("TmacUI.VideoLayout(): " + ex);
    }
};

// Video layout method
let CobrowseLayout = function (intid) {
    try {
        var this_ = this;
        this_.div = document.getElementById("remoteCobrowse" + intid);
        this_.addedStreams = {};
        this_.intid = intid;
        this_.cobrowseVideoId = "";

        this_.addVideo = function (stream, streamInfo) {
            let v = null;
            if (this_.addedStreams[stream.id]) {
                v = this_.addedStreams[stream.id].video;
            } else {
                v = document.createElement('video');
                v.id = "vid_" + stream.id;
                this_.cobrowseVideoId = v.id;
                this_.div.appendChild(v);
                this_.addedStreams[stream.id] = { video: v };
            }
            v.setAttribute('autoplay', 'autoplay');
            v.setAttribute('muted', 'muted');
            v.style.position = "absolute";
            v.addEventListener('loadedmetadata', function () {
                v.width = this.videoWidth;
                v.height = this.videoHeight;
                this_.div.style.height = $("#" + v.id)[0].offsetHeight + "px";
                this_.div.style.width = $("#" + v.id)[0].offsetWidth + "px";
                OnAgentInitiate(this_.div, this_.intid, coBrowse.MousePointerCapture, true);
            });
            v.srcObject = stream;
            v.onresize = function () {
                // We'll use the first onsize callback as an indication that video has started playing out
                setTimeout(function () {
                    this_.div.style.height = $("#" + this_.cobrowseVideoId)[0].offsetHeight + "px";
                    this_.div.style.width = $("#" + this_.cobrowseVideoId)[0].offsetWidth + "px";
                }, 500);
            };
        };

        this_.clear = function () {
            try {
                if (document.getElementById(this_.cobrowseVideoId)) document.getElementById(this_.cobrowseVideoId).remove();
                this_.addedStreams = {};
            } catch (ex) {
                log.LogDetails("Error", "TmacUI.CobrowseLayout()", ex, false);
            }
        };
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CobrowseLayout()", ex, false);
    }
};

function DraggableElement(elem, handler) {
    let _dragThis = this;
    let _isDisabled = false;

    // check if handler is provided, else take element as handler
    if (!handler) {
        handler = elem;
    }

    // to disable
    _dragThis.disable = function () {
        _isDisabled = true;
    }

    // to enable
    _dragThis.enable = function () {
        _isDisabled = false;
    }

    var pos1 = 0,
        pos2 = 0,
        pos3 = 0,
        pos4 = 0;

    // to drag by header
    _dragThis.byHeader = function () {
        // drag by popup header
        handler.onmousedown = dragMouseDown;
        elem.onmousedown = null;
    }

    // to drag by body
    _dragThis.byBody = function () {
        // drag by popup body
        handler.onmousedown = null;
        elem.onmousedown = dragMouseDown;
    }

    elem.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
        if (_isDisabled) return;
        e = e || window.event;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        if (_isDisabled) return;
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elem.style.top = (elem.offsetTop - pos2) + "px";
        elem.style.left = (elem.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

/**
 *  VP: Sep 18, '20: WebRTC Comm Stats store to send every interval
 */
avWebRTCCommStats = {
    content: {},
    intervalId: -1,
    init: function () {
        if (this.intervalId === -1) {
            this.intervalId = setInterval(function () {
                avWebRTCCommStats.send(false);
            }, 30000)
        }
    },
    add: function (stats, intId) {
        if (this.content[intId] == null) {
            this.content[intId] = [];
        }

        this.content[intId] = this.content[intId].concat(stats);
    },
    reset: function () {
        this.content = {};
        clearInterval(this.intervalId);
        this.intervalId = -1;
    },
    send: function (clearAll) {
        //  VP: Nov 18, '20: Only if there are any interactions, find
        if (Object.keys(this.content).length > 0) {
            $that = this;
            $.each($that.content, function (intId, stats) {
                //  VP: Nov 18, '20: Only if stats is non-empty, send stats
                if (stats.length > 0) {
                    StoreWebRTCCommStats(stats, {
                        intid: intId
                    }, null);
                    $that.content[intId] = [];
                }
            });
        }
        if (clearAll)
            this.reset();
    }
};