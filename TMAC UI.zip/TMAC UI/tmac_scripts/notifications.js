﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Notifications.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
//-----------------------------------------------------------------------------------
var popupwindow;
var popupAlertWindowInterval;
var popupAlertWindowIntervalCnt = 0;

$(document).ready(function () {
    console.log('notification alert loaded');
    $(window).focus(function () {
        try {
            isTmacWindowFocus = true;
            CloseNotifications();
        } catch (ex) {
            log.LogDetails("Error", "Notifications.focus()", ex, false);
        }
    });

    $(window).blur(function () {
        try {
            isTmacWindowFocus = false;
        } catch (ex) {
            log.LogDetails("Error", "Notifications.blur()", ex, false);
        }
    });
});

// request permission on page load
document.addEventListener('DOMContentLoaded', function () {
    if (isPushNotification) GrandChromeNotification();
});

function GrandChromeNotification() {
    try {
        if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
            notificationType = "chrome";
            if (Notification.permission !== "granted") {
                Notification.requestPermission().then(function (e) {
                    if (e != "granted") {
                        //show the notification denied alert if configured
                        if (showNotificationDeniedAlert) $("#notificationDeniedAlert").removeClass("uk-display-none");
                    }
                });
            }
        }
        else {
            notificationType = "custom";
            console.log('Desktop notifications not available in your browser. Try Chromium.');
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.GrandChromeNotification()", ex, false);
    }
}

// ------------------------------------------------------------------------------------------
// Incoming chat/call alerts
// ------------------------------------------------------------------------------------------

// -------------------------------------------------------------------------------------------
// Popup alert window
// type : chat or voice
// -------------------------------------------------------------------------------------------
function ShowNotification(title, message, icon) {
    try {
        let condition = checkForTmacFocus ? !isTmacWindowFocus : true;
        if (isPushNotification) {
            if (condition) {
                if (notificationType === "custom") {
                    CustomNotification(title, message);
                } else if (notificationType === "chrome") {
                    setTimeout(function () {
                        ChromeNotification(title, message, icon === undefined ? favionIcon : icon);
                    });
                }
            }
            setTimeout(function () {
                CloseNotifications();
            }, notificationDuration * 1000);
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.ShowNotification()", ex, false);
    }
}

function CustomNotification(title, message) {
    try {
        popupwindow = window.open("popupAlertWindow.htm?type=" + message, message,
            "menubar=no," +
            "location=no," +
            "scrollbars=no," +
            "width=150," +
            "height=150" +
            ",resizable=no,top=" + PopupWindowAlert_Top_Position() +
            ",left=" + PopupWindowAlert_Left_Position());
        popupwindow.onclick = function (e) {
            this.blur();
            this.opener.focus();
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.CustomNotification() - Inside1", ex, false);
    }
    try {
        popupwindow.document.write("<p style='font-weight:bold; color:Red;font-size:14px;'> " + title + " " + message + "</p>");
    } catch (ex) {
        log.LogDetails("Error", "Notifications.CustomNotification() - Inside2", ex, false);
    }
    try {
        let condition = checkForTmacFocus ? !isTmacWindowFocus : true;
        if (condition) {
            popupAlertWindowInterval = setInterval(function () {
                if (popupAlertWindowIntervalCnt > 3) {
                    clearInterval(popupAlertWindowInterval);
                    popupAlertWindowIntervalCnt = 0;
                }
                popupAlertWindowIntervalCnt++;
                popupwindow.focus();
            }, 1000);
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.CustomNotification() - Inside3", ex, false);
    }
}

function ChromeNotification(title, message, icon) {
    try {
        if (isAppMessage) {
            var json = JSON.parse(message);
            if (json.messageType === "image") {
                message = "Sent you an image";
            }
            else if (json.messageType === "audio") {
                message = "Sent you an audio";
            }
            else if (json.messageType === "video") {
                message = "Sent you a video";
            }
            else if (json.messageType === "file") {
                message = "Sent you a file";
            }
            else {
                message = json.message;
            }
        }
        if (Notification.permission === "granted") {
            var notification = new Notification(title, {
                body: message,
                icon: "assets/img/" + icon + ".png"
            });

            notification.onclick = function () {
                window.focus();
                if (isVoiceBio)
                    ResizeWindow(true);
            };

            notificationList.push(notification);
        }
        else {
            log.LogDetails("Error", "Notifications.ChromeNotification()", "Notification is not granted", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.ChromeNotification()", ex, false);
    }
}
// ----------------------------------------------------------------------------------------
// Close the popup window/ clear chrome notification
// ----------------------------------------------------------------------------------------
function CloseNotifications() {
    try {
        if (notificationType === "custom") {
            clearInterval(popupAlertWindowInterval);
            if (popupwindow !== undefined)
                popupwindow.close();
        } else if (notificationType === "chrome") {
            if (notificationList.length !== 0) {
                $.each(notificationList, function (i, val) {
                    if (val !== undefined)
                        val.close();
                });
            }
            notificationList = [];
        }
    } catch (ex) {
        log.LogDetails("Error", "Notifications.CloseNotifications()", ex, false);
    }
}
// ----------------------------------------------------------------------------------------
// Popup window Alert Top Postion.
// ----------------------------------------------------------------------------------------
function PopupWindowAlert_Top_Position() {
    return screen.height - 220;
}

// ----------------------------------------------------------------------------------------
// Popup window Alert Left Postion.
// ----------------------------------------------------------------------------------------
function PopupWindowAlert_Left_Position() {
    return screen.width - 250;
}