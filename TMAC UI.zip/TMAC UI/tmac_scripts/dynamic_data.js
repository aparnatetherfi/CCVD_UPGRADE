﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------

function AddDynamicFields(type) {
    try {
        //  VP: Aug 19, '20: Dynamically create customer info fields based on config
        let objType;
        let appendId;
        if (type === "voice") {
            objType = AppConfigs.Remote.Channel.Voice.IVR.CustomerInfo;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type === "chat") {
            objType = AppConfigs.Remote.Channel.TextChat.CustomerInfo;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (i, val) {
            AddDynamicDivs("dynamic_data_template", appendId, val.Title, val.HTMLElementID + "_INTID", val.ClassName);
        });

    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}

function AddHandlebarDynamicFields(type, intid) {
    try {
        //  VP: Aug 19, '20: Dynamically create customer info fields based on config
        let objType;
        let appendId;
        if (type === "voice") {
            objType = AppConfigs.Remote.Channel.Voice.IVR.CustomerInfo;
            appendId = "voice_dynamic_fields" + intid;
        } else if (type === "chat") {
            objType = AppConfigs.Remote.Channel.TextChat.CustomerInfo;
            appendId = "chat_dynamic_fields" + intid;
        }
        $("#" + appendId).html("");
        $.each(objType, function (i, val) {
            AddDynamicDivs("dynamic_data_template", appendId, val.Title, val.HTMLElementID, val.ClassName, val.DefaultValue);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddHandlebarDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AddDynamicDivs(templateId, appendId, text, value, className, fieldValue) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className,
                value: fieldValue
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------

function AssignDynamicValues(data, type, eventName) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type === "voice" && type === "voice") {
                try {
                    //  TestMe : Removed incoming call event clause
                    //  VP: Aug 19, '20: Dynamically load customer info
                    $.each(AppConfigs.Remote.Channel.Voice.IVR.CustomerInfo, function (i, val) {
                        try {
                            var fieldValue = fetchValueFromEvents(intid, val.Source);
                            if (fieldValue == "")
                                fieldValue = val.DefaultValue;

                            $("#" + val.HTMLElementID).val(fieldValue + val.Unit);
                            $("#" + val.HTMLElementID).attr("title", fieldValue + val.Unit);
                        } catch (e) { }
                    });
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Voice", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type.toLowerCase() === "tcmvoicewq" && type.toLowerCase() === "tcmvoicewq") {
                try {
                    //generic TCM interaction
                    if (eventName === "TCMVoiceWQInteraction") {
                        let item = data.Item;
                        let customData = JSON.parse(data.Item.Data);
                        $("#txtPhoneNumber" + intid).val(item.PhoneNumber ? item.PhoneNumber : "");
                        $("#txtCustId" + intid).val(item.CustomerIdentifier ? item.CustomerIdentifier : "");
                        $("#txtSkill" + intid).val(item.Skill ? item.Skill : "");
                        $("#txtIntent" + intid).val(item.Intent ? item.Intent : "");
                        $("#txtCamp" + intid).val(customData.CampaignName ? customData.CampaignName : "");
                        $("#txtname" + intid).val(customData.Name ? customData.Name : "");
                    }
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - generic_TCMVOICEWQ", ex, false);
                }
            }
            else if (GetTabReferenceObj(intid).type === "chat" && type === "chat") {
                try {
                    //  VP: Aug 19, '20: Dynamically load customer info
                    $.each(AppConfigs.Remote.Channel.TextChat.CustomerInfo, function (i, val) {
                        try {
                            var fieldValue = fetchValueFromEvents(intid, val.Source);
                            if (fieldValue == "")
                                fieldValue = val.DefaultValue;

                            $("#" + val.HTMLElementID + intid).val(fieldValue + val.Unit);
                            $("#" + val.HTMLElementID + intid).attr("title", fieldValue + val.Unit);

                            if (val.HTMLElementID === "tc_scName")
                                GetChatReferenceObj(intid).customerName = fieldValue;

                            if (val.HTMLElementID === "tc_chatQueueTime") {
                                let colorCode = GetColorCode(fieldValue);
                                $("#tc_chatQueueTime" + intid).css("color", colorCode);
                                $("#tc_chatQueueTime" + intid).attr("title", colorCode);
                            }
                        } catch (e) { }
                    });
                } catch (ex) {
                    log.LogDetails("Error", "DynamicData.AssignDynamicValues() - Chat", ex, false);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

function TmacServerConnectionSuccessEvent(event) {
    try {
        alert("Tmac connection established. Please use hard phone to control ongoing calls");
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.TmacServerConnectionSuccessEvent()", ex, false);
    }
}

/**
 * If needed open in new window
 * @param {*} msg 
 * @param {*} intId 
 */
var snapshotReceivedFromRemote = (msg, intId) => {
    try {
        // var filename = FileServerUrl.MediaProxy + global_UCID[intId] + "/" +
        //     unescape(msg.data.replace(new RegExp("^(?:.*[&\\?]" + escape("file-name").replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));

        // window.open(filename, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=400,height=400");

        let imageLink = FileServerUrl.MediaProxy + "/" + GetChatReferenceObj(intId).sessionId + "/" + msg.data;

        var text = '<img src="' + imageLink + '" style="height:300px;"/>';
        tmac_UpdateInteractionHistory(null, null, "TextChat", GetChatReferenceObj(intId).sessionId,
            "", "", "", "", "", text, "Out", global_AgentID, GetChatReferenceObj(intId).sessionId,
            "SnapShot", false, "", false, false, "", false);
    }
    catch (e) {
        log.LogDetails("Error", "DynamicData.snapshotReceivedFromRemote()", e, false);
    }
};