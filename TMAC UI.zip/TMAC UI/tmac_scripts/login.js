// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Login.js";
var file_version = "4.1.2.15";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

//this method will be exceuted after loading the file.
window.onload = function () {
    // lets set focus to lanid/station
    if ($.trim(GetLanID()) === "")
        $("#lan_id").focus();
    else
        isLoginWithPassword ? $("#password").focus() : $("#station_no").focus();

    if (isSinglePageLogin && AppConfigs.Local.Login.loginWithQueryString) {
        $("#lan_id").val(getQueryStringValue("lanid"));
        $("#station_no").val(getQueryStringValue("station"));
        $("#agent_id").val(getQueryStringValue("agentid"));
        $("#password").val(getQueryStringValue("password"));
        $("#domainList").val(getQueryStringValue("domain"));
        PerformLogin();
    }
};

$(document).ready(function () {
    console.log("login loaded");

    //GetLanIDFromServer();

    if (disableLanId) $("#lan_id").attr("disabled", "disabled");

    $("#div_login_mode").toggle(isLoginMode);

    if (isLoginMode) {
        $("input[name='pbx_mode']").on('change', function () {
            if (this.checked) {
                isStationAvailable = true;
                $("#div_station").toggle(isStationAvailable);
                $("#station_no").focus();
            }
            else {
                isStationAvailable = false;
                $("#div_station").toggle(isStationAvailable);
            }
        });

        if (loginMode === "pbx") {
            $("#pbx_mode").click();
        }
        else if (loginMode === "ms") {
            $("#ms_mode").click();
            isStationAvailable = false;
        }
        else if (loginMode === "pbxms") {
            $("#pbx_mode").click();
            $("#ms_mode").click();
        }
        else
            isStationAvailable = false;
    }

    $("#div_station").toggle(isStationAvailable);
    $("#div_password").toggle(isLoginWithPassword);
    $("#div_domain").toggle(isDomainList);

    // create DropDownList from input HTML element
    $("#domainList").kendoDropDownList();

    //put loading indicator for domain list, remove it after loading the items
    $('.k-i-arrow-60-down').addClass('k-i-loading');

    if (isDomainList) {
        GetUserDomainList();
    }

    $('#lan_id').keypress(function (e) {
        var key = e.which;
        if (key === 13) {
            $('#login_btn').click();
        }
    });

    $('#station_no').keypress(function (e) {
        var key = e.which;
        if (key === 13) {
            $('#login_btn').click();
        }
    });

    $('#agent_id').keypress(function (e) {
        var key = e.which;
        if (key === 13) {
            $('#login_btn').click();
        }
    });

    $('#password').keypress(function (e) {
        var key = e.which;
        if (key === 13) {
            $('#login_btn').click();
        }
    });

    //route to mainscreen page if login page is opned directly when isSinglePageLogin is true
    if ((isSinglePageLogin || isVoiceBio) && window === parent) {
        let message = "Single page login is enabled, routing to MainscreenUI..";
        setTimeout(function () {
            UIkit.modal.blockUI('<div class=\'uk-text-center\'>' + message + '<br/><img class=\'uk-margin-top\' src=\'assets/img/spinners/spinner.gif\' alt=\'\'>');
            setTimeout(function () {
                location.replace("MainscreenUI.html");
            }, 2000);
        }, 1000);
    }

    //test proxy connection
    tmac_GetTMACVersion(function (d, o) {
        console.log("Connected to: " + global_connectedProxy);
        console.log("TMAC Version: " + d);
        //$("#server_version").text(d);
    }, null);
});

function GetLanID() {
    //get the lan id
    let lanId = $("#lan_id").val();
    return lanId;
}

function GetStation() {
    if (isStationAvailable)
        return $("#station_no").val();
    else {
        var lanId = GetLanID().split('\\');
        lanId = lanId[lanId.length - 1];
        lanId = lanId.split(',');
        lanId = lanId[lanId.length - 1];
        return lanId.toLowerCase();
    }
}

function GetAgent() {
    return $("#agent_id").val();
}

function GetPassword() {
    if (!isLoginWithPassword)
        return "";

    return $("#password").val();
}

function GetDomain() {
    return $("#domainList").val();
}

function loginDone() {
    window.open('', '_self', '');
}

//perform login function
function PerformLogin() {
    try {
        //get the values
        let domain = GetDomain();
        let lanid = GetLanID();
        let station = GetStation();
        let password = GetPassword();
        let agent = $("#agent_id").val();

        //check if ms login is required
        var jsonData = {
            msLogin: $('#ms_mode').prop('checked'),
            pbxLogin: $('#pbx_mode').prop('checked'),
            customAuthData: $("#loginOtp").attr("hidden") === "hidden" ? null : { otp: $("#loginOtp").val() }
        };

        if (isDomainList && domain === "") {
            ShowNotify("Please select a domain", "danger", null, "top-center");
            return;
        }
        else if (lanid === "") {
            ShowNotify("Please provide lan id", "danger", null, "top-center");
            return;
        }
        else if (station === "") {
            ShowNotify("Please provide station", "danger", null, "top-center");
            return;
        }
        else if (isLoginWithPassword && password === "") {
            ShowNotify("Please provide password", "danger", null, "top-center");
            return;
        }
        else if ($("#loginOtp").attr("hidden") != "hidden" && $("#loginOtp").val().length === 0) {
            ShowNotify("Please enter the OTP.", "danger", null, "top-center");
            return;
        }
        else if (!$("#agent_extension").hasClass("uk-display-none") && !agent) {
            ShowNotify("Please provide agent id", "danger", null, "top-center");
            return;
        }

        Login(isDomainList ? domain + "\\" + lanid : lanid, station, agent, false, password, JSON.stringify(jsonData));

        $("#login_btn").addClass("disabled");
        $("#login_spinner").removeClass("uk-display-none");
        $("#login_card").addClass("blur-background");
    } catch (ex) {
        log.LogDetails("Error", "Login.PerformLogin()", ex, false);
    }
}

//update the login div text
function UpdateLoginTextDiv(text, append) {
    try {
        $("#login_spinner").removeClass("uk-display-none");
        $("#login_card").addClass("blur-background");
        if (append) {
            document.getElementById('login_text').innerHTML = text;
        } else
            document.getElementById('login_text').innerHTML = text;
    } catch (ex) {
        log.LogDetails("Error", "Login.UpdateLoginTextDiv()", ex, false);
    }
}

//for invalid lan id response from server
function InvalidLanID() {
    try {
        if (isAgentIdOnInvalidLanId) {
            //global_LoginRedisplay = true;
            $("#agent_extension").removeClass("uk-display-none");
            $("#agent_id").focus();
            ShowNotify("Invalid LAN ID detected. Please provide agent id.", "danger", null, "top-center");
        } else {
            ShowNotify("Invalid LAN ID detected. Please contact administrator for TMAC access.", "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "Login.InvalidLanID()", ex, false);
    }
}

//to redisplay login
function LoginReDisplay(flag) {
    try {
        var lanid = $("#lan_id").val();
        $("#login_spinner").addClass("uk-display-none");
        $("#login_card").removeClass("blur-background");
        if (flag) {
            $("#login_card").removeClass("uk-display-none");
            document.getElementById("agent_extension").style.display = "block";
            $("#agent_id").val(lanid);
            document.getElementById("agent_id").readOnly = true;
        } else {
            $("#login_card").addClass("uk-display-none");
            document.getElementById("agent_extension").style.display = "block";
        }
    } catch (ex) {
        log.LogDetails("Error", "Login.LoginReDisplay()", ex, false);
    }
}

//only number validation
function ValidateChar(event) {
    try {
        if (isNaN(String.fromCharCode(event.keyCode)) || String.fromCharCode(event.keyCode).trim() === "")
            event.preventDefault();
    } catch (ex) {
        log.LogDetails("Error", "Login.ValidateChar()", ex, false);
    }
}

function GetLanIDFromServer() {
    try {
        let _http = new XMLHttpRequest();
        let _url = "Login.aspx/GetMyLanID";
        _http.open("POST", _url, true);
        _http.withCredentials = true;
        _http.setRequestHeader("Content-type", "application/json; charset=utf-8");
        _http.onreadystatechange = function () {
            if (_http.readyState === 4 && _http.status === 200) {
                let _result = JSON.parse(_http.responseText).d;
                if (_result) {
                    $("#lan_id").val(_result);
                }
            }
            else if (_http.readyState === 4 && _http.status !== 200) {
                log.LogDetails("Error", "Login.GetLanIDFromServer()", _http.status, false);
            }
        };
        _http.send();
    } catch (ex) {
        log.LogDetails("Error", "Login.GetLanIDFromServer()", ex, false);
    }
}

var faceAuth = new function () {
    try {
        if (!AppConfigs.Local.Login.faceAuthenticateOnLogin) {
            return;
        }
        $("#form_validation").prepend(`
			<div class="uk-grid" data-uk-grid-margin="">
				<div id="login_video_container" class="uk-width-medium-1 uk-row-first" style="position: relative;">
					<video id="login_video" muted autoplay="" ></video>
					
				<div></div>
				</div>
			</div>		
		`);

        // Prefer camera resolution nearest to 1280x720.
        var constraints = { audio: true, video: true };

        navigator.mediaDevices.getUserMedia(constraints)
            .then(function (mediaStream) {
                var video = document.querySelector('#login_video');
                video.srcObject = mediaStream;
                video.onloadedmetadata = function (e) {
                    video.play();
                    $("#login_video_container").prepend(`<div class="face-shape animate__animated animate__pulse"></div>`);
                };
            }).catch(function (err) {
                console.log(err.name + ": " + err.message);
            }); // always check for errors at the end.

        $("#login_btn").attr("onclick", "getFaceAuthResults()");


    } catch (ex) {
        log.LogDetails("Error", "Login.faceAuth()", ex, false);
    }
}
function getFaceAuthResults() {
    try {
        // get Face Auth proxy url from config
        var url = AppConfigs.URLs.Main.TFaceAuthProxy;
        // select agent video element
        var videoEle = document.getElementById('login_video');
        let lanid = GetLanID();
        if (lanid === "") {
            ShowNotify("Please provide lan id", "danger", null, "top-center");
            return;
        }
        var canvas = document.createElement("canvas");
        // scale the canvas accordingly
        canvas.width = videoEle.videoWidth;
        canvas.height = videoEle.videoHeight;
        let ctx = canvas.getContext("2d");
        ctx.drawImage(videoEle, 0, 0, canvas.width, canvas.height);
        let base64 = canvas.toDataURL();
        if (!base64) {
            ShowNotify("Unable to capture image, make sure you provide access to camera", "danger", null, "top-center");
            return;
        }
        let callback = function (status, userObj, inputData, response) {
            if (true) {
                PerformLogin();
            } else {

            }
        }
        let userObj = {};
        let inputData = {
            snapdata: base64,
            snaptype: "base64",
            pptype: "",
            agentId: GetLanID(),
            originator: "",
            ppdata: ""
        };
        // call face auth proxy method to authenticate agent 
        InvokeRestMethod(callback, userObj, inputData, url);
    } catch (ex) {

    }
}