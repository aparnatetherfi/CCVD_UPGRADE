﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "POMUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

//--------------------------------------------------------------------------------------------
$(function () {
    POMConfigurations();
    LoadPOMAgentListGrid();
    FadeOutButton("#btn_change_status");
    //create campaign dashboard grid if configured
    if (isPOMCmpaignDashboard)
        CreatePOMCampaignDetailsGrid();
    //create callback dashboard grid if configured
    if (isPOMCallbackDashboard)
        CreatePOMPendingCallbackGrid();
    CreatePOMCallbackDestinationGrid();
    if (isPOMCallDashboard)
        POMGetCallDashboardData();
});

//----------------------------------AGENT CALL EVENTS-----------------------------------------
function POMIncomingVoiceCall(event) {
    try {
        var intid = event.InteractionID;
        var extraParam = event.UUI.split("|")[1];
        var isRedial = false;
        var consultFrom = "";
        if (extraParam.toLowerCase() === "redial") {
            isRedial = true;
        }
        else {
            consultFrom = event.UUI.split("|")[1];
        }
        var jsonData = JSON.parse(event.UUI.split("|")[2]);
        pomActiveCallInteractionID = intid;
        //create callback tab
        CreatePOMCallbackTab(intid, consultFrom !== "", isRedial);
        //for cacs no need to create customer info panel
        if (!isCACS) {
            //create customer information panel II
            CreateCustomerInfoPanel(intid, jsonData.CampaignName);
        }
        //process incoming call data
        IncomingCallUUIData(intid, jsonData, consultFrom, isRedial);
        GetPOMReferenceObj(intid).UCID = event.UCID;
        GetPOMReferenceObj(intid).isRedial = isRedial;
        GetTabReferenceObj(intid).OtherData.updatedPOMFeilds = [];
        GetTabReferenceObj(intid).OtherData.markUnCallable = [];
        //GetPOMReferenceObj(intid).closeTab = true;
        GetTabReferenceObj(intid).isCloseTab = true;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMIncomingVoiceCall()", ex, false);
    }
}

function POMVoiceCallConnectedEvent(event) {
    try {
        var intid = event.InteractionID;
        //if the call type is conference passive then ignore processing connected event
        if (GetPOMReferenceObj(intid).conferenceType !== "passive") {
            if (GetPOMReferenceObj(intid).isRedial) {
                POMSetCallControlStatus(intid, false, false, false, true, false, false, false, false, false, false, false);
                GetPOMReferenceObj(intid).isRedial = false;
                ChangeTabReferenceStatus(intid, "Redialed");
            }
            else {
                ChangeTabReferenceStatus(intid, "CallConnected");
                POMSetCallControlStatus(intid, false, false, false, true, true, false, true, true, false, true, false);
            }
            //GetPOMReferenceObj(intid).closeTab = false;
            GetTabReferenceObj(intid).isCloseTab = false;
        }
        else {
            ChangeTabReferenceStatus(intid, "PassiveConferenceConnected");
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallConnectedEvent()", ex, false);
    }
}

function POMVoiceCallDisconnectedEvent(event) {
    try {
        var intid = event.InteractionID;
        var agentStatus = $("#divAuxStatus").text().toLowerCase();
        $("#li_" + intid).removeClass("li-on-call");
        POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, false);
        ChangeTabReferenceStatus(intid, "CallDisconnected");
        global_CallType = "";
        //if this is a transferred call we dont have WrapUp mode to close the tab
        //so close the tab here
        //if (GetPOMReferenceObj(intid).closeTab && agentStatus !== "wrapup" && !event.RecoveryEvent) {
        if (GetTabReferenceObj(intid).isCloseTab && agentStatus !== "wrapup" && !event.RecoveryEvent) {
            CloseTab(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallDisconnectedEvent()", ex, false);
    }
}

function POMVoiceCallInitiating(event) {
    try {
        //POMVoiceCallInitiating
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallInitiating()", ex, false);
    }
}

function POMVoiceOutgoingCallEvent(event) {
    try {
        //POMVoiceOutgoingCallEvent
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceOutgoingCallEvent()", ex, false);
    }
}

function POMVoiceCallTransferInitiatedEvent(event) {
    try {
        //POMVoiceCallTransferInitiatedEvent
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferInitiatedEvent()", ex, false);
    }
}

function POMVoiceCallTransferRemoteConnected(event) {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferRemoteConnected()", ex, false);
    }
}

function POMVoiceCallTransferLineDisconnectEvent(event) {
    try {
        var intid = event.InteractionID;
        //hide the confirm window
        HideConfirmDialog();
        //disable answer button
        if (event.IsMainLine) //in connected state
            POMSetCallControlStatus(intid, false, false, false, true, true, false, true, true, false, false, false);
        else //in hold state
            POMSetCallControlStatus(intid, false, false, false, false, false, true, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferLineDisconnectEvent()", ex, false);
    }
}

function POMConferenceInitiated(event) {
    try {
        //POMConferenceInitiated
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceInitiated()", ex, false);
    }
}

function POMConferenceRemoteConnected(event) {
    try {
        //POMConferenceRemoteConnected
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceRemoteConnected()", ex, false);
    }
}

function POMConferenceCompleted(event) {
    try {
        //POMConferenceCompleted
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceCompleted()", ex, false);
    }
}

function POMConferenceLineDisconnected(event) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //disable answer button
        POMSetCallControlStatus(event.InteractionID, false, false, false, true, true, false, true, true, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceLineDisconnected()", ex, false);
    }
}

function POMVoiceCallHoldEvent(event) {
    try {
        POMSetCallControlStatus(event.InteractionID, false, false, false, false, false, true, false, false, false, false, false);
        ChangeTabReferenceStatus(event.InteractionID, "CallHold");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallHoldEvent()", ex, false);
    }
}

function POMVoiceCallHoldReconnectEvent(event) {
    try {
        POMSetCallControlStatus(event.InteractionID, false, false, false, true, true, false, true, true, false, true, false);
        ChangeTabReferenceStatus(event.InteractionID, "CallConnected");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallHoldReconnectEvent()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------GENERIC CTI EVENTS----------------------------------------

function CallStateChangeNotify(event) {
    try {
        var jsonData = JSON.parse(event.JsonData);
        var callState = jsonData.CallState;
        switch (callState.toLocaleLowerCase()) {
            case "conferenceowner":
                GetPOMReferenceObj(pomActiveCallInteractionID).isConference = true;
                break;
            case "conferencepassive":
                GetPOMReferenceObj(pomActiveCallInteractionID).isConference = true;
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CallStateChangeNotify()", ex, false);
    }
}

function OnPOMLoginSuccess(event) {
    try {
        var dispAgentType = "";
        pomLoginFlag = true;
        log.LogDetails("Info", "POMUI.OnPOMLoginSuccess()", "You are loggedIn as POM Agent", true);
        $("#div_pom_dashboard").removeClass("uk-display-none");
        $("#div_pom_dashboard").removeClass("uk-width-large-1-1");
        $("#div_pom_dashboard").addClass("uk-width-large-1-2");
        $("#div_agent_info").removeClass("uk-width-large-1-1");
        $("#div_agent_info").addClass("uk-width-large-1-2");
        //enable campaign dashboad if configured
        if (isPOMCmpaignDashboard) {
            $("#div_campaign_detials").removeClass("uk-display-none");
        }
        //enable campaign dashboad if configured
        if (isPOMCallbackDashboard) {
            $("#div_campaign_contact_list").removeClass("uk-display-none");
        }
        FadeInButton("#btn_change_status");
        if (isCACS)
            dispAgentType = "Outbound Agent";
        else
            dispAgentType = "AutoDialer Agent - Outbound";
        $("#agentType").text(dispAgentType);
        agentType = "AutoDialer";
        setTimeout(function () {
            TriggerResize();
        }, 800);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMLoginSuccess()", ex, false);
    }
}

function OnPOMLoginFailed(event) {
    try {
        pomLoginFlag = true;
        log.LogDetails("Info", "POMUI.OnPOMLoginFailed()", "You are loggedIn as ACD Agent", true);
        FadeInButton("#btn_change_status");
        $("#agentType").text("ACD Agent");
        agentType = "ACD";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMLoginFailed()", ex, false);
    }
}

function OnBlendToInbound(event) {
    try {
        log.LogDetails("Info", "POMUI.OnBlendToOutbound()", "Agent Blend to Inbound", true);
        var dispAgentType = "";
        if (isCACS)
            dispAgentType = "ACD Agent";
        else
            dispAgentType = "AutoDialer Agent - Inbound";
        $("#agentType").text(dispAgentType);
        agentType = "ACD";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnBlendToInbound()", ex, false);
    }
}

function OnBlendToOutbound(event) {
    try {
        log.LogDetails("Info", "POMUI.OnBlendToOutbound()", "Agent Blend to Outbound", true);
        var dispAgentType = "";
        if (isCACS)
            dispAgentType = "Outbound Agent";
        else
            dispAgentType = "AutoDialer Agent - Outbound";
        $("#agentType").text(dispAgentType);
        agentType = "AutoDialer";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnBlendToOutbound()", ex, false);
    }
}

function OnPOMCampaignsList(event) {
    try {
        if (isPOMCmpaignDashboard) {
            var eventJsonData = JSON.parse(event.JsonData);
            var jsonData = JSON.parse(eventJsonData.JsonData);
            var gridData = [];
            $.each(jsonData, function (i, val) {
                if (val.campaignName.indexOf("_" + global_TeamName) >= 0)
                    gridData.push(val);
            });
            $("#campaign_details_grid").data("kendoGrid").dataSource.data(gridData);
        }
        else {
            log.LogDetails("Info", "POMUI.OnPOMCampaignsList()", "Campaign dashboard is disabled!", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMCampaignsList()", ex, false);
    }
}

function OnPOMPendingCallbacksList(event) {
    try {
        var eventJsonData = JSON.parse(event.JsonData);
        var jsonData = JSON.parse(eventJsonData.JsonData);
        $("#pending_callbacks_grid").data("kendoGrid").dataSource.data(jsonData);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMCampaignsList()", ex, false);
    }
}

function OnDialFailed(event) {
    try {
        var intid = event.InteractionID;
        var eventJsonData = JSON.parse(event.JsonData);
        var reason = eventJsonData.FailedReason.replace(/['"]+/g, '');
        ChangeTabReferenceStatus(intid, "DialFailed");
        //GetPOMReferenceObj(intid).closeTab = false;
        GetTabReferenceObj(intid).isCloseTab = false;
        log.LogDetails("Error", "POMUI.OnDialFailed()", reason, true);

    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnDialFailed()", ex, false);
    }
}

function OnCallWrapUpDataEvent(event) {
    try {
        var intid = pomActiveCallInteractionID;
        var eventJsonData = JSON.parse(event.JsonData);
        var jsonArrayString = eventJsonData.JsonData.replace(/'/g, '"');
        var jsonArray = JSON.parse(jsonArrayString);
        if (intid !== "") {
            $("#wrapupCodeDropDown" + intid).data("kendoDropDownList").dataSource.data(jsonArray);
            $("#div_wrapup" + intid).removeClass("uk-display-none");
            POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, true, true, false);
        }
        TriggerResize();

        if (GetPOMReferenceObj(intid).cacsLogoutFlag) {
            ChangeStatus(global_DeviceID, 'aux', 1);
            setTimeout(function () {
                POMWrapUpCallContact(intid, "submit");
            }, 2000);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCallWrapUpDataEvent()", ex, false);
    }
}

function OnConsultDestinationAgentsList(event) {
    try {
        var eventJsonData = JSON.parse(JSON.parse(event.JsonData).JsonData);
        $("#pomAgentList").data("kendoGrid").dataSource.data(eventJsonData);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConsultDestinationAgentsList()", ex, false);
    }
}

function OnConsultPendingNotification(event) {
    try {
        log.LogDetails("Info", "POMUI.OnConsultPendingNotification()", "Consult call is pending", true);

    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConsultPendingNotification()", ex, false);
    }
}

function OnPendingConsultComplete(event) {
    try {
        POMVoiceCallTransferRemoteConnected();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPendingConsultComplete()", ex, false);
    }
}

function OnConferenceOwner(event) {
    try {
        var intid = event.InteractionID;
        var callTypeLabel = $("#callType" + intid).text();
        GetPOMReferenceObj(intid).isConference = true;
        GetPOMReferenceObj(intid).conferenceType = "owner";
        $("#callType" + intid).text(callTypeLabel + " - Conference Owner");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConferenceOwner()", ex, false);
    }
}

function OnConferencePassive(event) {
    try {
        var intid = event.InteractionID;
        if (GetPOMReferenceObj(intid).conferenceType !== "passive") {
            var callTypeLabel = $("#callType" + intid).text();
            POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, false);
            GetPOMReferenceObj(intid).conferenceType = "passive";
            $("#callType" + intid).text(callTypeLabel + " - Conference Passive");
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConferencePassive()", ex, false);
    }
}

function OnConferenceEnded(event) {
    try {
        GetPOMReferenceObj(event.InteractionID).isConference = false;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConferenceEnded()", ex, false);
    }
}

function OnCallbackTypes(event) {
    try {
        var intid = pomActiveCallInteractionID;
        EnableButton("#pomScheduleBtn" + intid, "phone_callback", "icon");

        //$("#pomSCRequestDate").val(moment(new Date()).format("DD/MM/YYYY"));
        //$("#pomSCRequestTime").val(moment(new Date()).format("HH:mm:00"));

        $("#pomSCRequestDate").data("kendoDatePicker").value(new Date());
        $("#pomSCRequestTime").data("kendoTimePicker").value(new Date());

        $("#pom_schedule_callback_dialog").data("kendoWindow").center().open();
        var eventJsonData = JSON.parse(event.JsonData);
        var jsonArray = JSON.parse(eventJsonData.JsonData);
        //default value
        $('#pomSCType').append($('<option>', {
            value: "",
            text: "Select a type..."
        }));
        $.each(jsonArray, function (i, item) {
            $('#pomSCType').append($('<option>', {
                value: item,
                text: item
            }));
        });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCallbackTypes()", ex, false);
    }
}

function OnCallbackDestsForType(event) {
    try {
        var eventJsonData = JSON.parse(event.JsonData);
        var jsonData = JSON.parse(eventJsonData.JsonData);
        var gridData = [];
        HideKendoLoading("#callback_destination_grid");
        $("#callback_destination_grid").data("kendoGrid").dataSource.data([]);
        $.each(jsonData, function (i, val) {
            if (!isNullOrWhitespace(val.destinationValue)) {
                gridData.push(val);
            }
        });
        $("#callback_destination_grid").data("kendoGrid").dataSource.data(gridData);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCallbackDestsForType()", ex, false);
    }
}

function OnLostNailedCall(event) {
    try {
        log.LogDetails("Warning", "POMUI.OnLostNailedCall()", "Nailed call is dropped", true);

    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnLostNailedCall()", ex, false);
    }
}

function OnCustomerContactData(event) {
    try {
        var intid = event.InteractionID;
        var data = JSON.parse(event.JsonData);
        var jsonData = JSON.parse(data.JsonData);
        if (jsonData.userContactID) {
            if (data.CampaignName) {
                //create customer information panel II and III for POM search
                CreateCustomerInfoPanel(intid, data.CampaignName);

                //get the user contact id and custom attribute list
                var cId = jsonData.userContactID, customFeildsList = jsonData.customAttributeList;

                //store contact list id for custom search wrapup submit
                GetTabReferenceObj(intid).OtherData.contactListID = jsonData.contactListID;

                //get the email id from jsonData if there
                var email = jsonData.email ? jsonData.email : "";

                //take the id from json data
                $("#ID_" + intid).val(cId);

                //if "E-Mail" attribute is there for this campaign then add email feild
                if ($("#E-Mail_" + intid).length > 0) $("#E-Mail_" + intid).val(email);

                //loop the custom feilds and append data
                $.each(customFeildsList, function (i, val) {
                    //get the element
                    var id = "#" + val.attributeName + "_" + intid;
                    //check element is present, then update the value
                    if ($(id).length > 0) {
                        $(id).val(val.attributeValue);
                    }
                });

                $("#customer_search_info_panel_II" + intid).removeClass("uk-display-none");
                $("#customer_search_info_panel_III" + intid).removeClass("uk-display-none");
                $("#customer_search_info_panel_II" + intid).addClass("blink_chat");
                $("#customer_search_info_panel_III" + intid).addClass("blink_chat");
                setTimeout(function () {
                    $("#customer_search_info_panel_II" + intid).removeClass("blink_chat");
                    $("#customer_search_info_panel_III" + intid).removeClass("blink_chat");
                }, 2000);
            }
            else {
                $("#customer_search_info_panel_II" + intid).addClass("uk-display-none");
                $("#customer_search_info_panel_III" + intid).addClass("uk-display-none");
                log.LogDetails("Error", "POMUI.OnCustomerContactData()", "This contact list is not associated to any campaign, Please contact the administrator.", true);
            }
        }
        else {
            $("#customer_search_info_panel_II" + intid).addClass("uk-display-none");
            $("#customer_search_info_panel_III" + intid).addClass("uk-display-none");
            log.LogDetails("Error", "POMUI.OnCustomerContactData()", jsonData.errorMessage, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCustomerContactData()", ex, false);
    }
}

function OnCallbackPending(event) {
    try {
        log.LogDetails("Info", "POMUI.OnCallbackPending()", "Callback is waiting", true);

    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCallbackPending()", ex, false);
    }
}

function OnAgentLoginMode(event) {
    try {
        var data = JSON.parse(event.JsonData);
        var loginMode = data.LoginMode;
        var userObject = JSON.parse(data.UserObject);
        if (loginMode === "outbound") {
            if (global_CallType === "Transfer") {
                EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
                EnableButton("#btndialogblindtransfercall", "BT", "tag");
                FadeOutButton("#btndialogtransfercall");
                FadeOutButton("#btndialogblindtransfercall");
            }
            if (global_CallType === "Conference") {
                EnableButton("#btnConfMCall", "call_split", "icon");
                FadeOutButton("#btnConfMCall");
            }
            log.LogDetails("Error", "POMUI.OnAgentLoginMode()", userObject.agentName + " is an auto dialer agent", true);
            return;
        }

        if (global_CallType === "Transfer") {
            EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
            EnableButton("#btndialogblindtransfercall", "BT", "tag");
        }
        else {
            EnableButton("#btndialogmakecall", "call", "icon");
            EnableButton("#btnConfMCall", "call_split", "icon");
        }

        $("#" + userObject.textBoxId).focus();
        $("#" + userObject.textBoxId).val(userObject.agentId);
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.OnAgentLoginMode()", ex, false);
    }
}

function OnGetCallDashboardData(event) {
    try {
        var data = JSON.parse(event.JsonData);
        var jsonData = JSON.parse(data.JsonData);
        $("#totalPOMInbound").text(jsonData.TotalInbound);
        $("#totalPOMPreview").text(jsonData.TotalPreview);
        $("#totalPOMPredictive").text(jsonData.TotalPredictive);
        $("#totalPOMCallback").text(jsonData.TotalCallback);
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.OnGetCallDashboardData()", ex, false);
    }
}

function OnCACSDataProxyClientLogout(event) {
    try {
        log.LogDetails("Warning", "POMUI.OnCACSDataProxyClientLogout()", "TMAC can not send the data to CACS because either agent is logged out from CACS or DataProxy closed. Please check!", false);
        var status = $('#divAuxStatus').text();
        if (status.toLowerCase().indexOf("on call") >= 0) {
            var intid = pomActiveCallInteractionID;
            GetPOMReferenceObj(intid).cacsLogoutFlag = true;
            POMDropCall(intid);

            //$.each(global_POMReference, function (i, val) {
            //});
        }
        else {
            LogoutConfirmed();
        }
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.OnCACSDataProxyClientLogout()", ex, false);
    }
}

function OnCACSInitialPoupupDataEvent(event) {
    try {
        var jsonData = JSON.parse(event.JsonData);
        $.each(jsonData, function (key, value) {
            var selector = $("#" + key + "_" + pomActiveCallInteractionID);
            if (selector.length) {
                if (key === "ACCOUNT" || key === "LOCATNID") {
                    selector.text(value);
                }
                selector.val(value);
            }
        });
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.OnCACSInitialPoupupDataEvent()", ex, false);
    }
}


//--------------------------------------------------------------------------------------------

//----------------------------------GENERIC CALL EVENTS---------------------------------------
function OnOutboundCallUUIData(event) {
    try {
        var intid = event.InteractionID;
        var data = JSON.parse(event.JsonData);
        var jsonData = JSON.parse(data.JsonData);
        var cId = jsonData.ID.value;
        var phoneFeildsList = jsonData.PhoneFields;
        var emailFeildsList = jsonData.EmailFields;
        var customFeildsList = jsonData.CustomFields;

        //var UCID = data.UCID;
        //var deviceId = data.Device;
        //var monitorHandle = data.MonitorHandle;
        //var firstName = jsonData.Firstname.value;
        //var lastName = jsonData.Lastname.value;
        //var title = jsonData.Title.value;
        //var addressList = jsonData.AddressList;

        //load interaction history for POM based on NRIC here after 5 seconds
        setTimeout(function (nric) {
            var historyParams = {};
            historyParams.CIF = "";
            historyParams.NRIC = nric;
            historyParams.EmailID = "";
            historyParams.PhoneNumber = "";
            historyParams.InteractionID = intid;
            ProcessInteractionHistoryEvent(historyParams, false, "pom");
        }, 3000, cId, intid);

        GetPOMReferenceObj(intid).connectionHandle = data.ConnectionHandle;

        //take the id from json data
        $("#ID_" + intid).val(cId);

        //take phone numbers from this list
        $.each(phoneFeildsList, function (i, val) {
            ProcessCustomerFeilds(intid, val.phoneNumber);
        });

        //take phone numbers from this list
        $.each(emailFeildsList, function (i, val) {
            ProcessCustomerFeilds(intid, val);
        });

        //loop the custom feilds and append data
        $.each(customFeildsList, function (i, val) {
            ProcessCustomerFeilds(intid, val);
        });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnOutboundCallUUIData()", ex, false);
    }
}

function ProcessCustomerFeilds(intid, val) {
    try {
        var id = "#" + val.key + "_" + intid;
        //check element is present, then update the value
        if ($(id).length > 0) {
            $(id).val(val.value);
            switch (val.attributeType) {
                case 0:
                    //READ ONLY
                    break;
                case 1:
                    //WRITE
                    if (val.key.toLowerCase() === "status")
                        $(id).removeAttr("disabled");
                    break;
                case 2:
                    //SCREEN POP
                    break;
                case 3:
                    //MASKED WRITE
                    break;
            }
            try {
                var evData = { intid: intid, key: val.key, value: val.value };
                $(id).blur(evData, function () {
                    var obj = {};
                    var intid = evData.intid;
                    obj.key = evData.key;
                    obj.value = this.value;
                    if (evData.value !== this.value) {
                        if (CheckPOMUpdatedFeilds(intid, obj.key).length === 0)
                            GetTabReferenceObj(intid).OtherData.updatedPOMFeilds.push(obj);
                        //GetPOMReferenceObj(intid).updatedPOMFeilds.push(obj);
                        else
                            UpdateCurrentFeildValues(intid, obj.key, obj.value);
                    }
                    else if (evData.value === this.value) {
                        if (CheckPOMUpdatedFeilds(intid, obj.key).length !== 0)
                            RemoveFeildValues(intid, obj.key);
                    }
                });
            } catch (ex) {
                log.LogDetails("Error", "POMUI.ProcessCustomerFeilds() - blur", ex, false);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.ProcessCustomerFeilds()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------

//----------------------------------DATA BINDING----------------------------------------------
function CreatePOMCallbackTab(intid, isConsult, isRedial) {
    try {
        //get the tab header and body template 
        var headerTemplate = GetHtmlFromTemplate("tab_header_template", intid, { icon: "phone_callback" });
        var bodyTemplate = GetHtmlFromTemplate("pom_tab_template", intid, { textcolor: "md-color-red-900" });
        //save tab and POM reference
        SaveTabReference("pom", intid, "new");
        SavePOMReference(intid);
        //add the tab
        AddTab(bodyTemplate, headerTemplate, intid, intid, true, false, true);
        //Initialize the UIKit accordion for the created tab
        var accordion = UIkit.accordion($('#pom_accordion' + intid), {
            collapse: false,
            showfirst: !isCACS
        });

        //if CACS enabled then show interaction history
        if (isCACS) {
            var wrapper = accordion.find('[data-wrapper]').get(2); //1 as index of the content
            accordion.toggleItem(UIkit.$(wrapper), true, false); // animated true and collapse true
            //show initial contact accordion
            $("#cacs_init_contact_" + intid).removeClass("uk-display-none");
        }
        //for POM alone then show salesscreen and both customer info panel and create sales dropdown
        else {
            $("#div_SalesScreen" + intid).removeClass("uk-display-none");
            $("#pom_accordion_cust_info1" + intid).removeClass("uk-display-none");
            $("#pom_accordion_cust_info2" + intid).removeClass("uk-display-none");
            //create a sales dropdown
            CreateSalesDropdown(intid);
        }

        //create wrapup dropdown
        CreateWrapupDropdown(intid, "outbound");


        //set call control status for incoming call
        if (isConsult)
            POMSetCallControlStatus(intid, false, false, true, false, false, false, false, false, false, false, false);
        else if (isRedial)
            POMSetCallControlStatus(intid, false, false, false, true, false, false, false, false, false, false, false);
        else
            POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, false);
        //POMSetCallControlStatus(intid, true, true, false, false, false, false, false, false, false, true, false);

        // When call comes, store the start time in the hidden field
        AddCallTimer(intid, "voice", "#hdn_voice_call_starttime" + intid, "#voice_call_starttime" + intid,
            "#voice_call_time_taken" + intid, "#voice_call_span_starttime" + intid, "", "", "", "", "", "");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreatePOMCallbackTab()", ex, false);
    }
}

function IncomingCallUUIData(intid, jsonData, consultFrom, isRedial) {
    try {
        //var canCancel = jsonData.CanCancel;
        //var canCancelSpecified = jsonData.CanCancelSpecified;
        //var canDial = jsonData.CanDial;
        //var canDialSpecified = jsonData.CanDialSpecified;
        //var canEnterFreeFormNumber = jsonData.CanEnterFreeFormNumber;
        //var canEnterFreeFormNumberSpecified = jsonData.CanEnterFreeFormNumberSpecified;
        //var canReschedule = jsonData.CanReschedule;
        //var canRescheduleSpecified = jsonData.CanRescheduleSpecified;
        //var contactCapabilities = jsonData.ContactCapabilities;
        //var contactTypeSpecified = jsonData.ContactTypeSpecified;        
        //var expiryTime = jsonData.ExpiryTime;
        //var scriptFailoverURL = jsonData.ScriptFailoverURL;
        //var scriptURL = jsonData.ScriptURL;
        //var skillsetID = jsonData.SkillsetID;
        //var skillsetName = jsonData.SkillsetName;
        //var timedSpecified = jsonData.TimedSpecified;
        //var timeoutSpecified = jsonData.TimeoutSpecified;
        //var timed = jsonData.Timed;

        var contactID = jsonData.ContactID;
        var contactNumbers = jsonData.ContactNumbers;
        var defaultNumber = jsonData.DefaultNumber;
        var campaignName = jsonData.CampaignName;
        var callbackNotes = jsonData.CallbackNotes;
        var contactType = jsonData.ContactType;
        var timeout = jsonData.Timeout;

        var callType = "";
        var tabLabel = "";
        var isConsult = consultFrom !== "";

        //to trim trunk code
        if (trimNumberLength && defaultNumber.length > parseInt(trimNumberLength))
            defaultNumber = defaultNumber.substr(defaultNumber.length - parseInt(trimNumberLength));

        switch (contactType) {
            case 0:
                callType = isConsult ? "Preview - " + consultFrom : "Preview";
                if (!isConsult) POMSetCallControlStatus(intid, true, true, false, false, false, false, false, false, false, true, false);
                //check if autodial is enabled then dial if the agent has not dialed
                if (isPreviewAutoDial) {
                    setTimeout(function () {
                        //if agent is not dialed then auto dial
                        if (GetPOMReferenceObj(intid).autoDial && !isRedial) {
                            POMDialPreviewCall(intid);
                        }
                    }, timeout * 1000, intid, isRedial);
                }
                break;
            case 1:
                callType = isConsult ? "Progressive - " + consultFrom : "Progressive";
                break;
            case 2:
                callType = isConsult ? "Predictive - " + consultFrom : "Predictive";
                if (!isConsult) POMSetCallControlStatus(intid, false, false, false, true, true, false, true, true, false, true, false);
                break;
            case 3:
                callType = isConsult ? "Callback - " + consultFrom : "Callback";
                $("#div_callback_notes" + intid).removeClass("uk-display-none");
                callbackNotes = callbackNotes.split('\n').filter(function (val) { return val; }).pop();
                $("#callbackNotes" + intid).text(callbackNotes);
                if (!isConsult) POMSetCallControlStatus(intid, true, true, false, false, false, false, false, false, false, true, false);
                break;
        }
        $("#callType" + intid).text(callType);

        if (isRedial && pomRedialNumber) {
            GetPOMReferenceObj(intid).phoneNumber = pomRedialNumber;
            tabLabel = pomRedialNumber;
            pomRedialNumber = "";
        }
        else {
            tabLabel = defaultNumber;
            GetPOMReferenceObj(intid).phoneNumber = defaultNumber;
        }
        $("#divTabHeader" + intid).text(tabLabel);
        $("#campaignName" + intid).text(campaignName);
        GetPOMReferenceObj(intid).contactNumbers = contactNumbers;
        GetPOMReferenceObj(intid).contactID = contactID;
        GetPOMReferenceObj(intid).campaignName = campaignName;
        GetPOMReferenceObj(intid).customerName = contactNumbers.filter(function (c) { return c.Number === defaultNumber; })[0].Name;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.IncomingCallUUIData()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------AGENT COMMANDS--------------------------------------------
function POMDialPreviewCall(intid) {
    try {
        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.numberToDial = GetPOMReferenceObj(intid).phoneNumber;
        data.custName = GetPOMReferenceObj(intid).customerName;

        obj.method = "DialPOMPreviewCall";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMDialCall()", ex, false);
    }
}

function DialPOMPreviewCallDone(result, obj) {
    try {
        GetPOMReferenceObj(obj.intid).autoDial = false;
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.DialPOMPreviewCallDone()", ex, false);
    }
}

function POMCancelPreviewCall(intid) {
    try {
        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

        obj.method = "CancelPOMPreviewCall";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMPreviewCall()", ex, false);
    }
}

function CancelPOMPreviewCallDone(result, obj) {
    try {
        //GetPOMReferenceObj(obj.intid).closeTab = false;
        GetTabReferenceObj(obj.intid).isCloseTab = false;
        GetPOMReferenceObj(obj.intid).autoDial = false;
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMPreviewCallDone()", ex, false);
    }
}

function POMRejectConsultCall(intid) {
    try {
        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

        obj.method = "RejectPOMConsultCallByRemoteAgent";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMRejectConsultCall()", ex, false);
    }
}

function RejectPOMConsultCallByRemoteAgentDone(result, obj) {
    try {
        //GetPOMReferenceObj(obj.intid).closeTab = true;
        GetTabReferenceObj(obj.intid).isCloseTab = true;
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMConsultCallByRemoteAgentDone()", ex, false);
    }
}

function POMDropCall(intid) {
    try {
        if (GetPOMReferenceObj(intid).isConference) {
            var obj = {};
            var data = {};
            data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

            obj.method = "EndPOMConferenceCall";
            obj.intid = intid;

            SendGenericCTICommand(obj.method, obj, data);
        }
        else
            DisconnectCall(global_DeviceID, intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.DropPOMCall()", ex, false);
    }
}

function EndPOMConferenceCallDone(result, obj) {
    try {
        GetPOMReferenceObj(obj.intid).isConference = false;
        log.LogDetails("Info", "POMUI.EndPOMConferenceCallDone()", "Coferenced party is removed from the call", true);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.EndPOMConferenceCallDone()", ex, false);
    }
}

function POMHoldDropCall(intid) {
    try {
        HoldCall(global_DeviceID, intid, null);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.HoldDropPOMCall()", ex, false);
    }
}

function POMUnHoldDropCall(intid) {
    try {
        UnHoldCall(global_DeviceID, intid, null);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.UnHoldDropPOMCall()", ex, false);
    }
}

function POMMakeCall() {
    try {
        POMRedialCall("", "");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMMakeCall()", ex, false);
    }
}

function POMRedialCall(intid, numberToDial) {
    try {
        var number = intid && GetPOMReferenceObj(intid) ? GetPOMReferenceObj(intid).phoneNumber : "";

        if (!numberToDial) {
            UIkit.modal.prompt("Enter the number:", number, function (newNumber) {
                if (isNaN(newNumber)) {
                    log.LogDetails("Error", "POMUI.POMRedialCall()", "Please enter a valid number", true);
                    return false;
                }
                RedialPOMCall(intid, number, newNumber);
            });
        }
        else {
            RedialPOMCall(intid, number, numberToDial);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMRedialCall()", ex, false);
    }
}

function RedialPOMCall(intid, number, numberToDial) {
    try {
        var obj = {};
        var data = {};
        //data.numberToDial = newNumber;
        if (numberToDial) {
            data.numberToDial = numberToDial;
        }
        else {
            return false;
        }
        data.custName = intid &&
            GetPOMReferenceObj(intid) &&
            GetPOMReferenceObj(intid).custName ?
            GetPOMReferenceObj(intid).custName : "ExternalNumber";
        obj.method = "RedialPOMCall";
        obj.intid = intid ? intid : "";
        obj.oldNumber = number;
        //obj.newNumber = newNumber;
        obj.newNumber = numberToDial;
        obj.type = intid ? "redial" : "makecall";
        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.RedialPOMCall()", ex, false);
    }
}

function RedialPOMCallDone(result, obj) {
    try {
        if (obj.type === "redial") {
            POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
            CloseTab(obj.intid);
            pomRedialNumber = obj.newNumber;
            log.LogDetails("Info", "POMUI.RedialPOMCallDone()", "Redialing to " + pomRedialNumber, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.RedialPOMCallDone()", ex, false);
    }
}

function POMScheduleCall(intid) {
    try {
        $("#pomSCNumber").val("");
        $("#pomSCType").html("");
        $("#pomSCRequestDate").val("");
        $("#pomSCRequestTime").val("");
        $("#pomSCExpiry").val("");
        $("#pomSCEComments").val("");
        $("#callback_destination_grid").data("kendoGrid").dataSource.data([]);

        DisableButton("#pomScheduleBtn" + intid);
        $("#pomSCNumber").val(GetPOMReferenceObj(intid).phoneNumber);
        POMGetCallbackTypes(intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SchedulePOMCall()", ex, false);
    }
}

function POMWrapUpCallContact(intid, source) {
    try {
        var callType = GetPOMReferenceObj(intid) ? "pom" : "acd";
        var wrapUpDropDown = $("#wrapupCodeDropDown" + intid).data("kendoDropDownList");
        if (!wrapUpDropDown.value()) {
            log.LogDetails("Error", "POMUI.POMWrapUpCallContact()", "Please select a completion code", true);
            return;
        }
        var obj = {};
        var data = {};
        data.connectionHandle = callType === "pom" ?
            GetPOMReferenceObj(intid).connectionHandle :
            GetTabReferenceObj(intid).OtherData.ConnectionHandle;
        data.compCode = wrapUpDropDown.value();
        data.compValue = wrapUpDropDown.text();
        data.callType = callType;

        if (source === "submit" && data.compValue.indexOf("NSP") >= 0) {
            OpenMUDialog(intid);
            return;
        }

        obj = $.extend({}, data);
        obj.method = "WrapUpCallContact";
        obj.intid = intid;
        obj.UCID = callType === "pom" ?
            GetPOMReferenceObj(intid).UCID :
            GetTabReferenceObj(intid).OtherData.UCID;

        //set customer feilds if available and wrapup the call on SetCustomerDataDone
        //set customer feilds is not available and calltype is 'pom' then wrap the call
        if (!SetCustomerData(intid, obj)) {
            //wrapup call contact
            SendGenericCTICommand(obj.method, obj, data);
        }
        $("#btnSubmitWrapUp" + intid).addClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMWrapUpCallContact()", ex, false);
    }
}

function WrapUpCallContactDone(result, obj) {
    try {
        var intid = obj.intid;
        if (result !== 0) {
            $("#btnSubmitWrapUp" + intid).removeClass("disabled");
            log.LogDetails("Error", "POMUI.WrapUpCallContactDone()", "WrapUp Call Contact Failed", true);
        }
        else {
            //set custom wrapup data after wrapup success
            //custom_SetWrapUpData(intid, obj.connectionHandle, obj.UCID, obj.compCode, obj.compValue, GetPOMReferenceObj(intid).markUnCallable.join(";"));
            custom_SetWrapUpData(intid, obj.connectionHandle, obj.UCID, obj.compCode, obj.compValue, GetTabReferenceObj(intid).OtherData.markUnCallable.join(";"));
            POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, true);
            CloseTab(intid);
            POMGetCallDashboardData();

            if (GetPOMReferenceObj(intid).cacsLogoutFlag) {
                LogoutConfirmed();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.WrapUpCallContactDone()", ex, false);
    }
}

function SetCustomerData(intid, wrapData) {
    try {
        var obj = {};
        var data = {};
        var update = false;
        //check if this completion code is there in pomDNDType list
        if (pomDNDType.indexOf(wrapData.compValue) >= 0) {
            //append status by default
            //GetPOMReferenceObj(intid).updatedPOMFeilds.push({ key: "STATUS", value: wrapData.compValue });
            GetTabReferenceObj(intid).OtherData.updatedPOMFeilds.push({ key: "STATUS", value: wrapData.compValue });
            //if  this completion code is not NSP and then add all phone numbers to markUnCallable
            //if (wrapData.compValue.indexOf("NSP") < 0) GetPOMReferenceObj(intid).markUnCallable = [$("#PHONE1_" + intid).val(), $("#PHONE2_" + intid).val(), $("#PHONE3_" + intid).val()].filter(function (n) { return n !== ""; });
            if (wrapData.compValue.indexOf("NSP") < 0)
                GetTabReferenceObj(intid).OtherData.markUnCallable = [$("#PHONE1_" + intid).val(), $("#PHONE2_" + intid).val(), $("#PHONE3_" + intid).val()].filter(function (n) { return n !== ""; });
            update = true;
        }
        //check if agent updated any feilds
        //if (GetPOMReferenceObj(intid).updatedPOMFeilds.length !== 0) {
        if (GetTabReferenceObj(intid).OtherData.updatedPOMFeilds.length !== 0) {
            //data.customerJsonData = JSON.stringify(GetPOMReferenceObj(intid).updatedPOMFeilds);
            data.customerJsonData = JSON.stringify(GetTabReferenceObj(intid).OtherData.updatedPOMFeilds);
            update = true;
        }
        //if wrapup type is in DND or if the agent has changed any feilds
        //then call SetCustomerData else ignore
        if (update) {
            data.connectionHandle = wrapData.connectionHandle;
            //data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
            data.callType = wrapData.callType;
            data.statusAttributeValue = wrapData.compValue;
            data.contactListID = GetTabReferenceObj(intid).OtherData.contactListID;
            data.customerIdentifier = $("#ID_" + intid).val();

            obj.method = "SetCustomerData";
            obj.intid = intid;
            obj.wrapData = wrapData;

            SendGenericCTICommand(obj.method, obj, data);
        }
        return update;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SetCustomerData()", ex, false);
    }
}

function SetCustomerDataDone(result, obj) {
    try {
        var data = {};
        data.connectionHandle = obj.wrapData.connectionHandle;
        data.compCode = obj.wrapData.compCode;
        data.compValue = obj.wrapData.compValue;
        data.callType = obj.wrapData.callType;

        //wrapup call contact
        SendGenericCTICommand(obj.wrapData.method, obj.wrapData, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SetCustomerDataDone()", ex, false);
    }
}

function POMGetCallbackTypes(intid) {
    try {
        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        obj.method = "GetCallbackTypes";
        obj.intid = intid;
        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMGetCallbackTypes()", ex, false);
    }
}

function GetCallbackTypesDone(result, obj) {
    try {
        if (result !== 0) {
            EnableButton("#pomScheduleBtn" + obj.intid, "phone_callback", "icon");
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetCallbackTypesDone()", ex, false);
    }
}

function POMGetCallbackDestsForType() {
    try {
        $("#callback_destination_grid").data("kendoGrid").dataSource.data([]);
        var intid = pomActiveCallInteractionID;
        var callbackType = $("#pomSCType").val();
        if (callbackType && callbackType.toLowerCase() !== "strictagent") {
            var obj = {};
            var data = {};
            data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
            data.callbackType = $("#pomSCType").val();
            obj.method = "GetCallbackDestsForType";
            obj.intid = intid;
            SendGenericCTICommand(obj.method, obj, data);
            ShowKendoLoading("#callback_destination_grid");
        }
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.POMGetCallbackDestsForType()", ex, false);
    }
}

function GetCallbackDestsForTypeDone(result, obj) {
    try {
        //GetCallbackDestsForTypeDone
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.GetCallbackDestsForTypeDone()", ex, false);
    }
}

function SubmitPOMScheduledCallbackRequest() {
    try {
        var intid = pomActiveCallInteractionID;
        if (!intid) {
            log.LogDetails("Error", "POMUI.SubmitPOMScheduledCallbackRequest()", "Interaction not available", true);
            return false;
        }
        var callbackContactToDial = $("#pomSCNumber").val();
        var callbackType = $("#pomSCType").val();
        var remoteDestinationAgent = "";
        var $grid = $("#callback_destination_grid").data("kendoGrid"); //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var callbackDate = $("#pomSCRequestDate").val();
        var callbackTime = $("#pomSCRequestTime").val();
        var callbackExpiryTime = $("#pomSCExpiry").val();
        var agentNotes = $("#pomSCEComments").val();
        var todayDate = moment(new Date()).format("DD/MM/YYYY");
        var todayDateTime = moment(new Date()).format("DD/MM/YYYY HH:mm:ss");
        var callbackDateTime = "";
        var isValid = true;
        var errorMsg = "";
        if (callbackContactToDial === "") {
            errorMsg = "Please provide contact number";
            isValid = false;
        }
        else if (callbackType === "") {
            errorMsg = "Please provide callback type";
            isValid = false;
        }
        else if (callbackDate === "") {
            errorMsg = "Please provide callback date";
            isValid = false;
        }
        else if (!moment(callbackDate, "DD/MM/YYYY").isSameOrAfter(moment(todayDate, "DD/MM/YYYY"))) {
            errorMsg = "Please provide valid callback date";
            isValid = false;
        }
        else if (callbackTime === "") {
            errorMsg = "Please provide callback time";
            isValid = false;
        }
        else if (!moment(callbackTime, "HH:mm:ss", true).isValid()) {
            errorMsg = "Please provide valid callback time";
            isValid = false;
        }
        else if (!moment(callbackDate + " " + callbackTime, "DD/MM/YYYY HH:mm:ss").isAfter(moment(todayDateTime, "DD/MM/YYYY HH:mm:ss"))) {
            errorMsg = "Please provide valid callback time";
            isValid = false;
        }
        else if (callbackType.toLowerCase() !== "standard" && callbackType.toLowerCase() !== "strictagent" && ($row === null || $row.length === 0)) {
            errorMsg = "Please select a destination agent";
            isValid = false;
        }

        if (!isValid) {
            log.LogDetails("Error", "POMUI.SubmitPOMScheduledCallbackRequest()", errorMsg, true);
            return false;
        }

        callbackDateTime = moment(callbackDate + " " + callbackTime, "DD/MM/YYYY HH:mm:ss").format("YYYYMMDDHHmmss");

        if (callbackType.toLowerCase() === "strictagent") {
            remoteDestinationAgent = global_AgentID;
        }
        else if (callbackType.toLowerCase() !== "standard") {
            var rowData = $grid.dataItem($row); //selected row data
            remoteDestinationAgent = rowData.destinationValue;
        }

        //if (callbackContactToDial.length > 8)
        //    callbackContactToDial = callbackContactToDial.substr(callbackContactToDial.length - 8);

        //trim number for callback
        if (trimNumberLength && callbackContactToDial.length > parseInt(trimNumberLength))
            callbackContactToDial = callbackContactToDial.substr(callbackContactToDial.length - parseInt(trimNumberLength));

        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.callbackType = callbackType;
        data.remoteDestinationAgent = remoteDestinationAgent;
        data.callbackContactToDial = callbackContactToDial;
        data.callbackTime = callbackDateTime;
        data.callbackExpiryTime = callbackExpiryTime;
        data.agentNotes = agentNotes;
        data.contactID = GetPOMReferenceObj(intid).contactID;
        data.campaignName = GetPOMReferenceObj(intid).campaignName;
        data.campaignID = $("#CAMP_ID_" + intid).val();
        var tempContactsList = GetPOMReferenceObj(intid).contactNumbers.filter(function (c) { return c.Number === callbackContactToDial; });
        if (tempContactsList.length > 0)
            data.custName = tempContactsList[0].Name;
        else
            data.custName = "ExternalNumber";

        obj.method = "CreateCallback";
        obj.intid = intid;
        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SubmitPOMScheduledCallbackRequest()", ex, false);
    }
}

function CreateCallbackDone(result, obj) {
    try {
        //CreateCallbackDone
        log.LogDetails("Success", "POMUI.CreateCallbackDone()", "Callback request successfully scheduled", true);
        $("#pom_schedule_callback_dialog").data("kendoWindow").close();
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.CreateCallbackDone()", ex, false);
    }
}

function NRICSearchEvent(event, intid) {
    try {
        if (event.keyCode === 13) POMSearchCustomer(intid);
    }
    catch (ex) {
        log.LogDetails("Error", "POMUI.NRICSearchEvent()", ex, false);
    }
}

function POMSearchCustomer(intid) {
    try {
        var nric = $('#txtNRIC' + intid).val().trim();
        if (nric === '') {
            ShowNotify("Please enter the NRIC", "danger", null, "top-center");
            return;
        }

        var obj = {};
        var data = {};

        data.connectionHandle = GetTabReferenceObj(intid).OtherData.ConnectionHandle;
        data.teamName = global_TeamName;
        data.userContactID = nric;
        data.ucid = GetTabReferenceObj(intid).OtherData.UCID;

        obj.method = "GetCustomerContact";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);

        FadeOutButton("#btnSearchCustomer" + intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMSearchCustomer()", ex, false);
    }
}

function GetCustomerContactDone(result, obj) {
    try {
        if (result !== 0) {
            log.LogDetails("Error", "POMUI.GetCustomerContactDone()", "GetCustomerContact Failed", true);
        }
        FadeInButton("#btnSearchCustomer" + obj.intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetCustomerContactDone()", ex, false);
    }
}

function OpenPOMTransfConfDialog(intid, type) {
    try {
        $("#consult_transfer_type").data("kendoDropDownList").text("Select Consult Type...");
        $("#consult_transfer_type").data("kendoDropDownList").value("");
        $("#pomAgentList").data("kendoGrid").dataSource.data([]);
        $("#btnpomtransfercall").addClass("uk-display-none");
        $("#btnpomconferencecall").addClass("uk-display-none");
        $("#pomTxtNumberTransConf").val("");
        if (type === "trans") {
            global_CallType = "Transfer";
            global_transferIntID = intid;
            $("#pom_trans_conf_dialog").data("kendoWindow").title("Transfer Agent List");
            $("#btnpomtransfercall").removeClass("uk-display-none");
        }
        else {
            global_CallType = "Conference";
            global_conferenceIntID = intid;
            $("#pom_trans_conf_dialog").data("kendoWindow").title("Conference Agent List");
            $("#btnpomconferencecall").removeClass("uk-display-none");
        }
        $("#pom_trans_conf_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenPOMTransfConfDialog()", ex, false);
    }
}

function ClosePOMTransConfDialog() {
    try {
        $("#pom_trans_conf_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenPOMTransfConfDialog()", ex, false);
    }
}

function GetConsultDestinationAgentsList(intid, type) {
    try {
        var obj = {};
        var data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.consultType = type;

        obj.method = "GetConsultDestinationAgentsList";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetConsultDestinationAgentsList()", ex, false);
    }
}

function GetConsultDestinationAgentsListDone(result, obj) {
    try {
        if (result !== 0) {
            $("#pomAgentList").data("kendoGrid").dataSource.data([]);
        }
        if (result === "-382")
            log.LogDetails("Error", "POMUI.SendGenericCTICommandDone()", "No Destinations Available", true);
        else if (result === "-383")
            log.LogDetails("Error", "POMUI.SendGenericCTICommandDone()", "Agents are not Available", true);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetConsultDestinationAgentsListDone()", ex, false);
    }
}

function POMTransConfCallEvent(event) {
    try {
        if (event.keyCode === 13) {
            if (global_CallType === "transfer")
                POMTransferCall();
            else if (global_CallType === "conference")
                POMConferenceCall();
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMTransConfCallEvent()", ex, false);
    }
}

function POMTransferCall() {
    try {
        DisableButton("#btnpomtransfercall");
        var comment = "";
        var number = $("#pomTxtNumberTransConf").val();
        //get the interaction id
        var intId = global_transferIntID;
        var obj = {};
        obj.buttonId = "#btnpomtransfercall";
        obj.icon = "swap_horiz";
        obj.type = "pom";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Please provide the destination number", "danger", null, "top-center");
            return;
        }
        TransferCallCommand(global_DeviceID, intId, number, comment, obj);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMTransferCall()", ex, false);
    }
}

function POMConferenceCall() {
    try {
        DisableButton("#btnpomconferencecall");
        var comment = "";
        var number = $("#pomTxtNumberTransConf").val();
        //get the interaction id
        var intId = global_conferenceIntID;
        var obj = {};
        obj.buttonId = "#btnpomconferencecall";
        obj.icon = "call_split";
        obj.type = "pom";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Please provide destination number", "danger", null, "top-center");
            return;
        }
        ConferenceCall(global_DeviceID, intId, number, comment, obj);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceCall()", ex, false);
    }
}

function POMOpenSaleScreen(intid) {
    try {
        var salesScreenDropDown = $("#salesScreen" + intid).data("kendoDropDownList");
        var sessionId = GetPOMReferenceObj(intid) ? GetPOMReferenceObj(intid).UCID : GetTabReferenceObj(intid).OtherData.UCID;
        var url = salesScreenDropDown.value() + sessionId;
        window.open(url, intid, "width=" + screen.width + ",height=" + screen.height);

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMOpenSaleScreen()", ex, false);
    }
}

function POMGetAgentLoginMode(agentId, userObject) {
    try {
        var obj = {};
        var data = {};
        data.agentId = agentId;
        data.deviceId = global_DeviceID;
        data.userObject = userObject;

        obj.method = "GetAgentLoginMode";
        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMGetAgentLoginMode()", ex, false);
    }
}

function GetAgentLoginModeDone(result, obj) {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "POMUI.AgentSessionsListLoaded()", ex, false);
    }
}

function POMGetCallDashboardData() {
    try {
        var obj = {};
        obj.method = "GetCallDashboardData";
        SendGenericCTICommand(obj.method, obj, {});
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMGetCallDashboardData()", ex, false);
    }
}

function GetCallDashboardDataDone() {
    try {
        //
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetCallDashboardDataDone()", ex, false);
    }
}

function EditPOMCallback(arg) {
    try {
        var dataItem = this.dataItem($(arg.currentTarget).closest("tr"));
        var dateTime = moment(dataItem.callbackDateTime, "DD/MM/YYYY HH:mm:ss");

        $("#pomEditSCNumber").val(dataItem.callerID);
        $("#pomEditSCType").val("StrictAgent");
        $("#pomEditSCRequestDate").data("kendoDatePicker").value(moment(dateTime).format("DD/MM/YYYY"));
        $("#pomEditSCRequestTime").data("kendoTimePicker").value(moment(dateTime).format("HH:mm:ss"));
        $("#pomEditSCEComments").val(dataItem.agentNotes);
        $("#pomEditSCContactID").val(dataItem.contactID);
        $("#pomEditSCCampaignName").val(dataItem.campaignName);
        $("#pomEditSCCampaignID").val(dataItem.campaignID);
        $("#pomEditSCCustName").val(dataItem.custName);

        $("#pom_edit_callback_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.EditPOMCallback()", ex, false);
    }
}

function EditPOMScheduledCallbackRequest() {
    try {
        var data = {};
        var obj = {};

        var isValid = true;
        var errorMsg = "";

        var callbackDate = $("#pomEditSCRequestDate").val();
        var callbackTime = $("#pomEditSCRequestTime").val();

        var todayDate = moment(new Date()).format("DD/MM/YYYY");
        var todayDateTime = moment(new Date()).format("DD/MM/YYYY HH:mm:ss");

        data.callbackType = $("#pomEditSCType").val();
        data.remoteDestinationAgent = "";
        data.callbackContactToDial = $("#pomEditSCNumber").val();
        data.agentNotes = $("#pomEditSCEComments").val();
        data.contactID = $("#pomSCContactID").val();
        data.campaignName = $("#pomSCCampaignName").val();
        data.campaignID = $("#pomSCCampaignID").val();
        data.custName = $("#pomSCCustName").val();

        if (data.callbackContactToDial === "") {
            errorMsg = "Please provide contact number";
            isValid = false;
        }
        else if (data.callbackType === "") {
            errorMsg = "Please provide callback type";
            isValid = false;
        }
        else if (callbackDate === "") {
            errorMsg = "Please provide callback date";
            isValid = false;
        }
        else if (!moment(callbackDate, "DD/MM/YYYY").isSameOrAfter(moment(todayDate, "DD/MM/YYYY"))) {
            errorMsg = "Please provide valid callback date";
            isValid = false;
        }
        else if (callbackTime === "") {
            errorMsg = "Please provide callback time";
            isValid = false;
        }
        else if (!moment(callbackTime, "HH:mm:ss", true).isValid()) {
            errorMsg = "Please provide valid callback time";
            isValid = false;
        }
        else if (!moment(callbackDate + " " + callbackTime, "DD/MM/YYYY HH:mm:ss").isAfter(moment(todayDateTime, "DD/MM/YYYY HH:mm:ss"))) {
            errorMsg = "Please provide valid callback time";
            isValid = false;
        }
        else if (data.callbackType.toLowerCase() !== "standard" && data.callbackType.toLowerCase() !== "strictagent" && ($row === null || $row.length === 0)) {
            errorMsg = "Please select a destination agent";
            isValid = false;
        }

        if (!isValid) {
            log.LogDetails("Error", "POMUI.EditPOMScheduledCallbackRequest()", errorMsg, true);
            return false;
        }

        data.callbackTime = moment(callbackDate + " " + callbackTime, "DD/MM/YYYY HH:mm:ss").format("YYYYMMDDHHmmss");

        if (data.callbackType.toLowerCase() === "strictagent") {
            data.remoteDestinationAgent = global_AgentID;
        }

        //trim number for callback
        if (trimNumberLength && data.callbackContactToDial.length > parseInt(trimNumberLength))
            data.callbackContactToDial = data.callbackContactToDial.substr(data.callbackContactToDial.length - parseInt(trimNumberLength));

        obj.method = "EditCallback";

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.EditPOMScheduledCallbackRequest()", ex, false);
    }
}

function EditCallbackDone() {
    try {
        $("#pom_edit_callback_dialog").data("kendoWindow").close();

        $("#pomEditSCNumber").val("");
        $("#pomEditSCType").val("");
        $("#pomEditSCRequestDate").data("");
        $("#pomEditSCRequestTime").data("");
        $("#pomEditSCEComments").val("");
        $("#pomEditSCContactID").val("");
        $("#pomEditSCCampaignName").val("");
        $("#pomEditSCCampaignID").val("");
        $("#pomEditSCCustName").val("");

        log.LogDetails("Success", "POMUI.EditCallbackDone()", "Callback updated successfully", true);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.EditCallbackDone()", ex, false);
    }
}

function TerminatePOMCallback(arg) {
    try {
        var dataItem = this.dataItem($(arg.currentTarget).closest("tr"));
        UIkit.modal.confirm('Are you sure to terminate this callback?',
            function () {
                var obj = {};
                var data = {};
                data.contactID = dataItem.contactID;

                obj.method = "TerminateCallback";
                SendGenericCTICommand(obj.method, obj, data);
            });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.TerminatePOMCallback()", ex, false);
    }
}

function TerminateCallbackDone() {
    try {
        log.LogDetails("Success", "POMUI.TerminateCallbackDone()", "Callback terminated successfully", true);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.TerminateCallbackDone()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------GENERIC METHODS-------------------------------------------
function POMConfigurations() {
    try {
        $.getJSON("configs/POMCustomerInfoConfig.json", function (json) {
            pomCustomerInfoConfig = json;
        });
        $("#agent_type_li").removeClass("uk-display-none");
        if (isPOMCallDashboard)
            $("#pom_dashboard_grid").removeClass("uk-display-none");
        //consult transfer_type dropdown
        $("#consult_transfer_type").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: [
                { text: "Agent", value: "Agent" },
                { text: "External", value: "External" }
            ],
            select: OnConsultTransferTypeSelected
        });
        $("#consult_transfer_type").data("kendoDropDownList").text("Select a consult type...");

        $("input[name='mu_checkbox']").on('change', function () {
            if (this.checked) {
                GetTabReferenceObj(global_activeTabInteractionID).OtherData.markUnCallable.push(this.value);
                //GetPOMReferenceObj(pomActiveCallInteractionID).markUnCallable.push(this.value);
            }
            else {
                var index = GetTabReferenceObj(global_activeTabInteractionID).OtherData.markUnCallable.indexOf(this.value);
                if (index > -1) GetTabReferenceObj(global_activeTabInteractionID).OtherData.markUnCallable.splice(index, 1);
                //var index = GetPOMReferenceObj(pomActiveCallInteractionID).markUnCallable.indexOf(this.value);
                //if (index > -1) GetPOMReferenceObj(pomActiveCallInteractionID).markUnCallable.splice(index, 1);
            }
        });

        var datePicker = $("#pomSCRequestDate").kendoDatePicker({
            format: "dd/MM/yyyy",
            min: new Date()
            //disableDates: ["sa", "su"]
        }).data("kendoDatePicker");
        $("[for=pomSCRequestDate]").siblings("span").css("margin-top", "10px");

        var datePickerEdit = $("#pomEditSCRequestDate").kendoDatePicker({
            format: "dd/MM/yyyy",
            min: new Date()
            //disableDates: ["sa", "su"]
        }).data("kendoDatePicker");
        $("[for=pomEditSCRequestDate]").siblings("span").css("margin-top", "10px");

        if (limitPOMCallbackDate) {
            datePicker.enable(false);
            datePickerEdit.enable(false);
        }

        $("#pomSCRequestTime").kendoTimePicker({
            format: "HH:mm:ss",
            interval: 15
        });
        $("[for=pomSCRequestTime]").siblings("span").css("margin-top", "10px");

        $("#pomEditSCRequestTime").kendoTimePicker({
            format: "HH:mm:ss",
            interval: 15
        });
        $("[for=pomEditSCRequestTime]").siblings("span").css("margin-top", "10px");

        $('#chkManualEnter').change(function () {
            if (this.checked === true) {
                $("#pomManualNumberGrid").removeClass("uk-display-none");
                $("#pomAutoNumberGrid").addClass("uk-display-none");

                $("#mc_radio_mobile").removeAttr("checked", "checked");
                $("#mc_radio_work").removeAttr("checked", "checked");
                $("#mc_radio_home").removeAttr("checked", "checked");

            } else {
                $("#pomManualNumberGrid").addClass("uk-display-none");
                $("#pomAutoNumberGrid").removeClass("uk-display-none");

                $("#pomManualNumber").val("");
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConfigurations()", ex, false);
    }
}

function SavePOMReference(intid) {
    try {
        var pomRef = {};
        pomRef.intid = intid;
        pomRef.contactID = "";
        pomRef.campaignName = "";
        pomRef.connectionHandle = "";
        pomRef.contactNumbers = [];
        pomRef.phoneNumber = "";
        pomRef.customerName = "";
        pomRef.UCID = "";
        //pomRef.closeTab = false;
        pomRef.isConference = false;
        pomRef.conferenceType = "";
        pomRef.isRedial = false;
        pomRef.updatedPOMFeilds = [];
        pomRef.markUnCallable = [];
        pomRef.autoDial = true;
        pomRef.cacsLogoutFlag = false;
        //push to the array for that interaction
        global_POMReference.push(pomRef);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SaveFaxReference()", ex, false);
    }
}

function GetPOMReferenceObj(intid) {
    try {
        for (var i = 0; i < global_POMReference.length; i++) {
            if (global_POMReference[i] !== undefined && global_POMReference[i].intid === parseInt(intid))
                return global_POMReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetPOMReferenceObj()", ex, false);
    }
}

function RemovePOMReference(intid) {
    try {
        for (var i = 0; i < global_POMReference.length; i++) {
            if (global_POMReference[i] !== undefined && global_POMReference[i].intid === parseInt(intid)) {
                global_POMReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.RemovePOMReference()", ex, false);
    }
}

function POMSetCallControlStatus(intid, dial, reject, transferCancel, drop, hold, unhold, trans, conf, redial, schedule, tabClose) {
    try {
        if (dial === false) {
            $('#pomDialBtn' + intid).addClass('disabled');
        } else {
            $('#pomDialBtn' + intid).removeClass('disabled');
        }

        if (reject) {
            $('#pomCancelBtn' + intid).css("display", "inline-block");
            $('#pomCancelBtn' + intid).removeClass('disabled');
            $('#pomRejectConsultBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }
        else if (transferCancel) {
            $('#pomRejectConsultBtn' + intid).css("display", "inline-block");
            $('#pomRejectConsultBtn' + intid).removeClass('disabled');
            $('#pomCancelBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }
        else if (drop) {
            $('#pomDropBtn' + intid).css("display", "inline-block");
            $('#pomDropBtn' + intid).removeClass('disabled');
            $('#pomCancelBtn' + intid).css("display", "none");
            $('#pomRejectConsultBtn' + intid).css("display", "none");
        } else {
            $('#pomCancelBtn' + intid).css("display", "inline-block");
            $('#pomCancelBtn' + intid).addClass('disabled');
            $('#pomRejectConsultBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }

        if (!hold && !unhold) {
            $('#pomHoldBtn' + intid).css("display", "inline-block");
            $('#pomUnHoldBtn' + intid).css("display", "none");
            $('#pomHoldBtn' + intid).addClass('disabled');
        } else if (hold) {
            $('#pomHoldBtn' + intid).css("display", "inline-block");
            $('#pomUnHoldBtn' + intid).css("display", "none");
            $('#pomHoldBtn' + intid).removeClass('disabled');
        } else if (unhold !== "disable") {
            $('#pomUnHoldBtn' + intid).css("display", "inline-block");
            $('#pomHoldBtn' + intid).css("display", "none");
            $('#pomUnHoldBtn' + intid).removeClass('disabled');
        } else {
            $('#pomUnHoldBtn' + intid).css("display", "inline-block");
            $('#pomHoldBtn' + intid).css("display", "none");
            $('#pomUnHoldBtn' + intid).addClass('disabled');
        }

        if (trans === false) {
            $('#pomTransBtn' + intid).addClass('disabled');
        } else {
            $('#pomTransBtn' + intid).removeClass('disabled');
        }

        if (conf === false) {
            $('#pomConfBtn' + intid).addClass('disabled');
        } else {
            $('#pomConfBtn' + intid).removeClass('disabled');
        }

        if (redial === false) {
            $('#pomRediaBtn' + intid).addClass('disabled');
        } else {
            $('#pomRediaBtn' + intid).removeClass('disabled');
        }

        if (schedule === false) {
            $('#pomScheduleBtn' + intid).addClass('disabled');
        } else {
            $('#pomScheduleBtn' + intid).removeClass('disabled');
        }

        if (tabClose === true) {
            EnableTabCloseButton(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMSetCallControlStatus()", ex, false);
    }
}

function CreateCustomerInfoPanel(intid, campaignName) {
    try {
        var sections = [];
        if (campaignName) {
            //get all the section for this campaign
            $.each(pomCustomerInfoConfig, function (key, val) {
                if (val.CampaignNames.indexOf(campaignName) > -1)
                    sections.push(this);
            });
            if (sections.length !== 0)
                //create section feilds
                CreateSectionFeilds(intid, sections);
            else {
                var text = "<i class='material-icons notranslate md-34 uk-text-danger'>report</i>Customer informations not available for you team. Please contact your supervisor.";
                $("#dynamic_customer_info_" + intid).html("<div class='heading_b uk-text-center custom-padding'>" + text + "</div>");
            }
        }
        else
            log.LogDetails("Error", "POMUI.CreateCustomerInfoPanel()", "campaign name is empty", false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateCustomerInfoPanel()", ex, false);
    }
}

function CreateSectionFeilds(intid, sections) {
    try {
        //check for no of sections
        //create the tab for more than one section
        if (sections.length > 1) {
            //get the html from template for tab
            var tab = GetHtmlFromTemplate("pom_customer_info_tab", intid, null);
            //append to the div
            $("#dynamic_customer_info_" + intid).html(tab);
            //foreach section create 'li' and associative 'div' for the kendo tabstrip
            $.each(sections, function (key, val) {
                //create the li, set it to active it this is the first tab
                var liMain = '<li class="' + (key === 0 ? "k-state-active" : "") + '">Section ' + (key + 1) + '</li>';
                //append the li to the tabstrip ul
                $("#customer_info_tabstrip_ul_" + intid).append(liMain);
                //create the associative div for the li
                var subDiv =
                    '<div>'
                    //load the inner section for the tab content
                    + CreateOuterSection(intid, val.Variables)
                    + '</div>';
                //append the div to tabstrip
                $("#customer_info_tabstrip_" + intid).append(subDiv);
            });
            //create kendo tabstip
            $("#customer_info_tabstrip_" + intid).kendoTabStrip({
                animation: false,
                select: function () { TriggerResize(); }
            });
        }
        //if there is only one section then append the section and feilds directly without the tab
        else {
            var html = CreateOuterSection(intid, sections[0].Variables);
            $("#dynamic_customer_info_" + intid).html(html);
            $("#dynamic_customer_info_" + intid).removeClass("no-padding");
        }

        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateSectionFeilds()", ex, false);
    }
}

function CreateOuterSection(intid, sectionVariables) {
    try {
        //create outer section
        var section =
            '<div class="uk-grid uk-animation-scale-up">' +
            '<div class="uk-width-1-1">' +
            '<div class="uk-grid">';
        //save the last row id
        var lastRowId = 1;
        //foreach sections create the main section and feilds
        $.each(sectionVariables, function (key, val) {
            //split the key from json
            var keySplit = key.split("|");
            //get the rowid from the split
            var rowId = keySplit[0].split('_')[0];
            //get the column count for this inner section
            var columnCount = keySplit[0].split('_')[1];
            //label for the inner section
            var label = keySplit[1].split("_").join(" ");
            //if rowid is not as last row id then split the section to next
            //this will split the rows to be shown in UI
            if (rowId !== lastRowId)
                //create new outer section
                section +=
                    '</div>' +
                    '</div>' +
                    '<div class="uk-width-1-1">' +
                    '<div class="uk-grid">';
            //custom data handlebar context
            var customData = {};
            customData.columncount = columnCount;
            //Load the inner feilds to the obj
            customData.feildhtml = CreateFeildHtml(intid, val, label);
            //get the sections from handlebar template
            section += GetHtmlFromTemplate("pom_customer_info_section", intid, customData);
            //update the last row id
            lastRowId = rowId;
        });
        //return the section with close 'uk-grid' div
        return section + "</div>";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateOuterSection()", ex, false);
    }
}

function CreateFeildHtml(intid, variable, label) {
    try {
        //to store feild html
        var feildHtml = "";
        //is first element in feilds
        var isFirst = true;
        var customData = {};
        customData.textcolor = "md-color-red-900";
        //if the variable feilds are more than a row its in a array       
        if (typeof (variable) === "object")
            //loop and get the feilds for each row
            $.each(variable, function (key, feild) {
                //if this the first row get add the label
                customData.label = isFirst ? "<label>" + label + "</label>" : "";
                //text id for the feild textbox
                customData.textid = feild + "_" + intid;
                //get the feilds from handlebar template
                feildHtml += GetHtmlFromTemplate("pom_customer_info_feild", intid, customData);
                //make first false
                isFirst = false;
            });
        else {
            customData.label = "<label>" + label + "</label>";
            customData.textid = variable + "_" + intid;
            //get the feilds from handlebar template for single row variable
            feildHtml += GetHtmlFromTemplate("pom_customer_info_feild", intid, customData);
        }
        return feildHtml;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateFeildHtml()", ex, false);
    }
}

function POMTransferCompleteDone(data, obj) {
    try {
        //ProcessPendingBlendRequest();
        if (agentType === "AutoDialer")
            //GetPOMReferenceObj(obj.interactionid).closeTab = true;
            GetTabReferenceObj(obj.interactionid).isCloseTab = true;
        else if (agentType === "ACD") {
            GetTabReferenceObj(obj.interactionid).isCloseTab = true;
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMTransferCompleteDone()", ex, false);
    }
}

function POMDisconnectCallDone(data, obj) {
    try {
        //ProcessPendingBlendRequest();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMDisconnectCallDone()", ex, false);
    }
}

//-------------------------------------------------------------------------------------------
function CheckPOMUpdatedFeilds(intid, key) {
    try {
        //return $.grep(GetPOMReferenceObj(intid).updatedPOMFeilds, function (n) { return key === n.key; });
        return $.grep(GetTabReferenceObj(intid).OtherData.updatedPOMFeilds, function (n) { return key === n.key; });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CheckPOMUpdatedFeilds()", ex, false);
    }
}

function UpdateCurrentFeildValues(intid, key, value) {
    try {
        //return $.grep(GetPOMReferenceObj(intid).updatedPOMFeilds, function (n, i) { if (key === n.key) { GetPOMReferenceObj(intid).updatedPOMFeilds[i].value = value; return; } });
        return $.grep(GetTabReferenceObj(intid).OtherData.updatedPOMFeilds, function (n, i) { if (key === n.key) { GetTabReferenceObj(intid).OtherData.updatedPOMFeilds[i].value = value; return; } });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.UpdateCurrentFeildValues()", ex, false);
    }
}

function RemoveFeildValues(intid, key) {
    try {
        //return $.grep(GetPOMReferenceObj(intid).updatedPOMFeilds, function (n, i) { if (key === n.key) { GetPOMReferenceObj(intid).updatedPOMFeilds.splice(i, 1); return; } });
        return $.grep(GetTabReferenceObj(intid).OtherData.updatedPOMFeilds, function (n, i) { if (key === n.key) { GetTabReferenceObj(intid).OtherData.updatedPOMFeilds.splice(i, 1); return; } });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.RemoveFeildValues()", ex, false);
    }
}

function OpenMUDialog(intid) {
    try {
        var mobile = $("#PHONE1_" + intid).val().trim();
        var work = $("#PHONE2_" + intid).val().trim();
        var home = $("#PHONE3_" + intid).val().trim();

        if (mobile) {
            $("#mu_checkbox_mobile").removeAttr("disabled");
            $("#mu_checkbox_mobile").attr("value", mobile);
            $("#muMobile").text(mobile);
        }
        if (work) {
            $("#mu_checkbox_work").removeAttr("disabled");
            $("#mu_checkbox_work").attr("value", work);
            $("#muWork").text(work);
        }
        if (home) {
            $("#mu_checkbox_home").removeAttr("disabled");
            $("#mu_checkbox_home").attr("value", home);
            $("#muHome").text(home);
        }
        UIkit.modal("#modal_mark_uncallable").show();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenMUDialog()", ex, false);
    }
}

function CloseMUDialog(type) {
    if (type === "ok") {
        POMWrapUpCallContact(global_activeTabInteractionID, "mu");
        //POMWrapUpCallContact(pomActiveCallInteractionID, "mu");
    }
    $("#mu_checkbox_mobile").attr("disabled", "disabled");
    $("#mu_checkbox_work").attr("disabled", "disabled");
    $("#mu_checkbox_home").attr("disabled", "disabled");

    $("#mu_checkbox_mobile").removeAttr("checked", "checked");
    $("#mu_checkbox_work").removeAttr("checked", "checked");
    $("#mu_checkbox_home").removeAttr("checked", "checked");

    $("#muMobile").text("-");
    $("#muWork").text("-");
    $("#muHome").text("-");
    UIkit.modal("#modal_mark_uncallable").hide();
}

function POMInboundCallEvent(event) {
    try {
        var intid = event.InteractionID;
        //create wrapup dropdown
        CreateWrapupDropdown(intid, "inbound");
        //create sales screen and show NRIC search only for POM
        if (!isCACS) {
            //create sales screen dropdown
            CreateSalesDropdown(intid);
            //show the sales screen dropdown
            $("#div_SalesScreen" + intid).removeClass("uk-display-none");
            //show NRIC search
            $("#div_NRICSearch" + intid).removeClass("uk-display-none");
        }
        else {
            //if this is CACS inbound then close the tab to true
            GetTabReferenceObj(intid).isCloseTab = true;
        }
        GetTabReferenceObj(intid).OtherData.UCID = event.UCID;
        GetTabReferenceObj(intid).OtherData.ConnectionHandle = event.RecoveryData.ConnectionHandle;
        GetTabReferenceObj(intid).OtherData.updatedPOMFeilds = [];
        GetTabReferenceObj(intid).OtherData.markUnCallable = [];
        ChangeStatus(global_DeviceID, 'acw', '0');
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMInboundCallCustom()", ex, false);
    }
}

function POMInboundDisconnectEvent(event) {
    try {
        var intid = event.InteractionID, data = pomInboundWrapupCodes;
        FadeOutButton("#btnSearchCustomer" + intid);
        $("#txtNRIC" + intid).attr("disabled");
        //check if this tab to be closed then close it
        if (GetTabReferenceObj(intid).isCloseTab) {
            CloseTab(intid);
        }
        else {
            //no need to filter as CACS inbound NRIC search is disabled
            if ($("#ID_" + intid).val()) {
                data = pomInboundWrapupCodes.filter(function (d) { return d.codeID !== "0"; });
            }
            else {
                data = pomInboundWrapupCodes.filter(function (d) { return d.codeID === "0"; });
            }
            $("#wrapupCodeDropDown" + intid).data("kendoDropDownList").dataSource.data(data);
            $("#wrapupCodeDropDown" + intid).data("kendoDropDownList").text("Select a completion code...");
            //show wrapup for POM inbound disconnect
            $("#div_wrapup" + intid).removeClass("uk-display-none");
            //disable close tab for non acd calls also
            $('#btnCloseTab' + intid).toggle(false);
        }
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMPOMInboundDisconnectEvent()", ex, false);
    }
}

function CreateWrapupDropdown(intid, type) {
    try {
        //initialise completionCode dropdown
        $("#wrapupCodeDropDown" + intid).kendoDropDownList({
            dataTextField: "codeValue",
            dataValueField: "codeID",
            index: 0,
            select: function (e) {
                var update = false;
                var value = "";
                var dataItem = this.dataItem(e.item);
                if (pomDNDType.indexOf(dataItem.codeValue) >= 0) {
                    update = true;
                }
                value = update ? dataItem.codeValue : "";
                $("#STATUS_" + intid).val(value);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateWrapupDropdown()", ex, false);
    }
}

function CreateSalesDropdown(intid) {
    try {
        //initialise sales screen dropdown
        $("#salesScreen" + intid).kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: pomSaleScreenList
        });
        $("#salesScreen" + intid).data("kendoDropDownList").text("Select a screen...");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreateSalesDropdown()", ex, false);
    }
}

function OpenMCDialog(intid) {
    try {
        var mobile = $("#PHONE1_" + intid).val().trim();
        var work = $("#PHONE2_" + intid).val().trim();
        var home = $("#PHONE3_" + intid).val().trim();

        $("#redialInteractionId").val(intid);

        if (mobile) {
            $("#mc_radio_mobile").removeAttr("disabled");
            $("#mc_radio_mobile").attr("value", mobile);
            $("#mcMobile").text(mobile);
        }
        if (work) {
            $("#mc_radio_work").removeAttr("disabled");
            $("#mc_radio_work").attr("value", work);
            $("#mcWork").text(work);
        }
        if (home) {
            $("#mc_radio_home").removeAttr("disabled");
            $("#mc_radio_home").attr("value", home);
            $("#mcHome").text(home);
        }
        UIkit.modal("#modal_pom_mark_call").show();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenMCDialog()", ex, false);
    }
}

function CloseMCDialog(type) {
    try {
        var numberToDial = "";
        if (type === "call") {

            if ($('#chkManualEnter')[0].checked) {
                numberToDial = $("#pomManualNumber").val();
            }
            else {
                numberToDial = $('input[name=mc_radio]:checked').val();
            }

            if (numberToDial) {
                var intid = $("#redialInteractionId").val();
                POMRedialCall(intid, numberToDial);
            }
            else {
                log.LogDetails("Error", "POMUI.CloseMCDialog()", "Please select a number or enter number manually", true);
                return false;
            }
        }

        UIkit.modal("#modal_pom_mark_call").hide();

        $("#mc_radio_mobile").attr("disabled", "disabled");
        $("#mc_radio_work").attr("disabled", "disabled");
        $("#mc_radio_home").attr("disabled", "disabled");

        $("#mc_radio_mobile").removeAttr("checked", "checked");
        $("#mc_radio_work").removeAttr("checked", "checked");
        $("#mc_radio_home").removeAttr("checked", "checked");

        $("#mcMobile").text("-");
        $("#mcWork").text("-");
        $("#mcHome").text("-");

        $("#pomManualNumber").val("");

        var chkManualEnter = document.querySelector('#chkManualEnter');
        chkManualEnter.checked = false;
        onSwitchChange(chkManualEnter);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CloseMCDialog()", ex, false);
    }
}