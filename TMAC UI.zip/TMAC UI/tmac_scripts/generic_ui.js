﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "GenericUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

function GenericInteraction(event) {
    try {
        let headerTemplate = "";
        let bodyTemplate = "";
        let item = event.Item;
        switch (item.Type.toLowerCase()) {
            case "voicebio":
                headerTemplate = GetHtmlFromTemplate("tab_header_template", event.InteractionID, { icon: "phone" });
                bodyTemplate = GetHtmlFromTemplate("voice_bio_body_template", event.InteractionID, null);
                break;

            case "twitter":
                TwitterIncomingTweetEvent(event);
                return;

            case "twitterdm":
                TwitterIncomingMessageEvent(event);
                return;

            case "line":
                LineIncomingMessageEvent(event);
                return;

            case "tcmvoicewq":
                TCMVoiceWQInteraction(event);
                return;

            case "videoaudit":
                VideoAuditInteraction(event);
                return;
            default:
                log.LogDetails("Error", "GenericUI.GenericInteraction()", item.Type + " is not defined in switch case!", false);
        }

        SaveTabReference("generic_" + item.Type, event.InteractionID, "new");
        AddTab(bodyTemplate, headerTemplate, event.InteractionID, item.CustomerIdentifier, true, false, true);
        window[item.Type + "Interaction"](event);

    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GenericInteraction()", ex, false);
    }
}

function HandleGenericCTIEvent(event) {
    try {
        window[event.SubEventName](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.HandleGenericCTIEvent()", ex, false);
    }
}

function HandleGenericCallEvent(event) {
    try {
        window[event.SubEventName](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.HandleGenericCallEvent()", ex, false);
    }
}

function HandleGenericTMACEvent(event) {
    try {
        window[event.SubEventName](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.HandleGenericTMACEvent()", ex, false);
    }
}
