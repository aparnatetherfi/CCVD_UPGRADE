//  File version: 4.0.11.12

/**
 * OPens a tab forr video audit
 * @param {*} event 
 */
function VideoAuditInteraction(event) {
    try {
        var url = AppConfigs.Remote.URLs.Custom.VideoAudit + "?sessionid=" + JSON.parse(event.Item.Data).sessionID;

        OpenIframeTab("gen_video-audit", url, "Video Audit", false, event.InteractionID);

    } catch (ex) {
        log.LogDetails("Error", "video-audit.VideoAuditInteraction()", ex, false);
    }
}