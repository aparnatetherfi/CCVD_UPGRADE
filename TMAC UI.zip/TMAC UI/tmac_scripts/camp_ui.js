﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CampUI.js";
var file_version = "4.0.11.12";
var changedBy = "Vishal Pinto";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
function AcceptCallack(fromAddr) {
    try {
        OnAgentResponseToDacRequest(fromAddr, "accept", global_AgentID, global_DeviceID, "");
    } catch (ex) {
        log.LogDetails("Error", "CampUI.AcceptCallack()", ex, false);
    }
}

function RejectCallack(fromAddr) {
    try {
        OnAgentResponseToDacRequest(fromAddr, "reject", global_AgentID, global_DeviceID, "");
        //chcek if the notification is popped in kendo window then destroy it
        if ($("#dac_notification_dialog_" + fromAddr).length > 0) {
            $("#dac_notification_dialog_" + fromAddr).data("kendoWindow").destroy();
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.RejectCallack()", ex, false);
    }
}

function SnoozeCallback(fromAddr) {
    try {
        let scheduletTime = "";
        if ($("#txtSnooze").length > 0) {
            let date = new Date();
            let d = moment(date).add(parseInt($("#txtSnooze").val()), 'm').toDate();
            scheduletTime = moment(d).format("YYYYMMDDHHmmss");
        }
        else {
            scheduletTime = moment(new Date()).add((typeof (defaultSnoozeTimeout) !== "undefined" ? defaultSnoozeTimeout : 5), 'minutes').format("YYYYMMDDHHmmss");
        }
        OnAgentResponseToDacRequest(fromAddr, "snooze", global_AgentID, global_DeviceID, scheduletTime);
        //chcek if the notification is popped in kendo window then destroy it
        if ($("#dac_notification_dialog_" + fromAddr).length > 0) {
            $("#dac_notification_dialog_" + fromAddr).data("kendoWindow").destroy();
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.SnoozeCallback()", ex, false);
    }
}

function OnAgentResponseToDacRequestDone(result, mydata) {
    try {
        callbackDialog.dialog("close");
        if (result == 0) {
            log.LogDetails("Success", "CampUI.OnAgentResponseToDacRequestDone", mydata + " success", true);
        } else {
            log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequestDone", mydata + " failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequestDone()", ex, false);
    }
}

function DirectAgentNotifyEvent(event) {
    try {
        let obj = JSON.parse(event.JsonData);
        let contact = JSON.parse(obj.Contact);
        let title = "Callback for " + contact.Name + " number " + contact.PhoneNumber + ".";
        let jsonData = JSON.parse(event.JsonData);
        let fromAddr = jsonData.FromAddr;
        //for voice bio callback project use kendo window notification instead of UIKit modal
        if (isVoiceBio) {
            let dacTemplate = GetHtmlFromTemplate("dac_notification_template", "", { callId: fromAddr });
            $('body').append(dacTemplate);
            $("#dac_notification_dialog_" + fromAddr).kendoWindow({
                modal: false,
                title: title,
                width: "525px",
                height: "auto",
                visible: false,
                resizable: false,
                close: function (e) {
                    RejectCallack(fromAddr);
                    e.sender.destroy();
                }
            }).data("kendoWindow").open().center();
        }
        else {
            UIkit.modal.confirm(title,
                function () {
                    AcceptCallack(fromAddr);
                },
                function oncancel() {
                    RejectCallack(fromAddr);
                });
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.tmacevent_TCM_DirectAgentNotifyEvent()", ex, false);
    }
}

function DirectAgentNotifyTimeoutEvent(event) {
    try {
        let obj = JSON.parse(event.JsonData);
        let contact = JSON.parse(obj.Contact);
        let msg = "Callback for " + contact.Name + " number " + contact.PhoneNumber + " will be routed to skill.";
        log.LogDetails("Warning", "CampUI.DirectAgentNotifyTimeoutEvent", msg, true);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.tmacevent_TCM_DirectAgentNotifyTimeoutEvent()", ex, false);
    }
}

function camp_setCallerData(intid, phone, recordid, intent) {
    try {
        //intent
        // try {
        // let intentEvent = {};
        // intentEvent.InteractionID = intid;
        // intentEvent.IntentName = intent;
        // intentEvent.IntentStatus = 'Close';
        // tmacevent_CallerIntentEvent(intentEvent);
        // } catch (e) {
        // }

        ChangeStatus(global_DeviceID, "acw", 0);
        $("#hf_voice_phone" + intid).val(phone);
        $("#hf_voice_source" + intid).val('tcamp');
        $("#hf_voice_sourceid" + intid).val(recordid);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.camp_setCallerData()", ex, false);
    }
}

function NotifyCampaignType(type, intid) {
    try {
        if (type == "pop") {

        }
        else if (type == "iframe") {
            $("#custom_frame" + intid).removeClass("uk-display-none");
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.NotifyCampaignType()", ex, false);
    }
}

function OnAgentResponseToDacRequest(fromAddr, response, agentID, extension, scheduletime) {
    try {
        let d = {};
        d.fromAddr = fromAddr;
        d.response = response;
        d.agentID = agentID;
        d.extension = extension;
        d.scheduletime = scheduletime;
        CallServer(d, "OnAgentResponseToDacRequest", response);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequest()", ex, false);
    }
}

function CallServer(obj, method, mydata) {
    try {
        $.ajax({
            type: "POST",
            url: campServiceUrl + "/" + method,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(obj),
            success: function (result) {
                window[method + "Done"](result.d, mydata);
            },
            error: function (result) {
                log.LogDetails("Error", "CampUI.CallServer() - AJAX - ", result.responseText, false);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "CampUI.CallServer()", ex, false);
    }
}

// send call status to campaign manager iframe
function SendCallStatusToCamp(intid, type) {
    try {
        var campIframeWindow = document.getElementById("ui_custom_frame" + intid).contentWindow;
        campChildframeWindow = campIframeWindow.document.getElementById("campaign_iframe").contentWindow;
        campChildframeWindow.SendCallStatusToSurvey(type);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.SendCallStatusToSurvey()", ex, false);
    }

}

//calls campaign method and validates true or false
function IsCloseTabAllowedFromCampaign(intid) {
    try {
        var frameId = "ui_custom_frame" + intid;
        var campaignSelectorWindow = document.getElementById(frameId).contentWindow;
        var tmacCampaignWindow = campaignSelectorWindow.campaignChildWindow;
        var result = tmacCampaignWindow.ValidateRecordSubmission();
        if (!result.isRecordSubmitted) {
            log.LogDetails("Error", "CampUI.IsCloseTabAllowedFromCampaign()", result.message, true);
            return false;
        }
        return true;
    }
    catch (ex) {
        log.LogDetails("Error", "CampUI.IsCloseTab()", ex, false);
        return true;
    }
}

// Call campaign on force logout
function CampaignOnForceLogout() {
    try {
        $.each(global_InteractionTabs, function (i, val) {
            var intid = val.intid;
            // is the intid numeric
            if (!isNaN(intid)) {
                try {
                    // get campaign selector window
                    var campIframeWindow = document.getElementById("ui_custom_frame" + intid).contentWindow;
                    // get campaign window
                    campChildframeWindow = campIframeWindow.document.getElementById("campaign_iframe").contentWindow;
                    campChildframeWindow.OnClose();
                } catch (ex) {
                    //
                }
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "CampUI.CampaignOnForceLogout()", ex, false);
    }
}

//create WQ voice campaign tab
function TCMVoiceWQInteraction(event) {
    try {
        let intId = event.InteractionID;
        let item = event.Item;
        let phoneNumber = item.PhoneNumber;
        //save the tab reference
        SaveTabReference(item.Type, intId, "new");
        //for singtel callback project we just need to load custom tab
        if (isVoiceBio) {
            var id = item.PhoneNumber;
            //tab header content
            var tempTabHeaderContent = GetHtmlFromTemplate("tab_header_template", intId, { icon: "callback" });
            //tab body content
            var tempTabContent = GetHtmlFromTemplate("iframe_template", intId, null);
            //add a kendo tab
            AddTab(tempTabContent, tempTabHeaderContent, intId, phoneNumber, true, true, false);
        }
        else {
            //create a new voice tab
            AddVoiceTab(intId, phoneNumber, false, false, null);
            //remove active for call tab
            $("#li_" + intId).removeClass("li-on-call");
            SetCallControlStatus(intId, false, false, false, false, false, false, true, false);
            //assign dynamic values
            AssignDynamicValues(event, "TCMVOICEWQ", "TCMVoiceWQInteraction");
            //Initialize the UIKit accordion for the created tab
            let accordion = UIkit.accordion($('#voice_accordion' + intId), {
                collapse: false,
                showfirst: false
            }),
                wrapper1 = accordion.find('[data-wrapper]').get(0), //0 as index of the content
                wrapper2 = accordion.find('[data-wrapper]').get(3); //1 as index of the content
            accordion.toggleItem(UIkit.$(wrapper1), true, false); // animated true and collapse true
            accordion.toggleItem(UIkit.$(wrapper2), true, false); // animated true and collapse true
        }
        //open voice data window
        let campObj = {
            SubType: "camp",
            SubTypeData: item.PhoneNumber,
            UCID: "",
            Queue: item.Skill,
            InteractionID: intId,
            ID: item.ID
        };
        //to open tmac campaign selector iframe
        OpenVoiceDataWindow(campObj, isVoiceBio ? intId + "_iframe" : null);

        //  VP: Oct 3, '19: Show pop-up to agent if dial out can happen now
        UIkit.modal.alert("Dial out to customer?").on('hide.uk.modal', function () {
            tmac_InitiateCall("InitiateCallDone", null, global_DeviceID, phoneNumber, "", "t", "Y", "");
        });

        //we have to invoke campaign selector
        //NotifyCallbackAssigned();
    } catch (ex) {
        log.LogDetails("Error", "CampUI.TCMVoiceWQInteraction()", ex, false);
    }
}