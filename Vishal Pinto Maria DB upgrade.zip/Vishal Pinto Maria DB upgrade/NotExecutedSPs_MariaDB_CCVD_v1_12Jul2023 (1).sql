
-- Dumping structure for procedure OCM.Get_OCM_AgentAuxReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentAuxReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
	
	IF(p_Type = 'MAIN')
	THEN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
				SELECT AgentID,AgentName,AuxName,AuxCode,TIMESTAMPDIFF(second,VARCHARTODATETIME(SecondDateTime), VARCHARTODATETIME(FirstDateTime)) AuxTime,`TimeStamp`
				FROM (
				SELECT  T.AgentID,T.LoginInstanceID,IFNULL(A.UserName,' ')  AS AgentName,
				T.Status AS AuxName,
				ifnull(convert(C.Value, char),' ') AS AuxCode,
						LEAD(`TimeStamp`,1,0) OVER(PARTITION  BY T.AgentID  ORDER BY T.TimeStamp,T.ID asc) FirstDateTime,`TimeStamp` SecondDateTime,`TimeStamp`
						FROM  AGT_Agent_TimeTrack M 
						LEFT JOIN `AGT_Agent_StatusTrack` T   ON M.AgentID = T.AgentID AND M.LoginInstanceID =  T.LoginInstanceID 
						LEFT JOIN AGT_AUX_Codes C ON C.Name =T.Status 
						LEFT JOIN `AGT_Agent` A ON A.AvayaLoginID = T.AgentID 
						WHERE concat(M.LogoutDate,LogoutTime)>=v_DataFromDate AND concat(LogoutDate,LogoutTime)<=v_DataToDate
				 ) q WHERE  FirstDateTime<>0 AND AgentID IS NOT NULL;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		END IF;
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AgentStateSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentStateSummaryReport`(
 p_FromDate VARCHAR(20),
 p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	DROP TEMPORARY TABLE IF EXISTS AgentStatTable;
	CREATE TEMPORARY TABLE AgentStatTable (AgentID LONGTEXT, AgentState LONGTEXT, TimeSpent INT);
	
		INSERT AgentStatTable 
		SELECT AgentID,
		Status,
		sum(TimeSpent) TimeSpent
		FROM 
		(
			SELECT AgentID,
				TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(`TimeStamp`),
				VARCHARTODATETIME(CASE WHEN (MIN(nextTime) is null or MIN(nextTime)>v_DataToDate ) THEN v_DataToDate ELSE MIN(nextTime) END)) AS TimeSpent,
				CASE WHEN (`StatusType` like 'AUX' and `Status` not like '%- On Call') THEN 'AUX' 
				ELSE CASE WHEN (`StatusType` like 'ACW' and `Status` not like '%- On Call') THEN 'ACW' ELSE  `Status` END END AS Status 
				FROM(
						SELECT AgentID,`TimeStamp`,`Status`,StatusType,
						lead(`TimeStamp`,1,v_DataToDate) over (partition by AgentID order by ID asc) as nextTime,
						lead(`Status`,1,0) over (partition by AgentID order by ID asc) as preStatus
						FROM AGT_Agent_StatusTrack
						WHERE `TimeStamp`>=v_DataFromDate and `TimeStamp`<=v_DataToDate and `Status`!='Login' 
				) A   GROUP BY  AgentID,`Status`,`StatusType`,`TimeStamp`,nextTime
			union all
			Select PreviousStatus.AgentID,
			TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(v_DataFromDate),
				VARCHARTODATETIME(CASE WHEN (CurrentStatus.TimeStamp is null or CurrentStatus.TimeStamp>=v_DataToDate) THEN v_DataToDate ELSE CurrentStatus.TimeStamp END)) AS TimeSpent,
			CASE WHEN (`StatusType` like 'AUX' and `Status` not like '%- On Call') THEN 'AUX' 
			ELSE CASE WHEN (`StatusType` like 'ACW' and `Status` not like '%- On Call') THEN 'ACW' ELSE  `Status` END END AS Status 
			FROM
			(	
				SELECT AgentID,`TimeStamp`,`Status` ,StatusType
				FROM
				(
					SELECT AgentID,
						   `TimeStamp`,
						   `Status` ,
						   StatusType,
				           ROW_NUMBER() OVER (PARTITION BY AgentID ORDER BY ID DESC) AS RowNumber
				    FROM AGT_Agent_StatusTrack  
					WHERE  `TimeStamp` <=v_DataFromDate and `Status`!='Login' 
					GROUP BY ID,AgentID,`TimeStamp`,`Status` ,StatusType
				)AgentsPreviousStatus 
				WHERE RowNumber=1
				) PreviousStatus 
				Left join
				(
				SELECT AgentID,TimeStamp 
				FROM
				(
					SELECT AgentID,
						   TimeStamp ,
						   ROW_NUMBER() OVER (PARTITION BY AgentID ORDER BY TimeStamp ASC) AS RowNumber
					FROM  `AGT_Agent_StatusTrack`  
					WHERE `TimeStamp` >=v_DataFromDate and `Status`!='Login' 
					GROUP BY AgentID,`TimeStamp`,`Status` , StatusType
				 ) AgentsNextStatus
				WHERE RowNumber=1
				)CurrentStatus 
				on PreviousStatus.AgentID=CurrentStatus.AgentID
		) M GROUP BY  AgentID,Status;

	DROP TEMPORARY TABLE IF EXISTS AgentStatTableTemp1;
	CREATE TEMPORARY TABLE AgentStatTableTemp1 (AgentID LONGTEXT, AgentState LONGTEXT, TimeSpent INT);
	INSERT INTO AgentStatTableTemp1 SELECT * FROM AgentStatTable;
	
	DROP TEMPORARY TABLE IF EXISTS AgentStatTableTemp2;
	CREATE TEMPORARY TABLE AgentStatTableTemp2 (AgentID LONGTEXT, AgentState LONGTEXT, TimeSpent INT);
	INSERT INTO AgentStatTableTemp2 SELECT * FROM AgentStatTable;

	SELECT TAB2.AgentID,
	TAB2.StationID as Extension,
	IFNULL(SUM(TAB2.TotalLoggedIn),0) TotalLoggedInTime,
	IFNULL(SUM(TAB1.TotalInteraction),0) TotalInteractions,
	IFNULL((SELECT IFNULL(SUM(TimeSpent),0) FROM AgentStatTableTemp1 WHERE (AgentState = 'AUX' OR AgentState = 'ACW') AND AgentID = TAB2.AgentID),0) AS TotalNotReadyTime,
	IFNULL((SELECT IFNULL(TimeSpent,0) FROM AgentStatTableTemp2 WHERE AgentState  = 'Available' and AgentID = TAB2.AgentID LIMIT 1),0) AS TotalReadyTime,
	IFNULL(SUM(TAB1.TalkTime),0) TotalTalkTime,
	IFNULL(SUM(TAB1.AfterCallWorkTime),0) TotalAfterCallWorkTime 
	FROM 
	(
		SELECT AgentId,
			    CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN  1 ELSE 0 END AS TotalInteraction,
			    CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN ActiveTime ELSE 0 END AS TalkTime,
			    CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN AcwTime ELSE 0 END AS AfterCallWorkTime
		FROM TMAC_Interactions 
	) TAB1
	RIGHT OUTER JOIN 
	(
		SELECT  
		AgentID,
		StationID,
		SUM(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(IntervalStartTime),VARCHARTODATETIME(IntervalEndTime))) 
		AS TotalLoggedIn
		FROM (
				SELECT DISTINCT Timetrack.AgentID,StationID,
				CASE WHEN LoginDateTime >= v_DataFromDate  and LoginDateTime <= v_DataToDate THEN LoginDateTime ELSE v_DataFromDate END AS IntervalStartTime,
				CASE WHEN IFNULL(LogoutDateTime,'')='' or LogoutDateTime >= v_DataToDate THEN v_DataToDate ELSE LogoutDateTime END AS IntervalEndTime
				FROM
				(
					SELECT concat(LoginDate,LoginTime) as LoginDateTime,
						concat(LogoutDate,LogoutTime) as LogoutDateTime,
						AgentID,
						StationID,
						ROW_NUMBER() OVER (PARTITION BY AgentID ORDER BY ID desc) AS RowNumber
					FROM AGT_Agent_TimeTrack 
				) Timetrack 
				WHERE (LogoutDateTime > v_DataFromDate or (LogoutDateTime  = '' and RowNumber=1)) and LoginDateTime <= v_DataToDate
			) iq
		GROUP BY iq.AgentID,StationID
	) TAB2
	on TAB1.AgentId=TAB2.AgentID
	GROUP by TAB2.AgentID, TAB2.StationID;
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AgentLoginLogoutReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentLoginLogoutReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate = REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
    	SELECT DISTINCT I.ID AS Id,I.AgentID AS AgentId,A.UserName AS AgentName,I.StationID AS StationId,concat(I.LoginDate,I.LoginTime) AS LoginDateTime,
		concat(I.LogoutDate,I.LogoutTime) AS LogoutDateTime,I.SkillList,Skills.SkillList as SkillNameList,LogoutReason,LogoutReasonCode 
		FROM AGT_Agent_TimeTrack I 
		LEFT JOIN AGT_Agent A ON A.AvayaLoginID=I.AgentID
		LEFT JOIN TMAC_Interactions T ON T.AgentId=I.AgentID 
		CROSS JOIN LATERAL 
		(SELECT GetSkillNameListFromSkillIDList(I.SkillList) SkillList
		) AS Skills
		WHERE A.UserName != 'NULL' AND  concat(LogoutDate,LogoutTime)>=v_DataFromDate AND concat(LogoutDate,LogoutTime)<=v_DataToDate;
	END IF;
END;
END//
DELIMITER ;



-- Dumping structure for procedure OCM.Get_OCM_AgentSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentSummaryReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
    	Select TAB2.AgentID as AgentID,Concat(Ifnull(FirstName,''),' ',ifnull(LastName,'')) AgentName,TAB2.StationID,TAB2.LoginDateTime as LoginDateTime,TAB2.LogoutDateTime as LogoutDateTime,
		TAB2.SkillList, Ifnull(TAB2.TotalStaffedTime,0) as TotalStaffedTime,Skills.SkillLists AS SkillNameList, 
		Ifnull(SUM(TotalACWTime),0) TotalACWTime, Ifnull(ifnull(TAB2.TotalStaffedTime,0) - (ifnull(SUM(TotalInteractionTime),0) + ifnull(SUM(TotalACWTime),0)),0) TotalAuxTime,
		Ifnull(SUM(TotalInteraction),0) TotalInteraction,Ifnull(SUM(TotalInteractionTime)+SUM(TotalInteractionHoldTime),0) TotalInteractionTime,
		Ifnull(SUM(TotalVoice),0) TotalVoice,Ifnull(SUM(TotalVoiceTime)+SUM(TotalVoiceHoldTime),0) TotalVoiceTime,
		Ifnull(SUM(TotalEmail),0) TotalEmail,Ifnull(SUM(TotalEmailTime)+SUM(TotalEmailHoldTime),0) TotalEmailTime,
		Ifnull(SUM(TotalChat),0)TotalChat,Ifnull(SUM(TotalChatTime)+SUM(TotalChatHoldTime),0) TotalChatTime,
		Ifnull(SUM(TotalSMS),0)TotalSMS,Ifnull(SUM(TotalSMSTime)+SUM(TotalSMSHoldTime),0) TotalSMSTime,
		Ifnull(SUM(TotalFax),0)TotalFax,Ifnull(SUM(TotalFaxTime)+SUM(TotalFaxHoldTime),0) TotalFaxTime,
		Ifnull(SUM(TotalSM),0)TotalSM,Ifnull(SUM(TotalSMTime)+SUM(TotalSMHoldTime),0) TotalSMTime,
		Ifnull(SUM(TotalAudioIP),0)TotalAudioIP,Ifnull(SUM(TotalAudioIPTime)+SUM(TotalAudioIPHoldTime),0) TotalAudioIPTime,
		Ifnull(SUM(TotalVideoIP),0)TotalVideoIP,Ifnull(SUM(TotalVideoIPTime)+SUM(TotalVideoIPHoldTime),0) TotalVideoIPTime,
		Ifnull(SUM(TotalExtIn),0)TotalExtIn,
		Ifnull(SUM(TotalExtOut),0)TotalExtOut,Ifnull(SUM(TotalTranIn),0)TotalTransferIn,Ifnull(SUM(TotalTranOut),0) TotalTransferOut,
		Ifnull(SUM(TotalConfIn),0)TotalConferenceIn,Ifnull(SUM(TotalConfOut),0)TotalConferenceOut FROM (
		Select TMAC_Interactions.AgentId, ClosedDateTime,
	  CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN  1 ELSE 0 END AS TotalInteraction,
	  CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN  ActiveTime ELSE 0 END AS TotalInteractionTime,
	  CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN  HoldTime ELSE 0 END AS TotalInteractionHoldTime,
	  CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX')  THEN AcwTime ELSE 0 END AS TotalACWTime,

	  CASE WHEN (Channel='Voice' AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalVoice,
	  CASE WHEN (Channel='Email' AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalEmail,
	 CASE WHEN (Channel IN ('Chat','TextChat') AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalChat,
	 CASE WHEN (Channel='SMS' AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalSMS,
	 CASE WHEN (Channel='FAX' AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalFax,
	  CASE WHEN (Channel IN ('FBPost','FBPrivate') AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalSM,
	 CASE WHEN ((SubChannel='Audio' OR Channel='AudioChat') AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalAudioIP,
	 CASE WHEN ((SubChannel='Video' OR Channel='VideoChat') AND IsTransfered<>1 AND IsConferenced<>1) THEN 1 ELSE 0 END AS TotalVideoIP,

	 CASE WHEN Channel='Voice' THEN ActiveTime ELSE 0 END AS TotalVoiceTime,
	  CASE WHEN Channel='Email' THEN ActiveTime ELSE 0 END AS TotalEmailTime,
	  CASE WHEN Channel IN ('Chat','TextChat') THEN ActiveTime ELSE 0 END AS TotalChatTime,
	  CASE WHEN Channel='SMS' THEN ActiveTime ELSE 0 END AS TotalSMSTime,
	  CASE WHEN Channel='FAX' THEN ActiveTime ELSE 0 END AS TotalFaxTime,
	  CASE WHEN Channel IN ('FBPost','FBPrivate') THEN ActiveTime ELSE 0 END AS TotalSMTime,
	  CASE WHEN (SubChannel='Audio' OR Channel='AudioChat') THEN ActiveTime ELSE 0 END AS TotalAudioIPTime,
	  CASE WHEN (SubChannel='Video' OR Channel='VideoChat') THEN ActiveTime ELSE 0 END AS TotalVideoIPTime,

	  CASE WHEN Channel='Voice' THEN HoldTime ELSE 0 END AS TotalVoiceHoldTime,
	  CASE WHEN Channel='Email' THEN HoldTime ELSE 0 END AS TotalEmailHoldTime,
	  CASE WHEN Channel IN ('Chat','TextChat') THEN HoldTime ELSE 0 END AS TotalChatHoldTime,
	  CASE WHEN Channel='SMS' THEN HoldTime ELSE 0 END AS TotalSMSHoldTime,
	  CASE WHEN Channel='FAX' THEN HoldTime ELSE 0 END AS TotalFaxHoldTime,
	  CASE WHEN Channel IN ('FBPost','FBPrivate') THEN HoldTime ELSE 0 END AS TotalSMHoldTime,
	  CASE WHEN (SubChannel='Audio' OR Channel='AudioChat') THEN HoldTime ELSE 0 END AS TotalAudioIPHoldTime,
	  CASE WHEN (SubChannel='Video' OR Channel='VideoChat') THEN HoldTime ELSE 0 END AS TotalVideoIPHoldTime,

	  CASE WHEN (CALLTYPE='2' AND Direction='In' AND Channel='Voice') THEN 1 ELSE 0 END AS TotalExtIn,
	  CASE WHEN (CALLTYPE='2' AND Direction='Out' AND Channel='Voice') THEN 1 ELSE 0 END AS TotalExtOut,
	  CASE WHEN IsTransfered='1' THEN 1 ELSE 0 END AS TotalTranIn,
	  CASE WHEN IsTranferedTo='1' THEN 1 ELSE 0 END AS TotalTranOut,
	  CASE WHEN IsConferenced='1' THEN 1 ELSE 0 END AS TotalConfIn,
	  CASE WHEN IsConferencedTo='1' THEN 1 ELSE 0 END AS TotalConfOut,LoginInstanceID 
		From TMAC_Interactions 
		) AS TAB1 
		RIGHT JOIN
		(SELECT  AgentID,LoginDateTime,LogoutDateTime,A.LoginInstanceID,
		SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(LoginDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
		CONVERT(INSERT(INSERT(INSERT(LogoutDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) AS TotalStaffedTime,StationID,SkillList
		FROM (SELECT DISTINCT AgentID,concat(LoginDate,LoginTime) AS LoginDateTime ,concat(LogoutDate,LogoutTime) AS LogoutDateTime,LoginInstanceID,StationID,SkillList
		FROM AGT_Agent_TimeTrack A WHERE concat(LogoutDate,LogoutTime)>=v_DataFromDate AND concat(LogoutDate,LogoutTime)<=v_DataToDate 
		)A Group by AgentID,StationID,SkillList,LoginDateTime,LogoutDateTime,LoginInstanceID) AS TAB2 
		ON TAB2.AgentID=TAB1.AgentId AND TAB2.LoginInstanceID = TAB1.LoginInstanceID AND TAB1.ClosedDateTime between LoginDateTime AND LogoutDateTime 
		INNER JOIN AGT_Agent A ON A.AvayaLoginID = TAB2.AgentID
		CROSS JOIN LATERAL 
		(SELECT GetSkillNameListFromSkillIDList(TAB2.SkillList) SkillLists
		) AS Skills
		Group by TAB2.AgentID,FirstName,LastName,TAB2.StationID,TAB2.LoginDateTime,TAB2.LogoutDateTime,TAB2.SkillList,TAB2.TotalStaffedTime,Skills.SkillLists ORDER BY LoginDateTime ASC;
	END IF;
	
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AnalysisCount_Report
DELIMITER //
CREATE PROCEDURE `Get_OCM_AnalysisCount_Report`(
   p_Type VARCHAR(50),
	p_StartDate VARCHAR(50),
	p_EndDate VARCHAR(50)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = REPLACE(p_StartDate,' ','');
	SET v_DataToDate =REPLACE( p_EndDate,' ','');
	
  IF p_Type='MAIN'
   THEN
     SELECT MAX(TabAccessCount.IMD_MENU_NAME) as Menu, 
			TabAccessCount.SUM_II AS InvalidInput,
			TabAccessCount.SUM_NI AS NoInput,
			 '' as Language,
			IFNULL(TabAccessCount.Cnt,0) AS AccessCount, 
			TabAccessCount.Max_Tries AS MaxTries,
			IFNULL(TabAgentTranfer.Cnt,0) as AgentTransfers,
			IFNULL(TabIVRDisconnect.Cnt,0) as IvrDisconnects,
			TabAccessCount.EndDateTime,
			TabAccessCount.CallerID,
			TabAccessCount.MenuID,
			TabAccessCount.MenuOrder
	FROM  (
			SELECT distinct IVR_MENU_DESC.IMD_MENU_NAME,SUM(CAST(IVR_Usage.IU_EII AS UNSIGNED)) as SUM_II , SUM(CAST(IVR_Usage.IU_ENI AS UNSIGNED)) AS SUM_NI,
			SUM(CAST(IVR_Usage.IU_EMC AS UNSIGNED)) AS Max_Tries, COUNT(1) AS Cnt,
			concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) as EndDateTime,
			IVR_Usage.ICH_CALLREFID as CallerID,IVR_MENU_DESC.IMD_MENU_ID as MenuID,IVR_Usage.IU_ORDER as MenuOrder
			FROM IVR_Usage 
			INNER JOIN IVR_MENU_DESC ON IVR_Usage.IU_ID = IVR_MENU_DESC.IMD_MENU_ID
			inner JOIN IVR_Call_History ON IVR_Usage.ICH_CALLREFID=IVR_Call_History.ICH_CALLREFID
			WHERE concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) >= v_DataFromDate and concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) <= v_DataToDate
			GROUP BY IVR_Usage.ICH_CALLREFID,ICH_END_TIME,ICH_END_DATE,IVR_MENU_DESC.IMD_MENU_NAME,IVR_MENU_DESC.IMD_MENU_ID,IVR_Usage.IU_ORDER

	) as TabAccessCount
	LEFT JOIN (	
    SELECT IVR_MENU_DESC.IMD_MENU_NAME, COUNT(1) AS Cnt ,IVR_Call_History.ICH_CALLREFID
    FROM IVR_Call_History  
	INNER JOIN IVR_MENU_DESC ON IVR_Call_History.IU_LAST_MENU_ID = IVR_MENU_DESC.IMD_MENU_NAME
    WHERE concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) >= v_DataFromDate and concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) <= v_DataToDate AND 
	(IVR_Call_History.ICH_TR_DIS_FLAG = 'AT' OR IVR_Call_History.ICH_TR_DIS_FLAG = 'AF') 
    GROUP BY IVR_Call_History.ICH_CALLREFID,IVR_MENU_DESC.IMD_MENU_NAME

	) as TabAgentTranfer on TabAgentTranfer.IMD_MENU_NAME = TabAccessCount.IMD_MENU_NAME and TabAgentTranfer.ICH_CALLREFID = TabAccessCount.CallerID
	LEFT JOIN (
       SELECT IVR_MENU_DESC.IMD_MENU_NAME , COUNT(1) AS Cnt ,IVR_Call_History.ICH_CALLREFID,IVRUsage.IU_ORDER as MenuOrder
       FROM IVR_Call_History  
	   INNER JOIN IVR_MENU_DESC ON IVR_Call_History.IU_LAST_MENU_ID = IVR_MENU_DESC.IMD_MENU_NAME
	   CROSS JOIN LATERAL (select IU_ORDER from IVR_Usage where IVR_Usage.IU_ID = IVR_MENU_DESC.IMD_MENU_ID and 
	   IVR_Usage.ICH_CALLREFID=IVR_Call_History.ICH_CALLREFID order by IU_ORDER DESC LIMIT 1) IVRUsage
       WHERE 
	   concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) >= v_DataFromDate and concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) <= v_DataToDate AND 
	   (IVR_Call_History.ICH_TR_DIS_FLAG = 'DC') 
       GROUP BY IVR_Call_History.ICH_CALLREFID,IVR_MENU_DESC.IMD_MENU_NAME,IVRUsage.IU_ORDER
	) as TabIVRDisconnect on TabIVRDisconnect.IMD_MENU_NAME = TabAccessCount.IMD_MENU_NAME and TabIVRDisconnect.ICH_CALLREFID = TabAccessCount.CallerID
	and TabIVRDisconnect.MenuOrder=TabAccessCount.MenuOrder
	GROUP BY TabAccessCount.EndDateTime, TabAccessCount.IMD_MENU_NAME,TabAccessCount.SUM_II,TabAccessCount.SUM_NI,TabAccessCount.Max_Tries,TabAccessCount.Cnt,TabAgentTranfer.Cnt,TabIVRDisconnect.Cnt
	,TabAccessCount.CallerID,TabAccessCount.MenuID,TabAccessCount.MenuOrder;

	END IF;
 END;
END//
DELIMITER ;

