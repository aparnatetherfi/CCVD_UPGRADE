-- --------------------------------------------------------
-- Host:                         35.240.205.168
-- Server version:               8.0.21 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for OCM
CREATE DATABASE IF NOT EXISTS `NEW_OCM` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `NEW_OCM`;

-- Dumping structure for table OCM.AGENT_DETAILS
CREATE TABLE IF NOT EXISTS `AGENT_DETAILS` (
  `AGENT_ID` varchar(20) DEFAULT NULL,
  `AGENT_NAME` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_AbandonACD_Calls
CREATE TABLE IF NOT EXISTS `AGT_AbandonACD_Calls` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `CallRoutedCSQ` varchar(50) DEFAULT NULL,
  `CallSkill` varchar(10) DEFAULT NULL,
  `AbandonDateTime` varchar(14) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_AgentFeature
CREATE TABLE IF NOT EXISTS `AGT_AgentFeature` (
  `AgentID` varchar(50) NOT NULL,
  `Feature` varchar(50) NOT NULL,
  `Enable` bit(1) NOT NULL DEFAULT b'0',
  `FeatureValue` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`AgentID`,`Feature`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Agent_InteractionTemplates
CREATE TABLE IF NOT EXISTS `AGT_Agent_InteractionTemplates` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AgentId` varchar(50) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Data` varchar(500) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `CreatedDate` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`AgentId`,`Name`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Agent_Profile_Picture
CREATE TABLE IF NOT EXISTS `AGT_Agent_Profile_Picture` (
  `PicID` varchar(25) NOT NULL,
  `AgentID` varchar(20) NOT NULL,
  `ProfilePicture` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`AgentID`,`PicID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Agent_Rating
CREATE TABLE IF NOT EXISTS `AGT_Agent_Rating` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CIF` varchar(50) DEFAULT NULL,
  `SessionId` varchar(50) DEFAULT NULL,
  `Date` varchar(8) DEFAULT NULL,
  `Time` varchar(6) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `Rating` varchar(50) DEFAULT NULL,
  `RatingType` varchar(50) DEFAULT NULL,
  `OtherData` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.agt_agent_reminders_history
CREATE TABLE IF NOT EXISTS `agt_agent_reminders_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `createddatetime` datetime(3) NOT NULL,
  `createdby` varchar(50) NOT NULL,
  `reminderto` varchar(50) NOT NULL,
  `reminderdatetime` datetime(3) NOT NULL,
  `reminderstatus` varchar(50) NOT NULL,
  `remindermessage` varchar(1000) DEFAULT NULL,
  `remindertype` varchar(20) DEFAULT NULL,
  `updateddatetime` datetime(3) DEFAULT NULL,
  `updatedby` varchar(50) DEFAULT NULL,
  `inserteddatetime` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_agt_agent_reminders_history_creayeddatetime` (`createddatetime`),
  KEY `IX_agt_agent_reminders_history_reminderto` (`reminderto`),
  KEY `IX_agt_agent_reminders_history_updateddatetime` (`updateddatetime`),
  KEY `IX_N_agt_agent_reminders_history_insertdatetime` (`inserteddatetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Agent_Telesales_Data
CREATE TABLE IF NOT EXISTS `AGT_Agent_Telesales_Data` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ScreenType` varchar(50) DEFAULT NULL,
  `SessionId` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentFirstName` varchar(50) DEFAULT NULL,
  `AgentLastName` varchar(50) DEFAULT NULL,
  `CampaignName` varchar(50) DEFAULT NULL,
  `CampaignID` varchar(50) DEFAULT NULL,
  `ContactID` varchar(50) DEFAULT NULL,
  `CustomerNRIC` varchar(50) DEFAULT NULL,
  `CustomerPhoneNo` varchar(50) DEFAULT NULL,
  `TeamName` varchar(50) DEFAULT NULL,
  `DateTime` datetime(3) DEFAULT NULL,
  `OtherData` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_AMAC_Versions
CREATE TABLE IF NOT EXISTS `AGT_AMAC_Versions` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Version` varchar(50) DEFAULT NULL,
  `DownloadURL` varchar(500) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `ChangedDate` datetime(3) DEFAULT NULL,
  `ChangedBy` varchar(250) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_AppLogin_Attempts
CREATE TABLE IF NOT EXISTS `AGT_AppLogin_Attempts` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UserID` varchar(50) DEFAULT NULL,
  `AppName` varchar(10) DEFAULT NULL,
  `AttemptDateTime` varchar(20) DEFAULT NULL,
  `LoginAttempt` int NOT NULL,
  `IsSuccess` bit(1) DEFAULT b'0',
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `UserHostAddress` varchar(50) DEFAULT NULL,
  `Page` varchar(50) DEFAULT NULL,
  `Reason` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_AppLogin_Track
CREATE TABLE IF NOT EXISTS `AGT_AppLogin_Track` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AppName` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `UserID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `LastLoginDateTime` varchar(20) DEFAULT NULL,
  `LoginAttempts` int DEFAULT NULL,
  `Enabled` bit(1) DEFAULT b'1',
  `Locked` bit(1) DEFAULT b'0',
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `Email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `IsDormant` bit(1) NOT NULL DEFAULT b'0',
  `EmailSentDateTime` datetime(3) DEFAULT NULL,
  `LastLoggedInAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_AGT_AppLogin_Track_UserID_AppName` (`UserID`,`AppName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Apps
CREATE TABLE IF NOT EXISTS `AGT_Apps` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `AppName` varchar(10) NOT NULL,
  `Threshold` int NOT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_ChannelCount
CREATE TABLE IF NOT EXISTS `AGT_ChannelCount` (
  `AgentID` varchar(50) NOT NULL,
  `Channel` varchar(50) NOT NULL,
  `Count` int DEFAULT NULL,
  `BaseInteraction` varchar(50) DEFAULT NULL,
  `Enable` bit(1) DEFAULT NULL,
  PRIMARY KEY (`AgentID`,`Channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Email_Templates
CREATE TABLE IF NOT EXISTS `AGT_Email_Templates` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GroupID` int DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `Subject` varchar(500) DEFAULT NULL,
  `BodyHTML` longtext,
  `Type` varchar(10) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Email_Template_Attachments
CREATE TABLE IF NOT EXISTS `AGT_Email_Template_Attachments` (
  `AttachmentID` int NOT NULL AUTO_INCREMENT,
  `TemplateID` int DEFAULT NULL,
  `FileName` varchar(250) DEFAULT NULL,
  `ChangedBy` varchar(50) DEFAULT NULL,
  `ChangedOn` varchar(50) DEFAULT NULL,
  KEY `AttachmentID` (`AttachmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Email_Template_Departments
CREATE TABLE IF NOT EXISTS `AGT_Email_Template_Departments` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Email_Template_Groups
CREATE TABLE IF NOT EXISTS `AGT_Email_Template_Groups` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DepartmentID` int NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_OpenSessions
CREATE TABLE IF NOT EXISTS `AGT_OpenSessions` (
  `InteractionID` int DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentDevice` varchar(10) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `CIF` varchar(20) DEFAULT NULL,
  `NRIC` varchar(15) DEFAULT NULL,
  `EmailID` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `OpenDate` varchar(8) DEFAULT NULL,
  `OpenTime` varchar(6) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Parked_Contacts
CREATE TABLE IF NOT EXISTS `AGT_Parked_Contacts` (
  `Channel` varchar(10) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `ContactID` varchar(50) DEFAULT NULL,
  `CLID` varchar(100) DEFAULT NULL,
  `ContactList` varchar(250) DEFAULT NULL,
  `UUI` varchar(100) DEFAULT NULL,
  `ParkType` varchar(10) DEFAULT NULL,
  `DraftMessage` longtext,
  `Subject` varchar(250) DEFAULT NULL,
  `ParkDate` varchar(8) DEFAULT NULL,
  `ParkTime` varchar(6) DEFAULT NULL,
  `Intent` varchar(100) DEFAULT NULL,
  `SessionID` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.agt_slots
CREATE TABLE IF NOT EXISTS `agt_slots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `orgunit` int DEFAULT NULL,
  `slotgroup` varchar(50) DEFAULT NULL,
  `slottype` varchar(50) DEFAULT NULL,
  `slotdescription` varchar(300) DEFAULT NULL,
  `startofweek` date DEFAULT NULL,
  `endofweek` date DEFAULT NULL,
  `fromtime` time NOT NULL,
  `totime` time NOT NULL,
  `monday` int NOT NULL DEFAULT '0',
  `tuesday` int NOT NULL DEFAULT '0',
  `wednesday` int NOT NULL DEFAULT '0',
  `thursday` int NOT NULL DEFAULT '0',
  `friday` int NOT NULL DEFAULT '0',
  `saturday` int NOT NULL DEFAULT '0',
  `sunday` int NOT NULL DEFAULT '0',
  `lastchangedon` datetime(3) DEFAULT NULL,
  `lastchangedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_N_agt_slots_startofweek_endofweek` (`startofweek`,`endofweek`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_SMS_Alert
CREATE TABLE IF NOT EXISTS `AGT_SMS_Alert` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Number` int DEFAULT NULL,
  `OtherData` varchar(4000) DEFAULT NULL,
  `TemplateId` int DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `Comments` varchar(250) DEFAULT NULL,
  `SentMessage` varchar(4000) DEFAULT NULL,
  `SentTime` varchar(50) DEFAULT NULL,
  `SentStatus` varchar(50) DEFAULT NULL,
  `RecievedMessage` varchar(4000) DEFAULT NULL,
  `RecievedTime` varchar(50) DEFAULT NULL,
  `RecievedStatus` varchar(50) DEFAULT NULL,
  `Last_Changed_By` varchar(50) DEFAULT NULL,
  `Last_Changed_On` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_SMS_Template_Groups
CREATE TABLE IF NOT EXISTS `AGT_SMS_Template_Groups` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DepartmentID` int NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_Text_Transfered_Calls
CREATE TABLE IF NOT EXISTS `AGT_Text_Transfered_Calls` (
  `SessionID` varchar(50) DEFAULT NULL,
  `CLID` varchar(16) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CIF` varchar(19) DEFAULT NULL,
  `NRIC` varchar(10) DEFAULT NULL,
  `Segment` varchar(1) DEFAULT NULL,
  `EmailID` varchar(100) DEFAULT NULL,
  `RegisteredPhone` varchar(16) DEFAULT NULL,
  `InsertDate` varchar(8) DEFAULT NULL,
  `InsertTime` varchar(6) DEFAULT NULL,
  `Channel` varchar(10) DEFAULT NULL,
  `Status` varchar(50) DEFAULT 'Queue',
  `Intent` varchar(100) DEFAULT NULL,
  `Skill` varchar(10) DEFAULT NULL,
  `InteractionText` varchar(500) DEFAULT NULL,
  `QueueType` varchar(50) DEFAULT NULL,
  `IsTransfer` int DEFAULT NULL,
  `AdditionalContact` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.AGT_WallBoard_Templates
CREATE TABLE IF NOT EXISTS `AGT_WallBoard_Templates` (
  `ID` int NOT NULL,
  `Queue1` varchar(10) DEFAULT NULL,
  `Queue2` varchar(10) DEFAULT NULL,
  `Queue3` varchar(10) DEFAULT NULL,
  `Queue4` varchar(10) DEFAULT NULL,
  `Queue5` varchar(10) DEFAULT NULL,
  `CIQ_TS1` int DEFAULT NULL,
  `CIQ_TS2` int DEFAULT NULL,
  `CIQ_TS3` int DEFAULT NULL,
  `CIQ_TS4` int DEFAULT NULL,
  `CIQ_TS5` int DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `AUXTIME_TS` int DEFAULT NULL,
  `IDLETIME_TS` int DEFAULT NULL,
  `TALKTIME_TS` int DEFAULT NULL,
  `ACWTIME_TS` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.BreakStringIntoRows
DELIMITER //
CREATE FUNCTION `BreakStringIntoRows`(p_CommadelimitedString LONGTEXT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
 	return	replace(quote(Lower(ltrim(rtrim(p_CommadelimitedString)))),',',''',''');
 		
END//
DELIMITER ;

-- Dumping structure for table OCM.BulkUploadKA
CREATE TABLE IF NOT EXISTS `BulkUploadKA` (
  `CIN` varchar(50) DEFAULT NULL,
  `PassportNo` varchar(50) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `ID` int NOT NULL AUTO_INCREMENT,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Campaign
CREATE TABLE IF NOT EXISTS `Campaign` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `ContactType` varchar(50) DEFAULT NULL,
  `MaxConcurrentCalls` varchar(50) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignAgentScreen
CREATE TABLE IF NOT EXISTS `CampaignAgentScreen` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `Url` varchar(100) DEFAULT NULL,
  `ScreenPopType` varchar(50) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignContact
CREATE TABLE IF NOT EXISTS `CampaignContact` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Age` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Gender` varchar(100) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignDndContact
CREATE TABLE IF NOT EXISTS `CampaignDndContact` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `Type` varchar(100) DEFAULT NULL,
  `Contact` varchar(50) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignQueueSkill
CREATE TABLE IF NOT EXISTS `CampaignQueueSkill` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `Skill` varchar(100) DEFAULT NULL,
  `SkillName` varchar(100) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignRecord
CREATE TABLE IF NOT EXISTS `CampaignRecord` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `ContactId` bigint NOT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `DialDateTime` varchar(100) DEFAULT NULL,
  `CompletedDateTime` varchar(100) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignSchedule
CREATE TABLE IF NOT EXISTS `CampaignSchedule` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampId` bigint NOT NULL,
  `StartDateTime` varchar(100) DEFAULT NULL,
  `EndDateTime` varchar(100) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CampaignScheduleDate
CREATE TABLE IF NOT EXISTS `CampaignScheduleDate` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `ScheduleId` bigint NOT NULL,
  `Date` varchar(100) DEFAULT NULL,
  `StartTime` varchar(100) DEFAULT NULL,
  `EndTime` varchar(100) DEFAULT NULL,
  `Last_Changed_ON` varchar(100) DEFAULT NULL,
  `Last_Changed_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Chat_Call_History
CREATE TABLE IF NOT EXISTS `Chat_Call_History` (
  `STARTDATETIME` varchar(20) DEFAULT NULL,
  `ENDDATETIME` varchar(20) DEFAULT NULL,
  `CALL_DUR` varchar(20) DEFAULT NULL,
  `CLID` varchar(30) DEFAULT NULL,
  `DNIS` varchar(30) DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  `TR_DIS_FLAG` varchar(2) DEFAULT NULL,
  `LAST_MENU_ID` varchar(100) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `COMPANY` varchar(50) DEFAULT NULL,
  `CIF` varchar(19) DEFAULT NULL,
  `EMP_NAME` varchar(50) DEFAULT NULL,
  `BB_CUSTOM_INDICATOR` varchar(5) DEFAULT NULL,
  `CUSTOMER_SEGMENT` varchar(50) DEFAULT NULL,
  `CUSTOMER_STATUS` varchar(50) DEFAULT NULL,
  `TPIN_VERIFIED` varchar(10) DEFAULT NULL,
  `OTP_VERFIFIED` varchar(50) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `PHONE_CODE` varchar(20) DEFAULT NULL,
  `LASTMENU_1` varchar(100) DEFAULT NULL,
  `LASTMENU_2` varchar(100) DEFAULT NULL,
  `LASTMENU_3` varchar(100) DEFAULT NULL,
  `LASTMENU_4` varchar(100) DEFAULT NULL,
  `QUEUETIME` varchar(8) DEFAULT NULL,
  `TRANSFER_VDN` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Chat_Details
CREATE TABLE IF NOT EXISTS `Chat_Details` (
  `SessionID` varchar(60) DEFAULT NULL,
  `Ani` varchar(20) DEFAULT NULL,
  `Conversation` varchar(4000) DEFAULT NULL,
  `SentimentScore` varchar(5) DEFAULT NULL,
  `StartTime` varchar(20) DEFAULT NULL,
  `EndTime` varchar(20) DEFAULT NULL,
  `Duration` varchar(10) DEFAULT NULL,
  `Language` varchar(15) DEFAULT NULL,
  `AgentSkill` varchar(10) DEFAULT NULL,
  `SentimentDetail` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Chat_Menu_Desc
CREATE TABLE IF NOT EXISTS `Chat_Menu_Desc` (
  `MENU_ID` varchar(12) NOT NULL,
  `MENU_NAME` varchar(100) NOT NULL,
  `INTENT` varchar(50) NOT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Chat_TRL
CREATE TABLE IF NOT EXISTS `Chat_TRL` (
  `SessionID` varchar(20) DEFAULT NULL,
  `REQUEST_UUID` varchar(40) DEFAULT NULL,
  `TRANSACTION_NAME` varchar(50) DEFAULT NULL,
  `MENU_DESCRIPTION` varchar(100) DEFAULT NULL,
  `CHAT_TRANS_DATE` datetime(3) NOT NULL,
  `REQUEST_DATE` datetime(3) DEFAULT NULL,
  `RESPONSE_DATE` datetime(3) DEFAULT NULL,
  `REQ_MESSAGE` varchar(2000) DEFAULT NULL,
  `RES_MESSAGE` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Chat_Usage
CREATE TABLE IF NOT EXISTS `Chat_Usage` (
  `SessionID` varchar(50) DEFAULT NULL,
  `ID` varchar(100) DEFAULT NULL,
  `EII` varchar(10) DEFAULT NULL,
  `ENI` varchar(10) DEFAULT NULL,
  `EMC` varchar(10) DEFAULT NULL,
  `ORDER` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CMM_Admin_Users
CREATE TABLE IF NOT EXISTS `CMM_Admin_Users` (
  `USER_ID` varchar(50) NOT NULL,
  `ACCESS` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CMM_Report_Scheduler
CREATE TABLE IF NOT EXISTS `CMM_Report_Scheduler` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(250) DEFAULT NULL,
  `Address` varchar(4000) DEFAULT NULL,
  `EndTime` varchar(50) DEFAULT NULL,
  `Frequency` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Report` varchar(4000) DEFAULT NULL,
  `Day` varchar(50) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `ReportTitle` varchar(4000) DEFAULT NULL,
  `StartTime` varchar(20) DEFAULT NULL,
  `OrgUnit` varchar(50) DEFAULT NULL,
  `UserId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.cmm_role_profile
CREATE TABLE IF NOT EXISTS `cmm_role_profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `roleid` int NOT NULL,
  `profile` varchar(1) NOT NULL,
  `orgid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.CMM_VIP_BulkUpload
CREATE TABLE IF NOT EXISTS `CMM_VIP_BulkUpload` (
  `UpdatedDate` varchar(10) DEFAULT NULL,
  `UpdatedTime` varchar(10) DEFAULT NULL,
  `FileName` varchar(25) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Comments` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.content.conversation_media
CREATE TABLE IF NOT EXISTS `content.conversation_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `size` bigint NOT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `conv_id` varchar(255) NOT NULL,
  `file_id` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `organization_id` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.content.links
CREATE TABLE IF NOT EXISTS `content.links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `conv_id` varchar(255) NOT NULL,
  `interaction_id` varchar(255) NOT NULL,
  `uploaded_by` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `organization_id` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.content.media
CREATE TABLE IF NOT EXISTS `content.media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `size` bigint NOT NULL,
  `type` varchar(255) NOT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `conv_id` varchar(255) NOT NULL,
  `interaction_id` varchar(255) NOT NULL,
  `version` int NOT NULL,
  `uploaded_by` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `organization_id` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `interaction_unique_index` (`interaction_id`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.content.usages
CREATE TABLE IF NOT EXISTS `content.usages` (
  `organization_id` varchar(255) NOT NULL,
  `upload_size` bigint DEFAULT NULL,
  `download_size` bigint DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.conversation_media
CREATE TABLE IF NOT EXISTS `conversation_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `original_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `size` bigint NOT NULL,
  `content_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `conv_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `file_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `uploaded_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `active` tinyint NOT NULL,
  `organization_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createdAt` datetime(6) NOT NULL,
  `updatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_AccountConfiguration
CREATE TABLE IF NOT EXISTS `Email_AccountConfiguration` (
  `MailAccountName` varchar(100) DEFAULT NULL,
  `MailAccountID` varchar(5) NOT NULL,
  `IncomingMailServerAddress` varchar(100) DEFAULT NULL,
  `IncomingMailServerPort` int DEFAULT NULL,
  `IncomingMailServerUserName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IncomingMailServerPassword` varchar(250) DEFAULT NULL,
  `IncomingMailUseSSL` int DEFAULT NULL,
  `OutboundMailServerAddress` varchar(100) DEFAULT NULL,
  `OutboundMailServerPort` int DEFAULT NULL,
  `OutboundMailServerUserName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `OutboundMailServerPassword` varchar(250) DEFAULT NULL,
  `OutboundMailUseSSL` int DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `SendEnabled` int DEFAULT NULL,
  `ReceiveEnabled` int DEFAULT NULL,
  `PollTimeSeconds` int DEFAULT NULL,
  `AutoBCCEmailAddressList` varchar(500) DEFAULT NULL,
  `OwnerServerID` int DEFAULT NULL,
  `TeamIDList` varchar(100) DEFAULT NULL,
  `OutlookRoutingEnabled` int DEFAULT NULL,
  `LastReceiveTime` varchar(14) DEFAULT NULL,
  `NextReceivers` varchar(100) DEFAULT NULL,
  `MustReceive` int DEFAULT NULL,
  `RoutePath` varchar(50) DEFAULT NULL,
  `OutboundEmailFromAddress` varchar(50) DEFAULT NULL,
  `NdrReadingEnabled` int DEFAULT NULL,
  `NdrEmailFwdEnabled` int DEFAULT NULL,
  `NdrCcAddressList` longtext,
  `NdrBccAddressList` longtext,
  `NdrFromAddress` varchar(20) DEFAULT NULL,
  `NdrCustomAddressList` longtext,
  `NdrEmailCustomSubject` varchar(50) DEFAULT NULL,
  `NdrEmailCustomBody` longtext,
  `LastChangedBy` varchar(80) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`MailAccountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.email_accountreadlock
CREATE TABLE IF NOT EXISTS `email_accountreadlock` (
  `mailaccountid` varchar(50) DEFAULT NULL,
  `locked` varchar(1) DEFAULT NULL,
  `lockedtime` varchar(14) DEFAULT NULL,
  `lockedby` varchar(50) DEFAULT NULL,
  KEY `FK_email_accountreadlock_mailaccountid` (`mailaccountid`),
  CONSTRAINT `FK_email_accountreadlock_mailaccountid` FOREIGN KEY (`mailaccountid`) REFERENCES `Email_AccountConfiguration` (`MailAccountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.email_account_teamlist
CREATE TABLE IF NOT EXISTS `email_account_teamlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mailaccountid` varchar(5) NOT NULL,
  `teamid` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mailaccountid` (`mailaccountid`),
  CONSTRAINT `email_account_teamlist_ibfk_1` FOREIGN KEY (`mailaccountid`) REFERENCES `Email_AccountConfiguration` (`MailAccountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Actions
CREATE TABLE IF NOT EXISTS `Email_Actions` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Action` varchar(100) DEFAULT NULL,
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Direction` varchar(5) DEFAULT NULL,
  `ActionDate` varchar(8) DEFAULT NULL,
  `ActionTime` varchar(6) DEFAULT NULL,
  `ActionBy` varchar(50) DEFAULT NULL,
  `Info` varchar(250) DEFAULT NULL,
  `RouteId` bigint DEFAULT NULL,
  KEY `IX_Email_Actions_Action_ActionDate_ActionBy` (`Action`,`ActionDate`,`ActionBy`),
  KEY `IX_Email_Actions_ActionDate_ActionTime` (`ActionDate`,`ActionTime`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for view OCM.email_actions_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `email_actions_view` (
	`ID` INT(10) NOT NULL,
	`Action` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Direction` VARCHAR(5) NULL COLLATE 'utf8mb4_general_ci',
	`ActionDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ActionTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`ActionBy` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Info` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`RouteId` BIGINT(19) NULL
) ENGINE=MyISAM;

-- Dumping structure for table OCM.Email_CALLBACK
CREATE TABLE IF NOT EXISTS `Email_CALLBACK` (
  `UCID` varchar(50) DEFAULT NULL,
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `LAST_CIF_IDENTIFIED` varchar(50) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `CC_NUMBER` varchar(20) DEFAULT NULL,
  `VIP_STATUS` varchar(10) DEFAULT NULL,
  `SALUTATION` varchar(10) DEFAULT NULL,
  `NAME` varchar(250) DEFAULT NULL,
  `DOB` varchar(15) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `LAST_IVR_OPTION` varchar(50) DEFAULT NULL,
  `CALLER_ID` varchar(15) DEFAULT NULL,
  `CALLBACK_NUMBER` varchar(15) DEFAULT NULL,
  `REQUESTED_DATETIME` datetime(3) DEFAULT NULL,
  `ASSIGNDATETIME` datetime(3) DEFAULT NULL,
  `DIALDATETIME` datetime(3) DEFAULT NULL,
  `PROCESS_DATETIME` datetime(3) DEFAULT NULL,
  `CALLBACK_DATETIME` datetime(3) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `ASSIGNTO` varchar(250) DEFAULT NULL,
  `REJECT_DATETIME` datetime(3) DEFAULT NULL,
  `CHANNEL` varchar(20) DEFAULT NULL,
  `DIAL_TYPE` varchar(20) DEFAULT NULL,
  `VERIFIED` varchar(20) DEFAULT NULL,
  `CB_VDN` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  KEY `SRNO` (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Conversations
CREATE TABLE IF NOT EXISTS `Email_Conversations` (
  `ConversationID` varchar(16) DEFAULT NULL,
  `OriginalSubject` varchar(1000) DEFAULT NULL,
  `OriginalEmailAddress` varchar(250) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  KEY `IX_Email_Conversations_ConversationID` (`ConversationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_ExclusionList
CREATE TABLE IF NOT EXISTS `Email_ExclusionList` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EmailID` varchar(250) DEFAULT NULL,
  `Description` varchar(250) DEFAULT NULL,
  `ChangedBy` varchar(50) DEFAULT NULL,
  `ChangedOn` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Inbox
CREATE TABLE IF NOT EXISTS `Email_Inbox` (
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `From` varchar(250) DEFAULT NULL,
  `ToList` varchar(4000) DEFAULT NULL,
  `CCList` varchar(4000) DEFAULT NULL,
  `Subject` varchar(520) DEFAULT NULL,
  `Body` longtext,
  `IsHtml` int DEFAULT NULL,
  `Priority` varchar(20) DEFAULT NULL,
  `Pop3MessageID` varchar(500) DEFAULT NULL,
  `SentDate` varchar(8) DEFAULT NULL,
  `SentTime` varchar(6) DEFAULT NULL,
  `ReceivedDate` varchar(8) DEFAULT NULL,
  `ReceivedTime` varchar(6) DEFAULT NULL,
  `ConversationID` varchar(16) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CurrentServicePoint` varchar(50) DEFAULT NULL,
  `Mailbox` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL,
  `CMSkill` varchar(50) DEFAULT NULL,
  `CheckerSkill` varchar(50) DEFAULT NULL,
  `ActiveTime` bigint DEFAULT NULL,
  `HoldTime` bigint DEFAULT NULL,
  `AssignedDate` varchar(8) DEFAULT NULL,
  `AssignedTime` varchar(6) DEFAULT NULL,
  `AssignedTo` varchar(20) DEFAULT NULL,
  `RepliedDate` varchar(8) DEFAULT NULL,
  `RepliedTime` varchar(6) DEFAULT NULL,
  `RepliedBy` varchar(20) DEFAULT NULL,
  `RepliedStatus` int DEFAULT NULL,
  `ClosedDate` varchar(8) DEFAULT NULL,
  `ClosedTime` varchar(6) DEFAULT NULL,
  `ClosedBy` varchar(20) DEFAULT NULL,
  `ClosedReasonCode` int DEFAULT NULL,
  `Deleted` int DEFAULT NULL,
  `DeletedBy` varchar(10) DEFAULT NULL,
  `DeletedOn` varchar(20) DEFAULT NULL,
  `DeletedSource` varchar(50) DEFAULT NULL,
  `IgnoredDateTime` varchar(6) DEFAULT NULL,
  `IgnoredBy` varchar(20) DEFAULT NULL,
  `IgnoredStatus` int DEFAULT NULL,
  `Outlookfoldername` varchar(250) DEFAULT NULL,
  `OverallSentimentScore` float DEFAULT NULL,
  `EmailType` varchar(20) DEFAULT NULL,
  KEY `IX_Email_Inbox_RepliedDate_ClosedDate` (`RepliedDate`,`ClosedDate`,`SessionID`,`ReceivedDate`,`ReceivedTime`,`Mailbox`,`CMSkill`),
  KEY `IX_Email_Inbox_SessionID` (`SessionID`,`Mailbox`),
  KEY `IX_Email_Inbox_Mailbox` (`Mailbox`,`SessionID`),
  KEY `IX_Email_Inbox_CMSkill_RepliedDate_ClosedDate` (`CMSkill`,`RepliedDate`,`ClosedDate`,`SessionID`,`ReceivedDate`,`ReceivedTime`,`Mailbox`),
  KEY `IX_Email_Inbox_CMSkill_CurrentStatus` (`CMSkill`,`CurrentStatus`,`ReceivedDate`,`ReceivedTime`,`Mailbox`,`ClosedDate`),
  KEY `IX_Email_Inbox_CMSkill` (`CMSkill`,`SessionID`,`ReceivedDate`,`ReceivedTime`,`Mailbox`,`RepliedDate`,`ClosedDate`,`AssignedDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Inbox_Attachments
CREATE TABLE IF NOT EXISTS `Email_Inbox_Attachments` (
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `URL` varchar(250) DEFAULT NULL,
  KEY `NonClusteredIndex_SesisonID` (`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Inbox_External
CREATE TABLE IF NOT EXISTS `Email_Inbox_External` (
  `SessionID` varchar(16) DEFAULT NULL,
  `From` varchar(250) DEFAULT NULL,
  `ToList` varchar(4000) DEFAULT NULL,
  `CCList` varchar(4000) DEFAULT NULL,
  `Subject` varchar(520) DEFAULT NULL,
  `Body` longtext,
  `IsHtml` int DEFAULT NULL,
  `Priority` varchar(20) DEFAULT NULL,
  `Pop3MessageID` varchar(500) DEFAULT NULL,
  `SentDate` varchar(8) DEFAULT NULL,
  `SentTime` varchar(6) DEFAULT NULL,
  `ReceivedDate` varchar(8) DEFAULT NULL,
  `ReceivedTime` varchar(6) DEFAULT NULL,
  `ConversationID` varchar(16) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CurrentServicePoint` varchar(50) DEFAULT NULL,
  `Mailbox` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL,
  `CMSkill` varchar(50) DEFAULT NULL,
  `CheckerSkill` varchar(50) DEFAULT NULL,
  `ActiveTime` bigint DEFAULT NULL,
  `HoldTime` bigint DEFAULT NULL,
  `AssignedDate` varchar(8) DEFAULT NULL,
  `AssignedTime` varchar(6) DEFAULT NULL,
  `AssignedTo` varchar(20) DEFAULT NULL,
  `RepliedDate` varchar(8) DEFAULT NULL,
  `RepliedTime` varchar(6) DEFAULT NULL,
  `RepliedBy` varchar(20) DEFAULT NULL,
  `RepliedStatus` int DEFAULT NULL,
  `ClosedDate` varchar(8) DEFAULT NULL,
  `ClosedTime` varchar(6) DEFAULT NULL,
  `ClosedBy` varchar(20) DEFAULT NULL,
  `ClosedReasonCode` int DEFAULT NULL,
  `Deleted` int DEFAULT NULL,
  `DeletedBy` varchar(10) DEFAULT NULL,
  `DeletedOn` varchar(20) DEFAULT NULL,
  `DeletedSource` varchar(50) DEFAULT NULL,
  `IgnoredDateTime` varchar(6) DEFAULT NULL,
  `IgnoredBy` varchar(20) DEFAULT NULL,
  `IgnoredStatus` int DEFAULT NULL,
  `Outlookfoldername` varchar(250) DEFAULT NULL,
  `OverallSentimentScore` float DEFAULT NULL,
  `EmailType` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_InternetHeaders
CREATE TABLE IF NOT EXISTS `Email_InternetHeaders` (
  `header_id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(50) DEFAULT NULL,
  `header_data` longtext,
  `created_datetime` datetime DEFAULT NULL,
  `service_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`header_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_NDR_Error
CREATE TABLE IF NOT EXISTS `Email_NDR_Error` (
  `Ndr_Error_Cde` varchar(8) NOT NULL,
  `Ndr_Error_Desc` varchar(150) DEFAULT NULL,
  `NDR_Regex` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ndr_Error_Cde`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_NDR_Mapping
CREATE TABLE IF NOT EXISTS `Email_NDR_Mapping` (
  `Ndr_Id` int NOT NULL AUTO_INCREMENT,
  `OutBoxSessionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `InboxSessionId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Ndr_OutboxSessionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Ndr_Error_Cde` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`Ndr_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Outbox
CREATE TABLE IF NOT EXISTS `Email_Outbox` (
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `InSessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `From` varchar(250) DEFAULT NULL,
  `ToList` varchar(4000) DEFAULT NULL,
  `CCList` varchar(4000) DEFAULT NULL,
  `BCCList` varchar(4000) DEFAULT NULL,
  `Subject` varchar(1000) DEFAULT NULL,
  `Body` longtext,
  `IsHtml` int DEFAULT NULL,
  `SendDate` varchar(8) DEFAULT NULL,
  `SendTime` varchar(6) DEFAULT NULL,
  `SendStatus` varchar(10) DEFAULT NULL,
  `CreatedDate` varchar(8) DEFAULT NULL,
  `CreatedTime` varchar(6) DEFAULT NULL,
  `CreatedBy` varchar(20) DEFAULT NULL,
  `ConversationID` varchar(16) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CurrentServicePoint` varchar(50) DEFAULT NULL,
  `Mailbox` varchar(50) DEFAULT NULL,
  `Label` varchar(50) DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL,
  `CMSkill` varchar(50) DEFAULT NULL,
  `RouteID` varchar(50) DEFAULT NULL,
  KEY `ClusteredIndex_SentDatetime` (`SendDate`,`SendTime`),
  KEY `IX_Email_Outbox_Mailbox` (`Mailbox`),
  KEY `IX_Email_Outbox_SessionID` (`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Outbox_Attachments
CREATE TABLE IF NOT EXISTS `Email_Outbox_Attachments` (
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `URL` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Outbox_External
CREATE TABLE IF NOT EXISTS `Email_Outbox_External` (
  `SessionID` varchar(16) DEFAULT NULL,
  `InSessionID` varchar(16) DEFAULT NULL,
  `From` varchar(250) DEFAULT NULL,
  `ToList` varchar(4000) DEFAULT NULL,
  `CCList` varchar(4000) DEFAULT NULL,
  `BCCList` varchar(4000) DEFAULT NULL,
  `Subject` varchar(1000) DEFAULT NULL,
  `Body` longtext,
  `IsHtml` int DEFAULT NULL,
  `SendDate` varchar(8) DEFAULT NULL,
  `SendTime` varchar(6) DEFAULT NULL,
  `SendStatus` varchar(10) DEFAULT NULL,
  `CreatedDate` varchar(8) DEFAULT NULL,
  `CreatedTime` varchar(6) DEFAULT NULL,
  `CreatedBy` varchar(20) DEFAULT NULL,
  `ConversationID` varchar(16) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CurrentServicePoint` varchar(50) DEFAULT NULL,
  `Mailbox` varchar(50) DEFAULT NULL,
  `Label` varchar(50) DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL,
  `CMSkill` varchar(50) DEFAULT NULL,
  `RouteID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_OverAllIntentData
CREATE TABLE IF NOT EXISTS `Email_OverAllIntentData` (
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IntentData` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Queued
CREATE TABLE IF NOT EXISTS `Email_Queued` (
  `QID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `CLID` varchar(500) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `IsTransfer` varchar(50) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `RegPhone` varchar(50) DEFAULT NULL,
  `Segment` varchar(50) DEFAULT NULL,
  `IsCheckerRoute` varchar(50) DEFAULT NULL,
  `Intent` varchar(250) DEFAULT NULL,
  `InteractionText` varchar(500) DEFAULT NULL,
  `AdditionalContactID` varchar(50) DEFAULT NULL,
  `ReRoute` varchar(50) DEFAULT NULL,
  `EmailReceivedDateTime` varchar(50) DEFAULT NULL,
  KEY `QID` (`QID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_Routes
CREATE TABLE IF NOT EXISTS `Email_Routes` (
  `RID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `RouteType` varchar(50) DEFAULT NULL,
  `RouteTo` varchar(50) DEFAULT NULL,
  `RouteDateTime` varchar(50) DEFAULT NULL,
  `AssignedTo` varchar(50) DEFAULT NULL,
  `AssingedDateTime` varchar(50) DEFAULT NULL,
  `RepliedDateTime` varchar(50) DEFAULT NULL,
  `ClosedDateTime` varchar(50) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `ReplyIDList` varchar(250) DEFAULT NULL,
  `DraftID` varchar(50) DEFAULT NULL,
  `ActiveTime` int DEFAULT NULL,
  `HoldTime` int DEFAULT NULL,
  `ActiveOrHold` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `DraftDateTime` varchar(50) DEFAULT NULL,
  `RouteReason` varchar(50) DEFAULT NULL,
  `CloseReason` varchar(50) DEFAULT NULL,
  `RepliedBy` varchar(50) DEFAULT NULL,
  `ATTACHMENTINFO` varchar(20) DEFAULT NULL,
  `EWS_EmailSentDateTime` varchar(100) DEFAULT NULL,
  KEY `IX_Email_Routes_RID` (`RID`),
  KEY `IX_Email_Routes_AssignedDateTime_AssignedTo` (`AssignedTo`,`AssingedDateTime`,`CurrentStatus`,`ClosedDateTime`,`DraftDateTime`,`SessionID`,`RepliedDateTime`),
  KEY `IX_Email_Routes_AssingedDateTime` (`AssingedDateTime`,`SessionID`,`AssignedTo`),
  KEY `IX_Email_Routes_ClosedDT_CurrentStatus_RouteType_AssingedDT` (`ClosedDateTime`,`CurrentStatus`,`RouteType`,`AssingedDateTime`),
  KEY `IX_Email_Routes_CurrentStatus_AssingedDateTime` (`CurrentStatus`,`AssingedDateTime`,`SessionID`,`Skill`,`ClosedDateTime`),
  KEY `IX_Email_Routes_RepliedDT_ClosedDT_Skill_RouteType_AssingedDT` (`RepliedDateTime`,`ClosedDateTime`,`Skill`,`RouteType`,`AssingedDateTime`),
  KEY `IX_Email_Routes_SessionID_Skill_RouteDateTime_ClosedDateTime` (`SessionID`,`Skill`,`RouteDateTime`,`ClosedDateTime`),
  KEY `IX_Email_Routes_Skill` (`Skill`),
  KEY `IX_Email_Routes_Skill_AssingedDateTime_CurrentStatus` (`Skill`,`AssingedDateTime`,`CurrentStatus`,`SessionID`,`RepliedDateTime`,`ClosedDateTime`),
  KEY `IX_Email_Routes_Skill_RouteDateTime` (`Skill`,`RouteDateTime`,`RouteType`,`RepliedDateTime`,`CurrentStatus`,`ClosedDateTime`,`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for view OCM.email_routes_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `email_routes_view` (
	`RID` BIGINT(19) NOT NULL,
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteType` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteTo` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedTo` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssingedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ReplyIDList` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`DraftID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ActiveTime` INT(10) NULL,
	`HoldTime` INT(10) NULL,
	`ActiveOrHold` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Skill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`DraftDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteReason` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CloseReason` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedBy` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ATTACHMENTINFO` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`EWS_EmailSentDateTime` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for table OCM.Email_Senders
CREATE TABLE IF NOT EXISTS `Email_Senders` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `MailBoxId` varchar(50) DEFAULT NULL,
  `EmailID` varchar(80) DEFAULT NULL,
  `SenderType` varchar(10) DEFAULT NULL,
  `LastChangedBy` varchar(80) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_SenderTypes
CREATE TABLE IF NOT EXISTS `Email_SenderTypes` (
  `MailBoxId` varchar(50) DEFAULT NULL,
  `TypeName` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_SkillMap
CREATE TABLE IF NOT EXISTS `Email_SkillMap` (
  `MailBoxId` varchar(50) DEFAULT NULL,
  `Intent` varchar(150) DEFAULT NULL,
  `MailFromContains` varchar(250) DEFAULT NULL,
  `MailToContains` varchar(250) DEFAULT NULL,
  `MailCcContains` varchar(250) DEFAULT NULL,
  `MailBccContains` varchar(250) DEFAULT NULL,
  `Priority` varchar(10) DEFAULT NULL,
  `Index` int DEFAULT NULL,
  `MakerSkill` varchar(20) DEFAULT NULL,
  `CheckerSkill` varchar(20) DEFAULT NULL,
  `AutoResponseTemplateID` int DEFAULT NULL,
  `SenderType` varchar(10) DEFAULT NULL,
  `ID` int NOT NULL AUTO_INCREMENT,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_SL
CREATE TABLE IF NOT EXISTS `Email_SL` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ServiceLevelOne` int DEFAULT NULL,
  `ServiceLevelTwo` int DEFAULT NULL,
  `ServiceLevelThree` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Email_SpamID
CREATE TABLE IF NOT EXISTS `Email_SpamID` (
  `SpamID` int NOT NULL AUTO_INCREMENT,
  `EmailID` varchar(50) NOT NULL,
  PRIMARY KEY (`SpamID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Actions
CREATE TABLE IF NOT EXISTS `EML_Actions` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Action` varchar(100) DEFAULT NULL,
  `SessionID` varchar(150) DEFAULT NULL,
  `ActionDate` varchar(8) DEFAULT NULL,
  `ActionTime` varchar(6) DEFAULT NULL,
  `ActionBy` varchar(50) DEFAULT NULL,
  `Info` varchar(250) DEFAULT NULL,
  `OutboxSessionID` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Configuration
CREATE TABLE IF NOT EXISTS `EML_Configuration` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SMTPServer` varchar(100) DEFAULT NULL,
  `EmailID` varchar(50) DEFAULT NULL,
  `Password` varchar(25) DEFAULT NULL,
  `PortNo` int DEFAULT NULL,
  `EnableSSL` bit(1) DEFAULT NULL,
  `CreatedBy` varchar(250) DEFAULT NULL,
  `mailbox` varchar(200) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Conversations
CREATE TABLE IF NOT EXISTS `EML_Conversations` (
  `ConversationID` int DEFAULT NULL,
  `OriginalSubject` varchar(250) DEFAULT NULL,
  `OriginalEmailAddress` varchar(250) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Inbox
CREATE TABLE IF NOT EXISTS `EML_Inbox` (
  `SessionID` varchar(150) DEFAULT NULL,
  `EmailID` varchar(250) DEFAULT NULL,
  `RecDate` varchar(8) DEFAULT NULL,
  `RecTime` varchar(6) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CurrentServicePoint` varchar(50) DEFAULT NULL,
  `Subject` varchar(260) DEFAULT NULL,
  `Body` longtext,
  `ToList` varchar(250) DEFAULT NULL,
  `CCList` varchar(250) DEFAULT NULL,
  `Mailbox` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `ArrivalDate` varchar(8) DEFAULT NULL,
  `ArrivalTime` varchar(6) DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL,
  `CMSkill` varchar(50) DEFAULT NULL,
  `CheckerID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Inbox_Attachments
CREATE TABLE IF NOT EXISTS `EML_Inbox_Attachments` (
  `SessionID` varchar(150) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `URL` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Outbox
CREATE TABLE IF NOT EXISTS `EML_Outbox` (
  `SessionID` varchar(50) DEFAULT NULL,
  `EmailID` varchar(250) DEFAULT NULL,
  `InSessionID` varchar(50) DEFAULT NULL,
  `Subject` varchar(260) DEFAULT NULL,
  `Body` longtext,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `CreatedDate` varchar(8) DEFAULT NULL,
  `CreatedTime` varchar(6) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `EmailCC` varchar(250) DEFAULT NULL,
  `EmailBCC` varchar(250) DEFAULT NULL,
  `SkillID` varchar(50) DEFAULT NULL,
  `CurrentStatus` varchar(50) DEFAULT NULL,
  `CurrentStatusDate` varchar(8) DEFAULT NULL,
  `CurrentStatusTime` varchar(6) DEFAULT NULL,
  `CheckerID` varchar(50) DEFAULT NULL,
  `CheckerChangedContent` int DEFAULT NULL,
  `HasAttachments` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.EML_Outbox_Attachments
CREATE TABLE IF NOT EXISTS `EML_Outbox_Attachments` (
  `SessionID` varchar(50) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `URL` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.EndDayCalculation
DELIMITER //
CREATE FUNCTION `EndDayCalculation`(
	p_SL varchar(10),
	p_EndDate DATETIME,
	v_tStartTime DATETIME,
 	v_tEndTime DATETIME,
 	v_nextDate DATETIME,
 	v_startDayOutMins DOUBLE,
	v_endDayOutMins DOUBLE,
	p_Type varchar(50)
) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN

	Declare v_Day varchar(3);
	Declare v_sod datetime(3);  
	Declare v_eod datetime(3);
	Declare v_OpStartTime varchar(10); 
	Declare v_OpEndTime varchar(10);
	
	set v_Day= LEFT(DAYNAME( p_EndDate), 3);
	
	Drop temporary table if exists TempTable;
	Create temporary table TempTable 
		(WeeDay varchar(10),
		Start_Time varchar(10),
		End_Time varchar(10),
		VDN_Name varchar(50));

	Drop temporary table if exists HolidayTempTable;
	Create temporary table HolidayTempTable 
		(Holiday varchar(100),
		HolidayStartDate varchar(10),
		HolidayEndDate varchar(10),
		VDN varchar(10));
		
	insert into HolidayTempTable
		SELECT ANNOUNCED_HOLIDAY,Start_Date,End_Date,VDN 
		FROM IVR_HOLIDAY_LIST WHERE ltrim(rtrim(VDN))=ltrim(rtrim(p_Type));

	if(exists(select 1 from HolidayTempTable HT where DATE_FORMAT(p_EndDate,'%Y%m%d') >= DATE_FORMAT(convert(HT.HolidayStartDate, datetime),'%Y%m%d') AND DATE_FORMAT(p_EndDate,'%Y%m%d') <= DATE_FORMAT(convert(HT.HolidayEndDate, datetime),'%Y%m%d')))
	then  
		set v_tStartTime = DATE_FORMAT(concat(DATE_FORMAT(p_EndDate,'%Y%m%d') + '000001'), '%Y-%m-%d %H:%i:%s');
		set v_endDayOutMins = timestampdiff(minute, v_tStartTime, p_EndDate);

		#goto NextDayCalculation;
		RETURN (SELECT NextDayCalculation(p_EndDate,v_tStartTime,v_tEndTime,v_nextDate,	v_startDayOutMins,v_endDayOutMins, p_Type));
	end if;

	insert into TempTable
		SELECT `WEEKDAY`,START_TIME,END_TIME,GROUP_NAME FROM IVR_BUSINESS_HOUR WHERE 
		lower(ltrim(rtrim(WEEKDAY)))=lower(ltrim(rtrim(v_Day))) AND ltrim(rtrim(GROUP_NAME))=ltrim(rtrim(p_Type));

	if (not exists (select 1 from TempTable))
	then
		insert into TempTable values(null,'000001','235959',null);
	end if;

	select replace(Start_Time,':','') into v_OpStartTime from TempTable;
	
	select replace(End_Time,':','') into v_OpEndTime from TempTable;
	
	set v_sod=DATE_FORMAT(concat(DATE_FORMAT(p_EndDate,'%Y%m%d'),'000001'), '%Y-%m-%d %H:%i:%s');
	set v_eod=DATE_FORMAT(concat(DATE_FORMAT(p_EndDate,'%Y%m%d'),'235959'), '%Y-%m-%d %H:%i:%s');

	set v_tStartTime = DATE_FORMAT(concat(DATE_FORMAT(p_EndDate,'%Y%m%d') , v_OpStartTime), '%Y-%m-%d %H:%i:%s');
	if(v_tStartTime = cast(-53690 as datetime(3))) then
		set v_tStartTime = v_sod;
	end if;

	set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_EndDate,'%Y%m%d') , v_OpEndTime), '%Y-%m-%d %H:%i:%s');
	if(v_tEndTime = cast(-53690 as datetime(3))) then
		set v_tEndTime = v_eod;
	end if;

	if(p_EndDate < v_tStartTime) then
		set v_endDayOutMins = timestampdiff(minute,v_sod, p_EndDate);
		if(timestampdiff(minute,v_sod, p_EndDate) = 1439) then
		   set v_endDayOutMins = v_endDayOutMins - 1 ;
		end if;
	ELSEIF (p_EndDate >= v_tStartTime and p_EndDate <= v_tEndTime) then
		set v_endDayOutMins = timestampdiff(minute,v_sod,v_tStartTime);
	ELSE
		set v_endDayOutMins =timestampdiff(minute,v_sod,v_tStartTime) + TIMESTAMPDIFF(minute,v_tEndTime,p_EndDate);
		if(TIMESTAMPDIFF(minute,v_tEndTime,p_EndDate) = 1439) then
		   SET v_endDayOutMins = v_endDayOutMins - 1;
	   end if;
	end if;

	Delete from TempTable;
	Delete from HolidayTempTable;
	
	return v_endDayOutMins;

END//
DELIMITER ;

-- Dumping structure for table OCM.ExportReportsAudit
CREATE TABLE IF NOT EXISTS `ExportReportsAudit` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `ReportName` varchar(50) DEFAULT NULL,
  `FromDateTime` varchar(15) DEFAULT NULL,
  `ToDateTime` varchar(15) DEFAULT NULL,
  `ExecutedDateTime` datetime(3) DEFAULT NULL,
  `StateOfExecution` varchar(8000) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.ExportReportScheduler
CREATE TABLE IF NOT EXISTS `ExportReportScheduler` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ReportName` varchar(50) DEFAULT NULL,
  `LastExecutedDateTime` datetime(3) NOT NULL,
  `FrequencyInMinutes` int NOT NULL,
  `ServerID` varchar(50) DEFAULT NULL,
  `Status` varchar(25) DEFAULT 'COMPLETEDWITHSUCCESS',
  `STATUSDATETIME` datetime(3) NOT NULL,
  `InputStartDate` varchar(15) DEFAULT NULL,
  `InputEndDate` varchar(15) DEFAULT NULL,
  `WIPTIMEOUT` int NOT NULL,
  `Time` time DEFAULT NULL,
  `CronExpression` varchar(50) NOT NULL DEFAULT '*/15 * * * *',
  `ReportType` tinyint unsigned NOT NULL DEFAULT '1',
  `StatusJob` smallint DEFAULT '3',
  UNIQUE KEY `UQ__ExportRe__930D5CE792194C42` (`ReportName`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.FaceAuth_Transactions
CREATE TABLE IF NOT EXISTS `FaceAuth_Transactions` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `RequestDateTime` datetime(3) DEFAULT NULL,
  `ResponseDateTime` datetime(3) DEFAULT NULL,
  `Originator` varchar(20) DEFAULT NULL,
  `Image1Path` varchar(255) DEFAULT NULL,
  `Image2Path` varchar(255) DEFAULT NULL,
  `Result` varchar(10) DEFAULT NULL,
  `ResultReason` varchar(50) DEFAULT NULL,
  `Score` varchar(25) DEFAULT NULL,
  `Confidence` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_N_FaceAuth_Transactions_Dates` (`RequestDateTime`,`ResponseDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Face_Encodings
CREATE TABLE IF NOT EXISTS `Face_Encodings` (
  `AgentId` varchar(50) NOT NULL,
  `Encoding` longtext NOT NULL,
  `ProfilePic` varchar(255) NOT NULL,
  `CreatedDateTime` varchar(50) NOT NULL,
  PRIMARY KEY (`AgentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.FavoriteFunctionality
CREATE TABLE IF NOT EXISTS `FavoriteFunctionality` (
  `contactNumber` varchar(255) NOT NULL,
  `functionality` varchar(255) NOT NULL,
  `attempts` int NOT NULL,
  `lastTransaction` varchar(255) DEFAULT NULL,
  `lastTransactionDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contactNumber`,`functionality`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.FaxScheduler
CREATE TABLE IF NOT EXISTS `FaxScheduler` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Number` varchar(2000) DEFAULT NULL,
  `Time` varchar(50) DEFAULT NULL,
  `FileName` varchar(100) DEFAULT NULL,
  `Day` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Frequency` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `EnableTemp` varchar(10) DEFAULT NULL,
  `TemplateName` varchar(50) DEFAULT NULL,
  `GUID` varchar(50) DEFAULT NULL,
  `Scheduled` bit(1) NOT NULL DEFAULT b'0',
  `toNumber` varchar(50) DEFAULT NULL,
  `fromNumber` varchar(50) DEFAULT NULL,
  `FaxLine` varchar(20) DEFAULT NULL,
  `SplitKey` varchar(10) DEFAULT NULL,
  `GlobalTemplate` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.FaxTemplate
CREATE TABLE IF NOT EXISTS `FaxTemplate` (
  `TemplateID` int NOT NULL AUTO_INCREMENT,
  `TemplateName` varchar(50) NOT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  `TemplateType` int DEFAULT '0',
  `FileName` varchar(200) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`TemplateName`),
  KEY `TemplateID` (`TemplateID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_ACK_Details
CREATE TABLE IF NOT EXISTS `Fax_ACK_Details` (
  `DNIS` varchar(20) DEFAULT NULL,
  `ACKFile` varchar(260) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_AddressBook
CREATE TABLE IF NOT EXISTS `Fax_AddressBook` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `FaxLine` varchar(20) NOT NULL,
  `RecipientIds` varchar(1000) NOT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UK_Fax_AddressBook_Name` (`Name`),
  KEY `IX_N_Fax_Directory_FaxLine` (`FaxLine`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_AutoAckTemplates
CREATE TABLE IF NOT EXISTS `Fax_AutoAckTemplates` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DNIS` varchar(20) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `TemplateId` int DEFAULT NULL,
  `TemplateContent` varchar(4000) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `Name` varchar(15) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Dashboard
CREATE TABLE IF NOT EXISTS `Fax_Dashboard` (
  `JobId` varchar(20) NOT NULL,
  `FaxReceived` varchar(10) DEFAULT NULL,
  `FaxSent` varchar(10) DEFAULT NULL,
  `FaxDnis` varchar(10) DEFAULT NULL,
  `FaxReceiving` varchar(10) DEFAULT NULL,
  `FaxFailed` varchar(10) DEFAULT NULL,
  `FaxRoute` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`JobId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Dnis
CREATE TABLE IF NOT EXISTS `Fax_Dnis` (
  `DNIS` varchar(20) NOT NULL,
  `Description` varchar(250) DEFAULT NULL,
  `InTrunkConfigId` int DEFAULT NULL,
  `OutTrunkConfigId` int DEFAULT NULL,
  `SendEnabled` int DEFAULT NULL,
  `ReceiveEnabled` int DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `FaxLineName` varchar(15) DEFAULT NULL,
  `Prefix` varchar(10) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`DNIS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.FAX_Ini_File_Details
CREATE TABLE IF NOT EXISTS `FAX_Ini_File_Details` (
  `DNIS` longtext,
  `VIPLIST` longtext,
  `BLACKLIST` longtext,
  `WHITELIST` longtext,
  `DEFAULTLIST` longtext,
  `ACKFILEPATH` longtext,
  `VIPLISTFOLDER` longtext,
  `BLACKLISTFOLDER` longtext,
  `WHITELISTFOLDER` longtext,
  `DEFAULTFOLDER` longtext,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `BLACKLISTSKILLTOROUTE` varchar(100) DEFAULT NULL,
  `WHITELISTSKILLTOROUTE` varchar(100) DEFAULT NULL,
  `VIPLISTSKILLTOROUTE` varchar(100) DEFAULT NULL,
  `DEFAULTLISTSKILLTOROUTE` varchar(100) DEFAULT NULL,
  `EnableACK` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_JobDetails
CREATE TABLE IF NOT EXISTS `Fax_JobDetails` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Ucid` varchar(50) DEFAULT NULL,
  `Source` varchar(50) DEFAULT NULL,
  `Number` varchar(50) DEFAULT NULL,
  `FilePath` varchar(50) DEFAULT NULL,
  `JobId` varchar(50) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `StatusReason` varchar(50) DEFAULT NULL,
  `CreatedTime` varchar(14) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Received_Details
CREATE TABLE IF NOT EXISTS `Fax_Received_Details` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `JobID` varchar(100) DEFAULT NULL,
  `FileName` varchar(260) DEFAULT NULL,
  `SIPNumber` varchar(260) DEFAULT NULL,
  `ErrorString` varchar(100) DEFAULT NULL,
  `ReceivedDateTime` varchar(50) DEFAULT NULL,
  `Result` int DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `DNIS` varchar(50) DEFAULT NULL,
  `PageCount` int DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `CallDuration` varchar(10) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `RouteStatus` varchar(20) DEFAULT NULL,
  `ReceiveStatus` varchar(20) DEFAULT NULL,
  `AssignedAgentID` varchar(20) DEFAULT NULL,
  `AnnotatedFile` varchar(260) DEFAULT NULL,
  `WorkCodes` varchar(50) DEFAULT NULL,
  `TransferredAgentID` varchar(50) DEFAULT NULL,
  `SFTPUploadStatus` varchar(30) DEFAULT NULL,
  `EWFErrorCode` varchar(30) DEFAULT NULL,
  `EWFErrorDetails` varchar(30) DEFAULT NULL,
  `EWFConsolidateErrorCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `InstanceId` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Recipient
CREATE TABLE IF NOT EXISTS `Fax_Recipient` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `FaxNumber` varchar(20) NOT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UK_Fax_Recipient_FaxNumber_OrgUnit` (`FaxNumber`,`OrgUnit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_RouteMap
CREATE TABLE IF NOT EXISTS `Fax_RouteMap` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DNIS` varchar(20) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `Intent` varchar(100) DEFAULT NULL,
  `RouteType` varchar(10) DEFAULT NULL,
  `RouteData` varchar(250) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Senders
CREATE TABLE IF NOT EXISTS `Fax_Senders` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `DNIS` varchar(20) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `FaxNumber` varchar(20) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_SenderTypes
CREATE TABLE IF NOT EXISTS `Fax_SenderTypes` (
  `TypeName` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Fax_Sent_Details
CREATE TABLE IF NOT EXISTS `Fax_Sent_Details` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `jobID` varchar(100) DEFAULT NULL,
  `FileName` varchar(250) DEFAULT NULL,
  `SIPNumber` varchar(250) DEFAULT NULL,
  `ErrorString` varchar(250) DEFAULT NULL,
  `SentDateTime` varchar(50) DEFAULT NULL,
  `Result` int DEFAULT NULL,
  `Attempts` int DEFAULT NULL,
  `ANI` varchar(20) DEFAULT NULL,
  `DNIS` varchar(20) DEFAULT NULL,
  `PageCount` int DEFAULT NULL,
  `RecipientNumber` varchar(50) DEFAULT NULL,
  `CallDuration` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `SendStatus` varchar(20) DEFAULT NULL,
  `SentBy` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.fn_AgentHierarchy
DELIMITER //
CREATE FUNCTION `fn_AgentHierarchy`(p_type VARCHAR(50), p_teamid varchar(10),p_supervisorid varchar(10)) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
      DECLARE sf_result INT DEFAULT 0;
		DROP TEMPORARY TABLE IF EXISTS AgentHierarchyResult;
      CREATE TEMPORARY TABLE AgentHierarchyResult (AgentId varchar(50),AgentName varchar(200),SupervisorName varchar(200),TeamName varchar(200));
        IF(p_type='team') THEN
			INSERT INTO AgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName)
			SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT TeamID FROM AGT_Teams WHERE TeamID = p_teamid
			UNION ALL
			SELECT t.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID)
			SELECT DISTINCT A.AvayaLoginID,concat(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			concat(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,
			IFNULL(C.TeamName,' ') AS TeamName 
			FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN AGT_Agent S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN AGT_Teams C ON C.TeamID = A.TeamID
			LEFT JOIN AGT_Teams P ON C.ParentID  = P.TeamID
			LEFT JOIN AGT_Teams PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN (SELECT TeamID FROM Team)) Temp;
	 ELSEIF (p_type='teamsupervisor') THEN
			INSERT INTO AgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName)
			SELECT * FROM 
    (
			WITH RECURSIVE Team AS(
			SELECT TeamID FROM AGT_Teams WHERE TeamID = p_teamid
			UNION ALL
			SELECT T.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID),
			Supervisor AS ( 
			SELECT ID FROM AGT_Agent  WHERE ID=p_supervisorid
			UNION ALL
			SELECT A.ID FROM AGT_Agent A INNER JOIN Supervisor B   ON A.PrimarySupervisorID = B.ID)
			SELECT DISTINCT  A.AvayaLoginID AgentId,concat(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			concat(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN AGT_Agent S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN AGT_Teams C ON C.TeamID = A.TeamID
			LEFT JOIN AGT_Teams P ON C.ParentID  = P.TeamID
			LEFT JOIN AGT_Teams PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN ( SELECT TeamID FROM Team )  AND A.ID IN ( SELECT ID FROM Supervisor)) Temp;
	 ELSE
	        INSERT INTO AgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName)
	        SELECT DISTINCT  A.AvayaLoginID AgentId,concat(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			concat(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN AGT_Teams C ON C.TeamID = A.TeamID;

			
			IF (select Table_Name from information_schema.TABLES where Table_Name='OCM_AgentSummaryReport') IS NOT NULL 
			THEN
				CREATE TEMPORARY TABLE AgentHierarchyResultTemp AS SELECT * FROM AgentHierarchyResult;
				
				INSERT INTO AgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName)
				SELECT distinct AgentId,'' AgentName, '' SupervisorName, '' TeamName FROM OCM_AgentSummaryReport where AgentId not in (select AgentID from AgentHierarchyResultTemp);
				
				DROP TEMPORARY TABLE IF EXISTS AgentHierarchyResultTemp;
			END IF;
			
	 END IF;
   SET sf_result = 1;
 	RETURN sf_result;
END//
DELIMITER ;

-- Dumping structure for function OCM.fn_CalculateFaxSLA
DELIMITER //
CREATE FUNCTION `fn_CalculateFaxSLA`(
	p_StartDate datetime,
	p_EndDate datetime,
	p_Type varchar(50),
	p_SL varchar(10)
) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	Declare v_sla double; 
	Declare v_startDayOutMins double;  
	Declare v_Day varchar(3);  
	Declare v_endDayOutMins double; 
	Declare v_dayOutMins double;  
	Declare v_slaTS int;  
	Declare v_diff INT;
	
	Declare v_sod datetime(3);  
	Declare v_eod datetime(3);
	Declare v_tStartTime datetime(3);  
	Declare v_tEndTime datetime(3);
	Declare v_nextDate datetime(3);
	Declare v_OpStartTime varchar(10); 
	Declare v_OpEndTime varchar(10);

	Drop temporary table if exists TempTable;
	Create temporary table TempTable 
		(WeeDay varchar(10),
		Start_Time varchar(10),
		End_Time varchar(10),
		VDN_Name varchar(50));

	Drop temporary table if exists HolidayTempTable;
	Create temporary table HolidayTempTable 
		(Holiday varchar(100),
		HolidayStartDate varchar(10),
		HolidayEndDate varchar(10),
		VDN varchar(10));

	set v_sla=0;
	set v_startDayOutMins=0;
	set v_endDayOutMins=0;
	set v_dayOutMins=0;
	set v_nextDate = p_StartDate;

	set v_Day= LEFT(DAYNAME( p_StartDate), 3);

	insert into HolidayTempTable
		SELECT `ANNOUNCED_HOLIDAY`,`Start_Date`,`End_Date`,`VDN` 
		FROM IVR_HOLIDAY_LIST WHERE ltrim(rtrim(VDN))=ltrim(rtrim(p_Type));

	if(exists(select 1 from HolidayTempTable HT where DATE_FORMAT(p_StartDate,'%Y%m%d') >= DATE_FORMAT(convert(HT.HolidayStartDate, datetime),'%Y%m%d') AND DATE_FORMAT(p_StartDate,'%Y%m%d') <= DATE_FORMAT(convert(HT.HolidayEndDate, datetime),'%Y%m%d')))
	then
		if(DATE_FORMAT(p_StartDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d'))
			then 
				set v_sla = 0;
				#goto SLACalculation;
				return (select SLACalculation(p_SL, v_sla));
		else
		 		set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'), '235959'), '%Y-%m-%d %H:%i:%s');
				set v_startDayOutMins = timestampdiff(minute, p_StartDate, v_tEndTime);
			end if;
		
		#goto EndDayCalculation;
		return (select EndDayCalculation(p_SL, p_EndDate, v_tStartTime, v_tEndTime, v_nextDate, v_startDayOutMins, v_endDayOutMins, p_Type));
	end if;

	insert into TempTable
		SELECT `WEEKDAY`,START_TIME,END_TIME,GROUP_NAME FROM IVR_BUSINESS_HOUR WHERE 
		lower(ltrim(rtrim(WEEKDAY)))=lower(ltrim(rtrim(v_Day))) AND ltrim(rtrim(GROUP_NAME))=ltrim(rtrim(p_Type));

	if (not exists (select 1 from TempTable))
	then
		insert into TempTable values(null,'000001','235959',null);
	end if;

	select replace(Start_Time,':','') into v_OpStartTime from TempTable;
	
	select replace(End_Time,':','') into v_OpEndTime from TempTable;

	set v_sod = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'),'000001'), '%Y-%m-%d %H:%i:%s');
	set v_eod = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'),'235959'), '%Y-%m-%d %H:%i:%s');
	
	set v_tStartTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d') , v_OpStartTime), '%Y-%m-%d %H:%i:%s');
	if(v_tStartTime = cast('1753-1-1' as DATETIME)) then
		set v_tStartTime = v_sod;
	end if;

	set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d') , v_OpEndTime), '%Y-%m-%d %H:%i:%s');
	if(v_tEndTime = cast('1753-1-1' as DATETIME)) then
		set v_tEndTime = v_eod;
	end if;

	if(p_StartDate < v_tStartTime) then
		set v_startDayOutMins = timestampdiff(minute, p_StartDate, v_tStartTime) + timestampdiff(minute, v_tEndTime, v_eod);
		if(timestampdiff(minute, p_StartDate, v_tStartTime) = 1439) then
		   set v_startDayOutMins = v_startDayOutMins - 1;
		end if;
	elseif (p_StartDate >= v_tStartTime and p_StartDate <= v_tEndTime) then
		set v_startDayOutMins = timestampdiff(minute, v_tEndTime, v_eod);
	else 
		set v_startDayOutMins =timestampdiff(minute, p_StartDate, v_eod);
		if(timestampdiff(minute, p_StartDate, v_eod) = 1439) then
		    set v_startDayOutMins = v_startDayOutMins - 1;
		end if;
	end if;

	if(p_StartDate >= v_tStartTime and p_EndDate <= v_tEndTime)
		then
			set v_sla=timestampdiff(minute, p_StartDate, p_EndDate);
			#goto SLACalculation;
			return (select SLACalculation(p_SL, v_sla));
		end if;

	if(DATE_FORMAT(p_StartDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d'))
		then
			if(p_StartDate > v_tStartTime) then
				set v_tStartTime = p_StartDate;
			end if;
			if(p_EndDate < v_tEndTime) then
				set v_tEndTime = p_EndDate;
			end if;

			set v_sla= TIMESTAMPDIFF(minute,v_tStartTime,v_tEndTime);
			#goto SLACalculation;
			return (select SLACalculation(p_SL, v_sla));
		end if;

	Delete from TempTable;

	set v_sla=TIMESTAMPDIFF(minute,p_StartDate,p_EndDate) - (v_startDayOutMins + v_endDayOutMins + v_dayOutMins);

	Delete from HolidayTempTable;

	RETURN (select SLACalculation(p_SL, v_sla));
END//
DELIMITER ;

-- Dumping structure for function OCM.fn_Fax_AddressBook
DELIMITER //
CREATE FUNCTION `fn_Fax_AddressBook`(p_type varchar(50), p_faxLine varchar(20),p_adddressbookid bigint) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
		DECLARE sf_result INT DEFAULT 0;
		DROP TEMPORARY TABLE IF EXISTS FaxAddressBookResult;
      CREATE TEMPORARY TABLE FaxAddressBookResult (FaxLine varchar(20),FaxLineName varchar(20),
										ReceiveEnabled int,SendEnabled int,AdddressBookId bigint,
										AdddressBookName varchar(50), RecipientName varchar(150), 
										FaxNumber varchar(20), RecipientDisplay varchar(200),OrgUnit int);
        
	 IF(p_type='faxline')
	 THEN
			INSERT INTO FaxAddressBookResult(FaxLine, FaxLineName, ReceiveEnabled, SendEnabled, OrgUnit)
			SELECT `DNIS` AS FaxLine, FaxLineName, ReceiveEnabled, SendEnabled, OrgUnit FROM Fax_Dnis WHERE `Enabled` =1;
	 ELSEIF (p_type='addressbook')
	 THEN
			INSERT INTO FaxAddressBookResult(FaxLine,AdddressBookId,AdddressBookName,OrgUnit)
			SELECT  FaxLine,Id AdddressBookId,`Name` AdddressBookName, OrgUnit 
			FROM Fax_AddressBook WHERE FaxLine = p_faxLine;
	 ELSE
			INSERT INTO FaxAddressBookResult(RecipientName,FaxNumber,RecipientDisplay,OrgUnit)
			SELECT CONCAT(FirstName,' ',LastName) AS RecipientName, FaxNumber, 
			CONCAT(FirstName,' ',LastName,'<', FaxNumber,'>') RecipientDisplay, A.OrgUnit FROM Fax_Recipient R 
			INNER JOIN Fax_AddressBook A ON R.Id in (SELECT BreakStringIntoRows(A.RecipientIds))
			where A.ID =p_adddressbookid;
	 END IF;
	 	SET sf_result = 1;
 		RETURN sf_result;
END//
DELIMITER ;

-- Dumping structure for function OCM.fn_Generic_AgentHierarchy
DELIMITER //
CREATE FUNCTION `fn_Generic_AgentHierarchy`(p_type varchar(50),p_teamid varchar(20),p_agentid varchar(20)) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
	DECLARE sf_result INT DEFAULT 0;
		DROP TEMPORARY TABLE IF EXISTS GenericAgentHierarchyResult;
      CREATE TEMPORARY TABLE GenericAgentHierarchyResult (AgentId varchar(50),AgentName varchar(200),SupervisorName varchar(200),TeamName varchar(200),TeamID int,ParentID int);
        
	 IF(p_type='orgunit')
	 THEN
	 		INSERT INTO GenericAgentHierarchyResult(ParentID,TeamID,TeamName)
	 		SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT t.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID)
			
			SELECT IFNULL(ChildTable.ParentID,'0') ParentID ,ChildTable.TeamID, ChildTable.TeamName FROM AGT_Teams AS ChildTable 
			LEFT JOIN AGT_Teams AS ParentTable ON ChildTable.ParentID = ParentTable.TeamID WHERE 1=1 and 
			ChildTable.TeamID IN (SELECT TeamID FROM Team)  
			Order By ChildTable.ParentID, ChildTable.TeamID) Temp;
			
	 ELSEIF (p_type='team')
	 THEN
	 INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	 SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT t.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID)

			
			SELECT DISTINCT A.AvayaLoginID,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,
			IFNULL(C.TeamName,' ') AS TeamName , C.TeamID
			FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Agent` S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID
			LEFT JOIN `AGT_Teams` P ON C.ParentID  = P.TeamID
			LEFT JOIN `AGT_Teams` PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN (SELECT TeamID FROM Team))Temp; 
			
	 ELSEIF (p_type='teamsupervisor')
	 THEN
	 INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	 SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT T.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID),
			Supervisor AS ( 
			SELECT ID FROM `AGT_Agent`  WHERE AvayaLoginID=p_agentid
			UNION ALL
			SELECT A.ID FROM AGT_Agent A INNER JOIN Supervisor B   ON A.PrimarySupervisorID = B.ID)

			
			SELECT DISTINCT  A.AvayaLoginID AgentId,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName,C.TeamID FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Agent` S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID
			LEFT JOIN `AGT_Teams` P ON C.ParentID  = P.TeamID
			LEFT JOIN `AGT_Teams` PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN ( SELECT TeamID FROM Team )  AND A.ID IN ( SELECT ID FROM Supervisor) )Temp;
			
	 ELSE
	        INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	        SELECT DISTINCT  A.AvayaLoginID AgentId,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName,C.TeamID FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID;
			
	 END IF;
	 SET sf_result = 1;
 	RETURN sf_result;
END//
DELIMITER ;

-- Dumping structure for function OCM.FORMATDATETIME
DELIMITER //
CREATE FUNCTION `FORMATDATETIME`(p_DateTime datetime(3),
	p_Format varchar(25)) RETURNS varchar(25) CHARSET utf8mb4
    DETERMINISTIC
BEGIN  
    Declare v_ret varchar(25) Default '';

	IF(p_Format = 'dd/MM/yyyy HH:mm:ss')
	THEN
	   SET v_ret = DATE_FORMAT(p_DateTime, '%d/%m/%Y %T');
	ELSEIF (p_Format='yyyy-MM-dd HH:mm:ss')
	THEN
	  SET v_ret = DATE_FORMAT(p_DateTime, '%Y-%m-%d %T');
	ELSEIF (p_Format = 'dd/MM/yyyy')
	THEN
	   SET v_ret = DATE_FORMAT(p_DateTime, '%d/%m/%Y');
	END IF;
    RETURN v_ret;  
END//
DELIMITER ;

-- Dumping structure for table OCM.Gamification_Achievements
CREATE TABLE IF NOT EXISTS `Gamification_Achievements` (
  `AchievementId` int NOT NULL AUTO_INCREMENT,
  `AgentId` varchar(50) DEFAULT NULL,
  `BadgesAchieved` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`AchievementId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Agent_Goals
CREATE TABLE IF NOT EXISTS `Gamification_Agent_Goals` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AgentId` varchar(50) NOT NULL,
  `GoalId` int NOT NULL,
  `GoalAchieved` bit(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Agent_Interactions
CREATE TABLE IF NOT EXISTS `Gamification_Agent_Interactions` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MetricId` int NOT NULL,
  `SessionId` varchar(100) DEFAULT NULL,
  `AgentId` varchar(50) DEFAULT NULL,
  `PointsAssigned` bigint DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Agent_Metrics
CREATE TABLE IF NOT EXISTS `Gamification_Agent_Metrics` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MetricId` int NOT NULL,
  `AgentId` varchar(50) DEFAULT NULL,
  `MetricCurrentPoint` bigint DEFAULT NULL,
  `MetricTotalPoint` bigint DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Badges
CREATE TABLE IF NOT EXISTS `Gamification_Badges` (
  `BadgeId` int NOT NULL AUTO_INCREMENT,
  `BadgeName` varchar(100) DEFAULT NULL,
  `BadgeUrl` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`BadgeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Goals
CREATE TABLE IF NOT EXISTS `Gamification_Goals` (
  `GoalId` int NOT NULL AUTO_INCREMENT,
  `GoalName` varchar(100) NOT NULL,
  `GoalType` varchar(50) NOT NULL,
  `GoalTarget` bigint NOT NULL,
  PRIMARY KEY (`GoalId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Goals_Badge_Mapping
CREATE TABLE IF NOT EXISTS `Gamification_Goals_Badge_Mapping` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MetricMappingId` int NOT NULL,
  `GoalId` int NOT NULL,
  `BadgeId` int NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Goals_Targets_Mapping
CREATE TABLE IF NOT EXISTS `Gamification_Goals_Targets_Mapping` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `TargetId` int NOT NULL,
  `GoalId` int NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Metrics
CREATE TABLE IF NOT EXISTS `Gamification_Metrics` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `MetricType` varchar(100) DEFAULT NULL,
  `Channel` varchar(100) DEFAULT NULL,
  `MetricValue` varchar(100) DEFAULT NULL,
  `MetricPoint` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Metrics_Team_Mapping
CREATE TABLE IF NOT EXISTS `Gamification_Metrics_Team_Mapping` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MetricId` int NOT NULL,
  `TeamId` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Gamification_Targets
CREATE TABLE IF NOT EXISTS `Gamification_Targets` (
  `TargetId` int NOT NULL AUTO_INCREMENT,
  `TargetName` varchar(100) NOT NULL,
  `TargetType` varchar(50) NOT NULL,
  `TargetStartDate` varchar(20) NOT NULL,
  PRIMARY KEY (`TargetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_ActivationRequest
CREATE TABLE IF NOT EXISTS `GBL_ActivationRequest` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UCID` varchar(20) DEFAULT NULL,
  `Request_Date` varchar(20) DEFAULT NULL,
  `Request_Time` varchar(20) DEFAULT NULL,
  `Request_Mode` varchar(10) DEFAULT NULL,
  `MobileNumber_Request` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `CardNumLastFourDigits` varchar(16) DEFAULT NULL,
  `CardProductCode` varchar(10) DEFAULT NULL,
  `AccountNumber` varchar(20) DEFAULT NULL,
  `SMS_Content` varchar(500) DEFAULT NULL,
  `Request_Status` varchar(10) DEFAULT NULL,
  `Reason` varchar(100) DEFAULT NULL,
  `Ack_Message` varchar(500) DEFAULT NULL,
  `Verification_Mode` varchar(20) DEFAULT NULL,
  `AgentId_Manual` varchar(10) DEFAULT NULL,
  `Audit_Trial` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_Agent_Interaction
CREATE TABLE IF NOT EXISTS `GBL_Agent_Interaction` (
  `ID` int NOT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(50) DEFAULT NULL,
  `SupervisorID` varchar(50) DEFAULT NULL,
  `SupervisorName` varchar(50) DEFAULT NULL,
  `DepartmentID` varchar(50) DEFAULT NULL,
  `DepartmentName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_Custom_ContactList
CREATE TABLE IF NOT EXISTS `GBL_Custom_ContactList` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CallerID` varchar(20) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `FBHandle` varchar(50) DEFAULT NULL,
  `MessengerID` varchar(20) DEFAULT NULL,
  `CustomerIDType` varchar(20) NOT NULL,
  `CustomerIDNo` varchar(50) NOT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `ContactType` varchar(20) DEFAULT NULL,
  `InclusionFlag` varchar(1) DEFAULT NULL,
  `ExclusionFlag` varchar(1) DEFAULT NULL,
  `OtherData` longtext,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_GBL_Custom_ContactList_CallerID` (`CallerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_Drop_Requests
CREATE TABLE IF NOT EXISTS `GBL_Drop_Requests` (
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `CLID` varchar(50) DEFAULT NULL,
  `REQUEST_DATE` varchar(50) DEFAULT NULL,
  `REQUEST_TIME` varchar(50) DEFAULT NULL,
  `PREFIX` varchar(100) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `CARD_NUMBER` varchar(50) DEFAULT NULL,
  `HANDPHONE` varchar(50) DEFAULT NULL,
  `OTHER_INFORMATION` varchar(500) DEFAULT NULL,
  `ASSIGNED_TO` varchar(50) DEFAULT NULL,
  `ASSIGNED_DATE` varchar(50) DEFAULT NULL,
  `ASSIGNED_TIME` varchar(50) DEFAULT NULL,
  `PROCESS_DATE` varchar(50) DEFAULT NULL,
  `PROCESS_TIME` varchar(50) DEFAULT NULL,
  `CHANNEL` varchar(50) DEFAULT NULL,
  `SESSIONID` varchar(50) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT 'Open',
  PRIMARY KEY (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_IntentSkill_Mapping
CREATE TABLE IF NOT EXISTS `GBL_IntentSkill_Mapping` (
  `INTENT_TALENT` varchar(50) NOT NULL,
  `VDN` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  `QueueGroup` varchar(100) DEFAULT NULL,
  `CallbackSkill` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`INTENT_TALENT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_Intent_Master
CREATE TABLE IF NOT EXISTS `GBL_Intent_Master` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `IntentName` varchar(200) NOT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDate` datetime(3) NOT NULL,
  `MarkedForDeletion` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.GBL_WhatsappReply
CREATE TABLE IF NOT EXISTS `GBL_WhatsappReply` (
  `Number` varchar(20) DEFAULT NULL,
  `Message` varchar(1000) DEFAULT NULL,
  `Insert_Time` datetime(3) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.GenerateRawData
DELIMITER //
CREATE PROCEDURE `GenerateRawData`(
p_startdate varchar(8),
p_enddate varchar(8),
p_type varchar(10))
begin
-- SQLINES LICENSE FOR EVALUATION USE ONLY
select * from vw_Email_Raw_Data_View where sentDate>=p_startdate and sentDate<=p_enddate
order by SessionID,ReceivedDateTime;

end//
DELIMITER ;

-- Dumping structure for procedure OCM.GetDashboardData
DELIMITER //
CREATE PROCEDURE `GetDashboardData`(
p_ReportType	int,
p_FromDate  VARCHAR(50),
p_ToDate  VARCHAR(50),
p_Value VARCHAR(1000))
BEGIN
   DECLARE v_FromDateTime VARCHAR (50);
   DECLARE v_ToDateTime VARCHAR (50);
   
   DECLARE v_TotalAgentTransfer INT;
	DECLARE v_TriesExceeded INT;

	DECLARE v_TotalAttempts INT;
	DECLARE v_TotalIVRCalls INT;

	DECLARE v_TotalInvalidInput  INT;
	DECLARE v_TotalNoInput  INT;
   
   SET v_FromDateTime = p_FromDate;
   SET v_ToDateTime = p_ToDate;
   
   IF(p_ReportType = 1) 
		THEN
			Select E.Mailbox AS Emailbox,
			COUNT(CASE WHEN  IFNULL(E.ReceivedDate,'') != '' THEN 1 END) AS EmailRecieved,
			COUNT(CASE WHEN IFNULL(E.AssignedDate,'') != '' THEN 1 END) AS EmailAssigned,
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') != '' THEN 1 END) AS EmailReplied,
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') = '' THEN 1 END) AS EmailNotReplied,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') != '' THEN 1 END) AS EmailClosed,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') = '' THEN 1 END) AS EmailNotClosed
			FROM Email_Inbox E WHERE
			CONCAT(E.ReceivedDate,E.ReceivedTime) >= v_FromDateTime AND CONCAT(E.ReceivedDate,E.ReceivedTime) <= v_ToDateTime 
			GROUP BY E.Mailbox;
		END IF;
			
	  IF(p_ReportType = 2) 
		THEN
			Select E.Mailbox AS Emailbox,
			COUNT(CASE WHEN  IFNULL(E.ReceivedDate,'') != '' THEN 1 END) AS EmailRecieved,
			COUNT(CASE WHEN IFNULL(E.AssignedDate,'') != '' THEN 1 END) AS EmailAssigned, 
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') != '' THEN 1 END) AS EmailReplied,
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') = '' THEN 1 END) AS EmailNotReplied,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') != '' THEN 1 END) AS EmailClosed,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') = '' THEN 1 END) AS EmailNotClosed
			FROM Email_Inbox E WHERE
			CONCAT(E.ReceivedDate,E.ReceivedTime) >= v_FromDateTime AND CONCAT(E.ReceivedDate,E.ReceivedTime) <= v_ToDateTime  
			GROUP BY E.Mailbox;
		END IF;			
		
		IF(p_ReportType = 3) 
		THEN
			Select Distinct `Channel`,
			COUNT(1) as TotalInteraction, 
			COUNT(CASE WHEN IFNULL(UPPER(IsVerified),'Y') = 'Y' THEN IsVerified END) AS TotalVerifiedInteraction,
			COUNT(CASE WHEN IFNULL(UPPER(IsVerified),'Y') != 'Y' THEN IsVerified END) AS NonVerifiedInteraction
			from GBL_InteractionHistory
			GROUP BY `Channel`;
		END IF;
		
		IF(p_ReportType = 4)
		THEN
			Select COUNT(1) Into v_TotalIVRCalls FROM IVR_Call_History; 
				 
			Select COUNT(1) Into v_TotalAgentTransfer FROM IVR_Call_History WHERE  IVR_Call_History.ICH_TR_DIS_FLAG = 'AT';

			SELECT SUM(CAST(IVR_Usage.IU_EMC AS UNSIGNED)) INTO v_TriesExceeded
			FROM IVR_Usage
			INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
			INNER JOIN IVR_MENU_DESC ON IVR_MENU_DESC.IMD_MENU_ID = 
			CASE WHEN char_length(rtrim(IVR_Usage.IU_ID)) = 8 THEN IVR_Usage.IU_ID ELSE substring(IVR_Usage.IU_ID, 1, 8) END
			WHERE 
			(IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

			SELECT COUNT(IVR_MENU_DESC.IMD_MENU_ID) INTO v_TotalAttempts
			FROM IVR_Usage
			INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
			INNER JOIN IVR_MENU_DESC ON IVR_MENU_DESC.IMD_MENU_ID = 
			CASE WHEN char_length(rtrim(IVR_Usage.IU_ID)) = 8 THEN IVR_Usage.IU_ID ELSE substring(IVR_Usage.IU_ID, 1, 8) END
			WHERE 
			(IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

			SELECT  SUM(CAST(IVR_Usage.IU_ENI AS UNSIGNED)) INTO v_TotalNoInput
			FROM IVR_Usage
			INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
			INNER JOIN IVR_MENU_DESC ON IVR_MENU_DESC.IMD_MENU_ID = 
			CASE WHEN char_length(rtrim(IVR_Usage.IU_ID)) = 8 THEN IVR_Usage.IU_ID ELSE substring(IVR_Usage.IU_ID, 1, 8) END
			WHERE 
			(IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

			SELECT  SUM(CAST(IVR_Usage.IU_EII AS UNSIGNED)) INTO v_TotalInvalidInput
			FROM IVR_Usage
			INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
			INNER JOIN IVR_MENU_DESC ON IVR_MENU_DESC.IMD_MENU_ID = 
			CASE WHEN char_length(rtrim(IVR_Usage.IU_ID)) = 8 THEN IVR_Usage.IU_ID ELSE substring(IVR_Usage.IU_ID, 1, 8) END
			WHERE 
			(IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));
				
			Select 
			IFNULL(((v_TotalAttempts - IFNULL(v_TriesExceeded,1) - v_TotalAgentTransfer) * 100),1) / IFNULL(v_TotalAttempts,1)  'TaskCompletionRate',
			IFNULL(((v_TotalIVRCalls- v_TotalAgentTransfer)*100),1)/IFNULL(v_TotalIVRCalls,1) 'CallClosureRate' ,
			IFNULL(((v_TotalAttempts-v_TriesExceeded-v_TotalInvalidInput-v_TotalNoInput-v_TotalAgentTransfer)*100),1)/IFNULL(v_TotalAttempts,1) 'FirstAttemptCompletionRate';
		END IF;
		
		IF(p_ReportType = 5) 
		THEN
			Select CONCAT('QN-', CONVERT(ROW_NUMBER() OVER(ORDER BY AGENTID DESC),CHAR(50))) AS 'Row',
			SUM(CASE WHEN IFNULL(E.QN1RESULT,'') != '' THEN 1 END) AS 'VPoor',
			SUM(CASE WHEN IFNULL(E.QN2RESULT,'') != '' THEN 2 END) AS 'Poor', 
			SUM(CASE WHEN IFNULL(E.QN3RESULT,'') != '' THEN 6 END) AS 'Good',
			SUM(CASE WHEN IFNULL(E.QN4RESULT,'') != '' THEN 5 END) AS 'Excellent',
			SUM(CASE WHEN IFNULL(E.QN5RESULT,'') != '' THEN 10 END) AS 'Exceptional'
			from IVR_SURVEY_OF_CSO_REPORT E
			GROUP BY E.QN1RESULT,AGENTID LIMIT 50;
		END IF;
		
		IF(p_ReportType = 6) 
		THEN
			Select Distinct UPPER(`Channel`) 'Channel',
			COUNT(1) as 'Total'
			from GBL_InteractionHistory  Where `Channel` !=''
			GROUP BY `Channel`;
		END IF;
		
		IF(p_ReportType = 7) 
		THEN
			Select Distinct UPPER(`Status`) 'Callback Status',
			COUNT(1) as 'Value'
			from IVR_CALLBACK Where `Status` !=''
			GROUP BY `Status`
			UNION
			Select 'Total Callback',
			COUNT(1) as 'Total'
			from IVR_CALLBACK;
		END IF;

	IF(p_ReportType = 8) 
		THEN
			Select CASE WHEN IntentStatus  = 'Closed' THEN 'Happy' WHEN IntentStatus  = 'Open' THEN 'UnHappy' else 'Normal' END AS IndexName,
			COUNT(CASE WHEN IntentStatus = 'Closed' THEN 1 END) AS 'Happy', 
			COUNT(CASE WHEN IntentStatus = 'Open' THEN IsVerified END) AS 'UnHappy',
			COUNT(CASE WHEN IntentStatus Not in ( 'Closed' ,'Open') THEN IsVerified END) AS 'Normal'
			from GBL_InteractionHistory inner join GBL_IntentMapping 
			on GBL_IntentMapping.SessionID=GBL_InteractionHistory.SessionID 
			WHERE IFNULL(IntentName,'') !=''
			and GBL_IntentMapping.`channel` In ('FBPost','FBPrivate')
			GROUP BY IntentStatus;
	END IF;	
		
	  IF(p_ReportType = 9) 
		THEN
			Select distinct(I.AACCSkillName) EmailBox,
			COUNT(CASE WHEN  IFNULL(E.ReceivedDate,'') != '' THEN 1 END) AS EmailRecieved,
			COUNT(CASE WHEN IFNULL(E.AssignedDate,'') != '' THEN 1 END) AS EmailAssigned, 
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') != '' THEN 1 END) AS EmailReplied,
			COUNT(CASE WHEN IFNULL(E.RepliedDate,'') = '' THEN 1 END) AS EmailNotReplied,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') != '' THEN 1 END) AS EmailClosed,
			COUNT(CASE WHEN IFNULL(E.ClosedDate,'') = '' THEN 1 END) AS EmailNotClosed
			FROM Email_Inbox E 
			INNER JOIN AGT_Intent_Skill_Map I on E.Mailbox = I.IncomingMailBox WHERE 
			CONCAT(E.ReceivedDate,E.ReceivedTime) >= v_FromDateTime AND CONCAT(E.ReceivedDate,E.ReceivedTime) <= v_ToDateTime AND I.AACCSkillName = p_Value
			GROUP BY I.AACCSkillName;
		END IF;	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.GetExtensionCallDetails
DELIMITER //
CREATE PROCEDURE `GetExtensionCallDetails`(
p_Date varchar(8),
p_StartTime varchar(6),
p_EndTime varchar(6),
p_AgentId int,
p_Channel varchar(20)
)
Begin
	Select IFNULL(A.ExtInTime+A.ExtOutTime,0) as ExtTime, IFNULL(A.ExtInCalls+A.ExtOutCalls,0) as ExtnCalls, IFNULL(A.ACDCalls,0) as AcdCalls
	from (
	Select
	ifnull(sum(acd.acdcalls),0) as ACDCalls,
	ifnull(sum(extIn),0) as ExtInCalls, 
	ifnull(sum(extIntime),0) as ExtInTime,
	ifnull(sum(extOut),0) as ExtOutCalls, 
	ifnull(sum(extOutTime),0) as ExtOutTime
	from tmac_interactions main  
	left join(
	select distinct sessionid, count(1) acdcalls, SUM(ActiveTime) acdtime 
	from tmac_interactions   
	where calltype=1 and `channel` in (p_Channel) and agentid = p_AgentId
	group by sessionid ) acd 
	on main.sessionid = acd.sessionid 
	left join(
	select distinct sessionid, count(1) extIn, 
	SUM(ActiveTime) extIntime 
	from tmac_interactions  
	where calltype=2 and `channel` in (p_Channel) and agentid = p_AgentId
	group by sessionid ) extIn 
	on main.sessionid = extIn.sessionid 
	left join(
	select distinct sessionid, count(1) extOut, 
	SUM(ActiveTime) extOutTime 
	from tmac_interactions  
	where calltype='' and `channel` in (p_Channel) and agentid = p_AgentId
	group by sessionid ) extOut 
	on main.sessionid = extOut.sessionid 
	where `channel`  in (p_Channel) and agentid = p_AgentId and createddatetime>=CONCAT(p_Date,p_StartTime) and createddatetime<= CONCAT(p_Date,p_EndTime)) A;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.GetGridReport
DELIMITER //
CREATE PROCEDURE `GetGridReport`(
p_ReportType	INT,
p_ReportSQL LONGTEXT)
BEGIN
  IF(p_ReportType = 1)
   		THEN
 			SELECT UPPER(COLUMN_NAME)'COLUMN' FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = p_ReportSQL;
		END IF;
		
   IF(p_ReportType = 2)
		THEN
			 SET @stmt_str =  p_ReportSQ;
  			 PREPARE stmt FROM @stmt_str;
  			 EXECUTE stmt;
  			 DEALLOCATE PREPARE stmt;
	    END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.GetRealtimeData
DELIMITER //
CREATE PROCEDURE `GetRealtimeData`(
p_startdate varchar(20),
p_enddate varchar(20),
p_acceptablesla int)
begin
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
begin
	SET v_DataFromDate = p_startdate;
	SET v_DataToDate = p_enddate;

	select 
			t.Skill,
			SUM(t.ActiveTime) as ActiveTime, 
			SUM(t.HoldTime) as HoldTime, 
			SUM(t.AcwTime) as ACWTime, 
			COUNT(1) as TotalCallsInEachSkill,
			SUM(t.CallsAnsWithnSLA) as CallsAnsWithnSLA,
			SUM(QueueTime) as QueueTime,
			Max(QueueTime) as MaxWaitTime
			from (
			select 
			Case when tmac.QueueTime < p_acceptablesla then 1 else 0 end as CallsAnsWithnSLA, 
			tmac.ActiveTime as ActiveTime,
			tmac.HoldTime as HoldTime,
			tmac.AcwTime as AcwTime,
			Skill,
			tmac.QueueTime as QueueTime
			from TMAC_Interactions tmac
			where tmac.Skill is not null and tmac.Skill !='' 
			and ClosedDateTime >= v_DataFromDate and ClosedDateTime <= v_DataToDate ) t
			group by t.Skill;
end;
END//
DELIMITER ;

-- Dumping structure for function OCM.GetSkillNameListFromSkillIDList
DELIMITER //
CREATE FUNCTION `GetSkillNameListFromSkillIDList`(p_CommadelimitedSkillIDList longtext) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
		DECLARE v_IntLocation INT;
		DECLARE SkillNameList LONGTEXT;

		DROP TEMPORARY TABLE IF EXISTS SkillNameResult;
      CREATE TEMPORARY TABLE SkillNameResult (rowid int AUTO_INCREMENT PRIMARY KEY,id VARCHAR(100));
        
        WHILE (LOCATE(',', p_CommadelimitedSkillIDList, 1) > 0)
        DO
              SET v_IntLocation :=   LOCATE(',',p_CommadelimitedSkillIDList, 1);
				      
              INSERT INTO   SkillNameResult (id)
              SELECT RTRIM(LTRIM(SUBSTRING(p_CommadelimitedSkillIDList,   1, v_IntLocation-1)));
				    
              SET p_CommadelimitedSkillIDList := INSERT(p_CommadelimitedSkillIDList,   1, v_IntLocation,   '');
        END WHILE;
        
      INSERT INTO SkillNameResult (id) SELECT RTRIM(LTRIM(p_CommadelimitedSkillIDList));
        
      DROP TEMPORARY TABLE IF EXISTS SkillNameResultTemp;
      CREATE TEMPORARY TABLE SkillNameResultTemp (rowid int AUTO_INCREMENT PRIMARY KEY,id VARCHAR(100));
      
      INSERT INTO SkillNameResultTemp SELECT * FROM SkillNameResult;
        
      set SkillNameList := (SELECT group_CONCAT(SkillName) from (
		SELECT SkillName FROM TMAC_Skills
		where SkillExtension IN (SELECT ID FROM SkillNameResult)
		#WHERE (select FIND_IN_SET(SkillExtension , (SELECT ID FROM SkillNameResult)))>0
		union
		SELECT ID as SkillName FROM SkillNameResultTemp WHERE ID NOT IN (SELECT SkillExtension from TMAC_Skills)
		) Skill order by SkillName desc
		);
      
		RETURN SkillNameList;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_AgentAHT_Summary_Report
DELIMITER //
CREATE PROCEDURE `Get_AgentAHT_Summary_Report`( 
p_Agent VARCHAR(20),
p_FromDate VARCHAR(8),
p_ToDate VARCHAR(8),
p_FromTime VARCHAR(8),
p_ToTime VARCHAR(8))
BEGIN

DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

DECLARE v_EmailsAssigned INT;
DECLARE v_EmailsReplied INT;
DECLARE v_EmailsClosed INT;
DECLARE v_EmailsHandled INT;
DECLARE v_EmailsInDraft INT;
DECLARE v_EmailsTransferred INT;
DECLARE v_EmailsAverageDraftTime INT;
DECLARE v_EmailsAverageActiveTime INT;
DECLARE v_EmailsAverageHandleTime INT;
DECLARE v_EmailsAverageHoldTime INT;
DECLARE v_EmailsStaffedTime INT;

declare v_avgRepliedTime int DEFAULT 0;
declare v_avgClosedTime int DEFAULT 0;

BEGIN

	IF(IFNULL(p_Agent,'') != '')

	THEN
	
		SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
		SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		select  ifnull(count(1),0) into v_EmailsAssigned from Email_Routes  
		where AssingedDateTime>=v_DataFromDate and AssingedDateTime<=v_DataToDate 
		and AssignedTo =p_Agent;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
                      
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    Select  Count(1) Into v_EmailsReplied  from Email_Routes   
    where IFNULL(CurrentStatus,'')='Replied' and 
    RepliedDateTime>= v_DataFromDate  and RepliedDateTime<=v_DataToDate and AssignedTo = p_Agent;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	
	 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    Select COUNT(1) Into v_EmailsClosed from Email_Routes  
	 where currentstatus ='Closed' and
    IFNULL(RepliedDateTime,'0')='0' and IFNULL(ClosedDateTime,'0')<>'0' and 
    ClosedDateTime>= v_DataFromDate  and ClosedDateTime<=v_DataToDate and AssignedTo = p_Agent;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
    
    -- Transfered
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    select  Count(1) into v_EmailsInDraft from Email_Routes   
    where currentstatus ='Draft' and AssignedTo=p_Agent and
    DraftDateTime>=v_DataFromDate  and DraftDateTime<=v_DataToDate;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	
	
	-- Average Active Time
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    select ifnull(AVG(ActiveTime),0) into v_EmailsAverageActiveTime  from Email_Routes   
    where AssignedTo=p_Agent and
    AssingedDateTime>=v_DataFromDate and AssingedDateTime<=v_DataToDate;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	
	
	-- Average Hold Time
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    select ifnull(AVG(HoldTime),0) into v_EmailsAverageHoldTime  from Email_Routes  
    where AssignedTo=p_Agent and
    AssingedDateTime>=v_DataFromDate  and AssingedDateTime<=v_DataToDate;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
    
    --              
    -- SQLINES DEMO *** ime              
    -- 
    
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
     select ifnull(avg(timestampdiff(minute,
     CONVERT(CONCAT(SUBSTRING(AssingedDateTime,1,8),' ',SUBSTRING(AssingedDateTime,9,2),':',SUBSTRING(AssingedDateTime,11,2),':',SUBSTRING(AssingedDateTime,13,2)), datetime),
     CONVERT(CONCAT(SUBSTRING(RepliedDateTime,1,8),' ',SUBSTRING(RepliedDateTime,9,2),':',SUBSTRING(RepliedDateTime,11,2),':',SUBSTRING(RepliedDateTime,13,2)), datetime))),0) into v_avgRepliedTime
	 from Email_Routes  
	 where  ifnull(currentstatus,'')='Replied' and 
		RepliedDateTime>=v_DataFromDate  and RepliedDateTime<=v_DataToDate and AssignedTo =p_Agent;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
                          
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    select ifnull(avg(timestampdiff(minute,
     CONVERT(CONCAT(SUBSTRING(AssingedDateTime,1,8),' ',SUBSTRING(AssingedDateTime,9,2),':',SUBSTRING(AssingedDateTime,11,2),':',SUBSTRING(AssingedDateTime,13,2)), datetime),
     CONVERT(CONCAT(SUBSTRING(ClosedDateTime,1,8),' ',SUBSTRING(ClosedDateTime,9,2),':',SUBSTRING(ClosedDateTime,11,2),':',SUBSTRING(ClosedDateTime,13,2)), datetime))),0) into v_avgClosedTime
	 from Email_Routes  
	 where  ifnull(currentstatus,'')='Closed' and	
		ClosedDateTime>=v_DataFromDate  and ClosedDateTime<=v_DataToDate and AssignedTo =p_Agent;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		
     if(v_avgRepliedTime>0 and  v_avgClosedTime>0)
		then
			set v_EmailsAverageHandleTime=  v_avgClosedTime;
    else
			set v_EmailsAverageHandleTime= v_avgRepliedTime+ v_avgClosedTime;
		end if;
	
	
	END IF;

    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    Select
    Ifnull(v_EmailsAssigned,0) EmailsAssigned,
    Ifnull(v_EmailsStaffedTime,0) EmailsStaffedTime,
    Ifnull(v_EmailsReplied,0) EmailsReplied,
    Ifnull(v_EmailsClosed,0) EmailsClosed,
    Ifnull(v_EmailsHandled,0) EmailsHandled,
    Ifnull(v_EmailsInDraft,0) EmailsInDraft,
    Ifnull(v_EmailsTransferred,0) EmailsTransferred,
    Ifnull(v_EmailsAverageDraftTime,0) EmailsAverageDraftTime,
    Ifnull(v_EmailsAverageActiveTime,0) EmailsAverageActiveTime,
     Ifnull(v_EmailsAverageHoldTime,0) EmailsAverageHoldTime,
    Ifnull(v_EmailsAverageHandleTime,0) EmailsAverageHandleTime;
    	
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_AgentCallDivertedReport
DELIMITER //
CREATE PROCEDURE `Get_AgentCallDivertedReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_Where varchar(20))
BEGIN

    Drop temporary table if exists Temp;
    Create temporary table Temp (ID bigint,AGENTID varchar(50),SESSIONID varchar(50),CALLCONNECTEDTIME varchar(50),CALLTYPE varchar(50),ROWNUM INT);

	Insert into Temp 
	select m.ID,m.AGENTID,m.SESSIONID,m.CALLCONNECTEDTIME , 'aaaaaaaaaaaaaaaaa' CALLTYPE,
	row_number() OVER(PARTITION BY CALLCONNECTEDTIME ORDER BY CALLCONNECTEDTIME asc)  ROWNUM
	from tmac_interactions m 
	inner join ( 
	select  sessionid, count(1) c from tmac_interactions 
	where CALLTYPE=1 and char_length(rtrim(dnis))=4 AND VARCHARTODATETIME(CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(CreatedDateTime ) <= p_ToDate 
	group by sessionid
	)  M1 on M.SessionId=M1.SessionId where c>1   
	AND VARCHARTODATETIME(m.CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(m.CreatedDateTime) <= p_ToDate 
	group by m.id,m.agentid,m.SessionId,m.CALLCONNECTEDTIME,c 
	order by  m.sessionid,m.id ASC;

	update Temp set CALLTYPE='ANS' WHERE ROWNUM=1;

	update Temp set CALLTYPE='DVT' where  substring(CALLCONNECTEDTIME,9,char_length(rtrim(CALLCONNECTEDTIME)))='000000' AND 
	ID NOT IN ( SELECT MAX(ID) FROM Temp where  substring(CALLCONNECTEDTIME,9,char_length(rtrim(CALLCONNECTEDTIME)))='000000' AND calltype!='ANS'  GROUP BY SESSIONID
	HAVING COUNT(1) >1 );


	UPDATE  Temp set calltype='ABN' where substring(CALLCONNECTEDTIME,9,char_length(rtrim(CALLCONNECTEDTIME)))='000000' AND ID  IN ( SELECT MAX(ID) FROM 
	Temp WHERE  SessionId NOT IN (SELECT SessionId FROM Temp WHERE calltype='ANS' ) GROUP BY SessionId );


	UPDATE Temp set calltype='DVT' where calltype='aaaaaaaaaaaaaaaaa';


	Insert into Temp 
	select m.ID, m.agentid,m.SessionId,m.CALLCONNECTEDTIME,'ABN',
	row_number() OVER(PARTITION BY CALLCONNECTEDTIME ORDER BY CALLCONNECTEDTIME asc)  ROWNUM
	from tmac_interactions m 
	left join ( 
	select  sessionid, count(1) c from tmac_interactions 
	where CALLTYPE=1 and char_length(rtrim(dnis))=4 AND VARCHARTODATETIME(CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(CreatedDateTime ) <= p_ToDate 
	group by sessionid
	)  M1 on M.SessionId=M1.SessionId where c=1 and  substring(M.CALLCONNECTEDTIME,9,char_length(rtrim(M.CALLCONNECTEDTIME)))='000000'
	AND VARCHARTODATETIME(M.CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(M.CreatedDateTime ) <= p_ToDate;

	Insert into Temp 
	select m.ID,m.agentid,m.SessionId,m.CALLCONNECTEDTIME,'ANS',
	row_number() OVER(PARTITION BY CALLCONNECTEDTIME ORDER BY CALLCONNECTEDTIME asc)  ROWNUM
	from tmac_interactions m 
	left join ( 
	select  sessionid, count(1) c from tmac_interactions 
	where CALLTYPE=1 and char_length(rtrim(dnis))=4 AND VARCHARTODATETIME(CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(CreatedDateTime ) <= p_ToDate 
	group by sessionid
	)  M1 on M.SessionId=M1.SessionId where c=1 and  substring(M.CALLCONNECTEDTIME,9,char_length(rtrim(M.CALLCONNECTEDTIME)))!='000000'
	AND VARCHARTODATETIME(M.CreatedDateTime ) >= p_FromDate AND VARCHARTODATETIME(M.CreatedDateTime ) <= p_ToDate;

	SELECT T.AgentId,CONCAT(IFNULL(A.FirstName,''),IFNULL(A.LastName,'')) AgentName, 
	SUM(CallsPresented)-SUM(CallsABN) as CallsPresented,SUM(CallsDVT) CallsDiverted,
	SUM(CallsHandled) CallsHandled,SUM(CallsABN) CallAbbandend,
	convert(convert(SUM(CallsHandled),float)/convert(SUM(CallsPresented)-SUM(CallsABN),float) * 100,decimal(5,2)) as GOS 
	FROM (
	SELECT AGENTID, count(1) CallsPresented, 
	case when CALLTYPE='ANS' THEN COUNT(1) ELSE 0 END CallsHandled, 
	case when CALLTYPE='DVT' THEN COUNT(1) ELSE 0 END CallsDVT,
	case when CALLTYPE='ABN' THEN COUNT(1) ELSE 0 END CallsABN
	FROM Temp X  group by AGENTID,CALLTYPE) T 
	LEFT JOIN AGT_Agent A ON A.AvayaLoginID=T.AgentId 
	group by  AGENTID,A.FirstName,A.LastName;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_AgentDetailReport
DELIMITER //
CREATE PROCEDURE `Get_AgentDetailReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_AgentId VARCHAR(20))
BEGIN

DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_SkillList VARCHAR(1000);
DECLARE v_Loginhour INT;

DECLARE v_mailCount INT;
declare v_Id VARCHAR(50);
declare v_AgentName VARCHAR(50);
declare v_counter int DEFAULT 0;

DECLARE v_auxCount INT;
declare v_startDate VARCHAR(50);
declare v_endDate VARCHAR(50);
declare v_auxcounter int DEFAULT 1;

DECLARE v_AgentCount INT;
DECLARE v_ChannelCount INT;
declare v_Channel VARCHAR(50);
declare v_AHT VARCHAR(50);
declare v_Channelcounter int DEFAULT 0;

DECLARE v_status INT;
SET v_status := BreakStringIntoRows(v_SkillList);

DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT,AgentID varchar(50),AgentName varchar(50));

DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
CREATE TEMPORARY TABLE Result_TempTable (AgentID VARCHAR(50),AgentName VARCHAR(50),TotalHoursLoggedIn INT);

BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate;
	IF(p_Type = 'MAIN')
	THEN	
	INSERT INTO Calculation_TempTable
	SELECT  DISTINCT(AgentID),A.UserName FROM AGT_Agent_TimeTrack I LEFT JOIN AGT_Agent A ON A.AvayaLoginID=I.AgentID;
			
	SET v_mailCount = (SELECT COUNT(1) FROM Calculation_TempTable);
	
			WHILE(v_counter<v_mailCount)
			DO
				SET v_counter=v_counter+1;
						
				set v_Id = (select AgentID from Calculation_TempTable where ID=v_counter group by AgentID);
				set v_AgentName = (select AgentName from Calculation_TempTable where ID=v_counter group by AgentName);
				Select  SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(A.LoginDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
				CONVERT(INSERT(INSERT(INSERT(A.LogoutDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_Loginhour
				FROM (SELECT DISTINCT AgentID,CONCAT(LoginDate,LoginTime) AS LoginDateTime ,CONCAT(LogoutDate,LogoutTime) AS LogoutDateTime FROM AGT_Agent_TimeTrack Where AgentID=v_Id) A;
				
				
				INSERT INTO Result_TempTable VALUES(v_Id,v_AgentName,ifnull(v_Loginhour,0)); 
	        END WHILE;
        	SELECT * FROM Result_TempTable;
	END IF;
	IF(p_Type = 'InteractionsHandled')
	THEN
      select DISTINCT Channel,COUNT(1) AS COUNT from TMAC_Interactions where AgentId=p_AgentId Group by Channel; 
    
	END IF;
	IF(p_Type = 'Skill')
	THEN
	      select DISTINCT  SkillList into v_SkillList from AGT_Agent_TimeTrack  where AgentID = p_AgentId;
			select id as SkillList from BreakStringIntoRowsResult;
			
	END IF;
	IF(p_Type = 'CSAT')
	THEN
					Select * from (
					Select 'Q1' AS QNType,
					SUM(CASE WHEN ( ISNUMERIC(E.QN1RESULT) = 0 AND IFNULL(E.QN1RESULT,'NO') ='NO' )  THEN 1 else 0 END) AS 'VPoor',
					0 AS 'Poor', 
					0 AS 'Good',
					0 AS 'Excellent',
					SUM(CASE WHEN ( ISNUMERIC(E.QN1RESULT) = 0 AND IFNULL(E.QN1RESULT,'NO') ='YES' )  THEN 1 else 0 END) AS 'Exceptional'
					from IVR_SURVEY_OF_CSO_REPORT E 

					UNION

					Select 'Q2' AS QNType,
					SUM(CASE WHEN ISNUMERIC(E.QN2RESULT) = 1  THEN 1 else 0 END) AS 'VPoor',
					SUM(CASE WHEN ISNUMERIC(E.QN2RESULT) = 2  THEN 1 else 0 END) AS 'Poor', 
					SUM(CASE WHEN ISNUMERIC(E.QN2RESULT) = 3  THEN 1 else 0 END) AS 'Good',
					SUM(CASE WHEN ISNUMERIC(E.QN2RESULT) = 4  THEN 1 else 0 END) AS 'Excellent',
					SUM(CASE WHEN ISNUMERIC(E.QN2RESULT) = 5 THEN 1 else 0 END) AS 'Exceptional'
					from IVR_SURVEY_OF_CSO_REPORT E 

					UNION

					Select 'Q3' AS QNType,
					SUM(CASE WHEN ISNUMERIC(E.QN3RESULT) = 1  THEN 1 else 0 END) AS 'VPoor',
					SUM(CASE WHEN ISNUMERIC(E.QN3RESULT) = 2  THEN 1 else 0 END) AS 'Poor', 
					SUM(CASE WHEN ISNUMERIC(E.QN3RESULT) = 3  THEN 1 else 0 END) AS 'Good',
					SUM(CASE WHEN ISNUMERIC(E.QN3RESULT) = 4  THEN 1 else 0 END) AS 'Excellent',
					SUM(CASE WHEN ISNUMERIC(E.QN3RESULT) = 5 THEN 1 else 0 END) AS 'Exceptional'
					from IVR_SURVEY_OF_CSO_REPORT E

					UNION

					Select 'Q4' AS QNType,
					SUM(CASE WHEN ISNUMERIC(E.QN4RESULT) = 1  THEN 1 else 0 END) AS 'VPoor',
					0 AS 'Poor', 
					0 AS 'Good',
					0 AS 'Excellent',
					SUM(CASE WHEN ISNUMERIC(E.QN4RESULT) = 2 THEN 1 else 0 END) AS 'Exceptional'
					from IVR_SURVEY_OF_CSO_REPORT E 
					)as tab;

	END IF;
	IF(p_Type = 'AUXModes')
	THEN
	
	DROP TEMPORARY TABLE IF EXISTS CalculateAuxMode;
	CREATE TEMPORARY TABLE CalculateAuxMode (ID INT AUTO_INCREMENT, AgentID varchar(50), `TimeStamp` varchar(50),`Status` varchar(50), StartDate varchar(50),EndDate varchar(50));
	
	INSERT INTO CalculateAuxMode
	SELECT `AgentID`,`TimeStamp`,`Status`,`TimeStamp`,`TimeStamp` FROM AGT_Agent_StatusTrack  WHERE AgentID=p_AgentId  order by Id;
	
	SET v_auxCount = (SELECT COUNT(1) FROM CalculateAuxMode);
	
			WHILE(v_auxcounter<v_auxCount)
			DO
				SET v_auxcounter=v_auxcounter+1;
						
				set v_startDate = (select `TimeStamp` from CalculateAuxMode where ID=v_auxcounter+1 group by `TimeStamp`);
				if (v_startDate!='NULL')
				THEN
				UPDATE CalculateAuxMode
						SET EndDate=v_startDate
						WHERE ID=v_auxcounter;
				END IF;		
	        END WHILE;
	        
	Select SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(A.StartDate, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
				CONVERT(INSERT(INSERT(INSERT(A.EndDate, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime)))AS `Time`,`Status`
				FROM (SELECT * from CalculateAuxMode) A group by `Status`;
	  
	END IF;
    IF(p_Type = 'AHT')
	THEN
			DROP TEMPORARY TABLE IF EXISTS Calculate_AHT;
			CREATE TEMPORARY TABLE Calculate_AHT (ID INT AUTO_INCREMENT, Channel varchar(50));
			DROP TEMPORARY TABLE IF EXISTS Result_AHT;
			CREATE TEMPORARY TABLE Result_AHT (Channel VARCHAR(50),AHT VARCHAR(50));
			
			INSERT INTO Calculate_AHT
			SELECT  DISTINCT Channel FROM TMAC_Interactions where AgentId = p_AgentId;
			SET v_ChannelCount = (SELECT COUNT(1) FROM Calculate_AHT);
			
					WHILE(v_Channelcounter<v_ChannelCount)
					DO
						SET v_Channelcounter=v_Channelcounter+1;
						set v_Channel = (select Channel from Calculate_AHT where ID=v_Channelcounter group by Channel);
						select COUNT(1) into v_AgentCount from TMAC_Interactions where AgentId = p_AgentId AND Channel=v_Channel;
			   
						Select v_AHT= (SUM(ActiveTime)+SUM(HoldTime))/v_AgentCount from TMAC_Interactions Where AgentId = p_AgentId AND Channel=v_Channel;
						INSERT INTO Result_AHT VALUES(v_Channel,ifnull(v_AHT,0)); 
					END WHILE;
					Select * from Result_AHT;
	END IF;
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_AgentPerformance_Report
DELIMITER //
CREATE PROCEDURE `Get_AgentPerformance_Report`(
	p_StartDate VARCHAR(50),
	p_EndDate VARCHAR(50)
)
BEGIN
-- SQLINES DEMO *** IABLES
DECLARE v_AgentCount int;
DECLARE v_mailbox varchar (50);
DECLARE v_Email_Assigned INT;
DECLARE v_email_Completed_With_Reply INT;
DECLARE v_email_Completed_Without_Reply INT;
DECLARE v_emails_Handled INT;
DECLARE v_emails_Rejected INT;
DECLARE v_active_Time DOUBLE;
DECLARE v_avg_Draft_Time INT;
DECLARE v_no_Transfers INT;
DECLARE v_emails_ignored INT;
DECLARE v_emails_deleted INT;


-- DECLARING ALL TABLES

DROP TEMPORARY TABLE IF EXISTS MailAccounts;
CREATE TEMPORARY TABLE MailAccounts (ID int AUTO_INCREMENT, MailAccounts varchar (50));

DROP TEMPORARY TABLE IF EXISTS Performance;
CREATE TEMPORARY TABLE Performance (
mailbox varchar (50),
Email_Assigned INT,
email_Completed_With_Reply INT,
email_Completed_Without_Reply INT,
emails_Handled INT,
emails_Rejected INT,
active_Time DOUBLE,
avg_Draft_Time INT,
no_Transfers INT,
emails_ignored INT,
emails_deleted INT);


--  SQLINES DEMO *** illTable
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
INSERT INTO MailAccounts 
SELECT DISTINCT MailAccountName as MailAccounts  FROM Email_AccountConfiguration;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;

SET v_AgentCount = (SELECT COUNT(1) FROM MailAccounts);


--  SQLINES DEMO *** formance TABLE

WHILE (v_AgentCount >= 1 )
DO

SET v_mailbox = (SELECT MailAccounts FROM MailAccounts WHERE ID = v_AgentCount);
SET v_Email_Assigned = (SELECT COUNT(1) FROM Email_Inbox WHERE AssignedDate >= p_StartDate AND AssignedDate <= p_EndDate and mailbox = v_mailbox);
SET v_email_Completed_With_Reply = (SELECT COUNT(1) FROM Email_Inbox where IFNULL(repliedStatus,0)<>0 and SentDate >= p_StartDate AND SentDate<=p_EndDate AND mailbox = v_mailbox);
SET v_emails_deleted = (SELECT COUNT(1) FROM Email_Inbox WHERE (IFNULL(Deleted,0)<>0 AND SentDate >= p_StartDate AND SentDate <= p_EndDate AND mailbox = v_mailbox));
SET v_active_Time = (select CAST((SELECT SUM(ActiveTime) FROM Email_Inbox WHERE (mailbox = v_mailbox AND sentdate>= p_StartDate AND  sentdate<= p_EndDate )) AS FLOAT)/ CAST((SELECT COUNT(1) FROM Email_Inbox WHERE (mailbox = v_mailbox AND sentdate>= p_StartDate AND  sentdate<= p_EndDate )) AS FLOAT));

-- FOR M --
	SET v_email_Completed_Without_Reply = (SELECT COUNT(1) FROM Email_Inbox where IFNULL(repliedStatus,0) =0 AND IFNULL(ClosedDate,0)<>0  AND SentDate>=p_StartDate AND SentDate<= p_EndDate AND mailbox = v_mailbox);
	SET v_emails_Handled = (SELECT COUNT(1) FROM Email_Inbox WHERE (IFNULL(repliedStatus,0)<>0 OR IFNULL(ClosedDate,0)<>0)
							AND SentDate>=p_StartDate AND SentDate<= p_EndDate AND mailbox = v_mailbox);
							
	--  SQLINES DEMO *** e = (SELECT ISNULL((SELECT SUM(DATEPART(DAY,CONVERT(DATE,ActionDate))) FROM Email_Inbox I INNER JOIN Email_Actions A on A.SessionID = I.SessionID with (nolock) WHERE ( A.Action = 'Draft' )and A.ActionDate>=@StartDate AND A.ActionDate<=@EndDate and cmskill = @skills and A.ActionBy  = @myAgent)/(Select Count(1) as Draft from Email_Inbox I Inner join Email_Actions A on A.SessionID = I.SessionID  WHERE ( A.Action = 'Draft' )and A.ActionDate>= @StartDate AND A.ActionDate<=@EndDate AND cmskill = @skills AND A.ActionBy  = @myAgent),0));
	--  SQLINES DEMO *** = (SELECT COUNT(1) as Transfers from Email_Inbox I Inner join Email_Actions A on A.SessionID = I.SessionID  A.ActionDate>= @StartDate AND ActionDate<= @EndDate  AND cmskill = @skills AND ActionBy = @myAgent);
	--  SQLINES DEMO *** ed = 0;
	SET v_emails_ignored = 0;


         
                             
INSERT INTO Performance 
SELECT 
v_mailbox,
IFNULL(v_Email_Assigned,0),
IFNULL(v_email_Completed_With_Reply,0),
IFNULL(v_email_Completed_Without_Reply,0),
IFNULL(v_emails_Handled,0),
IFNULL(v_emails_Rejected,0) ,
IFNULL(v_active_Time,0),
IFNULL(v_avg_Draft_Time,0) ,
IFNULL(v_no_Transfers,0),
IFNULL(v_emails_ignored ,0),
IFNULL(v_emails_deleted,0);

SET v_AgentCount = v_AgentCount-1; 

SET v_Email_Assigned = 0;
SET v_email_Completed_With_Reply=0 ; 
SET v_email_Completed_Without_Reply=0;
SET v_emails_Handled=0;
SET v_emails_Rejected =0;
SET v_active_Time =0;
SET v_avg_Draft_Time =0;
SET v_no_Transfers =0;
SET v_emails_ignored =0;
SET v_emails_deleted =0;


END WHILE;
-- SQLINES LICENSE FOR EVALUATION USE ONLY
SELECT * FROM Performance;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Agents_Staffed
DELIMITER //
CREATE PROCEDURE `Get_Agents_Staffed`(p_Type VARCHAR(10))
BEGIN
DECLARE v_AgentCount INT;

DECLARE v_currentID INT;
DECLARE v_AgentID VARCHAR(50);
DECLARE v_MailBoxId VARCHAR(50);
DECLARE v_MailBoxName VARCHAR(50);
DECLARE v_SkillList LONGTEXT;

DECLARE v_status INT;
SET v_status := BreakStringIntoRows(v_SkillList);

DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT, AgentID VARCHAR(50),SkillList LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
CREATE TEMPORARY TABLE Result_TempTable (AgentID VARCHAR(50),MailBoxId VARCHAR(50), MailBoxName VARCHAR(50));

BEGIN
      INSERT INTO Calculation_TempTable
      SELECT A.AgentID,A.SkillList FROM AGT_Agent_TimeTrack A
      WHERE( A.LogoutDate IS NULL AND A.LogoutTime IS NULL) OR ( A.LogoutDate = '' OR A.LogoutDate = '');

      SET v_AgentCount = (SELECT COUNT(1) FROM Calculation_TempTable);

      WHILE(v_AgentCount > 0)     
	  	DO
      
      SET v_currentID =(SELECT ID FROM Calculation_TempTable LIMIT 1);
      SET v_AgentID = (SELECT AgentID FROM Calculation_TempTable WHERE ID = v_currentID);      
      SET v_SkillList = (SELECT SkillList FROM Calculation_TempTable WHERE ID = v_currentID);    

      IF NOT EXISTS(SELECT AgentID FROM Result_TempTable WHERE AgentID = v_AgentID)
      THEN
            INSERT INTO Result_TempTable VALUES(v_AgentID,'','');
      END IF;
      	IF(p_Type = 'amac')
      	THEN
			SELECT `IncomingMailBox`, `AACCSkillName` INTO v_MailBoxId, v_MailBoxName
			FROM Email_Inbox_c E INNER JOIN AGT_Intent_Skill_Map A ON E.Mailbox = A.IncomingMailBox
			WHERE A.CMSkillID IN (Select ID from BreakStringIntoRowsResult) and A.CMCheckerSkillID IN (Select ID from BreakStringIntoRowsResult);
		END IF;
		IF(p_Type = 'tmac')
      	THEN
         SELECT `MailBoxId`, `MailAccountName` INTO v_MailBoxId, v_MailBoxName
			FROM Email_SkillMap E INNER JOIN Email_AccountConfiguration C ON C.MailAccountID = E.MailBoxId
			WHERE `MakerSkill` IN (Select ID from BreakStringIntoRowsResult) and `CheckerSkill` IN (Select ID from BreakStringIntoRowsResult);
		END IF;
            UPDATE Result_TempTable
            SET MailBoxId = v_MailBoxId,
            MailBoxName = v_MailBoxName
            WHERE AgentID = v_AgentID;

            DELETE FROM Calculation_TempTable WHERE ID = v_currentID;
            SET v_AgentCount = (SELECT COUNT(1) FROM Calculation_TempTable);
      END WHILE;
      SELECT * FROM Result_TempTable;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Agents_Staffed_Email
DELIMITER //
CREATE PROCEDURE `Get_Agents_Staffed_Email`(p_Type VARCHAR(10))
BEGIN 
	DECLARE v_AgentFinalCount INT;
   DECLARE v_AgentCount INT;
   
   DECLARE v_currentID INT;
   DECLARE v_AgentID VARCHAR(50);
   DECLARE v_MailBoxId VARCHAR(50);
   DECLARE v_MailBoxName VARCHAR(50);
	DECLARE v_SkillList LONGTEXT;
      
DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT PRIMARY KEY, AgentID VARCHAR(50),SkillList LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
CREATE TEMPORARY TABLE Result_TempTable (AgentID VARCHAR(50),MailBoxId VARCHAR(50), MailBoxName VARCHAR(50));

BEGIN
      INSERT INTO Calculation_TempTable (AgentID, SkillList)
		SELECT DISTINCT A.AgentID , '' FROM AGT_Agent_TimeTrack A
      WHERE( A.LogoutDate IS NULL AND A.LogoutTime IS NULL) OR ( A.LogoutDate = ''  AND A.LogoutTime = '');
  
      SET v_AgentCount = (SELECT COUNT(1) FROM Calculation_TempTable);
	   SET v_AgentFinalCount = v_AgentCount;

      WHILE(v_AgentCount > 0)
      DO
      
      SET v_currentID =(SELECT ID FROM Calculation_TempTable LIMIT 1);
      SET v_AgentID = (SELECT AgentID FROM Calculation_TempTable WHERE ID = v_currentID);      
      SET v_SkillList = (SELECT SkillList FROM Calculation_TempTable WHERE ID = v_currentID);    
 
      IF NOT EXISTS(SELECT AgentID FROM Result_TempTable WHERE AgentID = v_AgentID)
      THEN
            INSERT INTO Result_TempTable VALUES(v_AgentID,'','');
      END IF;
      	IF(p_Type = 'amac')
      	THEN
			SELECT `IncomingMailBox`, `AACCSkillName` INTO v_MailBoxId,v_MailBoxName
			FROM Email_Inbox E INNER JOIN AGT_Intent_Skill_Map A ON E.Mailbox = A.IncomingMailBox
			WHERE FIND_IN_SET(A.CMSkillID, v_SkillList)>0 and FIND_IN_SET(A.CMCheckerSkillID, v_SkillList)>0;
		END IF;
		IF(p_Type = 'tmac')
      	THEN
			SELECT `MailBoxId`, `MailAccountName` INTO v_MailBoxId, v_MailBoxName
			FROM Email_SkillMap E INNER JOIN Email_AccountConfiguration C ON C.MailAccountID = E.MailBoxId
			WHERE FIND_IN_SET(`MakerSkill`, v_SkillList)>0 and FIND_IN_SET(`CheckerSkill`,v_SkillList)>0;

		END IF;
            UPDATE Result_TempTable
            SET MailBoxId = v_MailBoxId,
            MailBoxName = v_MailBoxName
            WHERE AgentID = v_AgentID;

            DELETE FROM Calculation_TempTable WHERE ID = v_currentID;
            
            SET v_AgentCount = (SELECT COUNT(1) FROM Calculation_TempTable);
      END WHILE;
       
      	SELECT v_AgentFinalCount as 'Count', MailAccountID as MailboxId, `MailAccountName` as MailboxName 
			FROM Email_AccountConfiguration C Where `Enabled` = 1;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Agent_PerformanceDrill
DELIMITER //
CREATE PROCEDURE `Get_Agent_PerformanceDrill`(
p_Agent VARCHAR(20), 
p_FromDate VARCHAR(8), 
p_ToDate VARCHAR(8), 
p_FromTime VARCHAR(8), 
p_ToTime VARCHAR(8), 
p_DrillType VARCHAR(20),
p_OrgUnit TEXT
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	IF(IFNULL(p_Agent,'') != '')
	THEN
	SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
	SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);
	IF(p_DrillType = 'EmailsAssigned')
	THEN
	SELECT A.SessionID, A.AssingedDateTime, I.From, I.Subject, I.Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, 
	A.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes A inner join Email_Inbox I on A.SessionID = I.SessionID
	WHERE
	A.AssingedDateTime>=v_DataFromDate and AssingedDateTime<=v_DataToDate 
	and A.AssignedTo =p_Agent AND
	I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	ELSEIF (p_DrillType = 'EmailsReplied')
	THEN
	SELECT A.SessionID, A.AssingedDateTime, B.From, B.Subject, B.Intent, A.CurrentStatus, A.RepliedDateTime as ActionDateTime, 
	A.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes A inner join Email_Inbox B on  A.SessionID=B.SessionID
		Where A.RepliedDateTime>= v_DataFromDate and A.RepliedDateTime<= v_DataToDate and A.AssignedTo = p_Agent 
		and (A.CurrentStatus = 'Replied' or A.currentStatus='Closed' )
		and B.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	ELSEIF (p_DrillType = 'EmailsWithoutReplied')
	THEN
	SELECT A.SessionID, A.AssingedDateTime, I.From, I.Subject, I.Intent, A.CurrentStatus, A.ClosedDateTime as ActionDateTime, 
	A.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes A inner join Email_Inbox I on A.SessionID = I.SessionID
	WHERE A.CurrentStatus = 'Closed'  and A.RepliedDateTime is null 
	and A.ClosedDateTime>= v_DataFromDate and A.ClosedDateTime<= v_DataToDate and A.AssignedTo = p_Agent
	and I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	ELSEIF (p_DrillType = 'EmailsInDraft')
	THEN
	SELECT  R.SessionID, R.AssingedDateTime, I.From, I.Subject, I.Intent, R.CurrentStatus, R.DraftDateTime as ActionDateTime, 
	R.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes R inner join Email_Inbox I on R.SessionID = I.SessionID
	Where R.CurrentStatus = 'Draft' and  R.DraftDateTime >= v_DataFromDate 
		and R.DraftDateTime<= v_DataToDate and R.AssignedTo = p_Agent
		and I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	ELSEIF (p_DrillType = 'EmailsTransferred')
	THEN	
	SELECT R.SessionID, R.AssingedDateTime, I.From, I.Subject, I.Intent, R.CurrentStatus, R.RouteDateTime as ActionDateTime, 
	R.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes R inner join Email_Inbox I on R.SessionID = I.SessionID
	Where R.AssingedDateTime >= v_DataFromDate and R.AssingedDateTime <= v_DataToDate and R.AssignedTo = p_Agent and ( R.RouteReason = 'TransferToAgent' OR R.RouteReason = 'TransferToSkill');
	ELSEIF (p_DrillType = 'EmailsRejected')
	THEN	
	SELECT R.SessionID, R.AssingedDateTime, I.From, I.Subject, I.Intent, R.CurrentStatus, R.RepliedDateTime as ActionDateTime, 
	R.ATTACHMENTINFO as AttachmentInfo FROM Email_Routes R inner join Email_Inbox I on R.SessionID = I.SessionID
	Where AssingedDateTime >= v_DataFromDate and AssingedDateTime <= v_DataToDate and R.AssignedTo = p_Agent
	and ( R.CurrentStatus = 'EditRejectedByChecker' or R.CurrentStatus = 'RejectedBychecker');	
	END IF;
END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Agent_PerformanceMain
DELIMITER //
CREATE PROCEDURE `Get_Agent_PerformanceMain`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20), 
p_FromTime VARCHAR(20), 
p_ToTime VARCHAR(20), 
p_CurrDateTime VARCHAR(20),
 p_OrgUnit TEXT
)
BEGIN

DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_EmailsStaffedTime INT;
DECLARE v_EmailsAssigned INT;
DECLARE v_EmailsReplied INT;
DECLARE v_EmailsWithoutReplied INT;
DECLARE v_EmailsTransferred INT;
DECLARE v_EmailsInDraft INT;
DECLARE v_TotalActiveEmailCount INT;
DECLARE v_TotalActiveTime INT;
DECLARE v_EmailsAverageActiveTime INT;
DECLARE v_TotalDraftEmailCount INT;
DECLARE v_TotalDraftTime INT;
DECLARE v_EmailsAverageDraftTime INT;
DECLARE v_EmailsAverageHandleTime INT;
DECLARE v_TotalSkillsAssigned INT;
DECLARE v_EmailsRejected INT;

DECLARE v_agentCount INT;
DECLARE v_currentID INT;
DECLARE v_Agent VARCHAR(20);
DECLARE v_agentName VARCHAR(50);


DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT PRIMARY KEY, AgentID varchar(10), AgentName VARCHAR(50));
DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
CREATE TEMPORARY TABLE Result_TempTable (agentID varchar(10), agentName VARCHAR(50), EmailsStaffedTime INT, 
EmailsAssigned INT, EmailsReplied INT, EmailsWithoutReplied INT, EmailsTransferred INT, EmailsInDraft INT,
EmailsAverageActiveTime INT, EmailsAverageDraftTime INT, EmailsAverageHandleTime INT,
EmailsRejected INT, TotalSkillsAssigned INT);


BEGIN		
	SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
	SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);
	INSERT INTO Calculation_TempTable (AgentID,AgentName) 
	SELECT DISTINCT A.AvayaLoginID as Agent , Concat(Ifnull(A.Firstname,A.AvayaLoginID ) ,' ', Ifnull(A.LastName,'')) AS AgentName 
	FROM Email_Routes R INNER JOIN AGT_Agent A ON R.AssignedTo = A.AvayaLoginID 
	INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID WHERE 1=1 
	AND R.AssingedDateTime>= v_DataFromDate AND R.AssingedDateTime<= v_DataToDate AND 
	I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));

	SET v_agentCount = (SELECT COUNT(1) FROM Calculation_TempTable);	

	WHILE(v_agentCount>0)	
	DO
		
		SET v_currentID =(SELECT ID FROM Calculation_TempTable LIMIT 1);
		SET v_Agent = (SELECT AgentID FROM Calculation_TempTable WHERE ID=v_currentID);	
		SET v_agentName = (SELECT agentName FROM Calculation_TempTable WHERE ID=v_currentID);	 
		
		IF NOT EXISTS(SELECT AgentID FROM Result_TempTable WHERE AgentID = v_Agent)
		THEN
			INSERT INTO Result_TempTable VALUES(v_Agent,v_agentName,0,0,0,0,0,0,0,0,0,0,0);
		END IF;		
							
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		select  ifnull(count(1),0) into v_EmailsAssigned from Email_Routes  R 
		INNER JOIN Email_Inbox I  ON I.SessionID = R.SessionID
		where AssingedDateTime>=v_DataFromDate and AssingedDateTime<=v_DataToDate 
		and R.AssignedTo =v_Agent AND
		I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		Select  Count(1) Into v_EmailsReplied  from Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		WHERE  (R.CurrentStatus = 'Replied' OR R.currentStatus='Closed' ) and
		RepliedDateTime>= v_DataFromDate  and RepliedDateTime<=v_DataToDate and R.AssignedTo = v_Agent AND
		I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
 		Select COUNT(1) Into v_EmailsWithoutReplied from Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
	     WHERE R.currentstatus ='Closed' and
         IFNULL(RepliedDateTime,'0')='0' and IFNULL(ClosedDateTime,'0')<>'0' and 
         ClosedDateTime>= v_DataFromDate  and ClosedDateTime<=v_DataToDate and R.AssignedTo = v_Agent AND
		 I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
 		select  Count(1) into v_EmailsInDraft from Email_Routes R 
		 INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID  
         WHERE R.currentstatus ='Draft' and R.AssignedTo=v_Agent and
         DraftDateTime>=v_DataFromDate  and DraftDateTime<=v_DataToDate AND
		 I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	
		Select COUNT(1) Into v_EmailsTransferred FROM Email_Routes R 
		INNER JOIN Email_Inbox I  ON I.SessionID = R.SessionID
		Where AssingedDateTime >= v_DataFromDate and AssingedDateTime <= v_DataToDate and R.AssignedTo = v_Agent 
		and ( RouteReason = 'TransferToAgent' OR RouteReason = 'TransferToSkill') AND
		 I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		
		Select COUNT(distinct R.SessionID) Into v_EmailsRejected FROM Email_Routes R  
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		Where AssingedDateTime >= v_DataFromDate and AssingedDateTime <= v_DataToDate and R.AssignedTo = v_Agent
		AND ( R.CurrentStatus = 'EditRejectedByChecker' OR R.CurrentStatus = 'RejectedBychecker') AND
		 I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));  	
		
		Select SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(R.AssingedDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
		CONVERT(INSERT(INSERT(INSERT(IFNULL(R.DraftDateTime,R.ClosedDateTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_TotalActiveTime
		FROM Email_Routes R
		INNER JOIN Email_Inbox E ON E.SessionID = R.SessionID
		Where AssingedDateTime>= v_DataFromDate  and AssingedDateTime<= v_DataToDate and R.AssignedTo = v_Agent AND
		E.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		 
		
		Set v_TotalActiveEmailCount = (Select COUNT(distinct R.SessionID)
		FROM Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		Where AssingedDateTime>= v_DataFromDate  and AssingedDateTime<= v_DataToDate AND R.AssignedTo = v_Agent AND 
		(DraftDateTime IS NOT NULL OR ClosedDateTime IS NOT NULL) AND
		I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit)));
		
		set v_EmailsAverageActiveTime = (v_TotalActiveTime/v_TotalActiveEmailCount);
		
		Select SUM(TIMESTAMPDIFF(SECOND,
		CONVERT(INSERT(INSERT(INSERT(R.DraftDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime), 
		CONVERT(INSERT(INSERT(INSERT(IFNULL(R.RepliedDateTime,R.ClosedDateTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_TotalDraftTime
		FROM Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		WHERE  R.DraftDateTime IS NOT NULL  and AssingedDateTime>= v_DataFromDate and AssingedDateTime<= v_DataToDate and R.AssignedTo = v_Agent AND (R.RepliedDateTime IS NOT NULL OR R.ClosedDateTime IS NOT NULL) AND
		I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		
		
		set v_TotalDraftEmailCount = (select COUNT(distinct R.SessionID) from Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		WHERE  R.DraftDateTime IS NOT NULL  and AssingedDateTime>= v_DataFromDate and AssingedDateTime<= v_DataToDate and R.AssignedTo = v_Agent AND (R.DraftDateTime IS NOT NULL OR R.ClosedDateTime IS NOT NULL) AND
		I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit)));
		
		
		set v_EmailsAverageDraftTime = v_TotalDraftTime/v_TotalDraftEmailCount;
		
		if(v_TotalActiveEmailCount!=0)
		then
			Set v_EmailsAverageHandleTime = (Ifnull(CASE WHEN @TotalActiveTime<0 THEN 0 ELSE v_TotalActiveTime END,0)+IFNULL(CASE WHEN v_TotalDraftTime<0 THEN 0 ELSE v_TotalDraftTime END,0))/(v_TotalActiveEmailCount);
		else
			set v_EmailsAverageHandleTime = 0; 
		end if;
		
		Select SUM(TIMESTAMPDIFF(SECOND,
		CONVERT(INSERT(INSERT(INSERT(CONCAT(T.LoginDate , T.LoginTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime), 
		CONVERT(INSERT(INSERT(INSERT(CASE WHEN IFNULL(LogoutDate+LogoutTime,'')='' THEN p_CurrDateTime ELSE LogoutDate+LogoutTime END  , 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_EmailsStaffedTime
		From AGT_Agent_TimeTrack T
		Where CONCAT(T.LoginDate,T.LoginTime) >= v_DataFromDate and CONCAT(T.LoginDate,T.LoginTime) <= v_DataToDate and T.AgentID = v_Agent;	
		
		Select COUNT(DISTINCT skill) Into v_TotalSkillsAssigned FROM Email_Routes R
		INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
		WHERE R.AssignedTo = v_Agent AND Skill != '' AND Skill IS NOT NULL 
		AND AssingedDateTime>= v_DataFromDate AND AssingedDateTime<= v_DataToDate
		AND I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
					
		UPDATE Result_TempTable			
		SET EmailsStaffedTime = Ifnull(v_EmailsStaffedTime,0),
		 EmailsAssigned = Ifnull(v_EmailsAssigned,0),
		 EmailsReplied = Ifnull(v_EmailsReplied,0),
		 EmailsWithoutReplied = Ifnull(v_EmailsWithoutReplied,0),
		 EmailsTransferred = Ifnull(v_EmailsTransferred,0),
		 EmailsInDraft = Ifnull(v_EmailsInDraft,0),
		 EmailsAverageActiveTime = Ifnull(v_EmailsAverageActiveTime,0),
		 EmailsAverageDraftTime = Ifnull(v_EmailsAverageDraftTime,0),
		 EmailsAverageHandleTime = Ifnull(v_EmailsAverageHandleTime,0),
		 EmailsRejected = Ifnull(v_EmailsRejected,0),
		 TotalSkillsAssigned = Ifnull(v_TotalSkillsAssigned,0)
		WHERE agentID = v_Agent;	

		DELETE FROM Calculation_TempTable WHERE ID=v_currentID;
		SET v_agentCount = (SELECT COUNT(1) FROM Calculation_TempTable);		
	END WHILE;
	SELECT * FROM Result_TempTable;		
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Agent_PerformanceSkill
DELIMITER //
CREATE PROCEDURE `Get_Agent_PerformanceSkill`(
p_Agent VARCHAR(20),
p_FromDate VARCHAR(8), 
p_ToDate VARCHAR(8), 
p_FromTime VARCHAR(8), 
p_ToTime VARCHAR(8),
p_OrgUnit TEXT
)
BEGIN

DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_EmailsAssigned INT;
DECLARE v_TotalActiveEmailCount INT;
DECLARE v_TotalActiveTime INT;
DECLARE v_EmailsAverageActiveTime INT;
DECLARE v_TotalDraftEmailCount INT;
DECLARE v_TotalDraftTime INT;
DECLARE v_EmailsAverageDraftTime INT;
DECLARE v_EmailsAverageHandleTime INT;

DECLARE v_mailCount INT;
DECLARE v_currentID INT;
DECLARE v_skillValue INT;
DECLARE v_skillName VARCHAR(50);

DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT PRIMARY KEY, SkillID INT,SkillName VARCHAR(50));
DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
CREATE TEMPORARY TABLE Result_TempTable (SkillID INT,SkillName VARCHAR(50), EmailsAssigned INT, AverageHandleTime INT);

BEGIN
	IF(IFNULL(p_Agent,'') != '')
	THEN
		SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
		SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);
		
		IF(IFNULL(p_OrgUnit,'') = '')
		THEN
			INSERT INTO Calculation_TempTable(SkillID, SkillName) 
			SELECT DISTINCT Skill as SkillID, S.SkillName as SkillName FROM Email_Routes R inner join Email_SkillMap I 
			ON R.Skill=I.MakerSkill LEFT JOIN TMAC_Skills S ON S.SkillExtension =R.Skill 
			WHERE AssignedTo = p_Agent AND Skill != '' AND AssingedDateTime >= v_DataFromDate AND AssingedDateTime <= v_DataToDate AND Skill IS NOT NULL
			UNION 
			SELECT DISTINCT Skill as SkillID, S.SkillName as SkillName FROM Email_Routes R inner join Email_SkillMap I 
			ON R.Skill=I.CheckerSkill LEFT JOIN TMAC_Skills S ON S.SkillExtension =R.Skill
			WHERE AssignedTo = p_Agent AND Skill != '' AND AssingedDateTime >= v_DataFromDate AND AssingedDateTime <= v_DataToDate AND Skill IS NOT NULL;
		ELSE
			INSERT INTO Calculation_TempTable(SkillID, SkillName)
			Select DISTINCT Skill as SkillID, S.SkillName as SkillName  FROM Email_Routes R
			INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
			LEFT JOIN TMAC_Skills S ON S.SkillExtension =R.Skill 
			WHERE R.AssignedTo = p_Agent AND Skill != '' AND Skill IS NOT NULL 
			AND AssingedDateTime>= v_DataFromDate AND AssingedDateTime<= v_DataToDate
			AND I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		END IF;

		SET v_mailCount = (SELECT COUNT(1) FROM Calculation_TempTable);

		WHILE(v_mailCount>0)
		DO
			
			SET v_currentID =(SELECT ID FROM Calculation_TempTable LIMIT 1);
			SET v_skillValue = (SELECT SkillID FROM Calculation_TempTable WHERE ID=v_currentID);	
			SET v_skillName = (SELECT SkillName FROM Calculation_TempTable WHERE ID=v_currentID);	 
			IF NOT EXISTS(SELECT SkillID FROM Result_TempTable WHERE SkillID = v_skillValue)
			THEN
				INSERT INTO Result_TempTable VALUES(v_skillValue,v_skillName,0,0);
			END IF;	
				
				SELECT  IFNULL(COUNT(1),0) INTO v_EmailsAssigned FROM Email_Routes  R 
				INNER JOIN Email_Inbox I  ON I.SessionID = R.SessionID
				WHERE AssingedDateTime>=v_DataFromDate and AssingedDateTime<=v_DataToDate 
				AND R.AssignedTo = p_Agent;
			
				Select SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(R.AssingedDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
				CONVERT(INSERT(INSERT(INSERT(IFNULL(R.DraftDateTime,R.ClosedDateTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_TotalActiveTime
				FROM Email_Routes R
				INNER JOIN Email_Inbox E ON E.SessionID = R.SessionID
				Where AssingedDateTime>= v_DataFromDate  and AssingedDateTime<= v_DataToDate and R.AssignedTo = p_Agent  AND Skill = v_skillValue AND
				E.Mailbox IN (
					SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
					INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
					WHERE FIND_IN_SET(teamid,p_OrgUnit));
				
				Set v_TotalActiveEmailCount = (Select COUNT(distinct R.SessionID)
				FROM Email_Routes R
				INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
				Where AssingedDateTime>= v_DataFromDate  and AssingedDateTime<= v_DataToDate AND R.AssignedTo = p_Agent  AND Skill = v_skillValue AND 
				(DraftDateTime IS NOT NULL OR ClosedDateTime IS NOT NULL) AND
				I.Mailbox IN (
					SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
					INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
					WHERE FIND_IN_SET(teamid,p_OrgUnit)));
				
				SET v_EmailsAverageActiveTime = (v_TotalActiveTime/v_TotalActiveEmailCount);
												
				Select SUM(TIMESTAMPDIFF(SECOND,
				CONVERT(INSERT(INSERT(INSERT(R.DraftDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime), 
				CONVERT(INSERT(INSERT(INSERT(IFNULL(R.RepliedDateTime,R.ClosedDateTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) Into v_TotalDraftTime
				FROM Email_Routes R
				INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
				WHERE  R.DraftDateTime IS NOT NULL  and AssingedDateTime>= v_DataFromDate and AssingedDateTime<= v_DataToDate and 
				R.AssignedTo = p_Agent AND Skill = v_skillValue AND (R.RepliedDateTime IS NOT NULL OR R.ClosedDateTime IS NOT NULL) AND
				I.Mailbox IN (
					SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
					INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
					WHERE FIND_IN_SET(teamid,p_OrgUnit));
				
				
				set v_TotalDraftEmailCount = (select COUNT(distinct R.SessionID) from Email_Routes R
				INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID
				WHERE  R.DraftDateTime IS NOT NULL  and AssingedDateTime>= v_DataFromDate and AssingedDateTime<= v_DataToDate and 
				R.AssignedTo = p_Agent AND Skill = v_skillValue AND (R.DraftDateTime IS NOT NULL OR R.ClosedDateTime IS NOT NULL) AND
				I.Mailbox IN (
					SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
					INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
					WHERE FIND_IN_SET(teamid,p_OrgUnit)));
						
				SET v_EmailsAverageDraftTime = v_TotalDraftTime/v_TotalDraftEmailCount;
				
				
				IF(v_TotalActiveEmailCount!=0)
				THEN
					Set v_EmailsAverageHandleTime = (Ifnull(CASE WHEN @TotalActiveTime<0 THEN 0 ELSE v_TotalActiveTime END,0)+IFNULL(CASE WHEN v_TotalDraftTime<0 THEN 0 ELSE v_TotalDraftTime END,0))/(v_TotalActiveEmailCount);
				ELSE
					SET v_EmailsAverageHandleTime = 0; 
				END IF;		
			
				UPDATE Result_TempTable
				SET EmailsAssigned = v_EmailsAssigned,
				AverageHandleTime = v_EmailsAverageHandleTime
				WHERE SkillID = v_skillValue;	

				DELETE FROM Calculation_TempTable WHERE ID=v_currentID;
				SET v_mailCount = (SELECT COUNT(1) FROM Calculation_TempTable);							
		END WHILE;
	SELECT * FROM Result_TempTable;		 	                     		  
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_AuditTrail_Report
DELIMITER //
CREATE PROCEDURE `Get_AuditTrail_Report`(
      p_Type VARCHAR(50),p_FromDate VARCHAR(8),p_ToDate VARCHAR(8),p_CustomerEmailID VARCHAR(100),p_SessionID VARCHAR(20)
)
BEGIN
   DECLARE v_SelectSql LONGTEXT;
   DECLARE v_FilterBy LONGTEXT;
   DECLARE v_OrderBy LONGTEXT;
            
    IF(p_Type = 'AuditTrailSummary')
      THEN
         SET v_SelectSql = 'SELECT distinct E.From,E.SessionID,E.ReceivedDate,E.ReceivedTime , E.ClosedDate ,E.ClosedTime,E.Subject,S.CMSkillName as Skill 
                                      FROM Email_Inbox E 
                                      Left Join AGT_Intent_Skill_Map S On S.CMSkillName = E.CMSkill ';

         SET v_OrderBy = ' Order By E.SessionID';
            
         SET v_FilterBy = CONCAT(' Where E.ReceivedDate>=', p_FromDate ,' and E.ReceivedDate<=' , p_ToDate ,'');
                  
         IF(p_CustomerEmailID != '')
   			THEN
               SET v_FilterBy = CONCAT(v_FilterBy ,' AND E.From= ''', p_CustomerEmailID ,'''');
         END IF;        
    END IF;
      
    IF(p_Type = 'AuditTrailDrillDown')
      THEN
         SET v_SelectSql = 'SELECT distinct E.ID,E.SessionID, CONCAT(Ifnull(A.Firstname,A.AvayaLoginID ) ,'' '', Ifnull(A.LastName,'''')) as Owner , P.Role as OwnerSkill,E.ActionDate, E.ActionTime,E.Action
                                      FROM Email_Actions E
                                      Inner Join AGT_Agent A On A.AvayaLoginID = E.ActionBy
                                      Inner Join AGT_Agent_Profile P On P.AgentId = A.AvayaLoginID and P.Email = 1 ';
            
         SET v_OrderBy = ' Order By E.SessionID';
            
         IF(p_SessionID != '')
         	THEN
         		SET v_FilterBy = CONCAT(' WHERE E.SessionID = ', p_SessionID ,'');
         END IF;
      END IF;
      
      SET v_SelectSql = CONCAT(v_SelectSql , IFNULL(v_FilterBy,''));
      SET v_SelectSql = CONCAT(v_SelectSql , IFNULL(v_OrderBy,''));
      
    SET @stmt_str = v_SelectSql;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Audit_Trail_OCM_Report
DELIMITER //
CREATE PROCEDURE `Get_Audit_Trail_OCM_Report`(
	p_startdate varchar(20),
	p_enddate varchar(20),
	p_SearchString LONGTEXT,
	p_SortString VARCHAR(1000),
	p_PageNo INT /* = 1 */,
	p_PageSize INT /* = 10 */,
	OUT p_TotalPageSize INT )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
Declare v_lPageNbr INT;
	Declare v_lPageSize INT;
	Declare v_lFirstRec INT;
	Declare v_lLastRec INT;
	Declare v_lTotalRows INT;
    Declare v_CombineQuery LONGTEXT;
    Declare v_MAIN LONGTEXT;
	Declare v_DRILL LONGTEXT;
    Declare v_ToatlCount LONGTEXT;
		
	SET p_TotalPageSize = 0;
		SET v_lPageNbr = p_PageNo;
		SET v_lPageSize = p_PageSize;
		SET v_DataFromDate = p_startdate;
		SET v_DataToDate = p_enddate;
		SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
		SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );
			
		SET v_MAIN=CONCAT('SELECT ROW_NUMBER() OVER (ORDER BY NEWID()) as ID,TXN_DATE,TRANSACTION_NAME AS Transactionname,FUNCTIONNAME AS Functionname,CONCAT(TXN_DATE,TXN_TIME) AS DateTime,OLD_VALUES AS OldValues,NEW_VALUES as NewValues,USER_ID as UserID,CHANGEREASON AS ChangeReason FROM AUDITTRAIL_REPORT WHERE TXN_DATE >=',p_startdate,'AND TXN_DATE <= ',p_enddate); 
 
			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY TXN_DATE ASC) RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR),' ',p_SortString);
           
			SET v_ToatlCount = CONCAT('SELECT COUNT(*) into @x FROM(',v_MAIN,')AS table1 Where 1=1  AND (TXN_DATE >= ',v_DataFromDate,' AND TXN_DATE <= ',v_DataToDate,') ',p_SearchString); -- +' '+@SortString
			
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			 
			SET @stmt_strTotCnt = v_ToatlCount;
			PREPARE stmt1 FROM @stmt_strTotCnt;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 
	      SET p_TotalPageSize :=  @x;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_BcmsAgentSummaryData
DELIMITER //
CREATE PROCEDURE `Get_BcmsAgentSummaryData`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_AgentId VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN	

	DECLARE v_TotalStaffedTime int;
	DECLARE v_TotalACDTime int;
	DECLARE v_TotalAHTTime int;
	DECLARE v_TotACWTime int;
	DECLARE v_TotAuxTime int;


	DECLARE v_TotalLoginCounts int;
	DECLARE v_TotalAcdCalls int;
	DECLARE v_AgentLoginID int;
	
	DECLARE v_TotalACDPercent Decimal(10,2);
	DECLARE v_TotalAHTPercent Decimal(10,2);
	DECLARE v_TotACWPercent Decimal(10,2);
	DECLARE v_TotAuxPercent Decimal(10,2);
	
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');

	-- SQLINES LICENSE FOR EVALUATION USE ONLY
	Select bcms.AgentID,
 IFNULL(Count(1),0) ,
 Ifnull(SUM(bcms.TotACDCalls),0) ,
 Ifnull(SUM(bcms.TotalACDTime),0),
 Ifnull(SUM(bcms.TotalAHTTime),0),
 Ifnull(SUM(bcms.TotACWTime),0),
 Ifnull(SUM(bcms.TotAuxTime),0),
 Ifnull(SUM(bcms.TotalstaffedTime),0) Into v_AgentLoginID, v_TotalLoginCounts, v_TotalAcdCalls, v_TotalACDTime, v_TotalAHTTime, v_TotACWTime, v_TotAuxTime, v_TotalStaffedTime 
	from (
	Select TAB2.AgentID,UserName AgentName,TAB2.StationID,TAB2.LoginDateTime as LoginDateTime,TAB2.LogoutDateTime as LogoutDateTime,
	TAB2.SkillList, Ifnull(TAB2.TotalstaffedTime,0) as TotalstaffedTime, Ifnull(SUM(TotalACDTime),0) TotalACDTime,Ifnull(SUM(TotalAHTTime),0) TotalAHTTime,
	Ifnull(SUM(TotACWTime),0) TotACWTime, Ifnull((TAB2.TotalstaffedTime) - ((SUM(TotalACDTime)) + SUM(TotACWTime)),0) TotAuxTime,
	Ifnull(SUM(TotACDCalls),0) TotACDCalls,Ifnull(SUM(TotEmail),0) TotEmail,Ifnull(SUM(TotChat),0)TotChat,Ifnull(SUM(TotSMS),0)TotSMS,
	Ifnull(SUM(TotSM),0)TotSM,Ifnull(SUM(TotExtIn),0)TotExtIn,
	Ifnull(SUM(TotExtOut),0)TotExtOut,Ifnull(SUM(TotTranIn),0)TotTranIn,Ifnull(SUM(TotTranOut),0)TotTranOut,
	Ifnull(SUM(TotConfIn),0)TotConfIn,Ifnull(SUM(TotConfOut),0)TotConfOut FROM (
	Select TMAC_Interactions.AgentID, CreatedDateTime,
 CASE WHEN Channel='Voice' THEN 1 ELSE 0 END AS TotACDCalls,
 CASE WHEN Channel='Voice' THEN  ActiveTime ELSE 0 END AS TotalACDTime,
 CASE WHEN Channel='Voice' THEN  HoldTime ELSE 0 END AS TotalAHTTime,
 CASE WHEN Channel='Voice' THEN AcwTime ELSE 0 END AS TotACWTime,
 CASE WHEN Channel='Email' THEN 1 ELSE 0 END AS TotEmail,
 CASE WHEN Channel='Chat' THEN 1 ELSE 0 END AS TotChat,
 CASE WHEN Channel='SMS' THEN 1 ELSE 0 END AS TotSMS,
 CASE WHEN Channel IN ('FBPost','FBPrivate') THEN 1 ELSE 0 END AS TotSM,
 CASE WHEN CallType='2' THEN 1 ELSE 0 END AS TotExtIn,
 CASE WHEN CallType='3' THEN 1 ELSE 0 END AS TotExtOut,
 CASE WHEN IsTransfered='1' THEN 1 ELSE 0 END AS TotTranIn,
 CASE WHEN IsTranferedTo='1' THEN 1 ELSE 0 END AS TotTranOut,
 CASE WHEN IsConferenced='1' THEN 1 ELSE 0 END AS TotConfIn,
 CASE WHEN IsConferencedTo='1' THEN 1 ELSE 0 END AS TotConfOut 
	From TMAC_Interactions Where CreatedDateTime>= v_DataFromDate AND CreatedDateTime<=v_DataToDate and AgentId = p_AgentId
	) AS TAB1
	RIGHT JOIN ( SELECT DISTINCT AgentID,LoginDateTime,LogoutDateTime,
	SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(LoginDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
	CONVERT(INSERT(INSERT(INSERT(LogoutDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) AS TotalstaffedTime,StationID,SkillList
	FROM (SELECT DISTINCT AgentID,CONCAT(LoginDate,LoginTime) AS LoginDateTime ,CONCAT(LogoutDate,LogoutTime) AS LogoutDateTime,StationID,SkillList
	FROM AGT_Agent_TimeTrack A  WHERE CONCAT(LoginDate,LoginTime) >= v_DataFromDate AND CONCAT(LoginDate,LoginTime) <=v_DataToDate and AgentID = p_AgentId)TAB2
	Group by AgentID,StationID,SkillList,LoginDateTime,LogoutDateTime) AS TAB2
	ON  TAB2.AgentID = TAB1.AgentID and TAB1.CreatedDateTime between TAB2.LoginDateTime AND TAB2.LogoutDateTime
	INNER JOIN AGT_Agent A ON A.AvayaLoginID = p_AgentId
	Group by TAB2.AgentID,UserName,TAB2.StationID,TAB2.LoginDateTime,TAB2.LogoutDateTime,TAB2.SkillList,TAB2.TotalstaffedTime
	) as bcms
	Group by bcms.AgentID;
		
	
	IF(IFNULL(v_TotalStaffedTime,0) <> 0)
	THEN
	SET v_TotalACDPercent = (100.2 * (IFNULL(v_TotalACDTime,0))/(IFNULL(v_TotalStaffedTime,1)));
	SET v_TotalAHTPercent = (100.2 * (IFNULL(v_TotalAHTTime,0))/(IFNULL(v_TotalStaffedTime,1)));
	SET v_TotACWPercent = (100.2 * (IFNULL(v_TotACWTime,0))/(IFNULL(v_TotalStaffedTime,1)));
	SET v_TotAuxPercent = (100.2 * (IFNULL(v_TotAuxTime,0))/(IFNULL(v_TotalStaffedTime,1)));		
	END IF;
	
	SELECT v_AgentLoginID AS AgentID,
	IFNULL(v_TotalLoginCounts,0) AS TotalLoginCounts ,
	IFNULL(v_TotalAcdCalls,0) AS TotalAcdCalls,
	IFNULL(v_TotalACDPercent,0) AS TotalACDPercent,	
	IFNULL(v_TotACWPercent,0) AS TotACWPercent,
	IFNULL(v_TotAuxPercent,0) AS TotAuxPercent,
	IFNULL(v_TotalStaffedTime,0) AS TotalStaffedTime,
	IFNULL(v_TotalAHTPercent,0) AS TotalAHTPercent;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_CallBackSLAReport
DELIMITER //
CREATE PROCEDURE `Get_CallBackSLAReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_UCID VARCHAR(250),
p_SearchString LONGTEXT,
p_SortString VARCHAR(1000),
p_PageNo INT /* = 1 */,
p_PageSize INT /* = 10 */,
p_CallBackFilter VARCHAR(50),
OUT p_TotalPageSize INT)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_lPageNbr INT;
Declare v_lPageSize INT;
Declare v_lFirstRec INT;
Declare v_lLastRec INT;
Declare v_lTotalRows INT;
Declare v_CombineQuery LONGTEXT;
Declare v_MAIN LONGTEXT;
Declare v_DRILL LONGTEXT;
Declare v_ToatlCount LONGTEXT;

BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate; 

		SET p_TotalPageSize = 0;
		SET v_DataFromDate = p_FromDate;
		SET v_DataToDate = p_ToDate;
		SET v_lPageNbr = p_PageNo;
		SET v_lPageSize = p_PageSize;
		SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
		SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );

	IF(p_Type = 'MAIN')
	THEN	
		SET v_MAIN=CONCAT('SELECT TYPE_OF_INQUIRY AS TypeOfInquiry,CALLERID,UCID,I.OtherData,PREFFERRED_CONTACTNO AS PreferredCallbackContact,QUEUE_NAME AS QueueName,
		REPLACE(CONCAT(REQUEST_DATE,REQUEST_TIME), '' '','''') AS RequestDatetime,QUEUE_WAIT_TIME AS CallerQueueWaitTime,NO_CALLBACK_ATTEMPTS AS NoOfCallbackAttempts,
		REPLACE(CONCAT(ASSIGNED_DATE,ASSIGNED_TIME),'' '','''') AS AssignedDateTime,REPLACE(CONCAT(DIAL_DATE,DIAL_TIME),'' '','''') AS AgentDialDateTime,
		REPLACE(CONCAT(CALLBACK_DATE,CALLBACK_TIME),'' '','''') AS CallbackDateTime,CALLBACK_STATUS AS StatusOfCallback,
		CONCAT(IFNULL(FIRSTNAME,''''),'' '',IFNULL(LASTNAME,'''')) AS AssignedToAgentName, AvayaLoginID as AgentID,
		REPLACE(CONCAT(PROCESSED_DATE,PROCESSED_TIME),'' '','''') AS ProcessedDateTime,SLA AS SLATime,
		CASE WHEN REPLACE(CONCAT(ASSIGNED_DATE,ASSIGNED_TIME), '' '','''')>= REPLACE(CONCAT(PROCESSED_DATE,PROCESSED_TIME),'' '','''') THEN IFNULL(AHT,0) ELSE
		IFNULL(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(REPLACE(CONCAT(ASSIGNED_DATE,ASSIGNED_TIME), '' '',''''), 9, 0, '' ''), 12, 0, '':''), 15, 0, '':''),datetime),
		CONVERT(INSERT(INSERT(INSERT(REPLACE(CONCAT(PROCESSED_DATE,PROCESSED_TIME), '' '',''''), 9, 0, '' ''), 12, 0, '':''), 15, 0, '':''),datetime)),0) END
		AS AgentHandleTime,COMMENTS AS Comments,TYPE,T.SubChannel As SubChannel,T.Channel As Channel, APP
		FROM IVR_Callback_Requests I LEFT JOIN AGT_Agent A ON A.AvayaLoginID=I.ASSIGNED_TO left join TMAC_Interactions T on I.UCID =T.SubSessionid
		WHERE   CONCAT(REQUEST_DATE,REQUEST_TIME) >= ''', v_DataFromDate , ''' AND CONCAT(REQUEST_DATE,REQUEST_TIME) <= ''', v_DataToDate  ,''' AND (APP <> ''',p_CallBackFilter,''' OR APP is NULL)');
	
			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY RequestDatetime ASC) RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1 AND (RequestDatetime >= ''',v_DataFromDate,''' AND RequestDatetime <= ''',v_DataToDate,''') ',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR),' ',p_SortString);

		
			SET v_ToatlCount = CONCAT('SELECT COUNT(*) into @x FROM(',v_MAIN,')AS table1 Where 1=1  AND (RequestDatetime >= ''',v_DataFromDate,''' AND RequestDatetime <= ''',v_DataToDate,''') ',p_SearchString); -- +' '+@SortString
			
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			
            SET @stmt_strTotCnt = v_ToatlCount;
			PREPARE stmt1 FROM @stmt_strTotCnt;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 
	     SET p_TotalPageSize :=  @x;
		 SELECT p_TotalPageSize as 'TotalPageSize';
	END IF;
	
	IF(p_Type = 'DRILL')
	THEN	
		SET v_MAIN= CONCAT('SELECT  AvayaLoginID as AgentID, UCID , replace(CONCAT(DIAL_DATE,DIAL_TIME),'' '','''') as AgentDialDateTime,
			 replace(CONCAT(ASSIGNED_DATE,ASSIGNED_TIME),'' '','''') as AssignedDateTime, 
             CALLBACK_STATUS AS StatusOfCallback,COMMENTS,CONCAT(IFNULL(FIRSTNAME,''''),'' '',IFNULL(LASTNAME,''''))  AS AssignedToAgentName  FROM IVR_Callback_Requests_Attempts 
             LEFT JOIN AGT_Agent ON ASSIGNED_TO=AvayaLoginID WHERE UCID=''' ,p_UCID ,'''');

			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY UCID ASC) RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1 ',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR),' ',p_SortString);


			 SET v_ToatlCount = CONCAT('SELECT COUNT(*) into @x FROM(',v_MAIN,')AS table1 Where 1=1 ');
		
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			
            SET @stmt_strTotCnt = v_ToatlCount;
			PREPARE stmt1 FROM @stmt_strTotCnt;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 
	      SET p_TotalPageSize :=  @x;
		  SELECT p_TotalPageSize as 'TotalPageSize';
	END IF;
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.GET_CALLWORK_REPORT
DELIMITER //
CREATE PROCEDURE `GET_CALLWORK_REPORT`(
	p_Type varchar(20),
	p_FromDate VARCHAR(20),	
	p_ToDate VARCHAR(20),
	p_Agent VARCHAR(250),
	p_WorkCode VARCHAR(8)
	)
BEGIN
	If (p_Type = 'MAIN')
	THEN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		SELECT cm.WorkCodeName as WorkCodeDesc, cm.WorkCode Workcode,CONCAT(IFNULL(agt.FirstName,'') ,' ', IFNULL(agt.LastName,'')) as AgentName,
		agt.AvayaLoginID ,COUNT(agt.AvayaLoginID) as `Count` from AGT_Agent agt 
		INNER JOIN GBL_CallWorkCodes cwc on agt.AvayaLoginID =cwc.AgentID
		left join AGT_InboundACD_Calls inb on cwc.SessionID = inb.UCID
		INNER JOIN GBL_CallWorkCodeMapping cm on cwc.WorkCode = cm.WorkCode 
	    WHERE CONCAT(cwc.InsertDate,cwc.InsertTime) >= p_FromDate and CONCAT(cwc.InsertDate,cwc.InsertTime) <= p_ToDate
		GROUP BY agt.AvayaLoginID, agt.FirstName,agt.LastName,cwc.WorkCode,cm.WorkCode,cm.WorkCodeName
		ORDER BY cwc.WorkCode;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	END IF;

	If (p_Type = 'DRILL')
	THEN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		select cm.WorkCodeName as WorkcodeDesc, cm.WorkCode Workcode,CONCAT(IFNULL(agt.FirstName,'') ,' ', IFNULL(agt.LastName,'')) as AgentName,
        CONCAT(cwc.InsertDate,cwc.InsertTime) as `DateTime`,
		cwc.CallerID,inb.Queue
		from GBL_CallWorkCodes cwc 
		INNER JOIN GBL_CallWorkCodeMapping cm on cwc.WorkCode = cm.WorkCode
		INNER JOIN AGT_Agent agt on agt.AvayaLoginID =cwc.AgentID
		left join AGT_InboundACD_Calls inb on cwc.SessionID = inb.UCID
		WHERE cwc.WorkCode = p_WorkCode
		AND CONCAT(cwc.InsertDate,cwc.InsertTime) >= p_FromDate and CONCAT(cwc.InsertDate,cwc.InsertTime) <= p_ToDate 
		and agt.AvayaLoginID=p_Agent
		ORDER BY cm.WorkCode;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	END IF;	
	If (p_Type = 'DRILLEXPORT')
	THEN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
		select cm.WorkCodeName as WorkcodeDesc, cm.WorkCode Workcode,CONCAT(IFNULL(agt.FirstName,'') ,' ', IFNULL(agt.LastName,'')) as AgentName ,
        CONCAT(cwc.InsertDate,cwc.InsertTime) as `DateTime`,
		cwc.CallerID,inb.Queue
		from GBL_CallWorkCodes cwc 
		INNER JOIN GBL_CallWorkCodeMapping cm  on cwc.WorkCode = cm.WorkCode
		INNER JOIN AGT_Agent agt  on agt.AvayaLoginID =cwc.AgentID
		left join AGT_InboundACD_Calls inb  on cwc.SessionID = inb.UCID
		ORDER BY cm.WorkCode;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	END IF;	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.GET_CALL_WORK_COMBO
DELIMITER //
CREATE PROCEDURE `GET_CALL_WORK_COMBO`(
p_Type Int
)
BEGIN

	If (p_Type = 1)-- Get Call Work Months
	THEN			
		SELECT DISTINCT LEFT(InsertDate,6) Value,
		REPLACE(RIGHT(DATE_FORMAT(cast( InsertDate as datetime(3)), 106), 8), ' ', '-') Display
		FROM GBL_CALLWORKCODES 
		Where InsertDate IS NOT NULL 
		ORDER BY Value DESC;
	END IF;
	
	If (p_Type = 2)-- Get Call Work Codes
	THEN		
		SELECT DISTINCT CWM.WORKCODE Value, CWM.WorkCodeName Display
		FROM GBL_CALLWORKCODES CW
		Inner Join GBL_CallWorkCodeMapping CWM On CWM.WORKCODE = CW.WORKCODE
		ORDER BY Value ASC;
	END IF;
	
	If (p_Type = 3)-- Get Call Work Agents
	THEN		
		SELECT DISTINCT AG.AvayaLoginID Value, AG.USERNAME Display
		FROM GBL_CALLWORKCODES CW
		Inner Join AGT_Agent AG On AG.AvayaLoginID = CW.AGENTID
		ORDER BY Value ASC;			
	END IF;	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Chatbot_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Chatbot_DashboardData`(
	p_Type varchar(20), p_startdate varchar(20), p_enddate varchar(20), p_dnis varchar(1000)
)
BEGIN
	Declare v_ChatCallback INT;
	Declare v_TotalChat INT;
	Declare v_ChatCount INT;
	Declare v_ChatToAudio INT;
	Declare v_ChatToVideo INT;
	Declare v_AudioIP INT;
	Declare v_AudioToVideo INT;
	Declare v_AudioToChat INT;
	Declare v_VideoIP INT;
	Declare v_VideoToAudio INT;
	Declare v_VideoToChat INT;
	Declare v_TransferedChat INT;
	Declare v_TransferedAudio INT;
	Declare v_TransferedVideo INT;
	Declare v_ConferencedChat INT;
	Declare v_ConferencedAudio INT;
	Declare v_ConferencedVideo INT;
	Declare v_AverageHandleTime DOUBLE;
	Declare v_AverageHandleAudioTime DOUBLE;
	Declare v_AverageHandleVideoTime DOUBLE;
	
IF(p_Type='summarydata')
THEN
   IF(p_dnis !='')
   THEN
    SET v_ChatCallback=(IFNULL(( SELECT COUNT(1) FROM IVR_Callback_Requests R INNER JOIN TMAC_Interactions T on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(Concat(p_startdate,'000000')) AND 
	T.CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(T.Skill,p_dnis)>0),0)),

	v_TotalChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatCount=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatToAudio=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatToVideo=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioIP=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioToVideo=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioToChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoIP=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoToAudio=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoToChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),
	

	v_TransferedChat=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_TransferedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_TransferedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedChat=(IFNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions 
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleAudioTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleVideoTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0));


	Select v_ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,v_ChatCount as ChatCount,v_ChatToAudio as ChatToAudio,v_ChatToVideo as ChatToVideo,
	v_AudioIP as AudioIP,v_AudioToVideo as AudioToVideo,v_AudioToChat as AudioToChat,v_VideoIP as VideoIP,v_VideoToAudio as VideoToAudio,v_VideoToChat as VideoToChat,
	v_TransferedChat as TransferedChat,v_TransferedAudio as TransferedAudio,v_TransferedVideo as TransferedVideo,v_ConferencedChat as ConferencedChat,
	v_ConferencedAudio as ConferencedAudio,v_ConferencedVideo as ConferencedVideo, v_AverageHandleTime as AverageHandleTime,v_AverageHandleAudioTime as AverageHandleAudioTime, v_AverageHandleVideoTime as AverageHandleVideoTime,
	convert(ifnull(((convert(v_TotalChat,float) - (convert(v_TransferedChat,float) +convert(v_ConferencedChat,float) ))/convert(nullif(v_TotalChat,0),float)),0),decimal(5,2)) as FirstCallResolution,
	convert(ifnull(((convert(v_AudioIP,float) - (convert(v_TransferedAudio,float) +convert(v_ConferencedAudio,float) ))/convert(nullif(v_AudioIP,0),float)),0),decimal(5,2)) as FirstCallResolutionAudio,
	convert(ifnull(((convert(v_VideoIP,float) - (convert(v_TransferedVideo,float) +convert(v_ConferencedVideo,float) ))/convert(nullif(v_VideoIP,0),float)),0),decimal(5,2)) as FirstCallResolutionVideo;

   ELSE

	SET v_ChatCallback=(IFNULL(( SELECT COUNT(1)  FROM IVR_Callback_Requests R  INNER JOIN TMAC_Interactions T on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(Concat(p_startdate,'000000')) AND 
	T.CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TotalChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatCount=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatToAudio=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatToVideo=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioIP=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioToVideo=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioToChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoIP=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoToAudio=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoToChat=IFNULL((SELECT COUNT(DISTINCT SubSessionId) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),
	

	v_TransferedChat=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TransferedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TransferedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedChat=(IFNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions 
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleAudioTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleVideoTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(DISTINCT SubSessionId) from TMAC_Interactions   
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0));

	Select v_ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,v_ChatCount as ChatCount,v_ChatToAudio as ChatToAudio,v_ChatToVideo as ChatToVideo,
	v_AudioIP as AudioIP,v_AudioToVideo as AudioToVideo,v_AudioToChat as AudioToChat,v_VideoIP as VideoIP,v_VideoToAudio as VideoToAudio,v_VideoToChat as VideoToChat,
	v_TransferedChat as TransferedChat,v_TransferedAudio as TransferedAudio,v_TransferedVideo as TransferedVideo,v_ConferencedChat as ConferencedChat,
	v_ConferencedAudio as ConferencedAudio,v_ConferencedVideo as ConferencedVideo, v_AverageHandleTime as AverageHandleTime,v_AverageHandleAudioTime as AverageHandleAudioTime, v_AverageHandleVideoTime as AverageHandleVideoTime,
	convert(ifnull(((convert(v_TotalChat,float) - (convert(v_TransferedChat,float) +convert(v_ConferencedChat,float) ))/convert(nullif(v_TotalChat,0),float)),0),decimal(5,2)) as FirstCallResolution,
	convert(ifnull(((convert(v_AudioIP,float) - (convert(v_TransferedAudio,float) +convert(v_ConferencedAudio,float) ))/convert(nullif(v_AudioIP,0),float)),0),decimal(5,2)) as FirstCallResolutionAudio,
	convert(ifnull(((convert(v_VideoIP,float) - (convert(v_TransferedVideo,float) +convert(v_ConferencedVideo,float) ))/convert(nullif(v_VideoIP,0),float)),0),decimal(5,2)) as FirstCallResolutionVideo;

   END IF;
END IF;
IF(p_Type='chartintentdata')
THEN
   IF(p_dnis !='')
   THEN
		SELECT DISTINCT Intent as IntentName,count(DISTINCT SubSessionId) as ChatCount FROM TMAC_Interactions 
	   WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))  AND
		FIND_IN_SET(Skill,p_dnis)>0 AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(DISTINCT SubSessionId ) DESC, Intent ASC	LIMIT 10;
   ELSE
		SELECT DISTINCT Intent as IntentName ,count(DISTINCT SubSessionId) as ChatCount FROM TMAC_Interactions 
		 WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))  AND 
		IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(DISTINCT SubSessionId ) DESC, Intent ASC	LIMIT 10;
   END IF;
ELSEIF
 (p_Type='chartskilldata')
THEN
   IF(p_dnis !='')
   THEN
		SELECT DISTINCT CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(DISTINCT SubSessionId) AS ChatCount  FROM TMAC_Interactions T 
		LEFT JOIN TMAC_Skills S  ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000'AND CREATEDDATETIME>=(Concat(p_startdate,'000000')) AND CREATEDDATETIME<=(Concat(p_enddate,'235959'))
		AND FIND_IN_SET(T.SKILL,p_dnis)>0 AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(DISTINCT SubSessionId ) DESC,  SKILL ASC LIMIT 10;
   ELSE
		SELECT DISTINCT CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(DISTINCT SubSessionId) AS ChatCount  FROM TMAC_Interactions T 
		LEFT JOIN TMAC_Skills S  ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000' AND CREATEDDATETIME>=(Concat(p_startdate,'000000')) AND CREATEDDATETIME<=(Concat(p_enddate,'235959')) AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(DISTINCT SubSessionId ) DESC,  SKILL ASC LIMIT 10;
   END IF;
	
END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Chat_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Chat_DashboardData`(
	p_Type varchar(20), p_startdate varchar(20), p_enddate varchar(20), p_dnis varchar(1000)
)
BEGIN
   Declare v_ChatCallback INT;
	Declare v_TotalChat INT;
	Declare v_ChatCount INT;
	Declare v_ChatToAudio INT;
	Declare v_ChatToVideo INT;
	Declare v_AudioIP INT;
	Declare v_AudioToVideo INT;
	Declare v_AudioToChat INT;
	Declare v_VideoIP INT;
	Declare v_VideoToAudio INT;
	Declare v_VideoToChat INT;
	Declare v_TransferedChat INT;
	Declare v_TransferedAudio INT;
	Declare v_TransferedVideo INT;
	Declare v_ConferencedChat INT;
	Declare v_ConferencedAudio INT;
	Declare v_ConferencedVideo INT;
	Declare v_AverageHandleTime DOUBLE;
	Declare v_AverageHandleAudioTime DOUBLE;
	Declare v_AverageHandleVideoTime DOUBLE;
	
IF(p_Type='summarydata')
THEN
   IF(p_dnis !='')
   THEN
   SET v_ChatCallback=(IFNULL(( SELECT COUNT(1)  FROM IVR_Callback_Requests R INNER JOIN TMAC_Interactions T on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(Concat(p_startdate,'000000')) AND 
	T.CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(T.Skill,p_dnis)>0),0)),

	v_TotalChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatCount=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatToAudio=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_ChatToVideo=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioIP=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioToVideo=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_AudioToChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoIP=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoToAudio=IFNULL((SELECT COUNT(1) from TMAC_Interactions T 
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),

	v_VideoToChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0),
	

	v_TransferedChat=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_TransferedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions   
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_TransferedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedChat=(IFNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions 
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions  
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_ConferencedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions 
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleAudioTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions   
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0)),

	v_AverageHandleVideoTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions 
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959')) AND FIND_IN_SET(Skill,p_dnis)>0),0));

	Select v_ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,v_ChatCount as ChatCount,v_ChatToAudio as ChatToAudio,v_ChatToVideo as ChatToVideo,
	v_AudioIP as AudioIP,v_AudioToVideo as AudioToVideo,v_AudioToChat as AudioToChat,v_VideoIP as VideoIP,v_VideoToAudio as VideoToAudio,v_VideoToChat as VideoToChat,
	v_TransferedChat as TransferedChat,v_TransferedAudio as TransferedAudio,v_TransferedVideo as TransferedVideo,v_ConferencedChat as ConferencedChat,
	v_ConferencedAudio as ConferencedAudio,v_ConferencedVideo as ConferencedVideo, v_AverageHandleTime as AverageHandleTime,v_AverageHandleAudioTime as AverageHandleAudioTime, v_AverageHandleVideoTime as AverageHandleVideoTime,
	convert(ifnull(((convert(v_TotalChat,float) - (convert(v_TransferedChat,float) +convert(v_ConferencedChat,float)))/convert(nullif(v_TotalChat,0),float)),0),decimal(5,2)) as FirstCallResolution,
	convert(ifnull(((convert(v_AudioIP,float) - (convert(v_TransferedAudio,float) +convert(v_ConferencedAudio,float)))/convert(nullif(v_AudioIP,0),FLOAT)),0),decimal(5,2)) as FirstCallResolutionAudio,
	convert(ifnull(((convert(v_VideoIP,float) - (convert(v_TransferedVideo,float) +convert(v_ConferencedVideo,float)))/convert(nullif(v_VideoIP,0),float)),0),decimal(5,2)) as FirstCallResolutionVideo;

   ELSE

	SET v_ChatCallback=(IFNULL(( SELECT COUNT(1)  FROM IVR_Callback_Requests R INNER JOIN TMAC_Interactions T on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(Concat(p_startdate,'000000')) AND 
	T.CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TotalChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T 
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatCount=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatToAudio=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_ChatToVideo=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioIP=IFNULL((SELECT COUNT(1) from TMAC_Interactions T 
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioToVideo=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_AudioToChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoIP=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoToAudio=IFNULL((SELECT COUNT(1) from TMAC_Interactions T  
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),

	v_VideoToChat=IFNULL((SELECT COUNT(1) from TMAC_Interactions T   
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0),
	

	v_TransferedChat=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions   
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TransferedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_TransferedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions 
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedChat=(IFNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions 
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedAudio=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_ConferencedVideo=(IFNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions    
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleAudioTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions   
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0)),

	v_AverageHandleVideoTime=(IFNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))),0));

	Select v_ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,v_ChatCount as ChatCount,v_ChatToAudio as ChatToAudio,v_ChatToVideo as ChatToVideo,
	v_AudioIP as AudioIP,v_AudioToVideo as AudioToVideo,v_AudioToChat as AudioToChat,v_VideoIP as VideoIP,v_VideoToAudio as VideoToAudio,v_VideoToChat as VideoToChat,
	v_TransferedChat as TransferedChat,v_TransferedAudio as TransferedAudio,v_TransferedVideo as TransferedVideo,v_ConferencedChat as ConferencedChat,
	v_ConferencedAudio as ConferencedAudio,v_ConferencedVideo as ConferencedVideo, v_AverageHandleTime as AverageHandleTime,v_AverageHandleAudioTime as AverageHandleAudioTime, v_AverageHandleVideoTime as AverageHandleVideoTime,
	convert(ifnull(((convert(v_TotalChat,float) - (convert(v_TransferedChat,float) +convert(v_ConferencedChat,float) ))/convert(nullif(v_TotalChat,0),float)),0),decimal(5,2)) as FirstCallResolution,
	convert(ifnull(((convert(v_AudioIP,float) - (convert(v_TransferedAudio,float) +convert(v_ConferencedAudio,float) ))/convert(nullif(v_AudioIP,0),float)),0),decimal(5,2)) as FirstCallResolutionAudio,
	convert(ifnull(((convert(v_VideoIP,float) - (convert(v_TransferedVideo,float) +convert(v_ConferencedVideo,float) ))/convert(nullif(v_VideoIP,0),float)),0),decimal(5,2)) as FirstCallResolutionVideo;

   END IF;
END IF;
IF(p_Type='chartintentdata')
THEN
   IF(p_dnis !='')
   THEN
		SELECT DISTINCT  Intent as IntentName,count(SessionId) as ChatCount FROM TMAC_Interactions 
		 WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))  AND
		FIND_IN_SET(Skill,p_dnis)>0 AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(SessionId ) DESC, Intent ASC	LIMIT 10;
   ELSE
		SELECT DISTINCT Intent as IntentName ,count(SessionId) as ChatCount FROM TMAC_Interactions 
	 WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(Concat(p_startdate,'000000')) AND CreatedDateTime<=(Concat(p_enddate,'235959'))  AND 
		IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(SessionId ) DESC, Intent ASC	LIMIT 10;
   END IF;
ELSEIF
 (p_Type='chartskilldata')
THEN
   IF(p_dnis !='')
   THEN
		SELECT DISTINCT CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(SESSIONID) AS ChatCount  FROM TMAC_Interactions T
		LEFT JOIN TMAC_Skills S ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000'AND CREATEDDATETIME>=(Concat(p_startdate,'000000')) AND CREATEDDATETIME<=(Concat(p_enddate,'235959'))
		AND FIND_IN_SET(T.SKILL,p_dnis)>0 AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(SESSIONID ) DESC,  SKILL ASC LIMIT 10;
   ELSE
		SELECT DISTINCT CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(SESSIONID) AS ChatCount  FROM TMAC_Interactions T
		LEFT JOIN TMAC_Skills S ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000' AND CREATEDDATETIME>=(Concat(p_startdate,'000000')) AND CREATEDDATETIME<=(Concat(p_enddate,'235959')) AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(SESSIONID ) DESC,  SKILL ASC LIMIT 10;
   END IF;
	
END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Customer_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Customer_DashboardData`(
p_Type VARCHAR(100))
begin
		if(p_Type='csat')
		then
				select count(surveyid) totalresponse, 
				convert(cast(sum(verysatisfiedcount)+sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) csat ,
				ifnull(sum(verysatisfiedcount),0) verysatisfiedcount,
				convert(cast(sum(verysatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verysatisfiedpercent ,
				ifnull(sum(satisfiedcount),0) satisfiedcount,
				convert(cast(sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) satisfiedpercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(dissatisfiedneutralcount),0) dissatisfiedcount,
				convert(cast(sum(dissatisfiedneutralcount) as double)/count(surveyid) * 100, decimal(5,1)) dissatisfiedpercent ,
				ifnull(sum(verydissatisfiedcount),0) verydissatisfiedcount,
				convert(cast(sum(verydissatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verydissatisfiedpercent 
				from(
				select s.surveyid,
				case when responsevalue = 5 then 1 else 0 end verysatisfiedcount,
				case when responsevalue = 4 then 1 else 0 end satisfiedcount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end dissatisfiedneutralcount,
				case when responsevalue = 1 then 1 else 0 end verydissatisfiedcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='csat'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='csat'
				)csat;

		elseif (p_Type='nps')
		then
				select count(surveyid) totalresponse, 
				ifnull(sum(promotercount),0) promotercount,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100, decimal(5,1)) promoterpercent ,
				ifnull(sum(passivecount),0) passivecount,
				convert(cast(sum(passivecount) as double)/count(surveyid) * 100, decimal(5,1)) passivepercent, 
				ifnull(sum(detractorcount),0) detractorcount,
				convert(cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,1)) detractorpercent ,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100 -cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,0)) nps
				from (
				select s.surveyid,
				case when responsevalue <=10 and responsevalue >=9 then 1 else 0 end promotercount,
				case when responsevalue <=8 and responsevalue >=7 then 1 else 0 end passivecount,
				case when responsevalue <=6 and responsevalue >=0 then 1 else 0 end detractorcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='nps'
		inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='nps')nps;
		elseif (p_Type = 'ces') 
		then
				select count(surveyid) totalresponse, 
				ifnull(sum(stronglyagreecount),0) stronglyagreecount,
				convert(cast(sum(stronglyagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglyagreepercent ,
				ifnull(sum(agreecount),0) agreecount,
				convert(cast(sum(agreecount) as double)/count(surveyid) * 100, decimal(5,1)) agreepercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(disagreecount),0) disagreecount,
				convert(cast(sum(disagreecount) as double)/count(surveyid) * 100, decimal(5,1)) disagreepercent ,
				ifnull(sum(stronglydisagreecount),0) stronglydisagreecount,
				convert(cast(sum(stronglydisagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglydisagreepercent ,
				convert(cast(sum(responsevalue) as double)/count(surveyid), decimal(5,1)) ces
				from(
				select s.surveyid,responsevalue,
				case when responsevalue = 5 then 1 else 0 end stronglyagreecount,
				case when responsevalue = 4 then 1 else 0 end agreecount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end disagreecount,
				case when responsevalue = 1 then 1 else 0 end stronglydisagreecount 
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='ces'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='ces')ces;			
		elseif (p_Type='agentcsat')
		then
				select agentid,count(surveyid) totalresponse, 
				convert(cast(sum(verysatisfiedcount)+sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) csat ,
				ifnull(sum(verysatisfiedcount),0) verysatisfiedcount,
				convert(cast(sum(verysatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verysatisfiedpercent ,
				ifnull(sum(satisfiedcount),0) satisfiedcount,
				convert(cast(sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) satisfiedpercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(dissatisfiedneutralcount),0) dissatisfiedcount,
				convert(cast(sum(dissatisfiedneutralcount) as double)/count(surveyid) * 100, decimal(5,1)) dissatisfiedpercent ,
				ifnull(sum(verydissatisfiedcount),0) verydissatisfiedcount,
				convert(cast(sum(verydissatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verydissatisfiedpercent 
				from(
				select s.surveyid,agentid,
				case when responsevalue = 5 then 1 else 0 end verysatisfiedcount,
				case when responsevalue = 4 then 1 else 0 end satisfiedcount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end dissatisfiedneutralcount,
				case when responsevalue = 1 then 1 else 0 end verydissatisfiedcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='csat'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='csat' )csat group by agentid;
		elseif (p_Type='agentnps')
		then
				select agentid,count(surveyid) totalresponse, 
				ifnull(sum(promotercount),0) promotercount,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100, decimal(5,1)) promoterpercent ,
				ifnull(sum(passivecount),0) passivecount,
				convert(cast(sum(passivecount) as double)/count(surveyid) * 100, decimal(5,1)) passivepercent, 
				ifnull(sum(detractorcount),0) detractorcount,
				convert(cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,1)) detractorpercent ,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100 -cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,0)) nps
				from (
				select s.surveyid,agentid,
				case when responsevalue <=10 and responsevalue >=9 then 1 else 0 end promotercount,
				case when responsevalue <=8 and responsevalue >=7 then 1 else 0 end passivecount,
				case when responsevalue <=6 and responsevalue >=0 then 1 else 0 end detractorcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='nps'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='nps')nps group by agentid;
		elseif (p_Type='agentces')
		then
				select agentid,count(surveyid) totalresponse, 
				ifnull(sum(stronglyagreecount),0) stronglyagreecount,
				convert(cast(sum(stronglyagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglyagreepercent ,
				ifnull(sum(agreecount),0) agreecount,
				convert(cast(sum(agreecount) as double)/count(surveyid) * 100, decimal(5,1)) agreepercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(disagreecount),0) disagreecount,
				convert(cast(sum(disagreecount) as double)/count(surveyid) * 100, decimal(5,1)) disagreepercent ,
				ifnull(sum(stronglydisagreecount),0) stronglydisagreecount,
				convert(cast(sum(stronglydisagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglydisagreepercent ,
				convert(cast(sum(responsevalue) as double)/count(surveyid), decimal(5,1)) ces
				from(
				select s.surveyid,responsevalue,agentid,
				case when responsevalue = 5 then 1 else 0 end stronglyagreecount,
				case when responsevalue = 4 then 1 else 0 end agreecount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end disagreecount,
				case when responsevalue = 1 then 1 else 0 end stronglydisagreecount 
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='ces'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='ces')ces	group by agentid;	
		elseif (p_Type='destchannelcsat')
		then
				select destchannel,count(surveyid) totalresponse, 
				convert(cast(sum(verysatisfiedcount)+sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) csat ,
				ifnull(sum(verysatisfiedcount),0) verysatisfiedcount,
				convert(cast(sum(verysatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verysatisfiedpercent ,
				ifnull(sum(satisfiedcount),0) satisfiedcount,
				convert(cast(sum(satisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) satisfiedpercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(dissatisfiedneutralcount),0) dissatisfiedcount,
				convert(cast(sum(dissatisfiedneutralcount) as double)/count(surveyid) * 100, decimal(5,1)) dissatisfiedpercent ,
				ifnull(sum(verydissatisfiedcount),0) verydissatisfiedcount,
				convert(cast(sum(verydissatisfiedcount) as double)/count(surveyid) * 100, decimal(5,1)) verydissatisfiedpercent 
				from(
				select s.surveyid,destchannel,
				case when responsevalue = 5 then 1 else 0 end verysatisfiedcount,
				case when responsevalue = 4 then 1 else 0 end satisfiedcount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end dissatisfiedneutralcount,
				case when responsevalue = 1 then 1 else 0 end verydissatisfiedcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='csat'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='csat' )csat group by destchannel;
		elseif (p_Type='destchannelnps')
		then
				select destchannel,count(surveyid) totalresponse, 
				ifnull(sum(promotercount),0) promotercount,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100, decimal(5,1)) promoterpercent ,
				ifnull(sum(passivecount),0) passivecount,
				convert(cast(sum(passivecount) as double)/count(surveyid) * 100, decimal(5,1)) passivepercent, 
				ifnull(sum(detractorcount),0) detractorcount,
				convert(cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,1)) detractorpercent ,
				convert(cast(sum(promotercount) as double)/count(surveyid) * 100 -cast(sum(detractorcount) as double)/count(surveyid) * 100, decimal(5,0)) nps
				from (
				select s.surveyid,destchannel,
				case when responsevalue <=10 and responsevalue >=9 then 1 else 0 end promotercount,
				case when responsevalue <=8 and responsevalue >=7 then 1 else 0 end passivecount,
				case when responsevalue <=6 and responsevalue >=0 then 1 else 0 end detractorcount
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='nps'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='nps')nps group by destchannel;
		elseif (p_Type='destchannelces')
		then
				select destchannel,count(surveyid) totalresponse, 
				ifnull(sum(stronglyagreecount),0) stronglyagreecount,
				convert(cast(sum(stronglyagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglyagreepercent ,
				ifnull(sum(agreecount),0) agreecount,
				convert(cast(sum(agreecount) as double)/count(surveyid) * 100, decimal(5,1)) agreepercent ,
				ifnull(sum(neutralcount),0) neutralcount,
				convert(cast(sum(neutralcount) as double)/count(surveyid) * 100, decimal(5,1)) neutralpercent ,
				ifnull(sum(disagreecount),0) disagreecount,
				convert(cast(sum(disagreecount) as double)/count(surveyid) * 100, decimal(5,1)) disagreepercent ,
				ifnull(sum(stronglydisagreecount),0) stronglydisagreecount,
				convert(cast(sum(stronglydisagreecount) as double)/count(surveyid) * 100, decimal(5,1)) stronglydisagreepercent ,
				convert(cast(sum(responsevalue) as double)/count(surveyid), decimal(5,1)) ces
				from(
				select s.surveyid,responsevalue,destchannel,
				case when responsevalue = 5 then 1 else 0 end stronglyagreecount,
				case when responsevalue = 4 then 1 else 0 end agreecount,
				case when responsevalue = 3 then 1 else 0 end neutralcount,
				case when responsevalue = 2 then 1 else 0 end disagreecount,
				case when responsevalue = 1 then 1 else 0 end stronglydisagreecount 
				from tetherfi_customer_survey s 
				left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype='ces'
				inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype='ces')ces	group by destchannel;
		elseif (p_Type='sessionscore')
		then
				
		select sessionid, agentid, cif,srcchannel,destchannel,r.surveytype, responsevalue score ,

		case when r.surveytype='ces' then 
						case when responsevalue = 5 then 'stronglyagree' else 
						case when responsevalue = 4  then 'agree' else
						case when responsevalue = 3 then 'neutral'else
						case when responsevalue = 2  then 'disagree'else
						case when responsevalue = 1 then 'stronglydisagree' end end end end end  else 

		case when r.surveytype='nps' then 
		case when responsevalue <=10 and responsevalue >=9 then 'promoter' else
						case when responsevalue <=8 then 'passive' else
						case when responsevalue <=6 and responsevalue >=0 then 'detractor' end end end   else 
				
				
		case when r.surveytype='csat' then 
		 case when responsevalue = 5 then 'verysatisfiedcount' else 
						case when responsevalue = 4  then 'satisfiedcount' else
						case when responsevalue = 3 then 'neutral'else
						case when responsevalue = 2  then 'dissatisfied'else
						case when responsevalue = 1 then 'verydissatisfied' end end end end end  else  '' end 
				
						end end scoredescription
		from tetherfi_customer_survey s 
		left join tetherfi_customer_survey_response r on s.surveyid=r.surveyid and r.surveytype in('nps','ces','csat')
		inner join tetherfi_customer_survey_response_value v on v.responseid=r.responseid  and r.surveytype in('nps','ces','csat');

		end if; 
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_CustomReport
DELIMITER //
CREATE PROCEDURE `Get_CustomReport`(
p_Type VARCHAR(20),
p_SearchString LONGTEXT,
p_SortString VARCHAR(1000),
p_PageNo INT /* = 1 */,
p_PageSize INT /* = 10 */,
OUT p_TotalPageSize INT,
p_Query LONGTEXT,
p_OrderbyString LONGTEXT)
BEGIN
	Declare v_lPageNbr INT;
	Declare v_lPageSize INT;
	Declare v_lFirstRec INT;
	Declare v_lLastRec INT;
	Declare v_lTotalRows INT;
   Declare v_CombineQuery LONGTEXT;
   Declare v_MAIN LONGTEXT;
   Declare v_TotalCount LONGTEXT;	

		
		SET p_TotalPageSize = 0;
		SET v_lPageNbr = p_PageNo;
		SET v_lPageSize = p_PageSize;
		SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
		SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );
		SET v_MAIN = p_Query;

	IF(p_Type = 'MAIN' and p_Query like '%Get_AgentCallDivertedReport%')
	then
    	SET v_MAIN= Concat('',p_Query,'');
					SET @stmt_str = v_MAIN;
					PREPARE stmt FROM @stmt_str;
					EXECUTE stmt;
					DEALLOCATE PREPARE stmt;
	elseif (p_Type = 'MAIN')
		THEN
			SET v_MAIN= Concat('',p_Query,'');

			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY ',p_OrderbyString,' ASC) RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1 ',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR) ,' ',p_SortString);
			
			SET v_TotalCount = CONCAT('SELECT COUNT(*) INTO @x FROM(',v_MAIN,')AS table12 Where 1=1 ',p_SearchString);
			
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			 
			SET @stmt_strtotcnt = v_TotalCount;
			PREPARE stmt1 FROM @stmt_strtotcnt;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 
	      SET p_TotalPageSize :=  @x;
	      
	ELSEIF ( p_Type='DETAIL')	
		THEN
			SET v_MAIN= Concat('',p_Query,'');
			
					SET @stmt_str = v_MAIN;
					PREPARE stmt FROM @stmt_str;
					EXECUTE stmt;
					DEALLOCATE PREPARE stmt;
	END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_DropRequest
DELIMITER //
CREATE PROCEDURE `Get_DropRequest`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(8), 
p_ToDate VARCHAR(8),
p_Prefix VARCHAR(250),
p_SubType VARCHAR(100))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate; 
	--  SQLINES DEMO *** ata for calltrace
	IF(p_Type = 'MAIN')
	THEN	
			  	SELECT R.CLID,REQUEST_DATE,REQUEST_TIME,R.PREFIX,R.NRIC,CARD_NUMBER,HANDPHONE,
			OTHER_INFORMATION,ASSIGNED_TO, ASSIGNED_DATE, ASSIGNED_TIME, PROCESS_DATE, PROCESS_TIME,STATUS, G.AgentName, 
			G.SupervisorName, G.DepartmentName,(case when TPIN_VERIFIED = 'pass' then 'Y' else 'N' end) as verified_tpin,
			(case when OTP_VERFIFIED = 'pass' then 'Y' else 'N' end) as verified_otp from 
			(GBL_DROP_REQUESTS R left join GBL_Agent_Interaction G on (G.ID = R.srno AND (G.Type = 'DROP' OR G.Type IS NULL)))
			left join IVR_Call_History H on H.ICH_CALLREFID = R.SESSIONID  WHERE R.Channel = 'Voice'  AND R.REQUEST_DATE >= v_DataFromDate AND R.REQUEST_DATE <= v_DataToDate;                         		   
	END IF;

END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_EmailSkillDaily_Report
DELIMITER //
CREATE PROCEDURE `Get_EmailSkillDaily_Report`(
	p_FromDate VARCHAR(8),
	p_ToDate VARCHAR(8),
	p_FromTime VARCHAR(8),
	p_ToTime VARCHAR(8),
	p_OrgUnit TEXT
)
BEGIN

DECLARE v_EmailsReceived INT;
DECLARE v_EmailsReplied INT;
DECLARE v_EmailsAssigned INT;
DECLARE v_EmailsNotAssigned INT;
DECLARE v_EmailsClosed INT;
DECLARE v_EmailsASA INT;
DECLARE v_EmailsAHT INT;
DECLARE v_EmailsInBacklog INT;
DECLARE v_AvgASA INT;
DECLARE v_ASACount INT;
DECLARE v_AvgAHT INT;
DECLARE v_AHTCount INT;
DECLARE v_ASASum INT;
DECLARE v_AHTSum INT;

-- to generate all dates between @p_FromDate and @p_ToDate
DECLARE v_dt1 DATETIME(3) DEFAULT `VARCHARTODATETIME`(concat(p_FromDate , '235959'));
DECLARE v_dt2 DATETIME(3) DEFAULT `VARCHARTODATETIME`(concat(p_ToDate , '235959'));
DECLARE v_currentDate DATETIME(3) DEFAULT v_dt1;

-- check the count of records in SkillDetails
DECLARE v_skillCount INT;
DECLARE v_datecount INT;
DECLARE v_datecounter INT DEFAULT 1;
DECLARE v_mindaterow bigint;

DECLARE v_currentID BIGINT;
DECLARE v_skill VARCHAR(50);
DECLARE v_skillname VARCHAR(50);
DECLARE v_loop_date VARCHAR(20);

DROP TEMPORARY TABLE IF EXISTS tmp_SeparateASA;
CREATE TEMPORARY TABLE tmp_SeparateASA (ASA INT);

DROP TEMPORARY TABLE IF EXISTS tmp_SeparateAHT;
CREATE TEMPORARY TABLE tmp_SeparateAHT (AHT INT);

-- final table toÂ 
DROP TEMPORARY TABLE IF EXISTS tmp_TEMP;
CREATE TEMPORARY TABLE tmp_TEMP (`DateTime` VARCHAR(20),SkillName VARCHAR(50),
TotalEmailsReceived VARCHAR(50),TotalEmailsReplied VARCHAR(50),TotalEmailsAssigned varchar(50),
TotalEmailsNotAssigned VARCHAR(20), TotalEmailsClosed VARCHAR(20), ASA VARCHAR(20), AHT VARCHAR(20), Backlog VARCHAR(20));

-- temp table to hold orgunits of mailbox
DROP TEMPORARY TABLE IF EXISTS tmp_OrgUnitsMailAccountName;
CREATE TEMPORARY TABLE tmp_OrgUnitsMailAccountName (MailAccountName varchar(100));

-- this temp table used to loop through all the dates with skill
DROP TEMPORARY TABLE IF EXISTS tmp_DateRange;
CREATE TEMPORARY TABLE tmp_DateRange (Id bigint AUTO_INCREMENT KEY,`DateTime` VARCHAR(20));

-- this temp table used to loop through all the dates with skill
DROP TEMPORARY TABLE IF EXISTS tmp_SkillDetails;
CREATE TEMPORARY TABLE tmp_SkillDetails (Id bigint AUTO_INCREMENT KEY,`Skill` varchar(50),`SkillName` varchar(50));

BEGIN
	set p_ToTime='235959';
	set p_FromTime='000000';

	INSERT INTO tmp_OrgUnitsMailAccountName 
	SELECT MailAccountName FROM Email_AccountConfiguration C 
	INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
	WHERE FIND_IN_SET(teamid,p_OrgUnit)>0;

	WHILE v_currentDate <= v_dt2 
	DO
		INSERT INTO tmp_DateRange (`DateTime`) 
		SELECT DATE_FORMAT (v_currentDate, '%Y%m%d') `DateTime`;

		SET v_currentDate = TIMESTAMPADD(day, 1, v_currentDate);
	END WHILE;
	
	-- filling temp table with skill and dates
	INSERT INTO tmp_SkillDetails (`Skill`,`SkillName`) 
	SELECT DISTINCT R.Skill, S.SkillName 
	FROM Email_Routes R
	INNER JOIN TMAC_Skills S ON S.SkillExtension = R.Skill
	INNER JOIN Email_Inbox E ON E.SessionID = R.SessionID
	WHERE R.Skill IS NOT NULL 
	AND E.Mailbox IN (SELECT MailAccountName FROM tmp_OrgUnitsMailAccountName)
	AND R.RouteDateTime BETWEEN CONCAT(p_FromDate , p_FromTime) AND CONCAT(p_ToDate , p_ToTime)
	ORDER BY S.SkillName;
	
	-- check the count of records in SkillDetails
	SET v_skillCount = (SELECT COUNT(1) FROM tmp_SkillDetails);
	SET v_datecount = (SELECT COUNT(1) FROM tmp_DateRange);
	
	-- loop through each record present in SkillDetails table, one record at a time.
	WHILE v_skillCount > 0
	DO
   	SET v_currentID = (SELECT ID FROM tmp_SkillDetails LIMIT 1);
   	SET v_skill = (SELECT Skill FROM tmp_SkillDetails WHERE ID = v_currentID);
   	SET v_skillname = (SELECT SkillName FROM tmp_SkillDetails WHERE ID = v_currentID);
   	SET v_mindaterow = (SELECT MIN(ID) FROM tmp_DateRange);
   	
   	WHILE(v_datecounter <= v_datecount)
		DO
			SET v_loop_date=(SELECT `DateTime` FROM tmp_DateRange WHERE ID = v_mindaterow);
			
			-- Total Email Recived betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			SELECT COUNT(distinct R.sessionid) INTO v_EmailsReceived FROM Email_Routes R 
			INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
			WHERE RouteDateTime>= CONCAT(v_loop_date , p_FromTime) AND RouteDateTime<= CONCAT(v_loop_date, p_ToTime) 
			AND Skill = v_skill AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			-- Total Emails Replied betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			SELECT COUNT(1) INTO v_EmailsReplied FROM Email_Routes A 
			INNER JOIN Email_Inbox B ON A.sessionid=B.sessionid 
			WHERE A.RepliedDateTime>= CONCAT(v_loop_date , p_FromTime) AND A.RepliedDateTime<= CONCAT(v_loop_date , p_ToTime) 
			AND A.Skill = v_skill AND (A.CurrentStatus = 'Replied' or A.currentStatus='Closed' ) 
			AND RouteType!='Reopen' AND B.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			-- Total Emails Assigned betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			SELECT COUNT(1) INTO v_EmailsAssigned FROM Email_Routes R 
			INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
			WHERE AssingedDateTime>= CONCAT(v_loop_date , p_FromTime) AND AssingedDateTime<= CONCAT(v_loop_date , p_ToTime) 
			AND Skill = v_skill AND ClosedDateTime IS NULL AND RouteType != 'Reopen' AND RepliedDateTime IS NULL 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			-- Total Emails Not Assigned betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			SELECT COUNT(distinct R.sessionid) INTO v_EmailsNotAssigned FROM Email_Routes R 
			INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
			WHERE RouteDateTime>= CONCAT(v_loop_date , p_FromTime) AND RouteDateTime<= CONCAT(v_loop_date , p_ToTime) 
			AND Skill = v_skill AND R.CurrentStatus = 'Queue' AND 
			E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			-- Total Emails Cloased betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			Select COUNT(distinct R.sessionid) INTO v_EmailsClosed FROM Email_Routes R 
			INNER JOIN Email_Inbox I on I.SessionID = R.SessionID 
			WHERE AssingedDateTime>= CONCAT(v_loop_date , p_FromTime) AND AssingedDateTime<= CONCAT(v_loop_date , p_ToTime) 
			AND CONCAT(ClosedDate,ClosedTime) >= CONCAT(v_loop_date,p_FromTime) AND 
			CONCAT(ClosedDate,ClosedTime) <= CONCAT(v_loop_date,p_ToTime) AND Skill = v_skill AND 
			I.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			-- Total Emails in backlog betweenÂ  @loop_date+@p_FromTime and @loop_date+ @p_ToTime
			Select COUNT(1) INTO v_EmailsInBacklog FROM Email_Inbox 
			WHERE IFNULL(ClosedDate,'')='' AND CMSkill = v_skill 
			AND CONCAT(ReceivedDate,ReceivedTime) >= CONCAT(v_loop_date,p_FromTime) AND 
			CONCAT(ReceivedDate,ReceivedTime) <= CONCAT(v_loop_date,p_ToTime) 
			AND CurrentStatus NOT IN( 'DirectEmailAnswered','Closed', 'CloseWithReply', 'Closewithoutreply','Answered','SentToCustomer') 
			AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
			
			DROP TEMPORARY TABLE IF EXISTS tmp_OrgUnitsMailAccountNameCopy;
			CREATE TEMPORARY TABLE tmp_OrgUnitsMailAccountNameCopy AS 
			SELECT * FROM tmp_OrgUnitsMailAccountName;

			-- To get ASA to that Skill
			INSERT INTO tmp_SeparateASA
			Select (timestampdiff(SECOND,VARCHARTODATETIME(A.RouteDateTime),VARCHARTODATETIME(D.ClosedDateTime))) 
			FROM (
				SELECT R.SessionID,RouteDateTime 
				FROM Email_Routes R INNER JOIN Email_Inbox I on I.SessionID = R.SessionID 
				WHERE RouteDateTime>= CONCAT(v_loop_date,p_FromTime) AND RouteDateTime <= CONCAT(v_loop_date,p_ToTime) 
				AND Skill = v_skill AND ClosedDateTime IS NOT NULL AND 
				I.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
			) A 
			INNER JOIN (
				SELECT R.SessionID,ClosedDateTime 
				FROM Email_Routes R INNER JOIN Email_Inbox I on I.SessionID = R.SessionID 
				WHERE R.CurrentStatus in('CloseWithReply','Closed','Approved','EditApproved','CloseWithoutReply') 
				AND RouteDateTime>= CONCAT(v_loop_date,p_FromTime) AND RouteDateTime<= CONCAT(v_loop_date,p_ToTime) 
				AND Skill = v_skill AND I.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountNameCopy)
			) D on A.SessionID = D.SessionID;
			
			-- CALCULATE THE AVERAGE ASA
			SET v_ASACount = (SELECT COUNT(*) FROM tmp_SeparateASA);
			SET v_ASASum = (SELECT SUM(ASA) FROM tmp_SeparateASA);
			
			IF(v_ASACount !=0) THEN 
				BEGIN
					SET v_EmailsASA = IFNULL(v_ASASum,0)/IFNULL(v_ASACount,1);
				END;
			ELSE
				BEGIN
					SET v_EmailsASA =0;
				END;
			END IF;
			
			-- To get Active Time(AHT) to that SkillÂ 
			INSERT INTO tmp_SeparateAHT
				Select timestampdiff(SECOND,VARCHARTODATETIME(R.AssingedDateTime),VARCHARTODATETIME(R.ClosedDateTime)) 
				FROM Email_Routes R INNER JOIN Email_Inbox I ON I.SessionID = R.SessionID 
				WHERE R.CurrentStatus IN ('CloseWithReply','Closed','Approved','EditApproved','CloseWithoutReply') 
				AND AssingedDateTime>= CONCAT(v_loop_date,p_FromTime) AND AssingedDateTime<= CONCAT(v_loop_date,p_ToTime) 
				AND Skill = v_skill AND I.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
				
			-- CALCULATE THE AVERAGE AHT
			SET v_AHTCount = (SELECT COUNT(*) FROM tmp_SeparateAHT);
			SET v_AHTSum = (SELECT SUM(AHT) FROM tmp_SeparateAHT);
				
			IF(v_AHTCount !=0) THEN
				BEGIN
					SET v_EmailsAHT = IFNULL(v_AHTSum,0)/IFNULL(v_AHTCount,1);
				END;
			ELSE
				BEGIN
					SET v_EmailsAHT =0;
				END;
			END IF;
				
			-- final table which holds calculated data
			INSERT INTO tmp_TEMP VALUES (ifnull(v_loop_date,0),ifnull(v_skillname,0),
			ifnull(v_EmailsReceived,0),ifnull(v_EmailsReplied,0),ifnull(v_EmailsAssigned,0),
			ifnull(v_EmailsNotAssigned,0),ifnull(v_EmailsClosed,0),ifnull(v_EmailsASA,0),
			ifnull(v_EmailsAHT,0),ifnull(v_EmailsInBacklog,0));
			
			SET v_EmailsAHT =0;
			SET v_EmailsASA =0;
			
			delete from tmp_SeparateASA;
			delete from tmp_SeparateAHT;

			SET v_datecounter= v_datecounter + 1;
			SET v_mindaterow=v_mindaterow+1;
		END WHILE;
		
		-- delete the record from the temptable once the calculation is done
		DELETE FROM tmp_SkillDetails WHERE ID = v_currentID;
		
		-- set the new countvalue
		SET v_skillCount = (SELECT COUNT(1) FROM tmp_SkillDetails);
		SET v_datecounter=1;
	END WHILE;
	
	SELECT * FROM tmp_TEMP ORDER BY `DateTime` ASC;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_EmailSLReportDrill
DELIMITER //
CREATE PROCEDURE `Get_EmailSLReportDrill`(
p_Skill VARCHAR(20), 
p_FromDate VARCHAR(8), 
p_ToDate VARCHAR(8), 
p_FromTime VARCHAR(8), 
p_ToTime VARCHAR(8), 
p_DrillType VARCHAR(20),
p_OrgUnit TEXT)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	IF(IFNULL(p_Skill,'') != '')
	THEN
	SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
	SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);
	
	IF(p_DrillType = 'EmailsReceived')
		THEN
			SELECT A.SessionID, CONCAT(IFNULL(T.FirstName,'') , '- ' , IFNULL(T.LastName,'')) AS 'AssignedTo', A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, '0' AS BacklogMinute
			FROM Email_Routes A INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
			LEFT JOIN AGT_Agent T on T.AvayaLoginID = A.AssignedTo
			WHERE RouteDateTime>= v_DataFromDate and RouteDateTime<= v_DataToDate and Skill = p_Skill AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
		END IF;
	END IF;
	IF(p_DrillType = 'EmailsInQueue')
	THEN
		SELECT A.SessionID, 'N/A' AS 'AssignedTo', A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, '0' AS BacklogMinute
		FROM Email_Routes A INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
		WHERE RouteDateTime>=v_DataFromDate  and RouteDateTime<=v_DataToDate and Skill = p_Skill and 
			A.CurrentStatus = 'Queue' AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	END IF;
	IF(p_DrillType = 'EmailsClosed')
	THEN
		SELECT A.SessionID, CONCAT(IFNULL(T.FirstName,'') , '- ' , IFNULL(T.LastName,'')) AS 'AssignedTo', A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, '0' AS BacklogMinute
		FROM Email_Routes A INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
		LEFT JOIN AGT_Agent T on T.AvayaLoginID = A.AssignedTo		
		WHERE
		A.SessionID IN (SELECT E.SessionID FROM Email_Routes R
		Inner join Email_Inbox E on E.SessionID = R.SessionID 
		WHERE AssingedDateTime>= v_DataFromDate and AssingedDateTime <= v_DataToDate
		and CONCAT(ClosedDate,ClosedTime) >= v_DataFromDate and CONCAT(ClosedDate,ClosedTime) <= v_DataToDate and A.CurrentStatus = 'Closed'
		and Skill = p_Skill) AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	END IF;
	IF(p_DrillType = 'EmailsAssigned')
	THEN
		SELECT A.SessionID, CONCAT(IFNULL(T.FirstName,'') , '- ' , IFNULL(T.LastName,'')) AS 'AssignedTo', A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, '0' AS BacklogMinute
		FROM Email_Routes A 
		INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
		LEFT JOIN AGT_Agent T on T.AvayaLoginID = I.AssignedTo
		WHERE AssingedDateTime>= v_DataFromDate and AssingedDateTime<= v_DataToDate  and Skill = p_Skill  and ClosedDateTime is null and A.CurrentStatus = 'Replied'
			AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit)); 
	END IF;
	IF(p_DrillType = 'EmailsOldest')
	THEN
		SELECT A.SessionID, 'N/A' AS 'AssignedTo' , A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime, '0' AS BacklogMinute
		FROM Email_Routes A INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
		WHERE
		A.SessionID IN (SELECT SessionID FROM Email_Inbox WHERE CMSKILL = p_Skill
	AND  IFNULL(AssignedDate,'')='' AND CONCAT(ReceivedDate,ReceivedTime) >=  v_DataFromDate  and  CONCAT(ReceivedDate,ReceivedTime) <= v_DataToDate ) AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	END IF;
	IF(p_DrillType = 'EmailsInBacklog')
	THEN
		SELECT A.SessionID, CONCAT(IFNULL(T.FirstName,'') , '- ' , IFNULL(T.LastName,'')) AS 'AssignedTo' , A.AssingedDateTime, I.`From`, I.`Subject`, IFNULL(I.Intent,'N/A') AS Intent, A.CurrentStatus, A.RouteDateTime as ActionDateTime,
		TIMESTAMPDIFF(MINUTE, CONVERT(INSERT(INSERT(INSERT(A.AssingedDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime), NOW(3)) AS BacklogMinute
		FROM Email_Routes A INNER JOIN Email_Inbox I on A.SessionID = I.SessionID
		LEFT JOIN AGT_Agent T on T.AvayaLoginID = I.AssignedTo
		WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' and CMSkill = p_Skill 
	        and (( CONCAT(ReceivedDate,ReceivedTime) >= v_DataFromDate and CONCAT(ReceivedDate,ReceivedTime) <= v_DataToDate )) AND
			I.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit));
	END IF;
	END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_EmailSL_Report
DELIMITER //
CREATE PROCEDURE `Get_EmailSL_Report`(
	p_FromDate VARCHAR(20),
	p_ToDate VARCHAR(20),
	p_FromTime VARCHAR(8),
	p_ToTime VARCHAR(8),
	p_OrgUnit TEXT
)
BEGIN

DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

DECLARE v_EmailsInQueue INT;
DECLARE v_EmailsAssigned INT;

DECLARE v_EmailsInBacklog INT;
DECLARE v_EmailsInBacklog12 INT;
DECLARE v_EmailsInBacklog24 INT;
DECLARE v_EmailsInBacklog48 INT;
DECLARE v_EmailsInBacklog72 INT;
DECLARE v_EmailsInBacklog96 INT;
DECLARE v_EmailsInBacklog120 INT;
DECLARE v_EmailsInBacklogOver120 INT;

DECLARE v_EmailsReceived INT;
DECLARE v_EmailsReceived12 INT;
DECLARE v_EmailsReceived24 INT;
DECLARE v_EmailsReceived48 INT;
DECLARE v_EmailsReceived72 INT;
DECLARE v_EmailsReceived96 INT;
DECLARE v_EmailsReceived120 INT;
DECLARE v_EmailsReceivedOver120 INT;

DECLARE v_EmailsInSL12 INT;
DECLARE v_EmailsInSL24 INT;
DECLARE v_EmailsInSL48 INT;
DECLARE v_EmailsInSL72 INT;
DECLARE v_EmailsInSL96 INT;
DECLARE v_EmailsInSL120 INT;
DECLARE v_EmailsInSLOver120 INT;

DECLARE v_EmailsInSL12Count INT;
DECLARE v_EmailsInSL24Count INT;
DECLARE v_EmailsInSL48Count INT;
DECLARE v_EmailsInSL72Count INT;
DECLARE v_EmailsInSL96Count INT;
DECLARE v_EmailsInSL120Count INT;
DECLARE v_EmailsInSLOver120Count INT;

DECLARE v_EmailsOldest INT;
DECLARE v_EmailsOldestDate VARCHAR(50);
DECLARE v_EmailsAverageHandleTime VARCHAR(50);

DECLARE v_SLValue INT;
DECLARE v_SL1Value INT;
DECLARE v_SL2Value INT;
DECLARE v_SL3Value INT;
DECLARE v_SL4Value INT;
DECLARE v_SL5Value INT;
DECLARE v_SL6Value INT;

DECLARE v_SL DECIMAL(18,10);
DECLARE v_SL1 DECIMAL(18,10);
DECLARE v_SL2 DECIMAL(18,10);
DECLARE v_SL3 DECIMAL(18,10);
DECLARE v_SL4 DECIMAL(18,10);
DECLARE v_SL5 DECIMAL(18,10);
DECLARE v_SL6 DECIMAL(18,10);

DECLARE v_AvgAHT INT;
DECLARE v_AHTCount INT;
DECLARE v_AHTSum INT;
DECLARE v_EmailCompleted INT;

DECLARE v_mailCount INT;
DECLARE v_currentID INT;
DECLARE v_skillValue VARCHAR(50);
DECLARE v_skillName VARCHAR(50);


-- declare the temp tablesÂ 
DROP TEMPORARY TABLE IF EXISTS tmp_Calculation_Table;
CREATE TEMPORARY TABLE tmp_Calculation_Table (ID INT AUTO_INCREMENT KEY, SkillID INT,SkillName VARCHAR(50));

-- declare the result tablesÂ 
DROP TEMPORARY TABLE IF EXISTS tmp_Result_Table;
CREATE TEMPORARY TABLE tmp_Result_Table (SkillID INT,SkillName VARCHAR(50),TotalMailsReceived INT,
	TotalMailsInQueue INT,TotalMailsAssigned INT,TotalMailsCompleted INT,TotalBacklog INT,
	EmailsInBacklog12 INT,EmailsInBacklog24 INT,EmailsInBacklog48 INT,EmailsInBacklog72 INT, 
	EmailsInBacklog96 INT, EmailsInBacklog120 INT,EmailsInBacklogOver120 INT,SLABucket12 INT,
	SLABucket24 INT,SLABucket48 INT,SLABucket72 INT, SLABucket96 INT, SLABucket120 INT, 
	SLABucketOver120 INT,EmailsOldest INT, OldestMailwaiting VARCHAR(50),AverageHandleTime INT,
	EmailsReceived12 INT,EmailsReceived24 INT,EmailsReceived48 INT,
	EmailsReceived72 INT, EmailsReceived96 INT, EmailsReceived120 INT, EmailsReceivedOver120 INT, 
	EmailsCompleted12 INT,EmailsCompleted24 INT,EmailsCompleted48 INT,EmailsCompleted72 INT, 
	EmailsCompleted96 INT,EmailsCompleted120 INT, EmailsCompletedOver120 INT, EmailSLABucket12Count INT,
	EmailSLABucket24Count INT,EmailSLABucket48Count INT,EmailSLABucket72Count INT, EmailSLABucket96Count INT, 
	EmailSLABucket120Count INT, EmailSLABucketOver120Count INT);

DROP TEMPORARY TABLE IF EXISTS tmp_SeparateAHT;
CREATE TEMPORARY TABLE tmp_SeparateAHT (AHT INT);

-- temp table to hold orgunits of mailbox
DROP TEMPORARY TABLE IF EXISTS tmp_OrgUnitsMailAccountName;
CREATE TEMPORARY TABLE tmp_OrgUnitsMailAccountName (MailAccountName varchar(100));

BEGIN
	SET v_DataFromDate = CONCAT(p_FromDate , p_FromTime);
	SET v_DataToDate = CONCAT(p_ToDate , p_ToTime);
	
	INSERT INTO tmp_OrgUnitsMailAccountName 
	SELECT MailAccountName FROM Email_AccountConfiguration C 
	INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid 
	WHERE FIND_IN_SET(teamid,p_OrgUnit)>0;
	
	-- To get total skills assigned
	INSERT INTO tmp_Calculation_Table (SkillID,SkillName) 
		SELECT DISTINCT Skill as SkillID, SkillName as SkillName FROM Email_Routes R 
		INNER JOIN TMAC_Skills S on S.SkillExtension = R.Skill 
		INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
		WHERE IFNULL(R.Skill,'') !='' AND RouteDateTime >= v_DataFromDate AND RouteDateTime <= v_DataToDate 
		AND Skill IS NOT NULL AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

	-- check the count of records in calculation table 
	SET v_mailCount = (SELECT COUNT(1) FROM tmp_Calculation_Table);

	-- loop through each record present in calculation table, one record at a time.
	WHILE (v_mailCount>0) 
	DO 
		SET v_currentID = (SELECT ID FROM tmp_Calculation_Table LIMIT 1);
		SET v_skillValue = (SELECT SkillID FROM tmp_Calculation_Table WHERE ID = v_currentID);
		SET v_skillName = (SELECT SkillName FROM tmp_Calculation_Table WHERE ID = v_currentID);
		
		-- check if the mailbox is already present in final result table,
		if NOT EXISTS (SELECT SkillID FROM tmp_Result_Table WHERE SkillID = v_skillValue) 
		THEN
			BEGIN 
				-- if not present then add a record with mailbox value to final result table,and dont delete the record from calculation table
 				INSERT INTO tmp_Result_Table VALUES(v_skillValue,v_skillName,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
 			END;
 		END if;

		-- To get No of Emails In Queue to that Skill
		SELECT COUNT(distinct R.sessionid) INTO v_EmailsInQueue FROM Email_Routes R 
		INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
		WHERE RouteDateTime >= v_DataFromDate AND RouteDateTime <= v_DataToDate AND Skill = v_skillValue AND 
		R.CurrentStatus = 'Queue' AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- To get No of Emails Assigned to that Skill
		SELECT COUNT(distinct R.sessionid) INTO v_EmailsAssigned FROM Email_Routes R 
		INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
		WHERE AssingedDateTime >= v_DataFromDate AND AssingedDateTime <= v_DataToDate AND Skill = v_skillValue 
		AND R.CurrentStatus='Replied' AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- To get No of Emails Received to that Skill
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived FROM Email_Inbox 
		WHERE CONCAT(ReceivedDate,ReceivedTime)>= v_DataFromDate and CONCAT(ReceivedDate,ReceivedTime)<= v_DataToDate 
		AND CMSkill = v_skillValue AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 12 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived12 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue AND VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-0.5)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 24 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived24 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-1)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 48 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived48 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-2)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 72 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived72 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-3)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 96 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived96 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-4)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in last 120 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceived120 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) 
		BETWEEN (VARCHARTODATETIME(v_DataToDate)-5)and(VARCHARTODATETIME(v_DataToDate)) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- no of of emails got in over 120 hours
		SELECT COUNT(distinct sessionid) INTO v_EmailsReceivedOver120 FROM Email_Inbox 
		WHERE CMSkill = v_skillValue and VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)) <(VARCHARTODATETIME(v_DataToDate)-5) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- To get Total No of Emails in backlog for that Skill
		SELECT COUNT(distinct sessionid) INTO v_EmailsInBacklog FROM Email_Inbox 
		WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' and CMSkill = v_skillValue 
		AND (CONCAT(ReceivedDate,ReceivedTime) >= v_DataFromDate and CONCAT(ReceivedDate,ReceivedTime) <= v_DataToDate) 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- To get Total No of Emails in backlog for that Skill in last 12 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog12 FROM (
			SELECT DISTINCT sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) BETWEEN (VARCHARTODATETIME(v_DataToDate)-0.5) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName) 
		)AS x where TimeTaken <= 720;

		-- To get Total No of Emails in backlog for that Skill in last 24 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog24 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE ClosedDate is null and RepliedDate is NULL 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) BETWEEN (VARCHARTODATETIME(v_DataToDate)-1) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken <= 1440;

		-- To get Total No of Emails in backlog for that Skill in last 48 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog48 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) BETWEEN (VARCHARTODATETIME(v_DataToDate)-2) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken <= 2880;

		-- To get Total No of Emails in backlog for that Skill in last 72 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog72 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) BETWEEN (VARCHARTODATETIME(v_DataToDate)-3) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken <= 4320;

		-- To get Total No of Emails in backlog for that Skill in last 96 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog96 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) BETWEEN (VARCHARTODATETIME(v_DataToDate)-4) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken <= 5760;

		-- To get Total No of Emails in backlog for that Skill in last 120 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklog120 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) between(VARCHARTODATETIME(v_DataToDate)-5) 
			AND (VARCHARTODATETIME(v_DataToDate)) AND E.cmskill= v_skillValue 
			AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken <= 7200;

		-- To get Total No of Emails in backlog for that Skill in over 120 hours
		SELECT COUNT(TimeTaken) INTO v_EmailsInBacklogOver120 FROM (
			select distinct sessionid, timestampdiff(minute, VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)),
			VARCHARTODATETIME(v_DataToDate)) AS TimeTaken from Email_Inbox E 
			WHERE IFNULL(ClosedDate,'')='' and IFNULL(RepliedDate,'')='' 
			AND VARCHARTODATETIME(CONCAT(E.ReceivedDate,E.ReceivedTime)) <(VARCHARTODATETIME(v_DataToDate)-5) 
			AND E.cmskill= v_skillValue AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName)
		)AS x where TimeTaken > 7200;

		-- To get SLAÂ  of Emails for that Skill
		SET v_EmailsInSL12 = IFNULL(abs((v_EmailsReceived12 - v_EmailsInBacklog12) * 100)/nullif(v_EmailsReceived12,0),100);
		-- To get SLA 1 of Emails for that Skill
		SET v_EmailsInSL24 = IFNULL(abs((v_EmailsReceived24 - v_EmailsInBacklog24) * 100)/nullif(v_EmailsReceived24,0),100);
		-- To get SLA 2 of Emails for that Skill
		SET v_EmailsInSL48 = IFNULL(abs((v_EmailsReceived48 - v_EmailsInBacklog48)*100)/nullif(v_EmailsReceived48,0),100);
		-- To get SLA 3 of Emails for that Skill
		SET v_EmailsInSL72 = IFNULL(abs((v_EmailsReceived72 - v_EmailsInBacklog72)*100)/nullif(v_EmailsReceived72,0),100);
		-- To get SLA 4 of Emails for that Skill
		SET v_EmailsInSL96 = IFNULL(abs((v_EmailsReceived96 - v_EmailsInBacklog96)*100)/nullif(v_EmailsReceived96,0),100);
		-- To get SLA 5 of Emails for that Skill
		SET v_EmailsInSL120 = IFNULL(abs((v_EmailsReceived120 - v_EmailsInBacklog120)*100)/nullif(v_EmailsReceived120,0),100);
		
		-- To get SLA 6 of Emails for that Skill
		SET v_EmailsInSLOver120 = IFNULL(abs((v_EmailsReceivedOver120 - v_EmailsInBacklogOver120)*100)/nullif(v_EmailsReceivedOver120,0),100);
		SET v_EmailsInSL12Count = abs(v_EmailsReceived12 - v_EmailsInBacklog12);
		SET v_EmailsInSL24Count = abs(v_EmailsReceived24 - v_EmailsInBacklog24);
		SET v_EmailsInSL48Count = abs(v_EmailsReceived48 - v_EmailsInBacklog48);
		SET v_EmailsInSL72Count = abs(v_EmailsReceived72 - v_EmailsInBacklog72);
		SET v_EmailsInSL96Count = abs(v_EmailsReceived96 - v_EmailsInBacklog96);
		SET v_EmailsInSL120Count = abs(v_EmailsReceived120 - v_EmailsInBacklog120);
		SET v_EmailsInSLOver120Count = abs(v_EmailsReceivedOver120 - v_EmailsInBacklogOver120);

		-- To get Oldest Emails In Queue to that Skill
		SELECT SUM(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(CONCAT(ReceivedDate,ReceivedTime)), NOW(3))) 
		INTO v_EmailsOldest FROM Email_Inbox WHERE CMSKILL = v_skillValue 
		AND IFNULL(AssignedDate,'')='' AND CONCAT(ReceivedDate,ReceivedTime) >= v_DataFromDate AND 
		CONCAT(ReceivedDate,ReceivedTime) <= v_DataToDate 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		SELECT MAX(RouteDateTime) INTO v_EmailsOldestDate FROM Email_Routes R 
		INNER JOIN Email_Inbox E ON E.SessionID = R.SessionID 
		WHERE skill = v_skillValue AND RouteDateTime >= v_DataFromDate AND RouteDateTime <= v_DataToDate 
		AND E.Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);
		
		SELECT COUNT(distinct E.SessionID) INTO v_EmailCompleted FROM Email_Routes R
		INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
		WHERE AssingedDateTime>= v_DataFromDate and AssingedDateTime <= v_DataToDate 
		AND CONCAT(ClosedDate,ClosedTime) >= v_DataFromDate and CONCAT(ClosedDate,ClosedTime) <= v_DataToDate 
		AND R.CurrentStatus = 'Closed' and Skill = v_skillValue 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- To get Active Time(AHT) to that SkillÂ Â 
		INSERT INTO tmp_SeparateAHT 
		SELECT TIMESTAMPDIFF(SECOND, VARCHARTODATETIME(R.AssingedDateTime),
		VARCHARTODATETIME(IFNULL(R.RepliedDateTime,R.ClosedDateTime)))
		From Email_Routes R INNER JOIN Email_Inbox E on E.SessionID = R.SessionID 
		Where R.CurrentStatus in('CloseWithReply','Closed','Approved','EditApproved','CloseWithoutReply','Replied') 
		AND AssingedDateTime >= v_DataFromDate AND AssingedDateTime <= v_DataToDate AND Skill = v_skillValue 
		AND Mailbox IN (select MailAccountName from tmp_OrgUnitsMailAccountName);

		-- CALCULATE THE AVERAGE AHT
		SET v_AHTCount = (SELECT COUNT(*) FROM tmp_SeparateAHT);
		SET v_AHTSum = (SELECT SUM(AHT) FROM tmp_SeparateAHT);
		
		IF(v_AHTCount !=0) 
		THEN
			BEGIN
				SET v_EmailsAverageHandleTime = IFNULL(v_AHTSum,0)/IFNULL(v_AHTCount,1);
			END;
		ELSE
			BEGIN
				SET v_EmailsAverageHandleTime = 0;
			END;
		END IF; 

		-- keep updating the final result table with value current variable value and respective column value
		UPDATE tmp_Result_Table
		SET TotalMailsReceived = Ifnull(v_EmailsReceived,0),
		TotalMailsInQueue = Ifnull(v_EmailsInQueue,0),
		TotalMailsAssigned = Ifnull(v_EmailsAssigned,0),
		TotalMailsCompleted = Ifnull(v_EmailCompleted,0),
		TotalBacklog = Ifnull(v_EmailsInBacklog,0),

		EmailsInBacklog12 = Ifnull(v_EmailsInBacklog12,0),
		EmailsInBacklog24 = Ifnull(v_EmailsInBacklog24,0),
		EmailsInBacklog48 = Ifnull(v_EmailsInBacklog48,0),
		EmailsInBacklog72 = Ifnull(v_EmailsInBacklog72,0),
		EmailsInBacklog96 = Ifnull(v_EmailsInBacklog96,0),
		EmailsInBacklog120 = Ifnull(v_EmailsInBacklog120,0),
		EmailsInBacklogOver120 = Ifnull(v_EmailsInBacklogOver120,0),

		SLABucket12 = Ifnull(v_EmailsInSL12,0),
		SLABucket24 = Ifnull(v_EmailsInSL24,0),
		SLABucket48 = Ifnull(v_EmailsInSL48,0),
		SLABucket72 = Ifnull(v_EmailsInSL72,0),
		SLABucket96 = Ifnull(v_EmailsInSL96,0),
		SLABucket120 = Ifnull(v_EmailsInSL120,0),
		SLABucketOver120 = Ifnull(v_EmailsInSLOver120,0),

		EmailSLABucket12Count = ifnull( v_EmailsInSL12Count,0),
		EmailSLABucket24Count = ifnull( v_EmailsInSL24Count,0),
		EmailSLABucket48Count = ifnull( v_EmailsInSL48Count,0),
		EmailSLABucket72Count = ifnull( v_EmailsInSL72Count,0),
		EmailSLABucket96Count = ifnull( v_EmailsInSL96Count,0),
		EmailSLABucket120Count = ifnull( v_EmailsInSL120Count,0),
		EmailSLABucketOver120Count = ifnull( v_EmailsInSLOver120Count,0),

		EmailsOldest = Ifnull(v_EmailsOldest,0),
		OldestMailwaiting = v_EmailsOldestDate,
		AverageHandleTime = Ifnull(v_EmailsAverageHandleTime,0),

		EmailsReceived12 =Ifnull(v_EmailsReceived12,0),
		EmailsReceived24 =Ifnull(v_EmailsReceived24,0),
		EmailsReceived48 =Ifnull(v_EmailsReceived48,0),
		EmailsReceived72 =Ifnull(v_EmailsReceived72,0),
		EmailsReceived96 =Ifnull(v_EmailsReceived96,0),
		EmailsReceived120 =Ifnull(v_EmailsReceived120,0),
		EmailsReceivedOver120 =Ifnull(v_EmailsReceivedOver120,0),

		EmailsCompleted12 =Ifnull(v_EmailsReceived12 - v_EmailsInBacklog12,0),
		EmailsCompleted24 =Ifnull(v_EmailsReceived24 - v_EmailsInBacklog24,0),
		EmailsCompleted48 =Ifnull(v_EmailsReceived48 - v_EmailsInBacklog48,0),
		EmailsCompleted72 =Ifnull(v_EmailsReceived72 - v_EmailsInBacklog72,0),
		EmailsCompleted96 =Ifnull(v_EmailsReceived96 - v_EmailsInBacklog96,0),
		EmailsCompleted120 =Ifnull(v_EmailsReceived120 - v_EmailsInBacklog120,0),
		EmailsCompletedOver120 =Ifnull(v_EmailsReceivedOver120 - v_EmailsInBacklogOver120,0)
		WHERE SkillID = v_skillValue;

		-- delete the record from the temptable once the calculation is done
		DELETE FROM tmp_Calculation_Table WHERE ID = v_currentID;
		
		-- set the new countvalue
		SET v_mailCount = (SELECT COUNT(1) FROM tmp_Calculation_Table);
	END WHILE;
	SELECT * FROM tmp_Result_Table;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_EmailTrace_Report
DELIMITER //
CREATE PROCEDURE `Get_EmailTrace_Report`(
      p_Type VARCHAR(50),p_FilterType VARCHAR(50),p_FromDate VARCHAR(20),p_ToDate VARCHAR(20),p_FilterValue VARCHAR(100),p_Status VARCHAR(100), p_SessionID VARCHAR(20), p_OrgUnit TEXT
)
BEGIN
            DECLARE v_SelectSql LONGTEXT;
            DECLARE v_FilterBy LONGTEXT;
            DECLARE v_OrderBy LONGTEXT;
            
    IF(p_Type = 'EmailTraceSummary')
      THEN
      
            SET v_SelectSql = CONCAT('SELECT E.Mailbox, E.AssignedTime, E.`From`,E.`From`,CASE WHEN E.EmailType = ''Dummy'' THEN '''' ELSE E.`Subject` END `Subject`,
					E.CurrentStatus,E.ReceivedTime,E.SessionID,OverallSentimentScore,	
					(SELECT AssignedTo FROM Email_Routes A WHERE A.SessionID = E.SessionID AND AssignedTo IS NOT NULL Order by A.RID DESC LIMIT 1) AS AgentID,
					(SELECT CONCAT(IFNULL(Firstname,''''),'' '',IFNULL(aa.LastName,'''')) FROM (SELECT AssignedTo FROM Email_Routes A
									WHERE A.`SessionID` = E.`SessionID` and AssignedTo IS NOT NULL Order by A.RID DESC LIMIT 1) 
									tab inner join AGT_Agent aa on tab.AssignedTo = aa.AvayaLoginID) AS AgentName,
(SELECT QueueDateTime FROM (SELECT CONCAT(ActionDate,ActionTime) as QueueDateTime, ROW_NUMBER() OVER (PARTITION BY E.SessionID ORDER BY A.ActionDate DESC) rn FROM Email_Actions AS 
	A WHERE A.`SessionID` = E.`SessionID` AND A.Action =  ''Queue'') t1 LIMIT 1) AS QueueDateTime,
					(SELECT RepliedDateTime FROM Email_Routes A WHERE A.`SessionID` = E.`SessionID` and RepliedDateTime IS NOT NULL Order by A.RID DESC LIMIT 1) AS RepliedDateTime,
					(SELECT ClosedDateTime FROM Email_Routes A WHERE A.`SessionID` = E.`SessionID` AND A.ClosedDateTime IS NOT NULL Order by A.RID DESC LIMIT 1) AS ClosedDateTime
FROM Email_Inbox E 
WHERE E.EmailType != ''Dummy'' AND E.Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,''',p_OrgUnit,'''))');

            SET v_OrderBy = ' Order By E.SessionID';
            
            SET v_FilterBy = CONCAT(' AND E.ReceivedDate>=''', p_FromDate ,''' and E.ReceivedDate<=''' , p_ToDate ,'''');
                  
              IF(p_FilterType != '')
              THEN
                  
                             IF(p_FilterType = 'EmailID')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`From` Like ''%', p_FilterValue ,'%''');
                             END IF;
                             
                             IF(p_FilterType = 'Subject')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`Subject` Like ''%', p_FilterValue ,'%''');
                             END IF;
                             
                             IF(p_FilterType = 'Contact ID')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`SessionID`= ''', p_FilterValue ,'''');
                             END IF;
              
                            IF(p_FilterType = 'Agent Name')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND Ifnull(A.Firstname,A.AvayaLoginID ) +'' ''+ Ifnull(A.LastName,'''') Like ''%', p_FilterValue ,'%''');
                             END IF;
              END IF;
                             
              IF(p_Status != '')
              THEN           
                             IF(p_Status = 'Queued')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`CurrentStatus`=''Queued''');
                             END IF;
                             
                             IF(p_Status = 'Assigned')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`CurrentStatus` IN (''EmailDirectToAgent'' , ''SentToChecker'', ''EditRejectedByChecker'')');
                             END IF;
                             
                             IF(p_Status = 'Replied')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`CurrentStatus` IN (''Answered'' , ''SentToChecker'' , ''Approved'',''Closewithoutreply'' , ''CloseWithReply'')');
                             END IF;
              
                            IF(p_Status = 'Closed')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`CurrentStatus` IN (''Closewithoutreply'' , ''CloseWithReply'', ''DraftedEmailClosed'')');
                             END IF;                        
                             
                            IF(p_Status = 'Draft')
                             THEN
                                  SET v_FilterBy = CONCAT(v_FilterBy , ' AND E.`CurrentStatus`=''Parked''');
                             END IF;
              END IF;        
    END IF;
      
      IF(p_Type = 'EmailTraceDrillDown')
      THEN
                  
            SET v_SelectSql = CONCAT('SELECT I.ClosedReasonCode,I.CCList as cc,I.`From` as CustomerEmail,I.SessionID,I.Body as C_EmailBody, I.`ToList` as AgentEmail,O.Body as A_EmailBody
                              FROM Email_Inbox I
							  Left Outer Join Email_Outbox O on O.InSessionID = I.SessionID AND O.SessionID = ( Select MAX(SessionID) from Email_Outbox Where InSessionID = ''', p_SessionID ,''' LIMIT 1)');
            
            SET v_OrderBy = ' Order By I.SessionID';
            
            IF(p_SessionID != '')
            THEN
				SET v_FilterBy = CONCAT(' WHERE I.ReceivedDate>=''', p_FromDate ,''' and I.ReceivedDate<=''' , p_ToDate ,''' AND I.SessionID = ''', p_SessionID ,''''); 			
            END IF;
      END IF;	  
	   IF(p_Type = 'EmailAction')
      THEN
                  
            SET v_SelectSql = 'SELECT Action,ActionDate,ActionTime,ActionBy,Info,SessionID  from Email_Actions I';
            
            SET v_OrderBy = ' Order By I.ID';
            
            IF(p_SessionID != '')
            THEN
				SET v_FilterBy = CONCAT(' WHERE I.ActionDate>=''', p_FromDate ,''' and I.ActionDate<=''' , p_ToDate ,''' AND I.SessionID = ''', p_SessionID ,'''');				
            END IF;            
      END IF;
      
      IF(p_Type = 'EmailActionDetails')
      THEN
                  
            SET v_SelectSql = 'SELECT SessionID,Action,ActionDate,ActionTime,ActionBy,Info  from Email_Actions I';
            
            SET v_OrderBy = ' Order By I.ID';                     
      END IF;
      
      SET v_SelectSql = CONCAT(v_SelectSql , IFNULL(v_FilterBy,''));
      SET v_SelectSql = CONCAT(v_SelectSql , IFNULL(v_OrderBy,''));
      
      
      SET @stmt_str = v_SelectSql;
	  PREPARE stmt FROM @stmt_str;
	  EXECUTE stmt;
	  DEALLOCATE PREPARE stmt;
    
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Email_Dashboard
DELIMITER //
CREATE PROCEDURE `Get_Email_Dashboard`(
p_FromDateTime VARCHAR(20),
p_ToDateTime VARCHAR(20),
p_mailboxList VARCHAR(50)
)
BEGIN	
	DECLARE v_startDateTime VARCHAR(20);
	DECLARE v_endDateTime VARCHAR(20);
	
	DECLARE v_sla1 INT;
	DECLARE v_sla2 INT;
	DECLARE v_sla3 INT;
	DECLARE v_bucketSLA1 INT;
	DECLARE v_bucketSLA2 INT;
	DECLARE v_bucketSLA3 INT;
	DECLARE v_bucketSLA4 INT;
	
	DECLARE v_received24 INT;
	DECLARE v_received48 INT;
	DECLARE v_received72 INT;
	
	DECLARE v_completed24 INT;
	DECLARE v_completed48 INT;
	DECLARE v_completed72 INT;
	
	DECLARE v_emailsReceived INT;
	DECLARE v_emailsReplied INT;
	DECLARE v_emailsClosed INT;	
	DECLARE v_emailsNotAssigned INT;
	DECLARE v_emailsAssigned INT;	
	DECLARE v_contactCenterSLA DECIMAL(5,2);
	DECLARE v_sla1Percentage DECIMAL(5,2);
	DECLARE v_sla2Percentage DECIMAL(5,2);
	DECLARE v_sla3Percentage DECIMAL(5,2);
	DECLARE v_sla4Percentage DECIMAL(5,2);
	DECLARE v_totalEmailsReceived INT;
	DECLARE v_totalEmailsclosedWithotreply INT;
	DECLARE v_totalEmailsReplied INT;
	DECLARE v_AHT INT;
	
	DECLARE v_DateTime24 DATETIME(3);
	DECLARE v_DateTime48 DATETIME(3);
	DECLARE v_DateTime72 DATETIME(3);
	
	DECLARE v_StartDateTime24 VARCHAR(20);
	DECLARE v_StartDateTime48 VARCHAR(20);
	DECLARE v_StartDateTime72 VARCHAR(20);
	DECLARE v_CurrentDateTime VARCHAR(20);
	
	DECLARE v_mailCount INT;
	
	DECLARE v_currentID INT;
	DECLARE v_assignedTime VARCHAR(50);
	DECLARE v_mailboxValue INT;
	DECLARE v_currentStatusOfMail VARCHAR(50);
	DECLARE v_timeDiff VARCHAR(50);
	DECLARE v_ewsSentDateTime VARCHAR(100);
	DECLARE v_closedDateTime VARCHAR(50);
		
	DECLARE v_finalTableCount INT;
	
	SET v_startDateTime = CONCAT(p_FromDateTime,'000000');
	SET v_endDateTime = CONCAT(p_ToDateTime,'235959');
	
	SET v_DateTime24 = TIMESTAMPADD(day,-1,NOW(3));
	SET v_DateTime48 = TIMESTAMPADD(day,-2,NOW(3));
	SET v_DateTime72 = TIMESTAMPADD(day,-3,NOW(3));
	
	SET v_StartDateTime24 = (SELECT REPLACE(CONCAT(DATE_FORMAT (v_DateTime24, '%Y%m%d'),DATE_FORMAT (v_DateTime24, 114)), ':','')); 
	SET v_StartDateTime48 = (SELECT REPLACE(CONCAT(DATE_FORMAT (v_DateTime48, '%Y%m%d'),DATE_FORMAT (v_DateTime48, 114)), ':','')); 
	SET v_StartDateTime72 = (SELECT REPLACE(CONCAT(DATE_FORMAT (v_DateTime72, '%Y%m%d'),DATE_FORMAT (v_DateTime72, 114)), ':',''));
	
	SET v_startDateTime = v_StartDateTime72;
	SET v_CurrentDateTime = (SELECT REPLACE(CONCAT(DATE_FORMAT (NOW(3), '%Y%m%d'),DATE_FORMAT (NOW(3), 114)), ':',''));	
	SET v_endDateTime = v_CurrentDateTime;
	
	SET v_sla1 = (SELECT ServiceLevelOne FROM Email_SL LIMIT 1);
	SET v_sla2 = (SELECT ServiceLevelTwo FROM Email_SL LIMIT 1);
	SET v_sla3 = (SELECT ServiceLevelThree FROM Email_SL LIMIT 1);
	
	SET  v_bucketSLA1 = 0;
	SET  v_bucketSLA2 = 0;
	SET  v_bucketSLA3 = 0;
	SET  v_bucketSLA4 = 0;
	
	DROP TEMPORARY TABLE IF EXISTS Result_TempTable;
	CREATE TEMPORARY TABLE Result_TempTable (ID INT AUTO_INCREMENT PRIMARY KEY,Mailbox VARCHAR(50),EmailsReceived INT,Received24 INT,Received48 INT,Received72 INT,EmailsReplied INT,EmailsClosed INT,Completed24 INT,Completed48 INT,Completed72 INT,SLA1 DECIMAL(5,2), SLA2 DECIMAL(5,2),SLA3 DECIMAL(5,2),SLA4 DECIMAL(5,2),EmailsNotAssigned INT,EmailsAssigned INT,AHT INT);

	DROP TEMPORARY TABLE IF EXISTS Calculation_TempTable;
	CREATE TEMPORARY TABLE Calculation_TempTable (ID INT AUTO_INCREMENT PRIMARY KEY,RID BIGINT,SessionID varchar(50),RouteType VARCHAR(50),RouteTo varchar(50),RouteDateTime varchar(50),AssignedTo  varchar(50),AssingedDateTime VARCHAR(50),RepliedDateTime VARCHAR(50),RepliedBy VARCHAR(50),ClosedDateTime VARCHAR(50),CurrentStatus VARCHAR(50),ReplyIDList VARCHAR(250),DraftID VARCHAR(50),ActiveTime INT,HoldTime INT,ActiveOrHold VARCHAR(50),Skill VARCHAR(50), DraftDateTime VARCHAR(50),AttachmentInfo LONGTEXT,MailBox VARCHAR(50),EWS_EmailSentDateTime VARCHAR(100));
	
	INSERT INTO Calculation_TempTable(RID ,SessionID,RouteType ,RouteTo,RouteDateTime,AssignedTo,AssingedDateTime,
	RepliedDateTime ,RepliedBy ,ClosedDateTime ,CurrentStatus ,ReplyIDList ,DraftID ,ActiveTime ,HoldTime,ActiveOrHold,Skill, 
	DraftDateTime ,AttachmentInfo ,MailBox ,EWS_EmailSentDateTime)
	SELECT R.RID,R.SessionID,R.RouteType,R.RouteTo,R.RouteDateTime,R.AssignedTo,R.AssingedDateTime,R.RepliedDateTime,R.RepliedBy,
	R.ClosedDateTime,R.CurrentStatus,R.ReplyIDList,R.DraftID,R.ActiveTime,R.HoldTime,R.ActiveOrHold,R.Skill,R.DraftDateTime,
	R.AttachmentInfo,I.MailBox,R.EWS_EmailSentDateTime
	FROM Email_Routes R 
	INNER JOIN Email_Inbox I ON R.SessionID = I.SessionID
	WHERE FIND_IN_SET(I.Mailbox, p_mailboxList)>0 AND 
	R.RouteDateTime between v_startDateTime AND v_endDateTime ORDER BY AssingedDateTime ASC;
	
	SET v_mailCount = (SELECT COUNT(1) FROM Calculation_TempTable);
	
	WHILE(v_mailCount>0)
	DO	
		SET v_currentID=(SELECT ID FROM Calculation_TempTable LIMIT 1);		
		SET v_mailboxValue = (SELECT MailBox FROM Calculation_TempTable WHERE ID=v_currentID);		
		SET v_currentStatusOfMail=(SELECT CurrentStatus FROM Calculation_TempTable WHERE ID=v_currentID LIMIT 1);
		SET v_assignedTime = (SELECT AssingedDateTime FROM Calculation_TempTable WHERE ID=v_currentID LIMIT 1);
		
		SET v_closedDateTime = (SELECT ClosedDateTime FROM Calculation_TempTable WHERE ID=v_currentID LIMIT 1);
		SET v_ewsSentDateTime = (SELECT EWS_EmailSentDateTime FROM Calculation_TempTable WHERE ID=v_currentID LIMIT 1);
		SET v_ewsSentDateTime = IFNULL(v_ewsSentDateTime,v_closedDateTime);
		
		IF NOT EXISTS(SELECT Mailbox FROM Result_TempTable WHERE Mailbox = v_mailboxValue)
		THEN
			SET v_emailsReceived = 0;
			SET v_received24=0;
			SET v_received48=0;
			SET v_received72=0;			
			
			SELECT COUNT(*) INTO v_emailsReceived FROM Calculation_TempTable A	WHERE
									 A.RID = (Select MAX(B.RID) FROM Calculation_TempTable B where B.RouteDateTime>= v_startDateTime 
									 and B.RouteDateTime<= v_endDateTime 
									 and B.RouteType != 'DraftReopened' AND B.SessionID = A.SessionID) and MailBox = v_mailboxValue;

			SELECT COUNT(*) INTO v_received24 FROM Calculation_TempTable A	WHERE
									 A.RID = (Select MAX(B.RID) FROM Calculation_TempTable B where B.RouteDateTime>= v_StartDateTime24 
									 and B.RouteDateTime<= v_endDateTime 
									 and B.RouteType != 'DraftReopened' AND B.SessionID = A.SessionID) and MailBox = v_mailboxValue;
									 								
			SELECT COUNT(*) INTO v_received48 FROM Calculation_TempTable A	WHERE
									 A.RID = (Select MAX(B.RID) FROM Calculation_TempTable B where B.RouteDateTime>= v_StartDateTime48 
									 and B.RouteDateTime<= v_StartDateTime24 
									 and B.RouteType != 'DraftReopened' AND B.SessionID = A.SessionID) and MailBox = v_mailboxValue;

			SELECT COUNT(*) INTO v_received72 FROM Calculation_TempTable A	WHERE
									 A.RID = (Select MAX(B.RID) FROM Calculation_TempTable B where B.RouteDateTime>= v_StartDateTime72 
									 and B.RouteDateTime<= v_StartDateTime48 
									 and B.RouteType != 'DraftReopened' AND B.SessionID = A.SessionID) and MailBox = v_mailboxValue;									 
									 					 
			INSERT INTO Result_TempTable VALUES(v_mailboxValue,v_emailsReceived,v_received24,v_received48,v_received72,0,0,0,0,0,0,0,0,0,0,0,0);
		ELSE 	
					
			SET v_emailsReplied =0;
			SET v_emailsClosed =0;
			SET v_bucketSLA1 =0;
			SET v_bucketSLA2 =0;
			SET v_bucketSLA3 =0;
			SET v_bucketSLA4 =0;
			SET v_emailsNotAssigned=0;
			SET v_emailsAssigned=0;
						
			SET v_completed24=0;
			SET v_completed48=0;
			SET v_completed72=0;
			
			SET v_AHT=0;
				   
			SET v_emailsReplied = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable WHERE RepliedDateTime>= v_startDateTime AND RepliedDateTime<=v_endDateTime  AND ID=v_currentID); 
			
			SET v_emailsClosed = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable WHERE ClosedDateTime>= v_startDateTime AND ClosedDateTime<=v_endDateTime AND CurrentStatus IN ('ClosedWithoutReply','CloseWithReply') AND ID=v_currentID); 
			
			SET v_completed24 = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable WHERE 
			((ClosedDateTime>= v_StartDateTime24 AND ClosedDateTime<=v_endDateTime AND CurrentStatus IN ('ClosedWithoutReply','CloseWithReply')) OR (RepliedDateTime>= v_StartDateTime24 AND RepliedDateTime<=v_endDateTime)) AND ID=v_currentID);

			SET v_completed48 = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable WHERE 
			((ClosedDateTime>= v_StartDateTime48 AND ClosedDateTime<=v_StartDateTime24 AND CurrentStatus IN ('ClosedWithoutReply','CloseWithReply')) OR (RepliedDateTime>= v_StartDateTime48 AND RepliedDateTime<=v_StartDateTime24)) AND ID=v_currentID);

			SET v_completed72 = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable WHERE 
			((ClosedDateTime>= v_StartDateTime72 AND ClosedDateTime<=v_StartDateTime48 AND CurrentStatus IN ('ClosedWithoutReply','CloseWithReply')) OR (RepliedDateTime>= v_StartDateTime72 AND RepliedDateTime<=v_StartDateTime48)) AND ID=v_currentID);
				
			SET v_emailsNotAssigned = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable  WHERE RouteDateTime>= v_startDateTime AND RouteDateTime<=v_endDateTime and CurrentStatus IN ('QueuedToSkill','Queued') AND ID=v_currentID); 		
			
			SET v_emailsAssigned = (SELECT IFNULL(COUNT(1),0) FROM Calculation_TempTable  WHERE RouteDateTime>= v_startDateTime AND RouteDateTime<=v_endDateTime and CurrentStatus NOT IN ('QueuedToSkill','Queued') AND ID=v_currentID AND RouteType='Agent'); 		
			
			IF(v_currentStatusOfMail= 'CloseWithReply' OR v_currentStatusOfMail= 'Closewithoutreply')
			THEN
				SET v_timeDiff = (SELECT CONVERT((Timestampdiff(MINUTE,STR_TO_DATE(concat(Left(v_assignedTime,4),'-',SUBSTRING(v_assignedTime,5,2),'-', SUBSTRING(v_assignedTime,7,2),' ', SUBSTRING(v_assignedTime,9,2),':',SUBSTRING(v_assignedTime,11,2),':',RIGHT(v_assignedTime,2)),'%Y-%m-%d %T.%f'),STR_TO_DATE(concat(Left(v_ewsSentDateTime,4),'-',SUBSTRING(v_ewsSentDateTime,5,2),'-', SUBSTRING(v_ewsSentDateTime,7,2),' ', SUBSTRING(v_ewsSentDateTime,9,2),':',SUBSTRING(v_ewsSentDateTime,11,2),':',RIGHT(v_ewsSentDateTime,2)),'%Y-%m-%d %T.%f'))), CHAR(50)));

				IF(v_timeDiff <= v_sla1*60)
				THEN
					SET v_bucketSLA1 = 1;  
				ELSEIF (v_timeDiff <= v_sla2*60)
				THEN
					SET v_bucketSLA2 = 1; 
				ELSEIF (v_timeDiff <= v_sla3*60)
				THEN
					SET v_bucketSLA3 = 1; 
				ELSE
					SET v_bucketSLA4 = 1; 
				END IF;				
			END IF;
			
			UPDATE Result_TempTable
			SET EmailsReceived = EmailsReceived,
			Received24 = Received24,
			Received48 = Received48,
			Received72 = Received72,						
			EmailsReplied = EmailsReplied+v_emailsReplied,
			EmailsClosed = EmailsClosed+v_emailsClosed,
			Completed24 = Completed24 + v_completed24,
			Completed48 = Completed24 + v_completed48,
			Completed72 = Completed24 + v_completed72,
			EmailsNotAssigned = EmailsNotAssigned+v_emailsNotAssigned,
			EmailsAssigned = EmailsAssigned+v_emailsAssigned,
			SLA1=SLA1+v_bucketSLA1,
			SLA2=SLA2+v_bucketSLA2,
			SLA3=SLA3+v_bucketSLA3,
			SLA4=SLA4+v_bucketSLA4,
			AHT=AHT+v_AHT
			WHERE Mailbox=v_mailboxValue;		
			
			DELETE FROM Calculation_TempTable WHERE ID=v_currentID;
			
			SET v_mailCount = (SELECT COUNT(1) FROM Calculation_TempTable);		
		END IF;				
	END WHILE;
	
	SET v_finalTableCount=(SELECT COUNT(1) FROM Result_TempTable);
	
	IF(v_finalTableCount > 0)
	THEN
		UPDATE Result_TempTable R
		INNER JOIN Result_TempTable S
		ON R.ID = S.ID
		SET SLA1 = CASE WHEN R.EmailsReceived <> 0 THEN (R.SLA1 * 100)/(R.EmailsReceived)ELSE 0 END,
		SLA2 = CASE WHEN R.EmailsReceived <> 0 THEN (R.SLA2 * 100)/(R.EmailsReceived)ELSE 0 END,
		SLA3 = CASE WHEN R.EmailsReceived <> 0 THEN (R.SLA3 * 100)/(R.EmailsReceived)ELSE 0 END,
		SLA4 = CASE WHEN R.EmailsReceived <> 0 THEN (R.SLA4 * 100)/(R.EmailsReceived)ELSE 0 END;	
	END IF;
	
	SELECT Mailbox AS EmailBox,EmailsReceived as Emails_Received,Received24,Received48,Received72,EmailsReplied,EmailsClosed,Completed24,Completed48,Completed72,
	SLA1 AS SLA1,SLA2 AS SLA2,SLA3 AS SLA3, SLA4 AS SLA4,EmailsNotAssigned AS EmailsInQueue, EmailsAssigned AS EmailsAssigned,AHT
	FROM Result_TempTable;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Email_Outbound_Summary
DELIMITER //
CREATE PROCEDURE `Get_Email_Outbound_Summary`(
 p_FromDate varchar(20),
 p_ToDate varchar(20),
 p_Type varchar(50),
 p_Mailbox varchar(100),
 p_OrgUnit TEXT
)
BEGIN
  IF(p_Type='MAIN')
  then
		select Mailbox, count(1) as Sent from Email_Outbox 
		where CONCAT(SendDate,SendTime) >= p_FromDate and CONCAT(SendDate,SendTime) <= p_ToDate AND
		`Mailbox` IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
		INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit))
		group by mailbox;
  ELSEIF(p_Type='DRILL')
  then
    	select `From`,CONCAT(SendDate,SendTime) as SendDateTime,ToList,CCList,BCCList,Subject,Mailbox from Email_Outbox
    	where CONCAT(SendDate,SendTime) >= p_FromDate and CONCAT(SendDate,SendTime)<= p_ToDate and Mailbox = p_Mailbox;
  ELSEIF(p_Type='DRILLEXPORT')
  then
    	select `From`,CONCAT(SendDate,SendTime) as SendDateTime,ToList,CCList,BCCList,Subject,Mailbox from Email_Outbox
     	where CONCAT(SendDate,SendTime) >= p_FromDate and CONCAT(SendDate,SendTime)<= p_ToDate AND
		`Mailbox` IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C 
		INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit)); 
  end if;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_FaxSLAReport
DELIMITER //
CREATE PROCEDURE `Get_FaxSLAReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_SL VARCHAR(10),
p_SearchString LONGTEXT,
p_SortString VARCHAR(1000),
p_PageNo INT /* = 1 */,
p_PageSize INT /* = 10 */,
OUT p_TotalPageSize INT,
p_OrgUnit varchar(10))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_lPageNbr INT;
Declare v_lPageSize INT;
Declare v_lFirstRec INT;
Declare v_lLastRec INT;
Declare v_lTotalRows INT;
Declare v_CombineQuery LONGTEXT;
Declare v_MAIN LONGTEXT;
Declare v_DRILL LONGTEXT;
Declare v_ToatlCount LONGTEXT;
Declare v_SortValue LONGTEXT;

BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate; 

		SET p_TotalPageSize = 0;
		SET v_DataFromDate = p_FromDate;
		SET v_DataToDate = p_ToDate;
		SET v_lPageNbr = p_PageNo;
		SET v_lPageSize = p_PageSize;
		SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
		SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );
		SET v_SortValue =  CASE WHEN IFNULL(p_SortString,'')='' THEN 'ORDER BY CreatedDateTime ASC' ELSE p_SortString END;

	IF(p_Type = 'MAIN')
	THEN	
		SET v_MAIN=CONCAT('SELECT FaxLine,Skill,CreatedDateTime,CreatedBy,`Data`,AgentID,RouteDateTime,SLA,QueueTime FROM (
						SELECT JSON_VALUE(data, ''$.DNIS'') FaxLine,Skill,REPLACE(CONCAT(`CreateDate`,`CreatedTime`),'' '','''') as CreatedDateTime,CreatedBy,`Data`,AgentID,
						REPLACE(CONCAT(`RouteDate`,`RouteTime`),'' '','''') as RouteDateTime,
						fn_CalculateFaxSLA(DATE_FORMAT(CONCAT(`CreateDate`,`CreatedTime`), ''%Y-%m-%d %H:%m:%s''),
						(case when ifnull(CONCAT(`RouteDate`,`RouteTime`),'''')='''' then 
						NOW() else DATE_FORMAT(CONCAT(`RouteDate`,`RouteTime`), ''%Y-%m-%d %H:%m:%s'') end),
						JSON_VALUE(data, ''$.DNIS''), p_SL) as SLA,
						SEC_TO_TIME(TIMESTAMPDIFF(SECOND,DATE_FORMAT(CONCAT(`CreateDate`,`CreatedTime`), ''%Y-%m-%d %H:%m:%s''),
						(case when ifnull(CONCAT(`RouteDate`,`RouteTime`),'''')='''' then 
						NOW() else DATE_FORMAT(CONCAT(`RouteDate`,`RouteTime`), ''%Y-%m-%d %H:%m:%s'') end))) AS QueueTime 
						from TMAC_WorkQueueHistory 
						WHERE CONCAT(RouteDate,RouteTime) >= ''', v_DataFromDate , ''' AND CONCAT(RouteDate,RouteTime) <= ''', v_DataToDate  ,''' AND Channel=''fax''
						UNION
						SELECT JSON_VALUE(data, ''$.DNIS'') FaxLine,Skill,REPLACE(CONCAT(`CreateDate`,`CreatedTime`),'' '','''') as CreatedDateTime,CreatedBy,`Data`,AgentID,
						REPLACE(CONCAT(`RouteDate`,`RouteTime`),'' '','''') as RouteDateTime,
						fn_CalculateFaxSLA(DATE_FORMAT(CONCAT(`CreateDate`,`CreatedTime`), ''%Y-%m-%d %H:%m:%s''),
						(case when ifnull(CONCAT(`RouteDate`,`RouteTime`),'''')='''' then 
						NOW() else DATE_FORMAT(CONCAT(`RouteDate`,`RouteTime`), ''%Y-%m-%d %H:%m:%s'') end),
						JSON_VALUE(data, ''$.DNIS''),p_SL) as SLA,
						SEC_TO_TIME(TIMESTAMPDIFF(SECOND,DATE_FORMAT(CONCAT(`CreateDate`,`CreatedTime`), ''%Y-%m-%d %H:%m:%s''),
						(case when ifnull(CONCAT(`RouteDate`,`RouteTime`),'''')='''' then 
						NOW() else DATE_FORMAT(CONCAT(`RouteDate`,`RouteTime`), ''%Y-%m-%d %H:%m:%s'') end))) AS QueueTime from TMAC_WorkQueue 
						WHERE CONCAT(CreateDate,CreatedTime) >= ''', v_DataFromDate , ''' AND CONCAT(CreateDate,CreatedTime) <= ''', v_DataToDate  ,''' AND Channel=''fax''
						) MAIN');
		
			   if(p_OrgUnit <>'')
			   then
			      SET v_MAIN = CONCAT(v_MAIN , ' WHERE FaxLine IN (SELECT DISTINCT DNIS FROM Fax_Dnis WHERE OrgUnit in (SELECT DISTINCT TeamID FROM fn_Generic_AgentHierarchy(''orgunit'',', p_OrgUnit ,','''')))');
			   end if;
			   /* PRINT v_MAIN; */
			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(', v_SortValue ,') RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1 ',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR));

			 --  SQLINES DEMO *** et the total count
			SET v_ToatlCount = CONCAT('SELECT COUNT(*) INTO @x FROM(',v_MAIN,')AS table1 Where 1=1 ',p_SearchString); 
			--  SQLINES DEMO ***  as query
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			
            SET @stmt_strtotcnt = v_ToatlCount;
			PREPARE stmt1 FROM @stmt_strtotcnt;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 
	      SET p_TotalPageSize :=  @x;
		  SELECT p_TotalPageSize as 'TotalPageSize';
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Fax_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Fax_DashboardData`(
  p_dnis varchar(1000),p_startdate varchar(20),p_enddate varchar(20), p_type varchar(20)
)
BEGIN
	DECLARE v_FaxReceived int; 
	DECLARE v_FaxSent int; 
	DECLARE v_FaxReceivedFailed int; 
	DECLARE v_FaxSentFailed int;  
	DECLARE v_FaxRouted int;  
	DECLARE v_FaxReceiving int;  
	DECLARE v_FaxSending int;  
	DECLARE v_FaxAssigned INT;
	
 if (p_type='summarydata')
 then
		set v_FaxReceived=(select count(1) from Fax_Received_Details where 1=1 and  result=0 
		                 AND FIND_IN_SET(DNIS,p_dnis)>0 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate);

		set v_FaxReceivedFailed=(select count(1) from Fax_Received_Details where 1=1 and  result!=0 
		              AND FIND_IN_SET(DNIS,p_dnis)>0 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate);

		set v_FaxSent= (select count(1) from Fax_Sent_Details where 1=1 and  result=0 
		                        AND FIND_IN_SET(ANI,p_dnis)>0 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate);

		set v_FaxSentFailed =(select count(1) from Fax_Sent_Details where 1=1 and  result!=0 
		                      AND FIND_IN_SET(ANI,p_dnis)>0 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate);

		set v_FaxRouted=(select count(1) from Fax_Received_Details where 1=1 and RouteStatus='RouteQueueSuccess'
							AND FIND_IN_SET(DNIS,p_dnis)>0 and ReportDateTime>=p_startdate and ReportDateTime<=p_enddate);

		set v_FaxReceiving = (select count(`ReceiveStatus`) from Fax_Received_Details where 1=1 and ReceiveStatus='Receiving'
							 AND FIND_IN_SET(DNIS,p_dnis)>0 and ReportDateTime>=p_startdate and ReportDateTime<=p_enddate);

		set v_FaxSending=(select count(`SendStatus`) from Fax_Sent_Details where 1=1 and SendStatus='Sending'
							 AND FIND_IN_SET(ANI,p_dnis)>0 and ReportDateTime>=p_startdate and ReportDateTime<=p_enddate);

		set v_FaxAssigned = (select count(`AssignedAgentID`) from Fax_Received_Details where 1=1 and `AssignedAgentID` is not null 
							AND FIND_IN_SET(DNIS,p_dnis)>0 and ReportDateTime>=p_startdate and ReportDateTime<=p_enddate); 
		
		select v_FaxReceived as FaxReceived, v_FaxSent as FaxSent, v_FaxReceivedFailed as FaxReceivedFailed , v_FaxSentFailed as FaxSentFailed,v_FaxRouted as FaxRouted ,
		v_FaxReceiving as FaxReceiving,v_FaxSending as FaxSending,v_FaxAssigned as FaxAssigned;
 else
    select distinct m.DNIS,ifnull(FaxRecieved.Received,0) FaxRecieved, ifnull(FaxReceivedFailed.ReceivedFailed,0) FaxReceivedFailed,
	ifnull(FaxSent.sent,0) FaxSent,ifnull(FaxSentFailed.SentFailed,0)FaxSentFailed,ifnull(FaxReceiving.FaxReceiving,0)FaxReceiving,
	ifnull(FaxSending.FaxSending,0)FaxSending
	  from Fax_Dnis  as m  LEFT JOIN 
	 ( select DNIS ,count(1) Received from Fax_Received_Details where 1=1  and  result=0 
	 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate  GROUP BY DNIS  ) AS FaxRecieved on  FaxRecieved.DNIS =m.DNIS left join 

	(select DNIS ,count(1) ReceivedFailed from Fax_Received_Details where 1=1 and  result!=0 
     and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate GROUP BY DNIS) AS FaxReceivedFailed on FaxReceivedFailed.DNIS=m.DNIS left join 

	( select ANI,count(1) `sent` from Fax_Sent_Details where 1=1 and  result=0 
     and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate  GROUP BY ANI ) as FaxSent on  FaxSent.ANI=m.DNIS left join

	(select ANI,count(1) SentFailed from Fax_Sent_Details where 1=1 and  result!=0 
     and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate  GROUP BY ANI ) AS FaxSentFailed on FaxSentFailed.ANI =m.DNIS left join

	 (select DNIS,count(1) FaxReceiving from Fax_Received_Details where 1=1 and `ReceiveStatus`='Receiving' 
	  and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate GROUP BY DNIS) as FaxReceiving on FaxReceiving.DNIS=m.DNIS left join

	 (select ANI,count(1) FaxSending from Fax_Sent_Details where 1=1 and `SendStatus`='Sending' 
	 and ReportDateTime>=p_startdate AND ReportDateTime<=p_enddate GROUP BY ANI) as FaxSending on FaxSending.ANI=m.DNIS
	 
	WHERE FIND_IN_SET(m.DNIS,p_dnis)>0;
	
 end if;

 END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_HistoricalData
DELIMITER //
CREATE PROCEDURE `Get_HistoricalData`(
p_Date Varchar(8),
p_StartTime Varchar(6),
p_EndTime Varchar(6),
p_Id Varchar(20),
p_Type Varchar(10),
p_acceptableSL int
)
Begin
	IF(p_Type = 'skill')
	Then
		select  p_Date AS `Date`,
		p_Id as SkillID,
		Tab1.SkillName as SkillName,
		SUM(Tab1.TotalInteraction) as TotalInteraction,
		SUM(Tab1.SpeedOfAnswer) / IFNULL(SUM(Tab1.TotalInteraction),1) as AvgSpeedOfAnswer,
		SUM(IFNULL(Tab1.AbandCalls,0)) as AbandCalls,
		IFNULL(SUM(Tab1.AbandTime),0) / COALESCE(CASE When SUM(Tab1.AbandCalls) = 0 then 1 else SUM(Tab1.AbandCalls) end, 1) as AvgAbandTime,
		SUM(Tab1.TalkTime) / IFNULL(SUM(Tab1.TotalInteraction),1)  as AvgTalkTime,
		SUM(Tab1.TalkTime) as TotalACDTime,
		SUM(Tab1.TotalACWTime) as TotalACWTime,
		IFNULL(SUM(Tab1.FlowIn),0) as FlowIn,
		IFNULL(SUM(Tab1.FlowOut),0) as FlowOut,
		0 as AvgStaffedTime,
		0 as AvgStaffedTime,
		100 * ( SUM(Tab1.SLCount) / Ifnull(SUM(Tab1.TotalInteraction),1)) as SLPercentage
		from (
		Select TS.SkillName , COUNT(1) as TotalInteraction , TI.AgentID, TI.CreatedDateTime,
	 SUM(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(concat(TWQH.CreateDate,TWQH.CreatedTime)),
		VARCHARTODATETIME(TI.CreatedDateTime))) AS SpeedOfAnswer,
		
	 (Select  SUM(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(concat(CreateDate,CreatedTime)),
		VARCHARTODATETIME(concat(RouteDate,RouteTime)))) AS AbandTime From TMAC_WorkQueueHistory 
		where Reason = 'timedout' and CreateDate  = p_Date and CreatedTime between p_StartTime and p_EndTime
Limit 1) AS AbandTime,

	  (SELECT COUNT(1) FROM TMAC_WorkQueueHistory 
		where Reason = 'timedout' and CreateDate  = p_Date and CreatedTime between p_StartTime and p_EndTime) AS AbandCalls,
 
		TI.ActiveTime as TalkTime,
	 CASE WHEN TI.Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','Fax')  THEN TI.AcwTime ELSE 0 END AS TotalACWTime,
	 CASE WHEN TI.Direction='in' THEN 1 ELSE 0 END AS FlowIn,
	 CASE WHEN TI.Direction='out' THEN 1 ELSE 0 END AS FlowOut,
	 CASE When QueueTime <= p_acceptableSL THEN 1 ELSE 0 END AS SLCount 
		from TMAC_Skills TS 
		Inner Join TMAC_Interactions TI 
		On TI.Skill = TS.SkillExtension 
		Inner Join TMAC_WorkQueueHistory TWQH 
		on TI.SessionID = TWQH.ItemID
		where TI.Skill = p_Id and TI.CreatedDateTime >= CONCAT(p_Date , p_StartTime) and TI.CreatedDateTime <= CONCAT(p_Date , p_EndTime) 
		Group by  TI.AgentID, TI.CreatedDateTime,TS.SkillName,TWQH.Reason,TI.ActiveTime,TI.AcwTime,TI.Direction,QueueTime,TI.Channel
		) AS Tab1	
		Group by Tab1.SkillName;
	End if;

	IF(p_Type = 'agent')
	Then
		Select 
		Ifnull(SUM(Tab1.TotalInteraction),0) TotalInteraction,
		Ifnull(SUM(Tab1.TotalInteractionTime),0) TotalInteractionTime,
	 (Ifnull(SUM(Tab1.TotalInteractionTime),0) / case when SUM(Tab1.TotalInteraction) = 0 then 1 else SUM(Tab1.TotalInteraction) END) AS AvgInteractionTime,
		Ifnull(SUM(Tab1.TotalChat),0)TotalChat,
		Ifnull(SUM(Tab1.TotalChatTime),0) TotalChatTime,
	 (Ifnull(SUM(Tab1.TotalChatTime),0) / case when SUM(Tab1.TotalChat)= 0 then 1 else SUM(Tab1.TotalChat) END) AS AvgChatTime,
		Ifnull(SUM(Tab1.TotalAudioIP),0)TotalAudioIP,
		Ifnull(SUM(Tab1.TotalAudioIPTime),0) TotalAudioIPTime,
	 (Ifnull(SUM(Tab1.TotalAudioIPTime),0) / case when SUM(Tab1.TotalAudioIP)= 0 then 1 else SUM(Tab1.TotalAudioIP) END) AS AvgAudioIPTime 
	 
		FROM (Select 
	 CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','Fax') THEN  1 ELSE 0 END AS TotalInteraction,
	 CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','Fax') THEN  ActiveTime ELSE 0 END AS TotalInteractionTime,
	 CASE WHEN Channel IN ('Chat','TextChat') THEN 1 ELSE 0 END AS TotalChat,
	 CASE WHEN Channel IN ('Chat','TextChat') THEN ActiveTime ELSE 0 END AS TotalChatTime,
	 CASE WHEN SubChannel='AudioIP' THEN 1 ELSE 0 END AS TotalAudioIP,
	 CASE WHEN SubChannel='AudioIP' THEN ActiveTime ELSE 0 END AS TotalAudioIPTime 
		From TMAC_Interactions S  		
		Where CreatedDateTime>= CONCAT(p_Date,p_StartTime) AND CreatedDateTime<=CONCAT(p_Date,p_EndTime) AND S.AgentId = p_Id
		) Tab1;
	End if;
End//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_IntervalWise_Report
DELIMITER //
CREATE PROCEDURE `Get_IntervalWise_Report`(
	p_ReportStartDate VARCHAR(20),
	p_ReportEndDate VARCHAR(20),
	p_OrgUnit TEXT
)
BEGIN
		
	DROP TEMPORARY TABLE IF EXISTS TEMP;
	CREATE TEMPORARY TABLE TEMP(`Mailbox` VARCHAR(100),`One` INT,`Two`	INT,`Three`	INT,`Four`	INT,`Five`	INT,`Six`	INT,`Seven`	INT,`Eight`	INT,
	`Nine`	INT,`Ten` INT, `Eleven` INT,`Twelve` INT,`Thirteen` INT,`Fourteen` INT,`Fifteen` INT,`Sixteen` INT,`Seventeen` INT,`Eighteen` INT,`Ninteen` INT,
	`Twenty` INT,`TwentyOne` INT,`TwentyTwo` INT,`TwentyThree` INT,`TwentyFour` INT, Total INT);
	
	BEGIN
	
		INSERT INTO TEMP
			Select `Mailbox`, SUM(tab.`00_01`) as `One`, SUM(tab.`01-02`) as `Two`, SUM(tab.`02-03`) as `Three`, SUM(tab.`03-04`) as `Four`, 
			 SUM(tab.`04-05`) as `Five`, SUM(tab.`05-06`) as `Six`, SUM(tab.`06-07`) as `Seven`, SUM(tab.`07-08`) as `Eight`, SUM(tab.`08-09`) as `Nine`, 
			 SUM(tab.`09-10`) as `Ten`, SUM(tab.`10-11`) as `Eleven`, SUM(tab.`11-12`) as `Twelve`, SUM(tab.`12-13`) as `Thirteen`, SUM(tab.`13-14`) as `Fourteen`, 
			 SUM(tab.`14-15`) as `Fifteen`, SUM(tab.`15-16`) as `Sixteen`, SUM(tab.`16-17`) as `Seventeen`, SUM(tab.`17-18`) as `Eighteen`, SUM(tab.`18-19`) as `Ninteen`, 
			 SUM(tab.`19-20`) as `Twenty`, SUM(tab.`20-21`) as `TwentyOne`, SUM(tab.`21-22`) as `TwentyTwo`, SUM(tab.`22-23`) as `TwentyThree`, SUM(tab.`23-24`) as `TwentyFour`,
			 (SUM(tab.`00_01`)+SUM(tab.`01-02`)+SUM(tab.`02-03`)+SUM(tab.`03-04`)+SUM(tab.`04-05`)+SUM(tab.`05-06`)+SUM(tab.`06-07`)+SUM(tab.`07-08`)+SUM(tab.`08-09`)+ 
			 SUM(tab.`09-10`)+SUM(tab.`10-11`)+SUM(tab.`11-12`)+SUM(tab.`12-13`)+SUM(tab.`13-14`)+SUM(tab.`14-15`)+SUM(tab.`15-16`)+SUM(tab.`16-17`)+SUM(tab.`17-18`)+
			 SUM(tab.`18-19`)+SUM(tab.`19-20`)+SUM(tab.`20-21`)+SUM(tab.`21-22`)+SUM(tab.`22-23`)+SUM(tab.`23-24`)) AS Total
				from (
				SELECT `Mailbox`,
				CASE WHEN RECEIVEDTIME BETWEEN 000000 AND 010000 THEN COUNT(1) ELSE 0 END AS '00_01',
				CASE WHEN RECEIVEDTIME BETWEEN 010000 AND 020000 THEN COUNT(1) ELSE 0 END AS '01-02',
				CASE WHEN RECEIVEDTIME BETWEEN 020000 AND 030000 THEN COUNT(1) ELSE 0 END AS '02-03',
				CASE WHEN RECEIVEDTIME BETWEEN 030000 AND 040000 THEN COUNT(1) ELSE 0 END AS '03-04',
				CASE WHEN RECEIVEDTIME BETWEEN 040000 AND 050000 THEN COUNT(1) ELSE 0 END AS '04-05',
				CASE WHEN RECEIVEDTIME BETWEEN 050000 AND 060000 THEN COUNT(1) ELSE 0 END AS '05-06',
				CASE WHEN RECEIVEDTIME BETWEEN 060000 AND 070000 THEN COUNT(1) ELSE 0 END AS '06-07',
				CASE WHEN RECEIVEDTIME BETWEEN 070000 AND 080000 THEN COUNT(1) ELSE 0 END AS '07-08',
				CASE WHEN RECEIVEDTIME BETWEEN 080000 AND 090000 THEN COUNT(1) ELSE 0 END AS '08-09',
				CASE WHEN RECEIVEDTIME BETWEEN 090000 AND 100000 THEN COUNT(1) ELSE 0 END AS '09-10',
				CASE WHEN RECEIVEDTIME BETWEEN 100000 AND 110000 THEN COUNT(1) ELSE 0 END AS '10-11',
				CASE WHEN RECEIVEDTIME BETWEEN 110000 AND 120000 THEN COUNT(1) ELSE 0 END AS '11-12',
				CASE WHEN RECEIVEDTIME BETWEEN 120000 AND 130000 THEN COUNT(1) ELSE 0 END AS '12-13',
				CASE WHEN RECEIVEDTIME BETWEEN 130000 AND 140000 THEN COUNT(1) ELSE 0 END AS '13-14',
				CASE WHEN RECEIVEDTIME BETWEEN 140000 AND 150000 THEN COUNT(1) ELSE 0 END AS '14-15',
				CASE WHEN RECEIVEDTIME BETWEEN 150000 AND 160000 THEN COUNT(1) ELSE 0 END AS '15-16',
				CASE WHEN RECEIVEDTIME BETWEEN 160000 AND 170000 THEN COUNT(1) ELSE 0 END AS '16-17',
				CASE WHEN RECEIVEDTIME BETWEEN 170000 AND 180000 THEN COUNT(1) ELSE 0 END AS '17-18',
				CASE WHEN RECEIVEDTIME BETWEEN 180000 AND 190000 THEN COUNT(1) ELSE 0 END AS '18-19',
				CASE WHEN RECEIVEDTIME BETWEEN 190000 AND 200000 THEN COUNT(1) ELSE 0 END AS '19-20',
				CASE WHEN RECEIVEDTIME BETWEEN 200000 AND 210000 THEN COUNT(1) ELSE 0 END AS '20-21',
				CASE WHEN RECEIVEDTIME BETWEEN 210000 AND 220000 THEN COUNT(1) ELSE 0 END AS '21-22',
				CASE WHEN RECEIVEDTIME BETWEEN 220000 AND 230000 THEN COUNT(1) ELSE 0 END AS '22-23',
				CASE WHEN RECEIVEDTIME BETWEEN 230000 AND 235959 THEN COUNT(1) ELSE 0 END AS '23-24'
				FROM Email_Inbox E																	
				WHERE 1=1 AND CAST(RECEIVEDDATE AS DATE) Between  p_ReportStartDate AND p_ReportEndDate
				AND `Mailbox` IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit))
				GROUP BY RECEIVEDTIME,RECEIVEDDATE,`Mailbox`) AS tab 
			GROUP BY `Mailbox`;	

			DROP TEMPORARY TABLE IF EXISTS TempUnion;
			CREATE TEMPORARY TABLE TempUnion LIKE TEMP;
			
			INSERT INTO TempUnion
			SELECT * FROM TEMP;


			select `Mailbox` ,`One`, `Two`, `Three`, `Four`, `Five`, `Six`, `Seven`, `Eight`, `Nine`, `Ten`, `Eleven`, `Twelve`, 
					`Thirteen`, `Fourteen`, `Fifteen`, `Sixteen`, `Seventeen`, `Eighteen`, `Ninteen`, `Twenty`, `TwentyOne`, `TwentyTwo`, 
					`TwentyThree`, `TwentyFour`, Total 
			from TEMP 
			UNION 
			select 'Summary' AS `Mailbox` ,SUM(`One`), SUM(`Two`), SUM(`Three`), SUM(`Four`), SUM(`Five`), SUM(`Six`), SUM(`Seven`), SUM(`Eight`), 
					SUM(`Nine`), SUM(`Ten`), SUM(`Eleven`), SUM(`Twelve`), SUM(`Thirteen`), SUM(`Fourteen`), SUM(`Fifteen`), SUM(`Sixteen`), 
					SUM(`Seventeen`), SUM(`Eighteen`), 
					SUM(`Ninteen`), SUM(`Twenty`), SUM(`TwentyOne`), SUM(`TwentyTwo`), SUM(`TwentyThree`), SUM(`TwentyFour`), SUM(Total) 
			from TempUnion 
			HAVING COUNT(*) > 0;
	END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Interval_Report
DELIMITER //
CREATE PROCEDURE `Get_Interval_Report`(
	p_ReportStartDate VARCHAR(20),
	p_ReportEndDate VARCHAR(20),
	p_OrgUnit varchar(250)
)
BEGIN
		BEGIN
	DECLARE v_SELECTEDDATE DATETIME(3);
			DECLARE v_LOWERCOUNTER DATETIME(3);
			DECLARE v_ENDDATE DATETIME(3);
			DECLARE v_I INT;
			DECLARE v_CNT INT;
			DECLARE v_EmailInterval VARCHAR(20);
			
		DROP TEMPORARY TABLE IF EXISTS TEMP;
		CREATE TEMPORARY TABLE TEMP (`Date` VARCHAR(20),EmailCount INT,EmailInterval VARCHAR(20));
		INSERT INTO TEMP
		Select tab.`Date`,SUM(tab.EmailCount) as EmailCount,tab.EmailInterval from (
			SELECT ReceivedDate as `Date`,COUNT(1) as `EmailCount`,
			CASE 
				WHEN RECEIVEDTIME BETWEEN 000000 AND 003000 THEN '00:00'
				WHEN RECEIVEDTIME BETWEEN 003000 AND 010000 THEN '00:30'
				WHEN RECEIVEDTIME BETWEEN 010000 AND 013000 THEN '01:00'
				WHEN RECEIVEDTIME BETWEEN 013000 AND 020000 THEN '01:30'
				WHEN RECEIVEDTIME BETWEEN 020000 AND 023000 THEN '02:00'
				WHEN RECEIVEDTIME BETWEEN 023000 AND 030000 THEN '02:30'
				WHEN RECEIVEDTIME BETWEEN 030000 AND 033000 THEN '03:00'
				WHEN RECEIVEDTIME BETWEEN 033000 AND 040000 THEN '03:30'
				WHEN RECEIVEDTIME BETWEEN 033000 AND 040000 THEN '03:30'
				WHEN RECEIVEDTIME BETWEEN 040000 AND 043000 THEN '04:00'
				WHEN RECEIVEDTIME BETWEEN 043000 AND 050000 THEN '04:30'
				WHEN RECEIVEDTIME BETWEEN 050000 AND 053000 THEN '05:00'
				WHEN RECEIVEDTIME BETWEEN 053000 AND 060000 THEN '05:30'
				WHEN RECEIVEDTIME BETWEEN 060000 AND 063000 THEN '06:00'
				WHEN RECEIVEDTIME BETWEEN 063000 AND 070000 THEN '06:30'
				WHEN RECEIVEDTIME BETWEEN 070000 AND 073000 THEN '07:00'
				WHEN RECEIVEDTIME BETWEEN 073000 AND 080000 THEN '07:30'
				WHEN RECEIVEDTIME BETWEEN 080000 AND 083000 THEN '08:00'
				WHEN RECEIVEDTIME BETWEEN 083000 AND 090000 THEN '08:30'
				WHEN RECEIVEDTIME BETWEEN 090000 AND 093000 THEN '09:00'
				WHEN RECEIVEDTIME BETWEEN 093000 AND 100000 THEN '09:30'
				WHEN RECEIVEDTIME BETWEEN 100000 AND 103000 THEN '10:00'
				WHEN RECEIVEDTIME BETWEEN 103000 AND 110000 THEN '10:30'
				WHEN RECEIVEDTIME BETWEEN 110000 AND 113000 THEN '11:00'
				WHEN RECEIVEDTIME BETWEEN 113000 AND 120000 THEN '11:30'
				WHEN RECEIVEDTIME BETWEEN 120000 AND 123000 THEN '12:00'
				WHEN RECEIVEDTIME BETWEEN 123000 AND 130000 THEN '12:30'
				WHEN RECEIVEDTIME BETWEEN 130000 AND 133000 THEN '13:00'
				WHEN RECEIVEDTIME BETWEEN 133000 AND 140000 THEN '13:30'
				WHEN RECEIVEDTIME BETWEEN 140000 AND 143000 THEN '14:00'
				WHEN RECEIVEDTIME BETWEEN 143000 AND 150000 THEN '14:30'
				WHEN RECEIVEDTIME BETWEEN 150000 AND 153000 THEN '15:00'
				WHEN RECEIVEDTIME BETWEEN 153000 AND 160000 THEN '15:30'
				WHEN RECEIVEDTIME BETWEEN 160000 AND 163000 THEN '16:00'
				WHEN RECEIVEDTIME BETWEEN 163000 AND 170000 THEN '16:30'
				WHEN RECEIVEDTIME BETWEEN 170000 AND 173000 THEN '17:00'
				WHEN RECEIVEDTIME BETWEEN 173000 AND 180000 THEN '17:30'
				WHEN RECEIVEDTIME BETWEEN 180000 AND 183000 THEN '18:00'
				WHEN RECEIVEDTIME BETWEEN 183000 AND 190000 THEN '18:30'
				WHEN RECEIVEDTIME BETWEEN 190000 AND 193000 THEN '19:00'
				WHEN RECEIVEDTIME BETWEEN 193000 AND 200000 THEN '19:30'
				WHEN RECEIVEDTIME BETWEEN 200000 AND 203000 THEN '20:00'
				WHEN RECEIVEDTIME BETWEEN 203000 AND 210000 THEN '20:30'
				WHEN RECEIVEDTIME BETWEEN 210000 AND 213000 THEN '21:00'
				WHEN RECEIVEDTIME BETWEEN 213000 AND 220000 THEN '21:30'
				WHEN RECEIVEDTIME BETWEEN 220000 AND 223000 THEN '22:00'
				WHEN RECEIVEDTIME BETWEEN 223000 AND 230000 THEN '22:30'
				WHEN RECEIVEDTIME BETWEEN 230000 AND 233000 THEN '23:00'
				WHEN RECEIVEDTIME BETWEEN 233000 AND 235959 THEN '23:30'
			END as `EmailInterval`
			FROM Email_Inbox E
			WHERE 1=1 AND RECEIVEDDATE Between  p_ReportStartDate AND p_ReportEndDate 
			AND `Mailbox` IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit))
			GROUP BY RECEIVEDTIME,RECEIVEDDATE) AS tab 
			GROUP BY tab.`Date`,tab.EmailInterval;					
			
			DROP TEMPORARY TABLE IF EXISTS TEMPINTERVAL;
			CREATE TEMPORARY TABLE TEMPINTERVAL (IDX int AUTO_INCREMENT PRIMARY KEY, EmailInterval VARCHAR(20));
			INSERT INTO TEMPINTERVAL (EmailInterval) (Select '00:00' UNION	Select '00:30' UNION	Select '01:00' UNION	Select '01:30' UNION	Select '02:00' UNION	Select '02:30' UNION	Select '03:00' UNION	Select '03:30' UNION	Select '03:30' UNION	Select '04:00' UNION	Select '04:30' UNION	Select '05:00' UNION	Select '05:30' UNION	Select '06:00' UNION	Select '06:30' UNION	Select '07:00' UNION	Select '07:30' UNION	Select '08:00' UNION	Select '08:30' UNION	Select '09:00' UNION	Select '09:30' UNION	Select '10:00' UNION	Select '10:30' UNION	Select '11:00' UNION	Select '11:30' UNION	Select '12:00' UNION	Select '12:30' UNION	Select '13:00' UNION	Select '13:30' UNION	Select '14:00' UNION	Select '14:30' UNION	Select '15:00' UNION	Select '15:30' UNION	Select '16:00' UNION	Select '16:30' UNION	Select '17:00' UNION	Select '17:30' UNION	Select '18:00' UNION	Select '18:30' UNION	Select '19:00' UNION	Select '19:30' UNION	Select '20:00' UNION	Select '20:30' UNION	Select '21:00' UNION	Select '21:30' UNION	Select '22:00' UNION	Select '22:30' UNION	Select '23:00' UNION	Select '23:30');

			SET v_SELECTEDDATE = VARCHARTODATETIME(p_ReportStartDate);
			SET v_ENDDATE = VARCHARTODATETIME(p_ReportEndDate);

			WHILE v_SELECTEDDATE <=v_ENDDATE
			DO
			
			SET  v_I = 0;
			SET v_CNT = 48;

			WHILE v_I < v_CNT			
			DO
			SET v_I = v_I + 1;
			SELECT EmailInterval INTO v_EmailInterval FROM TEMPINTERVAL WHERE IDX = v_I;
			/* print v_EmailInterval */
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM TEMP WHERE `date` = v_SELECTEDDATE AND EmailInterval = v_EmailInterval)
					THEN					
						INSERT INTO TEMP 
						VALUES (DATE_FORMAT(v_SELECTEDDATE,'%Y%m%d'),0,v_EmailInterval);
					END IF;
				END;
			END WHILE;
			SET v_SELECTEDDATE = TIMESTAMPADD(DAY,1,v_SELECTEDDATE);
			END WHILE;			
		SELECT * FROM TEMP ORDER BY `date`, EmailInterval;
	END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_IvrDailyReport
DELIMITER //
CREATE PROCEDURE `Get_IvrDailyReport`(
p_Type VARCHAR(100),
p_MenuId VARCHAR(100),
p_CallerId LONGTEXT,
p_FromDate VARCHAR(50), 
p_ToDate VARCHAR(50))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

DECLARE v_Status INT;
BEGIN

SET v_Status := BreakStringIntoRows(p_CallerId);

IF(p_Type='calleriddata')
THEN
select  distinct H.ICH_CALLREFID FROM IVR_Call_History H 
		inner join IVR_Usage U on H.ICH_CALLREFID=U.ICH_CALLREFID
		where u.IU_ID in (p_MenuId) AND U.IU_ORDER='1' AND CONCAT(ICH_START_DATE,' ',ICH_START_TIME)>=p_FromDate AND CONCAT(ICH_START_DATE,' ',ICH_START_TIME)<=p_ToDate;
END IF;
IF(p_Type='menustatisticsdata')
THEN
	select COUNT(IU_ID) AS Access_Count,IFNULL(SUM(CAST(IU_EII AS UNSIGNED)),0) AS IU_EII,IFNULL(SUM(CAST(IU_ENI AS UNSIGNED)),0) AS IU_ENI,IFNULL(SUM(CAST(IU_EMC AS UNSIGNED)),0) AS IU_EMC from IVR_USAGE where ICH_CALLREFID IN (Select Id from BreakStringIntoRowsResult) and IU_ID = p_MenuId;
END IF;
IF(p_Type='individualmenudetaileddata')
THEN
	select ICH_CALLREFID,IU_ID,IU_EII,IU_ENI,IU_EMC,IU_ORDER,IMD_MENU_NAME from ivr_usage U 
	Inner JOIN IVR_MENU_DESC M ON U.IU_ID=M.IMD_MENU_ID
	where ich_callrefid=p_CallerId and iu_id=p_MenuId;
END IF;
IF(p_Type='detaileddata')
THEN
	Select * from IVR_USAGE U WHERE U.ICH_CALLREFID IN
	(
		select  distinct H.ICH_CALLREFID FROM IVR_Call_History H 
		inner join IVR_Usage U on H.ICH_CALLREFID=U.ICH_CALLREFID
		where u.IU_ID in (p_MenuId) AND U.IU_ORDER='1' AND CONCAT(ICH_START_DATE,' ',ICH_START_TIME)>=p_FromDate AND CONCAT(ICH_START_DATE,' ',ICH_START_TIME)<=p_ToDate
	);
END IF;
IF(p_Type='data')
	THEN 
		SELECT distinct  M.IMD_MENU_Name, M.IMD_MENU_ID FROM IVR_Call_History H
		inner join IVR_Usage U
		on H.ICH_CALLREFID = U.ICH_CALLREFID 
		inner join IVR_MENU_DESC M
		ON M.IMD_MENU_ID = U.IU_ID AND U.IU_ORDER='1'
		WHERE CONCAT(ICH_START_DATE,' ',ICH_START_TIME)>=p_FromDate AND CONCAT(ICH_START_DATE,' ',ICH_START_TIME)<=p_ToDate;
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_IvrHostTransaction_Report_Export
DELIMITER //
CREATE PROCEDURE `Get_IvrHostTransaction_Report_Export`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
			SELECT 
					IVR_CALL_HISTORY.ICH_CALLREFID AS UCID,
					SUBSTRING(REPLACE(REPLACE(REPLACE(DATE_FORMAT(IVR_TRL.REQUEST_DATE,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),0,15) AS REQUESTDATETIME,
					IVR_CALL_HISTORY.NRIC AS CIN,
					IVR_TRL.TRANSACTION_NAME AS TRANSACTIONNAME,
					IVR_TRL.MENU_DESCRIPTION AS MENUDESCRIPTION,
					IVR_TRL.REQ_MESSAGE AS REQUESTMESSAGE,
					IVR_TRL.RES_MESSAGE AS RESPONSEMESSAGE,
					IVR_CALL_HISTORY.ICH_DNIS AS HOTLINENUMBER,
					IVR_CALL_HISTORY.PHONE_CODE AS PHONECODE,
					IVR_CALL_HISTORY.CIF,					
					IVR_CALL_HISTORY.CUSTOMER_SEGMENT AS CUSTOMERSEGMENT,   
				    DATE_FORMAT(((SELECT(STR_TO_DATE(IVR_TRL.RESPONSE_DATE,108)))-(SELECT(STR_TO_DATE(IVR_TRL.REQUEST_DATE,108)))),114) AS RESPONSETIME,			
				    REPLACE(CONCAT(ICH_START_DATE,ICH_START_TIME),':','') AS STARTDATETIME
			 FROM  IVR_TRL INNER JOIN IVR_CALL_HISTORY ON IVR_CALL_HISTORY.ICH_CALLREFID=IVR_TRL.UCID
             WHERE 1=1 AND REPLACE(CONCAT(ICH_START_DATE,ICH_START_TIME),':','')>=v_DataFromDate AND REPLACE(CONCAT(ICH_START_DATE,ICH_START_TIME),':','')<=v_DataToDate;
			
		END;
END;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_IVR_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_IVR_DashboardData`(
  p_dnis varchar(1000),p_startdate VARCHAR(20),p_enddate VARCHAR(20), p_type varchar(20)
)
BEGIN
		DECLARE v_TotalAgentTransfer BIGINT;
		DECLARE v_TriesExceeded BIGINT;

		DECLARE v_TotalAttempts BIGINT;
		DECLARE v_TotalIVRCalls BIGINT;

		DECLARE v_TotalInvalidInput BIGINT;
		DECLARE v_TotalNoInput  BIGINT;
		
		DECLARE v_IntLocation INT;
	 
IF(p_type='summarydata')
	THEN
		select
		IFNULL((select count(1) from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0) as TotalCalls,
		IFNULL((select count(1) from IVR_Call_History where ICH_TR_DIS_FLAG != 'AT' AND FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0) as SelfServiceCalls,
		IFNULL((select count(1) from IVR_Call_History where ICH_TR_DIS_FLAG = 'AT' AND FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0) as TransferredCalls,
		IFNULL((select 
			(select SUM(ifnull(cast(ICH_CALL_DUR as double),0)) from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate)
			/
			NULLIF((select COUNT(1) from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0)),0) 
			as AverageHandleTime,
		IFNULL((select count(1) from IVR_Call_History where QUEUETIME='NULL' AND FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0) as CallsinQueue,
		IFNULL((select count(1) from IVR_Callback_Requests where `Type`='IVR' AND FIND_IN_SET(CALLERID,p_dnis)>0 AND Request_date>=p_startdate AND Request_date<=p_enddate),0) as TotalCallbacks,
		IFNULL((select MAX(ICH_CALL_DUR)  from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0) as MaxTimeSpent,
		IFNULL((select 
			  (select SUM(ifnull(cast(ICH_CALL_DUR as double),0)) from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate)
		      /
			  NULLIF((select COUNT(1) from IVR_Call_History WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and  ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate),0)),0)
			  AS AverageTimeSpent;
	END IF;
	


IF(p_type='piedata')
	THEN
		Select COUNT(1) as TotalInteraction, 
		COUNT(CASE WHEN IFNULL(UPPER(TPIN_VERIFIED),'Fail') = 'Pass' THEN TPIN_VERIFIED END) AS TPINVerifiedInteraction,
		COUNT(CASE WHEN IFNULL(UPPER(OTP_VERFIFIED),'Y') = 'Pass' THEN OTP_VERFIFIED END) AS OTPVerifiedInteraction
		from IVR_Call_History
		WHERE FIND_IN_SET(ICH_DNIS,p_dnis)>0 and ICH_START_DATE>=p_startdate AND ICH_END_DATE<=p_enddate;
	END IF;

IF(p_type='performancedata')
	THEN
		DROP TEMPORARY TABLE IF EXISTS Result_Table;
		CREATE TEMPORARY TABLE Result_Table (DNIS VARCHAR(50),TaskCompletionRate BIGINT,CallClosureRate BIGINT,FirstAttemptCompletionRate BIGINT);

		IF p_dnis NOT LIKE '%,'
		THEN
    		set p_dnis := concat(p_dnis , ',');
		END IF;

		WHILE (LOCATE(',', p_dnis, 1) > 0)
        DO
            SET v_IntLocation := LOCATE(',',p_dnis, 1);
				      
            SET @seldnis := RTRIM(LTRIM(SUBSTRING(p_dnis,   1, v_IntLocation-1)));
              
            Select COUNT(1) Into v_TotalIVRCalls FROM IVR_Call_History WHERE  IVR_Call_History.ICH_DNIS = @seldnis 
				AND IVR_Call_History.ICH_START_DATE>=p_startdate AND IVR_Call_History.ICH_END_DATE<=p_enddate;
				
				Select COUNT(1) Into v_TotalAgentTransfer FROM IVR_Call_History WHERE IVR_Call_History.ICH_TR_DIS_FLAG = 'AT' 
				and IVR_Call_History.ICH_DNIS =@seldnis and  IVR_Call_History.ICH_START_DATE>=p_startdate AND 
				IVR_Call_History.ICH_END_DATE<=p_enddate;

				SELECT SUM(CAST(IFNULL(IVR_Usage.IU_EMC,0) AS UNSIGNED)) INTO v_TriesExceeded
				FROM IVR_Usage
				INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
				WHERE IVR_Call_History.ICH_DNIS =@seldnis and  IVR_Call_History.ICH_START_DATE>=p_startdate 
				AND IVR_Call_History.ICH_END_DATE<=p_enddate and (IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

				SELECT COUNT(IVR_MENU_DESC.IMD_MENU_ID) INTO v_TotalAttempts
				FROM IVR_MENU_DESC,IVR_Usage
				INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
				WHERE IVR_Call_History.ICH_DNIS =@seldnis and  IVR_Call_History.ICH_START_DATE>=p_startdate 
				AND IVR_Call_History.ICH_END_DATE<=p_enddate and (IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

				SELECT  SUM(CAST(IFNULL(IVR_Usage.IU_ENI,0) AS UNSIGNED)) INTO v_TotalNoInput
				FROM IVR_Usage
				INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
				WHERE IVR_Call_History.ICH_DNIS =@seldnis and  IVR_Call_History.ICH_START_DATE>=p_startdate 
				AND IVR_Call_History.ICH_END_DATE<=p_enddate and (IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));
				
				SELECT  SUM(CAST(IFNULL(IVR_Usage.IU_EII,0) AS UNSIGNED)) INTO v_TotalInvalidInput
				FROM IVR_Usage
				INNER JOIN IVR_Call_History On IVR_Usage.ICH_CALLREFID  = IVR_Call_History.ICH_CALLREFID 
				WHERE IVR_Call_History.ICH_DNIS =@seldnis and  IVR_Call_History.ICH_START_DATE>=p_startdate 
				AND IVR_Call_History.ICH_END_DATE<=p_enddate and (IVR_Usage.ICH_CALLREFID IN(SELECT ICH_CALLREFID FROM IVR_Call_History));

				INSERT INTO Result_Table
				Select @seldnis as 'DNIS' , IFNULL((IFNULL(((v_TotalAttempts - IFNULL(v_TriesExceeded,0) - v_TotalAgentTransfer) * 100),0) / NULLIF(v_TotalAttempts,0)),0)  'TaskCompletionRate',
				IFNULL((IFNULL(((v_TotalIVRCalls- v_TotalAgentTransfer)*100),0)/NULLIF(v_TotalIVRCalls,0)),0) 'CallClosureRate' ,
				IFNULL((IFNULL(((v_TotalAttempts-v_TriesExceeded-v_TotalInvalidInput-v_TotalNoInput-v_TotalAgentTransfer)*100),0)/NULLIF(v_TotalAttempts,0)),0) 'FirstAttemptCompletionRate';
				    
            SET p_dnis := INSERT(p_dnis,   1, v_IntLocation,   '');
      END WHILE;

		Select * from Result_Table;

END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_IVR_OrderTakingReport_Export
DELIMITER //
CREATE PROCEDURE `Get_IVR_OrderTakingReport_Export`(
 p_FromDate VARCHAR(20),
 p_ToDate VARCHAR(20)
)
BEGIN

	SELECT 
		`UCID`,
	    `PHONENUMBER` AS CallerID,
		REPLACE(CONCAT(REQUEST_DATE,REQUEST_TIME), ' ' , '') AS REQUESTDATETIME,
		`TYPE` AS INTENT, 		  
		`CIN` AS CustomerIDOrCIN,
		DNIS,  
		`STATUS`, 
		REQUEST_DATA_1 AS REQUESTDATA_1, 
		REQUEST_DATA_2 AS REQUESTDATA_2, 
		REQUEST_DATA_3 AS REQUESTDATA_3, 
		REQUEST_DATA_4 AS REQUESTDATA_4, 
		REQUEST_DATA_5 AS REQUESTDATA_5, 
		REQUEST_DATA_6 AS REQUESTDATA_6, 
		REQUEST_DATA_7 AS REQUESTDATA_7, 
		REQUEST_DATA_8 AS REQUESTDATA_8, 
		REQUEST_DATA_9 AS REQUESTDATA_9, 
		REQUEST_DATA_10  AS REQUESTDATA_10 
FROM IVR_ORDER_TAKE 
WHERE 1=1 and CONCAT(REQUEST_DATE,REQUEST_TIME) >=p_FromDate and CONCAT(REQUEST_DATE,REQUEST_TIME) <= p_ToDate;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Line_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Line_DashboardData`(
	 p_statementenqid varchar(50),
	 p_rewardenqid varchar(50)
)
BEGIN
	Declare v_UniqueRegistration INT;
	Declare v_UniqueDeregistration INT;
	Declare v_Registration INT;
	Declare v_Deregistration INT;
	Declare v_UniqueOCMDeregistration INT;
	Declare v_StatementEnqCount INT;
	Declare v_RewardsEnqCount INT;

		
		SET v_UniqueRegistration=(SELECT COUNT(DISTINCT CustomerOrgId) UniqueRegistration FROM Notify_SMMCustomerHistory WHERE Active=1 AND  RegistrationMode='LINE'
		AND  CreatedDateTime >= TIMESTAMPADD(YEAR,-1,NOW(3)) AND  CreatedDateTime <=NOW(3));

		SET v_UniqueDeregistration=(SELECT  COUNT(DISTINCT CustomerOrgId) UniqueDeregistration FROM Notify_SMMCustomerHistory WHERE Active=0 AND  RegistrationMode='LINE'
		AND CreatedDateTime >= TIMESTAMPADD(YEAR,-1,NOW(3)) AND CreatedDateTime <=NOW(3));

		SET v_Registration=(SELECT COUNT(CustomerOrgId) Registration FROM Notify_SMMCustomerHistory	WHERE Active=1 AND  RegistrationMode='LINE'
		AND CreatedDateTime >= TIMESTAMPADD(YEAR,-1,NOW(3)) AND  CreatedDateTime  <=NOW(3));

		SET v_Deregistration=(SELECT COUNT(CustomerOrgId) Deregistration FROM Notify_SMMCustomerHistory WHERE Active=0 AND  RegistrationMode='LINE'
		AND CreatedDateTime >= TIMESTAMPADD(YEAR,-1,NOW(3)) AND  CreatedDateTime  <=NOW(3));

		SET v_UniqueOCMDeregistration=(SELECT COUNT(DISTINCT CustomerOrgId) UniqueOCMDeregistration FROM Notify_SMMCustomerHistory WHERE Active=0 AND  RegistrationMode='OCM'
		AND CreatedDateTime >= TIMESTAMPADD(YEAR,-1,NOW(3)) AND  CreatedDateTime  <=NOW(3));

		SET v_StatementEnqCount=(SELECT sum(StatementEnqCount) StatementEnqCount  FROM  Notify_SMMCustomer S 
		INNER JOIN Chat_Call_History C ON S.CustomerOrgId=C.CIF AND S.CustomerChannelId = C.EMP_NAME
		LEFT JOIN 
		(
			SELECT SessionID, COUNT(1) StatementEnqCount FROM Chat_Usage  WHERE ID=p_statementenqid
			GROUP BY SessionID
		) StatementEnq  ON C.SessionID=StatementEnq.SessionID
		WHERE C.`ENDDATETIME`>= DATE_FORMAT(TIMESTAMPADD(YEAR,-1,NOW(3)) ,'%Y%m%d%H%i%s') AND C.`ENDDATETIME`<=DATE_FORMAT(NOW(3),'%Y%m%d%H%i%s'));


		SET v_RewardsEnqCount=(SELECT sum(RewardsEnqCount) RewardsEnqCount  FROM  Notify_SMMCustomer S 
		INNER JOIN Chat_Call_History C ON S.CustomerOrgId=C.CIF AND S.CustomerChannelId = C.EMP_NAME
		LEFT JOIN 
		(
			SELECT SessionID, COUNT(1) RewardsEnqCount FROM Chat_Usage WHERE ID=p_rewardenqid
			GROUP BY SessionID
		) RewardsEnq  ON C.SessionID=RewardsEnq.SessionID
		WHERE C.`ENDDATETIME`>= DATE_FORMAT(TIMESTAMPADD(YEAR,-1,NOW(3)) ,'%Y%m%d%H%i%s') AND C.`ENDDATETIME`  <=DATE_FORMAT(NOW(3),'%Y%m%d%H%i%s'));

	
	SELECT IFNULL(v_UniqueRegistration,0) UniqueRegistration,IFNULL(v_UniqueDeregistration,0) UniqueDeregistration,
	IFNULL(v_Registration,0) Registration,IFNULL(v_Deregistration,0) Deregistration,IFNULL(v_UniqueOCMDeregistration,0) UniqueOCMDeregistration,
	IFNULL(v_StatementEnqCount,0) StatementEnqCount,IFNULL(v_RewardsEnqCount,0) RewardsEnqCount;
 
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Mailboxes
DELIMITER //
CREATE PROCEDURE `Get_Mailboxes`(p_Type VARCHAR(10), p_ID VARCHAR(10))
BEGIN
	IF(p_Type = 'amac')
	THEN
		IF(IFNULL(p_ID,'') = '')
		THEN
		Select 1; 
			--  SELECT DISTINCT AACCSkillName AS MailboxName, A.IncomingMailBox AS MailboxID FROM Email_Inbox_c E INNER JOIN 
			--  [SG_CFS_CMM_DBLINK].[OCM].[DBO].[AGT_Intent_Skill_Map] A ON E.Mailbox = A.IncomingMailBox
		ELSE
		SELECT 1;
			--  SELECT DISTINCT AACCSkillName AS MailboxName, A.IncomingMailBox AS MailboxID FROM Email_Inbox_c E INNER JOIN 
			--  [SG_CFS_CMM_DBLINK].[OCM].[DBO].[AGT_Intent_Skill_Map] A ON E.Mailbox = A.IncomingMailBox WHERE A.IncomingMailBox = p_ID
		END IF;
		END IF;
		
	IF(p_Type = 'tmac')
	THEN
		IF(IFNULL(p_ID,'') = '')
		THEN
			SELECT DISTINCT(MailAccountName) AS MailboxName, MailAccountID AS MailboxID  FROM Email_AccountConfiguration;
		ELSE
			SELECT DISTINCT(MailAccountName) AS MailboxName, MailAccountID AS MailboxID  FROM 
			Email_AccountConfiguration WHERE MailAccountID = p_ID;
		END IF;
	END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCMReport
DELIMITER //
CREATE PROCEDURE `Get_OCMReport`(
p_Type VARCHAR(20),
p_SearchString LONGTEXT,
p_SortString LONGTEXT,
p_PageNo INT /* = 1 */,
p_PageSize INT /* = 10 */,
p_Query LONGTEXT,
p_OrderbyString LONGTEXT)
BEGIN
   DECLARE  v_TotalCount LONGTEXT;
   
   DECLARE v_lPageNbr INT;
	DECLARE v_lPageSize INT;
	DECLARE v_lFirstRec INT;
	DECLARE v_lLastRec INT;
	DECLARE v_lTotalRows INT;
	DECLARE v_CombineQuery LONGTEXT;
	
	DECLARE v_FindChar VARCHAR(8); 
	DECLARE v_FindChars LONGTEXT;

   IF(p_Type = 'MAIN')
   THEN
		SET v_lPageNbr = p_PageNo;
		SET v_lPageSize = p_PageSize;
		SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
		SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );
		
		SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY ',p_OrderbyString,' ASC) RowNumber, * FROM  (',p_Query,'
		) AS table1  WHERE 1=1 ',p_SearchString,'
		)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR) ,' ',p_SortString);
		
		SET v_TotalCount = CONCAT('SELECT  COUNT(*) FROM(',p_Query,')AS table12 Where 1=1 ',p_SearchString);
		
		SET @stmt_str = v_CombineQuery;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		
		SET @stmt_str = v_TotalCount;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
   ELSEIF ( p_Type='DETAIL')	
	THEN			
	   SET @stmt_str = p_Query;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
   ELSE	
		SET @stmt_str = p_Query;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
   
	SET v_FindChar = 'order by';
	SET v_FindChars = LOCATE(v_FindChar, p_Query);

	if (v_FindChars<>0)
	then
		SET p_Query = LEFT(p_Query, v_FindChars-1);
	end if;
		SET v_TotalCount = CONCAT('SELECT  COUNT(*) FROM(',p_Query,')AS table12 Where 1=1 ');
	
	SET @stmt_str = v_TotalCount;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
   END IF;
END//
DELIMITER ;



-- Dumping structure for procedure OCM.Get_OCM_AgentHistoricalReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentHistoricalReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
   	select AgentID,AgentName,AcdCalls as AcdCalls,
	    convert(left(`Interval`,locate(':',`Interval`)-1),UNSIGNED) as intvl,DATE_FORMAT(date,120) as DateInt,REPLACE(`interval`,'- ','-') as `Interval`,
		left(AvgTalkTime, LOCATE(':', AvgTalkTime)-1)* 60 + substring(AvgTalkTime, LOCATE(':', AvgTalkTime)+1,2) 
		as AvgTalkTime, 
	    left(TotalAfterCall, LOCATE(':', TotalAfterCall)-1)* 60 + substring(TotalAfterCall, LOCATE(':', TotalAfterCall)+1,2) 
		as TotalAfterCallTime,
	    left(TotalAvailCall, LOCATE(':', TotalAvailCall)-1)* 60 + substring(TotalAvailCall, LOCATE(':', TotalAvailCall)+1,2)
        as TotalAvailTime,
		left(TotalAux, LOCATE(':', TotalAux)-1)* 60 + substring(TotalAux, LOCATE(':', TotalAux)+1,2) 
		as TotalAuxTime,
		ExtnCalls as ExtensionCalls,
		left(AvgExtnTime, LOCATE(':', AvgExtnTime)-1)* 60 + substring(AvgExtnTime, LOCATE(':', AvgExtnTime)+1,2) 
		as AvgExtensionTime,
		left(TotalTimeStaffed, LOCATE(':', TotalTimeStaffed)-1)* 60 + substring(TotalTimeStaffed, LOCATE(':', TotalTimeStaffed)+1,2)
		as TotalTimeStaffed,
		left(TotalHoldTime, LOCATE(':', TotalHoldTime)-1)* 60 + substring(TotalHoldTime, LOCATE(':', TotalHoldTime)+1,2)
		as TotalHoldTime,`Date`
		from `TMAC_H.Agent` 
		where `Date`>=v_DataFromDate AND `Date`<=v_DataToDate and `Interval` <> 'SUMMARY';
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_AgentInteractionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentInteractionReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_DISCONNECTEDBY_COLNAME VARCHAR(20);
DECLARE V_SQLQuery LONGTEXT;
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 
		SET v_DISCONNECTEDBY_COLNAME = 'DisconnectedBy';
	
		If EXISTS(SELECT 1 FROM Information_schema.COLUMNS WHERE TABLE_NAME = 'TMAC_Interactions' AND COLUMN_NAME = 'DisconnectedBy') 
		THEN
			SET v_DISCONNECTEDBY_COLNAME = 'DisconnectedBy';
		ELSE
			SET v_DISCONNECTEDBY_COLNAME = 'NULL';
		END IF;
		
		IF(p_Type = 'MAIN')
		THEN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
			SET V_SQLQuery=CONCAT('
			SELECT DISTINCT `User` AS Ani,
							AgentId as AgentID,
							T.Channel,
							SubChannel,
							T.SessionId AS SessionID,
							SubSessionId as SubSessionID,
							InteractionId as InteractionID,
							T.Direction,
							T.CreatedDateTime,
							CreatedReason,
							Skill,
							TS.SkillName,
							CONCAT(IFNULL(A.FirstName,'''') ,'''', IFNULL(A.LastName,'''')) AS AgentName,
							Dnis as DNIS,
							DnisName as DNISName,
							IsTransfered,
							IsConferenced,
							IsReconnected AS TPinTransferReconnected,
							IsConferencedTo AS ConferencedTo,
							IsTranferedTo AS TransferedTo,
							CASE WHEN IsTransfered=1 OR IsConferenced=1 THEN  TrasnferConferenceFromAgent ELSE '''' END AS TransferConferenceFromAgent,
							CASE WHEN IsTransfered=1 OR IsConferenced=1 THEN  TrasnferConferenceFromInteraction ELSE '''' END AS TransferConferenceFromInteraction,
							OtherData,
							ClosedDateTime AS ClosedDateTime,
							ClosedReason,
							CALLCONNECTEDTIME AS  ConnectedDateTime,
							CALLDISCONNECTEDTIME AS  DisconnectedDateTime,
							ActiveTime,
							HoldTime,
							TrasnferToAgent AS TransferToAgent,
							ConferenceToAgentList,
							QueueTime,
							AcwTime as ACWTime,
							ActiveTime+HoldTime+AcwTime HandleTime,
							CASE WHEN ifnull(TIUD.CIF,'''')='''' THEN IH.CIF ELSE TIUD.CIF END as CIF,
							IH.CLID AS RegisteredMobileNo,
							T.AgentComment, 
							',v_DISCONNECTEDBY_COLNAME,' AS DisconnectedBy
							FROM TMAC_Interactions T
							INNER JOIN AGT_Agent A ON A.AvayaLoginID=T.AgentId 
							LEFT JOIN AGT_Agent AA ON AA.AvayaLoginID = T.TrasnferConferenceFromAgent
							LEFT JOIN GBL_InteractionHistory IH ON IH.SessionID=T.SessionId 
							LEFT JOIN TMAC_Skills TS ON TS.SkillExtension=T.Skill
							LEFT JOIN TMAC_InteractionUserData TIUD ON TIUD.SessionId = T.SessionId
							where 1=1 AND IH.ID IN (SELECT MAX(ID) FROM GBL_InteractionHistory WHERE SessionID=T.SessionId)
							AND  ClosedDateTime>=''',v_DataFromDate,''' AND ClosedDateTime<=''',v_DataToDate,'''');
							
							SET @stmt_str = V_SQLQuery;
							PREPARE stmt FROM @stmt_str;
							EXECUTE stmt;
							DEALLOCATE PREPARE stmt;
							
							SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		END IF;
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AgentPerformanceReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentPerformanceReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
select OperatorID, 
OperatorName, 
AgentOrgUnit,
CampaignName, CampaignType, 
SupervisorName,
CallAttempts as CallAttempts, 
SurveyID, 
QuestionnaireName,
CampaignOrgUnit,
IFNULL(AgentConversationTime,0) as AgentConversationTime, 
IFNULL(sum(SuccessCalls),0) as SuccessCalls,
IFNULL(sum(TalkTimeOnSuccessCalls),0) as TalkTimeOnSuccessCalls,
CallAttempts - IFNULL(sum(SuccessCalls),0) as RefusedCalls,
IFNULL(sum(RejectedCalls),0) as RejectedCalls,
IFNULL(sum(PickedUpCalls),0) as PickedUpCalls,
IFNULL(sum(TalkTimeOnPickedUpCalls),0) as TalkTimeOnPickedUpCalls,
IFNULL(sum(DeclineCalls),0) as DeclineCalls,
IFNULL(sum(TalkTimeOnDeclineCalls),0) as TalkTimeOnDeclineCalls,
IFNULL(sum(Callback),0) as Callback,
IFNULL(sum(TalkTimeOnCallbackCalls),0) as TalkTimeOnCallbackCalls,
IFNULL(sum(MissedCalls),0) as MissedCalls,
IFNULL(sum(TalkTimeOnRejectedCalls),0) as TalkTimeOnRejectedCalls,
IFNULL(sum(RecievedCallbacks),0) as RecievedCallbacks,
CALLDISCONNECTEDTIME as CallDisconnectedDateTime,
CALLCONNECTEDTIME as CallConnectedDateTime, `Interval`
from(
SELECT distinct TI.CALLCONNECTEDTIME,
					TI.CALLDISCONNECTEDTIME,
					case   WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T') BETWEEN '00:00:00' AND '00:59:59'  THEN '00:00-00:59' 
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '01:00:00' AND '01:59:59'  THEN '01:00-01:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '02:00:00' AND '02:59:59'  THEN '02:00-02:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '03:00:00' AND '03:59:59'  THEN '03:00-03:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '04:00:00' AND '04:59:59'  THEN '04:00-04:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '05:00:00' AND '05:59:59'  THEN '05:00-05:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '06:00:00' AND '06:59:59'  THEN '06:00-06:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '07:00:00' AND '07:59:59'  THEN '07:00-07:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '08:00:00' AND '08:59:59'  THEN '08:00-08:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '09:00:00' AND '09:59:59'  THEN '09:00-09:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '10:00:00' AND '10:59:59'  THEN '10:00-10:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '11:00:00' AND '11:59:59'  THEN '11:00-11:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '12:00:00' AND '12:59:59'  THEN '12:00-12:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '13:00:00' AND '13:59:59'  THEN '13:00-13:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '14:00:00' AND '14:59:59'  THEN '14:00-14:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '15:00:00' AND '15:59:59'  THEN '15:00-15:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '16:00:00' AND '16:59:59'  THEN '16:00-16:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '17:00:00' AND '17:59:59'  THEN '17:00-17:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '18:00:00' AND '18:59:59'  THEN '18:00-18:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '19:00:00' AND '19:59:59'  THEN '19:00-19:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '20:00:00' AND '20:59:59'  THEN '20:00-20:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '21:00:00' AND '21:59:59'  THEN '21:00-21:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '22:00:00' AND '22:59:59'  THEN '22:00-22:59'
		WHEN DATE_FORMAT(VARCHARTODATETIME(TI.CALLDISCONNECTEDTIME),'%T')  BETWEEN '23:00:00' AND '23:59:59'  THEN '23:00-23:59'
				END AS `Interval`,
					R.Agent AS OperatorID, 
					CONCAT(A.FirstName,' ',A.LastName) AS OperatorName,
					T.TeamName AS AgentOrgUnit,
					CONCAT(A1.FirstName,' ',A1.LastName) AS SupervisorName,
					TC.`Name` AS CampaignName,
					TC.`Type` AS CampaignType,
					SR.SessionId as SurveyID,
					SR.QuestionnaireName as QuestionnaireName,
					T1.TeamName AS CampaignOrgUnit,
					D.`COUNT` as CallAttempts,
					TI.ActiveTime as AgentConversationTime,
					CASE WHEN SC.StatusCode ='SUCCESS' THEN 1 ELSE 0 END AS SuccessCalls,
					CASE WHEN SC.StatusCode ='SUCCESS' THEN TI.ActiveTime ELSE 0 END AS TalkTimeOnSuccessCalls,
					CASE WHEN SC.StatusCode ='REJECTED' THEN 1 ELSE 0 END AS RejectedCalls,
					CASE WHEN SC.StatusCode ='PICKEDUP' THEN 1 ELSE 0 END AS PickedUpCalls,
					CASE WHEN SC.StatusCode ='PICKEDUP' THEN TI.ActiveTime ELSE 0 END AS TalkTimeOnPickedUpCalls,
					CASE WHEN SC.StatusCode ='DECLINE' THEN 1 ELSE 0 END AS DeclineCalls,
					CASE WHEN SC.StatusCode ='DECLINE' THEN TI.ActiveTime ELSE 0 END AS TalkTimeOnDeclineCalls,
					CASE WHEN IsCallback = 1 THEN 1 ELSE 0 END AS Callback,
					CASE WHEN IsCallback = 1 THEN TI.ActiveTime ELSE 0 END AS TalkTimeOnCallbackCalls,
					CASE WHEN SC.StatusCode ='MISSED_CALL' THEN 1 ELSE 0 END AS MissedCalls,
					CASE WHEN SC.StatusCode ='REJECTED' THEN TI.ActiveTime ELSE 0 END AS TalkTimeOnRejectedCalls,
					CASE WHEN (R.Status LIKE '%AgentConnected%' AND IsCallback = 1) THEN 1 ELSE 0 END AS RecievedCallbacks
			FROM
			(SELECT SessionId,MIN(CALLCONNECTEDTIME) CALLCONNECTEDTIME, MAX(CALLDISCONNECTEDTIME) CALLDISCONNECTEDTIME,
						SUM(ActiveTime) ActiveTime, AgentId
						FROM TMAC_Interactions WHERE CALLDISCONNECTEDTIME >=  v_DataFromDate and  CALLDISCONNECTEDTIME <= v_DataToDate
						AND (CALLCONNECTEDTIME !='00010101000000' AND  CALLDISCONNECTEDTIME !='00010101000000')
						GROUP BY SessionId, AgentId)TI
			inner join TCM_Record R ON TI.SessionId=R.UCID AND TI.AgentId = R.Agent
			LEFT JOIN AGT_Agent A ON R.Agent=A.AvayaLoginID
			LEFT JOIN TCM_Contact C ON C.ID=R.ContactId
			LEFT JOIN AGT_Teams T ON A.TeamID = T.TeamID
			LEFT JOIN TCM_Campaign TC ON C.CampId = TC.ID
			LEFT JOIN AGT_Teams T1 ON TC.TeamID = T1.TeamID
			LEFT JOIN AGT_Agent A1 ON A1.ID=A.PrimarySupervisorID
			LEFT join (
					SELECT COUNT(C.ID) as `COUNT` ,ContactId  
					FROM TCM_Contact C 
					LEFT JOIN TCM_Record R on R.ContactId= C.ID 
					LEFT JOIN TMAC_Interactions TI ON R.UCID = TI.SessionId
					WHERE TI.CALLDISCONNECTEDTIME >= v_DataFromDate and TI.CALLDISCONNECTEDTIME <= v_DataToDate 
					AND TI.SubSessionId IS NOT NULL
					GROUP BY ContactId )D 
			on D.ContactId = R.ContactId
			LEFT join (SELECT `StatusCode`, CampId FROM TCM_StatusCodes) SC 
				on SC.CampId= R.CampId and SC.`StatusCode`= R.StatusCode
			left join TAS_SurveyResult SR on SR.UCID=R.UCID
			
			WHERE TI.CALLDISCONNECTEDTIME >= v_DataFromDate and TI.CALLDISCONNECTEDTIME <= v_DataToDate
			)X
			group by CALLCONNECTEDTIME, CALLDISCONNECTEDTIME, X.AgentConversationTime,
			OperatorID, OperatorName, CallAttempts, SurveyID, QuestionnaireName,
			AgentOrgUnit, CampaignOrgUnit, CampaignName, CampaignType, SupervisorName;
	END IF;
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AgentWrapupDataSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AgentWrapupDataSummaryReport`(
 p_FromDate VARCHAR(20),
 p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');

	SELECT AgentId,
	IFNULL(SUM(TAB.TotalInteraction),0) TotalAcdCalls,
	IFNULL(SUM(TAB.HandleTime),0) TotalHandleTime,
	IFNULL(MAX(TAB.HandleTime),0) MaxHandleTime,
	IFNULL(SUM(TAB.TalkTime),0) TotalTalkTime,
	IFNULL(MAX(TAB.TalkTime),0) MaxTalkTime,
	IFNULL(SUM(TAB.WorkTime),0) TotalAfterCallWorkTime,
	IFNULL(MAX(TAB.WorkTime),0) MaxWorkTime
	FROM
	(
		SELECT AgentId,
		CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN  1 ELSE 0 END AS TotalInteraction,
		CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN ActiveTime+HoldTime+AcwTime Else 0 END AS HandleTime,
		CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN ActiveTime ELSE 0 END AS TalkTime,
		CASE WHEN Channel IN ('Voice','Chat','TextChat','FBPost','FBPrivate','Email','AudioChat','VideoChat','SMS','FAX') THEN AcwTime ELSE 0 END AS WorkTime 
		FROM TMAC_Interactions 
		WHERE ClosedDateTime>=v_DataFromDate AND ClosedDateTime<=v_DataToDate AND AcwTime > 0
	) TAB
	GROUP BY TAB.AgentId;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_Agent_ChatPerformance
DELIMITER //
CREATE PROCEDURE `Get_OCM_Agent_ChatPerformance`(
 p_Type VARCHAR(50),
 p_FromDate VARCHAR(20),
 p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
		
		IF(p_Type = 'MAIN')
		THEN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
			Select  AgentId ,
					(concat(ifnull(A.FirstName,''),' ',ifnull(A.LastName,''))) as AgentName,
					ifnull(trans.Transfered,0) as ChatTransferred, 	
					ifnull(conf.Conferenced,0) as ChatConferenced,
					ActiveTime,HoldTime,
					AcwTime as AverageACWTime,
					T.CreatedDateTime as CreatedDateTime,
					T.ClosedDateTime as ClosedDateTime,
					QueueTime, 
					AgentWaitTimeForResponse AS AgentWaitTime, 
					UserWaitTimeForResponse AS UserWaitTime,
					0 AS Rating, 
					0 AS ConfereneceRejected,
					0 AS TransferRejected
			from TMAC_Interactions T left join `AGT_Agent` A on A.AvayaLoginID=T.AgentId
			left join
			(
				  select SessionId,TrasnferConferenceFromAgent, count(1) as Transfered from TMAC_Interactions 
				  where IsTransfered='1'  and (Channel='TextChat' OR Channel='Chat') group by TrasnferConferenceFromAgent,SessionId
			)
			trans on  trans.TrasnferConferenceFromAgent = A.AvayaLoginID and trans.SessionId = T.SessionId and TrasnferToAgent <> '' and (IsTransfered!='1' or IsTranferedTo !='0')
			left join
			(
				  select SessionId,TrasnferConferenceFromAgent, count(1) as Conferenced from TMAC_Interactions 
				  where IsConferenced='1' and (Channel='TextChat' OR Channel='Chat') group by TrasnferConferenceFromAgent,SessionId
			)
			conf on  conf.TrasnferConferenceFromAgent = A.AvayaLoginID and conf.SessionId = T.SessionId and ConferenceToAgentList <> '' and (IsConferenced!='1' or IsConferencedTo !='0')
			where (Channel='Chat' or Channel='TextChat')   AND
			T.ClosedDateTime>= v_DataFromDate and T.ClosedDateTime<=v_DataToDate;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		END IF;

		IF(p_Type = 'DETAIL')
		THEN
				SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
				SELECT DISTINCT T.Dnis, 
								B.Skill,
								T.SessionId, 
								(concat(ifnull(ATF.FirstName,''),' ',ifnull(ATF.LastName,'')))as TransferredOrConferencedFrom,
								(concat(ifnull(ATT.FirstName,''),' ',ifnull(ATT.LastName,'')))as TransferredOrConferencedTo,
								T.CreatedDateTime,
								T.ClosedDateTime,
								T.IsTransfered,
								T.IsConferenced,
								ATF.AvayaLoginID as AgentID
				from TMAC_Interactions T
				left JOIN `TMAC_Interactions`  B ON T.SessionId =B.SessionId AND B.TrasnferConferenceFromAgent=''
				left Join  `AGT_Agent` ATT On ATT.AvayaLoginID = T.AgentId
				Left Join `AGT_Agent` ATF On ATF.AvayaLoginID = T.TrasnferConferenceFromAgent
				Where T.ClosedDateTime >= v_DataFromDate and T.ClosedDateTime <= v_DataToDate and (T.Channel='Chat' or T.Channel='TextChat'); 
				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		END IF;
END;
END//
DELIMITER ;


-- Dumping structure for procedure OCM.Get_OCM_AudioVideoPlaybackReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_AudioVideoPlaybackReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'MAIN')
	THEN
 			SELECT DISTINCT  H.SessionID, I.SubSessionId as GroupID, H.ID, CASE WHEN ifnull(U.CIF,'')='' THEN INTDURTIME.CIF ELSE U.CIF END AS IDENTIFICATION, 
			INTDATETIME.StartDateTime, INTDATETIME.EndDateTime,
			CASE WHEN ChatBotStartDateTime IS NULL THEN INTDATETIME.StartDateTime ELSE ChatBotStartDateTime END ChatBotStartDateTime,
			CASE WHEN ChatBotEndDateTime IS NULL THEN INTDATETIME.EndDateTime ELSE ChatBotEndDateTime END ChatBotEndDateTime,I.Intent INTENTNAME ,
			(CASE WHEN IFNULL(S.SkillName,'')='' THEN IFNULL(I.Skill,'') ELSE IFNULL(S.SkillName,'') END) as Skill,
			(CASE WHEN (Ifnull(TabCallback.CallbackCount,0))=0 THEN 'No' ELSE 'Yes' END) AS CALLBACK, 
			ifnull((TIMESTAMPDIFF(SECOND,convert(insert(insert(insert(INTDATETIME.StartDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
			convert(insert(insert(insert(INTDURTIME.DurEndDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))),0) AS DURATIONTIME,
			ISCHATTRANSFERED,ISCHATCONFERENCED,  I.AgentId AS AGENTID,OtherData as OTHERDATA,Ifnull(QueueTime,0) AS QUEUEWAITTIME,
			AGENTWAITTIME,USERWAITTIME, I.SubChannel AS `CHANNEL`, INTDURTIME.CHATENDREASON
			FROM GBL_InteractionHistory H 
			LEFT JOIN TMAC_Interactions I ON I.SessionId= H.SessionID
			LEFT JOIN TMAC_InteractionUserData U ON U.SessionID= H.SessionID
			LEFT JOIN TMAC_Skills S on S.SkillExtension=I.Skill
			LEFT JOIN
			(
			  SELECT SessionId, ifnull(sum(IsTransfered),0) AS ISCHATTRANSFERED,ifnull(sum(IsConferenced),0) AS ISCHATCONFERENCED, 
			  ifnull(sum(AgentWaitTimeForResponse),0) as AGENTWAITTIME , ifnull(sum(UserWaitTimeForResponse),0) as USERWAITTIME from TMAC_Interactions  
			  WHERE `Channel` IN ('AudioChat','VideoChat') OR SubChannel IN ('Audio','Video') GROUP BY SessionId
			) 
			CHAT ON CHAT.SessionId=H.SessionID 
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS StartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS EndDateTime FROM GBL_InteractionHistory WHERE `Channel` IN ('AudioChat','VideoChat','Chat','TextChat') 
				AND ((InsertedBy <> 'ChatBot') AND (InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')))
				GROUP BY SessionID
			) 
			INTDATETIME ON INTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS ChatBotStartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS ChatBotEndDateTime FROM GBL_InteractionHistory WHERE Channel IN ('AudioChat','VideoChat','Chat','TextChat')
				AND ((InsertedBy = 'ChatBot') OR (InsertedBy IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot'))) 
				GROUP BY SessionID
			) 
			BOTDATETIME ON BOTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,CIF,CONCAT(InteractionDate,InteractionTime) AS DurEndDateTime,substring(InteractionText ,locate(':',InteractionText)+1,500) AS CHATENDREASON 
				FROM GBL_InteractionHistory WHERE ID IN ( SELECT  MAX(ID) as ID from GBL_InteractionHistory   
				WHERE `Channel` IN ('AudioChat','VideoChat','Chat','TextChat')  AND (InteractionText like '_RemoteEndDisconnected%'  OR InteractionText like '_RemoteEndClosed%' OR InteractionText like '_Agent-EndTextChat%')
				AND ((InsertedBy <> 'ChatBot') AND (InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot'))) 
				GROUP BY SessionID) GROUP BY SessionID,InteractionDate,InteractionTime,InteractionText,CIF
		
			) 
			INTDURTIME ON INTDURTIME.SessionID = H.SessionID 
			LEFT JOIN 
			(	
				 Select SessionId, COUNT(1) as CallbackCount FROM IVR_Callback_Requests R 
				 JOIN TMAC_Interactions C on C.SubSessionId  = R.UCID 
				 GROUP By SessionId
			) 
			TabCallback on TabCallback.SessionId = H.SessionID 
			INNER JOIN
			(
			  SELECT  min(ID) as ID,SessionID from GBL_InteractionHistory WHERE `Channel` IN ('AudioChat','VideoChat','Chat','TextChat')
			  GROUP BY SessionID
			)
			HID ON HID.SessionID = H.SessionID AND HID.ID=H.ID
			WHERE IsTransfered=0 AND IsConferenced=0  AND H.`Channel` IN ('AudioChat','VideoChat','Chat','TextChat') 
			AND I.ClosedDateTime >= v_DataFromDate AND I.ClosedDateTime <= v_DataToDate
			AND I.CreatedDateTime in ( SELECT  min(CreatedDateTime) as id from TMAC_Interactions   
			WHERE (`Channel` IN ('AudioChat','VideoChat') OR SubChannel IN ('Audio','Video')) 
			AND CALLCONNECTEDTIME != '00010101000000' 
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			GROUP BY SessionId)
			GROUP BY H.SessionID, I.SubSessionId, I.Intent, TabCallback.CallbackCount, CustomData, CHAT.AGENTWAITTIME, CHAT.USERWAITTIME,
			QueueTime, StartDateTime, EndDateTime, BOTDATETIME.ChatBotStartDateTime, BOTDATETIME.ChatBotEndDateTime, U.CIF, INTDURTIME.CIF, ISCHATTRANSFERED, 
			ISCHATCONFERENCED, H.ID, I.AgentId, INTDURTIME.DurEndDateTime, I.SubChannel, INTDURTIME.CHATENDREASON, I.OtherData, S.SkillName, I.Skill;
	END IF;	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CallbackDetailReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CallbackDetailReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
		select TCamp.`Channel`,TCon.PhoneNumber PreferredCallbackContact,TRec.RequestedDateTime as RequestDateTime, 
		timestampdiff(SECOND,VARCHARTODATETIME(TRec.DialDateTime),VARCHARTODATETIME(TRec.RequestedDateTime)) as CallerQueueWaitTime,
		TRec.DialDateTime as AgentDialDateTime, 
		TCon.ScheduleTime as CallBackDate,TRec.`Status` as StatusOfCallback
		from TCM_Contact TCon
		left join TCM_Campaign TCamp on TCon.CampID = TCamp.ID
		left join TCM_Record TRec on TCon.ID = TRec.ContactId 
		where DATE_FORMAT(TCon.ScheduleTime,'%T') >=DATE_FORMAT(v_DataFromDate,'%T') and DATE_FORMAT(TCon.ScheduleTime,'%T') <= DATE_FORMAT(v_DataToDate,'%T');
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CallBackScheduleReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CallBackScheduleReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate =  CONVERT(INSERT(INSERT(INSERT(REPLACE(p_FromDate,' ',''),13,0,':'),11,0,':'),9,0,' '), DATETIME);    
	SET v_DataToDate = CONVERT(INSERT(INSERT(INSERT(REPLACE(p_ToDate,' ',''),13,0,':'),11,0,':'),9,0,' '), DATETIME);  

	IF(p_Type = 'MAIN')
	THEN
			SELECT
				CB.AgentID,
				CONCAT(IFNULL(A.FirstName,'') ,' ', IFNULL(A.LastName,'')) AS AgentName,
				CB.CampaignID,
				CB.CampaignName,
				CB.ContactID,
				CB.ContactListName,
				CB.CallBackStatus,
				CB.CallBackType,
				CB.PhoneNumber,
				CB.ScheduledStartDateTime as StartDateTime,
				CB.ScheduledEndDateTime as EndDateTime,
				CB.NextAttemptDateTime as AttemptDateTime
			 FROM CallBackData CB 
			 JOIN `AGT_Agent` A on A.AvayaLoginID= CB.AgentID
			 WHERE CB.ScheduledEndDateTime>=v_DataFromDate AND CB.ScheduledEndDateTime<=v_DataToDate;
	END IF;	
END;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CallTraceReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CallTraceReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_MAIN LONGTEXT;
DECLARE	v_OTP_VERFIFIED_COLNAME VARCHAR(100);

DECLARE v_SQLCommand longtext;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
	SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';

		#BEGIN TRY
		IF EXISTS(SELECT 1 FROM Information_schema.COLUMNS WHERE TABLE_NAME = 'IVR_Call_History' AND COLUMN_NAME = 'OTP_VERFIFIED') 
		then
		   set v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';
		ELSE 
			SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERIFIED';
		END IF;			
	   #END TRY;
		#BEGIN CATCH
			#SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED'; 
		#END CATCH;
	

	IF(p_Type = 'MAIN')
	THEN
 				SET v_SQLCommand = CONCAT('SELECT ICH_CALLREFID AS UCID, 
											  ICH_DNIS As HotlineNumber,
											  concat(ICH_END_DATE , replace(ICH_END_TIME,'':'', '''')) AS EndDateTime,
											  ICH_CLID AS CallerID,
											  ICH_CALL_DUR AS Duration,
											  EMP_NAME AS Name,
											  ',v_OTP_VERFIFIED_COLNAME,' AS OTPVerified,
											  PHONE_CODE AS UID, 
											  concat(ICH_START_DATE , replace(ICH_START_TIME,'':'', '''')) AS StartDateTime,
											  TPIN_VERIFIED AS CallerStatus,
											  TPIN_VERIFIED AS TpinVerified,
											  NRIC AS CIN,
											  NRIC AS MembershipID,
											  LASTMENU_1 AS Lastmenu1,
											  LASTMENU_2 AS Lastmenu2,
											  LASTMENU_3 AS Lastmenu3,
											  LASTMENU_4 AS Lastmenu4,
											  CIF AS CIF,
											  CUSTOMER_SEGMENT AS Segment,
											  ICH_TR_DIS_FLAG AS TransferredFlag,
											  TRANSFER_VDN AS TransferVDN,
											  TRANSFER_VDN AS Intent,
											  IU_LANGUAGE AS `Language`,
											  CASE WHEN LOCATE(''tpin'', Lower(TRANSFER_VDN)) > 0 THEN ''Yes'' ELSE ''No'' END AS TpinTransfered,
											  CASE WHEN LOCATE(''feewaiver'', Lower(TRANSFER_VDN)) > 0 THEN ''Yes'' ELSE ''No'' END AS TransferredToFeewaiver, 
											  CASE WHEN SMSReport.UCID IS NULL THEN ''No'' ELSE ''Yes'' END AS SMSEligibility,
											  CASE WHEN VD.VDN_NAME IS NULL THEN '''' ELSE VD.VDN_NAME END AS VDNName 
									FROM IVR_Call_History ');
			IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'VDN_DETAILS') 
				THEN
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN VDN_DETAILS VD ON FIND_IN_SET(VD.VDN_No,IVR_Call_History.TRANSFER_VDN)>0');
			ELSE
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT '''' VDN_NAME,'''' VDN_No) VD ON FIND_IN_SET(VD.VDN_No,IVR_Call_History.TRANSFER_VDN)>0');
			END IF;

			IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'SMSReport')
				THEN
					SET v_SQLCommand = CONCAT(v_SQLCommand , ' LEFT JOIN  (SELECT  DISTINCT UCID FROM SMSReport GROUP BY UCID) SMSReport  ON SMSReport.UCID =IVR_Call_History.ICH_CALLREFID WHERE 1=1');
					
					SET v_MAIN=CONCAT(v_SQLCommand  ,' AND ((concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) >= ''',v_DataFromDate,''' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) <= ''',v_DataToDate,''')');
			ELSE
					SET v_SQLCommand = CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT ''0'' UCID ) SMSReport ON SMSReport.UCID =IVR_Call_History.ICH_CALLREFID WHERE 1=1');
				
					SET v_MAIN=CONCAT(v_SQLCommand  ,' AND ((concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) >= ''',v_DataFromDate,''' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) <= ''',v_DataToDate,''')');
				 
			END IF;
	END IF;
	SET @stmt_str = v_MAIN;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CallTransferReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CallTransferReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
DECLARE v_SQLCommand LONGTEXT;

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'MAIN')
	THEN
 		SET v_SQLCommand ='SELECT  IVR_Call_History.ICH_CALLREFID AS UCID,
					IVR_Call_History.CIF,
					IVR_Call_History.ICH_CLID AS CallerID, 
					IVR_Call_History.LASTMENU_1 AS LastMenu, 
					IVR_Call_History.LASTMENU_2 AS LastMenu1, 
					IVR_Call_History.LASTMENU_3 AS LastMenu2,
					IVR_Call_History.LASTMENU_4 AS LastMenu3,
					IVR_Call_History.ICH_DNIS AS HotlineNumber, 
					IVR_Call_History.NRIC AS CIN,
					IVR_Call_History.TRANSFER_VDN as TransferredVdn, 
					IVR_Call_History.PHONE_CODE AS UserID, 
					CONCAT(ICH_START_DATE,replace(ICH_START_TIME, '':'','''')) as StartDateTime,
					CONCAT(ICH_END_DATE,replace(ICH_END_TIME, '':'','''')) as EndDateTime,
					IVR_Call_Active.AccountNumber AS CreditorDebitCardNumber,
					CASE WHEN VD.VDN_NAME IS NULL THEN '''' ELSE VD.VDN_NAME END AS VDNName
			FROM IVR_Call_History   
			INNER JOIN IVR_Call_Active on IVR_Call_History.ICH_CALLREFID=IVR_Call_Active.UCID ';

			IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'VDN_DETAILS') 
				THEN
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN VDN_DETAILS VD ON FIND_IN_SET(VD.VDN_No,IVR_Call_History.TRANSFER_VDN)>0');
			ELSE
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT '''' VDN_NAME,'''' VDN_No) VD on FIND_IN_SET(VD.VDN_No, IVR_Call_History.TRANSFER_VDN)>0');
				END IF;

			SET v_SQLCommand=CONCAT(v_SQLCommand , ' where 1=1 AND CONCAT(ICH_END_DATE,replace(ICH_END_TIME,'':'',''''))>=''',v_DataFromDate,''' AND CONCAT(ICH_END_DATE,replace(ICH_END_TIME,'':'',''''))<=''',v_DataToDate,'''');
	
	SET @stmt_str = v_SQLCommand;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CampaignCallbackTimeoutReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CampaignCallbackTimeoutReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_OrgUnit varchar(8000))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = p_FromDate;
	SET v_DataToDate = p_ToDate;
	
	IF(p_Type = 'MAIN')
	THEN
			
			select distinct TCon.`Name`, TCamp.Channel,FORMATDATETIME(VARCHARTODATETIME(IFNULL(TCon.ScheduleTime,'')),'dd/MM/yyyy HH:mm:ss') CallBackDateTime,
			TCon.DirectAgent as CallbackAgentID,TRec.PhoneNumber as CallbackContactNumber,TCon.NRIC,
			SEC_TO_TIME(timestampdiff(SECOND,VARCHARTODATETIME(IFNULL(TRec.DialDatetime,'')),VARCHARTODATETIME(IFNULL(TRec.QueueConnectedDateTime,''))))
			as CallbackWaitTime,
			ifnull(TotSMSSent.TotalSMSSent,0) as NoofSMSSent, IFNULL(NotificationChannel,'') as NotificationChannel,
			(case when FIND_IN_SET('dacrequesttimeout' ,TRec.STATUS) then 'DacRequestTimeout' else 'QueueTimeout' end) as TimedoutReason,
			Age, Gender, TCon.Email, Country, CallType, RefNumber, SubReferNumber, RefType,
			CONCAT(FirstName , ' ' , LastName) AgentName, AGT.TeamName, 
			FORMATDATETIME(VARCHARTODATETIME(IFNULL(ActionTime,'')),'dd/MM/yyyy HH:mm:ss') as TimeoutDatetime
			from TCM_Contact TCon left join TCM_Campaign TCamp on TCamp.ID=TCon.CampID
			left join TCM_Record TRec on TRec.ContactId= TCon.ID
			left join (
			select count(1) as TotalSMSSent,ContactId,'SMS' AS NotificationChannel from TCM_SMS_History where lower(ltrim(rtrim(status)))='success' group by ContactId
			)TotSMSSent on TotSMSSent.ContactId = TCon.ID
			inner join AGT_Agent AG on AG.AvayaLoginID = TCon.DirectAgent
			left join AGT_Teams AGT on AG.TeamID = AGT.TeamID
			left join TCM_Contact_Actions TAction on TCon.ID = TAction.ContactId and action in ('dacrequesttimeout','QueueTimeout') AND TAction.RecordId = TRec.Id
			WHERE DATE_FORMAT(IFNULL(TCon.ScheduleTime,''),'%Y-%m-%d %H:%i:%s') >= v_DataFromDate and 
			DATE_FORMAT(IFNULL(TCon.ScheduleTime,''),'%Y-%m-%d %H:%i:%s')  <= v_DataToDate AND 
			(FIND_IN_SET('dacrequesttimeout' ,TRec.STATUS) or FIND_IN_SET('queuetimeout' ,TRec.STATUS)) and TCamp.IsDirectAgent = 1 AND
			TCamp.ID IN (SELECT campaignid FROM tcm_campaign_teamlist TL WHERE FIND_IN_SET(teamid,p_OrgUnit));
			
			
			END IF;
			END;
	END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CampaignDailyCallbackSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CampaignDailyCallbackSummaryReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_OrgUnit TEXT)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = p_FromDate;
	SET v_DataToDate = p_ToDate;
	
	IF(p_Type = 'MAIN')
	THEN
		
		select T.`Name` as CampaignName, T.`Type` CampaignType,T.TeamName CampaignTeamName,T.`Channel`,T.CallBackDate,
			T.TotalCallbackScheduled,T.TotalCallbackAttempted,T.TotalSuccessfulCallback,
			T.TotalRejectedCalls,T.TotalMissedCalls, T.TotalDeclineCalls, T.TotalCallbackCalls, T.TotalTimedoutCallback, T.TotalExceptionCallback from 
			(SELECT TCamp.`Name`, `Type`, AGT.TeamName, `CHANNEL`, FORMATDATETIME(VARCHARTODATETIME(IFNULL(TCon.ScheduleTime,'')),'dd/MM/yyyy') AS CallBackDate,
			Count(TCon.ID) as TotalCallbackScheduled, ifnull(TotCBAtmp.TotalCallbackAttemped,0) TotalCallbackAttempted,
			ifnull(TotSucesCB.TotalSuccessfulCallback,0) TotalSuccessfulCallback,
			ifnull(TotalRejectedCalls,0) as TotalRejectedCalls, 
			ifnull(TotalMissedCalls,0) TotalMissedCalls,
			ifnull(TotalDeclineCalls,0) TotalDeclineCalls,
			ifnull(TotalCallbackCalls,0) as TotalCallbackCalls, 
			ifnull(TotalTimedoutCallback,0) TotalTimedoutCallback, 
			ifnull(TotalExceptionCallback,0) TotalExceptionCallback
		FROM TCM_Contact TCon
		LEFT JOIN TCM_Campaign TCamp ON TCon.CampId = TCamp.ID
		LEFT JOIN AGT_Teams AGT on TCamp.TeamId =  AGT.TeamID
		LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalCallbackAttemped, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(Con.Status))) not in ('open','deleted')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotCBAtmp ON TotCBAtmp.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalSuccessfulCallback, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(StatusCode))) in ('success')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotSucesCB ON TotSucesCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalRejectedCalls, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(StatusCode))) in ('rejected')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotRejCB ON TotRejCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalMissedCalls, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(StatusCode))) in ('missed_call')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotMissCB ON TotMissCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalDeclineCalls, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(StatusCode))) in ('decline')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotDeclineCB ON TotDeclineCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalCallbackCalls, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where IsCallback = 1 And Lower(ltrim(rtrim(StatusCode))) in ('callback')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotCallCB ON TotCallCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalTimedoutCallback, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID WHERE (FIND_IN_SET('dacrequesttimeout' ,Rec.STATUS) or FIND_IN_SET('queuetimeout' ,Rec.STATUS)) 
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotTimeOutCB ON TotTimeOutCB.CampId = TCamp.ID
			LEFT JOIN(
				SELECT COUNT(Rec.ID) TotalExceptionCallback, Rec.CampId FROM TCM_Record Rec 
				LEFT JOIN TCM_Contact Con ON Rec.ContactID=Con.ID where Lower(ltrim(rtrim(StatusCode))) in ('error','exception')
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate
				and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <=  v_DataToDate 
				GROUP BY Rec.CampId
				) TotExCB ON TotExCB.CampId = TCamp.ID
				where FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') >= v_DataFromDate and FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'yyyy-MM-dd HH:mm:ss') <= v_DataToDate AND
				TCamp.ID IN (SELECT campaignid FROM tcm_campaign_teamlist TL WHERE FIND_IN_SET(teamid,p_OrgUnit))
				group by TCamp.`Name`,`Type`,TCamp.Channel,AGT.TeamName,TotalCallbackAttemped,TotalSuccessfulCallback,TotalRejectedCalls, TotalMissedCalls, TotalDeclineCalls, 
				TotalCallbackCalls, TotalTimedoutCallback, TotalExceptionCallback, 
				FORMATDATETIME(VARCHARTODATETIME(ifnull(ScheduleTime,'')),'dd/MM/yyyy')
				) T 
				group by T.`Name`, T.`Type`,T.TeamName, T.Channel,T.CallBackDate, T.TotalCallbackScheduled,T.TotalCallbackAttempted,T.TotalSuccessfulCallback,T.TotalRejectedCalls,T.TotalMissedCalls,
				T.TotalDeclineCalls, T.TotalCallbackCalls, T.TotalTimedoutCallback, T.TotalExceptionCallback;

	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatAnalysisCount_Report
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatAnalysisCount_Report`(
   p_Type VARCHAR(50),
	p_StartDate VARCHAR(50),
	p_EndDate VARCHAR(50)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = REPLACE(p_StartDate,' ','');
	SET v_DataToDate = REPLACE(p_EndDate,' ','');
	
  IF p_Type='MAIN'
   THEN
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    SELECT MAX(TabAccessCount.MENU_NAME) as Menu, 
			TabAccessCount.SUM_II AS InvalidInput,
			TabAccessCount.SUM_NI AS NoInput,
			 '' as `Language`,
			IFNULL(TabAccessCount.Cnt,0) AS AccessCount, 
			TabAccessCount.Max_Tries AS MaxTries,
			IFNULL(TabAgentTranfer.Cnt,0) as AgentTransfers,
			IFNULL(TabChatDisconnect.Cnt,0) as ChatDisconnects,
			TabAccessCount.EndDateTime,
			TabAccessCount.SessionID,
			TabAccessCount.MenuID,
			TabAccessCount.MenuOrder
	FROM  (
			SELECT distinct Chat_Menu_Desc.MENU_NAME,SUM(CAST(Chat_Usage.EII AS UNSIGNED)) as SUM_II , SUM(CAST(Chat_Usage.ENI AS UNSIGNED)) AS SUM_NI,
			SUM(CAST(Chat_Usage.EMC AS UNSIGNED)) AS Max_Tries, COUNT(1) AS Cnt,
			ENDDATETIME as EndDateTime,
			Chat_Usage.SessionID as SessionID,Chat_Menu_Desc.MENU_ID as MenuID,Chat_Usage.`ORDER` as MenuOrder
			FROM Chat_Usage 
			INNER JOIN Chat_Menu_Desc ON Chat_Usage.ID = Chat_Menu_Desc.MENU_ID
			INNER JOIN Chat_Call_History ON Chat_Usage.SessionID=Chat_Call_History.SessionID
			WHERE ENDDATETIME >= v_DataFromDate and ENDDATETIME <= v_DataToDate and TR_DIS_FLAG in ('AT','DC')
			GROUP BY Chat_Usage.SessionID,ENDDATETIME,Chat_Menu_Desc.MENU_NAME,Chat_Menu_Desc.MENU_ID,Chat_Usage.`ORDER`

	) as TabAccessCount
	LEFT JOIN (	
    SELECT Chat_Menu_Desc.MENU_NAME, COUNT(1) AS Cnt ,Chat_Call_History.SessionID
    FROM Chat_Call_History  
	INNER JOIN Chat_Menu_Desc ON Chat_Call_History.LAST_MENU_ID = Chat_Menu_Desc.MENU_NAME
    WHERE ENDDATETIME >= v_DataFromDate and ENDDATETIME <= v_DataToDate AND 
	(Chat_Call_History.TR_DIS_FLAG = 'AT' OR Chat_Call_History.TR_DIS_FLAG = 'AF') 
    GROUP BY Chat_Call_History.SessionID,Chat_Menu_Desc.MENU_NAME

	) as TabAgentTranfer on TabAgentTranfer.MENU_NAME = TabAccessCount.MENU_NAME and TabAgentTranfer.SessionID = TabAccessCount.SessionID
	LEFT JOIN (
       SELECT Chat_Menu_Desc.MENU_NAME , COUNT(1) AS Cnt ,Chat_Call_History.SessionID
       FROM Chat_Call_History  
	   INNER JOIN Chat_Menu_Desc ON Chat_Call_History.LAST_MENU_ID = Chat_Menu_Desc.MENU_NAME
       WHERE 
	   ENDDATETIME >= v_DataFromDate and ENDDATETIME <= v_DataToDate AND 
	   (Chat_Call_History.TR_DIS_FLAG = 'DC') 
       GROUP BY Chat_Call_History.SessionID,Chat_Menu_Desc.MENU_NAME
	) as TabChatDisconnect on TabChatDisconnect.MENU_NAME = TabAccessCount.MENU_NAME and TabChatDisconnect.SessionID = TabAccessCount.SessionID
	GROUP BY TabAccessCount.EndDateTime, TabAccessCount.MENU_NAME,TabAccessCount.SUM_II,TabAccessCount.SUM_NI,TabAccessCount.Max_Tries,TabAccessCount.Cnt,TabAgentTranfer.Cnt,TabChatDisconnect.Cnt
	,TabAccessCount.SessionID,TabAccessCount.MenuID,TabAccessCount.MenuOrder;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
	END IF;
 END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatbotInteractionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatbotInteractionReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'main')
	THEN
			SELECT DISTINCT H.SESSIONID, I.SubSessionId as GroupID, H.ID, CASE WHEN ifnull(U.NRIC,'')='' THEN INTDURTIME.NRIC ELSE U.NRIC END AS IDENTIFICATION,
			ChatBotStartDateTime,ChatBotEndDateTime,INTDATETIME.StartDateTime,INTDATETIME.EndDateTime,I.Intent INTENTNAME,
			(CASE WHEN IFNULL(S.SkillName,'')='' THEN IFNULL(I.Skill,'') ELSE IFNULL(S.SkillName,'') END) as SKILL,
			(CASE WHEN (Ifnull(TabCallback.CallbackCount,0))=0 THEN 'No' ELSE 'Yes' END) AS CALLBACK, 
			ifnull(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(CASE WHEN ChatBotStartDateTime IS NULL THEN INTDATETIME.StartDateTime ELSE ChatBotStartDateTime END),
			VARCHARTODATETIME(CASE WHEN ChatBotEndDateTime IS NULL THEN INTDATETIME.EndDateTime ELSE ChatBotEndDateTime END )),0) AS DURATIONTIME,
			ISCHATTRANSFERED,ISCHATCONFERENCED,  I.AgentId AS AGENTID,OtherData as OTHERDATA,Ifnull(CHAT.QueueTime,0) AS QUEUEWAITTIME,
			AGENTWAITTIME,USERWAITTIME, I.SubChannel AS `CHANNEL`, INTDURTIME.CHATENDREASON
			FROM GBL_InteractionHistory H 
			LEFT JOIN TMAC_Interactions I ON I.SessionId= H.SessionID
			LEFT JOIN TMAC_InteractionUserData U ON U.SessionID= H.SessionID
			LEFT JOIN TMAC_Skills S on S.SkillExtension=I.Skill
			LEFT JOIN
			(
				SELECT SessionId, ifnull(sum(IsTransfered),0) AS ISCHATTRANSFERED,ifnull(sum(IsConferenced),0) AS ISCHATCONFERENCED, 
				ifnull(sum(AgentWaitTimeForResponse),0) as AGENTWAITTIME , ifnull(sum(UserWaitTimeForResponse),0) as USERWAITTIME, 
				ifnull(sum(QueueTime),0) QueueTime from TMAC_Interactions  
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SessionId
			) 
			CHAT ON CHAT.SessionId=H.SessionID 
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS StartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS EndDateTime FROM GBL_InteractionHistory 
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') AND 
				InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
			    AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)	  
				GROUP BY SessionID
			) 
			INTDATETIME ON INTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS ChatBotStartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS ChatBotEndDateTime FROM GBL_InteractionHistory  
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') AND 
				InsertedBy IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
			    AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
				GROUP BY SessionID
			) 
			BOTDATETIME ON BOTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,NRIC,CONCAT(InteractionDate,InteractionTime) AS DurEndDateTime,substring(InteractionText ,locate(':',InteractionText)+1,500) AS CHATENDREASON 
				FROM GBL_InteractionHistory WHERE ID IN ( SELECT  MAX(ID) as ID from GBL_InteractionHistory   
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat')  
				AND (InteractionText like '_RemoteEndDisconnected%'  OR InteractionText like '_RemoteEndClosed%' OR InteractionText like '_Agent-EndTextChat%')
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
			    AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SessionId)
				GROUP BY SessionID) GROUP BY SessionID,InteractionDate,InteractionTime,InteractionText,NRIC
			) 
			INTDURTIME ON INTDURTIME.SessionID = H.SessionID 	
			LEFT JOIN 
			(	
					Select SessionId, COUNT(1) as CallbackCount FROM IVR_Callback_Requests R 
					JOIN TMAC_Interactions C on C.SubSessionId = R.UCID AND C.ClosedDateTime >= v_DataFromDate AND C.ClosedDateTime <= v_DataToDate 
					GROUP By SessionId
			)
			TabCallback on TabCallback.SessionId = H.GroupID 
			INNER JOIN
			(
				SELECT  min(ID) as ID,SessionID from GBL_InteractionHistory  WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat')
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
			    AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
				GROUP BY SessionID
			)
			HID ON HID.SessionID = H.SessionID AND HID.ID=H.ID
			WHERE IsTransfered=0 AND IsConferenced=0  AND (H.`Channel`='Chat' or H.`Channel`='TextChat' OR H.`Channel`='AudioChat' OR H.`Channel`='VideoChat') 	
			AND I.ClosedDateTime >= v_DataFromDate AND I.ClosedDateTime <= v_DataToDate
			AND I.CreatedDateTime in ( SELECT  min(CreatedDateTime) as id from TMAC_Interactions   
			WHERE  (`Channel`='Chat' OR `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') 
			AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate  GROUP BY SessionId) 
			GROUP BY H.SessionID, I.SubSessionId, I.Intent,TabCallback.CallbackCount,CustomData,CHAT.AGENTWAITTIME,CHAT.USERWAITTIME,
			CHAT.QueueTime,StartDateTime,EndDateTime,ChatBotStartDateTime,ChatBotEndDateTime, U.NRIC, INTDURTIME.NRIC,ISCHATTRANSFERED,ISCHATCONFERENCED,H.ID,
			I.AgentId,INTDURTIME.DurEndDateTime,I.SubChannel,INTDURTIME.CHATENDREASON,I.OtherData,S.SkillName,I.Skill;
		
	ELSEIF ( p_Type='chattransscript')	
	THEN 
			SELECT Distinct IH.SESSIONID, T.SubSessionId as GroupID, InteractionText, CONCAT(InteractionDate,InteractionTime) as INTERACTIONDATETIME,IH.Direction, 
			Concat('- ', AGT_Agent.FirstName , AGT_Agent.LastName)  as SERVICEDBY,(CASE WHEN upper(IH.Direction)='OUT' THEN 
			AGT_Agent.FirstName ELSE CASE WHEN I.UserName IS NULL OR I.UserName ='' THEN 'Customer' ELSE I.UserName END END) as FIRSTNAME,
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.LastName ELSE '' END) as LASTNAME,IH.ID
			FROM GBL_InteractionHistory IH  
			LEFT JOIN AGT_Agent ON AGT_Agent.AvayaLoginID = IH.InsertedBy 
			LEFT JOIN TMAC_Interactions T ON IH.SessionID=T.SessionId 
			LEFT JOIN
			( 
			  SELECT distinct SessionId,UserName  FROM TMAC_Interactions  
			  WHERE UserName IS NOT NULL OR UserName <>''  GROUP BY SessionId,UserName
			) I ON IH.SessionID=I.SessionId 
			WHERE IH.`Channel` in ('Chat','TextChat','AudioChat','VideoChat') AND  ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			order by ID ASC;
	ELSEIF ( p_Type='chatcallback')	
	THEN
			DROP TEMPORARY TABLE IF EXISTS CALLBACKTABLE;
			CREATE TEMPORARY TABLE CALLBACKTABLE (SESSIONID VARCHAR(50),UCID VARCHAR(50), CALLBACKSTATUS VARCHAR(10),CALLBACKDATE VARCHAR(10),CALLBACKTIME VARCHAR(10),CALLBACKCOUNT INT);
			INSERT INTO CALLBACKTABLE
			Select C.SessionID ,R.UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME, COUNT(1) as CALLBACKCOUNT FROM IVR_Callback_Requests R
			INNER JOIN GBL_Interaction_CustomData C on C.`Value` = R.UCID AND C.`Name`='ChatToCallback' AND 
			CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) >= v_DataFromDate and CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) <= v_DataToDate 
			GROUP By C.SessionID , UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME;
	
			SELECT SESSIONID,UCID,CALLBACKSTATUS,CALLBACKDATE,CALLBACKTIME,CALLBACKCOUNT FROM CALLBACKTABLE;
	END IF;	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatCSQAgentSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatCSQAgentSummaryReport`(
 p_FromDate VARCHAR(20),
 p_ToDate VARCHAR(20)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');

		DROP TEMPORARY TABLE IF EXISTS InteractionTable;
		CREATE TEMPORARY TABLE InteractionTable (ItemId VARCHAR(100),AgentID VARCHAR(50),`Date` VARCHAR(20));
		
		INSERT INTO InteractionTable
		SELECT SessionId AS ItemId, AgentId as AgentID, ClosedDateTime AS `Date` 
		FROM TMAC_Interactions 
		WHERE ClosedDateTime>=v_DataFromDate AND ClosedDateTime<=v_DataToDate AND Channel IN ('Chat','TextChat');
	
		SELECT WorkQueueHistory.AgentID,AgentName,
			Skill AS CSQID,
			SkillName AS CSQName,
			IFNULL(SUM(QueueTime),0) AS QueueTime,
			IFNULL(SUM(HandledTime),0) AS HandledTime,
			IFNULL(MIN(ChatPresented),0) AS ChatPresented, 
			IFNULL(COUNT(SessionId),0) AS ChatHandled,
			IFNULL(SUM(ActiveTime),0) AS ActiveTime,
			IFNULL(SUM(AgentWaitTimeForResponse),0) AS AcceptTime,
			IFNULL(MIN(ChatAbandoned),0) AS ChatAbandoned,
			WorkQueueHistory.`Date` AS `Date`
		FROM
		(
			SELECT SUM(ChatPresented) AS ChatPresented,SUM(ChatAbandoned) AS ChatAbandoned, AgentID, AgentName,`Date`
			FROM 
			(
				(
					SELECT COUNT(ItemID) AS ChatPresented,COUNT(ItemID) AS ChatAbandoned,AgentID,
					(CONCAT(FirstName,' ',LastName)) AS AgentName, concat(RouteDate,RouteTime) AS `Date` 
					FROM TMAC_WorkQueueHistory TW INNER JOIN AGT_Agent AA ON TW.AgentID=AA.AvayaLoginID
					WHERE concat(RouteDate,RouteTime)>=v_DataFromDate and concat(RouteDate,RouteTime)<=v_DataToDate AND 
					Channel IN ('Chat','TextChat') and Reason IN('TimedOut','QueueTimedOut')
					GROUP BY AgentID,FirstName,LastName,RouteDate, RouteTime
				) 
				UNION ALL
				(
					SELECT  Count(DISTINCT TW.ItemID) AS ChatPresented,0 AS ChatAbandoned,TW.AgentID,
					(CONCAT(FirstName,' ',LastName)) AS AgentName,`Date`
					FROM TMAC_WorkQueueHistory TW INNER JOIN InteractionTable TI ON TW.ItemID=TI.ItemId AND TW.AgentID = TI.AgentID
					INNER JOIN AGT_Agent AA ON TW.AgentID=AA.AvayaLoginID 
					GROUP BY TW.AgentID,FirstName,LastName,`Date`
				)	
			)A
			GROUP BY AgentID,AgentName,`Date`
		) WorkQueueHistory
		LEFT JOIN
		(
			SELECT SessionId,
				Skill,
				SkillName,
				ActiveTime, 
				AgentId,
				ActiveTime+HoldTime HandledTime,
				QueueTime ,
				ActiveTime ActiveChatTime,
				AgentWaitTimeForResponse,
			ClosedDateTime AS `Date` 
			FROM TMAC_Interactions TW
			JOIN TMAC_Skills TS ON TS.SkillExtension = TW.Skill
			WHERE ClosedDateTime>=v_DataFromDate and ClosedDateTime<=v_DataToDate AND 
			Channel IN ('Chat','TextChat')
		) Tmacinteraction
		ON WorkQueueHistory.AgentID=Tmacinteraction.AgentId and WorkQueueHistory.`Date`=Tmacinteraction.`Date`
		GROUP BY WorkQueueHistory.AgentID,AgentName,WorkQueueHistory.`Date`,Skill,SkillName;

END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatHostTransactionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatHostTransactionReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
			SELECT 
					Chat_Call_History.SessionID AS SessionID,
					SUBSTRING(REPLACE(REPLACE(REPLACE(DATE_FORMAT(Chat_TRL.REQUEST_DATE,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),0,15) AS RequestDateTime,
					Chat_Call_History.NRIC AS CIN,
					Chat_TRL.TRANSACTION_NAME AS TransactionName,
					CASE WHEN (CHAT_TRL.MENU_DESCRIPTION is null) THEN CHAT_TRL.TRANSACTION_NAME ELSE CHAT_TRL.MENU_DESCRIPTION END AS MenuDescription,
					Chat_TRL.REQ_MESSAGE AS RequestMessage,
					Chat_TRL.RES_MESSAGE AS ResponseMessage,
					Chat_Call_History.DNIS AS HotlineNumber,
					Chat_Call_History.PHONE_CODE AS PhoneCode,
					Chat_Call_History.CIF,					
					Chat_Call_History.CUSTOMER_SEGMENT AS CustomerSegment,   
				    DATE_FORMAT(((SELECT(STR_TO_DATE(Chat_TRL.RESPONSE_DATE,108)))-(SELECT(STR_TO_DATE(Chat_TRL.REQUEST_DATE,108)))),114) AS ResponseTime,			
				    ENDDATETIME AS EndDateTime
			 		FROM  Chat_TRL INNER JOIN Chat_Call_History ON Chat_Call_History.SessionID=Chat_TRL.SessionID
             WHERE 1=1 AND ENDDATETIME>=v_DataFromDate AND ENDDATETIME<=v_DataToDate;
			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
		END;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatInteractionChatBotReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatInteractionChatBotReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'main')
	THEN
			SELECT DISTINCT  H.SessionID, I.SubSessionId as GroupID, H.ID, CASE WHEN ifnull(U.CIF,'')='' THEN INTDURTIME.CIF ELSE U.CIF END AS IDENTIFICATION, 
			INTDATETIME.StartDateTime,INTDATETIME.EndDateTime,
			CASE WHEN ChatBotStartDateTime IS NULL THEN INTDATETIME.StartDateTime ELSE ChatBotStartDateTime END ChatBotStartDateTime,
			CASE WHEN ChatBotEndDateTime IS NULL THEN INTDATETIME.EndDateTime ELSE ChatBotEndDateTime END ChatBotEndDateTime,I.Intent INTENTNAME,
			(CASE WHEN IFNULL(S.SkillName,'')='' THEN IFNULL(I.Skill,'') ELSE IFNULL(S.SkillName,'') END) as Skill,
			(CASE WHEN (Ifnull(TabCallback.CallbackCount,0))=0 THEN 'No' ELSE 'Yes' END) AS CALLBACK, 
			ifnull((TIMESTAMPDIFF(SECOND,convert(insert(insert(insert(INTDATETIME.StartDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
			convert(insert(insert(insert(INTDURTIME.DurEndDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))),0) AS DURATIONTIME,
			ISCHATTRANSFERED,ISCHATCONFERENCED,  I.AgentId AS AGENTID,OtherData as OTHERDATA,Ifnull(QueueTime,0) AS QUEUEWAITTIME,
			AGENTWAITTIME,USERWAITTIME, CASE WHEN I.SubChannel IS NULL THEN H.`Channel` ELSE I.SubChannel END AS `CHANNEL`, INTDURTIME.CHATENDREASON
			FROM GBL_InteractionHistory H 
			LEFT JOIN TMAC_Interactions I ON I.SessionId= H.SessionID
			LEFT JOIN TMAC_InteractionUserData U ON U.SessionId= H.SessionID
			-- to get skill name
			LEFT JOIN TMAC_Skills S on S.SkillExtension=I.Skill
			LEFT JOIN
			(
				SELECT SessionId, ifnull(sum(IsTransfered),0) AS ISCHATTRANSFERED,ifnull(sum(IsConferenced),0) AS ISCHATCONFERENCED, 
				ifnull(sum(AgentWaitTimeForResponse),0) as AGENTWAITTIME , ifnull(sum(UserWaitTimeForResponse),0) as USERWAITTIME from TMAC_Interactions 
			  	WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') 
			  	AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate 
			  	GROUP BY SessionId
			) CHAT ON CHAT.SessionId=H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS StartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS EndDateTime FROM GBL_InteractionHistory 
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') 
				AND ((InsertedBy <> 'ChatBot') AND (InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot'))) 
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
				AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
				GROUP BY SessionID
			) INTDATETIME ON INTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS ChatBotStartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS ChatBotEndDateTime FROM GBL_InteractionHistory  
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') 
				AND ((InsertedBy = 'ChatBot') OR (InsertedBy IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')))  
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
				AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
				GROUP BY SessionID
			) BOTDATETIME ON BOTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,CIF,CONCAT(InteractionDate,InteractionTime) AS DurEndDateTime,substring(InteractionText ,locate(':',InteractionText)+1,500) AS CHATENDREASON 
				FROM GBL_InteractionHistory WHERE ID IN ( SELECT  MAX(ID) as ID from GBL_InteractionHistory   
				WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat')  AND (InteractionText like '_RemoteEndDisconnected%'  OR InteractionText like '_RemoteEndClosed%' OR InteractionText like '_Agent-EndTextChat%')
				AND ((InsertedBy <> 'ChatBot') AND (InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot'))) 
				AND SessionID  in (SELECT SessionId  from TMAC_Interactions WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
				AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
				GROUP BY SessionID) GROUP BY SessionID,InteractionDate,InteractionTime,InteractionText,CIF
			) INTDURTIME ON INTDURTIME.SessionID = H.SessionID 
			LEFT JOIN 
			(	
				Select SessionId, COUNT(1) as CallbackCount FROM IVR_Callback_Requests R 
				JOIN TMAC_Interactions C on C.SubSessionId  = R.UCID 
				WHERE C.CALLCONNECTEDTIME != '00010101000000' AND C.ClosedDateTime >= v_DataFromDate AND C.ClosedDateTime <= v_DataToDate 																																					 
				GROUP By SessionId
			) TabCallback on TabCallback.SessionId = H.SessionID 
			INNER JOIN
			(
			  	SELECT  min(ID) as ID,SessionID from GBL_InteractionHistory 
			  	WHERE (`Channel`='Chat' or `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat')
			  	AND SessionID  in (SELECT SessionId  from TMAC_Interactions  WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
				AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
			  	GROUP BY SessionID
			) HID ON HID.SessionID = H.SessionID AND HID.ID=H.ID
			WHERE (IsTransfered=0 AND IsConferenced=0  AND 
			(H.`Channel`='Chat' or H.`Channel`='TextChat' OR H.`Channel`='AudioChat' OR H.`Channel`='VideoChat') 
			AND ( I.ClosedDateTime >= v_DataFromDate AND I.ClosedDateTime <= v_DataToDate)
			AND ( I.CreatedDateTime in ( SELECT  min(CreatedDateTime) as id from TMAC_Interactions   
			WHERE  (`Channel`='Chat' OR `Channel`='TextChat' OR `Channel`='AudioChat' OR `Channel`='VideoChat') 
			AND CALLCONNECTEDTIME != '00010101000000' 
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			GROUP BY SessionId)))
			
			GROUP BY H.SessionID, I.SubSessionId, I.Intent, TabCallback.CallbackCount, CustomData, CHAT.AGENTWAITTIME, CHAT.USERWAITTIME,
			QueueTime, StartDateTime, EndDateTime, BOTDATETIME.ChatBotStartDateTime, BOTDATETIME.ChatBotEndDateTime, U.CIF, INTDURTIME.CIF, ISCHATTRANSFERED,ISCHATCONFERENCED, H.ID, I.AgentId, INTDURTIME.DurEndDateTime, I.SubChannel, H.`Channel`, INTDURTIME.CHATENDREASON, I.OtherData, S.SkillName, I.Skill
			
			UNION 

		-- below section is to handle chatbot only interactions
		SELECT DISTINCT  H.SESSIONID, H.GroupID, H.ID, H.CIF AS IDENTIFICATION, null, null,
		ChatBotStartDateTime, ChatBotEndDateTime, null INTENTNAME, null AS Skill, 'No'  AS CALLBACK, 
		ifnull((TIMESTAMPDIFF(SECOND,convert(insert(insert(insert(ChatBotStartDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
			convert(insert(insert(insert(ChatBotEndDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))),0) AS DURATIONTIME,
		0,0,  null AS AGENTID,null as OTHERDATA,0 AS QUEUEWAITTIME,
		0,0, H.Channel AS CHANNEL, null
		FROM GBL_InteractionHistory H  
		LEFT JOIN
		(
			SELECT  SessionID,MIN(concat(INTERACTIONDATE,INTERACTIONTIME)) AS ChatBotStartDateTime,
			MAX(concat(INTERACTIONDATE,INTERACTIONTIME)) AS ChatBotEndDateTime FROM GBL_InteractionHistory  
			WHERE (Channel='Chat' or Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
			AND ((InsertedBy = 'ChatBot') OR (InsertedBy IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')))  
			GROUP BY SESSIONID
		) BOTDATETIME ON BOTDATETIME.SessionID = H.SessionID 	
		INNER JOIN
		(
			SELECT  min(id) as ID,SESSIONID from GBL_InteractionHistory WHERE (Channel='Chat' or Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat')
			GROUP BY SESSIONID
		) HID ON HID.SESSIONID = H.SESSIONID AND HID.ID=H.ID
		WHERE H.GroupID = H.SessionId and (H.Channel='Chat' or H.Channel='TextChat' OR H.Channel='AudioChat' OR H.Channel='VideoChat')  AND IFNULL(H.CLID,'')='' 
		and H.SessionId in 
			(select distinct IHN.SessionID from GBL_InteractionHistory IHN where IHN.InteractionText in ('[ChatbotOnlyInteractionEnd]','[QueueAbandoned]') 
			AND concat(IHN.InteractionDate , IHN.InteractionTime)>=v_DataFromDate AND concat(IHN.InteractionDate , IHN.InteractionTime) <= v_DataToDate)
		AND H.SessionID not in (SELECT SessionId  from TMAC_Interactions  
		WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME != '00010101000000' AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate GROUP BY SESSIONID)
		GROUP BY H.sessionid, H.GroupID, CustomData, ChatBotStartDateTime, ChatBotEndDateTime, H.CIF, H.ID, H.Channel;
	
	ELSEIF ( p_Type='chattransscript')	
	THEN 
 			-- below section is to handle chatbot and escalated to agent
			SELECT Distinct 2 as GrpType, IH.SessionID as SESSIONID, I.SubSessionId as GroupID, InteractionText, 
			CONCAT(InteractionDate,InteractionTime) INTERACTIONDATETIME, IH.Direction, '-ChatBot' as SERVICEDBY, 
			(CASE WHEN upper(IH.Direction)='OUT' THEN 'ChatBot' ELSE IFNULL(I.UserName,'CUSTOMER') END ) FIRSTNAME,''LASTNAME,IH.ID,CustomData as ActionText 
			FROM GBL_InteractionHistory IH 
			LEFT JOIN TMAC_Interactions I ON IH.SessionID=I.SessionId 
			WHERE IH.`Channel` in ('Chat','TextChat','AudioChat','VideoChat')  
			AND ((InsertedBy = 'ChatBot') OR (InsertedBy IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')))  
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			
			UNION
			-- below section is to handle chatbot only interactions
			SELECT Distinct 2 as GrpType, IH.SESSIONID as SESSIONID, IH.GroupID, INTERACTIONTEXT, 
			concat(INTERACTIONDATE,INTERACTIONTIME) INTERACTIONDATETIME, IH.DIRECTION, '-ChatBot' as SERVICEDBY, 
			(CASE WHEN upper(IH.DIRECTION)='OUT' THEN 'ChatBot' ELSE 'CUSTOMER' END ) FIRSTNAME,''LASTNAME,IH.ID,CustomData as ActionText 
			FROM GBL_InteractionHistory IH  
			WHERE IH.Channel in ('Chat','TextChat','AudioChat','VideoChat') and SessionID in 
			(select distinct IHN.SessionID from GBL_InteractionHistory IHN where IHN.InteractionText in ('[ChatbotOnlyInteractionEnd]','[QueueAbandoned]') 
			AND concat(IHN.InteractionDate , IHN.InteractionTime)>=v_DataFromDate AND concat(IHN.InteractionDate , IHN.InteractionTime) <= v_DataToDate)
			
			UNION 
			-- below section is to all agent transcripts
			SELECT Distinct 4 as GrpType, IH.SessionID as SESSIONID, I.SubSessionId as GroupID, InteractionText, 
			CONCAT(InteractionDate,InteractionTime) as INTERACTIONDATETIME, IH.Direction, Concat('- ', AGT_Agent.FirstName , AGT_Agent.LastName) as SERVICEDBY,
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.FirstName ELSE IFNULL(I.UserName,'CUSTOMER') END) as FIRSTNAME,
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.LastName ELSE '' END) as LASTNAME,IH.ID,CustomData as ActionText
			FROM GBL_InteractionHistory IH  
			LEFT JOIN AGT_Agent ON AGT_Agent.AvayaLoginID = IH.InsertedBy 
			LEFT JOIN TMAC_Interactions I ON IH.SessionID=I.SessionId 
			WHERE IH.Channel in ('Chat','TextChat','AudioChat','VideoChat')  
			AND ((InsertedBy <> 'ChatBot') AND (InsertedBy NOT IN (select A.AvayaLoginID from AGT_Agent A join AGT_TMACAgentProfile P on A.AvayaLoginID=P.AgentID WHERE P.AccessRole='Chatbot')))
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			order by GrpType asc,ID ASC;
											   
	ELSEIF (p_Type='chatcallback')	
	THEN
			DROP TEMPORARY TABLE IF EXISTS CALLBACKTABLE;
			CREATE TEMPORARY TABLE CALLBACKTABLE (SESSIONID VARCHAR(50),UCID VARCHAR(50), CALLBACKSTATUS VARCHAR(10),CALLBACKDATE VARCHAR(10),CALLBACKTIME VARCHAR(10),CALLBACKCOUNT INT);
			INSERT INTO CALLBACKTABLE
			Select C.SessionID ,R.UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME, COUNT(1) as CALLBACKCOUNT FROM IVR_Callback_Requests R 
			INNER JOIN GBL_Interaction_CustomData C on C.`Value` = R.UCID AND C.`Name`='ChatToCallback' AND 
			CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) >= v_DataFromDate and CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) <= v_DataToDate 
			GROUP By C.SessionID , UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME;
			
			SELECT SESSIONID,UCID,CALLBACKSTATUS,CALLBACKDATE,CALLBACKTIME,CALLBACKCOUNT FROM CALLBACKTABLE;
	END IF;	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatInteractionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatInteractionReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'main')
	THEN
			SELECT DISTINCT H.SessionID, I.SubSessionId as GroupID, H.ID, CASE WHEN ifnull(U.CIF,'')='' THEN INTDURTIME.CIF ELSE U.CIF END AS IDENTIFICATION, 
			INTDATETIME.StartDateTime, INTDATETIME.EndDateTime,
			INTDATETIME.StartDateTime as ChatBotStartDateTime,INTDATETIME.EndDateTime as ChatBotEndDateTime,IntentName ,
			(CASE WHEN (Ifnull(TabCallback.CallbackCount,0))=0 THEN 'No' ELSE 'Yes' END) AS CALLBACK, 
			ifnull((TIMESTAMPDIFF(SECOND,convert(insert(insert(insert(INTDATETIME.StartDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
			convert(insert(insert(insert(INTDURTIME.DurEndDateTime, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))),0) AS DURATIONTIME,
			 ISCHATTRANSFERED,ISCHATCONFERENCED,  I.AgentId AS AGENTID,OtherData as OTHERDATA,Ifnull(QueueTime,0) AS QUEUEWAITTIME,
			 AGENTWAITTIME,USERWAITTIME, I.SubChannel AS `CHANNEL`, INTDURTIME.CHATENDREASON
			FROM GBL_InteractionHistory H  
			LEFT JOIN TMAC_Interactions I ON I.SessionId= H.SessionID
			LEFT JOIN TMAC_InteractionUserData U ON U.SessionID= H.SessionID
			-- to get intent
			LEFT JOIN GBL_IntentMapping M on H.SessionID = M.SessionID AND M.LastServicedAgent not in ('VA','IVR','ChatBot')
			
			LEFT JOIN
			(
			  SELECT   SessionId, ifnull(sum(IsTransfered),0) AS ISCHATTRANSFERED,ifnull(sum(IsConferenced),0) AS ISCHATCONFERENCED, 
			  ifnull(sum(AgentWaitTimeForResponse),0) as AGENTWAITTIME , ifnull(sum(UserWaitTimeForResponse),0) as USERWAITTIME from TMAC_Interactions  
			  WHERE (`Channel`='Chat' or `Channel`='TextChat')  GROUP BY SessionId
			) 
			CHAT ON CHAT.SessionId=H.SessionID 
			LEFT JOIN
			(
				SELECT  SessionID,MIN(CONCAT(InteractionDate,InteractionTime)) AS StartDateTime,
				MAX(CONCAT(InteractionDate,InteractionTime)) AS EndDateTime FROM GBL_InteractionHistory WHERE (`Channel`='Chat' or `Channel`='TextChat') 
				
				GROUP BY SessionID
			) 
			INTDATETIME ON INTDATETIME.SessionID = H.SessionID 	
			LEFT JOIN
			(
				SELECT  SessionID,CIF,CONCAT(InteractionDate,InteractionTime) AS DurEndDateTime,substring(InteractionText ,locate(':',InteractionText)+1,500) AS CHATENDREASON 
				FROM GBL_InteractionHistory WHERE ID IN ( SELECT  MAX(ID) as ID from GBL_InteractionHistory   
				WHERE (`Channel`='Chat' or `Channel`='TextChat')  AND (InteractionText like '_RemoteEndDisconnected%'  OR InteractionText like '_RemoteEndClosed%' OR InteractionText like '_Agent-EndTextChat%')
				GROUP BY SessionID) GROUP BY SessionID,InteractionDate,InteractionTime,InteractionText,CIF
		
			) 
			INTDURTIME ON INTDURTIME.SessionID = H.SessionID 	
			LEFT JOIN 
			(	
				 Select SessionId, COUNT(1) as CallbackCount FROM IVR_Callback_Requests R 
				 JOIN TMAC_Interactions C on C.SubSessionId  = R.UCID 
				 GROUP By SessionId
			) 
			TabCallback on TabCallback.SessionId = H.SessionID 
			INNER JOIN
			(
			  SELECT  min(ID) as ID,SessionID from GBL_InteractionHistory  WHERE (`Channel`='Chat' or `Channel`='TextChat')
			  GROUP BY SessionID
			)
			HID ON HID.SessionID = H.SessionID AND HID.ID=H.ID
			WHERE IsTransfered=0 AND IsConferenced=0  AND (H.`Channel`='Chat' or H.`Channel`='TextChat') 
			AND I.ClosedDateTime >= v_DataFromDate AND I.ClosedDateTime <= v_DataToDate
			AND I.CreatedDateTime in ( SELECT  min(CreatedDateTime) as id from TMAC_Interactions WHERE  (`Channel`='Chat' or `Channel`='TextChat') 
			AND CALLCONNECTEDTIME != '00010101000000' 
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			GROUP BY SessionId)
			GROUP BY H.SessionID, I.SubSessionId, IntentName, TabCallback.CallbackCount, CustomData, CHAT.AGENTWAITTIME, CHAT.USERWAITTIME,
			QueueTime, StartDateTime, EndDateTime, U.CIF, INTDURTIME.CIF, ISCHATTRANSFERED, ISCHATCONFERENCED, H.ID,
			I.AgentId, INTDURTIME.DurEndDateTime, I.SubChannel, INTDURTIME.CHATENDREASON, I.OtherData;
		
	ELSEIF ( p_Type='chattransscript')	
	THEN 
			SELECT Distinct 4 as GrpType, IH.SessionID as SESSIONID, I.SubSessionId as GroupID, InteractionText, 
			CONCAT(InteractionDate,InteractionTime) as INTERACTIONDATETIME,IH.Direction, 
			Concat('- ', AGT_Agent.FirstName , AGT_Agent.LastName)  as SERVICEDBY, 
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.FirstName ELSE IFNULL(I.UserName,'CUSTOMER') END) as FIRSTNAME, 
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.LastName ELSE '' END) as LASTNAME,IH.ID
			FROM GBL_InteractionHistory IH 
			LEFT JOIN AGT_Agent ON AGT_Agent.AvayaLoginID = IH.InsertedBy 
			LEFT JOIN TMAC_Interactions I ON IH.SessionID=I.SessionId
			WHERE IH.`Channel` in ('Chat','TextChat')  AND InsertedBy != 'VA' 
			AND ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			order by GrpType asc,ID ASC;
	ELSEIF ( p_Type='chatcallback')	
	THEN
			DROP TEMPORARY TABLE IF EXISTS CALLBACKTABLE;
			CREATE TEMPORARY TABLE CALLBACKTABLE (SESSIONID VARCHAR(50),UCID VARCHAR(50), CALLBACKSTATUS VARCHAR(10),CALLBACKDATE VARCHAR(10),CALLBACKTIME VARCHAR(10),CALLBACKCOUNT INT);
			INSERT INTO CALLBACKTABLE
			Select C.SessionID ,R.UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME, COUNT(1) as CALLBACKCOUNT FROM IVR_Callback_Requests R 
			INNER JOIN GBL_Interaction_CustomData C on C.`Value` = R.UCID AND C.`Name`='ChatToCallback' AND 
			CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) >= v_DataFromDate and CONCAT(R.CALLBACK_DATE,R.CALLBACK_TIME) <= v_DataToDate 
			GROUP By C.SessionID , UCID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME;
	
			SELECT SESSIONID,UCID,CALLBACKSTATUS,CALLBACKDATE,CALLBACKTIME,CALLBACKCOUNT FROM CALLBACKTABLE;
	END IF;	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ChatTransferReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ChatTransferReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'MAIN')
	THEN
			SELECT  C.SessionID AS SessionID,
					C.CIF,
					C.CLID AS CallerID, 
					C.LASTMENU_1 AS LastMenu, 
					C.LASTMENU_2 AS LastMenu1, 
					C.LASTMENU_3 AS LastMenu2,
					C.LASTMENU_4 AS LastMenu3,
					C.DNIS AS HotlineNumber, 
					C.CIF AS CIN,
					C.TRANSFER_VDN as TransferredVdn, 
					C.NRIC AS UserID, 
					C.ENDDATETIME as EndDateTime,
					C.STARTDATETIME as StartDateTime
			FROM Chat_Call_History C INNER JOIN TMAC_Interactions T ON T.SessionId = C.SessionID
			where 1=1 AND TR_DIS_FLAG ='AT' AND ENDDATETIME>=v_DataFromDate AND ENDDATETIME<=v_DataToDate;
	END IF;
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_CSOSurveyReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_CSOSurveyReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = p_FromDate;
	SET v_DataToDate = p_ToDate;
	
	IF(p_Type = 'MAIN')
	THEN
		   SELECT FORMATDATETIME(VARCHARTODATETIME( CONCAT(`START_DATE`,`START_TIME`)),'dd/MM/yyyy HH:mm:ss') StartDateTime,
			CIFNUMBER as CIFNumber, CONTACT_NAME as ContactName,CALLERID as CallerID,AGENTID as AgentID,DNIS as DNIS,
			FORMATDATETIME(VARCHARTODATETIME( CONCAT(`END_DATE`,`END_TIME`)),'dd/MM/yyyy HH:mm:ss') EndDateTime,
			CALL_DURATION As CallDuration,`LANGUAGE` as `Language`,
			IFNULL(QN1TEXT,'') AS QN1Text,IFNULL(QN2TEXT,'') AS QN2Text,
			IFNULL(QN3TEXT,'') AS QN3Text,IFNULL(QN4TEXT,'') AS QN4Text,IFNULL(QN5TEXT,'') AS QN5Text,
			IFNULL(QN1RESULT,'') as QN1Result,IFNULL(QN2RESULT,'') AS QN2Result,IFNULL(QN3RESULT,'') AS QN3Result,
			IFNULL(QN4RESULT,'') AS QN4Result,IFNULL(QN5RESULT,'') AS QN5Result,UCID,PHONECODE AS NRIC,
			IFNULL(QN6TEXT,'') AS QN6Text,IFNULL(QN7TEXT,'') AS QN7Text,
			IFNULL(QN8TEXT,'') AS QN8Text,IFNULL(QN9TEXT,'') AS QN9Text,IFNULL(QN10TEXT,'') AS QN10Text,
			IFNULL(QN6RESULT,'') as QN6Result,IFNULL(QN7RESULT,'') AS QN7Result,IFNULL(QN8RESULT,'') AS QN8Result,
			IFNULL(QN9RESULT,'') AS QN9Result,IFNULL(QN10RESULT,'') AS QN10Result,COMPANY_NAME AS CompanyName, CUSTOMER_SEGMENT AS CustomerSegment 
			FROM IVR_SURVEY_OF_CSO_REPORT I 
			where CONCAT(`END_DATE`,`END_TIME`) >= v_DataFromDate and CONCAT(`END_DATE`,`END_TIME`) <= v_DataToDate 
			group by `START_DATE`,`START_TIME`,`CIFNUMBER`,`CONTACT_NAME`,`CALLERID`,`AGENTID`,`DNIS`,`QN1TEXT`,`QN2TEXT`,`QN3TEXT`,`QN4TEXT`,`QN5TEXT`,`QN1RESULT`,
			`QN2RESULT`,`QN3RESULT`,`QN4RESULT`,`QN5RESULT`,`END_DATE`,`END_TIME`,`CALL_DURATION`,`LANGUAGE`,`UCID`,`QN6TEXT`,`QN7TEXT`,`QN8TEXT`,`QN9TEXT`,`QN10TEXT`,
			`QN6RESULT`,`QN7RESULT`,`QN8RESULT`,`QN9RESULT`,`QN10RESULT`,`PHONECODE`,`COMPANY_NAME`,`CUSTOMER_SEGMENT`;
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_DailyStatisticsByTransactionsReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_DailyStatisticsByTransactionsReport`(
p_FromDate VARCHAR(20),
p_ToDate VARCHAR(20))
BEGIN
    DECLARE v_LocalFromDateTime VARCHAR(20);
	 DECLARE v_LocalToDateTime VARCHAR(20);
	 DECLARE v_CombineQuery LONGTEXT;

	SET v_LocalFromDateTime = p_FromDate;
	SET v_LocalToDateTime = p_ToDate;
	
	SET v_CombineQuery = CONCAT('Select SessionId,
							case when `SessionId` is null and `TransactionTime` is null and `ApprovalCode` is null then '''' else `TransactionDate` end TransactionDate,
							`TransactionTime`,`ApprovalCode`,
							case when `SessionId` is null and `TransactionTime` is null and `ApprovalCode` is null and `TransactionType` is null then ''Grand Total'' else 
							case when `SessionId` is null and `TransactionTime` is null and `ApprovalCode` is null then ''Sub Total'' else
							`TransactionType` end end `TransactionType`,`Amount`
							from (
							SELECT `SessionId`,
							format(VARCHARTODATETIME(CONCAT(`TransactionDate`,`TransactionTime`)),''dd/MM/yyyy'') `TransactionDate`, 
							format(VARCHARTODATETIME(CONCAT(`TransactionDate`,`TransactionTime`)),''HH:mm:ss'') `TransactionTime`,`ApprovalCode`,
							`TransactionType`,sum(`Amount`)`Amount`
							 FROM  `IVR_Authorizer_Transactions` 
							WHERE CONCAT(`TransactionDate`,`TransactionTime`) >= ',v_LocalFromDateTime,' AND CONCAT(`TransactionDate`,`TransactionTime`) <= ',v_LocalToDateTime,'
							group by GROUPING SETS( 
							(`SessionId`,format(VARCHARTODATETIME( CONCAT(`TransactionDate`,`TransactionTime`)),''dd/MM/yyyy''), format(VARCHARTODATETIME( CONCAT(`TransactionDate`,`TransactionTime`)),''HH:mm:ss''),`TransactionType`,`ApprovalCode`),

							(format(VARCHARTODATETIME( CONCAT(`TransactionDate`,`TransactionTime`)),''dd/MM/yyyy''),`TransactionType`),()) 
							) Main');
	
	SET @stmt_str = v_CombineQuery;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_EKYCStatusReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_EKYCStatusReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
	DECLARE v_DataFromDate VARCHAR(50);
	DECLARE v_DataToDate VARCHAR(50);
	BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 
		
		select IA.SessionId, CASE WHEN ifnull(U.CIF,'')='' THEN INTDURTIME.CIF ELSE U.CIF END AS CIF,
		CASE WHEN ifnull(U.NRIC,'')='' THEN INTDURTIME.NRIC ELSE U.NRIC END AS NRIC, AuditType,
		RequestBy, RequestComment, STR_TO_DATE(RequestDateTime,'%Y%m%d%H%i%s') as RequestDateTime, 
		AuditBy, AuditComment, STR_TO_DATE(AuditDateTime,'%Y%m%d%H%i%s') as AuditDateTime, RequestStatus, ResponseMessage, ResponseResult 
		from TMAC_Interactions_Audit IA 
		LEFT JOIN TMAC_InteractionUserData U ON U.SessionID= IA.SessionID
		LEFT JOIN
		(
			SELECT  SessionID,CIF,NRIC,concat(INTERACTIONDATE,INTERACTIONTIME) AS DurEndDateTime 
			FROM GBL_InteractionHistory WHERE ID IN ( SELECT  MAX(id) as ID from GBL_InteractionHistory  
			WHERE Channel IN ('AudioChat','VideoChat','Chat','TextChat')  
			AND (INTERACTIONTEXT like '_RemoteEndDisconnected%'  OR INTERACTIONTEXT like '_RemoteEndClosed%' OR INTERACTIONTEXT like '_Agent-EndTextChat%')
			AND InsertedBy <> 'ChatBot' 
			GROUP BY SESSIONID) GROUP BY SESSIONID,INTERACTIONDATE,INTERACTIONTIME,CIF,NRIC
		) INTDURTIME ON INTDURTIME.SessionID = IA.SessionID 
		WHERE RequestStatus in ('Approved','Rejected') and ifnull(AuditDateTime,'') !='' and
		AuditDateTime >= v_DataFromDate AND AuditDateTime <= v_DataToDate;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_GISalesReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_GISalesReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	IF(p_Type = 'MAIN')
	THEN
			SELECT
				JSON_VALUE(OtherData, '$.CampaignID2') as CAMP_ID,
				JSON_VALUE(OtherData, '$.UOICAMP') as UOI_CAMP,
				JSON_VALUE(OtherData, '$.SA0Insured') as SA0_INSURED,
				JSON_VALUE(OtherData, '$.SA0PLANCODE') as SA0_PLANCODE,
				JSON_VALUE(OtherData, '$.CustName1') as CUST_NAME1,
				JSON_VALUE(OtherData, '$.CustName2') as CUST_NAME2,
				JSON_VALUE(OtherData, '$.IDNo') as ID_NO,
				JSON_VALUE(OtherData, '$.OCCUPNINDUSTRY') as OCCUPN,
				JSON_VALUE(OtherData, '$.OCCUPNCLASS') as OCCUPN_CLASS,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.DOB'),'') as date), 'dd/MM/yyyy') as DOB,
				JSON_VALUE(OtherData, '$.Gender') as Gender,
				JSON_VALUE(OtherData, '$.Salutation') as SALUTATION,
				JSON_VALUE(OtherData, '$.MaritalStatus') as MARITAL_STAT,
				JSON_VALUE(OtherData, '$.PHONE1') as PHONE1,
				JSON_VALUE(OtherData, '$.PHONE2') as PHONE2,
				JSON_VALUE(OtherData, '$.PHONE3') as PHONE3,
				JSON_VALUE(OtherData, '$.Address1') as ADDR1,
				JSON_VALUE(OtherData, '$.Address2') as ADDR2,
				JSON_VALUE(OtherData, '$.Address3') as ADDR3,
				JSON_VALUE(OtherData, '$.Address4') as ADDR4,
				JSON_VALUE(OtherData, '$.PCODE') as PCODE,
				JSON_VALUE(OtherData, '$.CODE') as CODE,
				JSON_VALUE(OtherData, '$.PAYFREQ') as PAY_FREQ,
				JSON_VALUE(OtherData, '$.PAYMODE') as PAY_MODE,
				JSON_VALUE(OtherData, '$.PAYBANK') as PAY_BANK,
				JSON_VALUE(OtherData, '$.PAYACCT') as PAY_ACCT,
				JSON_VALUE(OtherData, '$.PAYACCTTYPE') as PAY_ACCTTYPE,
				JSON_VALUE(OtherData, '$.PAYACCTEXP') as PAY_ACCTEXP,
				JSON_VALUE(OtherData, '$.PAYCOVERAGE') as PAY_COVERAGE,
				JSON_VALUE(OtherData, '$.PAYPREMIUM') as PAY_PREMIUM,
				JSON_VALUE(OtherData, '$.PAYTARP') as PAY_TARP,
				JSON_VALUE(OtherData, '$.DISCPERCENT') as DISC_PERCENT,
				JSON_VALUE(OtherData, '$.OPTBENEFIT') as OPT_BENEFIT,
				JSON_VALUE(OtherData, '$.SA1CUSTNAME1') as SA1_CUST_NAME1,
				JSON_VALUE(OtherData, '$.SA1CUSTNAME2') as SA1_CUST_NAME2,
				JSON_VALUE(OtherData, '$.SA1Gender') as SA1_Gender,
				JSON_VALUE(OtherData, '$.SA1IDNO') as SA1_ID_NO,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.SA1DOB'),'') as date), 'dd/MM/yyyy') as SA1_DOB,
				JSON_VALUE(OtherData, '$.SA1OCCUPN') as SA1_OCCUPN,
				JSON_VALUE(OtherData, '$.SA1OCCUPNCLASS') as SA1_OCCUPN_CLASS,
				JSON_VALUE(OtherData, '$.SA1TYPE') as SA1_TYPE,
				JSON_VALUE(OtherData, '$.SA1PLANCODE') as SA1_PLANCODE,
				JSON_VALUE(OtherData, '$.SA2CUSTNAME1') as SA2_CUST_NAME1,
				JSON_VALUE(OtherData, '$.SA2CUSTNAME2') as SA2_CUST_NAME2,
				JSON_VALUE(OtherData, '$.SA2Gender') as SA2_Gender,
				JSON_VALUE(OtherData, '$.SA2IDNO') as SA2_ID_NO,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.SA2DOB'),'') as date), 'dd/MM/yyyy') as SA2_DOB,
				JSON_VALUE(OtherData, '$.SA2OCCUPN') as SA2_OCCUPN,
				JSON_VALUE(OtherData, '$.SA2OCCUPNCLASS') as SA2_OCCUPN_CLASS,
				JSON_VALUE(OtherData, '$.SA2TYPE') as SA2_TYPE,
				JSON_VALUE(OtherData, '$.SA2PLANCODE') as SA2_PLANCODE,
				JSON_VALUE(OtherData, '$.SA3CUSTNAME1') as SA3_CUST_NAME1,
				JSON_VALUE(OtherData, '$.SA3CUSTNAME2') as SA3_CUST_NAME2,
				JSON_VALUE(OtherData, '$.SA3Gender') as SA3_Gender,
				JSON_VALUE(OtherData, '$.SA3IDNO') as SA3_ID_NO,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.SA3DOB'),'') as date), 'dd/MM/yyyy') as SA3_DOB,
				JSON_VALUE(OtherData, '$.SA3OCCUPN') as SA3_OCCUPN,
				JSON_VALUE(OtherData, '$.SA3OCCUPNCLASS') as SA3_OCCUPN_CLASS,
				JSON_VALUE(OtherData, '$.SA3TYPE') as SA3_TYPE,
				JSON_VALUE(OtherData, '$.SA3PLANCODE') as SA3_PLANCODE,
				JSON_VALUE(OtherData, '$.SA4CUSTNAME1') as SA4_CUST_NAME1,
				JSON_VALUE(OtherData, '$.SA4CUSTNAME2') as SA4_CUST_NAME2,
				JSON_VALUE(OtherData, '$.SA4Gender') as SA4_Gender,
				JSON_VALUE(OtherData, '$.SA4IDNO') as SA4_ID_NO,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.SA4DOB'),'') as date), 'dd/MM/yyyy') as SA4_DOB,
				JSON_VALUE(OtherData, '$.SA4OCCUPN') as SA4_OCCUPN,
				JSON_VALUE(OtherData, '$.SA4OCCUPNCLASS') as SA4_OCCUPN_CLASS,
				JSON_VALUE(OtherData, '$.SA4TYPE') as SA4_TYPE,
				JSON_VALUE(OtherData, '$.SA4PLANCODE') as SA4_PLANCODE,
				JSON_VALUE(OtherData, '$.SA5CUSTNAME1') as SA5_CUST_NAME1,
				JSON_VALUE(OtherData, '$.SA5CUSTNAME2') as SA5_CUST_NAME2,
				JSON_VALUE(OtherData, '$.SA5Gender') as SA5_Gender,
				JSON_VALUE(OtherData, '$.SA5IDNO') as SA5_ID_NO,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.SA5DOB'),'') as date), 'dd/MM/yyyy') as SA5_DOB,
				JSON_VALUE(OtherData, '$.SA5OCCUPN') as SA5_OCCUPN,
				JSON_VALUE(OtherData, '$.SA5OCCUPNCLASS') as SA5_OCCUPN_CLASS,
				JSON_VALUE(OtherData, '$.SA5TYPE') as SA5_TYPE,
				JSON_VALUE(OtherData, '$.SA5PLANCODE') as SA5_PLANCODE,
				JSON_VALUE(OtherData, '$.COMMENT1') as COMMENT1,
				JSON_VALUE(OtherData, '$.COMMENT2') as COMMENT2,
				JSON_VALUE(OtherData, '$.COMMENT3') as COMMENT3,
				JSON_VALUE(OtherData, '$.COMMENT4') as COMMENT4,
				JSON_VALUE(OtherData, '$.COMMENT5') as COMMENT5,
				FORMAT(CAST(NULLIF(JSON_VALUE(OtherData, '$.DTE'),'') as date), 'dd/MM/yyyy') as DTE,
				JSON_VALUE(OtherData, '$.TME') as TME,
				AgentID,
				CONCAT(AgentFirstName,' ', AgentLastName) as Agent_Name,
				JSON_VALUE(OtherData, '$.Email') as Email_ID,
				`DateTime`  
				from AGT_Agent_Telesales_Data  
				where `DateTime` >= p_FromDate AND `DateTime`<= p_ToDate and 
				ScreenType='GISales';

	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_InteractionActionsReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_InteractionActionsReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
	DECLARE v_DataFromDate VARCHAR(50);
	DECLARE v_DataToDate VARCHAR(50);
	BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 
		
		IF(p_Type = 'MAIN')
		THEN
			SELECT AgentId as AgentID, InteractionId as InteractionID, `Action`, ActionTime as ActionDateTime,
			ActionResult, Details, LoginInstanceID, SessionID 
			FROM TMAC_Interaction_Actions 
		   WHERE ActionTime >= v_DataFromDate AND ActionTime <= v_DataToDate;
		END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_IvrCallerIdentificationReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_IvrCallerIdentificationReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
		Select	FTab.ReportDate,FTab.Dnis as Hotline,FTAb.TotalCallsOffered,STab.`Language`,STab.CallsOfferedForLanguage,
		STab.Option1,STab.Option2,STab.Option3,STab.Option4,STab.Option5,STab.Option6,STab.Total from (
		(Select CONCAT(C.StartDate,C.startTime) as ReportDate,H.ICH_DNIS as Dnis,count(H.ICH_DNIS) AS TotalCallsOffered from IVR_Caller_Identification 
		C INNER JOIN IVR_CALL_HISTORY H on C.sessionId=H.ICH_CALLREFID 
		where CONCAT(C.StartDate,C.starttime)>=v_DataFromDate and CONCAT(C.StartDate,C.starttime)<=v_DataToDate
		GROUP BY CONCAT(StartDate,C.startTime),ICH_DNIS) as FTab inner join (SELECT T.ReportDate,T.Dnis,
		COUNT(T.Dnis) as CallsOfferedForLanguage ,T.`Language`, SUM(T.Option1) AS Option1,SUM(T.Option2) AS Option2,SUM(T.Option3) AS 
		Option3,SUM(T.Option4) AS Option4,SUM(T.Option5) AS Option5, sum(T.Option6) as Option6,
		SUM(T.Option1)+SUM(T.Option2)+SUM(T.Option3)+SUM(T.Option4)+SUM(T.Option5)+sum(T.Option6) 
		AS Total FROM ( Select C.SessionId,CONCAT(C.StartDate,C.startTime) as ReportDate,H.ICH_DNIS AS Dnis,IFNULL(`IU_LANGUAGE`,'') as `Language`,
		CASE WHEN LOWER(C.isCallerRegistered)='yes' AND LOWER(C.isMembershipIdEntered)='yes' AND LOWER(C.isIdentified)='yes' and 
		LOWER(C.isVerificationPinEntered)='yes' and LOWER(C.isPinVerified)='pass' THEN 1 ELSE 0 END AS Option1,
		CASE WHEN LOWER(C.isCallerRegistered)='yes' AND (LOWER(C.isMembershipIdEntered)='no' or LOWER(C.isMembershipIdEntered)='na' )THEN 1 ELSE 0 END AS Option2,
		CASE WHEN (LOWER(C.isCallerRegistered)='no' OR LOWER(C.isCallerRegistered)='na' ) AND LOWER(C.isMembershipIdEntered)='yes' AND LOWER(C.isIdentified)='yes' 
		AND LOWER(C.isVerificationPinEntered)='yes' AND LOWER(C.isPinVerified)='pass' THEN 1 ELSE 0 END AS Option3,CASE WHEN (LOWER(C.isCallerRegistered)='no' OR
		LOWER(C.isCallerRegistered)='na') AND LOWER(C.isMembershipIdEntered)='yes' and (LOWER(C.isVerificationPinEntered)='no' or LOWER(C.isVerificationPinEntered)='na' )  
		THEN 1 ELSE 0 END AS Option4,CASE WHEN (LOWER(C.isCallerRegistered)='no' or LOWER(C.isCallerRegistered)='na') AND (LOWER(C.isMembershipIdEntered)='no' or 
		LOWER(C.isMembershipIdEntered)='na' ) AND (LOWER(C.isVerificationPinEntered)='no' or LOWER(C.isVerificationPinEntered)='na') THEN 1 ELSE 0 END AS Option5,
		CASE WHEN LOWER(C.isCallerRegistered)='yes' AND LOWER(C.isMembershipIdEntered)='yes' and (LOWER(C.isVerificationPinEntered)='no' or LOWER(C.isVerificationPinEntered)='na' )  
		THEN 1 ELSE 0 END AS Option6						
		from IVR_Caller_Identification C INNER JOIN IVR_CALL_HISTORY H on C.sessionId=H.ICH_CALLREFID 
		where CONCAT(C.StartDate,C.starttime)>=v_DataFromDate and CONCAT(C.StartDate,C.starttime)<=v_DataToDate) 
		AS T GROUP BY ReportDate,T.`Language`,T.Dnis) as  STab on FTab.Dnis=STab.Dnis and  FTab.ReportDate=STab.ReportDate);

	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_IvrHostTransactionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_IvrHostTransactionReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_Type VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
			SELECT 
					IVR_Call_History.ICH_CALLREFID AS UCID,
					SUBSTRING(REPLACE(REPLACE(REPLACE(DATE_FORMAT(IVR_TRL.REQUEST_DATE,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),1,14) AS REQUESTDATETIME,
					IVR_Call_History.NRIC AS CIN,
					IVR_TRL.TRANSACTION_NAME AS TRANSACTIONNAME,
					IVR_TRL.MENU_DESCRIPTION AS MENUDESCRIPTION,
					IVR_TRL.REQ_MESSAGE AS REQUESTMESSAGE,
					IVR_TRL.RES_MESSAGE AS RESPONSEMESSAGE,
					IVR_Call_History.ICH_DNIS AS HOTLINENUMBER,
					IVR_Call_History.PHONE_CODE AS PHONECODE,
					IVR_Call_History.CIF,					
					IVR_Call_History.CUSTOMER_SEGMENT AS CUSTOMERSEGMENT,   
				    DATE_FORMAT(((SELECT(STR_TO_DATE(IVR_TRL.RESPONSE_DATE,108)))-(SELECT(STR_TO_DATE(IVR_TRL.REQUEST_DATE,108)))),114) AS RESPONSETIME,			
				    REPLACE(concat(ICH_END_DATE,ICH_END_TIME),':','') AS ENDDATETIME
			 		FROM  IVR_TRL INNER JOIN IVR_Call_History ON IVR_Call_History.ICH_CALLREFID=IVR_TRL.UCID
             WHERE 1=1 AND REPLACE(concat(ICH_END_DATE,ICH_END_TIME),':','')>=v_DataFromDate AND REPLACE(concat(ICH_END_DATE,ICH_END_TIME),':','')<=v_DataToDate;
		END;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_IvrJourneyReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_IvrJourneyReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_Type VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_MAIN LONGTEXT;
DECLARE v_OTP_VERFIFIED_COLNAME VARCHAR(100);

DECLARE v_SQLCommand LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 
	
	SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';
	
	IF EXISTS(SELECT 1 FROM Information_schema.COLUMNS WHERE TABLE_NAME = 'IVR_Call_History' AND COLUMN_NAME = 'OTP_VERFIFIED') 
	then
		SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';
	ELSE 
		SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERIFIED';
	END IF;	
	
	if(p_Type ='MAIN')
	then
	begin
		-- SELECT ICH_CALLREFID as UCID,
-- 		STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,':','')),'%Y%m%d%H%i%s') as StartDateTime,
-- 		STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,':','')),'%Y%m%d%H%i%s') as EndDateTime,	
-- 		ICH_CALL_DUR AS Duration,ICH_CLID AS CallerID,HDM.Hotline,
-- 		ICH_TR_DIS_FLAG AS TransferredFlag, TRANSFER_VDN AS TransferVDN,'' AS TransferOrDisconnectReason,
-- 		PHONE_CODE AS ServiceNumber,CIF AS CustomerID,EMP_NAME AS CustomerIDType, 
-- 		CUSTOMER_SEGMENT as CustomerType,ICH_DNIS  AS DNIS, IU_LANGUAGE AS Language, 
-- 		IU_LAST_MENU_ID AS LastMenu,COMPANY AS ProductType,BB_CUSTOM_INDICATOR as ServiceType from
-- 		IVR_Call_History AS ICH LEFT JOIN IVR_Hotline_DNIS_Mapping AS HDM ON ICH.ICH_DNIS = HDM.DNIS
-- 		WHERE concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) >= v_DataFromDate and 
-- 		concat(ICH_END_DATE,replace(ICH_END_TIME,':','')) <= v_DataToDate;
		
		SET v_SQLCommand = CONCAT('SELECT ICH_CALLREFID as UCID,
		STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,'':'','''')),''%Y%m%d%H%i%s'') as StartDateTime,
		STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,'':'','''')),''%Y%m%d%H%i%s'') as EndDateTime,  
		ICH_CALL_DUR AS Duration,ICH_CLID AS CallerID,HDM.Hotline,
		ICH_TR_DIS_FLAG AS TransferredFlag, TRANSFER_VDN AS TransferVDN,'''' AS TransferOrDisconnectReason,
		PHONE_CODE AS ServiceNumber,CIF AS CustomerID,EMP_NAME AS CustomerIDType, 
		CUSTOMER_SEGMENT as CustomerType,ICH_DNIS  AS DNIS, IU_LANGUAGE AS Language, ',v_OTP_VERFIFIED_COLNAME,' AS OTPVerified,
		TPIN_VERIFIED AS TpinVerified,NRIC AS CIN,LASTMENU_1 AS Lastmenu1,LASTMENU_2 AS Lastmenu2,
		LASTMENU_3 AS Lastmenu3, LASTMENU_4 AS Lastmenu4,
		IU_LAST_MENU_ID AS LastMenu,COMPANY AS ProductType,BB_CUSTOM_INDICATOR as ServiceType, 
		CASE WHEN LOCATE(''tpin'', Lower(TRANSFER_VDN)) > 0 THEN ''Yes'' ELSE ''No'' END AS TpinTransfered,
		CASE WHEN LOCATE(''feewaiver'', Lower(TRANSFER_VDN)) > 0 THEN ''Yes'' ELSE ''No'' END AS TransferredToFeewaiver, 
		CASE WHEN SMSReport.UCID IS NULL THEN ''No'' ELSE ''Yes'' END AS SMSEligibility,
		CASE WHEN VD.VDN_NAME IS NULL THEN '''' ELSE VD.VDN_NAME END AS VDNName 
		FROM IVR_Call_History AS ICH LEFT JOIN IVR_Hotline_DNIS_Mapping AS HDM ON ICH.ICH_DNIS = HDM.DNIS ');
		
			IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'VDN_DETAILS') 
				THEN
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN VDN_DETAILS VD ON FIND_IN_SET(VD.VDN_No,ICH.TRANSFER_VDN)>0');
			ELSE
					SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT '''' VDN_NAME,'''' VDN_No) VD ON FIND_IN_SET(VD.VDN_No,ICH.TRANSFER_VDN)>0');
			END IF;

			IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'SMSReport')
				THEN
					SET v_SQLCommand = CONCAT(v_SQLCommand , ' LEFT JOIN  (SELECT  DISTINCT UCID FROM SMSReport GROUP BY UCID) SMSReport  ON SMSReport.UCID =ICH.ICH_CALLREFID WHERE 1=1');
					
					SET v_MAIN=CONCAT(v_SQLCommand  ,' AND ((concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) >= ''',v_DataFromDate,''' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) <= ''',v_DataToDate,''')');
			ELSE
					SET v_SQLCommand = CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT ''0'' UCID ) SMSReport ON SMSReport.UCID =ICH.ICH_CALLREFID WHERE 1=1');
				
					SET v_MAIN=CONCAT(v_SQLCommand  ,' AND ((concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) >= ''',v_DataFromDate,''' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) <= ''',v_DataToDate,''')');
				 
			END IF;
			
		SET @stmt_str = v_MAIN;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END;
	ELSEIF (p_Type ='MENUNAVIGATION')
	then
		SELECT IVR_Usage.ICH_CALLREFID as UCID,
		STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,':','')),'%Y%m%d%H%i%s') as StartDateTime,
		STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,':','')),'%Y%m%d%H%i%s') as EndDateTime,	
		IU_ID AS MenuID,IU_EII AS InvalidInput,IU_ENI AS NoInput,IU_EMC AS MaxCount,IU_Order AS MenuOrder, IU_MENU_NAME AS MenuName,
		IU_VAL AS `Value`,IU_StartTime AS MenuStartDateTime,IU_EndTime AS MenuEndDateTime,ACCESS_DATETIME AS AccessDateTime, INSERT_TIME AS InsertedDateTime
		FROM IVR_Usage inner JOIN IVR_Call_History ON IVR_Usage.ICH_CALLREFID=IVR_Call_History.ICH_CALLREFID
		WHERE DATE_FORMAT(INSERT_TIME,'%Y%m%d%H%i%s') >= v_DataFromDate and 
		DATE_FORMAT(INSERT_TIME,'%Y%m%d%H%i%s') <= v_DataToDate;
	else
		SELECT UCID,
		STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,':','')),'%Y%m%d%H%i%s') as StartDateTime,
		STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,':','')),'%Y%m%d%H%i%s') as EndDateTime,
		TRANSACTION_NAME AS TransactionName,MENU_DESCRIPTION AS MenuDescription,IVR_TRANS_DATE AS TransactionDateTime,
		REQUEST_DATE AS RequestDateTime, RESPONSE_DATE AS ResponseDateTime,REQ_MESSAGE AS RequestMessage,
		RES_MESSAGE AS ResponseMessage,TIMESTAMPDIFF(SECOND,REQUEST_DATE,RESPONSE_DATE) AS ResponseTime
		FROM IVR_TRL inner JOIN IVR_Call_History ON IVR_TRL.UCID=IVR_Call_History.ICH_CALLREFID
		WHERE DATE_FORMAT(RESPONSE_DATE,'%Y%m%d%H%i%s') >= v_DataFromDate and 
		DATE_FORMAT(RESPONSE_DATE,'%Y%m%d%H%i%s') <= v_DataToDate;
	END if;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_LINEOverallStatisticReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_LINEOverallStatisticReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_StatementEnquiryMenuID VARCHAR(100),
p_RewardsEnquiryMenuID VARCHAR(100)
)
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
	
	IF(p_Type = 'MAIN')
	THEN
		SELECT S.CustomerOrgId as CIF,S.CustomerChannelId as LINEID,S.Active,C.ENDDATETIME as EndDateTime,
		ifnull(StatementEnqCount,0) as StatementEnquiry,ifnull(RewardsEnqCount,0) as RewardsEnquiry 
		FROM  Notify_SMMCustomer S  
		INNER JOIN Chat_Call_History C ON S.CustomerOrgId=C.CIF AND S.CustomerChannelId = C.EMP_NAME
		LEFT JOIN 
		(
			SELECT SessionID, COUNT(1) StatementEnqCount FROM Chat_Usage WHERE ID = p_StatementEnquiryMenuID
			GROUP BY SessionID
		) StatementEnq  ON C.SessionID=StatementEnq.SessionID
		LEFT JOIN 
		(
			SELECT SessionID, COUNT(1) RewardsEnqCount FROM Chat_Usage WHERE ID = p_RewardsEnquiryMenuID
			GROUP BY SessionID
		) RewardsEnq  ON C.SessionID=RewardsEnq.SessionID
		WHERE C.ENDDATETIME >= v_DataFromDate and C.ENDDATETIME <=v_DataToDate
		ORDER BY C.ENDDATETIME;
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_MX_InteractionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_MX_InteractionReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_Type VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
DECLARE v_MAIN LONGTEXT;
DECLARE v_OTP_VERFIFIED_COLNAME VARCHAR(100);
DECLARE v_DisconnectedBy_ColName VARCHAR(20);
DECLARE v_SQLCommand LONGTEXT;
DECLARE V_SQLQuery LONGTEXT;

	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
	SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';
	SET v_DisconnectedBy_ColName = 'DisconnectedBy';
	
		If EXISTS(SELECT 1 FROM Information_schema.COLUMNS WHERE TABLE_NAME = 'IVR_Call_History' AND COLUMN_NAME = 'OTP_VERFIFIED') 
		THEN
			SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERFIFIED';
		ELSE
			SET v_OTP_VERFIFIED_COLNAME = 'OTP_VERIFIED';
		END IF;

		If EXISTS(SELECT 1 FROM Information_schema.COLUMNS WHERE TABLE_NAME = 'TMAC_Interactions' AND COLUMN_NAME = 'DisconnectedBy') 
		THEN
			SET v_DisconnectedBy_ColName = 'DisconnectedBy';
		ELSE
			SET v_DisconnectedBy_ColName = 'NULL';
		END IF;	 
	
	IF(p_Type = 'MAIN')
	THEN
	BEGIN

		SET v_SQLCommand = CONCAT('
			SELECT ICH_CALLREFID as SessionID,
			STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,'':'','''')),''%Y%m%d%H%i%s'') as StartDateTime,
			STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,'':'','''')),''%Y%m%d%H%i%s'') as EndDateTime,  
			ICH_CALL_DUR AS Duration,ICH_CLID AS CallerID,HDM.Hotline,''Voice Bot'' as Channel,
			ICH_TR_DIS_FLAG AS TransferredFlag, TRANSFER_VDN AS TransferVDN, '''' AS TransferOrDisconnectReason,
			CASE WHEN VD.VDN_Name IS NULL THEN '''' ELSE VD.VDN_Name END AS VDNName,
			PHONE_CODE AS ServiceNumber,CIF AS CustomerID,EMP_NAME AS CustomerIDType,  
			CUSTOMER_SEGMENT as CustomerType,ICH.ICH_DNIS  AS DNIS, IU_LANGUAGE AS Language, ',v_OTP_VERFIFIED_COLNAME,' AS OTPVerified,
			TPIN_VERIFIED AS TpinVerified, NRIC AS CIN, LASTMENU_1 AS Lastmenu1, LASTMENU_2 AS Lastmenu2, LASTMENU_3 AS Lastmenu3, LASTMENU_4 AS Lastmenu4,
			IU_LAST_MENU_ID AS LastMenu,COMPANY AS ProductType,BB_CUSTOM_INDICATOR as ServiceType 
			FROM IVR_Call_History AS ICH LEFT JOIN IVR_Hotline_DNIS_Mapping AS HDM ON ICH.ICH_DNIS = HDM.DNIS ');

		IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'VDN_DETAILS') 
		THEN
					
			SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN VDN_DETAILS VD ON FIND_IN_SET(VD.VDN_No,ICH.TRANSFER_VDN)>0');
		ELSE
					
			SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT '''' VDN_NAME,'''' VDN_No) VD ON FIND_IN_SET(VD.VDN_No,ICH.TRANSFER_VDN)>0');
		END IF;

			SET v_MAIN=CONCAT(v_SQLCommand  ,' WHERE IFNULL(ICH_CALLREFID,'''')<>'''' AND ((concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) >= ''',v_DataFromDate,
			''' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,'':'', ''''))) <= ''',v_DataToDate,''')');

			
			SET v_SQLCommand=CONCAT(v_SQLCommand , ' UNION 
				SELECT SessionID,STARTDATETIME,ENDDATETIME, 
				CALL_DUR AS Duration,CLID AS CallerID,HDM.Hotline,''Chat Bot'' as Channel,
				TR_DIS_FLAG AS TransferredFlag, TRANSFER_VDN AS TransferVDN, '''' AS TransferOrDisconnectReason,
				CASE WHEN VD.VDN_Name IS NULL THEN '''' ELSE VD.VDN_Name END AS VDNName,
				PHONE_CODE AS ServiceNumber,CIF AS CustomerID,EMP_NAME AS CustomerIDType,  
				CUSTOMER_SEGMENT as CustomerType,CCH.DNIS, LANGUAGE, ',v_OTP_VERFIFIED_COLNAME,' AS OTPVerified,
				TPIN_VERIFIED AS TpinVerified, NRIC AS CIN, LASTMENU_1 AS Lastmenu1, LASTMENU_2 AS Lastmenu2, LASTMENU_3 AS Lastmenu3, LASTMENU_4 AS Lastmenu4,
				LAST_MENU_ID AS LastMenu,COMPANY AS ProductType,BB_CUSTOM_INDICATOR as ServiceType
				FROM Chat_Call_History AS CCH LEFT JOIN IVR_Hotline_DNIS_Mapping AS HDM ON CCH.DNIS = HDM.DNIS ');

		IF EXISTS(SELECT 1 FROM Information_schema.tables WHERE TABLE_NAME = 'VDN_DETAILS') 
		THEN
					
			SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN VDN_DETAILS VD ON FIND_IN_SET(VD.VDN_No,CCH.TRANSFER_VDN)>0');
		ELSE
					
			SET v_SQLCommand=CONCAT(v_SQLCommand , ' LEFT JOIN (SELECT '''' VDN_NAME,'''' VDN_No) VD ON FIND_IN_SET(VD.VDN_No,CCH.TRANSFER_VDN)>0');
		END IF;
		    
    		SET v_MAIN=CONCAT(v_SQLCommand  ,' WHERE IFNULL(SessionID,'''')<>'''' AND ENDDATETIME >= ''',v_DataFromDate,''' AND ENDDATETIME <= ''',v_DataToDate,'''');
    		
		SET @stmt_str = v_MAIN;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		
	END;
		
		ELSEIF ( p_Type='ACTIONS')
		THEN
		
			SELECT AgentId as AgentID, SessionID, InteractionId as InteractionID, Action, 
			STR_TO_DATE(ActionTime,'%Y%m%d%H%i%s') as ActionDateTime,
			ActionResult, Details, LoginInstanceID
			FROM TMAC_Interaction_Actions
			WHERE IFNULL(SessionID,'') <>'' AND ActionTime >= v_DataFromDate AND ActionTime <= v_DataToDate;
		
		
		ELSEIF ( p_Type='AGENTS')
		THEN
	
			SET V_SQLQuery = CONCAT('
			SELECT DISTINCT `User` AS Ani,
			AgentId as AgentID,
			T.Channel,
			SubChannel,
			T.SessionID AS SessionID,
			SubSessionId as SubSessionID,
			InteractionId as InteractionID,
			T.Direction,
			STR_TO_DATE(T.CreatedDateTime,''%Y%m%d%H%i%s'')AS CreatedDateTime,
			CreatedReason,
			Skill,
			TS.SkillName,
			CONCAT(IFNULL(A.FirstName,'''') ,'''', IFNULL(A.LastName,'''')) AS AgentName,
			Dnis as DNIS,
			DnisName as DNISName,
			IsTransfered,
			IsConferenced,
			IsReconnected AS TPinTransferReconnected,
			IsConferencedTo AS ConferencedTo,
			IsTranferedTo AS TransferedTo,
			CASE WHEN IsTransfered=1 OR IsConferenced=1 THEN TrasnferConferenceFromAgent ELSE '''' END AS TransferConferenceFromAgent,
			CASE WHEN IsTransfered=1 OR IsConferenced=1 THEN TrasnferConferenceFromInteraction ELSE '''' END AS TransferConferenceFromInteraction,
			OtherData,
			STR_TO_DATE(ClosedDateTime,''%Y%m%d%H%i%s'') AS ClosedDateTime,
			ClosedReason,
			STR_TO_DATE(CallConnectedTime,''%Y%m%d%H%i%s'') AS ConnectedDateTime,
			STR_TO_DATE(CallDisconnectedTime,''%Y%m%d%H%i%s'') AS DisconnectedDateTime,
			ActiveTime,
			HoldTime,
			TrasnferToAgent AS TransferToAgent,
			ConferenceToAgentList,
			QueueTime,
			AcwTime as ACWTime,
			ActiveTime+HoldTime+AcwTime HandleTime,
			CASE WHEN ifnull(TIUD.CIF,'''')='''' THEN IH.CIF ELSE TIUD.CIF END as CIF,
			IH.CLID AS RegisteredMobileNo,
			T.AgentComment,
			AgentWaitTimeForResponse,
			UserWaitTimeForResponse,
			Intent,
			DisconnectReason,',v_DisconnectedBy_ColName,' AS DisconnectedBy
			FROM TMAC_Interactions T
			INNER JOIN AGT_Agent A  ON A.AvayaLoginID=T.AgentId
			LEFT JOIN AGT_Agent AA  ON AA.AvayaLoginID = T.TrasnferConferenceFromAgent
			LEFT JOIN GBL_InteractionHistory IH  ON IH.SessionID=T.SessionId
			LEFT JOIN TMAC_Skills TS ON TS.SkillExtension=T.Skill
			LEFT JOIN TMAC_InteractionUserData TIUD ON TIUD.SessionId = T.SessionId
			WHERE IFNULL(T.SessionID,'''') <>'''' AND IH.ID IN (SELECT MAX(ID) FROM GBL_InteractionHistory WHERE SESSIONID=T.SessionId)
			AND ClosedDateTime>=''',v_DataFromDate,''' AND ClosedDateTime<= ''',v_DataToDate,''' ');
			
			
			SET @stmt_str = V_SQLQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			
		ELSEIF ( p_Type='USAGE')
		THEN
			SELECT IVR_Usage.ICH_CALLREFID as SessionID,
			STR_TO_DATE(concat(ICH_START_DATE,replace(ICH_START_TIME,':','')),'%Y%m%d%H%i%s') as StartDateTime,
			STR_TO_DATE(concat(ICH_END_DATE,replace(ICH_END_TIME,':','')),'%Y%m%d%H%i%s') as EndDateTime, 
			IU_ID AS MenuID,IU_MENU_NAME AS MenuName,IU_EII AS InvalidInput,IU_ENI AS NoInput,IU_EMC AS MaxCount,IU_Order AS MenuOrder,'Voice Bot' AS Channel
			FROM IVR_Usage inner JOIN IVR_Call_History ON IVR_Usage.ICH_CALLREFID=IVR_Call_History.ICH_CALLREFID
			LEFT JOIN IVR_MENU_DESC IMD ON IMD.IMD_MENU_ID=IVR_Usage.IU_ID
			WHERE IFNULL(IVR_Usage.ICH_CALLREFID,'') <>'' AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,':', ''))) >= v_DataFromDate 
			AND (concat(ICH_END_DATE,REPLACE(ICH_END_TIME,':', ''))) <= v_DataToDate
	
			UNION				

			SELECT Chat_Usage.SessionID,
			STR_TO_DATE(STARTDATETIME,'%Y%m%d%H%i%s')AS STARTDATETIME,
			STR_TO_DATE(ENDDATETIME,'%Y%m%d%H%i%s')AS ENDDATETIME,
			ID AS MenuID,CMD.MENU_NAME,EII AS InvalidInput,ENI AS NoInput,EMC AS MaxCount,`ORDER` AS MenuOrder,'Chat Bot' AS Channel
			FROM Chat_Usage inner JOIN Chat_Call_History ON Chat_Usage.SessionID=Chat_Call_History.SessionID
			LEFT JOIN Chat_Menu_Desc CMD ON CMD.MENU_ID=Chat_Usage.ID
			WHERE IFNULL(Chat_Usage.SessionID,'') <>'' AND ENDDATETIME >= v_DataFromDate AND ENDDATETIME <= v_DataToDate;
		
		ELSEIF ( p_Type='TRANSSCRIPT')	
		THEN 
			SELECT Distinct IH.SESSIONID, T.SubSessionId as GroupID,AGT_Agent.AvayaLoginID AS AgentID, InteractionText,
			STR_TO_DATE(concat(InteractionDate,InteractionTime),'%Y%m%d%H%i%s') as INTERACTIONDATETIME,IH.Direction, IH.`Channel`,IH.SubType AS SubChannel,
			CONCAT('- ', AGT_Agent.FirstName , AGT_Agent.LastName)  as SERVICEDBY,
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.FirstName ELSE CASE WHEN I.UserName IS NULL OR I.UserName ='' THEN 'Customer' ELSE I.UserName END END) as FIRSTNAME,
			(CASE WHEN upper(IH.Direction)='OUT' THEN AGT_Agent.LastName ELSE '' END) as LASTNAME,IH.ID
			FROM GBL_InteractionHistory IH  
			LEFT JOIN AGT_Agent ON AGT_Agent.AvayaLoginID = IH.InsertedBy 
			LEFT JOIN TMAC_Interactions T ON IH.SessionID=T.SessionId 
			LEFT JOIN
			( 
				SELECT distinct SessionId,UserName  FROM TMAC_Interactions  
				WHERE UserName IS NOT NULL OR UserName <>''  GROUP BY SessionId,UserName
			) I ON IH.SessionID=I.SessionId 
			WHERE IFNULL(IH.SESSIONID,'') <>'' AND IH.`Channel` in ('Chat','TextChat','AudioChat','VideoChat') AND  ClosedDateTime >= v_DataFromDate AND ClosedDateTime <= v_DataToDate
			order by ID ASC;
		
	END IF;	

END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_PersonalizeIVRReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_PersonalizeIVRReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	
	SET v_DataFromDate =  REPLACE(p_FromDate,' ',''); 
	SET v_DataToDate =REPLACE(p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
			SELECT PSR.CS_UCID as UCID,CH.ICH_CLID as CallerID,PSR.CS_CIN as CIN,PSR.CS_CINsfx as CINSuffix,CH.TPIN_VERIFIED as CallerIdentificationType,
			PSR.CS_ResponseStatus as CSSGResponseStatus,PSR.CS_ExclusionFlag as ExclusionFlag,PSR.CS_VoicePromptID as VoicePromptID,PSR.CS_ServiceID as ServiceID,
			PSR.CS_SMSAcceptance as SMSAcceptance,PSR.CS_SMS_SentStatus as SMSSentStatus,PSR.CS_SMS_SentDateTime as SMSSentDateTime,PSR.CS_SMS_MobileNo as SMSMobileNo,
			PSR.CS_SMSMobNumType as SMSMobileType,PSR.CS_URL as URLLink,PSR.CS_SMS_ICOM_TemplateID as SMSTemplateID,
			 CONCAT(ICH_START_DATE , replace(DATE_FORMAT (ICH_START_TIME, '%T'),':','')) AS CallStartDateTime,
			CONCAT(ICH_END_DATE , replace(DATE_FORMAT (ICH_END_TIME, '%T'),':','')) AS CallEndDateTime,CH.ICH_CALL_DUR as CallDuration,CH.LASTMENU_1 as LastMenu,
			CH.TPIN_VERIFIED as CallerStatus,CH.ICH_TR_DIS_FLAG as TransferFlag,CH.TRANSFER_VDN as TransferVDN,CH.TRANSFER_VDN as Intent,PSR.ReportDateTime
			FROM IVR_PersonalizedSMSReport PSR left join IVR_Call_History CH on PSR.CS_UCID=CH.ICH_CALLREFID
			Where PSR.ReportDateTime >= VARCHARTODATETIME( v_DataFromDate) and PSR.ReportDateTime <= VARCHARTODATETIME( v_DataToDate);
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_ProfanityWordsViolationReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_ProfanityWordsViolationReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN	
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		IF(p_Type = 'MAIN')
		THEN
			SELECT distinct gbl.SessionID, GroupID, NRIC as CustomerID, JSON_VALUE(Details,'$.Channel') as Channel, 
			JSON_VALUE(Details,'$.CustomerName') as CustomerName, AgentId as AgentID, 
			case when ActionResult = '-4.1' then 'Block' when ActionResult = '-4.2' then 'Mask' end as Action, 
			ActionTime as AttemptDateTime, JSON_VALUE(Details,'$.Message') as Message 
			FROM TMAC_Interaction_Actions tmac INNER JOIN GBL_InteractionHistory gbl on tmac.SessionID = gbl.SessionID 
			WHERE Action = 'ProfanityWordsViolation' AND IFNULL(GroupID,'') != '' AND 
			InsertedDateTime >= VARCHARTODATETIME(v_DataFromDate) AND InsertedDateTime <= VARCHARTODATETIME(v_DataToDate);			
		END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_RespondentSummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_RespondentSummaryReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
Declare v_MAIN LONGTEXT;
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 

	IF(p_Type = 'MAIN')
	THEN
			SELECT  C.`Name` AS RespondentName,
					R.PhoneNumber AS RespondentPhoneNumber,
					D.`count` as CallAttempts,
					CASE WHEN SC.`Status` ='MISSED' THEN 1 ELSE 0 END AS MissedCalls,
					CASE WHEN SC.`Status` ='REJECTED' THEN 1 ELSE 0 END AS RejectedCalls,
					CASE WHEN SC.`Status` ='PICKEDUP' THEN 1 ELSE 0 END AS PickedUpCalls,
					CASE WHEN SC.`Status` ='DECLINE' THEN 1 ELSE 0 END AS DeclineCalls,
					CASE WHEN IsCallback = 1 THEN 1 ELSE 0 END AS Callback,
					CASE WHEN SC.`Status` ='SUCCESS' THEN 1 ELSE 0 END AS SuccessCalls,
					R.AgentConnectTime AS AgentConnectTime
			FROM TCM_Record R
			LEFT JOIN AGT_Agent A ON R.Agent=A.AvayaLoginID
			LEFT JOIN TCM_Contact C ON C.ID=R.ContactId
			LEFT join (
					SELECT COUNT(C.ID) as `COUNT` ,ContactId  
					FROM TCM_Contact C 
					LEFT JOIN TCM_Record R on R.ContactId= C.ID 
					WHERE R.AgentConnectTime >= v_DataFromDate and R.AgentConnectTime<= v_DataToDate 
					GROUP BY ContactId )D 
			on D.ContactId = R.ContactId
			LEFT join (SELECT `Status`, CampId FROM TCM_StatusCodes 
						WHERE LastChangedOn >= v_DataFromDate AND LastChangedOn <= v_DataToDate) SC 
				on SC.CampId= R.CampId
			RIGHT JOIN 
						(SELECT DISTINCT SessionId,CALLCONNECTEDTIME, CALLDISCONNECTEDTIME
						FROM TMAC_Interactions WHERE CALLDISCONNECTEDTIME >=  v_DataFromDate and  CALLDISCONNECTEDTIME <= v_DataToDate
						AND (CALLCONNECTEDTIME !='00010101000000' AND  CALLDISCONNECTEDTIME !='00010101000000'))TI
						ON TI.SessionId=R.UCID
					WHERE TI.CALLDISCONNECTEDTIME >=  v_DataFromDate and  TI.CALLDISCONNECTEDTIME <= v_DataToDate
			GROUP BY C.`Name`,R.PhoneNumber,D.`COUNT`,SC.`Status`,R.AgentConnectTime,C.ScheduleTime,IsCallback;
		
	ELSEIF ( p_Type='SURVEYDETAILS')	
	THEN	
			SELECT  C.`Name` AS RespondentName,
					R.PhoneNumber AS RespondentPhoneNumber,
					SR.QuestionnaireName AS QuestionnaireName,
					FORMAT(SR.SurveyStartDateTime,'yyyyMMddHHmmss') AS SurveyStartDateTime,
					FORMAT(SR.SurveyEndDateTime,'yyyyMMddHHmmss') AS SurveyEndDateTime,
					SD.QuestionId AS QuestionID,
					SD.Question,
					CASE WHEN SD.AnswerType ='custom' THEN REPLACE(SD.MaskedAnswer,'||',', ') ELSE REPLACE(SD.Answers,'||',', ') END AS Answers,
					FORMAT(SD.StartDateTime,'yyyyMMddHHmmss') AS ResponseStartDateTime,
					FORMAT(SD.EndDateTime,'yyyyMMddHHmmss') AS ResponseEndDateTime,
					IFNULL(SUM(TIMESTAMPDIFF(SECOND,SD.StartDateTime, SD.EndDateTime)),0) AS ResponseTime,
					SR.SessionId AS SurveyID, 
					SR.Intent AS Intent
			FROM TCM_Contact C
			LEFT JOIN TCM_Record R ON R.ContactId=C.ID
			LEFT JOIN TAS_SurveyResult SR ON SR.CampaignId=C.CampId
			LEFT JOIN TAS_SurveyDetails SD ON SD.SessionId=SR.SessionId 
			RIGHT JOIN 
						(SELECT DISTINCT SessionId,CALLCONNECTEDTIME, CALLDISCONNECTEDTIME
						FROM TMAC_Interactions WHERE CALLDISCONNECTEDTIME >=  v_DataFromDate and  CALLDISCONNECTEDTIME <= v_DataToDate AND
						 (CALLCONNECTEDTIME !='00010101000000' AND  CALLDISCONNECTEDTIME !='00010101000000'))TI
						ON TI.SessionId=R.UCID
					WHERE TI.CALLDISCONNECTEDTIME >=  v_DataFromDate and  TI.CALLDISCONNECTEDTIME <= v_DataToDate
			GROUP BY C.`Name`,R.PhoneNumber,SR.QuestionnaireName,SR.SurveyStartDateTime,SR.SurveyEndDateTime,SD.QuestionId,SD.Question,SD.AnswerType,SD.MaskedAnswer,SD.Answers,SD.StartDateTime,SD.EndDateTime,SR.SessionId,SR.Intent;
	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_RollAccessReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_RollAccessReport`()
begin
		DECLARE   v_SQLPivotQuery LONGTEXT;
		DECLARE   v_PivotColumns LONGTEXT;
		DECLARE   v_PivotColumns1 LONGTEXT;
		DECLARE   v_PivotColumnsDisplay LONGTEXT;
		DECLARE 	 v_PivotForUserAccess LONGTEXT;
		DECLARE   v_PivotForAddAccess LONGTEXT;
		DECLARE   v_PivotForEditAccess LONGTEXT;
		DECLARE   v_PivotForDeleteAccess LONGTEXT;
		DECLARE   v_PivotForExportAccess LONGTEXT;

		SET SESSION group_concat_max_len = 1000000;

		SELECT GROUP_CONCAT( 'IFNULL(', QUOTENAME(PageName) , ',''Disable'')' , QUOTENAME(PageName)) INTO v_PivotColumns1
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;

		/* print v_PivotColumns1; */

      SELECT GROUP_CONCAT(QUOTENAME(PageName)) INTO v_PivotColumns
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;
		
		/* print v_PivotColumns; */
		
		SELECT GROUP_CONCAT('MIN(CASE WHEN PageName = "', PageName , '" THEN USER_ACCESS END) ' , QUOTENAME(PageName)) INTO v_PivotForUserAccess
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;
		
		SELECT GROUP_CONCAT('MIN(CASE WHEN PageName = "', PageName , '" THEN ADD_ACCESS END) ' , QUOTENAME(PageName)) INTO v_PivotForAddAccess
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;
		
		SELECT GROUP_CONCAT('MIN(CASE WHEN PageName = "', PageName , '" THEN EDIT_ACCESS END) ' , QUOTENAME(PageName)) INTO v_PivotForEditAccess
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;
		
		SELECT GROUP_CONCAT('MIN(CASE WHEN PageName = "', PageName , '" THEN DELETE_ACCESS END) ' , QUOTENAME(PageName)) INTO v_PivotForDeleteAccess
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;
		
		SELECT GROUP_CONCAT('MIN(CASE WHEN PageName = "', PageName , '" THEN EXPORT_ACCESS END) ' , QUOTENAME(PageName)) INTO v_PivotForExportAccess
		FROM (SELECT DISTINCT PageName FROM CMM_Role_Pages) AS PivotTbl;

		SET   v_SQLPivotQuery = 
		CONCAT(N'SELECT DISTINCT R.RoleName,R.Roleid,Access,' ,   v_PivotColumns1 , '
		FROM  (select 1 id,Roleid, ''View Access'' Access,' , v_PivotForUserAccess , ' from CMM_Role_Pages
		UNION all
		select 2  id, Roleid, ''Add Access'' Access,',v_PivotForAddAccess ,' from CMM_Role_Pages
		UNION all
		select 3 id, Roleid, ''Edit Access'' Access ,',v_PivotForEditAccess,' from CMM_Role_Pages
		UNION all
		select 4  id,Roleid, ''Delete Access'' Access,',v_PivotForDeleteAccess,' from CMM_Role_Pages
		UNION all
		select 6 id,Roleid, ''Export Access'' Access,',v_PivotForExportAccess,' from CMM_Role_Pages 
		) as P inner join CMM_Roles R on P.RoleID=R.RoleID order by roleid');

		#select v_SQLPivotQuery;

		set @stmt_str = v_SQLPivotQuery;
		prepare stmt from @stmt_str;
		execute stmt;
		deallocate prepare stmt;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SkillHistoricalReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SkillHistoricalReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
			SELECT  Skill as SkillId,
			SkillName,
			AcdCalls as AcdCalls,
			convert(left(`Interval`,LOCATE(':',`Interval`)-1),UNSIGNED) as Intvl,
			date_format(`DATE`,120)as DateInt,
			REPLACE(`interval`,'- ','-')  as `Interval`,
			case when Avgspeedans ='**:**' then '0' 
				else  left(Avgspeedans, LOCATE(':', Avgspeedans)-1)* 60 + substring(Avgspeedans, LOCATE(':', Avgspeedans)+1,2)  end as AvgSpeedAnswer, 
			AbanCalls as AbandCalls,
			case when AvgAbandTime ='**:**' then '0' 
				else left(AvgAbandTime, LOCATE(':', AvgAbandTime)-1)* 60 + substring(AvgAbandTime, LOCATE(':', AvgAbandTime)+1,2) end as AvgAbandTime, 
			case when AvgTalkTime ='**:**' then '0'
				else left(AvgTalkTime, LOCATE(':', AvgTalkTime)-1)* 60 + substring(AvgTalkTime, LOCATE(':', AvgTalkTime)+1,2)  end as AvgTalkTime,
			case when TotalAfterCall ='**:**' then '0' 
				else left(TotalAfterCall, LOCATE(':', TotalAfterCall)-1)* 60 + substring(TotalAfterCall, LOCATE(':', TotalAfterCall)+1,2) end as TotalAfterCallTime,
			FlowIn as FlowIn,
			FlowOut as FlowOut,
			case when TotalAux ='**:**' then '0'
				else left(TotalAux, LOCATE(':', TotalAux)-1)* 60 + substring(TotalAux, LOCATE(':', TotalAux)+1,2)  end  as TotalAux,
			AvgStaff as AvgStaff,
			PercentageServiceLevel as ServiceLevel,
			`date` as StartDateTime
		 from `TMAC_H.Skill`
		 where `date`>=v_DataFromDate AND `date`<=v_DataToDate and `Interval` <> 'SUMMARY';
		END;
	END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SmsHostTransactionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SmsHostTransactionReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate =  VARCHARTODATETIME(REPLACE(p_FromDate,' ',''));    
	SET v_DataToDate = VARCHARTODATETIME(REPLACE(p_ToDate,' ',''));  
	
	IF(p_Type = 'MAIN')
	THEN
			SELECT replace(CONCAT(DATE_FORMAT(IVR_TRL.REQUEST_DATE, '%Y%m%d'),DATE_FORMAT(IVR_TRL.REQUEST_DATE, 114)),':','') AS RequestDateTime,
				   replace(CONCAT(DATE_FORMAT(IVR_TRL.RESPONSE_DATE, '%Y%m%d'),DATE_FORMAT(IVR_TRL.RESPONSE_DATE, 114)),':','') AS ResponseDateTime,
				   IVR_TRL.UCID AS SessionID, 
				   IVR_TRL.TRANSACTION_NAME AS TransactionName, 
				   IVR_TRL.REQ_MESSAGE AS RequestMessage,  
				   IVR_TRL.RES_MESSAGE AS ResponseMessage
			FROM  IVR_TRL 
			INNER JOIN Notify_Processor ON IVR_TRL.UCID =  convert(Notify_Processor.NotifyRequestId, char)
			Where IVR_TRL.RESPONSE_DATE >= v_DataFromDate and IVR_TRL.RESPONSE_DATE <= v_DataToDate;

	END IF;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SMSInteractionReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SMSInteractionReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
					SELECT  T.UCID AS SessionID,
							NP.PrimaryRecipient as Identification,
							T.REQUEST_DATE AS StartDateTime,
							T.RESPONSE_DATE AS EndDateTime,
							NR.Message AS RequestMessage
					FROM  IVR_TRL  T 
					INNER JOIN Notify_Processor NP ON T.UCID = convert(NP.NotifyRequestId, char)
					LEFT JOIN `Notify_Requests` NR ON NR.RequestId = NP.NotifyRequestId					
					LEFT JOIN GBL_InteractionHistory H ON H.SessionID = T.UCID
					Where T.RESPONSE_DATE >= VARCHARTODATETIME(REPLACE(v_DataFromDate,' ','')) 
					 AND T.RESPONSE_DATE <= VARCHARTODATETIME(REPLACE(v_DataToDate,' ',''));
	ELSEIF ( p_Type='TRANSSCRIPT')
	THEN
			SELECT  
					GBL_InteractionHistory.SessionID as SESSIONID,
					InteractionText, 
					CONCAT(InteractionDate,InteractionTime) as INTERACTIONDATETIME,
					Direction, 
					CONCAT(AGT_Agent.FirstName , AGT_Agent.LastName)  as SERVICEDBY, 
					AGT_Agent.FirstName as FIRSTNAME, 
					AGT_Agent.LastName  as LASTNAME
				FROM GBL_InteractionHistory 
				LEFT JOIN AGT_Agent ON AGT_Agent.AvayaLoginID = GBL_InteractionHistory.InsertedBy
				WHERE GBL_InteractionHistory.`Channel` in ('SMS')  
				and CONCAT(GBL_InteractionHistory.InteractionDate,GBL_InteractionHistory.InteractionTime) >= v_DataFromDate
				and CONCAT(GBL_InteractionHistory.InteractionDate,GBL_InteractionHistory.InteractionTime) <= v_DataToDate
				order by InteractionTime ASC;
	END IF;
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SMSReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SMSReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
			SELECT SMSReport.UCID,
				   SMSReport.CallerID,
				   SMSReport.Entered_CIN as EnteredCIN,
				   SMSReport.RegMob_CIN as RegMobCIN,
				   SMSReport.SMS_SentStatus as SMSSentStatus,
				   SMS_SentDateTime AS SMSSentDateTime,
				   SMSReport.SMS_MobileNo as SMSMobileNo,
				   ifnull(convert(SMSReport.OCM_TemplateID, char),'NA')  as OCMTemplateID,
				   ICOM_TemplateID as ICOMTemplateID ,
				   SMSReport.SMS_MarketingPromptPoint as SMSMarketingPromptPoint,
				   SMSReport.SMS_TriggeredPoint as SMSTriggeredPoint,
				   SMSReport.TerminatedorContinued as  TerminateOrContinue,
				   ifnull(SMS_Template.`Text`,'NA') TemplateMessage,
				   SMSOfferedDateTime
	   
			FROM SMSReport left join SMS_Template on SMSReport.OCM_TemplateID=SMS_Template.ID
			where 1=1 AND SMSOfferedDateTime>=v_DataFromDate AND SMSOfferedDateTime<=v_DataToDate;
			
		END;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SMSTraceReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SMSTraceReport`(
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
	SET v_DataToDate = REPLACE(p_ToDate,' ', ''); 

	SELECT sessionid as SessionID, outgoingnumber as OutgoingNumber, agentid as AgentID, 
	`message` as Message, sendtimestamp as SentDateTime,
	case when apiresponse=1 then 'Success' else 'Failure' end as Status
	FROM smshistory 
	WHERE sendtimestamp >= VARCHARTODATETIME(v_DataFromDate) and 
	sendtimestamp <= VARCHARTODATETIME(v_DataToDate);
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_SurveySummaryReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_SurveySummaryReport`(
p_Type VARCHAR(100),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

BEGIN
	SET v_DataFromDate = REPLACE(p_FromDate,' ','');
	SET v_DataToDate =REPLACE( p_ToDate,' ','');
	
	IF(p_Type = 'MAIN')
	THEN
 			SELECT C.`Name` AS RespondentName,
					R.PhoneNumber AS RespondentPhoneNumber,
					R.Agent AS OperatorID, 
					CONCAT(A.FirstName,' ',A.LastName) AS OperatorName,
					S.SessionId AS SurveyID,
					S.StationId AS ExtensionNumber,
					R.UCID AS UCID,
					TI.CALLCONNECTEDTIME AS CallConnectedDateTime,
					TI.CALLDISCONNECTEDTIME AS CallDisconnectedDateTime,
					Ifnull(sum(TI.CallDuration),0) AS CallDuration,
					S.QuestionnaireName AS QuestionnaireName,
					S.Intent AS Intent,
					Ifnull(sum(G.HitCount),0) AS HelpHitCount,
					FORMAT(S.InsertedDateTime,'yyyyMMddHHmmss') AS SurveyCreatedDateTime,
					FORMAT(S.LastUpdatedDateTime,'yyyyMMddHHmmss') AS SurveyLastModifiedDateTime,
					S.InsertedBy AS SurveyCreator
					FROM TCM_Record R		
					LEFT JOIN AGT_Agent A ON R.Agent=A.AvayaLoginID
					LEFT JOIN TCM_Contact C ON C.ID=R.ContactId
					LEFT JOIN TAS_SurveyResult S ON S.UCID=R.UCID
					LEFT JOIN 
						(SELECT DISTINCT  GC.SurveyResultId,sum(HitCount) AS HitCount  FROM TAS_GlossaryCounts GC
						 LEFT JOIN TAS_SurveyResult SD  ON GC.SurveyResultId=SD.SessionId 
						 WHERE FORMAT(GC.InsertedDateTime, 'yyyyMMddHHmmss') >=  v_DataFromDate and  FORMAT(GC.InsertedDateTime,'yyyyMMddHHmmss') <= v_DataToDate
						 GROUP BY GC.SurveyResultId)G 
					ON G.SurveyResultId= S.SessionId
					RIGHT JOIN 
						(SELECT DISTINCT AgentId, SessionId,CALLCONNECTEDTIME, CALLDISCONNECTEDTIME, SUM(TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(CALLCONNECTEDTIME, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
							CONVERT(INSERT(INSERT(INSERT(CALLDISCONNECTEDTIME, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) AS CallDuration 
						FROM TMAC_Interactions WHERE CALLDISCONNECTEDTIME >=  v_DataFromDate and  CALLDISCONNECTEDTIME <= v_DataToDate
						AND (CALLCONNECTEDTIME !='00010101000000' AND  CALLDISCONNECTEDTIME !='00010101000000')
						GROUP BY AgentId,CALLCONNECTEDTIME,CALLDISCONNECTEDTIME,SessionId)TI
						ON TI.SessionId=R.UCID
					WHERE TI.CALLDISCONNECTEDTIME >=  v_DataFromDate and  TI.CALLDISCONNECTEDTIME <= v_DataToDate
					GROUP BY TI.CALLCONNECTEDTIME,TI.CALLDISCONNECTEDTIME,C.Name,R.PhoneNumber,R.Agent,A.FirstName,A.LastName,S.SessionId,
					S.StationId,R.UCID,S.QuestionnaireName,S.Intent,S.InsertedDateTime,S.InsertedBy,S.LastUpdatedDateTime;

	END IF;
	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_UserListingReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_UserListingReport`(
  p_AgentHierarchyQuery VARCHAR(8000),
  p_TeamCteQuery   VARCHAR(8000),
  p_SupervisorCteQuery VARCHAR(8000),
  p_CurrentDateTime DATETIME(3)
)
BEGIN
	#DECLARE fn_STATUS INT DEFAULT 0;
	#set fn_STATUS := fn_AgentHierarchy('NA',p_TeamFilter,p_UserIdFilter);
	#SELECT * FROM AgentHierarchyResult;
	
	SET @Query = concat(p_TeamCteQuery,
	p_SupervisorCteQuery,
	'select distinct A.UserName UserID,A.FirstName,A.LastName,M.SupervisorName,M.TeamName, LastLoginDateTime,
	case when IFNULL(`Enabled`,1) = 1 then ''Yes'' else ''No'' end Enabled,
	case when IFNULL(`Locked`,0)=1 then ''Yes'' else ''No'' end Locked,OCMRole.RoleName,OCMRole.RoleAccess,
	case when IFNULL(`IsDormant`,0) = 1 then ''DORMANT'' when A.PrimarySupervisorID=0 then NULL ELSE 
	CONVERT(FLOOR((TIMESTAMPDIFF(HOUR, ''',p_CurrentDateTime,''', STR_TO_DATE(
	DATE_ADD((case when ifnull(AP.LastLoggedInAt,'''') = '''' then A.CreatedDateTime else AP.LastLoggedInAt end), INTERVAL AA.Threshold DAY)
	,''%Y-%m-%d %H:%i:%s'')))/24), CHAR) END AS ExpiryDays, AA.AppName FROM 
	AGT_Agent A LEFT JOIN CMM_User_Details C ON C.UserName=A.UserName AND IsDeleted=0 
	LEFT JOIN AGT_AppLogin_Track AP  ON C.UserName =AP.UserID LEFT JOIN AGT_Apps AA ON AA.AppName = AP.AppName
	CROSS JOIN LATERAL ( 
	SELECT  distinct (SELECT  GROUP_CONCAT(distinct RoleName) from CMM_Roles R 
	INNER JOIN CMM_Role_Pages RP on RP.RoleID=R.RoleID 
	where RP.USER_ACCESS=''Enable'' AND R.RoleID IN (C.RoleID) ) AS RoleName  ,
	(SELECT  GROUP_CONCAT(distinct R.RoleID) from CMM_Roles R INNER JOIN CMM_Role_Pages RP on RP.RoleID=R.RoleID  
	where RP.USER_ACCESS=''Enable'' AND R.RoleID IN (C.RoleID) ) As RoleID,
	(SELECT GROUP_CONCAT(distinct PageName) from CMM_Roles R INNER JOIN CMM_Role_Pages RP on RP.RoleID=R.RoleID 
	where RP.USER_ACCESS=''Enable'' AND R.RoleID IN (C.RoleID) ) AS RoleAccess
	FROM `CMM_Roles` R INNER JOIN `CMM_Role_Pages` RP on RP.RoleID=R.RoleID 
	where RP.USER_ACCESS=''Enable'' AND R.RoleID IN (C.RoleID) 
	) As OCMRole 
	 ', p_AgentHierarchyQuery, ' M on A.AvayaLoginID=M.AgentID');
	 
	      SET @stmt_str = @Query;
			PREPARE stmt1 FROM @stmt_str;
	 		EXECUTE stmt1;
	 		DROP PREPARE stmt1;
	 		
end//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_OCM_VBCallbackDetailReport
DELIMITER //
CREATE PROCEDURE `Get_OCM_VBCallbackDetailReport`(

p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20) )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
		SET v_DataFromDate = REPLACE(p_FromDate, ' ', '');
		SET v_DataToDate =REPLACE(p_ToDate,' ', ''); 
		
		BEGIN
			SELECT 
					VB_Callback.MobileNumber,
					VB_Callback.CIN,
					VB_Callback.CINSuffix,
					VB_Callback.UCID,
					VB_Callback.RegMobileStatus AS RegisteredMobileStatus,
					substring(replace(replace(replace(date_format(RegDateTime,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),0,15) AS RegisteredDateTime
		   FROM VB_Callback   
		   where 1=1 AND substring(replace(replace(replace(date_format(RegDateTime,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),0,15) >=v_DataFromDate
					AND substring(replace(replace(replace(date_format(RegDateTime,'%Y-%m-%d %T.%f'),'-',''),':',''),' ',''),0,15)<=v_DataToDate;
			
		END;
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Pending_Email_Report
DELIMITER //
CREATE PROCEDURE `Get_Pending_Email_Report`(
	p_Type VARCHAR(50),
	p_FromDate VARCHAR(20),
	p_Todate VARCHAR(20),
	p_OrgUnit TEXT
)
BEGIN
	IF(p_Type = 'WorkingDay' OR p_Type = 'CalendarDay')
	THEN
	Select grouptab.SkillName,SUM(grouptab.TotalEmails) as TotalEmails,  
	min(grouptab.OldestEmail) as OldestEmail, 
	sum(grouptab.Email_1_Day) as 'Email_1_Day',
	sum(grouptab.Email_2_Day) as 'Email_2_Day',
	sum(grouptab.Email_3_Day) as 'Email_3_Day',
	sum(grouptab.Email_5_Day) as 'Email_5_Day',
	sum(grouptab.Email_10_Day) as 'Email_10_Day',
	sum(grouptab.Email_14_Day) as 'Email_14_Day',
	sum(grouptab.Email_15_Day) as 'Email_15_Day'
	from (
	Select S.SkillName as SkillName,ifnull(Count(1),0) as TotalEmails,MIN(tab.OldestEmail) as OldestEmail,
	case when tab.`Type` = '0-1' Then ifnull(Count(1),0) else 0 END AS 'Email_1_Day' ,
	case when tab.`Type` = '1-2' Then ifnull(Count(1),0) else 0 END AS 'Email_2_Day' ,
	case when tab.`Type` = '2-3' Then  ifnull(Count(1),0) else 0 END AS 'Email_3_Day' ,
	case when tab.`Type` = '3-5' Then ifnull(Count(1),0) else 0 END AS 'Email_5_Day' ,
	case when tab.`Type` = '5-10' Then ifnull(Count(1),0) else 0 END AS 'Email_10_Day' ,
	case when tab.`Type` = '10-14' Then ifnull(Count(1),0)else 0 END AS 'Email_14_Day' ,
	case when tab.`Type` = '15-15' Then ifnull(Count(1),0) else 0 END AS 'Email_15_Day' 
	from (
	select (case when t.DaysAgo between 0 and 1 then '0-1'
	when t.DaysAgo between 1 and 2 then '1-2'
	when t.DaysAgo between 2 and 3 then '2-3'
	when t.DaysAgo between 3 and 5 then '3-5'
	when t.DaysAgo between 5 and 10 then '5-10'
	when t.DaysAgo between 10 and 14 then '10-14'
	when t.DaysAgo >14 then '15-15'
	else '15-15'
	end) as `Type`,
	t.OldestEmailInQueue OldestEmail,
	a.Skill,a.RouteDateTime,a.SessionID
	from (SELECT Skill,RouteDateTime,R.SessionID
	FROM Email_Routes R
	Inner join Email_Inbox I on I.SessionID = R.SessionID
	WHERE I.CurrentStatus NOT IN( 'DirectEmailAnswered','Close','CloseWithReply', 'Closewithoutreply','Answered','SentToCustomer')   
	AND R.CurrentStatus NOT IN( 'DirectEmailAnswered', 'Closed','CloseWithReply', 'Closewithoutreply','Answered','Replied')   
	AND RouteDateTime Between  p_FromDate AND p_Todate AND Skill IS NOT NULL AND
	Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit))
	) a INNER JOIN
	(SELECT Skill,R.SessionID, MAX(RouteDateTime) as OldestEmailInQueue,
	TIMESTAMPDIFF(DAY, SUBSTRING(RouteDateTime,0,9), now(3)) as DaysAgo
	FROM Email_Routes R
	Inner join Email_Inbox I on I.SessionID = R.SessionID
	WHERE I.CurrentStatus NOT IN( 'DirectEmailAnswered','Close', 'CloseWithReply', 'Closewithoutreply','Answered','SentToCustomer')  
	AND R.CurrentStatus NOT IN( 'DirectEmailAnswered', 'Closed','CloseWithReply', 'Closewithoutreply','Answered','Replied')  
	AND RouteDateTime Between  p_FromDate AND p_Todate AND Skill IS NOT NULL AND
	Mailbox IN (SELECT DISTINCT MailAccountName FROM Email_AccountConfiguration C INNER JOIN email_account_teamlist T ON C.MailAccountID = T.mailaccountid WHERE FIND_IN_SET(teamid,p_OrgUnit))
	GROUP BY R.SessionID,Skill,RouteDateTime
	) t
	on a.SessionID = t.SessionID and a.Skill = t.Skill	
	group by  (case when t.DaysAgo between 0 and 1 then '0-1'
	when t.DaysAgo between 1 and 2 then '1-2'
	when t.DaysAgo between 2 and 3 then '2-3'
	when t.DaysAgo between 3 and 5 then '3-5'
	when t.DaysAgo between 5 and 10 then '5-10'
	when t.DaysAgo between 10 and 14 then '10-14'
	when t.DaysAgo >14 then '15-15'
	else '15-15'
	end),a.SessionID,a.Skill,a.RouteDateTime,t.OldestEmailInQueue) as tab 
	Inner join (SELECT DISTINCT MakerSkill from Email_SkillMap) SkillMap on SkillMap.MakerSkill=tab.Skill
	left join TMAC_Skills S On tab.Skill = S.SkillExtension
	Group by tab.`Type`,S.SkillName) as grouptab Group by grouptab.SkillName;
END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_Sms_DashboardData
DELIMITER //
CREATE PROCEDURE `Get_Sms_DashboardData`(
  p_dnis varchar(1000),p_startdate VARCHAR(20),p_enddate VARCHAR(20), p_type varchar(20)
)
BEGIN
	DECLARE v_TotalSmsCount INT;
	DECLARE v_AverageHandleTime INT;
	DECLARE v_TransferedSmsCount INT;
	DECLARE v_ConferencedSmsCount INT;
	DECLARE v_FirstCallResolution INT;
	DECLARE v_MaxHandleTime INT;
	
	DECLARE v_TotalCount INT;
	DECLARE v_TotalClosedCount INT;
	DECLARE v_TransferedCount INT;
	DECLARE v_ConferencedCount INT;
	
IF(p_type='summarydata')
THEN
	
	Set v_TotalSmsCount = IfNull((select COUNT(1) as SmsCount from GBL_InteractionHistory H 
	Inner Join TMAC_Interactions T On T.SessionId = H.SessionID where H.`Channel`='Sms' 
	AND FIND_IN_SET(Dnis,p_dnis)>0 and H.InteractionDate>=p_startdate 
	AND H.InteractionDate<=p_enddate),0);
	
	Set v_AverageHandleTime = Ifnull((select count(1) from GBL_InteractionHistory 
	where `Channel`='Sms'and InteractionDate>=p_startdate AND 
	InteractionDate<=p_enddate)/NULLIF((select count(1) from AGT_Agent_Profile,AGT_Agent 
	where AGT_Agent.AvayaLoginID=AGT_Agent_Profile.AgentID and AGT_Agent_Profile.Sms='1'),0),0);

	Set v_TransferedSmsCount = IfNull((select count(IsTransfered) as Transfered from TMAC_Interactions 
	where `Channel`='Sms' and CreatedDateTime>=(Concat(p_startdate,'000000')) and 
	CreatedDateTime<=(Concat(p_enddate,'125959')) and IsTransfered='1' and 
	FIND_IN_SET(Dnis,p_dnis)>0),0);
	
	Set v_ConferencedSmsCount = IfNull((select count(IsConferenced) as Conferenced from TMAC_Interactions 
	where `Channel`='Sms' and CreatedDateTime>=(Concat(p_startdate,'000000')) and 
	CreatedDateTime<=(Concat(p_enddate,'125959')) and IsConferenced='1' and 
	FIND_IN_SET(Dnis,p_dnis)>0),0);
	
	Set v_FirstCallResolution = IFNULL((v_TransferedSmsCount + v_ConferencedSmsCount ) / NULLIF((select count(1) 
	from AGT_Agent_Profile,AGT_Agent where AGT_Agent.AvayaLoginID=AGT_Agent_Profile.AgentID 
	and AGT_Agent_Profile.Sms='1'),0),0);
	
	Set v_MaxHandleTime = Ifnull((select count(1) from GBL_InteractionHistory where `Channel`='Sms' 
	and InteractionDate>=p_startdate AND InteractionDate<=p_enddate)/NULLIF((select count(1) from 
	AGT_Agent_Profile,AGT_Agent where AGT_Agent.AvayaLoginID=AGT_Agent_Profile.AgentID),0),0);

	Select v_TotalSmsCount AS SmsCount, v_AverageHandleTime AS AverageHandleTime, v_TransferedSmsCount AS Transfered, 
	v_ConferencedSmsCount AS Conferenced, v_FirstCallResolution AS FirstCallResolution, 
	v_MaxHandleTime as MaxHandleTime;
END IF;

IF(p_type='performancedata')
	THEN
	
	Set v_TotalCount = IfNull((select COUNT(1) as ChatCount from GBL_InteractionHistory H 
	Inner Join TMAC_Interactions T On T.SessionId = H.SessionID where H.`Channel`='Sms' and 
	FIND_IN_SET(Dnis,p_dnis)>0 and H.InteractionDate>=p_startdate 
	AND H.InteractionDate<=p_enddate),0);

	Set v_TotalClosedCount = IfNull((select COUNT(1) as ChatCount from GBL_InteractionHistory H 
	Inner Join TMAC_Interactions T On T.SessionId = H.SessionID where H.`Channel`='Sms' and 
	FIND_IN_SET(Dnis,p_dnis)>0 and ClosedDateTime!='' AND 
	H.InteractionDate>=p_startdate AND H.InteractionDate<=p_enddate),0);
	
	Set v_TransferedCount = IfNull((select count(IsTransfered) as Transfered from TMAC_Interactions 
	where `Channel`='Sms' and CreatedDateTime>=(Concat(p_startdate,'000000')) and 
	CreatedDateTime<=(Concat(p_enddate,'125959')) and IsTransfered='1' and 
	FIND_IN_SET(Dnis,p_dnis)>0),0);
	
	Set v_ConferencedCount = IfNull((select count(IsConferenced) as Conferenced from TMAC_Interactions 
	where `Channel`='Sms' and CreatedDateTime>=(Concat(p_startdate,'000000')) and 
	CreatedDateTime<=(Concat(p_enddate,'125959')) and IsConferenced='1' and 
	FIND_IN_SET(Dnis,p_dnis)>0),0);

	Select v_TotalCount AS TotalSms, v_TotalClosedCount AS ClosedSms, v_TransferedCount AS TransferedSms, 
	v_ConferencedCount AS ConferencedSms;

END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_SocialMediaInteraction
DELIMITER //
CREATE PROCEDURE `Get_SocialMediaInteraction`(
p_SessionID varchar(100),
p_Type varchar(100),
p_Channel varchar(100)
)
BEGIN	
IF(p_Type = 'callBack')
THEN
	DROP TEMPORARY TABLE IF EXISTS CALLBACKTABLE;
	CREATE TEMPORARY TABLE CALLBACKTABLE (SESSIONID VARCHAR(50),CALLBACKSTATUS VARCHAR(10),CALLBACKDATE VARCHAR(10),CALLBACKTIME VARCHAR(10),CALLBACKCOUNT INT);
	INSERT INTO CALLBACKTABLE
	Select SessionID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME, COUNT(1) as CALLBACKCOUNT FROM IVR_CALLBACK_REQUESTS R
	INNER JOIN GBL_Interaction_CustomData C on C.SessionID  = R.UCID AND C.`Name`='ChatToCallback' AND C.SESSIONID = p_SessionID 		
	GROUP By SessionID,R.CALLBACK_STATUS,R.CALLBACK_DATE,R.CALLBACK_TIME;
	
	SELECT SESSIONID,CALLBACKSTATUS,CALLBACKDATE,CALLBACKTIME,CALLBACKCOUNT FROM CALLBACKTABLE;
ELSE
	SELECT Distinct GBL_INTERACTIONHISTORY.SESSIONID as SESSIONID,INTERACTIONTEXT, INTERACTIONDATE,INTERACTIONTIME,DIRECTION, 
	CONCAT(AGT_AGENT.FIRSTNAME , AGT_AGENT.LASTNAME)  as SERVICEBY, AGT_AGENT.FIRSTNAME as FIRSTNAME, AGT_AGENT.LASTNAME  as LASTNAME
	FROM (GBL_INTERACTIONHISTORY  
	LEFT JOIN AGT_INTERACTION_SERVICE_HISTORY  
	ON GBL_INTERACTIONHISTORY.SESSIONID = AGT_INTERACTION_SERVICE_HISTORY.SESSIONID) 
	INNER JOIN AGT_AGENT ON AGT_AGENT.AVAYALOGINID = AGT_INTERACTION_SERVICE_HISTORY.SERVICEDBY 
	WHERE GBL_InteractionHistory.`Channel` = p_Channel AND GBL_INTERACTIONHISTORY.SESSIONID  = p_SessionID
	order by InteractionTime ASC;
END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_TmacReport
DELIMITER //
CREATE PROCEDURE `Get_TmacReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20),
p_LoginDate VARCHAR(20), 
p_LogoutDate VARCHAR(20),
p_AgentID VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate;
	--  SQLINES DEMO *** ata for calltrace
	IF(p_Type = 'MAIN')
	THEN	
		SELECT DISTINCT I.ID,I.AgentID,A.UserName,I.StationID,CONCAT(I.LoginDate,I.LoginTime) AS LoginDateTime,CONCAT(I.LogoutDate,I.LogoutTime) AS LogoutDateTime
		,I.SkillList FROM AGT_Agent_TimeTrack I LEFT JOIN AGT_Agent A ON A.AvayaLoginID=I.AgentID
		 LEFT JOIN TMAC_Interactions T ON T.AgentID=I.AgentID 
		WHERE A.UserName != 'NULL' AND  CONCAT(LoginDate,LoginTime)>=v_DataFromDate AND CONCAT(LoginDate,LoginTime)<=v_DataToDate;
	END IF;
	
	IF(p_Type = 'DRILL')
	THEN	
		SELECT `User` as ANI,AgentId,`Channel`,SessionID,Direction,CreatedDateTime,
		Skill,A.UserName,Dnis,IsTransfered,IsConferenced,IsReconnected,AA.UserName AS TransferConferenceFromAgent
         ,CallConnectedTime AS CallConnectedDateTime,CallDisconnectedTime AS CallDisconnectedDateTime,ActiveTime,HoldTime 
        FROM TMAC_Interactions T LEFT JOIN AGT_Agent A ON A.AvayaLoginID=T.AgentId 
        LEFT JOIN AGT_Agent AA ON AA.AvayaLoginID=T.TrasnferConferenceFromAgent 
        where 1=1  AND  CreatedDateTime>=p_LoginDate AND CreatedDateTime<=p_LogoutDate AND AgentId = p_AgentID; 
	   
	END IF;	

END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.Get_WakeUpCallReport
DELIMITER //
CREATE PROCEDURE `Get_WakeUpCallReport`(
p_Type VARCHAR(20),
p_FromDate VARCHAR(20), 
p_ToDate VARCHAR(20))
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);
BEGIN
	SET v_DataFromDate = p_FromDate; 
	SET v_DataToDate = p_ToDate;
	IF(p_Type = 'MAIN')
	THEN	
		SELECT W.ID,W.`Number`,W.`Language`,W.`Type`,W.WakeupDate,W.WakeupTime,W.CreatedDate,W.CreatedTime,W.CreatedBy,W.`Status`,IFNULL(W.NumberOfAttempts,0) NumberOfAttempts,W.LastAttemptDate,W.LastAttemptTime
                ,W.LastAttemptStatus,W.StatusChangedDate,W.StatusChangedTime,W.StatusChangedBy, CONCAT(A.FirstName , ' ' ,A.LastName) AS AvayaFullName,
                 CONCAT(B.FirstName , ' ' ,B.LastName) AS CreatedByName,IFNULL(RoomChanged,'0') AS RoomChanged,FailedReason FROM MBS_WAKEUP_CALLS W 
                 LEFT JOIN AGT_Agent A on W.StatusChangedBy=A.AvayaLoginID 
                LEFT JOIN AGT_Agent B on W.CreatedBy=B.AvayaLoginID WHERE CONCAT(W.WakeupDate,W.WakeupTime)>=p_FromDate AND CONCAT(W.WakeupDate,W.WakeupTime)<=p_ToDate;
	END IF;

END;
END//
DELIMITER ;

-- Dumping structure for table OCM.HeartBeat
CREATE TABLE IF NOT EXISTS `HeartBeat` (
  `ServerID` int DEFAULT NULL,
  `LastUpdateTime` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.ISDATE
DELIMITER //
CREATE FUNCTION `ISDATE`(datetimeString VARCHAR(30),formatString VARCHAR(30)) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
 return case when STR_TO_DATE(datetimeString, formatString) IS NOT NULL then 1 ELSE 0 END;
END//
DELIMITER ;

-- Dumping structure for table OCM.IServeAgentConfiguration
CREATE TABLE IF NOT EXISTS `IServeAgentConfiguration` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `PilotUserMode` bit(1) DEFAULT NULL,
  KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Active_Session
CREATE TABLE IF NOT EXISTS `IVR_Active_Session` (
  `UCID` varchar(50) DEFAULT NULL,
  `CLID` varchar(20) DEFAULT NULL,
  `PHONECODE_OR_CIF` varchar(20) DEFAULT NULL,
  `INSERT_TIME` varchar(6) DEFAULT NULL,
  `INSERT_DATE` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Authorizer_Transactions
CREATE TABLE IF NOT EXISTS `IVR_Authorizer_Transactions` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) NOT NULL,
  `TransactionDate` varchar(10) NOT NULL,
  `TransactionTime` varchar(8) NOT NULL,
  `TransactionType` varchar(50) NOT NULL,
  `Amount` decimal(7,2) NOT NULL,
  `ApprovalCode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_IVR_IVR_Authorizer_Transactions_TransactionDateTime` (`TransactionDate`,`TransactionTime`),
  KEY `IX_N_IVR_Authorizer_Transactions_SessionID` (`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Billing_Org
CREATE TABLE IF NOT EXISTS `IVR_Billing_Org` (
  `BILLING_ORG_CODE` varchar(50) NOT NULL,
  `WAVFILE` varchar(50) DEFAULT NULL,
  `LANGUAGE` varchar(50) NOT NULL,
  `DIGITS` varchar(50) DEFAULT NULL,
  `ALGO_CHECK` varchar(50) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BILLING_ORG_CODE`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_BOOKED_APPOINTMENTS
CREATE TABLE IF NOT EXISTS `IVR_BOOKED_APPOINTMENTS` (
  `ACCOUNT_NUMBER` varchar(12) DEFAULT NULL,
  `APPOINTMENT_TYPE` varchar(8) DEFAULT NULL,
  `BRANCH_CODE` varchar(10) DEFAULT NULL,
  `BRANCH_NAME` varchar(50) DEFAULT NULL,
  `BOOKING_DATE` varchar(30) NOT NULL,
  `BOOKED_DATE` varchar(8) DEFAULT NULL,
  `BOOKED_SLOT` varchar(11) DEFAULT NULL,
  `TOTAL_SEATS` int NOT NULL,
  `UCID` varchar(25) NOT NULL,
  `BOOKED_SLOT_NUMBER` int NOT NULL,
  PRIMARY KEY (`BOOKING_DATE`,`UCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_BRANCH_DETAILS
CREATE TABLE IF NOT EXISTS `IVR_BRANCH_DETAILS` (
  `BRANCH_CODE` varchar(10) DEFAULT NULL,
  `BRANCH_NAME` varchar(50) DEFAULT NULL,
  `LOCATION` varchar(50) DEFAULT NULL,
  `ADDRESS_TEXT` varchar(200) DEFAULT NULL,
  `BRANCH_WAVFILE` varchar(50) DEFAULT NULL,
  `ADDRESS_WAVFILE` varchar(50) DEFAULT NULL,
  `OPERATINGHOUR_WAVFILE` varchar(50) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `SEATS_ALLOWEDPER_ACCOUNT` int DEFAULT NULL,
  `SEATS_PER_SLOT` int DEFAULT NULL,
  `APPOINTMENT_TYPE` varchar(5) DEFAULT NULL,
  `SYNONYM_ONE` varchar(200) DEFAULT NULL,
  `SYNONYM_TWO` varchar(200) DEFAULT NULL,
  `SYNONYM_THREE` varchar(200) DEFAULT NULL,
  `SYNONYM_FOUR` varchar(200) DEFAULT NULL,
  `SYNONYM_FIVE` varchar(200) DEFAULT NULL,
  `SYNONYM_SIX` varchar(200) DEFAULT NULL,
  `SYNONYM_SEVEN` varchar(200) DEFAULT NULL,
  `SYNONYM_EIGHT` varchar(200) DEFAULT NULL,
  `SYNONYM_NINE` varchar(200) DEFAULT NULL,
  `SYNONYM_TEN` varchar(200) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_BULK_GEN_SMS
CREATE TABLE IF NOT EXISTS `IVR_BULK_GEN_SMS` (
  `ID` int NOT NULL,
  `Date` varchar(20) DEFAULT NULL,
  `Slot_Size` int DEFAULT NULL,
  `BG_SMS_Time_Slot` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_BUSINESS_HOUR
CREATE TABLE IF NOT EXISTS `IVR_BUSINESS_HOUR` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `WEEKDAY` varchar(10) DEFAULT NULL,
  `START_TIME` varchar(10) DEFAULT NULL,
  `END_TIME` varchar(10) DEFAULT NULL,
  `GROUP_NAME` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `Group` varchar(50) DEFAULT NULL,
  `BYPASS_PUBLIC_HOLIDAY` bit(1) DEFAULT b'1',
  `OrgUnit` int DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_CALLBACK
CREATE TABLE IF NOT EXISTS `IVR_CALLBACK` (
  `UCID` varchar(50) DEFAULT NULL,
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `LAST_CIF_IDENTIFIED` varchar(50) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `CC_NUMBER` varchar(20) DEFAULT NULL,
  `VIP_STATUS` varchar(10) DEFAULT NULL,
  `SALUTATION` varchar(10) DEFAULT NULL,
  `NAME` varchar(250) DEFAULT NULL,
  `DOB` varchar(15) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `LAST_IVR_OPTION` varchar(50) DEFAULT NULL,
  `CALLER_ID` varchar(15) DEFAULT NULL,
  `CALLBACK_NUMBER` varchar(15) DEFAULT NULL,
  `REQUESTED_DATETIME` datetime(3) DEFAULT NULL,
  `ASSIGNDATETIME` datetime(3) DEFAULT NULL,
  `DIALDATETIME` datetime(3) DEFAULT NULL,
  `PROCESS_DATETIME` datetime(3) DEFAULT NULL,
  `CALLBACK_DATETIME` datetime(3) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `ASSIGNTO` varchar(50) DEFAULT NULL,
  `REJECT_DATETIME` datetime(3) DEFAULT NULL,
  `CHANNEL` varchar(20) DEFAULT NULL,
  `DIAL_TYPE` varchar(20) DEFAULT NULL,
  `VERIFIED` varchar(20) DEFAULT NULL,
  `CB_VDN` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  KEY `SRNO` (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Callback_Announcement
CREATE TABLE IF NOT EXISTS `IVR_Callback_Announcement` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `START_TIME` varchar(10) DEFAULT NULL,
  `END_TIME` varchar(10) DEFAULT NULL,
  `WAV_FILE` varchar(250) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `Language` varchar(20) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Callback_Requests
CREATE TABLE IF NOT EXISTS `IVR_Callback_Requests` (
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `UCID` varchar(100) DEFAULT NULL,
  `CB_UCID` varchar(100) DEFAULT NULL,
  `DNIS_NAME` varchar(50) DEFAULT NULL,
  `LastMenu` varchar(50) DEFAULT NULL,
  `LastMenu_2` varchar(50) DEFAULT NULL,
  `LastMenu_3` varchar(50) DEFAULT NULL,
  `LastMenu_4` varchar(50) DEFAULT NULL,
  `CALLERID` varchar(20) DEFAULT NULL,
  `PREFFERRED_CONTACTNO` varchar(20) DEFAULT NULL,
  `TYPE_OF_INQUIRY` varchar(50) DEFAULT NULL,
  `TYPE` varchar(50) DEFAULT NULL,
  `REQUEST_DATE` varchar(10) DEFAULT NULL,
  `REQUEST_TIME` varchar(10) DEFAULT NULL,
  `QUEUE_NAME` varchar(50) DEFAULT NULL,
  `QUEUE_WAIT_TIME` varchar(10) DEFAULT NULL,
  `NO_CALLBACK_ATTEMPTS` int DEFAULT NULL,
  `CALLBACK_ATTEMPT_NO` int DEFAULT NULL,
  `DIAL_DATE` varchar(10) DEFAULT NULL,
  `DIAL_TIME` varchar(10) DEFAULT NULL,
  `ASSIGNED_DATE` varchar(10) DEFAULT NULL,
  `ASSIGNED_TIME` varchar(10) DEFAULT NULL,
  `ASSIGNED_TO` varchar(50) DEFAULT NULL,
  `CALLBACK_STATUS` varchar(10) DEFAULT NULL,
  `CALLBACK_DATE` varchar(10) DEFAULT NULL,
  `CALLBACK_TIME` varchar(10) DEFAULT NULL,
  `DISPOSED_DATE` varchar(10) DEFAULT NULL,
  `DISPOSED_TIME` varchar(10) DEFAULT NULL,
  `COMMENTS` varchar(100) DEFAULT NULL,
  `SERVERID` int DEFAULT NULL,
  `PROCESSED_DATE` varchar(50) DEFAULT NULL,
  `PROCESSED_TIME` varchar(50) DEFAULT NULL,
  `AHT` int DEFAULT NULL,
  `SLA` int DEFAULT NULL,
  `APP` varchar(50) DEFAULT NULL,
  `UUI` varchar(100) DEFAULT NULL,
  `OTHERDATA` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Callback_Requests_Attempts
CREATE TABLE IF NOT EXISTS `IVR_Callback_Requests_Attempts` (
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `UCID` varchar(100) DEFAULT NULL,
  `CB_UCID` varchar(100) DEFAULT NULL,
  `DNIS_NAME` varchar(50) DEFAULT NULL,
  `CALLERID` varchar(20) DEFAULT NULL,
  `PREFFERRED_CONTACTNO` varchar(20) DEFAULT NULL,
  `TYPE_OF_INQUIRY` varchar(50) DEFAULT NULL,
  `TYPE` varchar(50) DEFAULT NULL,
  `REQUEST_DATE` varchar(10) DEFAULT NULL,
  `REQUEST_TIME` varchar(10) DEFAULT NULL,
  `QUEUE_NAME` varchar(50) DEFAULT NULL,
  `QUEUE_WAIT_TIME` varchar(10) DEFAULT NULL,
  `NO_CALLBACK_ATTEMPTS` int DEFAULT NULL,
  `CALLBACK_ATTEMPT_NO` int DEFAULT NULL,
  `DIAL_DATE` varchar(10) DEFAULT NULL,
  `DIAL_TIME` varchar(10) DEFAULT NULL,
  `ASSIGNED_DATE` varchar(10) DEFAULT NULL,
  `ASSIGNED_TIME` varchar(10) DEFAULT NULL,
  `ASSIGNED_TO` varchar(50) DEFAULT NULL,
  `CALLBACK_STATUS` varchar(20) DEFAULT NULL,
  `CALLBACK_DATE` varchar(10) DEFAULT NULL,
  `CALLBACK_TIME` varchar(10) DEFAULT NULL,
  `DISPOSED_DATE` varchar(10) DEFAULT NULL,
  `DISPOSED_TIME` varchar(10) DEFAULT NULL,
  `COMMENTS` varchar(100) DEFAULT NULL,
  `SERVERID` int DEFAULT NULL,
  `PROCESSED_TIME` varchar(10) DEFAULT NULL,
  `PROCESSED_DATE` varchar(10) DEFAULT NULL,
  `AHT` int DEFAULT NULL,
  `SLA` int DEFAULT NULL,
  PRIMARY KEY (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_CALLER_IDENTIFICATION
CREATE TABLE IF NOT EXISTS `IVR_CALLER_IDENTIFICATION` (
  `sessionId` varchar(50) NOT NULL,
  `isCallerRegistered` varchar(5) NOT NULL,
  `startDate` varchar(50) NOT NULL,
  `startTime` varchar(50) NOT NULL,
  `isMembershipIdEntered` varchar(5) NOT NULL,
  `isIdentified` varchar(5) NOT NULL,
  `isVerificationPinEntered` varchar(5) NOT NULL,
  `isPinVerified` varchar(5) NOT NULL,
  PRIMARY KEY (`sessionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_CALL_DATA
CREATE TABLE IF NOT EXISTS `IVR_CALL_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `ConnectionHandle` varchar(50) DEFAULT NULL,
  `QueuedDateTime` varchar(50) DEFAULT NULL,
  `AnsweredDateTime` varchar(50) DEFAULT NULL,
  `Queue` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `VDN` varchar(50) DEFAULT NULL,
  `Status` varchar(5) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Call_History
CREATE TABLE IF NOT EXISTS `IVR_Call_History` (
  `ICH_START_DATE` varchar(20) DEFAULT NULL,
  `ICH_END_DATE` varchar(20) DEFAULT NULL,
  `ICH_START_TIME` varchar(20) DEFAULT NULL,
  `ICH_END_TIME` varchar(20) DEFAULT NULL,
  `ICH_CALL_DUR` varchar(20) DEFAULT NULL,
  `ICH_CLID` varchar(30) DEFAULT NULL,
  `ICH_DNIS` varchar(30) DEFAULT NULL,
  `ICH_CALLREFID` varchar(50) DEFAULT NULL,
  `ICH_TR_DIS_FLAG` varchar(2) DEFAULT NULL,
  `IU_LAST_MENU_ID` varchar(100) DEFAULT NULL,
  `IU_LANGUAGE` varchar(20) DEFAULT NULL,
  `COMPANY` varchar(50) DEFAULT NULL,
  `CIF` varchar(19) DEFAULT NULL,
  `EMP_NAME` varchar(50) DEFAULT NULL,
  `BB_CUSTOM_INDICATOR` varchar(5) DEFAULT NULL,
  `CUSTOMER_SEGMENT` varchar(50) DEFAULT NULL,
  `CUSTOMER_STATUS` varchar(50) DEFAULT NULL,
  `TPIN_VERIFIED` varchar(10) DEFAULT NULL,
  `OTP_VERFIFIED` varchar(50) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `PHONE_CODE` varchar(20) DEFAULT NULL,
  `LASTMENU_1` varchar(100) DEFAULT NULL,
  `LASTMENU_2` varchar(100) DEFAULT NULL,
  `LASTMENU_3` varchar(100) DEFAULT NULL,
  `LASTMENU_4` varchar(100) DEFAULT NULL,
  `QUEUETIME` varchar(8) DEFAULT NULL,
  `TRANSFER_VDN` varchar(50) DEFAULT NULL,
  KEY `IX_IVR_Call_History_ICH_CALLREFID` (`ICH_CALLREFID`),
  KEY `IX_IVR_Call_History_ICH_END_DATE` (`ICH_END_DATE`),
  KEY `IX_IVR_Call_History_ICH_END_TIME` (`ICH_END_TIME`),
  KEY `IX_IVR_Call_History_ICH_START_DATE` (`ICH_START_DATE`),
  KEY `IX_IVR_Call_History_ICH_START_TIME` (`ICH_START_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_CEP_CODE_MAPPING
CREATE TABLE IF NOT EXISTS `IVR_CEP_CODE_MAPPING` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EVENT_TYPE` varchar(100) DEFAULT NULL,
  `BIN` varchar(100) DEFAULT NULL,
  `PRODUCT_TYPE` varchar(100) DEFAULT NULL,
  `INTENT` varchar(100) DEFAULT NULL,
  `TRANSFER_STATUS` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(4000) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Customer_PreferenceList
CREATE TABLE IF NOT EXISTS `IVR_Customer_PreferenceList` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CID` varchar(20) NOT NULL,
  `PreferenceGroup` varchar(50) NOT NULL,
  `PreferenceType` varchar(20) DEFAULT NULL,
  `PreferenceValue` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_DNIS_DESC
CREATE TABLE IF NOT EXISTS `IVR_DNIS_DESC` (
  `VDN_NUMBER` varchar(10) DEFAULT NULL,
  `VDN_DESCRIPTION` varchar(50) DEFAULT NULL,
  `EMAILID` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_DNIS_INFO
CREATE TABLE IF NOT EXISTS `IVR_DNIS_INFO` (
  `CLIENT_INFO` varchar(50) DEFAULT NULL,
  `DNIS` varchar(50) NOT NULL,
  `LANGUAGE` varchar(50) DEFAULT NULL,
  `EMAILID` varchar(500) DEFAULT NULL,
  `COUNTRY` varchar(500) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  `STATUS` varchar(10) NOT NULL DEFAULT 'Enable',
  PRIMARY KEY (`DNIS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_EventSummary
CREATE TABLE IF NOT EXISTS `IVR_EventSummary` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `EventDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `OfferSelected` varchar(255) DEFAULT NULL,
  `OfferConfirmed` bit(1) NOT NULL DEFAULT b'0',
  `InsertionDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Exchange_Rate_Menu
CREATE TABLE IF NOT EXISTS `IVR_Exchange_Rate_Menu` (
  `CURRENCY_CODE` varchar(10) NOT NULL,
  `CURRENCY_NAME` varchar(50) DEFAULT NULL,
  `WAV_FILE` varchar(50) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `SYNONYM_ONE` varchar(200) DEFAULT NULL,
  `SYNONYM_TWO` varchar(200) DEFAULT NULL,
  `SYNONYM_THREE` varchar(200) DEFAULT NULL,
  `SYNONYM_FOUR` varchar(200) DEFAULT NULL,
  `SYNONYM_FIVE` varchar(200) DEFAULT NULL,
  `SYNONYM_SIX` varchar(200) DEFAULT NULL,
  `SYNONYM_SEVEN` varchar(200) DEFAULT NULL,
  `SYNONYM_EIGHT` varchar(200) DEFAULT NULL,
  `SYNONYM_NINE` varchar(200) DEFAULT NULL,
  `SYNONYM_TEN` varchar(200) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CURRENCY_CODE`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_EXTENSION
CREATE TABLE IF NOT EXISTS `IVR_EXTENSION` (
  `id` varchar(20) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_FaxForm_Name
CREATE TABLE IF NOT EXISTS `IVR_FaxForm_Name` (
  `ENTITY` varchar(100) DEFAULT NULL,
  `GROUP_NAME` varchar(100) NOT NULL,
  `FUNCTIONALITY` varchar(100) NOT NULL,
  `OVERSEAS_ENABLED` varchar(10) DEFAULT NULL,
  `FORM_NAME` varchar(100) DEFAULT NULL,
  `WAV_FILE` varchar(50) DEFAULT NULL,
  `OPTION_ORDER` int NOT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`GROUP_NAME`,`FUNCTIONALITY`,`OPTION_ORDER`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_FAX_DETAILS
CREATE TABLE IF NOT EXISTS `IVR_FAX_DETAILS` (
  `ICH_CALLREFID` varchar(30) NOT NULL,
  `ICH_START_DATE` varchar(10) NOT NULL,
  `ICH_END_DATE` varchar(10) NOT NULL,
  `ICH_START_TIME` varchar(8) NOT NULL,
  `ICH_END_TIME` varchar(8) NOT NULL,
  `ICH_CLID` varchar(20) NOT NULL,
  `IFD_FAX_NO` varchar(20) NOT NULL,
  `IFD_FAX_SDDR` varchar(1) NOT NULL,
  `IFD_FAX_FCTDR` varchar(1) NOT NULL,
  `IFD_FAX_ISAVVY` varchar(1) NOT NULL,
  `IFD_FAX_FER` varchar(1) NOT NULL,
  `IFD_FAX_FT` varchar(1) NOT NULL,
  `IFD_FAX_SCP` varchar(1) NOT NULL,
  `IFD_FAX_L3T` varchar(1) NOT NULL,
  `IFD_FAX_CASR` varchar(1) NOT NULL,
  `IFD_FAX_1_1` varchar(5) DEFAULT NULL,
  `IFD_FAX_1_2` varchar(5) DEFAULT NULL,
  `IFD_FAX_1_3` varchar(5) DEFAULT NULL,
  `IFD_FAX_1_4` varchar(5) DEFAULT NULL,
  `IFD_FAX_1_5` varchar(5) DEFAULT NULL,
  `IFD_FAX_2_1` varchar(5) DEFAULT NULL,
  `IFD_FAX_2_2` varchar(5) DEFAULT NULL,
  `IFD_FAX_2_3` varchar(5) DEFAULT NULL,
  `IFD_FAX_2_4` varchar(5) DEFAULT NULL,
  `IFD_FAX_2_5` varchar(5) DEFAULT NULL,
  `IFD_FAX_3_1` varchar(5) DEFAULT NULL,
  `IFD_FAX_3_2` varchar(5) DEFAULT NULL,
  `IFD_FAX_3_3` varchar(5) DEFAULT NULL,
  `IFD_FAX_3_4` varchar(5) DEFAULT NULL,
  `IFD_FAX_3_5` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Fax_Group
CREATE TABLE IF NOT EXISTS `IVR_Fax_Group` (
  `ENTITY` varchar(100) DEFAULT NULL,
  `GROUP_NAME` varchar(100) NOT NULL,
  `GROUP_NUMBER` int NOT NULL,
  `WAV_FILE` varchar(50) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`GROUP_NAME`,`GROUP_NUMBER`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Fax_Report
CREATE TABLE IF NOT EXISTS `IVR_Fax_Report` (
  `ICH_CALLREFID` varchar(30) DEFAULT NULL,
  `IFN_FAX_NAME` varchar(100) DEFAULT NULL,
  `IFN_FAX_NUMBER` varchar(20) DEFAULT NULL,
  `IFN_DATE` varchar(10) DEFAULT NULL,
  `IFR_SUCCESS` int NOT NULL,
  `IFR_FAILURE` int NOT NULL,
  `IFR_FLAG` varchar(1) DEFAULT NULL,
  `IFN_TIME` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_FeeWaiverRequest
CREATE TABLE IF NOT EXISTS `IVR_FeeWaiverRequest` (
  `srno` int NOT NULL AUTO_INCREMENT,
  `RequestDatetime` datetime(3) DEFAULT NULL,
  `DialDateTime` datetime(3) DEFAULT NULL,
  `AssignDateTime` datetime(3) DEFAULT NULL,
  `FinalDateTime` datetime(3) DEFAULT NULL,
  `RecordType` varchar(50) DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `AccountNumber` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `MobileNumber` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `AssignTo` varchar(250) DEFAULT NULL,
  `EDUID_1` varchar(100) DEFAULT NULL,
  `EDUID_2` varchar(100) DEFAULT NULL,
  `UCID` varchar(100) DEFAULT NULL,
  `Lock` varchar(2) DEFAULT NULL,
  `ErrorCode` varchar(50) DEFAULT NULL,
  `EmailID` varchar(512) DEFAULT NULL,
  KEY `srno` (`srno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_GENERIC_CONFIG
CREATE TABLE IF NOT EXISTS `IVR_GENERIC_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `PARAMETER` varchar(50) DEFAULT NULL,
  `VALUE` varchar(200) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  `EntityName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'IVR',
  `EntityValue` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'IVR',
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_HOLIDAY_LIST
CREATE TABLE IF NOT EXISTS `IVR_HOLIDAY_LIST` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `START_DATE` varchar(10) DEFAULT NULL,
  `END_DATE` varchar(10) DEFAULT NULL,
  `ANNOUNCED_HOLIDAY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `START_TIME` varchar(10) DEFAULT NULL,
  `END_TIME` varchar(10) DEFAULT NULL,
  `VDN` varchar(10) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_HostMap_Details
CREATE TABLE IF NOT EXISTS `IVR_HostMap_Details` (
  `FUNCTIONALITY` varchar(50) NOT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `HOST_DATA` varchar(50) NOT NULL,
  `WAV_FILE` varchar(100) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`FUNCTIONALITY`,`LANGUAGE`,`HOST_DATA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_HOST_INT
CREATE TABLE IF NOT EXISTS `IVR_HOST_INT` (
  `ICH_CALLREFID` varchar(30) NOT NULL,
  `IHI_TRANS_ID` varchar(8) DEFAULT NULL,
  `IHI_TRANS_SUC` varchar(5) DEFAULT NULL,
  `IHI_TRANS_FAIL` varchar(5) NOT NULL,
  `IHI_CIF` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Hotline_DNIS_Mapping
CREATE TABLE IF NOT EXISTS `IVR_Hotline_DNIS_Mapping` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Hotline` varchar(50) NOT NULL,
  `DNIS` varchar(50) NOT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_Hotline_DNIS_Mapping_Hotline_DNIS` (`Hotline`,`DNIS`),
  KEY `IX_N_Hotline_DNIS_Mapping_Hotline` (`Hotline`),
  KEY `IX_N_Hotline_DNIS_Mapping_DNIS` (`DNIS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Introductory_Message
CREATE TABLE IF NOT EXISTS `IVR_Introductory_Message` (
  `FUNCTIONALITY` varchar(100) NOT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `WAVFILE` varchar(100) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `START_DATE` varchar(10) DEFAULT NULL,
  `END_DATE` varchar(10) DEFAULT NULL,
  `START_TIME` varchar(10) DEFAULT NULL,
  `END_TIME` varchar(10) DEFAULT NULL,
  `INTERRUPT` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `HOTLINE` varchar(20) NOT NULL DEFAULT '''''',
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`FUNCTIONALITY`,`LANGUAGE`,`HOTLINE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Account_transaction
CREATE TABLE IF NOT EXISTS `IVR_IW_Account_transaction` (
  `TxnID` int NOT NULL AUTO_INCREMENT,
  `Date` datetime(3) DEFAULT NULL,
  `Accesscode` varchar(10) DEFAULT NULL,
  `Account_no` varchar(10) DEFAULT NULL,
  `Payee_no` varchar(10) DEFAULT NULL,
  `Narration` varchar(50) DEFAULT NULL,
  `Amount` varchar(12) DEFAULT NULL,
  `TxnType` varchar(10) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`TxnID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Credit_Card_Info
CREATE TABLE IF NOT EXISTS `IVR_IW_Credit_Card_Info` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Customer_ID` varchar(7) DEFAULT NULL,
  `Card_no` varchar(10) DEFAULT NULL,
  `Date` datetime(3) DEFAULT NULL,
  `Amount_payable` varchar(8) DEFAULT NULL,
  `Duedate` datetime(3) DEFAULT NULL,
  `paiddate` datetime(3) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Customer_Preference
CREATE TABLE IF NOT EXISTS `IVR_IW_Customer_Preference` (
  `CIF` varchar(20) DEFAULT NULL,
  `BANKREGISTERED_PHONENO` varchar(20) DEFAULT NULL,
  `PREFERRED_LANGUAGE` varchar(20) DEFAULT NULL,
  `FAVORITE_TRANSACTION` varchar(20) DEFAULT NULL,
  `PREFERRED_FLOW` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Dialog_State_Map
CREATE TABLE IF NOT EXISTS `IVR_IW_Dialog_State_Map` (
  `Dialog_State_Tag` varchar(100) NOT NULL,
  `Error_Limit_DTMF` int NOT NULL,
  `Error_Limit_Speech` int NOT NULL,
  `Speech_Grammar_Name` varchar(150) DEFAULT NULL,
  `DTMF_Grammar_Set` varchar(50) DEFAULT NULL,
  `Initial_Prompt` varchar(100) NOT NULL,
  `Fail1_Prompt` varchar(100) DEFAULT NULL,
  `Fail2_Prompt` varchar(100) DEFAULT NULL,
  `Timeout1_Prompt` varchar(100) DEFAULT NULL,
  `Timeout2_Prompt` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_DIALOG_STATE_MODULE
CREATE TABLE IF NOT EXISTS `IVR_IW_DIALOG_STATE_MODULE` (
  `Dialog_State_Tag` varchar(100) NOT NULL,
  `Dialog_Menu_ID` varchar(12) NOT NULL,
  `Error_Limit_DTMF` int NOT NULL,
  `Error_Limit_Speech` int NOT NULL,
  `Speech_Grammar_Name` varchar(150) DEFAULT NULL,
  `DTMF_Grammar_Set` varchar(50) DEFAULT NULL,
  `DTMF_Set_OR_Define_Length` varchar(1) DEFAULT NULL,
  `DTMF_MIN_LENGTH` varchar(2) DEFAULT NULL,
  `DTMF_MAX_LENGTH` varchar(2) DEFAULT NULL,
  `Initial_Prompt` varchar(100) NOT NULL,
  `Fail1_Prompt` varchar(100) DEFAULT NULL,
  `Fail2_Prompt` varchar(100) DEFAULT NULL,
  `Timeout1_Prompt` varchar(100) DEFAULT NULL,
  `Timeout2_Prompt` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_DNIS_Context
CREATE TABLE IF NOT EXISTS `IVR_IW_DNIS_Context` (
  `DNIS` varchar(50) NOT NULL,
  `HOTLINE_SEGMENT` varchar(10) DEFAULT NULL,
  `GREETING_WAVFILE` varchar(50) NOT NULL,
  `VOICE_TALENT_URL` varchar(250) NOT NULL,
  `ENTITY` varchar(10) NOT NULL,
  `DIALOG_STATE_TAG` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_DTMF_Map
CREATE TABLE IF NOT EXISTS `IVR_IW_DTMF_Map` (
  `DTMF_GRAMMAR_SET` varchar(50) NOT NULL,
  `OPTIONS` varchar(6) NOT NULL,
  `SEMANTIC_TAG` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_GeoCode
CREATE TABLE IF NOT EXISTS `IVR_IW_GeoCode` (
  `Branch_code` varchar(10) DEFAULT NULL,
  `Latitude` varchar(15) DEFAULT NULL,
  `Longitude` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_LOGIN_MST
CREATE TABLE IF NOT EXISTS `IVR_IW_LOGIN_MST` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Accesscode` varchar(10) NOT NULL,
  `pin` varchar(20) DEFAULT NULL,
  `Displayname` varchar(50) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `last_updated` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Accesscode`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_MODULE_EXITS_MAPPING
CREATE TABLE IF NOT EXISTS `IVR_IW_MODULE_EXITS_MAPPING` (
  `PRODUCT_LIST` varchar(4000) DEFAULT NULL,
  `QUANTITY` int DEFAULT NULL,
  `MODULE_NAME` varchar(50) DEFAULT NULL,
  `EXIT_NODES` varchar(4000) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Page_info
CREATE TABLE IF NOT EXISTS `IVR_IW_Page_info` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Tagname` varchar(30) DEFAULT NULL,
  `Imgname` varchar(50) DEFAULT NULL,
  `Pagename` varchar(50) DEFAULT NULL,
  `Parenthead` varchar(50) DEFAULT NULL,
  `Displayname` varchar(50) DEFAULT NULL,
  `Category` varchar(25) DEFAULT NULL,
  `SrNo` int DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_Payee_Account
CREATE TABLE IF NOT EXISTS `IVR_IW_Payee_Account` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Accesscode` varchar(10) DEFAULT NULL,
  `Payee_Account` varchar(10) NOT NULL,
  `Payee_Name` varchar(25) DEFAULT NULL,
  `IFSC_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Payee_Account`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_PREFERRED_LANGUAGE
CREATE TABLE IF NOT EXISTS `IVR_IW_PREFERRED_LANGUAGE` (
  `mobile_no` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `attempts` varchar(20) NOT NULL,
  `last_update` varchar(20) NOT NULL,
  PRIMARY KEY (`mobile_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_VIP_BulkChanges
CREATE TABLE IF NOT EXISTS `IVR_IW_VIP_BulkChanges` (
  `UpdatedDate` varchar(10) DEFAULT NULL,
  `UpdatedTime` varchar(10) DEFAULT NULL,
  `FileName` varchar(25) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Comments` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_IW_VIP_Customer
CREATE TABLE IF NOT EXISTS `IVR_IW_VIP_Customer` (
  `CIF` varchar(20) DEFAULT NULL,
  `ENTITY` varchar(10) DEFAULT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `SALUTATION` varchar(10) DEFAULT NULL,
  `ID` varchar(20) DEFAULT NULL,
  `ID_TYPE` varchar(50) DEFAULT NULL,
  `ID_COUNTRY` varchar(50) DEFAULT NULL,
  `CUSTOMER_SEGMENT` varchar(50) DEFAULT NULL,
  `CUSTOMER_PRODUCT_HOLDINGS` varchar(50) DEFAULT NULL,
  `BANKREGISTERED_PHONENO` varchar(20) NOT NULL,
  `BANKREGISTERED_EMAIL` varchar(50) DEFAULT NULL,
  `PROFITABLY_INDICATOR` varchar(50) DEFAULT NULL,
  `PROFILE_PHOTO` varchar(50) DEFAULT NULL,
  `CAMPAIGN1_CARD_ACTIVATION` varchar(50) DEFAULT NULL,
  `CAMPAIGN1_CARD_FEE_WAIVER` varchar(50) DEFAULT NULL,
  `CAMPAIGN1_CARD_CROSS_SELL` varchar(50) DEFAULT NULL,
  `CREDIT_CARD_1` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_1_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_2` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_2_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_3` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_3_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_4` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_4_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_5` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_5_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_6` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_6_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_7` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_7_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_8` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_8_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_9` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_9_WAIVER_DECISION` varchar(20) DEFAULT NULL,
  `VIP_FLAG` varchar(2) DEFAULT NULL,
  `VDN` varchar(20) DEFAULT NULL,
  `MESSAGE` varchar(250) DEFAULT NULL,
  `OFFER_SPEECH` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`BANKREGISTERED_PHONENO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_MENU_DESC
CREATE TABLE IF NOT EXISTS `IVR_MENU_DESC` (
  `IMD_MENU_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `IMD_MENU_NAME` varchar(100) NOT NULL,
  `INTENT` varchar(50) NOT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IMD_MENU_ID`),
  UNIQUE KEY `uni_menuDesc` (`IMD_MENU_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_ORDER_TAKE
CREATE TABLE IF NOT EXISTS `IVR_ORDER_TAKE` (
  `UCID` varchar(50) DEFAULT NULL,
  `PHONENUMBER` varchar(50) DEFAULT NULL,
  `DNIS` varchar(50) DEFAULT NULL,
  `REQUEST_DATE` varchar(50) DEFAULT NULL,
  `REQUEST_TIME` varchar(50) DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `TYPE` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_1` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_2` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_3` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_4` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_5` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_6` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_7` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_8` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_9` varchar(50) DEFAULT NULL,
  `REQUEST_DATA_10` varchar(50) DEFAULT NULL,
  `CIN` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_PersonalizedSMSReport
CREATE TABLE IF NOT EXISTS `IVR_PersonalizedSMSReport` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CS_UCID` varchar(20) NOT NULL,
  `CS_CIN` varchar(60) NOT NULL,
  `CS_CINsfx` varchar(2) NOT NULL,
  `CS_ResponseStatus` varchar(10) NOT NULL,
  `CS_VoicePromptID` varchar(60) NOT NULL,
  `CS_ServiceID` varchar(100) NOT NULL,
  `CS_SMSAcceptance` varchar(10) NOT NULL,
  `CS_SMS_SentStatus` varchar(20) DEFAULT NULL,
  `CS_SMS_SentDateTime` varchar(20) DEFAULT NULL,
  `CS_SMS_MobileNo` varchar(20) DEFAULT NULL,
  `CS_SMSMobNumType` varchar(20) NOT NULL,
  `CS_URL` varchar(255) NOT NULL,
  `CS_SMS_ICOM_TemplateID` varchar(60) NOT NULL,
  `CS_ExclusionFlag` varchar(1) NOT NULL,
  `ReportDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  UNIQUE KEY `IVR_PersonalizedSMSReport_UCID` (`CS_UCID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_PROD_TYPE_MAP
CREATE TABLE IF NOT EXISTS `IVR_PROD_TYPE_MAP` (
  `cardtype` varchar(50) DEFAULT NULL,
  `bin` varchar(50) DEFAULT NULL,
  `productdesc` varchar(50) DEFAULT NULL,
  `orgcode` varchar(255) DEFAULT NULL,
  `productaudio` varchar(255) DEFAULT NULL,
  `segment` varchar(255) DEFAULT NULL,
  `typecode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Promotions
CREATE TABLE IF NOT EXISTS `IVR_Promotions` (
  `PROMOTION_NUMBER` int NOT NULL,
  `PROMOTION_DESC` varchar(100) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `PROMOTION_WAVFILE` varchar(20) DEFAULT NULL,
  `PROMOTION_DESC_WAVFILE` varchar(20) DEFAULT NULL,
  `FAX_ENABLED` varchar(10) DEFAULT NULL,
  `START_DATE` varchar(10) DEFAULT NULL,
  `END_DATE` varchar(10) DEFAULT NULL,
  `START_TIME` varchar(6) DEFAULT NULL,
  `END_TIME` varchar(6) DEFAULT NULL,
  `TREATMENT` varchar(10) DEFAULT NULL,
  `OVERSEAS_ENABLED` varchar(10) DEFAULT NULL,
  `FAX_PDFFILE` varchar(100) DEFAULT NULL,
  `AGENT_GROUP` varchar(50) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PROMOTION_NUMBER`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_RPA_FeewaiverRequest
CREATE TABLE IF NOT EXISTS `IVR_RPA_FeewaiverRequest` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `MsgUID` varchar(50) DEFAULT NULL,
  `CustCIN` varchar(20) DEFAULT NULL,
  `CustCINSuffix` varchar(20) DEFAULT NULL,
  `RequestType` varchar(20) DEFAULT NULL,
  `CountryCode` varchar(10) DEFAULT NULL,
  `CreatedBy` varchar(20) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `ReportUIDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `RequestDateTime` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_IVR_RPA_FeewaiverRequest_MsgUIDUCID` (`MsgUID`,`UCID`),
  KEY `IX_IVR_RPA_FeewaiverRequest_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_SPEECH_USAGE
CREATE TABLE IF NOT EXISTS `IVR_SPEECH_USAGE` (
  `ICH_CALLREFID` varchar(50) DEFAULT NULL,
  `MENU_ID` varchar(100) DEFAULT NULL,
  `TRANS_NAME` varchar(1000) DEFAULT NULL,
  `SYNONYM_TAG` varchar(1000) DEFAULT NULL,
  `ISU_SCORE` varchar(1000) DEFAULT NULL,
  `ISU_RESULT` varchar(5) DEFAULT NULL,
  `ISU_ORDER` int NOT NULL,
  `CONFIRMATION_STATUS` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_SURVEY_OF_CSO
CREATE TABLE IF NOT EXISTS `IVR_SURVEY_OF_CSO` (
  `STATUS` varchar(10) DEFAULT NULL,
  `QUESTION_NUMBER` int NOT NULL,
  `QUESTION_WAVE_FILE_NUMBER` varchar(100) DEFAULT NULL,
  `MENU_WAVE_FILES` varchar(4000) DEFAULT NULL,
  `OPTIONS` varchar(30) DEFAULT NULL,
  `OPTIONS_TEXT` varchar(4000) DEFAULT NULL,
  `QUESTION_TEXT` varchar(1000) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `THRESHOLD` varchar(10) DEFAULT NULL,
  `DNIS` varchar(10) NOT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`QUESTION_NUMBER`,`LANGUAGE`,`DNIS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_SURVEY_OF_CSO_REPORT
CREATE TABLE IF NOT EXISTS `IVR_SURVEY_OF_CSO_REPORT` (
  `START_DATE` varchar(15) DEFAULT NULL,
  `END_DATE` varchar(15) DEFAULT NULL,
  `START_TIME` varchar(30) DEFAULT NULL,
  `END_TIME` varchar(30) DEFAULT NULL,
  `CALL_DURATION` varchar(20) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `QN1TEXT` varchar(200) DEFAULT NULL,
  `QN2TEXT` varchar(200) DEFAULT NULL,
  `QN3TEXT` varchar(200) DEFAULT NULL,
  `QN4TEXT` varchar(200) DEFAULT NULL,
  `QN5TEXT` varchar(200) DEFAULT NULL,
  `QN1RESULT` varchar(50) DEFAULT NULL,
  `QN2RESULT` varchar(50) DEFAULT NULL,
  `QN3RESULT` varchar(50) DEFAULT NULL,
  `QN4RESULT` varchar(50) DEFAULT NULL,
  `QN5RESULT` varchar(50) DEFAULT NULL,
  `AGENTID` varchar(50) DEFAULT NULL,
  `CALLERID` varchar(50) DEFAULT NULL,
  `COMPANY_NAME` varchar(100) DEFAULT NULL,
  `CIFNUMBER` varchar(15) DEFAULT NULL,
  `CUSTOMER_SEGMENT` varchar(30) DEFAULT NULL,
  `PHONECODE` varchar(10) DEFAULT NULL,
  `CONTACT_NAME` varchar(50) DEFAULT NULL,
  `DNIS` varchar(10) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `QN6TEXT` varchar(500) DEFAULT NULL,
  `QN7TEXT` varchar(500) DEFAULT NULL,
  `QN8TEXT` varchar(500) DEFAULT NULL,
  `QN9TEXT` varchar(500) DEFAULT NULL,
  `QN10TEXT` varchar(200) DEFAULT NULL,
  `QN6RESULT` varchar(50) DEFAULT NULL,
  `QN7RESULT` varchar(50) DEFAULT NULL,
  `QN8RESULT` varchar(50) DEFAULT NULL,
  `QN9RESULT` varchar(50) DEFAULT NULL,
  `QN10RESULT` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_SURVEY_OF_IVR
CREATE TABLE IF NOT EXISTS `IVR_SURVEY_OF_IVR` (
  `STATUS` varchar(10) DEFAULT NULL,
  `QUESTION_NUMBER` int NOT NULL,
  `QUESTION_WAVE_FILE_NUMBER` varchar(100) DEFAULT NULL,
  `MENU_WAVE_FILES` varchar(504) DEFAULT NULL,
  `OPTIONS` varchar(30) DEFAULT NULL,
  `OPTIONS_TEXT` varchar(200) DEFAULT NULL,
  `QUESTION_TEXT` varchar(200) DEFAULT NULL,
  `LANGUAGE` varchar(10) NOT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`QUESTION_NUMBER`,`LANGUAGE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_SURVEY_OF_IVR_REPORT
CREATE TABLE IF NOT EXISTS `IVR_SURVEY_OF_IVR_REPORT` (
  `start_date` varchar(50) DEFAULT NULL,
  `end_date` varchar(50) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `call_duration` varchar(50) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `QN1text` varchar(50) DEFAULT NULL,
  `QN2text` varchar(50) DEFAULT NULL,
  `QN3text` varchar(50) DEFAULT NULL,
  `QN4text` varchar(50) DEFAULT NULL,
  `QN5text` varchar(50) DEFAULT NULL,
  `Qn1result` varchar(50) DEFAULT NULL,
  `Qn2result` varchar(50) DEFAULT NULL,
  `qn3result` varchar(50) DEFAULT NULL,
  `qn4result` varchar(50) DEFAULT NULL,
  `qn5result` varchar(50) DEFAULT NULL,
  `callerid` varchar(50) DEFAULT NULL,
  `cif_number` varchar(50) DEFAULT NULL,
  `nric_number` varchar(50) DEFAULT NULL,
  `contact_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Transactions_Synonym
CREATE TABLE IF NOT EXISTS `IVR_Transactions_Synonym` (
  `TRANSACTIONNAME` varchar(50) DEFAULT NULL,
  `LANGUAGE` varchar(10) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `SYNONYM_ONE` varchar(200) DEFAULT NULL,
  `SYNONYM_TWO` varchar(200) DEFAULT NULL,
  `SYNONYM_THREE` varchar(200) DEFAULT NULL,
  `SYNONYM_FOUR` varchar(200) DEFAULT NULL,
  `SYNONYM_FIVE` varchar(200) DEFAULT NULL,
  `SYNONYM_SIX` varchar(200) DEFAULT NULL,
  `SYNONYM_SEVEN` varchar(200) DEFAULT NULL,
  `SYNONYM_EIGHT` varchar(200) DEFAULT NULL,
  `SYNONYM_NINE` varchar(200) DEFAULT NULL,
  `SYNONYM_TEN` varchar(200) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `ID` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_TRANS_DESC
CREATE TABLE IF NOT EXISTS `IVR_TRANS_DESC` (
  `ITD_TRANS_ID` varchar(8) NOT NULL,
  `ITD_TRANS_NAME` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_TREATPOINT_REDEMPTIONCODE
CREATE TABLE IF NOT EXISTS `IVR_TREATPOINT_REDEMPTIONCODE` (
  `Product` varchar(510) DEFAULT NULL,
  `RedemptionCode` varchar(50) DEFAULT NULL,
  `ProductWaveFile` varchar(15) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_TRL
CREATE TABLE IF NOT EXISTS `IVR_TRL` (
  `UCID` varchar(50) DEFAULT NULL,
  `REQUEST_UUID` varchar(40) DEFAULT NULL,
  `TRANSACTION_NAME` varchar(50) DEFAULT NULL,
  `MENU_DESCRIPTION` varchar(100) DEFAULT NULL,
  `IVR_TRANS_DATE` datetime(3) NOT NULL,
  `REQUEST_DATE` datetime(3) DEFAULT NULL,
  `RESPONSE_DATE` datetime(3) DEFAULT NULL,
  `REQ_MESSAGE` varchar(2000) DEFAULT NULL,
  `RES_MESSAGE` varchar(2000) DEFAULT NULL,
  `REQEUST_DATE` varchar(255) DEFAULT NULL,
  `REQ_MSG` varchar(255) DEFAULT NULL,
  `RES_MSG` varchar(255) DEFAULT NULL,
  KEY `IX_IVR_TRL` (`UCID`,`IVR_TRANS_DATE`,`REQUEST_DATE`,`RESPONSE_DATE`),
  KEY `IX_IVR_TRL_IVR_TRANS_DATE` (`IVR_TRANS_DATE`),
  KEY `IX_IVR_TRL_REQUEST_DATE` (`REQUEST_DATE`),
  KEY `IX_IVR_TRL_RESPONSE_DATE` (`RESPONSE_DATE`),
  KEY `IX_IVR_TRL_UCID` (`UCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_Usage
CREATE TABLE IF NOT EXISTS `IVR_Usage` (
  `ICH_CALLREFID` varchar(50) DEFAULT NULL,
  `IU_ID` varchar(100) NOT NULL,
  `IU_EII` varchar(10) NOT NULL,
  `IU_ENI` varchar(10) NOT NULL,
  `IU_EMC` varchar(10) DEFAULT NULL,
  `IU_ORDER` int DEFAULT NULL,
  `IU_MENU_NAME` varchar(100) NOT NULL,
  `IU_VAL` varchar(15) DEFAULT NULL,
  `IU_StartTime` datetime(3) DEFAULT NULL,
  `IU_EndTime` datetime(3) DEFAULT NULL,
  `ACCESS_DATETIME` datetime(3) DEFAULT NULL,
  `INSERT_TIME` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  KEY `IX_IVR_Usage` (`ICH_CALLREFID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IVR_VDN_NUM
CREATE TABLE IF NOT EXISTS `IVR_VDN_NUM` (
  `IMU_MENU_ID` varchar(15) DEFAULT NULL,
  `IVN_MENU_OPT` varchar(1) DEFAULT NULL,
  `IVN_VDN_NUM` varchar(5) DEFAULT NULL,
  `IVN_VDN_DESC` varchar(200) DEFAULT NULL,
  `IVN_SESS_DNIS` varchar(20) DEFAULT NULL,
  `IVN_VIP_VDN_NUM` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IW_Interpreter_Data
CREATE TABLE IF NOT EXISTS `IW_Interpreter_Data` (
  `FileName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SubType` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `JsonData` longtext NOT NULL,
  `UpdatedBy` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `UpdatedDateTime` bigint NOT NULL,
  `UpdatedDateTimeDisplay` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`FileName`,`Type`,`SubType`,`Status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.IW_UI_Data
CREATE TABLE IF NOT EXISTS `IW_UI_Data` (
  `Channel` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `FlowName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `FileName` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `VersionNo` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CurrentUser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SubType` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `JsonData` longtext NOT NULL,
  `CurrentUserType` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `UpdatedBy` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `UpdatedDatetime` bigint NOT NULL,
  `UpdatedDateTimeDisplay` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`Type`,`Status`,`FlowName`,`Channel`,`SubType`,`VersionNo`,`CurrentUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.JWT_RefreshTokens
CREATE TABLE IF NOT EXISTS `JWT_RefreshTokens` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ApplicationName` varchar(50) NOT NULL,
  `ClientID` varchar(100) NOT NULL,
  `RefreshToken` varchar(50) NOT NULL,
  `CreatedTime` datetime(3) NOT NULL,
  `CreatedBy` varchar(50) NOT NULL,
  `LastUpdatedBy` varchar(50) NOT NULL,
  `LastUpdatedTime` datetime(3) NOT NULL,
  `Isactive` bit(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.KmsAesKeys
CREATE TABLE IF NOT EXISTS `KmsAesKeys` (
  `KeyID` varchar(50) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedOn` datetime(6) DEFAULT NULL,
  `ExpireOn` datetime(6) NOT NULL,
  `KeyData` longtext NOT NULL,
  PRIMARY KEY (`KeyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.KmsEventLog
CREATE TABLE IF NOT EXISTS `KmsEventLog` (
  `SeqNo` bigint NOT NULL AUTO_INCREMENT,
  `InstanceID` varchar(10) NOT NULL,
  `Resource` longtext,
  `Details` longtext,
  `Owner` varchar(500) DEFAULT NULL,
  `Time` datetime(6) NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`SeqNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.KmsSettings
CREATE TABLE IF NOT EXISTS `KmsSettings` (
  `AttributeID` varchar(50) NOT NULL,
  `AttributeValue` longtext,
  PRIMARY KEY (`AttributeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.LicenseServerData
CREATE TABLE IF NOT EXISTS `LicenseServerData` (
  `Id` int DEFAULT NULL,
  `LicenseServerDetails` text,
  `LicenseServiceDetails` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.LicenseServerSessionDetails
CREATE TABLE IF NOT EXISTS `LicenseServerSessionDetails` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Component` text,
  `SessionDetails` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.links
CREATE TABLE IF NOT EXISTS `links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `conv_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `interaction_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `uploaded_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `active` tinyint NOT NULL,
  `organization_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createdAt` datetime(6) NOT NULL,
  `updatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Maintenance_Details
CREATE TABLE IF NOT EXISTS `Maintenance_Details` (
  `Service_No` varchar(10) NOT NULL,
  `Maintenance_ID` varchar(20) NOT NULL,
  `Request_Back` varchar(10) DEFAULT NULL,
  `Request_Time` datetime(3) DEFAULT NULL,
  `Mobile_Number` varchar(10) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Maintenance_Master
CREATE TABLE IF NOT EXISTS `Maintenance_Master` (
  `Maintenance_ID` varchar(20) NOT NULL,
  `Status` varchar(15) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Type` varchar(15) NOT NULL,
  `Play_On` varchar(20) NOT NULL,
  `Start_Time` datetime(3) NOT NULL,
  `End_Time` datetime(3) DEFAULT NULL,
  `Eng_Wav` varchar(100) DEFAULT NULL,
  `Mand_Wav` varchar(100) DEFAULT NULL,
  `Created_By` varchar(30) NOT NULL,
  `Deactivated_By` varchar(30) DEFAULT NULL,
  `CSV_From` varchar(50) NOT NULL,
  `ID` int NOT NULL AUTO_INCREMENT,
  `SMS_Content` varchar(600) DEFAULT NULL,
  `SMS_Outage` bit(1) DEFAULT b'0',
  `Hotline` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Maintenance_ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.media
CREATE TABLE IF NOT EXISTS `media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `original_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `size` bigint NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `conv_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `interaction_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `version` int NOT NULL,
  `uploaded_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `active` tinyint NOT NULL,
  `organization_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createdAt` datetime(6) NOT NULL,
  `updatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `interaction_unique_index` (`interaction_id`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.MyIVRLang
CREATE TABLE IF NOT EXISTS `MyIVRLang` (
  `CLI` varchar(10) NOT NULL,
  `Language` varchar(10) DEFAULT NULL,
  `CREATE_TIME` datetime(3) DEFAULT NULL,
  `UPDATE_TIME` datetime(3) DEFAULT NULL,
  `LAST_UPDATE_TIME` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`CLI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Neural_Master
CREATE TABLE IF NOT EXISTS `Neural_Master` (
  `trace_id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(50) DEFAULT NULL,
  `sender` varchar(10) DEFAULT NULL,
  `sender_id` varchar(20) DEFAULT NULL,
  `request_type` varchar(15) DEFAULT NULL,
  `command_name` varchar(30) DEFAULT NULL,
  `response_type` varchar(20) DEFAULT NULL,
  `response_type_Desc` varchar(150) DEFAULT NULL,
  `channel` varchar(10) DEFAULT NULL,
  `context` varchar(20) DEFAULT NULL,
  `created_datetime` datetime(3) DEFAULT NULL,
  `service_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`trace_id`),
  KEY `IX_Neural_Master_trace_id` (`trace_id`),
  KEY `IX_Neural_Master_session_id` (`session_id`),
  KEY `IX_Neural_Master_created_datetime` (`created_datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Neural_NLPResponseData
CREATE TABLE IF NOT EXISTS `Neural_NLPResponseData` (
  `nlp_id` bigint NOT NULL AUTO_INCREMENT,
  `trace_id` bigint DEFAULT NULL,
  `request_text` longtext,
  `response_intent` varchar(100) DEFAULT NULL,
  `response_entities` varchar(50) DEFAULT NULL,
  `response_confidence` varchar(10) DEFAULT NULL,
  `request_datetime` datetime(3) DEFAULT NULL,
  `response_datetime` datetime(3) DEFAULT NULL,
  `plugin` varchar(30) DEFAULT NULL,
  `response_status` bit(1) DEFAULT NULL,
  `error_message` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`nlp_id`),
  KEY `IX_Neural_NLPResponseData_trace_id` (`trace_id`),
  KEY `IX_Neural_NLPResponseData_request_datetime` (`request_datetime`),
  KEY `IX_Neural_NLPResponseData_response_datetime` (`response_datetime`),
  CONSTRAINT `neural_nlpresponsedata_ibfk_1` FOREIGN KEY (`trace_id`) REFERENCES `Neural_Master` (`trace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Neural_STTAudioData
CREATE TABLE IF NOT EXISTS `Neural_STTAudioData` (
  `audio_id` bigint NOT NULL AUTO_INCREMENT,
  `stt_id` bigint DEFAULT NULL,
  `audio_url` longtext,
  `audio_size` varchar(25) DEFAULT NULL,
  `audio_duration` varchar(25) DEFAULT NULL,
  `created_datetime` datetime(3) DEFAULT NULL,
  `conversion_status` bit(1) DEFAULT NULL,
  `error_message` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`audio_id`),
  KEY `IX_Neural_Neural_STTAudioData_stt_id` (`stt_id`),
  CONSTRAINT `neural_sttaudiodata_ibfk_1` FOREIGN KEY (`stt_id`) REFERENCES `Neural_STTResponseData` (`stt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Neural_STTResponseData
CREATE TABLE IF NOT EXISTS `Neural_STTResponseData` (
  `stt_id` bigint NOT NULL AUTO_INCREMENT,
  `trace_id` bigint DEFAULT NULL,
  `message_source` varchar(10) DEFAULT NULL,
  `response_text` longtext,
  `response_confidence` varchar(10) DEFAULT NULL,
  `request_datetime` datetime(3) DEFAULT NULL,
  `response_datetime` datetime(3) DEFAULT NULL,
  `plugin` varchar(30) DEFAULT NULL,
  `response_status` bit(1) DEFAULT NULL,
  `error_message` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`stt_id`),
  KEY `IX_Neural_STTResponseData_trace_id` (`trace_id`),
  KEY `IX_Neural_STTResponseData_message_source` (`message_source`),
  KEY `IX_Neural_STTResponseData_request_datetime` (`request_datetime`),
  KEY `IX_Neural_STTResponseData_response_datetime` (`response_datetime`),
  CONSTRAINT `neural_sttresponsedata_ibfk_1` FOREIGN KEY (`trace_id`) REFERENCES `Neural_Master` (`trace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.NewLineSeparatedStringIntoRows
DELIMITER //
CREATE FUNCTION `NewLineSeparatedStringIntoRows`(p_CommadelimitedString LONGTEXT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
 		RETURN replace(quote(Lower(ltrim(rtrim(p_CommadelimitedString)))),'~',''',''');
END//
DELIMITER ;

-- Dumping structure for function OCM.NextDayCalculation
DELIMITER //
CREATE FUNCTION `NextDayCalculation`(
	p_EndDate DATETIME,
	v_tStartTime DATETIME,
 	v_tEndTime DATETIME,
 	v_nextDate DATETIME,
 	v_startDayOutMins DOUBLE,
	v_endDayOutMins DOUBLE,
	p_Type varchar(50)
) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	
	Declare v_sla DOUBLE; 
	Declare v_Day varchar(3);
	Declare v_dayOutMins DOUBLE;
	Declare v_diff INT;
	Declare minsdiff INT;
	Declare v_sod datetime(3);  
	Declare v_eod datetime(3);
	Declare v_OpStartTime varchar(10); 
	Declare v_OpEndTime varchar(10);
	
	set v_sla=0;
	set v_dayOutMins=0;
	set minsdiff=0;
		
	Drop temporary table if exists TempTable;
	Create temporary table TempTable 
		(WeeDay varchar(10),
		Start_Time varchar(10),
		End_Time varchar(10),
		VDN_Name varchar(50));

	Drop temporary table if exists HolidayTempTable;
	Create temporary table HolidayTempTable 
		(Holiday varchar(100),
		HolidayStartDate varchar(10),
		HolidayEndDate varchar(10),
		VDN varchar(10));
		
	insert into HolidayTempTable
		SELECT ANNOUNCED_HOLIDAY,Start_Date,End_Date,VDN 
		FROM IVR_HOLIDAY_LIST WHERE ltrim(rtrim(VDN))=ltrim(rtrim(p_Type));
		
	whileloop: while(1=1)
		do
			set v_nextDate = TIMESTAMPADD(day,1,v_nextDate);

			if(DATE_FORMAT(v_nextDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d')) then
				leave whileloop;
			end if;

			set v_Day= LEFT(DAYNAME( v_nextDate), 3);

			if(exists(select 1 from HolidayTempTable HT where DATE_FORMAT(v_nextDate,'%Y%m%d') >= DATE_FORMAT(convert(HT.HolidayStartDate, datetime),'%Y%m%d') and DATE_FORMAT(v_nextDate,'%Y%m%d') <= DATE_FORMAT(convert(HT.HolidayEndDate, datetime),'%Y%m%d')))
			then 
				set v_dayOutMins = v_dayOutMins + 24 * 60;
				#goto NextDayCalculation;
				RETURN (SELECT NextDayCalculation(p_EndDate,v_tStartTime,v_tEndTime,v_nextDate,	v_startDayOutMins,v_endDayOutMins));#, p_Type));
			end if;

			insert into TempTable
			SELECT `WEEKDAY`,START_TIME,END_TIME,GROUP_NAME FROM IVR_BUSINESS_HOUR WHERE 
			lower(ltrim(rtrim(WEEKDAY)))=lower(ltrim(rtrim(v_Day))) AND ltrim(rtrim(GROUP_NAME))=ltrim(rtrim(p_Type));

			if (not exists (select 1 from TempTable))
			then
				insert into TempTable values(null,'000001','235959',null);
			end if;

			select replace(Start_Time,':','') into v_OpStartTime from TempTable;
		
			select replace(End_Time,':','') into v_OpEndTime from TempTable;

			set v_sod= DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d'),'000001'),'%Y-%m-%d %H:%i:%s');
			set v_eod= DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d'),'235959'),'%Y-%m-%d %H:%i:%s');

			set v_tStartTime = DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d') , v_OpStartTime),'%Y-%m-%d %H:%i:%s');
			if(v_tStartTime =  cast('1753-1-1' as DATETIME)) then
				set v_tStartTime = v_sod;
			end if;

			set v_tEndTime = DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d') , v_OpEndTime),'%Y-%m-%d %H:%i:%s');
			
			if(v_tEndTime = cast('1753-1-1' as DATETIME)) then
				set v_tEndTime = v_eod;
			end if;

			set v_dayOutMins = v_dayOutMins + (24 * 60 - TIMESTAMPDIFF(minute,v_tStartTime,v_tEndTime));
			
			if(TIMESTAMPDIFF(minute,v_tStartTime,v_tEndTime) = 1439) then
			   set minsdiff = minsdiff + 1;
			end if;

			Delete from TempTable;
		end while whileloop;
	
	Delete from HolidayTempTable;
	
	set v_dayOutMins = v_dayOutMins - minsdiff;
	return v_dayOutMins;
	
END//
DELIMITER ;

-- Dumping structure for table OCM.NGI_DR
CREATE TABLE IF NOT EXISTS `NGI_DR` (
  `Session_ID` varchar(56) DEFAULT NULL,
  `Hotline` varchar(20) DEFAULT NULL,
  `CLI` varchar(16) DEFAULT NULL,
  `Skill_Number` varchar(20) DEFAULT NULL,
  `Datetime` datetime(3) DEFAULT NULL,
  `UCID` varchar(56) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notifications
CREATE TABLE IF NOT EXISTS `Notifications` (
  `NotificationId` int NOT NULL,
  `NotificationReferenceNumber` varchar(100) NOT NULL,
  `NotificationType` int NOT NULL,
  `NotificationHandler` varchar(100) NOT NULL,
  `StartDate` datetime NOT NULL,
  `Time` varchar(50) NOT NULL,
  `IsRecurrence` bit(1) NOT NULL,
  `RecurrenceType` varchar(100) DEFAULT NULL,
  `RecurrenceEvery` int DEFAULT NULL,
  `RecurrenceMonth` varchar(100) DEFAULT NULL,
  `RecurrenceWeekDays` varchar(100) DEFAULT NULL,
  `RecurrenceDate` varchar(100) DEFAULT NULL,
  `RecurrenceRangeType` varchar(100) DEFAULT NULL,
  `RecurrenceRangeValue` datetime DEFAULT NULL,
  `Reminders` varchar(100) DEFAULT NULL,
  `NotificationData` varchar(100) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `NotificationVersion` int NOT NULL,
  `AppId` varchar(50) NOT NULL,
  `AppReferenceId` varchar(100) NOT NULL,
  `AppReferenceType` varchar(100) NOT NULL,
  `IsDeleted` bit(1) NOT NULL,
  `CreatedBy` varchar(100) NOT NULL,
  `CreatedOn` datetime NOT NULL,
  `ModifiedBy` varchar(100) DEFAULT NULL,
  `ModifiedOn` datetime DEFAULT NULL,
  `IsRedisAllowedToStoreEntireData` bit(1) NOT NULL,
  `IsEncodeDecodeRequired` bit(1) NOT NULL,
  PRIMARY KEY (`NotificationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.NotificationStatus
CREATE TABLE IF NOT EXISTS `NotificationStatus` (
  `NotificationStatusId` int NOT NULL AUTO_INCREMENT,
  `StatusCode` varchar(100) DEFAULT NULL,
  `Description` varchar(400) DEFAULT NULL,
  KEY `NotificationStatusId` (`NotificationStatusId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_Channel
CREATE TABLE IF NOT EXISTS `Notify_Channel` (
  `ChannelId` int NOT NULL AUTO_INCREMENT,
  `ChannelCode` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `LastSequenceId` int DEFAULT NULL,
  PRIMARY KEY (`ChannelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_ChannelIdentity
CREATE TABLE IF NOT EXISTS `Notify_ChannelIdentity` (
  `IdentifierId` int NOT NULL AUTO_INCREMENT,
  `IdentifierCode` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`IdentifierId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_Processor
CREATE TABLE IF NOT EXISTS `Notify_Processor` (
  `RequestProcessId` int NOT NULL AUTO_INCREMENT,
  `NotifyRequestId` int DEFAULT NULL,
  `StatusId` int DEFAULT NULL,
  `ChannelId` int DEFAULT NULL,
  `ScheduleTime` datetime(3) DEFAULT NULL,
  `NotifyResponseId` int DEFAULT NULL,
  `Content` varchar(4000) DEFAULT NULL,
  `PrimaryRecipient` varchar(200) DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDateTime` datetime(3) DEFAULT NULL,
  `IsPrimaryFailed` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`RequestProcessId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_Requests
CREATE TABLE IF NOT EXISTS `Notify_Requests` (
  `RequestId` int NOT NULL AUTO_INCREMENT,
  `Message` varchar(4000) DEFAULT NULL,
  `RequestBy` varchar(100) DEFAULT NULL,
  `RequestDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`RequestId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_Response
CREATE TABLE IF NOT EXISTS `Notify_Response` (
  `ResponseId` int NOT NULL AUTO_INCREMENT,
  `Message` varchar(4000) DEFAULT NULL,
  `StatusId` int DEFAULT NULL,
  `ResponseBy` varchar(100) DEFAULT NULL,
  `ChannelId` int DEFAULT NULL,
  `ResponseDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ResponseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_SMMCustomer
CREATE TABLE IF NOT EXISTS `Notify_SMMCustomer` (
  `SMMCustomerId` bigint NOT NULL AUTO_INCREMENT,
  `NotificationChannel` int DEFAULT NULL,
  `CustomerOrgId` varchar(50) DEFAULT NULL,
  `ChannelIdentifier` int DEFAULT NULL,
  `CustomerChannelId` varchar(50) DEFAULT NULL,
  `UserID` varchar(32) DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `RegistrationMode` varchar(20) DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedDateTime` datetime(3) DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDateTime` datetime(3) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`SMMCustomerId`),
  UNIQUE KEY `UK_IX_N_Notify_SMMCustomer_CustomerOrgIdChannelIdentifierCustom` (`CustomerOrgId`,`ChannelIdentifier`,`CustomerChannelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Notify_SMMCustomerHistory
CREATE TABLE IF NOT EXISTS `Notify_SMMCustomerHistory` (
  `SMMCustomerHistId` bigint NOT NULL AUTO_INCREMENT,
  `SMMCustomerId` bigint DEFAULT NULL,
  `NotificationChannel` int DEFAULT NULL,
  `CustomerOrgId` varchar(100) DEFAULT NULL,
  `ChannelIdentifier` int DEFAULT NULL,
  `CustomerChannelId` varchar(100) DEFAULT NULL,
  `UserID` varchar(32) DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `RegistrationMode` varchar(20) DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedDateTime` datetime(3) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SMMCustomerHistId`),
  KEY `IX_N_Notify_SMMCustomerHistory_CustomerChannelId` (`CustomerChannelId`),
  KEY `IX_N_Notify_SMMCustomerHistory_CustomerOrgId` (`CustomerOrgId`),
  KEY `IX-N_Notify_SMMCustomerHistory_CreatedDateTime` (`CreatedDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCMCustomDashboard
CREATE TABLE IF NOT EXISTS `OCMCustomDashboard` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DashboardName` varchar(250) DEFAULT NULL,
  `DashboardCreatedBy` varchar(50) DEFAULT NULL,
  `DashboardCreatedOn` varchar(50) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCMCustomDashboardWidget
CREATE TABLE IF NOT EXISTS `OCMCustomDashboardWidget` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DashboardID` int NOT NULL,
  `WidgetType` varchar(250) DEFAULT NULL,
  `WidgetName` varchar(250) DEFAULT NULL,
  `WidgetQuery` varchar(4000) DEFAULT NULL,
  `WidgetCreatedBy` varchar(50) DEFAULT NULL,
  `WidgetCreatedOn` varchar(50) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCMRecentlyAccessedReportsList
CREATE TABLE IF NOT EXISTS `OCMRecentlyAccessedReportsList` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) NOT NULL,
  `channel` varchar(50) DEFAULT NULL,
  `reportname` varchar(50) DEFAULT NULL,
  `daterange` varchar(60) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `time` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentAuxReport
CREATE TABLE IF NOT EXISTS `OCM_AgentAuxReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) NOT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `AuxName` varchar(50) NOT NULL,
  `AuxCode` varchar(50) DEFAULT NULL,
  `AuxTime` varchar(14) DEFAULT NULL,
  `TimeStamp` varchar(20) NOT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_AgentAuxReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentHistoricalReport
CREATE TABLE IF NOT EXISTS `OCM_AgentHistoricalReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `AcdCalls` int DEFAULT NULL,
  `TotalAfterCallTime` int DEFAULT NULL,
  `TotalAvailTime` int DEFAULT NULL,
  `TotalAuxTime` int DEFAULT NULL,
  `ExtensionCalls` int DEFAULT NULL,
  `TotalExtensionTime` int DEFAULT NULL,
  `TotalStaffedTime` int DEFAULT NULL,
  `TotalHoldTime` int DEFAULT NULL,
  `ReportDateTime` datetime(3) NOT NULL,
  `intvl` int DEFAULT NULL,
  `Dateint` varchar(20) DEFAULT NULL,
  `Interval` varchar(20) DEFAULT NULL,
  `TotalInteractionTime` int DEFAULT NULL,
  `TotalChat` int DEFAULT NULL,
  `TotalChatTime` int DEFAULT NULL,
  `TotalAudioIP` int DEFAULT NULL,
  `TotalAudioIPTime` int DEFAULT NULL,
  `TransferCall` int DEFAULT NULL,
  `LastUpdatedBy` longtext,
  `TotalQueueTime` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_AgentHistoricalReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentInteractionReport
CREATE TABLE IF NOT EXISTS `OCM_AgentInteractionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `Direction` varchar(5) DEFAULT NULL,
  `DNIS` varchar(50) DEFAULT NULL,
  `ConnectedDateTime` varchar(20) DEFAULT NULL,
  `CreatedDateTime` varchar(20) DEFAULT NULL,
  `Ani` varchar(50) DEFAULT NULL,
  `ActiveTime` varchar(10) DEFAULT NULL,
  `HoldTime` varchar(10) DEFAULT NULL,
  `IsConferenced` bit(1) DEFAULT NULL,
  `IsTransfered` bit(1) DEFAULT NULL,
  `TPINTransferReconnected` bit(1) DEFAULT NULL,
  `SubChannel` varchar(50) DEFAULT NULL,
  `SubSessionID` varchar(100) DEFAULT NULL,
  `InteractionID` int DEFAULT NULL,
  `Skill` varchar(100) DEFAULT NULL,
  `DNISName` varchar(50) DEFAULT NULL,
  `TransferedTo` int DEFAULT NULL,
  `ConferencedTo` int DEFAULT NULL,
  `ConferenceToAgentList` varchar(100) DEFAULT NULL,
  `TransferToAgent` varchar(20) DEFAULT NULL,
  `TransferConferenceFromAgent` varchar(10) DEFAULT NULL,
  `TransferConferenceFromInteraction` varchar(5) DEFAULT NULL,
  `OtherData` longtext,
  `ClosedDateTime` varchar(20) DEFAULT NULL,
  `DisconnectedDateTime` varchar(20) DEFAULT NULL,
  `ClosedReason` varchar(20) DEFAULT NULL,
  `QueueTime` varchar(10) DEFAULT NULL,
  `ACWTime` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `RegisteredMobileNo` varchar(20) DEFAULT NULL,
  `SkillName` varchar(100) DEFAULT NULL,
  `HandleTime` varchar(10) DEFAULT NULL,
  `AgentComment` varchar(2000) DEFAULT NULL,
  `DisconnectedBy` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_AgentInteractionReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentLoginLogoutReport
CREATE TABLE IF NOT EXISTS `OCM_AgentLoginLogoutReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `StationID` varchar(50) DEFAULT NULL,
  `SkillList` longtext,
  `LoginDateTime` varchar(20) DEFAULT NULL,
  `LogoutDateTime` varchar(20) DEFAULT NULL,
  `LogoutReasonCode` varchar(5) DEFAULT NULL,
  `LogoutReason` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `SkillNameList` longtext,
  PRIMARY KEY (`ID`),
  KEY `IX_N_AgentLoginLogout_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentPerformanceReport
CREATE TABLE IF NOT EXISTS `OCM_AgentPerformanceReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Date` varchar(10) DEFAULT NULL,
  `OperatorID` varchar(100) DEFAULT NULL,
  `OperatorName` varchar(100) DEFAULT NULL,
  `SurveyID` varchar(50) DEFAULT NULL,
  `QuestionnaireName` varchar(600) DEFAULT NULL,
  `CallAttempts` int DEFAULT NULL,
  `AgentConversationTime` varchar(14) DEFAULT NULL,
  `SuccessCalls` int DEFAULT NULL,
  `TalkTimeOnSuccessCalls` varchar(14) DEFAULT NULL,
  `RefusedCalls` int DEFAULT NULL,
  `RejectedCalls` int DEFAULT NULL,
  `PickedUpCalls` int DEFAULT NULL,
  `TalkTimeOnPickedUpCalls` varchar(14) DEFAULT NULL,
  `DeclineCalls` int DEFAULT NULL,
  `TalkTimeOnDeclineCalls` varchar(14) DEFAULT NULL,
  `Callback` int DEFAULT NULL,
  `TalkTimeOnCallbackCalls` varchar(14) DEFAULT NULL,
  `MissedCalls` int DEFAULT NULL,
  `CallConnectedDateTime` varchar(20) DEFAULT NULL,
  `CallDisconnectedDateTime` varchar(20) DEFAULT NULL,
  `Interval` varchar(12) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `CampaignOrgUnit` varchar(100) DEFAULT NULL,
  `AgentOrgUnit` varchar(100) DEFAULT NULL,
  `CampaignName` varchar(100) DEFAULT NULL,
  `CampaignType` varchar(100) DEFAULT NULL,
  `SupervisorName` varchar(100) DEFAULT NULL,
  `TalkTimeOnRejectedCalls` varchar(14) DEFAULT NULL,
  `RecievedCallbacks` int DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_N_AgentPerformance_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentStateSummaryReport
CREATE TABLE IF NOT EXISTS `OCM_AgentStateSummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) NOT NULL,
  `Extension` varchar(20) DEFAULT NULL,
  `TotalLoggedInTime` int DEFAULT NULL,
  `TotalInteractions` int DEFAULT NULL,
  `TotalNotReadyTime` int DEFAULT NULL,
  `TotalReadyTime` int DEFAULT NULL,
  `TotalTalkTime` int DEFAULT NULL,
  `TotalAfterCallWorkTime` int DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_AgentStateSummaryReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentSummaryReport
CREATE TABLE IF NOT EXISTS `OCM_AgentSummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `StationID` varchar(50) DEFAULT NULL,
  `TotalVoice` int DEFAULT NULL,
  `TotalChat` int DEFAULT NULL,
  `TotalSM` int DEFAULT NULL,
  `TotalSMS` int DEFAULT NULL,
  `TotalEmail` int DEFAULT NULL,
  `TotalStaffedTime` varchar(14) DEFAULT NULL,
  `TotalInteractionTime` varchar(14) DEFAULT NULL,
  `TotalACWTime` varchar(14) DEFAULT NULL,
  `TotalAuxTime` varchar(14) DEFAULT NULL,
  `TotalExtIn` int DEFAULT NULL,
  `TotalExtOut` int DEFAULT NULL,
  `TotalTransferIn` int DEFAULT NULL,
  `TotalTransferOut` int DEFAULT NULL,
  `TotalConferenceIn` int DEFAULT NULL,
  `TotalConferenceOut` int DEFAULT NULL,
  `SkillList` longtext,
  `LoginDateTime` varchar(20) DEFAULT NULL,
  `LogoutDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TotalInteraction` int DEFAULT NULL,
  `TotalVoiceTime` varchar(14) DEFAULT NULL,
  `TotalChatTime` varchar(14) DEFAULT NULL,
  `TotalSMTime` varchar(14) DEFAULT NULL,
  `TotalSMSTime` varchar(14) DEFAULT NULL,
  `TotalEmailTime` varchar(14) DEFAULT NULL,
  `TotalAudioIP` int DEFAULT NULL,
  `TotalAudioIPTime` varchar(14) DEFAULT NULL,
  `TotalVideoIP` int DEFAULT NULL,
  `TotalVideoIPTime` varchar(14) DEFAULT NULL,
  `TotalFax` int DEFAULT NULL,
  `TotalFaxTime` varchar(14) DEFAULT NULL,
  `SkillNameList` longtext,
  PRIMARY KEY (`ID`),
  KEY `IX_N_AgentSummary_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AgentWrapupDataSummaryReport
CREATE TABLE IF NOT EXISTS `OCM_AgentWrapupDataSummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) NOT NULL,
  `TotalAcdCalls` int DEFAULT NULL,
  `TotalHandleTime` int DEFAULT NULL,
  `MaxHandleTime` int DEFAULT NULL,
  `TotalTalkTime` int DEFAULT NULL,
  `MaxTalkTime` int DEFAULT NULL,
  `TotalAfterCallWorkTime` int DEFAULT NULL,
  `MaxWorkTime` int DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_AgentWrapupDataSummaryReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AnalysisCountReport
CREATE TABLE IF NOT EXISTS `OCM_AnalysisCountReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Menu` varchar(100) DEFAULT NULL,
  `AccessCount` int DEFAULT NULL,
  `InvalidInput` int DEFAULT NULL,
  `NoInput` int DEFAULT NULL,
  `MaxTries` int DEFAULT NULL,
  `AgentTransfers` int DEFAULT NULL,
  `IvrDisconnects` int DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `MenuID` varchar(50) DEFAULT NULL,
  `MenuOrder` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_AnalysisCountReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_AudioVideoPlaybackReport
CREATE TABLE IF NOT EXISTS `OCM_AudioVideoPlaybackReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `ChatBotStartDateTime` varchar(20) DEFAULT NULL,
  `ChatBotEndDateTime` varchar(20) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `DurationTime` varchar(10) DEFAULT NULL,
  `CallBack` varchar(5) DEFAULT NULL,
  `IntentName` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `SegmentCode` varchar(50) DEFAULT NULL,
  `SubSegmentCode` varchar(50) DEFAULT NULL,
  `CustEntType` varchar(50) DEFAULT NULL,
  `IsChatConferenced` varchar(5) DEFAULT NULL,
  `IsChatTransfered` varchar(5) DEFAULT NULL,
  `QueueWaitTime` varchar(10) DEFAULT NULL,
  `AgentWaitTime` varchar(10) DEFAULT NULL,
  `UserWaitTime` varchar(10) DEFAULT NULL,
  `ChatEndReason` varchar(500) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `ChatBotSessionID` varchar(50) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  `AVType` varchar(15) DEFAULT NULL,
  `CustomerAVConnected` bit(1) DEFAULT NULL,
  `CustomerAVConnectTime` varchar(50) DEFAULT NULL,
  `AgentAVConnected` bit(1) DEFAULT NULL,
  `AgentAVConnectTime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_AudioVideoPlaybackReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_BlendedAgentReport
CREATE TABLE IF NOT EXISTS `OCM_BlendedAgentReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `TotalInboundcalls` int DEFAULT NULL,
  `TotalOutboundcalls` int DEFAULT NULL,
  `AvgInboundTalkTime` varchar(14) DEFAULT NULL,
  `AvgOutboundTalkTime` varchar(14) DEFAULT NULL,
  `TotalAvgTalkTime` varchar(14) DEFAULT NULL,
  `AvgInboundACWTime` varchar(14) DEFAULT NULL,
  `AvgOutboundACWTime` varchar(14) DEFAULT NULL,
  `TotalAvgACWTime` varchar(14) DEFAULT NULL,
  `AvgInboundHoldTime` varchar(14) DEFAULT NULL,
  `AvgOutboundHoldTime` varchar(14) DEFAULT NULL,
  `TotalAvgHoldTime` varchar(14) DEFAULT NULL,
  `TotalIdleTime` varchar(14) DEFAULT NULL,
  `AvgBreakTime` varchar(14) DEFAULT NULL,
  `AvgInboundIdleTime` varchar(14) DEFAULT NULL,
  `AvgOutboundIdleTime` varchar(14) DEFAULT NULL,
  `ClosedDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TotalInboundTalkTime` varchar(14) DEFAULT NULL,
  `TotalOutboundTalkTime` varchar(14) DEFAULT NULL,
  `TotalTalkTime` varchar(14) DEFAULT NULL,
  `TotalACWTime` varchar(14) DEFAULT NULL,
  `TotalInboundHoldTime` varchar(14) DEFAULT NULL,
  `TotalOutboundHoldTime` varchar(14) DEFAULT NULL,
  `TotalInboundACWTime` varchar(14) DEFAULT NULL,
  `TotalOutboundACWTime` varchar(14) DEFAULT NULL,
  `TotalHoldTime` varchar(14) DEFAULT NULL,
  `TotalBreakTime` varchar(14) DEFAULT NULL,
  `OutboundBreakTime` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_BlendedAgent_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_CallAttemptReport
CREATE TABLE IF NOT EXISTS `OCM_CallAttemptReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `JobID` varchar(20) DEFAULT NULL,
  `JobName` varchar(50) DEFAULT NULL,
  `InteractionDateTime` varchar(20) DEFAULT NULL,
  `CampaignID` varchar(100) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `CompletionCodeName` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TalkTimeDuration` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_CallAttempt_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_CallTransferReport
CREATE TABLE IF NOT EXISTS `OCM_CallTransferReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `CallerID` varchar(250) DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `CreditorDebitCardNumber` varchar(250) DEFAULT NULL,
  `CIN` varchar(250) DEFAULT NULL,
  `LastMenu` varchar(100) DEFAULT NULL,
  `LastMenu1` varchar(100) DEFAULT NULL,
  `LastMenu2` varchar(100) DEFAULT NULL,
  `LastMenu3` varchar(100) DEFAULT NULL,
  `HotlineNumber` varchar(50) DEFAULT NULL,
  `TransferredVDN` varchar(100) DEFAULT NULL,
  `IntentSkill` varchar(50) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `VDNName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_CallTransferReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatAgentPerformanceReport
CREATE TABLE IF NOT EXISTS `OCM_ChatAgentPerformanceReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `ChatTransferred` int DEFAULT NULL,
  `ChatConferenced` int DEFAULT NULL,
  `ActiveTime` int DEFAULT NULL,
  `HoldTime` varchar(50) DEFAULT NULL,
  `Createddatetime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `AverageACWTime` varchar(50) DEFAULT NULL,
  `Closeddatetime` varchar(20) DEFAULT NULL,
  `QueueTime` int DEFAULT NULL,
  `AgentWaitTime` int DEFAULT NULL,
  `UserWaitTime` int DEFAULT NULL,
  `ConfereneceRejected` int DEFAULT NULL,
  `TransferRejected` int DEFAULT NULL,
  `Rating` decimal(4,1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_ChatAgentPerformance_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatAgentPerformanceReport_Detail
CREATE TABLE IF NOT EXISTS `OCM_ChatAgentPerformanceReport_Detail` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Dnis` varchar(50) DEFAULT NULL,
  `Skill` varchar(20) DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  `IsTransfered` int DEFAULT NULL,
  `IsConferenced` int DEFAULT NULL,
  `Createddatetime` varchar(20) DEFAULT NULL,
  `Closeddatetime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TransferredOrConferencedFrom` varchar(100) DEFAULT NULL,
  `TransferredOrConferencedTo` varchar(100) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_ChatAgentPerformance_Detail_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatAnalysisCountReport
CREATE TABLE IF NOT EXISTS `OCM_ChatAnalysisCountReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Menu` varchar(100) DEFAULT NULL,
  `AccessCount` int DEFAULT NULL,
  `InvalidInput` int DEFAULT NULL,
  `NoInput` int DEFAULT NULL,
  `MaxTries` int DEFAULT NULL,
  `AgentTransfers` int DEFAULT NULL,
  `ChatDisconnects` int DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  `MenuID` varchar(50) DEFAULT NULL,
  `MenuOrder` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_ChatAnalysiscount_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatbotInteractionReport
CREATE TABLE IF NOT EXISTS `OCM_ChatbotInteractionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) NOT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `CallBack` varchar(5) DEFAULT NULL,
  `DurationTime` varchar(10) DEFAULT NULL,
  `QueueWaitTime` varchar(10) DEFAULT NULL,
  `AgentWaitTime` varchar(10) DEFAULT NULL,
  `UserWaitTime` varchar(10) DEFAULT NULL,
  `ChatEndReason` varchar(500) DEFAULT NULL,
  `IntentName` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `SegmentCode` varchar(50) DEFAULT NULL,
  `SubSegmentCode` varchar(50) DEFAULT NULL,
  `IsChatConferenced` varchar(5) DEFAULT NULL,
  `IsChatTransfered` varchar(5) DEFAULT NULL,
  `CustEntType` varchar(50) DEFAULT NULL,
  `ChatBotSessionID` varchar(50) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ChatBotStartDateTime` varchar(20) DEFAULT NULL,
  `ChatBotEndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_ChatbotInteractionReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatbotInteractionReportCallback
CREATE TABLE IF NOT EXISTS `OCM_ChatbotInteractionReportCallback` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `CallBackStatus` varchar(50) DEFAULT NULL,
  `CallBackDate` varchar(20) DEFAULT NULL,
  `CallBackTime` varchar(20) DEFAULT NULL,
  `CallBackCount` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_OCM_ChatbotInteractionReportCallback_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatbotInteractionReportTransScript
CREATE TABLE IF NOT EXISTS `OCM_ChatbotInteractionReportTransScript` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `InteractionDateTime` varchar(20) DEFAULT NULL,
  `InteractionText` varchar(4000) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `ServicedBy` varchar(100) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `MessageId` varchar(50) DEFAULT NULL,
  `ReplyId` varchar(50) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Action` varchar(20) DEFAULT NULL,
  `ActionText` varchar(1000) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_OCM_ChatbotInteractionReportTransScript_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatCSQAgentSummaryReport
CREATE TABLE IF NOT EXISTS `OCM_ChatCSQAgentSummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CSQID` int DEFAULT NULL,
  `CSQName` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `QueueTime` int DEFAULT NULL,
  `HandledTime` int DEFAULT NULL,
  `ActiveTime` int DEFAULT NULL,
  `AcceptTime` int DEFAULT NULL,
  `ChatPresented` int DEFAULT NULL,
  `ChatHandled` int DEFAULT NULL,
  `ChatAbandoned` int DEFAULT NULL,
  `Ratings` decimal(5,1) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_ChatCSQAgentSummaryReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatHostTransactionReport
CREATE TABLE IF NOT EXISTS `OCM_ChatHostTransactionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `RequestDateTime` varchar(20) DEFAULT NULL,
  `CIN` varchar(250) DEFAULT NULL,
  `TransactionName` varchar(50) DEFAULT NULL,
  `MenuDescription` varchar(100) DEFAULT NULL,
  `RequestMessage` varchar(2000) DEFAULT NULL,
  `ResponseMessage` varchar(2000) DEFAULT NULL,
  `HotlineNumber` varchar(50) DEFAULT NULL,
  `PhoneCode` varchar(20) DEFAULT NULL,
  `CIF` varchar(250) DEFAULT NULL,
  `CustomerSegment` varchar(50) DEFAULT NULL,
  `ResponseTime` varchar(15) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_ChatHostTransaction_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatInteractionChatBotReport
CREATE TABLE IF NOT EXISTS `OCM_ChatInteractionChatBotReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) NOT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `CallBack` varchar(5) DEFAULT NULL,
  `DurationTime` varchar(10) DEFAULT NULL,
  `QueueWaitTime` varchar(10) DEFAULT NULL,
  `AgentWaitTime` varchar(10) DEFAULT NULL,
  `UserWaitTime` varchar(10) DEFAULT NULL,
  `ChatEndReason` varchar(500) DEFAULT NULL,
  `IntentName` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `SegmentCode` varchar(50) DEFAULT NULL,
  `SubSegmentCode` varchar(50) DEFAULT NULL,
  `IsChatConferenced` varchar(5) DEFAULT NULL,
  `IsChatTransfered` varchar(5) DEFAULT NULL,
  `CustEntType` varchar(50) DEFAULT NULL,
  `ChatBotSessionID` varchar(150) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ChatBotStartDateTime` varchar(20) DEFAULT NULL,
  `ChatBotEndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_ChatInteractionChatBotReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatInteractionReport
CREATE TABLE IF NOT EXISTS `OCM_ChatInteractionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `CallBack` varchar(5) DEFAULT NULL,
  `DurationTime` varchar(10) DEFAULT NULL,
  `QueueWaitTime` varchar(10) DEFAULT NULL,
  `AgentWaitTime` varchar(10) DEFAULT NULL,
  `UserWaitTime` varchar(10) DEFAULT NULL,
  `ChatEndReason` varchar(500) DEFAULT NULL,
  `IntentName` varchar(50) DEFAULT NULL,
  `SegmentCode` varchar(50) DEFAULT NULL,
  `SubSegmentCode` varchar(50) DEFAULT NULL,
  `IsChatConferenced` varchar(5) DEFAULT NULL,
  `IsChatTransfered` varchar(5) DEFAULT NULL,
  `CustEntType` varchar(50) DEFAULT NULL,
  `KasistoSessionID` varchar(50) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ChatBotStartDateTime` varchar(20) DEFAULT NULL,
  `ChatBotEndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_ChatInteractionReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatInteractionReportCallback
CREATE TABLE IF NOT EXISTS `OCM_ChatInteractionReportCallback` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `CallBackStatus` varchar(50) DEFAULT NULL,
  `CallBackDate` varchar(20) DEFAULT NULL,
  `CallBackTime` varchar(20) DEFAULT NULL,
  `CallBackCount` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_ChatCallback_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatInteractionReportTransScript
CREATE TABLE IF NOT EXISTS `OCM_ChatInteractionReportTransScript` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `InteractionDateTime` varchar(20) DEFAULT NULL,
  `InteractionText` varchar(4000) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `ServicedBy` varchar(100) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `MessageId` varchar(50) DEFAULT NULL,
  `ReplyId` varchar(50) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Action` varchar(20) DEFAULT NULL,
  `ActionText` varchar(1000) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_TransScripts_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ChatTransferReport
CREATE TABLE IF NOT EXISTS `OCM_ChatTransferReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `CallerID` varchar(250) DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `CreditorDebitCardNumber` varchar(250) DEFAULT NULL,
  `CIN` varchar(250) DEFAULT NULL,
  `LastMenu` varchar(100) DEFAULT NULL,
  `LastMenu1` varchar(100) DEFAULT NULL,
  `LastMenu2` varchar(100) DEFAULT NULL,
  `LastMenu3` varchar(100) DEFAULT NULL,
  `HotlineNumber` varchar(50) DEFAULT NULL,
  `TransferredVDN` varchar(100) DEFAULT NULL,
  `IntentSkill` varchar(50) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_ChatTransferReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ConsolidatedDayWiseAgentReport
CREATE TABLE IF NOT EXISTS `OCM_ConsolidatedDayWiseAgentReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentId` varchar(50) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `TimeSpentOnInstantMeeting` int DEFAULT NULL,
  `TimeSpentOnScheduledMeeting` int DEFAULT NULL,
  `MultipleFaceDetected` int DEFAULT NULL,
  `NoFaceDetected` int DEFAULT NULL,
  `GadgetDetected` int DEFAULT NULL,
  `LivenessFailureDetected` int DEFAULT NULL,
  `TotalViolationsMade` int DEFAULT NULL,
  `TotalstaffedTime` int DEFAULT NULL,
  `InActiveTime` int DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_ConsolidatedDayWiseAgentReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_CSOSurveyReport
CREATE TABLE IF NOT EXISTS `OCM_CSOSurveyReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `StartDateTime` varchar(20) NOT NULL,
  `CIFNumber` varchar(15) DEFAULT NULL,
  `ContactName` varchar(50) DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `DNIS` varchar(10) DEFAULT NULL,
  `QN1Text` varchar(200) DEFAULT NULL,
  `QN2Text` varchar(200) DEFAULT NULL,
  `QN3Text` varchar(200) DEFAULT NULL,
  `QN4Text` varchar(200) DEFAULT NULL,
  `QN5Text` varchar(200) DEFAULT NULL,
  `QN1Result` varchar(50) DEFAULT NULL,
  `QN2Result` varchar(50) DEFAULT NULL,
  `QN3Result` varchar(50) DEFAULT NULL,
  `QN4Result` varchar(50) DEFAULT NULL,
  `QN5Result` varchar(50) DEFAULT NULL,
  `CallDuration` varchar(20) DEFAULT NULL,
  `Language` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) NOT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `QN6Text` varchar(200) DEFAULT NULL,
  `QN7Text` varchar(200) DEFAULT NULL,
  `QN8Text` varchar(200) DEFAULT NULL,
  `QN9Text` varchar(200) DEFAULT NULL,
  `QN10Text` varchar(200) DEFAULT NULL,
  `QN6Result` varchar(50) DEFAULT NULL,
  `QN7Result` varchar(50) DEFAULT NULL,
  `QN8Result` varchar(50) DEFAULT NULL,
  `QN9Result` varchar(50) DEFAULT NULL,
  `QN10Result` varchar(50) DEFAULT NULL,
  `CompanyName` varchar(100) DEFAULT NULL,
  `CustomerSegment` varchar(30) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_CSOSurveyReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_DashboardColorCodeConfig
CREATE TABLE IF NOT EXISTS `OCM_DashboardColorCodeConfig` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DashboardName` varchar(50) NOT NULL,
  `ColumnName` varchar(50) NOT NULL,
  `StartRange` varchar(20) NOT NULL,
  `EndRange` varchar(20) NOT NULL,
  `BackgroundColor` varchar(20) NOT NULL,
  `FontColor` varchar(20) NOT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_OCM_DashboardColorCodeConfig` (`DashboardName`,`ColumnName`,`StartRange`,`EndRange`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.ocm_dataaccessauditlogreport
CREATE TABLE IF NOT EXISTS `ocm_dataaccessauditlogreport` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `component` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `actioncontext` varchar(50) NOT NULL,
  `actionrefid` varchar(50) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `actiondatetime` datetime(3) NOT NULL,
  `actionby` varchar(50) NOT NULL,
  `agentid` varchar(50) NOT NULL,
  `userhost` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_N_ocm_dataaccessauditlogreport_actiondatetime` (`actiondatetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_DNCListReport
CREATE TABLE IF NOT EXISTS `OCM_DNCListReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CampaignID` varchar(100) DEFAULT NULL,
  `CampaignDate` varchar(14) DEFAULT NULL,
  `CampaignName` varchar(100) DEFAULT NULL,
  `CallDate` varchar(14) DEFAULT NULL,
  `CallTime` varchar(14) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `CustomerName1` varchar(50) DEFAULT NULL,
  `CustomerName2` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `Phone1` varchar(50) DEFAULT NULL,
  `Phone2` varchar(50) DEFAULT NULL,
  `Phone3` varchar(50) DEFAULT NULL,
  `Phone4` varchar(50) DEFAULT NULL,
  `NSPPhone` varchar(50) DEFAULT NULL,
  `CompletionCodeName` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `Mode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_DNCList_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_EKYCStatusReport
CREATE TABLE IF NOT EXISTS `OCM_EKYCStatusReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `AuditType` varchar(20) NOT NULL,
  `RequestBy` varchar(100) NOT NULL,
  `RequestComment` varchar(2000) DEFAULT NULL,
  `RequestDateTime` datetime(3) DEFAULT NULL,
  `AuditBy` varchar(100) DEFAULT NULL,
  `AuditComment` varchar(2000) DEFAULT NULL,
  `AuditDateTime` datetime(3) DEFAULT NULL,
  `RequestStatus` varchar(20) NOT NULL,
  `ResponseMessage` varchar(255) DEFAULT NULL,
  `CustInfoOne` varchar(255) DEFAULT NULL,
  `CustInfoTwo` varchar(255) DEFAULT NULL,
  `CustInfoThree` varchar(255) DEFAULT NULL,
  `CustInfoFour` varchar(255) DEFAULT NULL,
  `CustInfoFive` varchar(255) DEFAULT NULL,
  `ReportDateTime` datetime(3) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_EKYCStatusReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_EmailStatusReport
CREATE TABLE IF NOT EXISTS `OCM_EmailStatusReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(16) DEFAULT NULL,
  `From` varchar(250) DEFAULT NULL,
  `ToList` longtext,
  `CCList` longtext,
  `BCCList` longtext,
  `Subject` varchar(500) DEFAULT NULL,
  `Body` longtext,
  `SendDate` varchar(8) DEFAULT NULL,
  `SendTime` varchar(6) DEFAULT NULL,
  `SentDate` varchar(8) DEFAULT NULL,
  `SentTime` varchar(6) DEFAULT NULL,
  `ReceivedDate` varchar(8) DEFAULT NULL,
  `ReceivedTime` varchar(6) DEFAULT NULL,
  `CurrentStatus` varchar(150) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `EmailType` varchar(20) DEFAULT NULL,
  `TimeStamp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_FaxCountReport
CREATE TABLE IF NOT EXISTS `OCM_FaxCountReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SingaporeDollerDepositRates` bigint DEFAULT NULL,
  `ForeignCurrencyTimeDepositRates` bigint DEFAULT NULL,
  `iSavvyRates` bigint DEFAULT NULL,
  `ForeignExchangeRates` bigint DEFAULT NULL,
  `FundTransfer` bigint DEFAULT NULL,
  `StopChequePayment` bigint DEFAULT NULL,
  `Last3Transactions` bigint DEFAULT NULL,
  `CurrentAccountStatementRequest` bigint DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `Language` varchar(50) DEFAULT NULL,
  `PersonalUpdate` bigint DEFAULT NULL,
  `BusinessUpdate` bigint DEFAULT NULL,
  `eserviceUpdate` bigint DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_FaxCountReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_InteractionActionsReport
CREATE TABLE IF NOT EXISTS `OCM_InteractionActionsReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `AgentID` varchar(50) DEFAULT NULL,
  `InteractionID` int DEFAULT NULL,
  `Action` varchar(50) DEFAULT NULL,
  `ActionDateTime` varchar(20) DEFAULT NULL,
  `ActionResult` varchar(5) DEFAULT NULL,
  `Details` longtext,
  `LoginInstanceID` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  KEY `IX_C_InteractionActions_ID` (`ID`),
  KEY `IX_N_InteractionActionsReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_IvrCallTraceReport
CREATE TABLE IF NOT EXISTS `OCM_IvrCallTraceReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `Name` varchar(250) DEFAULT NULL,
  `CallerID` varchar(250) DEFAULT NULL,
  `UID` varchar(250) DEFAULT NULL,
  `CIN` varchar(250) DEFAULT NULL,
  `MembershipID` varchar(250) DEFAULT NULL,
  `CallerStatus` varchar(50) DEFAULT NULL,
  `StartDate` varchar(14) DEFAULT NULL,
  `StartTime` varchar(14) DEFAULT NULL,
  `EndDate` varchar(14) DEFAULT NULL,
  `EndTime` varchar(14) DEFAULT NULL,
  `Duration` varchar(14) DEFAULT NULL,
  `Lastmenu1` varchar(100) DEFAULT NULL,
  `Lastmenu2` varchar(100) DEFAULT NULL,
  `Lastmenu3` varchar(100) DEFAULT NULL,
  `Lastmenu4` varchar(100) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `HotlineNumber` varchar(250) DEFAULT NULL,
  `TransferredFlag` varchar(50) DEFAULT NULL,
  `TransferVDN` varchar(250) DEFAULT NULL,
  `TransferredToFeewaiver` varchar(250) DEFAULT NULL,
  `Intent` varchar(250) DEFAULT NULL,
  `OTPVerified` varchar(250) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `Segment` varchar(50) DEFAULT NULL,
  `Language` varchar(50) DEFAULT NULL,
  `TransferCount` varchar(50) DEFAULT NULL,
  `SMSEligibility` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TpinVerified` varchar(50) DEFAULT NULL,
  `VDNName` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_CallTrace_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_IvrHostTransactionReport
CREATE TABLE IF NOT EXISTS `OCM_IvrHostTransactionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `RequestDateTime` varchar(20) DEFAULT NULL,
  `CIN` varchar(250) DEFAULT NULL,
  `TransactionName` varchar(50) DEFAULT NULL,
  `MenuDescription` varchar(100) DEFAULT NULL,
  `RequestMessage` varchar(2000) DEFAULT NULL,
  `ResponseMessage` varchar(2000) DEFAULT NULL,
  `HotlineNumber` varchar(50) DEFAULT NULL,
  `PhoneCode` varchar(20) DEFAULT NULL,
  `CIF` varchar(250) DEFAULT NULL,
  `CustomerSegment` varchar(50) DEFAULT NULL,
  `ResponseTime` varchar(15) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_IvrHostTransaction_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_IvrJourneyReport
CREATE TABLE IF NOT EXISTS `OCM_IvrJourneyReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `StartDateTime` datetime(3) DEFAULT NULL,
  `EndDateTime` datetime(3) DEFAULT NULL,
  `Duration` varchar(20) DEFAULT NULL,
  `CallerID` varchar(30) DEFAULT NULL,
  `Hotline` varchar(50) DEFAULT NULL,
  `TransferredFlag` varchar(2) DEFAULT NULL,
  `TransferVDN` varchar(50) DEFAULT NULL,
  `TransferOrDisconnectReason` varchar(250) DEFAULT NULL,
  `ServiceNumber` varchar(20) DEFAULT NULL,
  `CustomerID` varchar(19) DEFAULT NULL,
  `CustomerIDType` varchar(50) DEFAULT NULL,
  `CustomerType` varchar(50) DEFAULT NULL,
  `DNIS` varchar(30) DEFAULT NULL,
  `Language` varchar(20) DEFAULT NULL,
  `LastMenu` varchar(100) DEFAULT NULL,
  `ProductType` varchar(50) DEFAULT NULL,
  `ServiceType` varchar(5) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `OTPVerified` varchar(50) DEFAULT NULL,
  `TpinVerified` varchar(50) DEFAULT NULL,
  `CIN` varchar(50) DEFAULT NULL,
  `Lastmenu1` varchar(100) DEFAULT NULL,
  `Lastmenu2` varchar(100) DEFAULT NULL,
  `Lastmenu3` varchar(100) DEFAULT NULL,
  `Lastmenu4` varchar(100) DEFAULT NULL,
  `TpinTransfered` varchar(50) DEFAULT NULL,
  `TransferredToFeewaiver` varchar(50) DEFAULT NULL,
  `SMSEligibility` varchar(10) DEFAULT NULL,
  `VDNName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_IvrJourneyReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_IvrJourneyReport_MenuNavigation
CREATE TABLE IF NOT EXISTS `OCM_IvrJourneyReport_MenuNavigation` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `StartDateTime` datetime(3) DEFAULT NULL,
  `EndDateTime` datetime(3) DEFAULT NULL,
  `MenuID` varchar(100) DEFAULT NULL,
  `InvalidInput` varchar(10) DEFAULT NULL,
  `NoInput` varchar(10) DEFAULT NULL,
  `MaxCount` varchar(10) DEFAULT NULL,
  `MenuOrder` int DEFAULT NULL,
  `MenuName` varchar(100) DEFAULT NULL,
  `Value` varchar(15) DEFAULT NULL,
  `MenuStartDateTime` datetime(3) DEFAULT NULL,
  `MenuEndDateTime` datetime(3) DEFAULT NULL,
  `AccessDateTime` datetime(3) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_IvrJourneyReport_MenuNavigation_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_IvrJourneyReport_Transaction
CREATE TABLE IF NOT EXISTS `OCM_IvrJourneyReport_Transaction` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `StartDateTime` datetime(3) DEFAULT NULL,
  `EndDateTime` datetime(3) DEFAULT NULL,
  `TransactionName` varchar(50) DEFAULT NULL,
  `MenuDescription` varchar(100) DEFAULT NULL,
  `TransactionDateTime` datetime(3) DEFAULT NULL,
  `RequestDateTime` datetime(3) DEFAULT NULL,
  `ResponseDateTime` datetime(3) DEFAULT NULL,
  `RequestMessage` varchar(2000) DEFAULT NULL,
  `ResponseMessage` varchar(2000) DEFAULT NULL,
  `ResponseTime` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_IvrJourneyReport_Transaction_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_LINEOverallStatisticReport
CREATE TABLE IF NOT EXISTS `OCM_LINEOverallStatisticReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CIF` varchar(50) DEFAULT NULL,
  `LINEID` varchar(50) DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `StatementEnquiry` int DEFAULT NULL,
  `RewardsEnquiry` int DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_LINEOverallStatisticReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_MX_InteractionReport_Actions
CREATE TABLE IF NOT EXISTS `OCM_MX_InteractionReport_Actions` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `InteractionID` varchar(5) DEFAULT NULL,
  `Action` varchar(50) DEFAULT NULL,
  `ActionDateTime` datetime(3) DEFAULT NULL,
  `ActionResult` varchar(5) DEFAULT NULL,
  `Details` longtext,
  `LoginInstanceID` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_MX_InteractionReport_Actions_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_MX_InteractionReport_Agent
CREATE TABLE IF NOT EXISTS `OCM_MX_InteractionReport_Agent` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `Direction` varchar(5) DEFAULT NULL,
  `DNIS` varchar(50) DEFAULT NULL,
  `ConnectedDateTime` datetime(3) DEFAULT NULL,
  `CreatedDateTime` datetime(3) DEFAULT NULL,
  `Ani` varchar(50) DEFAULT NULL,
  `ActiveTime` time(3) DEFAULT NULL,
  `HoldTime` time(3) DEFAULT NULL,
  `IsConferenced` bit(1) DEFAULT NULL,
  `IsTransfered` bit(1) DEFAULT NULL,
  `TPINTransferReconnected` bit(1) DEFAULT NULL,
  `SubChannel` varchar(50) DEFAULT NULL,
  `SubSessionID` varchar(100) DEFAULT NULL,
  `InteractionID` int DEFAULT NULL,
  `Skill` varchar(100) DEFAULT NULL,
  `DnisName` varchar(50) DEFAULT NULL,
  `TransferedTo` int DEFAULT NULL,
  `ConferencedTo` int DEFAULT NULL,
  `ConferenceToAgentList` varchar(100) DEFAULT NULL,
  `TransferToAgent` varchar(20) DEFAULT NULL,
  `TransferConferenceFromAgent` varchar(10) DEFAULT NULL,
  `TransferConferenceFromInteraction` varchar(5) DEFAULT NULL,
  `OtherData` longtext,
  `ClosedDateTime` datetime(3) DEFAULT NULL,
  `DisconnectedDateTime` datetime(3) DEFAULT NULL,
  `ClosedReason` varchar(20) DEFAULT NULL,
  `QueueTime` time(3) DEFAULT NULL,
  `AcwTime` time(3) DEFAULT NULL,
  `CIF` varchar(50) DEFAULT NULL,
  `RegisteredMobileNo` varchar(20) DEFAULT NULL,
  `SkillName` varchar(100) DEFAULT NULL,
  `HandleTime` time(3) DEFAULT NULL,
  `AgentComment` varchar(2000) DEFAULT NULL,
  `AgentWaitTimeForResponse` int DEFAULT NULL,
  `UserWaitTimeForResponse` int DEFAULT NULL,
  `Intent` varchar(250) DEFAULT NULL,
  `DisconnectReason` varchar(25) DEFAULT NULL,
  `DisconnectedBy` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_MX_InteractionReport_Agent_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_MX_InteractionReport_Bot
CREATE TABLE IF NOT EXISTS `OCM_MX_InteractionReport_Bot` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `StartDateTime` datetime(3) DEFAULT NULL,
  `EndDateTime` datetime(3) DEFAULT NULL,
  `Duration` varchar(20) DEFAULT NULL,
  `CallerID` varchar(30) DEFAULT NULL,
  `Hotline` varchar(50) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `TransferredFlag` varchar(2) DEFAULT NULL,
  `TransferVDN` varchar(50) DEFAULT NULL,
  `VDNName` varchar(50) DEFAULT NULL,
  `TransferOrDisconnectReason` varchar(250) DEFAULT NULL,
  `ServiceNumber` varchar(20) DEFAULT NULL,
  `CustomerID` varchar(19) DEFAULT NULL,
  `CustomerIDType` varchar(50) DEFAULT NULL,
  `CustomerType` varchar(50) DEFAULT NULL,
  `DNIS` varchar(30) DEFAULT NULL,
  `Language` varchar(20) DEFAULT NULL,
  `LastMenu` varchar(100) DEFAULT NULL,
  `ProductType` varchar(50) DEFAULT NULL,
  `ServiceType` varchar(5) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `OTPVerified` varchar(50) DEFAULT NULL,
  `TpinVerified` varchar(50) DEFAULT NULL,
  `CIN` varchar(50) DEFAULT NULL,
  `Lastmenu1` varchar(50) DEFAULT NULL,
  `Lastmenu2` varchar(50) DEFAULT NULL,
  `Lastmenu3` varchar(50) DEFAULT NULL,
  `Lastmenu4` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_MX_InteractionReport_Bot_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_MX_InteractionReport_Transcript
CREATE TABLE IF NOT EXISTS `OCM_MX_InteractionReport_Transcript` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `InteractionDateTime` datetime(3) DEFAULT NULL,
  `InteractionText` varchar(500) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `SubChannel` varchar(50) DEFAULT NULL,
  `ServicedBy` varchar(100) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `MessageId` varchar(100) DEFAULT NULL,
  `ReplyId` varchar(50) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Action` varchar(20) DEFAULT NULL,
  `ActionText` varchar(1000) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_MX_InteractionReport_Transcript_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_MX_InteractionReport_Usage
CREATE TABLE IF NOT EXISTS `OCM_MX_InteractionReport_Usage` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `StartDateTime` datetime(3) DEFAULT NULL,
  `EndDateTime` datetime(3) DEFAULT NULL,
  `MenuID` varchar(100) DEFAULT NULL,
  `MenuName` varchar(100) DEFAULT NULL,
  `InvalidInput` varchar(10) DEFAULT NULL,
  `NoInput` varchar(10) DEFAULT NULL,
  `MaxCount` varchar(10) DEFAULT NULL,
  `MenuOrder` int DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_MX_InteractionReport_Usage_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_PersonalizeIVRReport
CREATE TABLE IF NOT EXISTS `OCM_PersonalizeIVRReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(20) NOT NULL,
  `CallerID` varchar(30) DEFAULT NULL,
  `CIN` varchar(60) NOT NULL,
  `CINSuffix` varchar(2) NOT NULL,
  `CallerIdentificationType` varchar(50) DEFAULT NULL,
  `CSSGResponseStatus` varchar(10) NOT NULL,
  `ExclusionFlag` varchar(1) NOT NULL,
  `VoicePromptID` varchar(60) NOT NULL,
  `ServiceID` varchar(100) NOT NULL,
  `SMSAcceptance` varchar(10) NOT NULL,
  `SMSSentStatus` varchar(20) DEFAULT NULL,
  `SMSSentDateTime` varchar(20) DEFAULT NULL,
  `SMSMobileNo` varchar(20) DEFAULT NULL,
  `SMSMobileType` varchar(20) NOT NULL,
  `URLLink` varchar(255) NOT NULL,
  `SMSTemplateID` varchar(60) NOT NULL,
  `CallStartDateTime` varchar(50) DEFAULT NULL,
  `CallEndDateTime` varchar(50) DEFAULT NULL,
  `CallDuration` varchar(20) DEFAULT NULL,
  `LastMenu` varchar(100) DEFAULT NULL,
  `CallerStatus` varchar(50) DEFAULT NULL,
  `TransferFlag` varchar(10) DEFAULT NULL,
  `TransferVDN` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_PersonalizeIVR_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_ProfanityWordsViolationReport
CREATE TABLE IF NOT EXISTS `OCM_ProfanityWordsViolationReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Channel` varchar(20) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `Action` varchar(50) DEFAULT NULL,
  `AttemptDateTime` varchar(20) DEFAULT NULL,
  `Message` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `GroupID` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`),
  KEY `IX_C_ProfanityWordsViolation_ID` (`ID`),
  KEY `IX_N_ProfanityWordsViolationReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_RespondentSummaryReport
CREATE TABLE IF NOT EXISTS `OCM_RespondentSummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `RespondentName` varchar(100) DEFAULT NULL,
  `RespondentPhoneNumber` varchar(100) DEFAULT NULL,
  `CallAttempts` int DEFAULT NULL,
  `MissedCalls` int DEFAULT NULL,
  `RejectedCalls` int DEFAULT NULL,
  `PickedUpCalls` int DEFAULT NULL,
  `DeclineCalls` int DEFAULT NULL,
  `Callback` int DEFAULT NULL,
  `SuccessCalls` int DEFAULT NULL,
  `AgentConnectTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_RespondentSummary_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_RespondentSummarySurveyDetailsReport
CREATE TABLE IF NOT EXISTS `OCM_RespondentSummarySurveyDetailsReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `RespondentName` varchar(100) DEFAULT NULL,
  `SurveyStartDateTime` varchar(20) DEFAULT NULL,
  `SurveyEndDateTime` varchar(20) DEFAULT NULL,
  `QuestionID` varchar(200) DEFAULT NULL,
  `Question` varchar(500) DEFAULT NULL,
  `Answers` varchar(4000) DEFAULT NULL,
  `ResponseTime` varchar(14) DEFAULT NULL,
  `ResponseStartDateTime` varchar(20) DEFAULT NULL,
  `ResponseEndDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `RespondentPhoneNumber` varchar(100) DEFAULT NULL,
  `QuestionnaireName` varchar(600) DEFAULT NULL,
  `SurveyID` varchar(50) DEFAULT NULL,
  `Intent` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_RespondentSummarySurveyDetails_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SkillHistoricalReport
CREATE TABLE IF NOT EXISTS `OCM_SkillHistoricalReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SkillId` varchar(20) DEFAULT NULL,
  `SkillName` varchar(50) DEFAULT NULL,
  `AcdCalls` int DEFAULT NULL,
  `intvl` int DEFAULT NULL,
  `Dateint` varchar(20) DEFAULT NULL,
  `Interval` varchar(20) DEFAULT NULL,
  `SpeedOfAnswer` int DEFAULT NULL,
  `AbandCalls` int DEFAULT NULL,
  `TotalAbandTime` int DEFAULT NULL,
  `TotalTalkTime` int DEFAULT NULL,
  `TotalAfterCallTime` int DEFAULT NULL,
  `FlowIn` int DEFAULT NULL,
  `FlowOut` int DEFAULT NULL,
  `TotalAuxTime` int DEFAULT NULL,
  `TotalStaffedTime` int DEFAULT NULL,
  `ServiceLevel` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) NOT NULL,
  `CallsHandledWithinSLAThreshold` int DEFAULT NULL,
  `CallsAbandonedAfterSLAThreshold` int DEFAULT NULL,
  `PassedCalls` int DEFAULT NULL,
  `TransferCall` int DEFAULT NULL,
  `TotalStaffedAgents` int DEFAULT NULL,
  `LastUpdatedBy` longtext,
  PRIMARY KEY (`ID`),
  KEY `IX_C_SkillHistorical_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SkillProfileReport
CREATE TABLE IF NOT EXISTS `OCM_SkillProfileReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SkillID` varchar(50) DEFAULT NULL,
  `SkillName` varchar(50) DEFAULT NULL,
  `Interval` varchar(20) DEFAULT NULL,
  `IntervalID` int DEFAULT NULL,
  `InteractionType` varchar(100) DEFAULT NULL,
  `ZeroToFive` bigint DEFAULT NULL,
  `FiveToTen` bigint DEFAULT NULL,
  `TenToFifteen` bigint DEFAULT NULL,
  `FifteenToTwenty` bigint DEFAULT NULL,
  `TwentyToTwentyFive` bigint DEFAULT NULL,
  `TwentyFiveToThirty` bigint DEFAULT NULL,
  `ThirtyToThirtyFive` bigint DEFAULT NULL,
  `ThirtyFiveToFourty` bigint DEFAULT NULL,
  `FourtyToFourtyFive` bigint DEFAULT NULL,
  `FourtyFiveMore` bigint DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `LastUpdatedBy` longtext,
  PRIMARY KEY (`ID`),
  KEY `IX_N_SkillProfileReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SmsHostTransactionReport
CREATE TABLE IF NOT EXISTS `OCM_SmsHostTransactionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(15) DEFAULT NULL,
  `RequestDateTime` varchar(20) DEFAULT NULL,
  `ResponseDateTime` varchar(20) DEFAULT NULL,
  `TransactionName` varchar(50) DEFAULT NULL,
  `RequestMessage` varchar(2000) DEFAULT NULL,
  `ResponseMessage` varchar(2000) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_SmsHostTransaction_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SMSInteractionReport
CREATE TABLE IF NOT EXISTS `OCM_SMSInteractionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `StartDateTime` varchar(20) DEFAULT NULL,
  `EndDateTime` varchar(20) DEFAULT NULL,
  `Source` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_SMSInteractionReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SMSInteractionReportTransScript
CREATE TABLE IF NOT EXISTS `OCM_SMSInteractionReportTransScript` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) NOT NULL,
  `InteractionDateTime` varchar(20) DEFAULT NULL,
  `InteractionText` varchar(4000) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `ServicedBy` varchar(100) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_C_SMSTransScripts_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SMSReport
CREATE TABLE IF NOT EXISTS `OCM_SMSReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `EnteredCIN` varchar(50) DEFAULT NULL,
  `RegMobCIN` varchar(50) DEFAULT NULL,
  `SMSSentStatus` varchar(20) DEFAULT NULL,
  `SMSSentDateTime` varchar(20) DEFAULT NULL,
  `SMSMobileNo` varchar(20) DEFAULT NULL,
  `OCMTemplateID` varchar(20) DEFAULT NULL,
  `ICOMTemplateID` varchar(50) DEFAULT NULL,
  `SMSMarketingPromptPoint` varchar(50) DEFAULT NULL,
  `SMSTriggeredPoint` varchar(20) DEFAULT NULL,
  `TerminateOrContinue` varchar(10) DEFAULT NULL,
  `SMSOfferedDateTime` varchar(20) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `TemplateMessage` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_SMS_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SMSTraceReport
CREATE TABLE IF NOT EXISTS `OCM_SMSTraceReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(100) NOT NULL,
  `OutgoingNumber` varchar(50) NOT NULL,
  `AgentID` varchar(50) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `SentDateTime` datetime(3) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_SMSTraceReport_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_SurveySummaryReport
CREATE TABLE IF NOT EXISTS `OCM_SurveySummaryReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `RespondentName` varchar(100) DEFAULT NULL,
  `RespondentPhoneNumber` varchar(100) DEFAULT NULL,
  `OperatorID` varchar(50) DEFAULT NULL,
  `OperatorName` varchar(50) DEFAULT NULL,
  `SurveyID` varchar(50) DEFAULT NULL,
  `ExtensionNumber` varchar(50) DEFAULT NULL,
  `UCID` varchar(100) DEFAULT NULL,
  `CallConnectedDateTime` varchar(20) DEFAULT NULL,
  `CallDisconnectedDateTime` varchar(20) DEFAULT NULL,
  `CallDuration` varchar(14) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  `QuestionnaireName` varchar(600) DEFAULT NULL,
  `Intent` varchar(100) DEFAULT NULL,
  `HelpHitCount` int DEFAULT NULL,
  `SurveyCreatedDateTime` varchar(20) DEFAULT NULL,
  `SurveyLastModifiedDateTime` varchar(20) DEFAULT NULL,
  `SurveyCreator` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_SurveySummary_ReportDateTime` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OCM_TransactionReport
CREATE TABLE IF NOT EXISTS `OCM_TransactionReport` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TransactionName` varchar(100) NOT NULL,
  `Successful` varchar(5) NOT NULL,
  `UnSuccessful` varchar(5) NOT NULL,
  `PhoneCode` varchar(20) DEFAULT NULL,
  `CIF` varchar(20) DEFAULT NULL,
  `NRIC` varchar(20) DEFAULT NULL,
  `Language` varchar(10) DEFAULT NULL,
  `ReportDateTime` datetime(3) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OCM_TransactionReport` (`ReportDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_Chat_Interaction_History
CREATE TABLE IF NOT EXISTS `Offline_Chat_Interaction_History` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) DEFAULT NULL,
  `NRIC` varchar(10) DEFAULT NULL,
  `CIF` varchar(20) DEFAULT NULL,
  `ChatID` varchar(30) DEFAULT NULL,
  `SenderID` varchar(20) DEFAULT NULL,
  `ReceiverID` varchar(20) DEFAULT NULL,
  `InteractionData` varchar(2000) DEFAULT NULL,
  `InteractionType` varchar(10) DEFAULT NULL,
  `InteractionDateTime` varchar(25) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `GroupID` varchar(30) DEFAULT NULL,
  `CustomData` varchar(200) DEFAULT NULL,
  `CustomDataType` varchar(10) DEFAULT NULL,
  `InteractionID` varchar(60) DEFAULT NULL,
  `RecieverType` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_Customer_Details
CREATE TABLE IF NOT EXISTS `Offline_Customer_Details` (
  `CustomerID` varchar(20) NOT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerDetails` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_Group_Details
CREATE TABLE IF NOT EXISTS `Offline_Group_Details` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GroupID` varchar(40) NOT NULL,
  `GroupName` varchar(25) DEFAULT NULL,
  `CustomerList` varchar(500) DEFAULT NULL,
  `AgentList` varchar(500) DEFAULT NULL,
  `CreationDateTime` varchar(30) DEFAULT NULL,
  `CreatedBy` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`GroupID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_Group_UserInfo
CREATE TABLE IF NOT EXISTS `Offline_Group_UserInfo` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserId` varchar(50) DEFAULT NULL,
  `GroupId` varchar(50) DEFAULT NULL,
  `LastDeliveredId` varchar(30) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_Messages
CREATE TABLE IF NOT EXISTS `Offline_Messages` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(30) DEFAULT NULL,
  `MsgContent` varchar(2000) DEFAULT NULL,
  `Type` varchar(30) DEFAULT NULL,
  `From` varchar(30) NOT NULL,
  `To` varchar(30) NOT NULL,
  `DateTime` varchar(25) DEFAULT NULL,
  `ChatID` varchar(50) DEFAULT NULL,
  `InteractionID` varchar(60) DEFAULT NULL,
  `RecieverType` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Offline_User_Details
CREATE TABLE IF NOT EXISTS `Offline_User_Details` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserID` varchar(30) DEFAULT NULL,
  `UserName` varchar(30) DEFAULT NULL,
  `UserDetails` varchar(500) DEFAULT NULL,
  `UserType` varchar(10) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OrderTakeConfiguration
CREATE TABLE IF NOT EXISTS `OrderTakeConfiguration` (
  `Intent` varchar(50) DEFAULT NULL,
  `FlowName` varchar(50) DEFAULT NULL,
  `CreatedDate` varchar(50) DEFAULT NULL,
  `CreatedTime` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.OutboundPurgedData
CREATE TABLE IF NOT EXISTS `OutboundPurgedData` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Mode` varchar(20) DEFAULT NULL,
  `ContactList` varchar(50) DEFAULT NULL,
  `CampaignID` varchar(50) DEFAULT NULL,
  `BeforePurging` int DEFAULT NULL,
  `AfterPurging` int DEFAULT NULL,
  `BusinessParameter` int DEFAULT NULL,
  `CreatedDateTime` datetime(3) DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_N_OutboundPurgedData_ReportDateTime` (`CreatedDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Outbound_CampaignMapping
CREATE TABLE IF NOT EXISTS `Outbound_CampaignMapping` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CampaignName` varchar(50) DEFAULT NULL,
  `TeamName` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(20) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_ASSIGN_EMAIL_ITEM
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_ASSIGN_EMAIL_ITEM`(
p_ASSIGNED_DATE VARCHAR(8),
p_ASSIGNED_TIME VARCHAR(6),
p_ASSIGNED_TO VARCHAR(20),
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE EMAIL_INBOX 
 SET ASSIGNEDDATE=p_ASSIGNED_DATE,ASSIGNEDTIME=p_ASSIGNED_TIME,ASSIGNEDTO=p_ASSIGNED_TO
 WHERE SESSIONID=p_SESSION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_DELETE_EMAIL_ITEM
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_DELETE_EMAIL_ITEM`(
p_DELETED_ON VARCHAR(20),
p_DELETED_BY VARCHAR(10),
p_DELETED INT,
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE Email_Inbox 
 SET DeletedOn = p_DELETED_ON, DeletedBy= p_DELETED_BY, Deleted= p_DELETED
 WHERE SessionID = p_SESSION_ID;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_FIND_EMAIL_INBOX_BY_CONVERSATIONID
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_FIND_EMAIL_INBOX_BY_CONVERSATIONID`(
p_CONVERSATION_ID VARCHAR(1000)
)
BEGIN
	SELECT CONVERSATIONID FROM  EMAIL_INBOX WHERE CONVERSATIONID=p_CONVERSATION_ID;	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_FIND_EMAIL_INBOX_BY_SESSIONID
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_FIND_EMAIL_INBOX_BY_SESSIONID`(
p_SESSIONID VARCHAR(250)
)
BEGIN
	SELECT SESSIONID FROM  Email_Inbox WHERE SESSIONID = p_SESSIONID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_FIND_EMAIL_OUTBOX_BY_CONVERSATIONID
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_FIND_EMAIL_OUTBOX_BY_CONVERSATIONID`(
p_CONVERSATION_ID VARCHAR(250)
)
BEGIN
	SELECT CONVERSATIONID FROM  EMAIL_OUTBOX WHERE CONVERSATIONID = p_CONVERSATION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_FIND_EMAIL_OUTBOX_BY_SESSIONID
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_FIND_EMAIL_OUTBOX_BY_SESSIONID`(
p_SESSION_ID VARCHAR(250)
)
BEGIN
	SELECT SessionID FROM  EMAIL_OUTBOX WHERE SessionID = p_SESSION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_FIND_USER_BY_EMAILID
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_FIND_USER_BY_EMAILID`(
p_emailid varchar(100))
begin
	select * from OUTLOOK_USER where Emailid=p_emailid;

end//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_INSERT_EMAIL_OUTBOX
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_INSERT_EMAIL_OUTBOX`(
p_BODY LONGTEXT,
p_SESSION_ID VARCHAR(250),
p_FROM VARCHAR(250),
p_TO_LIST LONGTEXT,
p_CC_LIST LONGTEXT,
p_BCC_LIST LONGTEXT,
p_SUBJECT NVARCHAR(500),
p_IS_HTML INT,
p_SEND_DATE VARCHAR(8),
p_SEND_TIME VARCHAR(6),
p_SEND_STATUS VARCHAR(10),
p_CREATED_DATE VARCHAR(8),
p_CREATED_TIME VARCHAR(6),
p_CREATED_BY VARCHAR(50),
p_CONVERSATION_ID VARCHAR(1000),
p_MAIL_BOX VARCHAR(50),
p_HAS_ATTACHMENTS INT,
p_CM_SKILL VARCHAR(50)
)
BEGIN

INSERT INTO Email_Outbox 
                (Body,
                SessionID,
                `From`,
                ToList,
                CCList,
                BCCList,
                Subject,                
                IsHtml,
                SendDate,
                SendTime,
                SendStatus,
                CreatedDate,
                CreatedTime,
                CreatedBy,
                ConversationID,
                Mailbox,
                HasAttachments,
                CMSkill) 
      VALUES(p_BODY,
			 p_SESSION_ID,
			 p_FROM,
			 p_TO_LIST,
			 p_CC_LIST,
			 p_BCC_LIST,
			 p_SUBJECT,
			 p_IS_HTML,
			 p_SEND_DATE,
			 p_SEND_TIME,
			 p_SEND_STATUS,
			 p_CREATED_DATE,
			 p_CREATED_TIME,
			 p_CREATED_BY,
			 p_CONVERSATION_ID,
			 p_MAIL_BOX,
			 p_HAS_ATTACHMENTS,
			 p_CM_SKILL);

END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_LAST_EMAIL_DELETED_DATETIME
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_LAST_EMAIL_DELETED_DATETIME`(
p_MAIL_BOX VARCHAR(50)
)
BEGIN
 SELECT DELETEDON AS DELETEDON 
 FROM  EMAIL_INBOX 
 WHERE MAILBOX=p_MAIL_BOX 
 ORDER BY (DELETEDON) DESC LIMIT 1;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_MARKTOCLOSE_EMAIL_ITEM
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_MARKTOCLOSE_EMAIL_ITEM`(
p_CLOSED_DATE VARCHAR(8),
p_CLOSED_TIME VARCHAR(6),
p_CLOSED_BY VARCHAR(20),
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE Email_Inbox 
 SET ClosedDate = p_CLOSED_DATE, ClosedTime=p_CLOSED_TIME ,ClosedBy = p_CLOSED_BY
 WHERE SessionID = p_SESSION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_REPLY_EMAIL_ITEM
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_REPLY_EMAIL_ITEM`(
p_REPLIED_DATE VARCHAR(8),
p_REPLIED_TIME VARCHAR(6),
p_REPLIED_BY VARCHAR(20),
p_REPLIED_STATUS INT,
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE Email_Inbox 
 SET RepliedDate = p_REPLIED_DATE, RepliedTime=p_REPLIED_TIME ,RepliedBy=p_REPLIED_BY, RepliedStatus = p_REPLIED_STATUS
 WHERE SessionID = p_SESSION_ID; 
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_UNMARKTOCLOSE_EMAIL_ITEM
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_UNMARKTOCLOSE_EMAIL_ITEM`(
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE Email_Inbox 
 SET ClosedDate = '', ClosedTime='' ,ClosedBy = ''
 WHERE SessionID = p_SESSION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_UPDATE_EMAIL_INBOX_ACTIVEHOLD_TIME
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_UPDATE_EMAIL_INBOX_ACTIVEHOLD_TIME`(
p_ACTIVE_TIME BIGINT,
p_SESSION_ID VARCHAR(250)
)
BEGIN
 UPDATE Email_Inbox 
 SET ACTIVETIME= IFNULL(ActiveTime,0)+p_ACTIVE_TIME
 WHERE SessionID = p_SESSION_ID;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_USER_FIND_ALL
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_USER_FIND_ALL`()
begin
	select * from OUTLOOK_USERS;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_USER_INSERT_UPDATE
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_USER_INSERT_UPDATE`(
	p_emailid varchar(100),
	p_LanName varchar(500),
	p_LastLogedInDateTime varchar(500),
	p_OutlookVersion varchar(500),	
	p_IsOnline tinyint,
	p_LastLogedOutDateTime datetime(3),
	p_OutlookPluginVersion varchar(500),
	p_ServiceStatusDateTime datetime(3),
	p_ServiceStatus tinyint	
)
begin
	if exists(select emailid from OUTLOOK_USERS where emailid=p_emailid)
		then
			UPDATE OUTLOOK_USERS set 
				LanName=p_LanName,
				LastLogedInDateTime=p_LastLogedInDateTime,
				OutlookVersion=p_OutlookVersion,
				IsOnline=p_IsOnline,
				LastLogedOutDateTime=p_LastLogedOutDateTime,
				OutlookPluginVersion=p_OutlookPluginVersion,
				ServiceStatusDateTime=p_ServiceStatusDateTime,
				ServiceStatus=p_ServiceStatus
			where
				p_emailid=p_emailid;
				
			SELECT '1' AS RESULT;
	else
			INSERT INTO OUTLOOK_USERS(
			Emailid,
			LanName,
			LastLogedInDateTime,
			OutlookVersion,
			IsOnline,
			LastLogedOutDateTime,
			OutlookPluginVersion,
			ServiceStatusDateTime,
			ServiceStatus)values(
			p_emailid,
			p_LanName,
			p_LastLogedInDateTime,
			p_OutlookVersion,
			p_IsOnline,
			p_LastLogedOutDateTime,
			p_OutlookPluginVersion,
			p_ServiceStatusDateTime,
			p_ServiceStatus);
			SELECT '1' AS RESULT;
		end if;

	
end//
DELIMITER ;

-- Dumping structure for procedure OCM.OUTLOOK_PLUGIN_USER_UPDATE_SERVICE_STATUS_INFO
DELIMITER //
CREATE PROCEDURE `OUTLOOK_PLUGIN_USER_UPDATE_SERVICE_STATUS_INFO`(
	p_ServiceStatusDateTime datetime(3),
	p_ServiceStatus tinyint	,
	p_emailid varchar(100)
)
begin
	UPDATE OUTLOOK_USER set 
				ServiceStatusDateTime=p_ServiceStatusDateTime,
				ServiceStatus=p_ServiceStatus
			where
				p_emailid=p_emailid;
end//
DELIMITER ;

-- Dumping structure for table OCM.OUTLOOK_USERS
CREATE TABLE IF NOT EXISTS `OUTLOOK_USERS` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `LanName` varchar(500) DEFAULT NULL,
  `LastLogedInDateTime` datetime(3) DEFAULT NULL,
  `OutlookVersion` varchar(500) DEFAULT NULL,
  `IsOnline` bit(1) DEFAULT NULL,
  `LastLogedOutDateTime` datetime(3) DEFAULT NULL,
  `OutlookPluginVersion` varchar(500) DEFAULT NULL,
  `ServiceStatusDateTime` datetime(3) DEFAULT NULL,
  `ServiceStatus` bit(1) DEFAULT NULL,
  `sysDateTime` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `Emailid` varchar(100) DEFAULT NULL,
  `isActive` bit(1) DEFAULT b'1',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Persons
CREATE TABLE IF NOT EXISTS `Persons` (
  `NotificationId` int NOT NULL,
  `NotificationReferenceNumber` varchar(100) NOT NULL,
  `NotificationType` int NOT NULL,
  `NotificationHandler` varchar(100) NOT NULL,
  `StartDate` datetime NOT NULL,
  `Time` varchar(50) NOT NULL,
  `IsRecurrence` bit(1) NOT NULL,
  `RecurrenceType` varchar(100) DEFAULT NULL,
  `RecurrenceEvery` int DEFAULT NULL,
  `RecurrenceMonth` varchar(100) DEFAULT NULL,
  `RecurrenceWeekDays` varchar(100) DEFAULT NULL,
  `RecurrenceDate` varchar(100) DEFAULT NULL,
  `RecurrenceRangeType` varchar(100) DEFAULT NULL,
  `RecurrenceRangeValue` datetime DEFAULT NULL,
  `Reminders` varchar(100) DEFAULT NULL,
  `NotificationData` varchar(100) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `NotificationVersion` int NOT NULL,
  `AppId` varchar(50) NOT NULL,
  `AppReferenceId` varchar(100) NOT NULL,
  `AppReferenceType` varchar(100) NOT NULL,
  `IsDeleted` bit(1) NOT NULL,
  `CreatedBy` varchar(100) NOT NULL,
  `CreatedOn` datetime NOT NULL,
  `ModifiedBy` varchar(100) DEFAULT NULL,
  `ModifiedOn` datetime DEFAULT NULL,
  `IsRedisAllowedToStoreEntireData` bit(1) NOT NULL,
  `IsEncodeDecodeRequired` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.QueueDetail
CREATE TABLE IF NOT EXISTS `QueueDetail` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `BRANCHCODE` varchar(4000) DEFAULT NULL,
  `SERVICECODE` varchar(4000) DEFAULT NULL,
  `QUEUE_NO` varchar(50) DEFAULT NULL,
  `CXIMAGE` longtext,
  `USERID` varchar(50) DEFAULT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(500) DEFAULT NULL,
  `MOBILE` varchar(50) DEFAULT NULL,
  `NOTIFY` varchar(1) DEFAULT NULL,
  `LAST_UPDATED` datetime(3) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `ACTION` varchar(500) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.QUOTENAME
DELIMITER //
CREATE FUNCTION `QUOTENAME`(strInput varchar(100)) RETURNS varchar(102) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
  DECLARE retval varchar(102); 
  DECLARE delimiterChar char(1);
  set delimiterChar='`';
  set retval = CONCAT(delimiterChar, REPLACE(strInput, delimiterChar, CONCAT(delimiterChar,delimiterChar)), delimiterChar);
  return (retval);
END//
DELIMITER ;

-- Dumping structure for table OCM.RequestQueue
CREATE TABLE IF NOT EXISTS `RequestQueue` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `QueueNumber` varchar(20) DEFAULT NULL,
  `BranchCode` varchar(50) DEFAULT NULL,
  `ServiceCode` varchar(50) DEFAULT NULL,
  `NRIC` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `SendNotification` int DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `RequestDate` varchar(8) DEFAULT NULL,
  `RequestTime` varchar(6) DEFAULT NULL,
  `DialDate` varchar(8) DEFAULT NULL,
  `DialTime` varchar(6) DEFAULT NULL,
  `AssignDate` varchar(8) DEFAULT NULL,
  `AssignTime` varchar(6) DEFAULT NULL,
  `ProcessedDate` varchar(8) DEFAULT NULL,
  `ProcessedTime` varchar(6) DEFAULT NULL,
  `AssignedTo` varchar(50) DEFAULT NULL,
  `Comment` varchar(500) DEFAULT NULL,
  `ServiceType` varchar(50) DEFAULT NULL,
  `Name` varchar(150) DEFAULT NULL,
  `BranchName` varchar(150) DEFAULT NULL,
  `ServiceName` varchar(250) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.RM_user_group_id
CREATE TABLE IF NOT EXISTS `RM_user_group_id` (
  `userid` longtext,
  `groupid` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.SECONDSTOXDayshhmmss
DELIMITER //
CREATE FUNCTION `SECONDSTOXDayshhmmss`(
	p_seconds BIGINT
) RETURNS varchar(20) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	
	IF(p_seconds = NULL)
	THEN
		RETURN '0 Days 00:00:00';
	END IF;
	 
	RETURN concat(
    format(floor(p_seconds / (3600 * 24)),0),
    ' Days ',
    time_format(sec_to_time(p_seconds % (3600 * 24)),'%H:%i:%s') 
  );
			
END//
DELIMITER ;

-- Dumping structure for table OCM.ServiceDetails
CREATE TABLE IF NOT EXISTS `ServiceDetails` (
  `BranchCode` varchar(50) DEFAULT NULL,
  `ServiceCode` varchar(50) DEFAULT NULL,
  `ServiceName` varchar(150) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.ServiceRegistry
CREATE TABLE IF NOT EXISTS `ServiceRegistry` (
  `serviceuniqueid` varchar(100) NOT NULL,
  `servicetype` varchar(100) DEFAULT NULL,
  `datajson` text,
  `tenant` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastupdatedby` varchar(50) DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`serviceuniqueid`,`tenant`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.sgx_SP_VDNMonitor_Update
DELIMITER //
CREATE PROCEDURE `sgx_SP_VDNMonitor_Update`(
p_OldCallID varchar(50), 
p_NewCallID varchar(50),
p_connectionHandle varchar(50))
BEGIN

DECLARE v_NewUCID VARCHAR(50);

select newucid into v_NewUCID  from sgx_vdn_temp where newcallid = p_NewCallID;

delete from sgx_vdn_temp where newcallid = p_NewCallID;
delete from sgx_VDN_temp where date < convert(now(3),date);
END//
DELIMITER ;

-- Dumping structure for function OCM.SLACalculation
DELIMITER //
CREATE FUNCTION `SLACalculation`(
	`v_SL` varchar(10),
	`v_sla` double
) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN

	Declare v_slaTS int;  
	Declare v_diff INT;
	
	SET v_SL= case when v_SL ='' then 0 ELSE v_SL END;
	set v_slaTS = CAST(ifnull(v_SL,0) AS UNSIGNED) * 60;

	set v_diff = (v_sla - v_slaTS);
	if (v_sla > v_slaTS)
	then
		return CONCAT('SLA is exceeded by ' , FLOOR(convert( v_diff / 60, char)) , ' hours and ' , FLOOR(convert( v_diff % 60, char)) , ' mins');
	else
		return 'Request is within SLA';
	end if;
END//
DELIMITER ;

-- Dumping structure for table OCM.smshistory
CREATE TABLE IF NOT EXISTS `smshistory` (
  `id` varchar(50) NOT NULL,
  `outgoingnumber` varchar(50) NOT NULL,
  `sessionid` varchar(100) NOT NULL,
  `agentid` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `sendtimestamp` datetime NOT NULL,
  `responsetimestamp` datetime DEFAULT NULL,
  `smsaccount` varchar(50) DEFAULT NULL,
  `apiurl` varchar(200) DEFAULT NULL,
  `apiresponse` varchar(5000) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `sourceid` varchar(100) DEFAULT NULL,
  `templateid` int DEFAULT NULL,
  `orgunit` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SMSReport
CREATE TABLE IF NOT EXISTS `SMSReport` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UCID` varchar(50) DEFAULT NULL,
  `CallerID` varchar(50) DEFAULT NULL,
  `Entered_CIN` varchar(50) DEFAULT NULL,
  `RegMob_CIN` varchar(50) DEFAULT NULL,
  `SMS_SentStatus` varchar(20) DEFAULT NULL,
  `SMS_SentDateTime` varchar(20) DEFAULT NULL,
  `SMS_MobileNo` varchar(20) DEFAULT NULL,
  `OCM_TemplateID` int DEFAULT NULL,
  `SMS_MarketingPromptPoint` varchar(50) DEFAULT NULL,
  `SMS_TriggeredPoint` varchar(20) DEFAULT NULL,
  `TerminatedorContinued` varchar(10) DEFAULT NULL,
  `ICOM_TemplateID` varchar(50) DEFAULT NULL,
  `SMSOfferedDateTime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SMSReport_CallerID` (`CallerID`),
  KEY `IX_SMSReport_Status` (`SMS_SentStatus`),
  KEY `IX_SMSReport_UCID` (`UCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SMS_Survey
CREATE TABLE IF NOT EXISTS `SMS_Survey` (
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `MobileNumber` varchar(20) DEFAULT NULL,
  `UCID` varchar(50) DEFAULT NULL,
  `DNIS` varchar(20) DEFAULT NULL,
  `ANI` varchar(20) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `AgentLanID` varchar(20) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `AgentName` varchar(100) DEFAULT NULL,
  `Action` varchar(20) DEFAULT NULL,
  `StopReason` varchar(250) DEFAULT NULL,
  `TemplateID` int DEFAULT NULL,
  `StopSurvey` int DEFAULT NULL,
  `SurveyMessage` varchar(250) DEFAULT NULL,
  `SaveDate` varchar(8) DEFAULT NULL,
  `SaveTime` varchar(6) DEFAULT NULL,
  `SentDate` varchar(8) DEFAULT NULL,
  `SentTime` varchar(6) DEFAULT NULL,
  `SendStatus` int DEFAULT NULL,
  `ResponseDate` varchar(8) DEFAULT NULL,
  `ResponseTime` varchar(6) DEFAULT NULL,
  `ResponseMessage` varchar(200) DEFAULT NULL,
  `ResponseStatus` int DEFAULT NULL,
  KEY `SRNO` (`SRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SMS_Survey_Config
CREATE TABLE IF NOT EXISTS `SMS_Survey_Config` (
  `SurveyEnabled` int DEFAULT NULL,
  `NoOfDaysForNextSMS` int DEFAULT NULL,
  `AutoTemplateID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SMS_Survey_DoNotCall_List
CREATE TABLE IF NOT EXISTS `SMS_Survey_DoNotCall_List` (
  `CLID` varchar(20) DEFAULT NULL,
  `Reason` varchar(250) DEFAULT NULL,
  `ChangedBy` varchar(100) DEFAULT NULL,
  `ChangedDate` datetime(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SMS_Template
CREATE TABLE IF NOT EXISTS `SMS_Template` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Text` varchar(500) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `Enable` bit(1) DEFAULT b'0',
  `ICOMTemplateID` varchar(20) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  `Source` varchar(8) DEFAULT NULL,
  `AlertCode` varchar(4000) DEFAULT NULL,
  `AppID` varchar(50) DEFAULT NULL,
  `MessageDescription` varchar(250) DEFAULT NULL,
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_SMS_Template_ICOMTemplateID` (`ICOMTemplateID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.SOI_IntentMapping
CREATE TABLE IF NOT EXISTS `SOI_IntentMapping` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Segment` varchar(50) DEFAULT NULL,
  `SubSegment` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `Language` varchar(20) DEFAULT NULL,
  `RequestType` varchar(20) DEFAULT NULL,
  `ChatVDN` varchar(20) DEFAULT NULL,
  `CBAVDN` varchar(20) DEFAULT NULL,
  `InsertDate` varchar(8) DEFAULT NULL,
  `InsertTime` varchar(6) DEFAULT NULL,
  `CustEntType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.sprocCountDialogStateTag
DELIMITER //
CREATE PROCEDURE `sprocCountDialogStateTag`(
   p_DNIS varchar(100) ,
   p_NAME varchar(100) ,
   p_REPORTTYPE varchar(100) ,
   p_STARTDATE varchar(100),
   p_ENDDATE varchar(100)
)
BEGIN	
	--  SQLINES DEMO ***  store result data
	DROP TEMPORARY TABLE IF EXISTS RAW;
	CREATE TEMPORARY TABLE RAW (MENU_NAME longtext,Access_Count INT);
	IF(p_REPORTTYPE = 'SingleDate')
	THEN		
		INSERT RAW
		SELECT MAX(IVR_MENU_DESC.IMD_MENU_NAME) AS MENU_NAME, COUNT(IVR_MENU_DESC.IMD_MENU_ID) AS Access_Count 
		FROM  IVR_USAGE INNER JOIN IVR_MENU_DESC 
		ON IVR_MENU_DESC.IMD_MENU_ID = IVR_USAGE.IU_ID 
		WHERE  (IVR_USAGE.ICH_CALLREFID IN
		(SELECT ICH_CALLREFID FROM IVR_CALL_HISTORY WHERE (IVR_CALL_HISTORY.ICH_START_DATE = p_STARTDATE) AND ICH_DNIS = p_DNIS) and 
		IVR_MENU_DESC.IMD_MENU_ID = p_NAME)
		GROUP BY IVR_MENU_DESC.IMD_MENU_ID;
	ELSE
		INSERT RAW
		SELECT MAX(IVR_MENU_DESC.IMD_MENU_NAME) AS MENU_NAME, COUNT(IVR_MENU_DESC.IMD_MENU_ID) AS Access_Count 
		FROM   IVR_USAGE INNER JOIN IVR_MENU_DESC 
		ON IVR_MENU_DESC.IMD_MENU_ID = IVR_USAGE.IU_ID 
		WHERE (IVR_USAGE.ICH_CALLREFID IN
		(SELECT ICH_CALLREFID FROM IVR_CALL_HISTORY WHERE ( IVR_CALL_HISTORY.ICH_START_DATE >= p_STARTDATE and IVR_CALL_HISTORY.ICH_END_DATE <= p_ENDDATE) AND ICH_DNIS = p_DNIS) and 
		IVR_MENU_DESC.IMD_MENU_ID = p_NAME)
		GROUP BY IVR_MENU_DESC.IMD_MENU_ID;
	END IF;	
	-- display the output
	select * from RAW;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.sprocGenerateDNISWorkFlow
DELIMITER //
CREATE PROCEDURE `sprocGenerateDNISWorkFlow`(
p_DNIS nvarchar(100)
)
BEGIN

DECLARE v_flag varchar(100);
DECLARE v_flag2 varchar(100);
DECLARE v_identifyFlag2 varchar(100);
DECLARE v_hitcount int;
DECLARE v_dnisParentID longtext;
DECLARE v_transParentID longtext;
DECLARE v_dialogParentID longtext;
DECLARE v_dtmfParentID longtext;
DECLARE v_dialogState longtext;
DECLARE v_dtmfgrammarset longtext;
DECLARE v_semanticValue varchar(100);
DECLARE v_destinationaction varchar(100);
DECLARE v_destinationnode varchar(100);
DECLARE v_ModuleDestination varchar(100);
declare v_ParentModule  varchar(100);
DECLARE v_semanticValueCount longtext;
DECLARE v_destinationnodevalidation longtext;
DECLARE v_intent varchar(1000);
DECLARE v_identityintent varchar(1000);
DECLARE v_ModelParentID varchar(1000);

DECLARE v_semanticValueCountIdentity longtext;
DECLARE v_semanticValueIdentity varchar(100);
DECLARE v_identitytransParentID longtext;
DECLARE v_identitydialogParentID longtext;
DECLARE v_identitydtmfParentID LONGTEXT;

declare v_ModuleName longtext;
DECLARE v_test1 INT;	
DECLARE v_tempStageValue varchar(1000);					
DECLARE v_test2 INT;
DECLARE v_test3 INT;
DECLARE v_test5 INT;
declare v_destActionnew varchar(50);	
DECLARE v_tempStageValue2 varchar(1000);
DECLARE v_test6 INT;
DECLARE v_test7 INT;
DECLARE v_test8 INT;
DECLARE v_PARENTID VARCHAR(100);
DECLARE v_identifyFlag varchar(1000);	
DECLARE v_test10 INT;
DECLARE v_tempStageValue10 varchar(1000);										
DECLARE v_test11 INT;
DECLARE v_test12 INT;
DECLARE v_test13 INT;
declare v_destActionnew1 varchar(50);
DECLARE v_tempStageValue3 varchar(1000);	
DECLARE v_test14 INT;
DECLARE v_test15 INT;

DROP TEMPORARY TABLE IF EXISTS DNIS_CONTEXT;
CREATE TEMPORARY TABLE DNIS_CONTEXT (ID int AUTO_INCREMENT, DNIS longtext,HOTLINE_SEGMENT longtext,GREETING_WAVEFILE longtext,VOICE_TALENT_URL longtext,ENTITY longtext,DIALOG_STATE_TAG LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS TRANSITION_MAP;
CREATE TEMPORARY TABLE TRANSITION_MAP (ID int AUTO_INCREMENT,CHANNEL longtext,INPUT_TAG longtext,CONFIDENCE_THRESHOLD longtext,DESTINATION_ACTION longtext,DESTINATION_NODE longtext,DIALOG_STATE longtext,PRODUCT longtext,INTENT longtext,INTENT_INDEX INT,LAST_CHANGED_BY longtext,LAST_CHANGED_ON LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS DIALOG_STATE_MAP;
CREATE TEMPORARY TABLE DIALOG_STATE_MAP (ID int AUTO_INCREMENT,DIALOG_STATE_TAG longtext,ERROR_LIMIT_DTMF INT,ERROR_LIMIT_SPEECH INT,SPEECH_GRAMMAR_NAME longtext,DTMF_GRAMMAR_SET longtext,INITIAL_PROMPT longtext,FAIL1_PROMPT longtext,FAIL2_PROMPT longtext,TIMEOUT1_PROMPT longtext,TIMEOUT2_PROMPT LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS DTMF_MAP;
CREATE TEMPORARY TABLE DTMF_MAP (ID int AUTO_INCREMENT,DTMF_GRAMMAR_SET longtext,OPTIONS longtext,SEMANTIC_TAG LONGTEXT);

DROP TEMPORARY TABLE IF EXISTS GRAPHTREE;
CREATE TEMPORARY TABLE GRAPHTREE (LEVEL INT, ID varchar(1000),NAMEID longtext,NAME varchar(1000),GRAMMARSET varchar(1000),DESTINATIONACTION varchar(1000),DESTINATIONNODE varchar(1000),Intent varchar(1000),InputTag varchar(1000),PARENT varchar(1000),IWTYPE varchar(100),HITCOUNT INT,PARENTID longtext,Options LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS GRAPHTREETEMP;
CREATE TEMPORARY TABLE GRAPHTREETEMP (LEVEL INT,ID varchar(1000), NAMEID longtext,NAME varchar(1000),PARENT varchar(1000),IWTYPE varchar(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS GRAPHTREETEMPIDENTITY;
CREATE TEMPORARY TABLE GRAPHTREETEMPIDENTITY (LEVEL INT,ID varchar(1000), NAMEID longtext,NAME varchar(1000),PARENT varchar(1000),IWTYPE varchar(100),HITCOUNT INT,PARENTID LONGTEXT);

DROP TEMPORARY TABLE IF EXISTS semanticTemp;
CREATE TEMPORARY TABLE semanticTemp (NO int AUTO_INCREMENT, NAME LONGTEXT,PARENT LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS semanticUpdate;
CREATE TEMPORARY TABLE semanticUpdate ( SemanticTag LONGTEXT,DestinationNode LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS semanticTempIdentity;
CREATE TEMPORARY TABLE semanticTempIdentity (NO int AUTO_INCREMENT, NAME LONGTEXT,PARENT LONGTEXT); 
DROP TEMPORARY TABLE IF EXISTS transStageTemp;
CREATE TEMPORARY TABLE transStageTemp (NO int AUTO_INCREMENT, NAME LONGTEXT,PARENT LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS dialogDtmfTemp;
CREATE TEMPORARY TABLE dialogDtmfTemp (NO int AUTO_INCREMENT, NAME LONGTEXT,PARENT LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS transDialogList;
CREATE TEMPORARY TABLE transDialogList (NO int AUTO_INCREMENT, NAME LONGTEXT,PARENT LONGTEXT,PARENTID LONGTEXT); 
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp1;
CREATE TEMPORARY TABLE graphTreeTemp1 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp2;
CREATE TEMPORARY TABLE graphTreeTemp2 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp3;
CREATE TEMPORARY TABLE graphTreeTemp3 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp4;
CREATE TEMPORARY TABLE graphTreeTemp4 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp5;
CREATE TEMPORARY TABLE graphTreeTemp5 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS ModuleNodeDetails;
CREATE TEMPORARY TABLE ModuleNodeDetails (ID LONGTEXT,SemanticTag VARCHAR(1000), destinationNode LONGTEXT,ExitNode LONGTEXT);

-- for identity

DROP TEMPORARY TABLE IF EXISTS graphTreeTemp6;
CREATE TEMPORARY TABLE graphTreeTemp6 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp7;
CREATE TEMPORARY TABLE graphTreeTemp7 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp8;
CREATE TEMPORARY TABLE graphTreeTemp8 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp9;
CREATE TEMPORARY TABLE graphTreeTemp9 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
DROP TEMPORARY TABLE IF EXISTS graphTreeTemp10;
CREATE TEMPORARY TABLE graphTreeTemp10 (LEVEL INT,ID VARCHAR(1000), NAMEID LONGTEXT,NAME VARCHAR(1000),PARENT VARCHAR(1000),IWTYPE VARCHAR(100),HITCOUNT INT,PARENTID LONGTEXT);
--  SQLINES DEMO *** to save hitcount values
DROP TEMPORARY TABLE IF EXISTS TransCount;
CREATE TEMPORARY TABLE  TransCount (NO int AUTO_INCREMENT, MENU_NAME LONGTEXT,MENU_COUNTS INT not NULL);
DROP TEMPORARY TABLE IF EXISTS DialogStateCount;
CREATE TEMPORARY TABLE  DialogStateCount (NO int AUTO_INCREMENT, MENU_NAME LONGTEXT,MENU_COUNTS INT not NULL);
DROP TEMPORARY TABLE IF EXISTS DTMFCount;
CREATE TEMPORARY TABLE  DTMFCount (NO int AUTO_INCREMENT, MENU_NAME LONGTEXT,MENU_COUNTS INT not NULL);

SET v_dtmfParentID = '0';
SET v_dtmfParentID = CONVERT(v_dtmfParentID, char);

INSERT DNIS_CONTEXT
SELECT * FROM IVR_IW_DNIS_Context;

INSERT TRANSITION_MAP
SELECT * FROM IVR_IW_Transition_Map;

INSERT DIALOG_STATE_MAP
SELECT * FROM IVR_IW_Dialog_State_Map;

INSERT DTMF_MAP
SELECT * FROM IVR_IW_DTMF_Map;

UPDATE DTMF_MAP GT
INNER JOIN TRANSITION_MAP t
on GT.SEMANTIC_TAG = t.INPUT_TAG and t.DESTINATION_ACTION='CallFlowContinue' 
SET SEMANTIC_TAG = t.DESTINATION_NODE;

BEGIN
	IF EXISTS(SELECT DNIS FROM DNIS_CONTEXT WHERE DNIS = p_DNIS)
	THEN
		SET v_flag = 'DNIS'; 
		
		WHILE(v_flag!='false')
			DO
				IF(v_flag='DNIS')
				THEN		
					INSERT GRAPHTREE
					SELECT DISTINCT 0 AS LEVEL,DIALOG_STATE_TAG AS ID,(convert('1', char)) AS NAMEID, DIALOG_STATE_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' as DESTINATIONNODE,'' as Intent, DIALOG_STATE_TAG AS InputTag, p_DNIS AS PARENT,'DNIS' AS IWTYPE, v_hitcount AS HITCOUNT,(convert('0', char)) AS PARENTID, '' as Options
					FROM DNIS_CONTEXT
					WHERE DNIS = p_DNIS;	
					
					SET v_dtmfParentID = (SELECT ID FROM DNIS_CONTEXT WHERE DNIS=p_DNIS);				
					SET v_dnisParentID = (convert('1', char));						
					SET v_dtmfParentID = v_dnisParentID;
					
					DELETE FROM semanticTemp;			
					INSERT semanticTemp  
					SELECT NAME,PARENT FROM GRAPHTREE WHERE IWTYPE='DNIS';					
					
					SET v_flag = 'TransitionMap';
					
				ELSEIF (v_flag='TransitionMap')
				THEN	
					set v_flag2 ='';	
					SET v_destinationaction = (SELECT DISTINCT DESTINATION_ACTION FROM TRANSITION_MAP  WHERE INPUT_TAG=v_semanticValue);
					IF (v_destinationaction = 'CallFlowContinue')
					THEN
						UPDATE GRAPHTREE set DESTINATIONACTION = Replace(v_destinationaction, ' ', '') where NAME = v_semanticValue;				
					END IF;	
					
						UPDATE semanticTemp GT
						INNER JOIN TRANSITION_MAP t
						on GT.NAME = t.INPUT_TAG and t.DESTINATION_ACTION='CallFlowContinue' 
						SET NAME = t.DESTINATION_NODE;
											
					SET v_semanticValue = (SELECT NAME FROM semanticTemp ORDER BY NO LIMIT 1);				
					
					IF(v_dtmfParentID<>v_dnisParentID OR v_dtmfParentID is null OR v_dtmfParentID='')
					THEN
						SET v_dtmfParentID=(SELECT PARENTID FROM graphTreeTemp5 WHERE IWTYPE='DTMF' AND NAME=v_semanticValue LIMIT 1);										
					END IF;	
					if(v_dtmfParentID is null OR v_dtmfParentID='')
					then 
					SET v_dtmfParentID=(select ID from ModuleNodeDetails where ExitNode=v_semanticValue LIMIT 1);
					
					set v_ModuleName=(select destinationNode from ModuleNodeDetails where ExitNode=v_semanticValue LIMIT 1);
					INSERT GRAPHTREE 
					SELECT DISTINCT 4 AS LEVEL,ExitNode AS ID,CONCAT(v_dtmfParentID,v_semanticValue) AS NAMEID, ExitNode AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' as DESTINATIONNODE,'' as Intent, ExitNode AS InputTag, v_dtmfParentID AS PARENT,'module' AS IWTYPE, v_hitcount AS HITCOUNT,v_dtmfParentID AS PARENTID, '' as Options
					from ModuleNodeDetails where ExitNode=v_semanticValue;
					SET v_dtmfParentID=CONCAT(v_dtmfParentID,v_semanticValue);
					end if;		
					
					SET v_semanticValueCount = (SELECT COUNT(1) FROM semanticTemp);
					set v_ParentModule=(select Parent from semanticTemp WHERE NAME=v_semanticValue LIMIT 1);
						
					DELETE  from semanticTemp WHERE NAME=v_semanticValue;	
									
					SET v_destinationaction = (SELECT DISTINCT DESTINATION_ACTION FROM TRANSITION_MAP  WHERE INPUT_TAG=v_semanticValue);	

					set v_ModuleDestination=(SELECT DISTINCT DESTINATION_NODE FROM TRANSITION_MAP  WHERE INPUT_TAG=v_semanticValue);	
	
					IF((v_destinationaction = 'Agent') or (v_destinationaction = 'Module')) 	
					THEN											
						SET v_flag = 'Agent';
						SET v_intent = (SELECT INTENT FROM IVR_IW_Transition_Map WHERE InputTag = v_semanticValue LIMIT 1);
						UPDATE GRAPHTREE set Intent = v_intent where NAME = v_semanticValue;								
					ELSE	
						IF((v_destinationaction = 'Agent') or (v_destinationaction = 'Module') or (v_destinationaction = 'NA')or (v_destinationaction is null or v_destinationaction = ''))
						THEN
							IF(v_semanticValueCount=0)
							THEN
								SET v_flag = 'false';
							ELSE
								SET v_flag = 'TransitionMap';
							END IF;	
						ELSE
							SET v_test1 = (SELECT  Count(1) FROM TRANSITION_MAP tm
							WHERE tm.INPUT_TAG = v_semanticValue);
							IF(v_test1>0)
							THEN
								SET v_hitcount = (select IFNULL(MENU_COUNTS,0) as MENU_COUNTS from TransCount LIMIT 1);
								
								DELETE FROM GRAPHTREETEMP;		
								INSERT GRAPHTREETEMP
								SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID, tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_dtmfParentID) AS PARENTID
								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValue;	

								UPDATE GRAPHTREE set DESTINATIONACTION = Replace(v_destinationaction, ' ', '') where NAME = v_semanticValue;	

								DELETE FROM graphTreeTemp1;
								INSERT graphTreeTemp1
								SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID,tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS PARENTID
								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValue;
								
								DELETE FROM transStageTemp;
								INSERT transStageTemp
								SELECT NAME,PARENT FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION';
								
								SET v_transParentID = (SELECT PARENTID FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION' LIMIT 1);
								
								SET v_intent = (SELECT INTENT FROM IVR_IW_Transition_Map WHERE InputTag = v_semanticValue LIMIT 1);
								
								SET v_dialogState = (SELECT NAME FROM transStageTemp LIMIT 1);
															
								SET v_flag = 'DialogStateMap';	
															
								SET v_tempStageValue=(Select DTMF_GRAMMAR_SET from DIALOG_STATE_MAP where DIALOG_STATE_TAG = v_dialogState LIMIT 1);
								
								IF EXISTS(SELECT NAME FROM transDialogList WHERE NAME=v_dialogState)
								THEN									
									SET v_flag = 'TransitionMap';
								END IF;
							ELSE
								SET v_flag = 'TransitionMap';
							END IF;																						
						END IF;
						END IF;
				
				ELSEIF (v_flag='DialogStateMap')
				THEN				
					SET v_test2 = (SELECT  Count(1) FROM DIALOG_STATE_MAP dsm
					INNER JOIN GRAPHTREETEMP gt
					ON gt.NAME = dsm.Dialog_State_Tag WHERE dsm.Dialog_State_Tag = v_dialogState);
					IF(v_test2>0)
					THEN	
						INSERT GRAPHTREETEMP 
						SELECT DISTINCT 2 AS LEVEL, dsm.DTMF_GRAMMAR_SET AS ID, (CONCAT(v_transParentID,'_',convert(dsm.ID, char))) AS NAMEID,dsm.DTMF_GRAMMAR_SET AS NAME, dsm.DIALOG_STATE_TAG AS PARENT ,'DIALOGSTATE' AS IWTYPE,v_hitcount AS HITCOUNT,(v_transParentID) AS PARENTID
						FROM DIALOG_STATE_MAP dsm 
						INNER JOIN GRAPHTREETEMP tm
						ON dsm.DIALOG_STATE_TAG = tm.NAME	
						WHERE dsm.Dialog_State_Tag = v_dialogState;	

						DELETE FROM graphTreeTemp4;
						INSERT graphTreeTemp4 
						SELECT DISTINCT 2 AS LEVEL, dsm.DTMF_GRAMMAR_SET AS ID, (CONCAT(v_transParentID,'_',convert(dsm.ID, char))) AS NAMEID,dsm.DTMF_GRAMMAR_SET AS NAME, dsm.DIALOG_STATE_TAG AS PARENT ,'DIALOGSTATE' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_transParentID,'_',convert(dsm.ID, char))) AS PARENTID
						FROM DIALOG_STATE_MAP dsm 
						INNER JOIN GRAPHTREETEMP tm
						ON dsm.DIALOG_STATE_TAG = tm.NAME	
						WHERE dsm.Dialog_State_Tag = v_dialogState;			
						
						SET v_dialogParentID = (SELECT PARENTID FROM graphTreeTemp4 WHERE IWTYPE='DIALOGSTATE' LIMIT 1);
						
						DELETE FROM dialogDtmfTemp;
						INSERT dialogDtmfTemp
						SELECT NAME,PARENT FROM graphTreeTemp4 WHERE IWTYPE='DIALOGSTATE';
					
						SET v_dtmfgrammarset=(SELECT NAME FROM dialogDtmfTemp LIMIT 1);
						
						INSERT transDialogList
						SELECT NAME,PARENT,PARENTID FROM GRAPHTREETEMP WHERE IWTYPE='TRANSITION';						
			
						SET v_flag = 'DTMFMap';
						
						IF(v_flag2='AgentM')
						THEN
							SET v_flag = 'DTMFMap2';
							SET v_flag2 = '';
						END IF;
					ELSE
						SET v_flag = 'TransitionMap';
					END IF;
				
				ELSEIF (v_flag='DTMFMap')
				THEN				
					SET v_test3 = (SELECT  Count(1) FROM  GRAPHTREETEMP dsm 
					INNER JOIN DTMF_MAP dtmf
					ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
					WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset);
					IF(v_test3>0)
					THEN			
				  		Drop temporary table if exists `tempTable`;
		  				Create temporary table `tempTable` (MenuName varchar(1000),Options varchar(1000),Counts INT);
				  		
						DELETE FROM `tempTable`;
						INSERT into `tempTable`(MenuName,Options,Counts)
						SELECT MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;						
					    
						INSERT GRAPHTREETEMP    
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_dialogParentID AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
						
						Drop temporary table if exists tempTable2;
						Create temporary table tempTable2 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);				
						
						DELETE FROM tempTable2;
						INSERT INTO tempTable2(MenuName,Options,Counts)
						SELECT dtmf.SEMANTIC_TAG as MenuName,t.Options,t.Counts from DTMF_MAP dtmf
						inner join `tempTable` t
						on t.Options = dtmf.OPTIONS
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset; 	
											
						UPDATE GRAPHTREETEMP GT
						INNER JOIN tempTable2 t
						on GT.ID = t.MenuName 
						SET HITCOUNT = t.Counts;						
						
						-- output table
						INSERT GRAPHTREE      
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS  GRAMMARSET,'0' AS DESTINATIONACTION,'' as DESTINATIONNODE,'' as Intent,dtmf.SEMANTIC_TAG AS InputTag, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(v_dtmfParentID) AS PARENTID,dtmf.OPTIONS as Options
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
						
						UPDATE GRAPHTREE GT
						INNER JOIN GRAPHTREETEMP t
						on GT.ID = t.ID 
						SET HITCOUNT = t.HITCOUNT;
						
						DELETE FROM graphTreeTemp2;
						INSERT graphTreeTemp2  
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
						
						INSERT graphTreeTemp5            
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (concat(convert(v_dialogParentID, char),'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;						

insert semanticUpdate 
select tm.INPUT_TAG,tm.DESTINATION_NODE FROM TRANSITION_MAP tm
WHERE tm.DESTINATION_ACTION = 'CallFlowContinue';

UPDATE semanticUpdate as semanticUpdate 
SET NAME = semanticUpdate.DestinationNode
WHERE
   NAME = semanticUpdate.SemanticTag and semanticUpdate.SemanticTag is not null;
						INSERT semanticTemp 
						SELECT NAME,PARENT FROM graphTreeTemp2 WHERE IWTYPE='DTMF'; 
											
						SET v_semanticValue = (SELECT NAME FROM semanticTemp ORDER BY NO LIMIT 1);

						SET v_dtmfParentID=(SELECT PARENTID FROM graphTreeTemp5 WHERE IWTYPE='DTMF' AND NAME=v_semanticValue LIMIT 1);
								
						SET v_semanticValueCount = (SELECT COUNT(1) FROM semanticTemp);		
						
						SET v_flag = 'TransitionMap';
					ELSE
						SET v_flag = 'TransitionMap';
					END IF;		
				
				ELSEIF (v_flag = 'Agent')
				THEN
					SET v_flag2 = 'AgentM';
					SET v_test5 = (SELECT  Count(1) FROM TRANSITION_MAP tm
					WHERE tm.INPUT_TAG = v_semanticValue);
					IF(v_test5>0)
					THEN
						DELETE FROM GRAPHTREETEMP;			
						INSERT GRAPHTREETEMP 
						SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID, tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_dtmfParentID) AS PARENTID
						FROM TRANSITION_MAP tm
						WHERE tm.INPUT_TAG = v_semanticValue;	
						SET v_destActionnew=(SELECT tm.DESTINATION_ACTION FROM TRANSITION_MAP tm	WHERE tm.INPUT_TAG = v_semanticValue);
					
						UPDATE GRAPHTREE set DESTINATIONACTION = Replace(v_destinationaction, ' ', '') where NAME = v_semanticValue;		
UPDATE GRAPHTREE set DESTINATIONNODE=v_ModuleDestination where NAME = v_semanticValue;
set v_ModelParentID= (select NAMEID from GRAPHTREE where NAME = v_semanticValue );

INSERT semanticTemp      
						SELECT EXIT_NODES,v_ParentModule  FROM IVR_IW_MODULE_EXITS_MAPPING
					WHERE MODULE_NAME = v_ModuleDestination;	
				
if(v_destinationaction='Module')
then
insert into ModuleNodeDetails
SELECT nameID,v_semanticValue,v_ModuleDestination,EXIT_NODES FROM IVR_IW_MODULE_EXITS_MAPPING inner join GRAPHTREE on NAME=v_semanticValue
					WHERE MODULE_NAME = v_ModuleDestination;	
end if;

						DELETE FROM graphTreeTemp1;
						INSERT graphTreeTemp1
						SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID,tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS PARENTID
						FROM TRANSITION_MAP tm
						WHERE tm.INPUT_TAG = v_semanticValue;
						
						DELETE FROM transStageTemp;
						INSERT transStageTemp
						SELECT NAME,PARENT FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION';
					
						SET v_transParentID = (SELECT PARENTID FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION' LIMIT 1);
						
						SET v_intent = (SELECT INTENT FROM IVR_IW_Transition_Map WHERE InputTag = v_semanticValue LIMIT 1);
						
						SET v_dialogState = (SELECT NAME FROM transStageTemp LIMIT 1);
						
						SET v_flag = 'TransitionMap';								
						SET v_tempStageValue2=(Select DTMF_GRAMMAR_SET from DIALOG_STATE_MAP where DIALOG_STATE_TAG = v_dialogState);
						
						IF(v_tempStageValue2=v_dialogState)
						THEN
							SET v_flag = 'JumpToDTMF';
						END IF;	
						IF EXISTS(SELECT NAME FROM transDialogList WHERE NAME=v_dialogState)
						THEN							
							SET v_flag = 'TransitionMap';
						END IF;
					ELSE
						SET v_flag = 'TransitionMap';
					END IF;	
				
				ELSEIF (v_flag = 'DTMFMap2')
				THEN
					SET v_test6 = (SELECT  Count(1) FROM  GRAPHTREETEMP dsm 
					INNER JOIN DTMF_MAP dtmf
					ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
					WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset);
					IF(v_test6>0)
					THEN										
				  		Drop temporary table if exists tempTable4;
		  				Create temporary table tempTable4 (MenuName varchar(1000),Options varchar(1000),Counts INT);
				  		
						delete from tempTable4;
						INSERT into tempTable4(MenuName,Options,Counts)
						select MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;

						INSERT GRAPHTREETEMP             
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_dialogParentID AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
						
						Drop temporary table if exists tempTable5;
						Create temporary table tempTable5 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);					

						delete from tempTable5;
						INSERT into tempTable5(MenuName,Options,Counts)
						select dtmf.SEMANTIC_TAG as MenuName,t.Options,t.Counts from DTMF_MAP dtmf
						inner join tempTable4 t
						on t.Options = dtmf.OPTIONS
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset; 	
						
						UPDATE GRAPHTREETEMP GT
						INNER JOIN tempTable2 t
						on GT.ID = t.MenuName 
						SET HITCOUNT = t.Counts;

						INSERT GRAPHTREE  
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_dialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' As DESTINATIONNODE,'' as Intent,dtmf.SEMANTIC_TAG AS InputTag, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(v_dialogParentID) AS PARENTID,dtmf.OPTIONS As Options
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
						
						UPDATE GRAPHTREE GT
						INNER JOIN GRAPHTREETEMP t
						on GT.ID = t.ID 
						SET HITCOUNT = t.HITCOUNT;
						
						SET v_flag = 'TransitionMap';
					ELSE
						SET v_flag = 'TransitionMap';
					END IF;	
				
				ELSEIF (v_flag = 'JumpToDTMF')
				THEN	
					SET v_test7 = (SELECT  Count(1) FROM  GRAPHTREETEMP dsm 
					INNER JOIN DTMF_MAP dtmf
					ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
					WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState);
					IF(v_test7>0)
					THEN					
				  		Drop temporary table if exists tempTable6;
		  				Create temporary table tempTable6 (MenuName varchar(1000),Options varchar(1000),Counts INT);
				  		
						INSERT into tempTable6(MenuName,Options,Counts)
						select MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;

						INSERT GRAPHTREETEMP             
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_transParentID AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
						
						DROP TEMPORARY TABLE IF EXISTS tempTable7;
						CREATE TEMPORARY TABLE tempTable7 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);					
						DELETE from tempTable7;
						INSERT into tempTable7(MenuName,Options,Counts)
						SELECT dtmf.SEMANTIC_TAG AS MenuName,t.Options,t.Counts FROM DTMF_MAP dtmf
						INNER JOIN tempTable6 t
						ON t.Options = dtmf.OPTIONS
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState; 	
												
						UPDATE GRAPHTREETEMP GT
						INNER JOIN tempTable7 t
						ON GT.ID = t.MenuName 
						SET HITCOUNT = t.Counts;

						INSERT GRAPHTREE       
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION ,'' AS DESTINATIONNODE,'' as Intent,dtmf.SEMANTIC_TAG AS InputTag,dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,v_transParentID AS PARENTID,dtmf.OPTIONS as Options
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState; 

						UPDATE GRAPHTREE GT
						INNER JOIN GRAPHTREETEMP t
						on GT.ID = t.ID 

						SET HITCOUNT = t.HITCOUNT;
						
						DELETE FROM graphTreeTemp2;
						INSERT graphTreeTemp2          
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
						
						INSERT graphTreeTemp5   
						SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_transParentID,'_',convert(dtmf.ID, char))) AS PARENTID
						FROM  GRAPHTREETEMP dsm 
						INNER JOIN DTMF_MAP dtmf
						ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
						WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
						
						INSERT semanticTemp          
						SELECT NAME,PARENT FROM graphTreeTemp2 WHERE IWTYPE='DTMF'; 
											
						SET v_semanticValue = (SELECT NAME FROM semanticTemp ORDER BY NO LIMIT 1);
						
						SET v_dtmfParentID=(SELECT PARENTID FROM graphTreeTemp5 WHERE IWTYPE='DTMF' AND NAME=v_semanticValue LIMIT 1);
						
						SET v_semanticValueCount = (SELECT COUNT(1) FROM semanticTemp);
										
						SET v_flag = 'TransitionMap';			
					ELSE
						SET v_flag = 'TransitionMap';
					END IF;	
				ELSEIF (v_flag = 'CFlowTransitionMap')
				THEN
					BEGIN
							SET v_test8 = (SELECT  Count(1) FROM TRANSITION_MAP tm
							WHERE tm.INPUT_TAG = v_semanticValue);
							IF(v_test8>0)
							THEN
								DELETE FROM GRAPHTREETEMP;			
								INSERT GRAPHTREETEMP
								SELECT DISTINCT 1 AS LEVEL, tm.DESTINATION_NODE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID, tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_dtmfParentID) AS PARENTID
								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValue;	

								DELETE FROM graphTreeTemp1;
								INSERT graphTreeTemp1
								SELECT DISTINCT 1 AS LEVEL, tm.DESTINATION_NODE AS ID,(CONCAT(v_dtmfParentID,'_',convert(tm.ID, char))) AS NAMEID,tm.DESTINATION_NODE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_dtmfParentID) AS PARENTID

								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValue;
								
								DELETE FROM transStageTemp;
								INSERT transStageTemp
								SELECT NAME,PARENT FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION';
							
								DELETE FROM semanticTempIdentity;			
								INSERT semanticTempIdentity           
								SELECT NAME,PARENTID FROM GRAPHTREE WHERE IWTYPE='TRANSITION';					

								SET v_PARENTID = (SELECT NAMEID FROM graphTreeTemp1 WHERE IWTYPE='TRANSITION' LIMIT 1);
								SET v_identitydtmfParentID = v_PARENTID;
								SET v_flag = 'CFlowTransitionMap2';
							ELSE
								SET v_flag = 'TransitionMap';
							END IF;																						
						END;
				
				ELSEIF (v_flag = 'CFlowTransitionMap2')
				THEN
					SET v_identifyFlag = 'IDFTNTransitionMap';	
					
					WHILE(v_identifyFlag!='STOP')
					DO
						IF(v_identifyFlag='IDFTNTransitionMap')
						THEN						
						SET v_semanticValueIdentity = (SELECT NAME FROM semanticTempIdentity ORDER BY NO LIMIT 1);
						
						IF(v_identitydtmfParentID<>v_PARENTID OR v_identitydtmfParentID is null OR v_identitydtmfParentID='')
						THEN
							SET v_identitydtmfParentID=(SELECT PARENTID FROM graphTreeTemp5 WHERE IWTYPE='DTMF' AND NAME=v_semanticValue LIMIT 1);										
						END IF;			
					
						SET v_semanticValueCountIdentity = (SELECT COUNT(1) FROM semanticTempIdentity);
															
						DELETE  from semanticTempIdentity WHERE NAME=v_semanticValueIdentity;	
										
						SET v_destinationaction = (SELECT DISTINCT DESTINATION_ACTION FROM TRANSITION_MAP  WHERE INPUT_TAG=v_semanticValueIdentity);
			
						IF((v_destinationaction = 'Agent') or (v_destinationaction = 'Module')) 	
						THEN											
							SET v_identifyFlag = 'IDFTNAgent';					
						ELSE
							IF((v_destinationaction = 'Agent') or (v_destinationaction = 'Module') or (v_destinationaction = 'NA')or (v_destinationaction is null or v_destinationaction = ''))
							THEN
								IF(v_semanticValueCountIdentity=0)
								THEN
									SET v_identifyFlag = 'STOP';
								ELSE
									SET v_identifyFlag = 'IDFTNTransitionMap';
								END IF;	
								ELSE
										SET v_test10 = (SELECT  Count(1) FROM TRANSITION_MAP tm
										WHERE tm.INPUT_TAG = v_semanticValueIdentity);
										IF(v_test10>0)
										THEN
											DELETE FROM GRAPHTREETEMPIDENTITY;			
											INSERT GRAPHTREETEMPIDENTITY
											SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS NAMEID, tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_identitydtmfParentID) AS PARENTID
											FROM TRANSITION_MAP tm
											WHERE tm.INPUT_TAG = v_semanticValueIdentity;
												
										   DELETE FROM graphTreeTemp8;
											INSERT graphTreeTemp8
											SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS NAMEID,tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS PARENTID
											FROM TRANSITION_MAP tm
											WHERE tm.INPUT_TAG = v_semanticValueIdentity;
											
											DELETE FROM transStageTemp;
											INSERT transStageTemp
											SELECT NAME,PARENT FROM graphTreeTemp8 WHERE IWTYPE='TRANSITION';
											
											SET v_identitytransParentID = (SELECT PARENTID FROM graphTreeTemp8 WHERE IWTYPE='TRANSITION' LIMIT 1);
											
											SET v_identityintent = (SELECT INTENT FROM IVR_IW_Transition_Map WHERE InputTag = v_semanticValueIdentity LIMIT 1);
											
											SET v_dialogState = (SELECT NAME FROM transStageTemp LIMIT 1);
																	
											SET v_identifyFlag = 'IDFTNDialogState';	
																	
											SET v_tempStageValue10=(Select DTMF_GRAMMAR_SET from DIALOG_STATE_MAP where DIALOG_STATE_TAG = v_dialogState LIMIT 1);
											
										ELSE
											SET v_identifyFlag = 'IDFTNTransitionMap';
										END IF;																						
									END IF;
								END IF;
							
							ELSEIF (v_identifyFlag='IDFTNDialogState')
							THEN		
								SET v_test11 = (SELECT  Count(1) FROM DIALOG_STATE_MAP dsm
								INNER JOIN GRAPHTREETEMPIDENTITY gt
								ON gt.NAME = dsm.Dialog_State_Tag WHERE dsm.Dialog_State_Tag = v_dialogState);
								IF(v_test11>0)
								THEN	
									INSERT GRAPHTREETEMPIDENTITY 
									SELECT DISTINCT 2 AS LEVEL, dsm.DTMF_GRAMMAR_SET AS ID, (CONCAT(v_identitytransParentID,'_',convert(dsm.ID, char))) AS NAMEID,dsm.DTMF_GRAMMAR_SET AS NAME, dsm.DIALOG_STATE_TAG AS PARENT ,'DIALOGSTATE' AS IWTYPE,v_hitcount AS HITCOUNT,(v_identitytransParentID) AS PARENTID
									FROM DIALOG_STATE_MAP dsm 
									INNER JOIN GRAPHTREETEMPIDENTITY tm
									ON dsm.DIALOG_STATE_TAG = tm.NAME	
									WHERE dsm.Dialog_State_Tag = v_dialogState;	

									DELETE FROM graphTreeTemp9;
									INSERT graphTreeTemp9 
									SELECT DISTINCT 2 AS LEVEL, dsm.DTMF_GRAMMAR_SET AS ID, (CONCAT(v_identitytransParentID,'_',convert(dsm.ID, char))) AS NAMEID,dsm.DTMF_GRAMMAR_SET AS NAME, dsm.DIALOG_STATE_TAG AS PARENT ,'DIALOGSTATE' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_identitytransParentID,'_',convert(dsm.ID, char))) AS PARENTID
									FROM DIALOG_STATE_MAP dsm 
									INNER JOIN GRAPHTREETEMPIDENTITY tm
									ON dsm.DIALOG_STATE_TAG = tm.NAME	
									WHERE dsm.Dialog_State_Tag = v_dialogState;			
									
									SET v_identitydialogParentID = (SELECT PARENTID FROM graphTreeTemp9 WHERE IWTYPE='DIALOGSTATE' LIMIT 1);
									
									DELETE FROM dialogDtmfTemp;
									INSERT dialogDtmfTemp
									SELECT NAME,PARENT FROM graphTreeTemp9 WHERE IWTYPE='DIALOGSTATE';
								
									SET v_dtmfgrammarset=(SELECT NAME FROM dialogDtmfTemp LIMIT 1);
									
									INSERT transDialogList
									SELECT NAME,PARENT,PARENTID FROM GRAPHTREETEMPIDENTITY WHERE IWTYPE='TRANSITION';						
								
									SET v_identifyFlag = 'IDFTNDTMFMap';
									
									IF(v_identifyFlag2='IDFTNAgentM')
									THEN
										SET v_identifyFlag = 'IDFTNDTMFMap2';
										SET v_identifyFlag2 = '';
									END IF;	
								ELSE
									SET v_identifyFlag = 'IDFTNTransitionMap';
								END IF;
							
							ELSEIF (v_identifyFlag='IDFTNDTMFMap')
							THEN				
								SET v_test12 = (SELECT  Count(1) FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset);
								IF(v_test12>0)
								THEN	
									Drop temporary table if exists tempTable8;
					  				Create temporary table tempTable8 (MenuName varchar(1000),Options varchar(1000),Counts INT);
							  		
									DELETE FROM tempTable8;
									INSERT into tempTable8(MenuName,Options,Counts)
									SELECT MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;						
								    
									INSERT GRAPHTREETEMPIDENTITY             
									SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_identitydialogParentID AS PARENTID
									FROM  GRAPHTREETEMPIDENTITY dsm 
									INNER JOIN DTMF_MAP dtmf
									ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
									WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
									
									Drop temporary table if exists tempTable9;
									Create temporary table tempTable9 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);						
									
									DELETE FROM tempTable9;
									INSERT INTO tempTable9(MenuName,Options,Counts)
									SELECT dtmf.SEMANTIC_TAG as MenuName,t.Options,t.Counts from DTMF_MAP dtmf
									inner join tempTable8 t
									on t.Options = dtmf.OPTIONS
									WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset; 	
														
									UPDATE GRAPHTREETEMPIDENTITY GT
									INNER JOIN tempTable9 t
									on GT.ID = t.MenuName 
									SET HITCOUNT = t.Counts;						
									
									INSERT GRAPHTREE       
									SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' AS DESTINATIONNODE,'' AS Intent,dtmf.SEMANTIC_TAG AS InputTag, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(v_identitydialogParentID) AS PARENTID,dtmf.OPTIONS as Options
									FROM  GRAPHTREETEMPIDENTITY dsm 
									INNER JOIN DTMF_MAP dtmf
									ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
									WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
									
									UPDATE GRAPHTREE GT
									INNER JOIN GRAPHTREETEMPIDENTITY t
									on GT.ID = t.ID 
									SET HITCOUNT = t.HITCOUNT;
									
									DELETE FROM graphTreeTemp6;
									INSERT graphTreeTemp6             
									SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS PARENTID
									FROM  GRAPHTREETEMPIDENTITY dsm 
									INNER JOIN DTMF_MAP dtmf
									ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
									WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
									
									INSERT graphTreeTemp7             
									SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS PARENTID
									FROM  GRAPHTREETEMPIDENTITY dsm 
									INNER JOIN DTMF_MAP dtmf
									ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
									WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;						
									
									INSERT semanticTempIdentity           
									SELECT NAME,PARENT FROM graphTreeTemp6 WHERE IWTYPE='DTMF'; 	
									 
								   SET v_semanticValueIdentity = (SELECT NAME FROM semanticTempIdentity ORDER BY NO LIMIT 1);
									
									SET v_identitydtmfParentID=(SELECT PARENTID FROM graphTreeTemp7 WHERE IWTYPE='DTMF' AND NAME=v_semanticValueIdentity LIMIT 1);
									
									SET v_semanticValueCountIdentity = (SELECT COUNT(1) FROM semanticTempIdentity);		
													
									SET v_identifyFlag = 'IDFTNTransitionMap';
								ELSE
									SET v_identifyFlag = 'IDFTNTransitionMap';
								END IF;
							
						ELSEIF (v_identifyFlag = 'IDFTNAgent')
						THEN
							SET v_identifyFlag2 = 'IDFTNAgentM';
							
							SET v_test13 = (SELECT  Count(1) FROM TRANSITION_MAP tm
							WHERE tm.INPUT_TAG = v_semanticValueIdentity);
							IF(v_test13>0)
							THEN
								
								DELETE FROM GRAPHTREETEMPIDENTITY;			
								INSERT GRAPHTREETEMPIDENTITY
								SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS NAMEID, tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(v_identitydtmfParentID) AS PARENTID
								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValueIdentity;
								
								SET v_destActionnew1=(SELECT  tm.DESTINATION_ACTION FROM TRANSITION_MAP tm	WHERE tm.INPUT_TAG = v_semanticValueIdentity);
								
								DELETE FROM graphTreeTemp8;
								INSERT graphTreeTemp8
								SELECT DISTINCT 1 AS LEVEL, tm.DIALOG_STATE AS ID,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS NAMEID,tm.DIALOG_STATE AS NAME, tm.INPUT_TAG AS PARENT , 'TRANSITION' AS IWTYPE,v_hitcount AS HITCOUNT,(CONCAT(v_identitydtmfParentID,'_',convert(tm.ID, char))) AS PARENTID
								FROM TRANSITION_MAP tm
								WHERE tm.INPUT_TAG = v_semanticValueIdentity;
								
								DELETE FROM transStageTemp;
								INSERT transStageTemp
								SELECT NAME,PARENT FROM graphTreeTemp8 WHERE IWTYPE='TRANSITION';

								SET v_identitytransParentID = (SELECT PARENTID FROM graphTreeTemp8 WHERE IWTYPE='TRANSITION' LIMIT 1);
								
								SET v_identityintent = (SELECT INTENT FROM IVR_IW_Transition_Map WHERE InputTag = v_semanticValueIdentity LIMIT 1);
								
								SET v_dialogState = (SELECT NAME FROM transStageTemp LIMIT 1);

								SET v_identifyFlag = 'IDFTNDialogState';
																	
								SET v_tempStageValue3=(Select DTMF_GRAMMAR_SET from DIALOG_STATE_MAP where DIALOG_STATE_TAG = v_dialogState);
								
								IF(v_tempStageValue3=v_dialogState)
								THEN
									SET v_identifyFlag = 'IDFTNJumpToDTMF';
								END IF;			
								
								IF EXISTS(SELECT NAME FROM transDialogList WHERE NAME=v_dialogState)
								THEN							
									SET v_identifyFlag = 'IDFTNTransitionMap';
								END IF;	
							ELSE
								SET v_flag = 'IDFTNTransitionMap';
							END IF;	
						
						ELSEIF (v_identifyFlag = 'IDFTNDTMFMap2')
						THEN	
							SET v_test14 = (SELECT  Count(1) FROM  GRAPHTREETEMPIDENTITY dsm 
							INNER JOIN DTMF_MAP dtmf
							ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
							WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset);
							IF(v_test14>0)
							THEN		
								Drop temporary table if exists tempTable10;
				  				Create temporary table tempTable10 (MenuName varchar(1000),Options varchar(1000),Counts INT);
						  		
								delete from tempTable10;
								INSERT into tempTable10(MenuName,Options,Counts)
								select MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;

								INSERT GRAPHTREETEMPIDENTITY             
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_identitydialogParentID AS PARENTID
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
								
								Drop temporary table if exists tempTable11;
								Create temporary table tempTable11 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);						

								delete from tempTable11;
								INSERT into tempTable11(MenuName,Options,Counts)
								select dtmf.SEMANTIC_TAG as MenuName,t.Options,t.Counts from DTMF_MAP dtmf
								inner join tempTable10 t
								on t.Options = dtmf.OPTIONS
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset; 	
								
								UPDATE GRAPHTREETEMPIDENTITY GT
								INNER JOIN tempTable11 t
								on GT.ID = t.MenuName 
								SET HITCOUNT = t.Counts;

								INSERT GRAPHTREE 
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitydialogParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' as DESTINATIONNODE,'' as Intent,dtmf.SEMANTIC_TAG AS InputTag, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(v_identitydialogParentID) AS PARENTID,dtmf.OPTIONS as Options
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dtmfgrammarset;
								
								UPDATE GRAPHTREE GT
								INNER JOIN GRAPHTREETEMPIDENTITY t
								on GT.ID = t.ID 
								SET HITCOUNT = t.HITCOUNT;
								
								SET v_identifyFlag = 'IDFTNTransitionMap';
							ELSE
								SET v_identifyFlag = 'IDFTNTransitionMap';
							END IF;				  	
						ELSEIF (v_identifyFlag = 'IDFTNJumpToDTMF')
						THEN		
							SET v_test15 = (SELECT  Count(1) FROM GRAPHTREETEMPIDENTITY dsm 
							INNER JOIN DTMF_MAP dtmf
							ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET
							WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState);
							IF(v_test15>0)
							THEN
								Drop temporary table if exists tempTable12;
				  				Create temporary table tempTable12 (MenuName varchar(1000),Options varchar(1000),Counts INT);
						  		
								delete from tempTable12;
								INSERT into tempTable12(MenuName,Options,Counts)
								select MENU_NAME,SUBSTRING(MENU_NAME,LOCATE('_',MENU_NAME)+1,CHAR_LENGTH(RTRIM(MENU_NAME))) as options,MENU_COUNTS from DTMFCount;

								INSERT GRAPHTREETEMPIDENTITY           
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, 0 AS HITCOUNT,v_identitytransParentID AS PARENTID
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
								
								DROP TEMPORARY TABLE IF EXISTS tempTable13;
								CREATE TEMPORARY TABLE tempTable13 (MenuName varchar(1000),Options varchar(1000),Counts int,ID INT);
													
								DELETE from tempTable13;
								INSERT into tempTable13(MenuName,Options,Counts)
								SELECT dtmf.SEMANTIC_TAG AS MenuName,t.Options,t.Counts FROM DTMF_MAP dtmf
								INNER JOIN tempTable12 t
								ON t.Options = dtmf.OPTIONS
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState; 	
														
								UPDATE GRAPHTREETEMPIDENTITY GT
								INNER JOIN tempTable13 t
								ON GT.ID = t.MenuName 
								SET HITCOUNT = t.Counts;

								INSERT GRAPHTREE       
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME,'0' AS GRAMMARSET,'0' AS DESTINATIONACTION ,''AS DESTINATIONNODE,'' as Intent, dtmf.SEMANTIC_TAG AS InputTag,dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,v_identitytransParentID AS PARENTID,dtmf.OPTIONS as Options
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
				
								UPDATE GRAPHTREE GT
								INNER JOIN GRAPHTREETEMPIDENTITY t
								on GT.ID = t.ID 
								SET HITCOUNT = t.HITCOUNT;
								
								DELETE  FROM graphTreeTemp6;
								INSERT graphTreeTemp6            
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS PARENTID
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;
								
								INSERT graphTreeTemp7             
								SELECT DISTINCT  3 AS LEVEL,dtmf.SEMANTIC_TAG AS ID, (CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS NAMEID,dtmf.SEMANTIC_TAG AS NAME, dsm.NAME AS PARENT, 'DTMF' as IWTYPE, v_hitcount AS HITCOUNT,(CONCAT(v_identitytransParentID,'_',convert(dtmf.ID, char))) AS PARENTID
								FROM  GRAPHTREETEMPIDENTITY dsm 
								INNER JOIN DTMF_MAP dtmf
								ON dsm.NAME = dtmf.DTMF_GRAMMAR_SET 					
								WHERE dtmf.DTMF_GRAMMAR_SET = v_dialogState;			
								
								INSERT semanticTempIdentity           
								SELECT NAME,PARENT FROM graphTreeTemp6 WHERE IWTYPE='DTMF'; 	
												
								SET v_semanticValueIdentity = (SELECT NAME FROM semanticTempIdentity ORDER BY NO LIMIT 1);
								
								SET v_identitydtmfParentID=(SELECT PARENTID FROM graphTreeTemp7 WHERE IWTYPE='DTMF' AND NAME=v_semanticValueIdentity LIMIT 1);
						
								SET v_semanticValueCountIdentity = (SELECT COUNT(1) FROM semanticTempIdentity);
														
								SET v_identifyFlag = 'IDFTNTransitionMap';		
							ELSE
								SET v_identifyFlag = 'IDFTNTransitionMap';
							END IF;	
						ELSE
								SET v_identifyFlag = 'STOP';
							END IF;
						END WHILE;		
							
					
					SET v_flag = 'TransitionMap';	
				ELSE
					SET v_flag = 'false';
				END IF;
END WHILE;

 UPDATE GRAPHTREE GT
						INNER JOIN TRANSITION_MAP t
						on GT.NAME = t.DESTINATION_NODE and t.DESTINATION_ACTION='CallFlowContinue' 
						SET NAME = t.INPUT_TAG,InputTag=t.INPUT_TAG;
						
update GRAPHTREE set NAME = p_DNIS where LEVEL ='0';

		SELECT   level ,NAMEID AS ID, NAME  AS NAME,GRAMMARSET AS GRAMMARSET,DESTINATIONACTION AS DESTINATIONACTION,DESTINATIONNODE AS DESTINATIONNODE,Intent AS Intent,InputTag AS InputTag,PARENTID AS PARENT ,Options as Options FROM GRAPHTREE   order by parentid,Options;
	
	ELSE
		INSERT GRAPHTREE
		SELECT DISTINCT 0 AS LEVEL,p_DNIS AS ID,'1' AS NAMEID,'NULL' AS NAME,'' AS GRAMMARSET,'0' AS DESTINATIONACTION,'' AS DESTINATIONNODE,'' AS Intent,'' AS InputTag, '0' AS PARENT,'DNISS' AS IWTYPE,v_hitcount AS HITCOUNT,'0' AS PARENTID,'' as Options;
	
		SELECT  level ,NAMEID AS ID, NAME  AS NAME,GRAMMARSET AS GRAMMARSET ,DESTINATIONACTION AS DESTINATIONACTION,DESTINATIONNODE AS DESTINATIONNODE,Intent AS Intent,InputTag AS InputTag,PARENTID AS PARENT ,Options as Options FROM GRAPHTREE; 	
	END IF;	
END;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.spTruncateVIPListTable
DELIMITER //
CREATE PROCEDURE `spTruncateVIPListTable`(
OUT p_TotalPageSize INT)
begin

	Declare v_MAIN LONGTEXT;
	Declare v_TotalCount LONGTEXT;
	SET p_TotalPageSize = 0;
	
	SET v_TotalCount = 'select count(1) INTO @x from GBL_Custom_ContactList';
	SET v_MAIN = 'truncate table `GBL_Custom_ContactList`';

	SET @stmt_strtot = v_TotalCount;
	PREPARE stmtTot FROM @stmt_strtot;
	EXECUTE stmtTot;
	DEALLOCATE PREPARE stmtTot;
	
	SET @stmt_str = v_MAIN;
	PREPARE stmt FROM @stmt_str;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
			
	SET p_TotalPageSize :=  @x;
	SELECT	p_TotalPageSize as 'TotalPageSize';
			
end//
DELIMITER ;

-- Dumping structure for procedure OCM.sp_checkForExistingFax
DELIMITER //
CREATE PROCEDURE `sp_checkForExistingFax`(p_jobid nvarchar(50))
begin
select 1 from Fax_Sent_Details where JobID = p_jobid;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.SP_ChkOutageAvailable_1608
DELIMITER //
CREATE PROCEDURE `SP_ChkOutageAvailable_1608`(  p_hotline varchar(7))
BEGIN
  select count(*) as Active_Count from Maintenance_Master where NOW(3) >= Start_Time and (NOW(3) < End_Time or End_Time is null) and Maintenance_ID not like 'Promo_%' and Maintenance_Master.Hotline=p_hotline; 
  END//
DELIMITER ;

-- Dumping structure for procedure OCM.sp_insertReceivedFaxDetails
DELIMITER //
CREATE PROCEDURE `sp_insertReceivedFaxDetails`(
p_jobid varchar(50),
p_FileName varchar(260),
p_AnnotatedFile varchar(260),
p_ErrorString varchar(500),
p_Time varchar(50),
p_Result int,
p_PageCount int,
p_CallerID varchar(50),
p_CallDuration varchar(10),
p_ReportDateTime datetime(3),
p_ReceiveStatus varchar(20))
begin
update Fax_Received_Details set `FileName` = p_FileName, `ErrorString` = p_ErrorString , `ReceivedDateTime` = p_Time,
`Result` = p_Result, `PageCount` = p_PageCount, `CallerID` = p_CallerID, `CallDuration` = p_CallDuration,
`ReportDateTime` = p_ReportDateTime, `ReceiveStatus` = p_ReceiveStatus, `AnnotatedFile` = p_AnnotatedFile where `JobID` = p_jobid;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.sp_insertSentFaxDetails
DELIMITER //
CREATE PROCEDURE `sp_insertSentFaxDetails`(
p_jobid varchar(50),
p_ErrorString varchar(500),
p_Time varchar(50),
p_Result int,
p_Attempts int,
p_CallDuration varchar(20),
p_ReportDateTime datetime(3),
p_SendStatus varchar(15))
begin
update Fax_Sent_Details set `ErrorString` = p_ErrorString, `SentDateTime` = p_Time,`Result` = p_Result,
`Attempts` = p_Attempts, `CallDuration` = p_CallDuration,`ReportDateTime` = p_ReportDateTime, `SendStatus` = p_SendStatus where `jobID` = p_jobid;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.SP_ON_VDN_CONNECT
DELIMITER //
CREATE PROCEDURE `SP_ON_VDN_CONNECT`(p_VDN VARCHAR(10),p_DEVICE VARCHAR(10),p_AGENT VARCHAR(10),p_UCID VARCHAR(50))
BEGIN
DECLARE v_UCID_COUNT VARCHAR(50);
--  SQLINES DEMO ***  RECORD
SELECT COUNT(UCID) INTO v_UCID_COUNT FROM VDN_MONITOR_DETAILS WHERE UCID = p_UCID;
IF(v_UCID_COUNT >0)--  SQLINES DEMO *** STS
	THEN
		--  SQLINES DEMO *** E IS AN IVR DEVICE, if yes then ignore
		IF(p_DEVICE NOT IN (Select extension from IVR_EXTENSION))
			THEN
			-- UPDATE THE RECORD
			UPDATE VDN_MONITOR_DETAILS SET AGENTID = p_AGENT,agent_connect_datetime = CONCAT(date_format(now(3),'%Y%m%d') , replace(date_format(now(3),'%T'),':',''))
			WHERE UCID = p_UCID;
		END IF;
ELSE
		--  SQLINES DEMO *** E IS AN IVR DEVICE
		IF(p_DEVICE NOT IN (Select extension from IVR_EXTENSION))
			THEN
			-- INSERT A RECORD
			INSERT INTO vdn_monitor_details(vdn,ucid,agentid,agent_connect_datetime) 
			VALUES (p_VDN,p_UCID,p_AGENT,CONCAT(date_format(now(3),'%Y%m%d') , replace(date_format(now(3),'%T'),':','')));
		END IF;
	END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.sp_updateSentFaxDetails
DELIMITER //
CREATE PROCEDURE `sp_updateSentFaxDetails`(
p_jobid varchar(50),
p_FileName varchar(260),
p_ErrorString varchar(500),
p_Time varchar(50),
p_Result int,
p_Attempts int,
p_CallDuration varchar(20),
p_ReportDateTime datetime(3),
p_SendStatus varchar(20))
begin
update Fax_Sent_Details set `FileName`=p_FileName,`ErrorString`=p_ErrorString,
`SentDateTime`=p_Time,`Result`=p_Result,`Attempts`=p_Attempts, `CallDuration`=p_CallDuration,
`ReportDateTime`=p_ReportDateTime, `SendStatus` = p_SendStatus where `jobID`=p_jobid;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.SP_VDNMonitor
DELIMITER //
CREATE PROCEDURE `SP_VDNMonitor`(
	p_UCID VARCHAR(30),
	p_AgentDevice VARCHAR(10),
	p_AgentID VARCHAR(10),
	p_PhoneNumber VARCHAR(20),
	p_VDN VARCHAR(10),
	p_Queue VARCHAR(10),
	p_ConnectDate VARCHAR(8),
	p_ConnectTime VARCHAR(6),
	p_callID VARCHAR(50)
)
BEGIN
	IF(p_AgentID <> '')
	THEN
		INSERT INTO VDN_Monitor(`UCID`,`AgentDevice`,`AgentID`,`PhoneNumber`,
		`VDN`,`Queue`,`ConnectDate`,`ConnectTime`, connectionhandle) VALUES 
		(p_UCID,p_AgentDevice,p_AgentID,p_PhoneNumber,p_VDN,p_Queue,p_ConnectDate,p_ConnectTime,p_callID);
	END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TAS.CampaignNames
DELIMITER //
CREATE PROCEDURE `TAS.CampaignNames`(
p_startdate datetime(3),
p_enddate datetime(3))
begin
select distinct `Name`,ID from TCM_Campaign c 
inner join TAS_SurveyResult s on c.id=s.CampaignId 
left join TAS_SurveyDetails d on s.SessionId=d.SessionId and d.StartDateTime >= p_startdate and d.EndDateTime <= p_enddate;
 end//
DELIMITER ;

-- Dumping structure for procedure OCM.TAS.GetIntentsByCampaign
DELIMITER //
CREATE PROCEDURE `TAS.GetIntentsByCampaign`(
p_startdate datetime(3),
p_enddate datetime(3),
 p_campaignId varchar(100))
begin
select  distinct(Intent) from TAS_SurveyResult s
left join TAS_SurveyDetails d on s.SessionId=d.SessionId and d.StartDateTime >= p_startdate and d.EndDateTime <= p_enddate 
 where 
     s.CampaignId=p_campaignId;
 end//
DELIMITER ;

-- Dumping structure for procedure OCM.TAS.GetQuestionnairesbyIntent
DELIMITER //
CREATE PROCEDURE `TAS.GetQuestionnairesbyIntent`(
p_startdate datetime(3),
p_enddate datetime(3),
p_intent varchar(100))
begin
select 
	QuestionnaireName as QuestionnaireNameId,  
	QuestionnaireName as QuestionnaireName
	  
	from(
	select distinct QuestionnaireName from TAS_SurveyResult s
	left join TAS_SurveyDetails d on s.SessionId=d.SessionId and d.StartDateTime >= p_startdate and d.EndDateTime <= p_enddate
	where 
		s.Intent=p_intent 
  ) as result;

 end//
DELIMITER ;

-- Dumping structure for table OCM.TAS_FileData
CREATE TABLE IF NOT EXISTS `TAS_FileData` (
  `FileContentId` bigint NOT NULL AUTO_INCREMENT,
  `QuestionnaireName` varchar(200) NOT NULL,
  `FileName` varchar(200) NOT NULL,
  `QuestionnaireStatus` varchar(50) NOT NULL,
  `Action` varchar(50) NOT NULL,
  `Contents` longtext NOT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDate` datetime(3) NOT NULL,
  PRIMARY KEY (`FileContentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_GlossaryCounts
CREATE TABLE IF NOT EXISTS `TAS_GlossaryCounts` (
  `GlossaryHitCountId` bigint NOT NULL AUTO_INCREMENT,
  `SessionDetailsId` bigint NOT NULL,
  `SurveyResultId` bigint NOT NULL,
  `QuestionId` varchar(200) DEFAULT NULL,
  `GlossaryId` varchar(50) NOT NULL,
  `GlossaryKey` varchar(50) NOT NULL,
  `GlossaryValue` varchar(1000) NOT NULL,
  `HitCount` bigint NOT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`GlossaryHitCountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_MaskingData
CREATE TABLE IF NOT EXISTS `TAS_MaskingData` (
  `MaskingItemId` bigint NOT NULL AUTO_INCREMENT,
  `MaskingKey` varchar(100) DEFAULT NULL,
  `MaskingValue` varchar(100) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `LastChangedBy` varchar(50) DEFAULT NULL,
  `LastChangedOn` varchar(30) DEFAULT NULL,
  `Action` varchar(20) NOT NULL DEFAULT 'block',
  `OrgUnit` int DEFAULT NULL,
  PRIMARY KEY (`MaskingItemId`),
  UNIQUE KEY `UK_TAS_MaskingData` (`MaskingKey`,`OrgUnit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_MonitoringAnswers
CREATE TABLE IF NOT EXISTS `TAS_MonitoringAnswers` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `QuestionnaireName` varchar(300) NOT NULL,
  `QuestionnaireFileName` varchar(100) NOT NULL,
  `QuestionId` varchar(200) DEFAULT NULL,
  `Question` varchar(2000) NOT NULL,
  `AnswerId` varchar(200) DEFAULT NULL,
  `Answer` varchar(2000) NOT NULL,
  `AnswerDescription` varchar(2000) NOT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDateTime` datetime(3) NOT NULL,
  `ModifiedDateTime` datetime(3) DEFAULT NULL,
  `MarkedForDeletion` bit(1) DEFAULT NULL,
  `ModifiedBy` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TAS_MonitoringAnswers_QuestionaireFileName` (`QuestionnaireFileName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_OfflineSurveyDetails
CREATE TABLE IF NOT EXISTS `TAS_OfflineSurveyDetails` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `SurveyFormDate` varchar(50) DEFAULT NULL,
  `CampaignId` varchar(50) DEFAULT NULL,
  `RespondentPhone` varchar(100) DEFAULT NULL,
  `AgentId` varchar(50) DEFAULT NULL,
  `StationId` varchar(50) DEFAULT NULL,
  `Intent` varchar(50) DEFAULT NULL,
  `QuestionnaireName` varchar(50) DEFAULT NULL,
  `QuestionCount` int DEFAULT NULL,
  `AnsweredCount` int DEFAULT NULL,
  `InsertedBy` varchar(50) DEFAULT NULL,
  `InsertedDateTime` datetime(3) DEFAULT NULL,
  `Comments` longtext,
  `TemplateDateTime` varchar(50) DEFAULT NULL,
  `RespondentName` varchar(100) DEFAULT NULL,
  `RespondentNRIC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_OfflineSurveyFiles
CREATE TABLE IF NOT EXISTS `TAS_OfflineSurveyFiles` (
  `UploadId` bigint NOT NULL AUTO_INCREMENT,
  `CampaignId` varchar(200) NOT NULL,
  `FileNames` varchar(5000) NOT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDate` datetime(3) NOT NULL,
  PRIMARY KEY (`UploadId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_SurveyDetails
CREATE TABLE IF NOT EXISTS `TAS_SurveyDetails` (
  `SessionDetailsId` bigint NOT NULL AUTO_INCREMENT,
  `SessionId` bigint NOT NULL,
  `NodeId` varchar(200) DEFAULT NULL,
  `QuestionId` varchar(200) DEFAULT NULL,
  `Question` varchar(2000) DEFAULT NULL,
  `AnswerIds` varchar(2000) DEFAULT NULL,
  `AnswerType` varchar(50) NOT NULL,
  `Answers` text,
  `CustomAnswer` text,
  `CustomType` varchar(50) DEFAULT NULL,
  `MaskedAnswer` text,
  `StartDateTime` datetime(3) NOT NULL,
  `EndDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `Note` text,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `ModifiedDateTime` datetime(3) NOT NULL,
  `Skipped` bit(1) NOT NULL,
  `MarkedForDeletion` bit(1) NOT NULL DEFAULT b'0',
  `Score` int DEFAULT NULL,
  PRIMARY KEY (`SessionDetailsId`),
  KEY `IX_TAS_SurveyDetails_EndDateTime` (`EndDateTime`),
  KEY `IX_TAS_SurveyDetails_SessionId_FK` (`SessionId`),
  KEY `IX_TAS_SurveyDetails_StartDateTime` (`StartDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_SurveyModellingAction
CREATE TABLE IF NOT EXISTS `TAS_SurveyModellingAction` (
  `ActionId` bigint NOT NULL AUTO_INCREMENT,
  `QuestionnaireName` varchar(50) NOT NULL,
  `FileName` varchar(200) NOT NULL,
  `QuestionnaireStatus` varchar(50) NOT NULL,
  `Action` varchar(50) NOT NULL,
  `ModifiedBy` varchar(50) NOT NULL,
  `ModifiedDate` datetime(3) NOT NULL,
  PRIMARY KEY (`ActionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TAS_SurveyResult
CREATE TABLE IF NOT EXISTS `TAS_SurveyResult` (
  `SessionId` bigint NOT NULL AUTO_INCREMENT,
  `CampaignId` varchar(50) NOT NULL,
  `CustomerId` varchar(50) NOT NULL,
  `UCID` varchar(50) NOT NULL,
  `AgentId` varchar(50) NOT NULL,
  `StationId` varchar(50) NOT NULL,
  `SurveyType` varchar(50) NOT NULL,
  `Intent` varchar(50) NOT NULL,
  `QuestionnaireName` varchar(300) NOT NULL,
  `SurveyComments` varchar(4000) DEFAULT NULL,
  `Status` varchar(400) NOT NULL,
  `Reason` varchar(400) DEFAULT NULL,
  `SurveyStartDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `SurveyEndDateTime` datetime(3) DEFAULT NULL,
  `InsertedBy` varchar(50) NOT NULL,
  `InsertedDateTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `MarkedForDeletion` bit(1) NOT NULL DEFAULT b'0',
  `LastUpdatedDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`SessionId`),
  KEY `IX_TAS_SurveyResult_CampaignId` (`CampaignId`),
  KEY `IX_TAS_SurveyResult_Intent` (`Intent`),
  KEY `IX_TAS_SurveyResult_SurveyEndDateTime` (`SurveyEndDateTime`),
  KEY `IX_TAS_SurveyResult_SurveyStartDateTime` (`SurveyStartDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_AgentScreen
CREATE TABLE IF NOT EXISTS `TCM_AgentScreen` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `Url` varchar(100) NOT NULL,
  `ScreenPopType` varchar(100) NOT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_AlternativeContact
CREATE TABLE IF NOT EXISTS `TCM_AlternativeContact` (
  `ContactId` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `Strategy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_BackupScript
CREATE TABLE IF NOT EXISTS `TCM_BackupScript` (
  `TCM_BackupScriptID` int NOT NULL AUTO_INCREMENT,
  `CreatedOn` varchar(50) NOT NULL,
  `CreatedBy` varchar(50) NOT NULL,
  `ChangedOn` varchar(50) NOT NULL,
  `ChangedBy` varchar(50) NOT NULL,
  `IsExecuted` int NOT NULL,
  `Script` varchar(4000) NOT NULL,
  `ServerId` varchar(100) DEFAULT NULL,
  KEY `TCM_BackupScriptID` (`TCM_BackupScriptID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Campaign
CREATE TABLE IF NOT EXISTS `TCM_Campaign` (
  `ID` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Channel` varchar(100) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `ContactType` varchar(100) DEFAULT NULL,
  `MaxConcurrentCalls` decimal(20,0) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `DialPrefix` varchar(100) DEFAULT NULL,
  `Url` varchar(100) DEFAULT NULL,
  `ScreenPopType` varchar(100) DEFAULT NULL,
  `DynamicContactDataCount` int DEFAULT NULL,
  `DynamicContactDataFields` varchar(1000) DEFAULT NULL,
  `WaitTimeBeforeDial` int NOT NULL,
  `IsForever` int NOT NULL,
  `Intent` varchar(100) DEFAULT NULL,
  `IsDirectAgent` int NOT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `RetryCount` int DEFAULT NULL,
  `Template` varchar(4000) DEFAULT NULL,
  `MessageTemplate` varchar(4000) DEFAULT NULL,
  `AppliedFilterId` varchar(100) DEFAULT NULL,
  `TeamId` int DEFAULT NULL,
  `TakenBy` varchar(100) DEFAULT NULL,
  KEY `IX_TCM_Campaign_ID` (`ID`),
  KEY `IX_TCM_Campaign_Name` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Campaign_EmailConfiguration
CREATE TABLE IF NOT EXISTS `TCM_Campaign_EmailConfiguration` (
  `Id` varchar(100) DEFAULT NULL,
  `CampaignId` varchar(100) DEFAULT NULL,
  `EmailAccountId` varchar(4000) DEFAULT NULL,
  `EmailSenderId` bigint DEFAULT NULL,
  `EmailTemplateId` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Campaign_Readlock
CREATE TABLE IF NOT EXISTS `TCM_Campaign_Readlock` (
  `campid` varchar(100) NOT NULL,
  `locked` int NOT NULL,
  `lockedtime` varchar(100) NOT NULL,
  `loadbalance` int NOT NULL,
  `lockedby` varchar(100) NOT NULL,
  `comment` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tcm_campaign_teamlist
CREATE TABLE IF NOT EXISTS `tcm_campaign_teamlist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaignid` varchar(100) NOT NULL,
  `teamid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Contact
CREATE TABLE IF NOT EXISTS `TCM_Contact` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Age` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Gender` varchar(100) DEFAULT NULL,
  `Status` varchar(100) NOT NULL,
  `IsDND` int NOT NULL,
  `NRIC` varchar(100) DEFAULT NULL,
  `Language` varchar(100) DEFAULT NULL,
  `DirectAgent` varchar(100) DEFAULT NULL,
  `ScheduleTime` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `Source` varchar(50) DEFAULT NULL,
  `SourceId` varchar(50) DEFAULT NULL,
  `RetryCount` int DEFAULT NULL,
  `DialAfterTime` longtext,
  `DialingPhoneNumber` varchar(100) DEFAULT NULL,
  `CallbackPhoneNumber` varchar(100) DEFAULT NULL,
  `Strategy` varchar(100) DEFAULT NULL,
  `MessageTemplate` varchar(100) DEFAULT NULL,
  `RequestedDateTime` varchar(100) DEFAULT NULL,
  `RefNumber` varchar(100) DEFAULT NULL,
  `SubReferNumber` varchar(100) DEFAULT NULL,
  `CallType` varchar(100) DEFAULT NULL,
  `RefType` varchar(100) DEFAULT NULL,
  `TakenBy` varchar(100) DEFAULT NULL,
  KEY `IX_TCM_Contact_campId` (`CampId`),
  KEY `IX_TCM_Contact_ID` (`ID`),
  KEY `IX_TCM_Contact_PhoneNumber` (`PhoneNumber`),
  KEY `IX_TCM_Contact_status` (`Status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_ContactDynamicData
CREATE TABLE IF NOT EXISTS `TCM_ContactDynamicData` (
  `ContactId` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Value` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  KEY `IX_TCM_ContactDynamicData_ContactId` (`ContactId`),
  KEY `IX_TCM_ContactDynamicData_Name` (`Name`),
  KEY `IX_TCM_ContactDynamicData_Value` (`Value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_ContactImportSchedule
CREATE TABLE IF NOT EXISTS `TCM_ContactImportSchedule` (
  `Id` varchar(100) DEFAULT NULL,
  `CampId` varchar(100) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `FilePath` varchar(100) DEFAULT NULL,
  `Frequency` int DEFAULT NULL,
  `ScheduleStartTime` varchar(100) DEFAULT NULL,
  `LastImportTime` varchar(100) DEFAULT NULL,
  `LastImportStatus` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Contact_Actions
CREATE TABLE IF NOT EXISTS `TCM_Contact_Actions` (
  `ContactId` varchar(100) DEFAULT NULL,
  `RecordId` varchar(100) DEFAULT NULL,
  `Action` varchar(30) DEFAULT NULL,
  `ActionTime` varchar(20) DEFAULT NULL,
  `ChangedBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Contact_Group
CREATE TABLE IF NOT EXISTS `TCM_Contact_Group` (
  `ID` varchar(100) NOT NULL,
  `GroupName` varchar(100) NOT NULL,
  `Intent` varchar(100) DEFAULT NULL,
  `Status` int NOT NULL,
  `Channel` varchar(100) DEFAULT NULL,
  `DynamicContactDataCount` int DEFAULT NULL,
  `DynamicContactDataFields` varchar(1000) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `TeamId` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Contact_Reminder
CREATE TABLE IF NOT EXISTS `TCM_Contact_Reminder` (
  `ID` varchar(100) NOT NULL,
  `ContactId` varchar(100) NOT NULL,
  `ScheduledTime` varchar(100) NOT NULL,
  `NotificationType` varchar(50) NOT NULL,
  `Status` int NOT NULL,
  `Comment` varchar(250) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `Order` int DEFAULT NULL,
  `TemplateId` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_DAC_Response
CREATE TABLE IF NOT EXISTS `TCM_DAC_Response` (
  `Id` varchar(100) DEFAULT NULL,
  `CampId` varchar(100) NOT NULL,
  `ContactId` varchar(100) NOT NULL,
  `AgentId` varchar(100) DEFAULT NULL,
  `Extension` varchar(100) DEFAULT NULL,
  `DacResponse` varchar(100) NOT NULL,
  `ScheduleDateTime` varchar(100) DEFAULT NULL,
  `Status` int NOT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_DoNoCallList_Mapping
CREATE TABLE IF NOT EXISTS `TCM_DoNoCallList_Mapping` (
  `CampId` varchar(100) DEFAULT NULL,
  `DndListId` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_DoNotCallList
CREATE TABLE IF NOT EXISTS `TCM_DoNotCallList` (
  `Id` varchar(100) NOT NULL,
  `DndListId` varchar(100) DEFAULT NULL,
  `Type` varchar(100) DEFAULT NULL,
  `Contact` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_DUPLICATE_CONTACT
CREATE TABLE IF NOT EXISTS `TCM_DUPLICATE_CONTACT` (
  `Id` varchar(100) NOT NULL,
  `CampaignId` varchar(100) DEFAULT NULL,
  `ContactId` varchar(100) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `RequestedDateTime` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `DynamicValues` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.TCM_Get_CallVolumeforEachCallType
DELIMITER //
CREATE PROCEDURE `TCM_Get_CallVolumeforEachCallType`()
BEGIN
   SELECT *, 
	CASE `value` 
	WHEN 'ver' then 1 
	WHEN 'ACT' then 2 
	WHEN 'TMP' then 3 
	when 'CVV' then 4 
	when 'FBM' then 5 
	else 6 end prio 
from (
	select `value`,CHeader,count(cheader) as c from (
	SELECT  `value` ,`status`,
	case `value` when 'VER' then 1 
				else `value` end VPriority,
	case `status` when 'Open' then 'RIQ' 
				 when 'QueueDialing' then 'RIQ' 
				 when 'QueueConnected' then 'RIQ'
	             when 'Deleted' then 'RC' else '' end as CHeader
	FROM TCM_ContactDynamicData,TCM_Contact
	WHERE TCM_ContactDynamicData.ContactId=TCM_Contact.ID 
	      and  TCM_ContactDynamicData.`Name`='calltype'
)tb 
where cheader <> '' and `Value` <> ''
GROUP BY   `value`,CHeader ) tm
order by CHeader desc, prio asc;
END//
DELIMITER ;

-- Dumping structure for table OCM.TCM_GroupContact
CREATE TABLE IF NOT EXISTS `TCM_GroupContact` (
  `ID` varchar(100) NOT NULL,
  `ContactGroupID` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `PhoneNumber` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Age` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Gender` varchar(100) DEFAULT NULL,
  `Status` varchar(100) NOT NULL,
  `NRIC` varchar(100) DEFAULT NULL,
  `Language` varchar(100) DEFAULT NULL,
  `Strategy` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `Source` varchar(50) DEFAULT NULL,
  `SourceId` varchar(50) DEFAULT NULL,
  `RetryCount` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_GroupContactDynamicData
CREATE TABLE IF NOT EXISTS `TCM_GroupContactDynamicData` (
  `ContactId` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Value` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Master_DoNotCallLists
CREATE TABLE IF NOT EXISTS `TCM_Master_DoNotCallLists` (
  `Id` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `Filter` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_PriorityMatrix
CREATE TABLE IF NOT EXISTS `TCM_PriorityMatrix` (
  `Id` varchar(100) DEFAULT NULL,
  `CampId` varchar(100) DEFAULT NULL,
  `PriorityMatrix` varchar(4000) DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_QueueSkill
CREATE TABLE IF NOT EXISTS `TCM_QueueSkill` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `Skill` varchar(100) DEFAULT NULL,
  `SkillName` varchar(100) DEFAULT NULL,
  `DialVdn` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `Filter` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Record
CREATE TABLE IF NOT EXISTS `TCM_Record` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `ContactId` varchar(100) NOT NULL,
  `PhoneNumber` varchar(100) NOT NULL,
  `DialDateTime` varchar(100) DEFAULT NULL,
  `CompletedDateTime` varchar(100) DEFAULT NULL,
  `Status` varchar(500) DEFAULT NULL,
  `UCID` varchar(100) DEFAULT NULL,
  `Agent` varchar(100) DEFAULT NULL,
  `AgentConnectTime` varchar(100) DEFAULT NULL,
  `AgentSkill` varchar(100) DEFAULT NULL,
  `StatusByAgent` varchar(100) DEFAULT NULL,
  `StatusReasonByAgent` varchar(100) DEFAULT NULL,
  `AgentComment` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `SMSMessage` varchar(4000) DEFAULT NULL,
  `AppliedFilterId` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `RequestedDateTime` varchar(100) DEFAULT NULL,
  `QueueConnectedDateTime` varchar(100) DEFAULT NULL,
  `InteractionId` varchar(5) DEFAULT NULL,
  `StatusCode` varchar(100) DEFAULT NULL,
  `CallDuration` varchar(100) DEFAULT NULL,
  `IsCallBack` int DEFAULT NULL,
  KEY `IX_TCM_Record_Agent` (`Agent`),
  KEY `IX_TCM_Record_CampId` (`CampId`),
  KEY `IX_TCM_Record_ContactId` (`ContactId`),
  KEY `IX_TCM_Record_UCID` (`UCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Schedule
CREATE TABLE IF NOT EXISTS `TCM_Schedule` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `StartDate` varchar(100) DEFAULT NULL,
  `EndDate` varchar(100) DEFAULT NULL,
  `ScheduleType` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_ScheduleDate
CREATE TABLE IF NOT EXISTS `TCM_ScheduleDate` (
  `ID` varchar(100) NOT NULL,
  `ScheduleId` varchar(100) NOT NULL,
  `StartDate` varchar(100) NOT NULL,
  `StartTime` varchar(100) NOT NULL,
  `EndTime` varchar(100) NOT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_Settings
CREATE TABLE IF NOT EXISTS `TCM_Settings` (
  `ID` varchar(100) NOT NULL,
  `CampId` varchar(100) NOT NULL,
  `Settings` longtext,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `IsDeleted` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_SMS_History
CREATE TABLE IF NOT EXISTS `TCM_SMS_History` (
  `ContactId` varchar(100) NOT NULL,
  `SMSType` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `SubCaseID` varchar(100) DEFAULT NULL,
  `Content` varchar(4000) DEFAULT NULL,
  `RecordId` varchar(100) DEFAULT NULL,
  `Id` int NOT NULL AUTO_INCREMENT,
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_StatusCodeReasons
CREATE TABLE IF NOT EXISTS `TCM_StatusCodeReasons` (
  `Id` varchar(100) NOT NULL,
  `CodeId` varchar(100) DEFAULT NULL,
  `Reason` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_StatusCodes
CREATE TABLE IF NOT EXISTS `TCM_StatusCodes` (
  `Id` varchar(100) NOT NULL,
  `CampId` varchar(100) DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  `LastChangedOn` varchar(100) DEFAULT NULL,
  `LastChangedBy` varchar(100) DEFAULT NULL,
  `StatusCode` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_TimeStamp
CREATE TABLE IF NOT EXISTS `TCM_TimeStamp` (
  `tstamp` varchar(50) NOT NULL,
  `ChangedOn` varchar(50) NOT NULL,
  `ChangedBy` varchar(50) NOT NULL,
  `ClusterNodeType` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TCM_TimeStamp1
CREATE TABLE IF NOT EXISTS `TCM_TimeStamp1` (
  `tstamp` varchar(50) NOT NULL,
  `ChangedOn` varchar(50) NOT NULL,
  `ChangedBy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.TDM_AddAlerts
DELIMITER //
CREATE PROCEDURE `TDM_AddAlerts`(
p_AgentName varchar(100),
p_StationID varchar(50),
p_AgentLoginID varchar(30),
p_TeamName varchar(20),
p_OldStatus varchar(100),
p_NewStatus varchar(100),
p_OldStatusTimeSpend varchar(100),
p_InsertedDateTime datetime(3),
p_Threshold varchar(10),
p_ChangedBy varchar(30),
p_NotificationType varchar(30),
p_ChangedType varchar(30),
p_TeamId int)
begin

Insert into TDM_alerts (AgentName,StationId,AgentLoginID,TeamName,OldStatus,NewStatus,
                   OldStatusTimeSpend,InsertedDateTime,Threshold,ChangedBy,NotificationType,ChangedType,TeamId)
                   values(p_AgentName,
                   p_StationID,
                   p_AgentLoginID,
				   p_TeamName,
				   p_OldStatus,
				   p_NewStatus,
				   p_OldStatusTimeSpend,
                   p_InsertedDateTime,
                   p_Threshold,
				   p_ChangedBy,
				   p_NotificationType,
				   p_ChangedType,
				   p_TeamId
				   );
                   

end//
DELIMITER ;

-- Dumping structure for table OCM.TDM_Alerts
CREATE TABLE IF NOT EXISTS `TDM_Alerts` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AgentName` varchar(100) DEFAULT NULL,
  `StationId` varchar(50) DEFAULT NULL,
  `AgentLoginId` varchar(30) DEFAULT NULL,
  `TeamName` varchar(20) DEFAULT NULL,
  `OldStatus` varchar(100) DEFAULT NULL,
  `NewStatus` varchar(100) DEFAULT NULL,
  `OldStatusTimeSpend` varchar(100) DEFAULT NULL,
  `InsertedDateTime` datetime(3) DEFAULT NULL,
  `Threshold` varchar(10) DEFAULT NULL,
  `ChangedBy` varchar(30) DEFAULT NULL,
  `NotificationType` varchar(30) DEFAULT NULL,
  `ChangedType` varchar(30) DEFAULT NULL,
  `TeamId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TDM_Alerts_ChangedType` (`ChangedType`),
  KEY `IX_TDM_Alerts_InsertedDateTime` (`InsertedDateTime`),
  KEY `IX_TDM_Alerts_TeamId` (`TeamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.TDM_FrequentlyHitThresholdReport
DELIMITER //
CREATE PROCEDURE `TDM_FrequentlyHitThresholdReport`(
	p_Type VARCHAR(100),
	p_FromDate VARCHAR(20), 
	p_ToDate VARCHAR(20),
	p_AgentName VARCHAR(100),
	p_TeamName VARCHAR(100)
)
BEGIN

    IF(p_Type = 'MAIN')
		THEN
			SELECT `AgentName`,`AgentLoginID`,`TeamName`,CONVERT(COUNT(1), CHAR(50)) AS ThresholdCount,DATE_FORMAT(MAX(`InsertedDateTime`),'%d/%m/%Y %H:%i:%s') LastThresholdDateTime FROM TDM_Alerts 
			WHERE `InsertedDateTime`>=p_FromDate AND `InsertedDateTime`<=p_ToDate
			GROUP BY `AgentName`,`AgentLoginID`,`TeamName` ORDER BY ThresholdCount DESC,LastThresholdDateTime DESC; 
	ELSEIF (p_Type='DRILL')
		THEN
			SELECT `AgentName`,`TeamName`,`OldStatus` AS AuxState,SEC_TO_TIME(SUM(LEFT(`OldStatusTimeSpend`,2) * 3600 + SUBSTRING(`OldStatusTimeSpend`, 4,2) * 60 + SUBSTRING(`OldStatusTimeSpend`, 7,2))) AS TotalTimeSpent,
			DATE_FORMAT(MAX(`InsertedDateTime`),'%d/%m/%Y %H:%i:%s')LastThresholdDateTime,COUNT(1) AS ThresholdCount FROM TDM_Alerts
			WHERE `InsertedDateTime`>=p_FromDate AND `InsertedDateTime`<=p_ToDate AND `AgentName` like p_AgentName AND `TeamName` like p_TeamName
			GROUP BY `AgentName`,`OldStatus` ORDER BY ThresholdCount DESC,LastThresholdDateTime DESC; 
    END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GenericAgentHierarchy
DELIMITER //
CREATE PROCEDURE `TDM_GenericAgentHierarchy`(p_type varchar(50),p_teamid varchar(20),p_agentid varchar(20), out result tinyint(1))
BEGIN
	DECLARE sf_result INT DEFAULT 0;
		DROP TEMPORARY TABLE IF EXISTS GenericAgentHierarchyResult;
      CREATE TEMPORARY TABLE GenericAgentHierarchyResult (AgentId varchar(50),AgentName varchar(200),SupervisorName varchar(200),TeamName varchar(200),TeamID int,ParentID int);
        
	 IF(p_type='orgunit')
	 THEN
	 		INSERT INTO GenericAgentHierarchyResult(ParentID,TeamID,TeamName)
	 		SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT t.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID)
			
			SELECT IFNULL(ChildTable.ParentID,'0') ParentID ,ChildTable.TeamID, ChildTable.TeamName FROM AGT_Teams AS ChildTable 
			LEFT JOIN AGT_Teams AS ParentTable ON ChildTable.ParentID = ParentTable.TeamID WHERE 1=1 and 
			ChildTable.TeamID IN (SELECT TeamID FROM Team)  
			Order By ChildTable.ParentID, ChildTable.TeamID) Temp;
			
	 ELSEIF (p_type='team')
	 THEN
	 INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	 SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT t.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID)

			
			SELECT DISTINCT A.AvayaLoginID,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,
			IFNULL(C.TeamName,' ') AS TeamName , C.TeamID
			FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Agent` S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID
			LEFT JOIN `AGT_Teams` P ON C.ParentID  = P.TeamID
			LEFT JOIN `AGT_Teams` PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN (SELECT TeamID FROM Team))Temp; 
			
	 ELSEIF (p_type='teamsupervisor')
	 THEN
	 INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	 SELECT * FROM 
         (
			WITH RECURSIVE Team AS(
			SELECT `TeamID` FROM `AGT_Teams` WHERE `TeamID` = p_teamid
			UNION ALL
			SELECT T.TeamID FROM AGT_Teams t INNER JOIN Team r ON t.ParentId = r.TeamID),
			Supervisor AS ( 
			SELECT ID FROM `AGT_Agent`  WHERE AvayaLoginID=p_agentid
			UNION ALL
			SELECT A.ID FROM AGT_Agent A INNER JOIN Supervisor B   ON A.PrimarySupervisorID = B.ID)

			
			SELECT DISTINCT  A.AvayaLoginID AgentId,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName,C.TeamID FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Agent` S ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID
			LEFT JOIN `AGT_Teams` P ON C.ParentID  = P.TeamID
			LEFT JOIN `AGT_Teams` PC ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN ( SELECT TeamID FROM Team )  AND A.ID IN ( SELECT ID FROM Supervisor) )Temp;
			
	 ELSE
	        INSERT INTO GenericAgentHierarchyResult(AgentId,AgentName,SupervisorName,TeamName,TeamID)
	        SELECT DISTINCT  A.AvayaLoginID AgentId,CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AgentName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,''))  SupervisorName ,IFNULL(C.TeamName,' ') AS TeamName,C.TeamID FROM AGT_Agent A 
			LEFT JOIN AGT_Agent B ON A.PrimarySupervisorID = B.ID 
			LEFT JOIN `AGT_Teams` C ON C.TeamID = A.TeamID;
			
	 END IF;
	 SET sf_result = 1;
     SET result=sf_result;
 	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentCallDetails
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentCallDetails`(
p_fromdate varchar(20), 
p_todate varchar(20),
p_agentId varchar(50),
p_isVoiceBioInterface varchar(1))
BEGIN
	DECLARE v_channel varchar(10) DEFAULT 'Voice';
	IF(p_isVoiceBioInterface=1)
	THEN
		SET v_channel='Generic';
	END IF;
	SELECT COUNT(1) AS  TotalCalls,
		IFNULL(SUM(main.ActiveTime),0) AS TotalCallTime,
		IFNULL(SUM(acd.acdcalls),0) AS ACDCalls,
		IFNULL(SUM(acd.acdtime),0) AS AcdTime,
		IFNULL(SUM(extIn),0) AS ExtInCalls, 
		IFNULL(SUM(extIntime),0) AS ExtInTime,
		IFNULL(SUM(extOut),0) AS ExtOutCalls, 
		IFNULL(SUM(extOutTime),0) AS ExtOutTime
    FROM TMAC_Interactions main  
	LEFT JOIN ( SELECT DISTINCT sessionid, 
					COUNT(1) acdcalls, 
					SUM(ActiveTime) acdtime 
				FROM TMAC_Interactions 
				WHERE calltype=1  and channel =v_channel and agentid=p_agentId
				GROUP  BY sessionid 
			  ) acd ON main.sessionid = acd.sessionid 
	LEFT JOIN ( SELECT DISTINCT sessionid, 
					COUNT(1) extIn, 
					SUM(ActiveTime) extIntime 
				FROM TMAC_Interactions  
				WHERE calltype=2 and channel =v_channel and agentid=p_agentId 
				GROUP BY sessionid 
			  ) extIn ON main.sessionid = extIn.sessionid 
	LEFT JOIN ( select distinct sessionid, 
					COUNT(1) extOut, 
					SUM(ActiveTime) extOutTime 
				FROM TMAC_Interactions  
				WHERE IFNULL(calltype,'')='' and channel=v_channel and agentid=p_agentId 
				GROUP BY sessionid 
			  ) extOut ON main.sessionid = extOut.sessionid 
	WHERE channel = v_channel and agentid = p_agentId  and createddatetime >= p_fromdate and createddatetime <= p_todate;

	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentChannelCount
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentChannelCount`(
	p_agentId varchar(50))
BEGIN
	SELECT 
		DISTINCT `channel`,
		`count`, 
		`Enable`, 		
		CASE WHEN `channel`='audiochat' THEN 'AudioChat'
			 WHEN `channel`='email' THEN 'Email'
			 WHEN `channel`='fax' THEN 'Fax'
			 WHEN `channel`='sms' THEN 'SMS'
			 WHEN `channel`='textchat' THEN 'TextChat'
			 WHEN `channel`='videochat' THEN 'VideoChat'
		     WHEN `channel`='voice' THEN 'Voice'
			 ELSE `channel`
	    END AS `ChannelName`
	FROM AGT_ChannelCount where agentid = p_agentId;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentDetails
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentDetails`(
	p_userName varchar(50))
BEGIN
	SELECT * 
	FROM AGT_Agent 
	WHERE `UserName` = p_userName;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentFeatures
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentFeatures`(
	p_agentId varchar(50))
BEGIN
	SELECT 
		DISTINCT `Feature`,
		`Enable` ,			
		CASE WHEN `Feature`='IsCRMEnabled' THEN 'IsCRMEnabled'
			 WHEN `Feature`='IsFaxInternationalEnabled' THEN 'IsFaxInternationalEnabled'
			 WHEN `Feature`='IsFaxOutEnabled' THEN 'IsFaxOutEnabled'
			 WHEN `Feature`='IsFaxPrintEnabled' THEN 'IsFaxPrintEnabled'
			 WHEN `Feature`='IsHoldVoiceCallOnChatCall' THEN 'IsHoldVoiceCallOnChatCall'
			 WHEN `Feature`='IsManualInEnabled' THEN 'IsManualInEnabled'
		     WHEN `Feature`='IsSecondTextChatAutoAnswer' THEN 'IsSecondTextChatAutoAnswer'
			 WHEN `Feature`='IsSMSOutEnabled' THEN 'IsSMSOutEnabled'
			 WHEN `Feature`='IsTextChatAutoACWEnabled' THEN 'IsTextChatAutoACWEnabled'
			 WHEN `Feature`='IsTextChatAutoAnswer' THEN 'IsTextChatAutoAnswer'
			 WHEN `Feature`='IsVoiceACDAutoACWEnabled' THEN 'IsVoiceACDAutoACWEnabled'
			 WHEN `Feature`='IsVoiceACDAutoAnswerEnabled' THEN 'IsVoiceACDAutoAnswerEnabled'
		     WHEN `Feature`='IsVoiceAllAutoACWEnabled' THEN 'IsVoiceAllAutoACWEnabled'
	    END AS FeatureName
	FROM AGT_AgentFeature where agentid = p_agentId;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentFirstLoggedInTime
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentFirstLoggedInTime`(
	p_startDate varchar(15),
	p_endDate varchar(15),
	p_agentId varchar(50))
BEGIN
	SELECT 
		min(DISTINCT(convert(insert(insert(insert(`TimeStamp`, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime))) AS `Time`
	FROM AGT_Agent_StatusTrack 
	WHERE `TimeStamp` >=  p_startDate and `TimeStamp` <= p_endDate and `status` like '%Login%'  and AgentId = p_agentId;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentHierarchyDetails
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentHierarchyDetails`(
	p_teamId varchar(10))
BEGIN
	SELECT * 
	FROM AGT_Teams 
	WHERE `TeamID` = p_teamId;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentProfile
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentProfile`(
	p_agentId varchar(50))
BEGIN
	SELECT DISTINCT A.AvayaLoginID,
			IFNULL(A.UserName,' ') as UserName,
			IFNULL(A.FirstName,' ') as FirstName,
			IFNULL(A.LastName,' ') as LastName,
			T.TeamName, 
			CASE A.`Profile` WHEN 'S' THEN 'Supervisor' ELSE 'Agent' END `Profile`,
			CONCAT(IFNULL(B.FirstName,' '),' ',IFNULL(B.LastName,' '))  as SupervisorName,
			AccessRole,
			IFNULL(`IsManualInEnabled`,0) AS Features,
			`CRMName`,
			IFNULL(`TotalTabsAllowed`,0) AS TotalTabsAllowed,
			IFNULL(`TotalChatTabsAllowed`,0)AS TotalChatTabsAllowed,
			IFNULL(`TotalVoiceTabsAllowed`,0) AS TotalVoiceTabsAllowed,
			IFNULL(`TotalEmailTabsAllowed`,0) AS TotalEmailTabsAllowed,
			IFNULL(`Voice`,0) AS Voice,
			IFNULL(A.Email,0) as Email,
			IFNULL(`SMS`,0) as SMS,
			IFNULL(`TextChat`,0) as TextChat,
			IFNULL(`VideoChat`,0) as VideoChat,
			IFNULL(`IsVoiceACDAutoAnswerEnabled`,0) as AutoAnswerAllACDCalls,
			IFNULL(`IsVoiceACDAutoACWEnabled`,0) GotoACWAfterEachACDCalls,
			IFNULL(`IsVoiceAllAutoACWEnabled`,0) as GotoACWAfterAnyCalls,
			IFNULL(`IsHoldVoiceCallOnChatCall`,0) as HoldVoiceCallOnChatCall,
			IFNULL(`IsSecondTextChatAutoAnswer`,0) as SecondTextChatAutoAnswer,
			IFNULL(`IsCRMEnabled`,0) as CRMEnabled,
			IFNULL(`IsTextChatAutoACWEnabled`,0) as 
			TextChatAutoACWEnabled,
			IFNULL(`IsTextChatAutoAnswer`,0) as TextChatAutoAnswer 
	FROM AGT_Agent A 
    LEFT Join `AGT_Agent_Profile` P on A.AvayaLoginID = P.AgentID 
	LEFT Join `AGT_TMACAgentProfile` TC on P.AgentID = TC.AgentID 
	LEFT JOIN `AGT_Agent` B ON A.PrimarySupervisorID=B.ID 
	LEFT JOIN `AGT_Teams` T ON A.TeamID =T.TeamID where A.AvayaLoginID= p_agentId;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentStatusHistory
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentStatusHistory`(
p_fromdate varchar(20), 
p_todate varchar(20),
p_agentId varchar(50))
BEGIN
	SELECT 
		DISTINCT(convert(insert(insert(insert(`TimeStamp`, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), DATETIME)) AS `Time`,
		`Status` 
	FROM AGT_Agent_StatusTrack 
    WHERE `TimeStamp` >= p_fromdate and  `TimeStamp` <= p_todate and AgentId= p_agentId 
	ORDER BY `Time`;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetAgentSummary
DELIMITER //
CREATE PROCEDURE `TDM_GetAgentSummary`(
p_startDate varchar(15),
p_endDate varchar(15),
p_agentId varchar(50))
begin
	/*DROP TEMPORARY TABLE IF EXISTS STATTEMP;
	CREATE TEMPORARY TABLE STATTEMP (agentid VARCHAR(50),`Status` VARCHAR(50), `TimeStamp` VARCHAR(20));
	INSERT INTO STATTEMP
	SELECT agentid,`Status`,`TimeStamp` FROM AGT_Agent_StatusTrack WHERE `TimeStamp` >= p_startDate and  `TimeStamp` <=p_endDate and 
	agentid=p_agentId;

	Select a.`status`,count(1) `Count`, ifnull(sum(a.dur),0) TimeSpent from (SELECT  T1.`Status`,
	ifnull(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(T1.`TimeStamp`),
				VARCHARTODATETIME(MIN(T2.`TimeStamp`))),0)  as dur    
	FROM  STATTEMP T1  LEFT JOIN STATTEMP T2  ON T1.agentid = T2.agentid
	AND T2.`TimeStamp` > T1.`TimeStamp`  GROUP BY T1.`Status`, T1.`TimeStamp`) a group by a.`status`;*/
    with cte as (SELECT agentid,`Status`,`TimeStamp` FROM AGT_Agent_StatusTrack WHERE `TimeStamp` >= p_startDate and  `TimeStamp` <=p_endDate and 
	agentid=p_agentId)

	Select a.`status`,count(1) `Count`, ifnull(sum(a.dur),0) TimeSpent from (SELECT  T1.`Status`,
	ifnull(TIMESTAMPDIFF(SECOND,VARCHARTODATETIME(T1.`TimeStamp`),
				VARCHARTODATETIME(MIN(T2.`TimeStamp`))),0)  as dur    
	FROM  cte T1  LEFT JOIN cte T2  ON T1.agentid = T2.agentid
	AND T2.`TimeStamp` > T1.`TimeStamp`  GROUP BY T1.`Status`, T1.`TimeStamp`) a group by a.`status`;
end//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetSupervisorTeams
DELIMITER //
CREATE PROCEDURE `TDM_GetSupervisorTeams`(
p_type varchar(50),
p_teamid varchar(10),
p_avayaLoginID varchar(20))
BEGIN
declare outResult tinyint(1);
call  TDM_GenericAgentHierarchy(p_type,p_teamid,p_avayaLoginID,@outResult);
SELECT 	TeamID,
		TeamName
	FROM AGT_Teams 
	WHERE TeamName in(select  teamname from GenericAgentHierarchyResult);
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetThreshholdConfiguration
DELIMITER //
CREATE PROCEDURE `TDM_GetThreshholdConfiguration`()
BEGIN
	SELECT 
		Team.TeamId,
		Team.TeamName,
		`AuxCodeFrom`,
		`AuxCodeTo`,
		`Threshhold`,
		`isStatusChange`,
		`AllowNotification`,
		`ExcludeSources`
	FROM TDM_ThreshholdConfiguration Threshold 
	INNER JOIN AGT_Teams Team 
	ON Team.TeamID = Threshold.TeamID 
	WHERE Threshold.`IsDeleted` = 0;
	
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_GetUserAccessRole
DELIMITER //
CREATE PROCEDURE `TDM_GetUserAccessRole`(p_userName varchar(50),
	p_shortName varchar(50),
	p_applicationAccesssType varchar(10))
BEGIN
IF(p_applicationAccesssType = 'page')
	THEN	
		SELECT USER_ID, 
		       LAST_CHANGED_BY,
			   LAST_CHANGED_ON, 
		       FUNCTIONALITY,
		       USER_ACCESS
         FROM CMM_USER_MANAGEMENT  
		 WHERE 1=1 AND FUNCTIONALITY like 'DeskManagerUrl%'  
		           AND USER_ID = p_userName;
	
	ELSEIF (p_applicationAccesssType='role')
	THEN
		SELECT DISTINCT (PageName),
			   UserName,
			   ifnull(USER_ACCESS,'Disable') USER_ACCESS 
		FROM (CMM_User_Details  
			  LEFT JOIN AGT_Teams 
			  ON CMM_User_Details.TeamID = AGT_Teams.TeamID)
		LEFT JOIN (CMM_Roles  
				   LEFT JOIN CMM_Role_Pages 
				   ON CMM_Roles.RoleID = CMM_Role_Pages.RoleID)
		ON FIND_IN_SET(CMM_Roles.RoleID, CMM_User_Details.RoleID)
		WHERE PageName like 'DeskManagerUrl%' 
			   AND (UserName = p_userName OR UserName LIKE concat('%',p_shortName,'%'));
	END IF;
END//
DELIMITER ;

-- Dumping structure for table OCM.TDM_ThreshholdConfiguration
CREATE TABLE IF NOT EXISTS `TDM_ThreshholdConfiguration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `TeamId` int NOT NULL,
  `AuxCodeFrom` varchar(250) NOT NULL,
  `AuxCodeTo` varchar(250) NOT NULL,
  `Threshhold` int NOT NULL,
  `CreatedBy` varchar(100) NOT NULL,
  `CreatedDateTime` datetime(3) NOT NULL,
  `ModifiedBy` varchar(100) DEFAULT NULL,
  `ModifiedDateTime` datetime(3) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `IsStatusChange` bit(1) DEFAULT b'0',
  `AllowNotification` bit(1) DEFAULT b'1',
  `ExcludeSources` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.TDM_ThresholdReport
DELIMITER //
CREATE PROCEDURE `TDM_ThresholdReport`(
	p_FromDate VARCHAR(20), 
	p_ToDate VARCHAR(20)
)
BEGIN
	SELECT `AgentName`,`StationId`,`AgentLoginID`,`TeamName`,`OldStatus`,`NewStatus`,
	`OldStatusTimeSpend`,`NotificationType`,`Threshold`, `ChangedBy`,`ChangedType`,DATE_FORMAT(`InsertedDateTime`,'%d/%m/%Y %H:%m:%s') AS InsertedDateTime 
	FROM TDM_Alerts WHERE `InsertedDateTime`>=p_FromDate AND `InsertedDateTime`<=p_ToDate
	ORDER BY `InsertedDateTime` DESC;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.TDM_TimeLineReport
DELIMITER //
CREATE PROCEDURE `TDM_TimeLineReport`(
	IN p_Type VARCHAR(100),
	IN p_FromDate VARCHAR(20),
	IN p_ToDate VARCHAR(20),
	IN p_AgentID VARCHAR(100)
)
BEGIN
    IF(p_Type = 'MAIN')
		THEN
			SELECT distinct AST.AgentID, CONCAT(IFNULL(A.FirstName,''),' ', IFNULL(A.LastName,'')) AS AgentName,IFNULL(T.TeamName,' ') AS TeamName,
			CONCAT(IFNULL(B.FirstName,'NA'),' ', IFNULL(B.LastName,'')) AS SupervisorName
			FROM  AGT_Agent_StatusTrack AST 
			left join AGT_Agent A on A.AvayaLoginID=AST.agentid
			left join AGT_Agent B on A.PrimarySupervisorID=B.ID
			left join AGT_Teams T on A.TeamID=T.TeamID 
			WHERE VARCHARTODATETIME( AST.`TimeStamp`) >= p_FromDate AND (VARCHARTODATETIME( AST.`TimeStamp`)) <=p_ToDate ORDER BY AgentName;
	ELSEIF (p_Type='DRILL')
		THEN
			SELECT distinct AST.AgentID,CONCAT(IFNULL(a.FirstName,''),' ', IFNULL(a.LastName,'')) AS AgentName,AST.StationID,  AST.`Status`,AST.StatusType, FORMATDATETIME(VARCHARTODATETIME(AST.`TimeStamp`),'dd/MM/yyyy HH:mm:ss') as `TimeStamp`   
			FROM  AGT_Agent_StatusTrack AST 
			left join AGT_Agent a on a.AvayaLoginID=AST.agentid
			WHERE VARCHARTODATETIME( AST.`TimeStamp`) >= p_FromDate AND (VARCHARTODATETIME( AST.`TimeStamp`)) <=p_ToDate AND AgentID like p_AgentID
			ORDER BY `TimeStamp` DESC;
    END IF;
END//
DELIMITER ;

-- Dumping structure for table OCM.Template_Node_Details
CREATE TABLE IF NOT EXISTS `Template_Node_Details` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(4000) DEFAULT NULL,
  `Channel` varchar(10) DEFAULT NULL,
  `ConfidenceThreshold` varchar(10) DEFAULT NULL,
  `Product` varchar(50) DEFAULT NULL,
  `IntentIndex` int DEFAULT NULL,
  `Error_Limit_DTMF` int NOT NULL,
  `Error_Limit_Speech` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Temp_Supervisors
CREATE TABLE IF NOT EXISTS `Temp_Supervisors` (
  `UserName` varchar(50) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL,
  `Profile` varchar(50) DEFAULT NULL,
  `AvayaLoginID` varchar(50) DEFAULT NULL,
  `SupLanID` varchar(50) DEFAULT NULL,
  `Status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.Test_CalculateFaxSLA
DELIMITER //
CREATE FUNCTION `Test_CalculateFaxSLA`(
	p_StartDate datetime,
	p_EndDate datetime,
	p_Type varchar(50),
	p_SL varchar(10)
) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	Declare v_sla double; 
	Declare v_startDayOutMins double;  
	Declare v_Day varchar(3);  
	Declare v_endDayOutMins double; 
	Declare v_dayOutMins double;  
	Declare v_slaTS int;  
	Declare v_diff INT;
	
	Declare v_sod datetime(3);  
	Declare v_eod datetime(3);
	Declare v_tStartTime datetime(3);  
	Declare v_tEndTime datetime(3);
	Declare v_nextDate datetime(3);
	Declare v_OpStartTime varchar(10); 
	Declare v_OpEndTime varchar(10);

	Drop temporary table if exists TempTable;
	Create temporary table TempTable 
		(WeeDay varchar(10),
		Start_Time varchar(10),
		End_Time varchar(10),
		VDN_Name varchar(50));

	Drop temporary table if exists HolidayTempTable;
	Create temporary table HolidayTempTable 
		(Holiday varchar(100),
		HolidayStartDate varchar(10),
		HolidayEndDate varchar(10),
		VDN varchar(10));

	set v_sla=0;
	set v_startDayOutMins=0;
	set v_endDayOutMins=0;
	set v_dayOutMins=0;
	set v_nextDate = p_StartDate;

	set v_Day= LEFT(DAYNAME( p_StartDate), 3);

	insert into HolidayTempTable
		SELECT `ANNOUNCED_HOLIDAY`,`Start_Date`,`End_Date`,`VDN` 
		FROM IVR_HOLIDAY_LIST WHERE ltrim(rtrim(VDN))=ltrim(rtrim(p_Type));

	if(exists(select 1 from HolidayTempTable HT where DATE_FORMAT(p_StartDate,'%Y%m%d') >= DATE_FORMAT(convert(HT.HolidayStartDate, datetime),'%Y%m%d') AND DATE_FORMAT(p_StartDate,'%Y%m%d') <= DATE_FORMAT(convert(HT.HolidayEndDate, datetime),'%Y%m%d')))
	then
		if(DATE_FORMAT(p_StartDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d'))
			then 
				set v_sla = 0;
				#goto SLACalculation;
				return (select SLACalculation(p_SL, v_sla));
		else
		 		set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'), '235959'), '%Y-%m-%d %H:%i:%s');
				set v_startDayOutMins = timestampdiff(minute, p_StartDate, v_tEndTime);
			end if;
		
		#goto EndDayCalculation;
		return (select EndDayCalculation(p_SL, p_EndDate, v_tStartTime, v_tEndTime, v_nextDate, v_startDayOutMins, v_endDayOutMins, p_Type));
	end if;

	insert into TempTable
		SELECT `WEEKDAY`,START_TIME,END_TIME,GROUP_NAME FROM IVR_BUSINESS_HOUR WHERE 
		lower(ltrim(rtrim(WEEKDAY)))=lower(ltrim(rtrim(v_Day))) AND ltrim(rtrim(GROUP_NAME))=ltrim(rtrim(p_Type));

	if (not exists (select 1 from TempTable))
	then
		insert into TempTable values(null,'000001','235959',null);
	end if;
	
	select replace(Start_Time,':','') into v_OpStartTime from TEMPTABLE;
	
	select replace(End_Time,':','') into v_OpEndTime from TEMPTABLE;
	
	set v_sod = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'),'000001'), '%Y-%m-%d %H:%i:%s');
	set v_eod = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'),'235959'), '%Y-%m-%d %H:%i:%s');
	
	set v_tStartTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d') , v_OpStartTime), '%Y-%m-%d %H:%i:%s');
	if(v_tStartTime = cast('1753-1-1' as DATETIME)) then
		set v_tStartTime = v_sod;
	end if;
	
	set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d') , v_OpEndTime), '%Y-%m-%d %H:%i:%s');
	if(v_tEndTime = cast('1753-1-1' as DATETIME)) then
		set v_tEndTime = v_eod;
	end if;
	
	if(p_StartDate < v_tStartTime) then
		set v_startDayOutMins = timestampdiff(minute, p_StartDate, v_tStartTime) + timestampdiff(minute, v_tEndTime, v_eod);
	elseif (p_StartDate >= v_tStartTime and p_StartDate <= v_tEndTime) then
		set v_startDayOutMins = timestampdiff(minute, v_tEndTime, v_eod);
	else
		set v_startDayOutMins =timestampdiff(minute, p_StartDate, v_eod);
	end if;
	
	if(p_StartDate >= v_tStartTime and p_EndDate <= v_tEndTime)
		then
			set v_sla=timestampdiff(minute, p_StartDate, p_EndDate);
			#goto SLACalculation;
			return (select SLACalculation(p_SL, v_sla));
		end if;
		
	if(DATE_FORMAT(p_StartDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d'))
		then
			if(p_StartDate > v_tStartTime) then
				set v_tStartTime = p_StartDate;
			end if;
			if(p_EndDate < v_tEndTime) then
				set v_tEndTime = p_EndDate;
			end if;

			set v_sla= TIMESTAMPDIFF(minute,v_tStartTime,v_tEndTime);
			#goto SLACalculation;
			return (select SLACalculation(p_SL, v_sla));
		end if;
		
		Delete from TEMPTABLE;

	set v_sla=TIMESTAMPDIFF(minute,p_StartDate,p_EndDate) - (v_startDayOutMins + v_endDayOutMins + v_dayOutMins);

	Delete from HolidayTempTable;

	
	RETURN (select SLACalculation(p_SL, v_sla));
END//
DELIMITER ;

-- Dumping structure for table OCM.Test_CallbackTimeSlot
CREATE TABLE IF NOT EXISTS `Test_CallbackTimeSlot` (
  `FromDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `FromTime` time DEFAULT NULL,
  `EndTime` time DEFAULT NULL,
  `Monday` int DEFAULT NULL,
  `Tuesday` int DEFAULT NULL,
  `Wednesday` int DEFAULT NULL,
  `Thursday` int DEFAULT NULL,
  `Friday` int DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Test_ChineseChar
CREATE TABLE IF NOT EXISTS `Test_ChineseChar` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ChineChar` varchar(100) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for function OCM.Test_EndDayCalculation
DELIMITER //
CREATE FUNCTION `Test_EndDayCalculation`(

) RETURNS varchar(250) CHARSET utf8mb4
    DETERMINISTIC
BEGIN

	Declare v_Day varchar(3);
	Declare v_sod datetime(3);  
	Declare v_eod datetime(3);
	Declare v_OpStartTime varchar(10); 
	Declare v_OpEndTime varchar(10);
	DECLARE v_tStartTime DATETIME;
 	DECLARE v_tEndTime DATETIME;
 	DECLARE v_nextDate DATETIME;
 	DECLARE v_startDayOutMins DOUBLE;
	DECLARE v_endDayOutMins DOUBLE;
	Declare v_dayOutMins DOUBLE;
	
	DECLARE p_StartDate DATETIME;
	DECLARE p_EndDate DATETIME;
	DECLARE p_Type varchar(50);
	SET p_StartDate='2017-11-25 10:11:47';
	SET p_EndDate='2017-11-27 10:11:06';
	SET p_Type='49011';
	set v_tEndTime = DATE_FORMAT(concat(DATE_FORMAT(p_StartDate,'%Y%m%d'), '235959'), '%Y-%m-%d %H:%i:%s');
	set v_startDayOutMins = timestampdiff(minute, p_StartDate, v_tEndTime);
	set v_nextDate = p_StartDate;
	set v_dayOutMins=0;
	
	set v_Day= LEFT(DAYNAME( p_EndDate), 3);
	
	Drop temporary table if exists TempTable;
	Create temporary table TempTable 
		(WeeDay varchar(10),
		Start_Time varchar(10),
		End_Time varchar(10),
		VDN_Name varchar(50));

	Drop temporary table if exists HolidayTempTable;
	Create temporary table HolidayTempTable 
		(Holiday varchar(100),
		HolidayStartDate varchar(10),
		HolidayEndDate varchar(10),
		VDN varchar(10));
		
	insert into HolidayTempTable
		SELECT ANNOUNCED_HOLIDAY,Start_Date,End_Date,VDN 
		FROM IVR_HOLIDAY_LIST WHERE ltrim(rtrim(VDN))=ltrim(rtrim(p_Type));
		
	whileloop: while(1=1)
		do
			set v_nextDate = TIMESTAMPADD(day,1,v_nextDate);

			if(DATE_FORMAT(v_nextDate,'%Y%m%d') = DATE_FORMAT(p_EndDate,'%Y%m%d')) then
				leave whileloop;
			end if;

			set v_Day= LEFT(DAYNAME( v_nextDate), 3);

			if(exists(select 1 from HolidayTempTable HT where DATE_FORMAT(v_nextDate,'%Y%m%d') >= DATE_FORMAT(convert(HT.HolidayStartDate, datetime),'%Y%m%d') and DATE_FORMAT(v_nextDate,'%Y%m%d') <= DATE_FORMAT(convert(HT.HolidayEndDate, datetime),'%Y%m%d')))
			then 
				set v_dayOutMins = v_dayOutMins + 24 * 60;
				#goto NextDayCalculation;
				RETURN (SELECT NextDayCalculation(p_EndDate,v_tStartTime,v_tEndTime,v_nextDate,	v_startDayOutMins,v_endDayOutMins));#, p_Type));
			end if;

			insert into TempTable
			SELECT `WEEKDAY`,START_TIME,END_TIME,GROUP_NAME FROM IVR_BUSINESS_HOUR WHERE 
			lower(ltrim(rtrim(WEEKDAY)))=lower(ltrim(rtrim(v_Day))) AND ltrim(rtrim(GROUP_NAME))=ltrim(rtrim(p_Type));

			if (not exists (select 1 from TempTable))
			then
				insert into TempTable values(null,'000001','235959',null);
			end if;

			select replace(Start_Time,':','') into v_OpStartTime from TEMPTABLE;
		
			select replace(End_Time,':','') into v_OpEndTime from TEMPTABLE;

			set v_sod= DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d'),'000001'),'%Y-%m-%d %H:%i:%s');
			set v_eod= DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d'),'235959'),'%Y-%m-%d %H:%i:%s');

			set v_tStartTime = DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d') , v_OpStartTime),'%Y-%m-%d %H:%i:%s');
			if(v_tStartTime =  cast('1753-1-1' as DATETIME)) then
				set v_tStartTime = v_sod;
			end if;

			set v_tEndTime = DATE_FORMAT(CONCAT(DATE_FORMAT(v_nextDate,'%Y%m%d') , v_OpEndTime),'%Y-%m-%d %H:%i:%s');
			if(v_tEndTime = cast('1753-1-1' as DATETIME)) then
				set v_tEndTime = v_eod;
			end if;

			set v_dayOutMins = v_dayOutMins + (24 * 60 - TIMESTAMPDIFF(minute,v_tStartTime,v_tEndTime));

			Delete from TEMPTABLE;
		end while whileloop;
	
	Delete from HolidayTempTable;

	return v_dayOutMins;
	
	
END//
DELIMITER ;

-- Dumping structure for table OCM.tetherfi_customer_survey
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey` (
  `surveyid` bigint NOT NULL AUTO_INCREMENT,
  `sessionid` varchar(50) NOT NULL,
  `agentid` varchar(50) NOT NULL,
  `cif` varchar(50) DEFAULT '',
  `srcchannel` varchar(50) NOT NULL,
  `destchannel` varchar(50) NOT NULL,
  `comment` varchar(250) DEFAULT '',
  `createddatetime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `intent` varchar(50) NOT NULL,
  `skill` varchar(50) NOT NULL,
  `language` varchar(50) DEFAULT '',
  `location` varchar(50) DEFAULT '',
  `interactiontime` int DEFAULT '0',
  `quequetime` int DEFAULT '0',
  `otherdata` varchar(2000) DEFAULT '',
  PRIMARY KEY (`surveyid`),
  KEY `IX_N_tetherfi_customer_survey_createddatetime` (`createddatetime`),
  KEY `IX_tetherfi_customer_survey_agentid` (`agentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_attributes
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_attributes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `surveyruleid` bigint NOT NULL,
  `attributes` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_destinations
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_destinations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `destinationchannel` varchar(50) NOT NULL,
  `destinationvalue` varchar(50) NOT NULL,
  `surveyruleid` bigint NOT NULL,
  `priority` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_response
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_response` (
  `responseid` bigint NOT NULL AUTO_INCREMENT,
  `surveyid` bigint NOT NULL,
  `surveytype` varchar(20) NOT NULL COMMENT 'survery templates are CSAT, CES, NPS and Long_Form',
  `questiontype` varchar(20) NOT NULL,
  `questiontext` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `responsedatetime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`responseid`),
  KEY `IX_tetherfi_customer_survey_response_responsedatetime` (`responsedatetime`),
  KEY `IX_tetherfi_customer_survey_response_surveyid` (`surveyid`),
  CONSTRAINT `FK_tetherfi_customer_survey_response_tetherfi_customer_survey` FOREIGN KEY (`surveyid`) REFERENCES `tetherfi_customer_survey` (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_response_value
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_response_value` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `responseid` bigint NOT NULL,
  `responsetext` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT 'response text will be stored here',
  `responsevalue` int NOT NULL DEFAULT '0' COMMENT 'numeric response value will be stored here',
  PRIMARY KEY (`id`),
  KEY `IX_tetherfi_customer_survey_response_value_responseid` (`responseid`),
  CONSTRAINT `FK_tetherfi_customer_survey_res_val_tetherfi_customer_survey_res` FOREIGN KEY (`responseid`) REFERENCES `tetherfi_customer_survey_response` (`responseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_rules
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sourcechannel` varchar(20) NOT NULL,
  `intractionendedby` varchar(30) DEFAULT NULL,
  `intent` varchar(50) DEFAULT NULL,
  `recurrence` int DEFAULT NULL,
  `fromtime` time DEFAULT NULL,
  `totime` time DEFAULT NULL,
  `offersurvey` bit(1) DEFAULT NULL,
  `lastchangedby` varchar(50) DEFAULT NULL,
  `lastchangedon` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tetherfi_customer_survey_status
CREATE TABLE IF NOT EXISTS `tetherfi_customer_survey_status` (
  `statusid` bigint NOT NULL AUTO_INCREMENT,
  `surveyid` bigint NOT NULL,
  `surveystatus` int NOT NULL DEFAULT '0' COMMENT 'status column 0=open, 1=closed ,2=failed,4=noresponse',
  `statusdatetime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`statusid`),
  KEY `IX_tetherfi_customer_survey_status_statusdatetime` (`statusdatetime`),
  KEY `IX_tetherfi_customer_survey_status_surveyid` (`surveyid`),
  CONSTRAINT `FK_tetherfi_customer_survey_status_tetherfi_customer_survey` FOREIGN KEY (`surveyid`) REFERENCES `tetherfi_customer_survey` (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_agent_attributes
CREATE TABLE IF NOT EXISTS `tmac_agent_attributes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `agentid` varchar(50) NOT NULL,
  `attrid` bigint DEFAULT NULL,
  `attrlevel` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_Agent_Skills
CREATE TABLE IF NOT EXISTS `TMAC_Agent_Skills` (
  `AgentID` varchar(50) DEFAULT NULL,
  `SkillID` varchar(50) DEFAULT NULL,
  `SkillLevel` int DEFAULT NULL,
  `endtime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_attributes
CREATE TABLE IF NOT EXISTS `tmac_attributes` (
  `attrid` bigint NOT NULL AUTO_INCREMENT,
  `attrname` varchar(50) NOT NULL,
  `attrcatergory` varchar(50) NOT NULL,
  `attrenabled` bit(1) NOT NULL,
  `attrservicelevel` int DEFAULT NULL,
  `attrtimeout` int DEFAULT NULL,
  `attrpriority` int DEFAULT NULL,
  `lastchangedon` datetime(3) DEFAULT NULL,
  `lastchangedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`attrid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_AuthSessions
CREATE TABLE IF NOT EXISTS `TMAC_AuthSessions` (
  `AuthCode` varchar(50) DEFAULT NULL,
  `ConnectedTmacServerName` varchar(50) DEFAULT NULL,
  `LanId` varchar(50) DEFAULT NULL,
  `AgentId` varchar(50) DEFAULT NULL,
  `StationId` varchar(50) DEFAULT NULL,
  `RevalidateCount` int DEFAULT NULL,
  `ConnectedProxy` varchar(50) DEFAULT NULL,
  `AgentSessionKey` varchar(50) DEFAULT NULL,
  `CreatedTime` varchar(50) DEFAULT NULL,
  `IsCalledFromProxy` int DEFAULT NULL,
  `LastCalledTimeFromProxy` varchar(50) DEFAULT NULL,
  `IsAgentLoggedIn` int DEFAULT NULL,
  `AgentLoggedInTime` varchar(50) DEFAULT NULL,
  `IsAgentLoggedOut` int DEFAULT NULL,
  `AgentLoggedOutTime` varchar(50) DEFAULT NULL,
  `ProxyUrlList` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_AuthSessions_History
CREATE TABLE IF NOT EXISTS `TMAC_AuthSessions_History` (
  `AuthCode` varchar(50) DEFAULT NULL,
  `ConnectedTmacServerName` varchar(50) DEFAULT NULL,
  `LanId` varchar(50) DEFAULT NULL,
  `AgentId` varchar(50) DEFAULT NULL,
  `StationId` varchar(50) DEFAULT NULL,
  `RevalidateCount` int DEFAULT NULL,
  `ConnectedProxy` varchar(50) DEFAULT NULL,
  `AgentSessionKey` varchar(50) DEFAULT NULL,
  `CreatedTime` varchar(50) DEFAULT NULL,
  `IsCalledFromProxy` int DEFAULT NULL,
  `LastCalledTimeFromProxy` varchar(50) DEFAULT NULL,
  `IsAgentLoggedIn` int DEFAULT NULL,
  `AgentLoggedInTime` varchar(50) DEFAULT NULL,
  `IsAgentLoggedOut` int DEFAULT NULL,
  `AgentLoggedOutTime` varchar(50) DEFAULT NULL,
  `ProxyUrlList` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_H.Agent
CREATE TABLE IF NOT EXISTS `TMAC_H.Agent` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `AgentID` int NOT NULL,
  `AgentName` varchar(50) DEFAULT NULL,
  `SwitchName` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Interval` varchar(50) DEFAULT NULL,
  `AcdCalls` int DEFAULT NULL,
  `AvgTalkTime` varchar(50) DEFAULT NULL,
  `TotalAfterCall` varchar(50) DEFAULT NULL,
  `TotalAvailCall` varchar(50) DEFAULT NULL,
  `TotalAux` varchar(50) DEFAULT NULL,
  `ExtnCalls` int DEFAULT NULL,
  `AvgExtnTime` varchar(50) DEFAULT NULL,
  `TotalTimeStaffed` varchar(50) DEFAULT NULL,
  `TotalHoldTime` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_H.Skill
CREATE TABLE IF NOT EXISTS `TMAC_H.Skill` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SwitchName` varchar(50) DEFAULT NULL,
  `Skill` int NOT NULL,
  `SkillName` varchar(50) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Interval` varchar(50) DEFAULT NULL,
  `AcdCalls` int DEFAULT NULL,
  `AbanCalls` int DEFAULT NULL,
  `AvgSpeedAns` varchar(50) DEFAULT NULL,
  `AvgAbandTime` varchar(50) DEFAULT NULL,
  `AvgTalkTime` varchar(50) DEFAULT NULL,
  `AvgStaff` decimal(8,2) DEFAULT NULL,
  `TotalAfterCall` varchar(50) DEFAULT NULL,
  `FlowIn` int DEFAULT NULL,
  `FlowOut` int DEFAULT NULL,
  `TotalAux` varchar(50) DEFAULT NULL,
  `AccServiceLevel` int DEFAULT NULL,
  `PercentageServiceLevel` int DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_Interactions_Audit
CREATE TABLE IF NOT EXISTS `TMAC_Interactions_Audit` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `SessionId` varchar(50) DEFAULT NULL,
  `AuditType` varchar(20) NOT NULL,
  `RequestStatus` varchar(20) NOT NULL,
  `RequestBy` varchar(100) NOT NULL,
  `RequestDateTime` varchar(14) DEFAULT NULL,
  `RequestComment` varchar(1000) DEFAULT NULL,
  `AuditBy` varchar(100) DEFAULT NULL,
  `AuditDateTime` varchar(14) DEFAULT NULL,
  `AuditComment` varchar(1000) DEFAULT NULL,
  `OtherData` varchar(2000) DEFAULT NULL,
  `ResponseMessage` varchar(255) DEFAULT NULL,
  `ResponseResult` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TMAC_Interactions_Audit` (`AuditType`,`RequestDateTime`,`AuditDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_InteractionUserData
CREATE TABLE IF NOT EXISTS `TMAC_InteractionUserData` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionId` varchar(50) DEFAULT NULL,
  `Salutation` varchar(10) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `Nric` varchar(20) DEFAULT NULL,
  `CIF` varchar(30) DEFAULT NULL,
  `MobileNumber` varchar(20) DEFAULT NULL,
  `MobileNumber2` varchar(20) DEFAULT NULL,
  `EmailId` varchar(150) DEFAULT NULL,
  `FacebookId` varchar(150) DEFAULT NULL,
  `ChatId` varchar(150) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `PhoneNumber2` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `PK_TMAC_InteractionUserData_SessionID` (`SessionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_interaction_deflection
CREATE TABLE IF NOT EXISTS `tmac_interaction_deflection` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `initiatedby` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sourcechannel` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sourcesessionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `deflectintent` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `createdat` datetime(3) NOT NULL,
  `destinationchannel` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `destinationsubchannel` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `customercontact` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contactinteractionsessionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `scheduledata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `expireat` datetime(3) DEFAULT NULL,
  `fallbackskillid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `deflectstatus` int NOT NULL,
  `agentcomment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `otherdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `IX_tmac_interaction_deflection_createdat` (`createdat`) USING BTREE,
  KEY `IX_tmac_interaction_deflection_customercontact` (`customercontact`) USING BTREE,
  KEY `IX_tmac_interaction_deflection_initiatedby` (`initiatedby`) USING BTREE,
  KEY `IX_tmac_interaction_deflection_sourcesessionid` (`sourcesessionid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_interaction_deflection_usage
CREATE TABLE IF NOT EXISTS `tmac_interaction_deflection_usage` (
  `deflectid` char(36) NOT NULL,
  `sessionid` varchar(50) DEFAULT NULL,
  `usagetime` datetime(3) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL,
  UNIQUE KEY `UK_tmac_interaction_deflection_usage_defid_sesid_time` (`deflectid`,`sessionid`,`usagetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_POM_DNC
CREATE TABLE IF NOT EXISTS `TMAC_POM_DNC` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NRIC` varchar(50) DEFAULT NULL,
  `ContactListName` varchar(50) DEFAULT NULL,
  `Mode` varchar(50) DEFAULT NULL,
  `CreatedDate` datetime(3) DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `CreatorId` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_TMAC_POM_DNC_CreatedDateTime` (`CreatedDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_POM_InteractionHistory
CREATE TABLE IF NOT EXISTS `TMAC_POM_InteractionHistory` (
  `EventID` int NOT NULL AUTO_INCREMENT,
  `AgentId` varchar(50) DEFAULT NULL,
  `SessionID` varchar(50) DEFAULT NULL,
  `CallType` varchar(50) DEFAULT NULL,
  `ContactID` varchar(50) DEFAULT NULL,
  `Direction` varchar(50) DEFAULT NULL,
  `SkillName` varchar(50) DEFAULT NULL,
  `InteractionID` varchar(50) DEFAULT NULL,
  `InteractionDateTime` varchar(50) DEFAULT NULL,
  `CampaignID` varchar(50) DEFAULT NULL,
  `CampaignName` varchar(50) DEFAULT NULL,
  `CampaignDateTime` varchar(50) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) DEFAULT NULL,
  `CustomerPhone1` varchar(50) DEFAULT NULL,
  `CustomerPhone2` varchar(50) DEFAULT NULL,
  `CustomerPhone3` varchar(50) DEFAULT NULL,
  `CustomerPhone4` varchar(50) DEFAULT NULL,
  `CompletionReasonName` varchar(50) DEFAULT NULL,
  `IncomingCallJSONData` longtext,
  `PomCustomerFieldsJSONData` longtext,
  `CreatedDateTime` varchar(50) DEFAULT NULL,
  `CompletionCode` varchar(50) DEFAULT NULL,
  `ConnectionHandle` varchar(30) DEFAULT NULL,
  `UnCallableNumbers` varchar(200) DEFAULT NULL,
  `DialedNumber` varchar(20) DEFAULT NULL,
  `CIN` varchar(20) DEFAULT NULL,
  `UserContactID` varchar(50) DEFAULT NULL,
  KEY `IX_N_TMAC_POM_InteractionHistory_AgentID` (`AgentId`),
  KEY `IX_N_TMAC_POM_InteractionHistory_Compaign` (`CampaignID`,`CampaignName`),
  KEY `IX_N_TMAC_POM_InteractionHistory_CompletionReasonName` (`CompletionReasonName`,`CompletionCode`),
  KEY `IX_N_TMAC_POM_InteractionHistory_InteractionDateTime` (`InteractionDateTime`),
  KEY `IX_N_TMAC_POM_InteractionHistory_SessionID` (`SessionID`),
  KEY `EventID` (`EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_SentimentAnalysis
CREATE TABLE IF NOT EXISTS `TMAC_SentimentAnalysis` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SessionID` varchar(50) NOT NULL,
  `AgentID` varchar(50) NOT NULL,
  `OverallSentiment` varchar(50) NOT NULL,
  `PositiveScore` int NOT NULL,
  `NegativeScore` int NOT NULL,
  `NeutralScore` int NOT NULL,
  `Sentence` longtext NOT NULL,
  `JsonData` longtext NOT NULL,
  `SentimentPosition` longtext NOT NULL,
  `DateTime` varchar(50) NOT NULL,
  PRIMARY KEY (`SessionID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_Skills
CREATE TABLE IF NOT EXISTS `TMAC_Skills` (
  `SkillID` varchar(50) DEFAULT NULL,
  `SkillExtension` varchar(50) DEFAULT NULL,
  `SkillName` varchar(50) DEFAULT NULL,
  `Enabled` int DEFAULT NULL,
  `AcceptableServiceLevel` int DEFAULT NULL,
  `Timeout` int DEFAULT NULL,
  `Priority` int DEFAULT NULL,
  `AcceptableSLThreshold` int DEFAULT NULL,
  `QueuePositionThreshold` int DEFAULT NULL,
  `FallbackSkillStrategy` int DEFAULT NULL,
  `FallbackSkill` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_skill_scheduler
CREATE TABLE IF NOT EXISTS `tmac_skill_scheduler` (
  `templateid` bigint NOT NULL,
  `agentid` varchar(100) DEFAULT NULL,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_skill_sla
CREATE TABLE IF NOT EXISTS `tmac_skill_sla` (
  `slaid` varchar(10) NOT NULL,
  `skillid` varchar(50) NOT NULL,
  `slaname` varchar(50) NOT NULL,
  `slavalue` int DEFAULT NULL,
  `isactive` tinyint(1) NOT NULL,
  PRIMARY KEY (`slaid`,`skillid`),
  KEY `IX_tmac_skill_sla_isactive_slaname` (`isactive`,`slaname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_skill_template
CREATE TABLE IF NOT EXISTS `tmac_skill_template` (
  `templateid` bigint NOT NULL AUTO_INCREMENT,
  `templatename` varchar(50) DEFAULT NULL,
  `orgunit` int DEFAULT NULL,
  `lastchangedby` varchar(50) DEFAULT NULL,
  `lastchangedon` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_skill_template_list
CREATE TABLE IF NOT EXISTS `tmac_skill_template_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `skillid` int NOT NULL,
  `skilllevel` int NOT NULL,
  `channel` varchar(20) DEFAULT NULL,
  `templateid` bigint NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template
CREATE TABLE IF NOT EXISTS `tmac_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `theme` varchar(50) NOT NULL,
  `orgid` int NOT NULL,
  `lastchangedby` varchar(50) DEFAULT NULL,
  `lastchangedon` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_access
CREATE TABLE IF NOT EXISTS `tmac_template_access` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `templateid` bigint NOT NULL,
  `orgid` int DEFAULT NULL,
  KEY `id` (`id`),
  KEY `templateid` (`templateid`),
  CONSTRAINT `tmac_template_access_ibfk_1` FOREIGN KEY (`templateid`) REFERENCES `tmac_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_auxcodes
CREATE TABLE IF NOT EXISTS `tmac_template_auxcodes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `templateid` bigint NOT NULL,
  `auxcode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_feature
CREATE TABLE IF NOT EXISTS `tmac_template_feature` (
  `templateid` bigint NOT NULL,
  `feature` varchar(50) NOT NULL,
  `enable` tinyint NOT NULL DEFAULT '0',
  `featurevalue` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`templateid`,`feature`),
  KEY `IX_tmac_template_feature` (`templateid`),
  CONSTRAINT `FK_tmac_template_feature_tmac_template` FOREIGN KEY (`templateid`) REFERENCES `tmac_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_ophours
CREATE TABLE IF NOT EXISTS `tmac_template_ophours` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `weekday` varchar(10) NOT NULL,
  `fromtime` time NOT NULL,
  `totime` time NOT NULL,
  `templateid` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_screens
CREATE TABLE IF NOT EXISTS `tmac_template_screens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `templateid` bigint NOT NULL,
  `screen` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.tmac_template_screen_widgets
CREATE TABLE IF NOT EXISTS `tmac_template_screen_widgets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `screenid` bigint NOT NULL,
  `widget` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.TMAC_WB_GetFaxSentItems
DELIMITER //
CREATE PROCEDURE `TMAC_WB_GetFaxSentItems`(p_DNIS varchar(20), p_startTime varchar(20), p_endTime varchar(20), p_agentId varchar(30))
BEGIN
  DECLARE v_Query longtext;
  SET v_Query = CONCAT('SELECT DNIS, RecipientNumber, FileName, SentDateTime, Result FROM Fax_Sent_Details WHERE 1 = 1 AND ReportDateTime >= ''' , p_startTime , ''' AND ReportDateTime <= ''' , p_endTime , '''');
  /* PRINT v_Query */
  IF (p_DNIS != '')
  THEN
    SET v_Query = CONCAT(v_Query , ' AND DNIS = ''' , p_DNIS , '''');
  END IF;
  IF (p_agentId != '')
  THEN
    SET v_Query = CONCAT(v_Query , ' AND SENTBY = ''' , p_agentId , '''');
  END IF;
  SET @stmt_str =  v_Query;
  PREPARE stmt FROM @stmt_str;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END//
DELIMITER ;

-- Dumping structure for table OCM.TMAC_WebRTCCommStats
CREATE TABLE IF NOT EXISTS `TMAC_WebRTCCommStats` (
  `Id` char(38) NOT NULL DEFAULT (uuid()),
  `SessionId` varchar(30) DEFAULT NULL,
  `Timestamp` datetime(3) NOT NULL,
  `Source` varchar(10) NOT NULL,
  `DataType` varchar(15) NOT NULL,
  `Data` longtext NOT NULL,
  `OtherData` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_WhatsAppData
CREATE TABLE IF NOT EXISTS `TMAC_WhatsAppData` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `Agent` varchar(500) DEFAULT NULL,
  `ChatName` varchar(500) DEFAULT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `MessageType` varchar(50) DEFAULT NULL,
  `DateTime` varchar(50) DEFAULT NULL,
  `Message` varchar(2000) DEFAULT NULL,
  `Direction` varchar(50) DEFAULT NULL,
  `ReportDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_WorkQueue
CREATE TABLE IF NOT EXISTS `TMAC_WorkQueue` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `GlobalKey` varchar(50) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `ItemID` varchar(50) DEFAULT NULL,
  `CreateDate` varchar(8) DEFAULT NULL,
  `CreatedTime` varchar(6) DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `Data` varchar(8000) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `RouteDate` varchar(8) DEFAULT NULL,
  `RouteTime` varchar(6) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Reason` varchar(50) DEFAULT NULL,
  `SubChannel` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) DEFAULT NULL,
  `RouteOptions` varchar(4000) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMAC_WorkQueueHistory
CREATE TABLE IF NOT EXISTS `TMAC_WorkQueueHistory` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `GlobalKey` varchar(50) DEFAULT NULL,
  `Channel` varchar(50) DEFAULT NULL,
  `Skill` varchar(50) DEFAULT NULL,
  `ItemID` varchar(50) DEFAULT NULL,
  `CreateDate` varchar(8) DEFAULT NULL,
  `CreatedTime` varchar(6) DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `Data` varchar(8000) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `RouteDate` varchar(8) DEFAULT NULL,
  `RouteTime` varchar(6) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Reason` varchar(50) DEFAULT NULL,
  `SubChannel` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) DEFAULT NULL,
  `RouteOptions` varchar(4000) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMC_AccessMatrix
CREATE TABLE IF NOT EXISTS `TMC_AccessMatrix` (
  `ID` bigint NOT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `ModuleName` varchar(50) DEFAULT NULL,
  `Access` bit(1) DEFAULT NULL,
  `Features` varchar(2500) DEFAULT NULL,
  `LastChangedOn` varchar(30) DEFAULT NULL,
  `LastChangedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMC_STATS_SESSIONS
CREATE TABLE IF NOT EXISTS `TMC_STATS_SESSIONS` (
  `SessionId` varchar(50) NOT NULL,
  `Server` smallint NOT NULL AUTO_INCREMENT,
  `TimeStamp` datetime(3) NOT NULL,
  PRIMARY KEY (`SessionId`),
  KEY `IX_TMC_STATS_SESSIONS` (`TimeStamp`),
  KEY `Server` (`Server`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMC_TAGS_MASTER
CREATE TABLE IF NOT EXISTS `TMC_TAGS_MASTER` (
  `TagId` int NOT NULL AUTO_INCREMENT,
  `TagName` varchar(50) NOT NULL,
  PRIMARY KEY (`TagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TMC_TAG_SESSION_MAP
CREATE TABLE IF NOT EXISTS `TMC_TAG_SESSION_MAP` (
  `Id` bigint NOT NULL,
  `TagId` int NOT NULL,
  `TagValue` varchar(50) NOT NULL,
  `SessionId` varchar(50) NOT NULL,
  `TimeStamp` datetime(3) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TMC_TAG_SESSION_MAP` (`TimeStamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TPPVA_Interaction_State
CREATE TABLE IF NOT EXISTS `TPPVA_Interaction_State` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `SessionId` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `StatusTime` varchar(17) DEFAULT NULL,
  `Data` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_action_details
CREATE TABLE IF NOT EXISTS `trs_action_details` (
  `ActionId` int NOT NULL AUTO_INCREMENT,
  `EventID` bigint NOT NULL,
  `ActionTaken` varchar(500) DEFAULT NULL,
  `ActionData` varchar(500) DEFAULT NULL,
  KEY `ActionId` (`ActionId`),
  KEY `FK_trs_violation_trs_action_details` (`EventID`),
  CONSTRAINT `FK_trs_violation_trs_action_details` FOREIGN KEY (`EventID`) REFERENCES `trs_violation` (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_analytic_events
CREATE TABLE IF NOT EXISTS `trs_analytic_events` (
  `analyticid` varchar(50) NOT NULL,
  `eventid` int NOT NULL,
  `timestamp` datetime(3) NOT NULL,
  `agentid` varchar(200) NOT NULL,
  `eventdata` varchar(200) NOT NULL,
  `eventsource` smallint NOT NULL,
  PRIMARY KEY (`analyticid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_analytic_events_master
CREATE TABLE IF NOT EXISTS `trs_analytic_events_master` (
  `eventid` int NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_auto_update_status
CREATE TABLE IF NOT EXISTS `trs_auto_update_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agentid` varchar(50) DEFAULT NULL,
  `currentversion` varchar(50) DEFAULT NULL,
  `newversion` varchar(50) DEFAULT NULL,
  `dateofdownload` varchar(50) DEFAULT NULL,
  `dateofupdate` varchar(50) DEFAULT NULL,
  `filenames` longtext,
  `status` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_dpa_active_processes
CREATE TABLE IF NOT EXISTS `trs_dpa_active_processes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agentid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `processid` int NOT NULL,
  `eventkind` smallint NOT NULL,
  `timestamp` datetime(3) NOT NULL,
  `processname` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title` varchar(510) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `activetime` decimal(18,0) NOT NULL,
  `updatedtimestamp` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_event_type
CREATE TABLE IF NOT EXISTS `trs_event_type` (
  `eventtypeid` int NOT NULL,
  `eventtypename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`eventtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_rejected_violation
CREATE TABLE IF NOT EXISTS `trs_rejected_violation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `eventid` bigint NOT NULL,
  `labelname` varchar(100) NOT NULL,
  `boundingboxes` varchar(50) NOT NULL,
  `imageupload` tinyint NOT NULL DEFAULT '1',
  `rejectioncomment` varchar(250) DEFAULT NULL,
  `rejectedby` varchar(50) NOT NULL,
  `rejecteddatetime` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_session_connection
CREATE TABLE IF NOT EXISTS `trs_session_connection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agentid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `teamid` int NOT NULL,
  `sessionid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `logininstanceid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `timestamp` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_session_violation
CREATE TABLE IF NOT EXISTS `trs_session_violation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `violationid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `logininstanceid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `timestamp` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_terms_and_condition
CREATE TABLE IF NOT EXISTS `trs_terms_and_condition` (
  `termsid` int NOT NULL AUTO_INCREMENT,
  `agentlanid` varchar(50) NOT NULL,
  `agentsystemname` varchar(50) NOT NULL,
  `orgname` varchar(200) NOT NULL,
  `termstype` int NOT NULL,
  `termsandconditions` longtext NOT NULL,
  `agreed` tinyint NOT NULL,
  `agreedutcdatetime` datetime(3) NOT NULL,
  `agentipaddress` varchar(50) NOT NULL,
  `licenseversion` varchar(50) NOT NULL,
  `termsrevoked` tinyint NOT NULL,
  PRIMARY KEY (`termsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.trs_violation
CREATE TABLE IF NOT EXISTS `trs_violation` (
  `eventid` bigint NOT NULL AUTO_INCREMENT,
  `eventname` varchar(100) NOT NULL,
  `agentid` varchar(200) NOT NULL,
  `agentstatus` varchar(100) NOT NULL,
  `threshold` int NOT NULL,
  `actionsummary` longtext,
  `campic` varchar(255) DEFAULT NULL,
  `screenshot` varchar(255) DEFAULT NULL,
  `screenvideo` varchar(255) DEFAULT NULL,
  `createddatetime` datetime(3) NOT NULL,
  `qrvideourl` varchar(200) DEFAULT NULL,
  `violationid` varchar(50) DEFAULT NULL,
  `eventtypeid` int NOT NULL,
  `buildversion` varchar(10) DEFAULT NULL,
  `modelversion` varchar(10) DEFAULT NULL,
  `boundingboxes` longtext,
  `isrejected` tinyint DEFAULT '0',
  `camvideo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`eventid`),
  KEY `FK_trs_violation_trs_event_type` (`eventtypeid`),
  CONSTRAINT `FK_trs_violation_trs_event_type` FOREIGN KEY (`eventtypeid`) REFERENCES `trs_event_type` (`eventtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TRS_ViolationSummary
CREATE TABLE IF NOT EXISTS `TRS_ViolationSummary` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AgentLanId` varchar(50) DEFAULT NULL,
  `ViolationName` varchar(50) DEFAULT NULL,
  `TotalViolationCount` varchar(50) DEFAULT NULL,
  `ModelVersion` varchar(50) DEFAULT NULL,
  `BuildVersion` varchar(50) DEFAULT NULL,
  `UpdatedDateTime` datetime(3) DEFAULT NULL,
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TSIP_CallData
CREATE TABLE IF NOT EXISTS `TSIP_CallData` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `SessionId` varchar(50) DEFAULT NULL,
  `Ucid` varchar(50) DEFAULT NULL,
  `SipCallSessionId` varchar(5) DEFAULT NULL,
  `CalledDevice` varchar(20) DEFAULT NULL,
  `CallingDevice` varchar(20) DEFAULT NULL,
  `CallStartTime` varchar(14) DEFAULT NULL,
  `FromVdnName` varchar(50) DEFAULT NULL,
  `DestinationVdnNumber` varchar(50) DEFAULT NULL,
  `Queued` int DEFAULT NULL,
  `QueuedTime` varchar(14) DEFAULT NULL,
  `QueueType` varchar(20) DEFAULT NULL,
  `QueueValue` varchar(50) DEFAULT NULL,
  `RouteToVdnStatus` varchar(20) DEFAULT NULL,
  `RouteToVdnTime` varchar(14) DEFAULT NULL,
  `Pulled` int DEFAULT NULL,
  `PulledBy` varchar(20) DEFAULT NULL,
  `PulledTime` varchar(14) DEFAULT NULL,
  `Abandoned` int DEFAULT NULL,
  `AbandonedTime` varchar(14) DEFAULT NULL,
  `Agent` varchar(50) DEFAULT NULL,
  `AgentStation` varchar(50) DEFAULT NULL,
  `CallStatusAtAgent` varchar(50) DEFAULT NULL,
  `RouteToAgentTime` varchar(14) DEFAULT NULL,
  `DisconnectedBy` varchar(50) DEFAULT NULL,
  `DisconnectTime` varchar(14) DEFAULT NULL,
  `StateusList` varchar(500) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Twitter_Data
CREATE TABLE IF NOT EXISTS `Twitter_Data` (
  `CreationDateTime` datetime(3) DEFAULT NULL,
  `TwitterDateTime` datetime(3) DEFAULT NULL,
  `Id` int NOT NULL AUTO_INCREMENT,
  `ItemId` varchar(20) DEFAULT NULL,
  `Channel` varchar(10) DEFAULT NULL,
  `SenderId` varchar(50) DEFAULT NULL,
  `ReceiverId` varchar(50) DEFAULT NULL,
  `Direction` varchar(3) DEFAULT NULL,
  `JsonData` longtext,
  `CacheJsonData` longtext,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TXT_Formats
CREATE TABLE IF NOT EXISTS `TXT_Formats` (
  `FormatString` varchar(500) NOT NULL,
  `InputTag` varchar(200) DEFAULT NULL,
  `FSUniquePrefix` varchar(20) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`FormatString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TXT_SMSQueue
CREATE TABLE IF NOT EXISTS `TXT_SMSQueue` (
  `MessageID` int NOT NULL AUTO_INCREMENT,
  `CLID` varchar(40) DEFAULT NULL,
  `Text` varchar(500) DEFAULT NULL,
  `ShortCode` varchar(40) DEFAULT NULL,
  `Time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`MessageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TXT_Strings
CREATE TABLE IF NOT EXISTS `TXT_Strings` (
  `Id` varchar(80) NOT NULL,
  `String` varchar(1000) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(100) DEFAULT NULL,
  `AvailableVariables` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.TXT_Synonyms
CREATE TABLE IF NOT EXISTS `TXT_Synonyms` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Intent` varchar(100) DEFAULT NULL,
  `Language` varchar(20) DEFAULT 'English',
  `Synonym` varchar(500) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  `Escalated` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.UPDATE_AbandonACD_Calls
DELIMITER //
CREATE PROCEDURE `UPDATE_AbandonACD_Calls`(
p_ID bigint, 
p_UCID VARCHAR(50),
p_CallRoutedCSQ VARCHAR(50),
p_CallSkill varchar(10),
p_AbandonDateTime varchar(14)
)
BEGIN	

IF NOT EXISTS(select 1 from AGT_AbandonACD_Calls where UCID=p_UCID)
	THEN
	
	INSERT INTO AGT_AbandonACD_Calls
	(`ID`, 
`UCID`,
`CallRoutedCSQ`,
`CallSkill`,
`AbandonDateTime`
)

VALUES
(p_ID,p_UCID,p_CallRoutedCSQ,p_CallSkill,p_AbandonDateTime
);
END IF;

END//
DELIMITER ;

-- Dumping structure for procedure OCM.UPDATE_CALLBACK_DATA
DELIMITER //
CREATE PROCEDURE `UPDATE_CALLBACK_DATA`(
p_SERVERID INT,
p_UCID VARCHAR(100),
p_DNIS_NAME VARCHAR(50),
p_CALLERID VARCHAR(20),
p_PREFFERRED_CONTACTNO VARCHAR(20),
p_TYPE_OF_INQUIRY VARCHAR(50),
p_TYPE VARCHAR(50),
p_REQUEST_DATE VARCHAR(10),
p_REQUEST_TIME VARCHAR(10),
p_QUEUE_WAIT_TIME VARCHAR(10),
p_CALLBACK_STATUS VARCHAR(10)
)
BEGIN
IF NOT EXISTS(SELECT 1 FROM IVR_Callback_Requests WHERE UCID = p_UCID )

THEN
INSERT INTO IVR_Callback_Requests
           (
		   `SERVERID`
		   ,`UCID`
           ,`DNIS_NAME`
           ,`CALLERID`
           ,`PREFFERRED_CONTACTNO`
           ,`TYPE_OF_INQUIRY`
           ,`TYPE`
           ,`REQUEST_DATE`
           ,`REQUEST_TIME`
           ,`QUEUE_WAIT_TIME`
           ,`CALLBACK_STATUS`)
     VALUES
	 (p_SERVERID,p_UCID,p_DNIS_NAME,p_CALLERID,p_PREFFERRED_CONTACTNO,p_TYPE_OF_INQUIRY,p_TYPE,p_REQUEST_DATE,p_REQUEST_TIME,p_QUEUE_WAIT_TIME,p_CALLBACK_STATUS);

END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.UpwardNodeEdit
DELIMITER //
CREATE PROCEDURE `UpwardNodeEdit`(
p_Channel varchar(10),
p_InputTag varchar(100),
p_ConfidenceThreshold varchar(10),
p_DestinationAction varchar(50),
p_PrevDestinationAction longtext,
p_DialogState varchar(100),
p_Product varchar(50),
p_Intent varchar(100),
p_IntentIndex int,
p_Error_Limit_DTMF int,
p_Error_Limit_Speech int,
p_Speech_Grammar_Name varchar(150),
p_DTMF_Grammar_Set varchar(50),
p_Initial_Prompt varchar(100),
p_Fail1_Prompt varchar(100),
p_Fail2_Prompt varchar(100),
p_Timeout1_Prompt varchar(100),
p_Timeout2_Prompt varchar(100),
p_NewNodeName longtext,
p_HasChildNode longtext,
p_Option varchar(6)
)
begin
declare v_GrammarSet LONGTEXT;  
declare v_Dialog_Tag LONGTEXT;

set v_GrammarSet=(SELECT DTMF_GRAMMAR_SET FROM IVR_IW_DTMF_Map where SEMANTIC_TAG=p_InputTag);
set v_Dialog_Tag=(select IVR_IW_Dialog_State_Map.Dialog_State_Tag from IVR_IW_Dialog_State_Map where IVR_IW_Dialog_State_Map.Speech_Grammar_Name=v_GrammarSet);

if(replace(p_DestinationAction,' ','')='AskQuestion' and replace(p_PrevDestinationAction,' ','')='AskQuestion')
then
update IVR_IW_Dialog_State_Map set Error_Limit_DTMF=p_Error_Limit_DTMF,Error_Limit_Speech=p_Error_Limit_Speech,Speech_Grammar_Name=v_GrammarSet,DTMF_Grammar_Set=v_GrammarSet,Initial_Prompt=p_Initial_Prompt,Fail1_Prompt=p_Fail1_Prompt,Fail2_Prompt=p_Fail2_Prompt,Timeout1_Prompt=p_Timeout1_Prompt,Timeout2_Prompt=p_Timeout2_Prompt where IVR_IW_Dialog_State_Map.DTMF_GRAMMAR_SET=v_GrammarSet;
update IVR_IW_DTMF_Map set SEMANTIC_TAG=p_NewNodeName , options=p_Option where SEMANTIC_TAG=p_InputTag and DTMF_GRAMMAR_SET=v_GrammarSet;


update IVR_IW_Transition_Map set IVR_IW_Transition_Map.Channel=p_Channel,IVR_IW_Transition_Map.ConfidenceThreshold=p_ConfidenceThreshold,IVR_IW_Transition_Map.Product=p_Product,IVR_IW_Transition_Map.IntentIndex=p_IntentIndex where IVR_IW_Transition_Map.DialogState=v_Dialog_Tag;

IF EXISTS (SELECT * FROM IVR_IW_Transition_Map where IVR_IW_Transition_Map.InputTag=p_InputTag)
then
update IVR_IW_Transition_Map set IVR_IW_Transition_Map.InputTag=p_NewNodeName where IVR_IW_Transition_Map.InputTag=p_InputTag;
end if;

end if;

if((p_DestinationAction='Agent' or p_DestinationAction='Module')and replace(p_PrevDestinationAction,' ','')='AskQuestion')
then
update IVR_IW_Transition_Map set DestinationAction=replace(p_DestinationAction,' ','') where IVR_IW_Transition_Map.DialogState=v_Dialog_Tag;
end if;

end//
DELIMITER ;

-- Dumping structure for table OCM.usages
CREATE TABLE IF NOT EXISTS `usages` (
  `organization_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `upload_size` bigint DEFAULT NULL,
  `download_size` bigint DEFAULT NULL,
  `createdAt` datetime(6) NOT NULL,
  `updatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.user_preference_bookmark
CREATE TABLE IF NOT EXISTS `user_preference_bookmark` (
  `id` char(38) NOT NULL,
  `parentid` char(38) DEFAULT NULL,
  `userid` varchar(20) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `bookmarkname` varchar(250) NOT NULL,
  `bookmarktype` varchar(20) NOT NULL,
  `bookmarkdata` varchar(1000) NOT NULL,
  `bookmarkstatus` int NOT NULL DEFAULT '1',
  `createdby` varchar(50) DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `updatedby` varchar(50) DEFAULT NULL,
  `updatedon` datetime DEFAULT NULL,
  `otherdata` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_user_preference_bookmark_bookmarkname` (`bookmarkname`),
  KEY `IX_user_preference_bookmark_bookmarkstatus` (`bookmarkstatus`),
  KEY `IX_user_preference_bookmark_bookmarktype` (`bookmarktype`),
  KEY `IX_user_preference_bookmark_createdon` (`createdon`),
  KEY `IX_user_preference_bookmark_userid` (`userid`),
  KEY `IX_user_preference_bookmark_usertype` (`usertype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for procedure OCM.Usp_GetSMMCustomer
DELIMITER //
CREATE PROCEDURE `Usp_GetSMMCustomer`(p_SearchBy VARCHAR(50),p_SearchValue VARCHAR(50))
BEGIN
	DECLARE v_IsActive TINYINT;  
	DECLARE v_MID VARCHAR(50);  
	DECLARE v_LINEID VARCHAR(50);  
	DECLARE v_CIF VARCHAR(50); 
	DECLARE v_Code INT;  
	DECLARE v_QueryMID VARCHAR(1000);  
	DECLARE v_QueryLINEID VARCHAR(1000);  
	DECLARE v_QueryCIF VARCHAR(1000); 

	SELECT CustomerchannelId INTO v_MID FROM Notify_SMMCustomer WHERE CustomerchannelId = p_SearchValue AND Active = 1;

	SELECT UserId INTO v_LINEID FROM Notify_SMMCustomer WHERE UserId = p_SearchValue AND Active = 1;
	
	SELECT CustomerOrgId INTO v_CIF FROM Notify_SMMCustomer WHERE CustomerOrgId = p_SearchValue AND Active = 1;
	
   IF (UPPER(p_SearchBy) = UPPER('UserId') AND (CHAR_LENGTH(RTRIM(IFNULL(v_LINEID,''))) = 0))
   THEN
	   SET v_Code = 102; 
   	SELECT v_Code AS ResponseMessage;
   END IF;
   
   IF (UPPER(p_SearchBy) = UPPER('CustomerchannelId') AND (CHAR_LENGTH(RTRIM(IFNULL(v_MID,''))) = 0))
   THEN
	   SET v_Code = 102; 
   	SELECT v_Code AS ResponseMessage;
   END IF;
   
   IF (UPPER(p_SearchBy) = UPPER('CustomerOrgId') AND (CHAR_LENGTH(RTRIM(IFNULL(v_CIF,''))) = 0))
   THEN
	   SET v_Code = 102; 
   	SELECT v_Code AS ResponseMessage;
   END IF;


	IF ((UPPER(p_SearchBy) = UPPER('Customerchannelid') AND (v_MID = p_SearchValue)))
	THEN
		SET v_QueryMID = CONCAT('SELECT nSmmCust.CustomerOrgId, nSmmCust.CustomerChannelId,nSmmCust.UserId,
		nSmmCust.RegistrationMode,nSmmCust.CreatedBy,nSmmCust.CreatedDateTime,Nc.ChannelCode 
		FROM Notify_SMMCustomer nSmmCust INNER JOIN Notify_Channel Nc ON nSmmCust.NotificationChannel = Nc.ChannelId 
		WHERE nSmmCust.customerChannelId =' , '''',p_SearchValue,'''' , ' AND nSmmCust.Active = 1 ORDER BY CreatedDateTime DESC LIMIT 1');
		SET @stmt_str = v_QueryMID;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
	
	IF ((UPPER(p_SearchBy) = UPPER('UserId') AND (v_LINEID = p_SearchValue)))
	THEN
		SET v_QueryLINEID = CONCAT('SELECT nSmmCust.CustomerOrgId, nSmmCust.CustomerChannelId,nSmmCust.UserId,
		nSmmCust.RegistrationMode,nSmmCust.CreatedBy,nSmmCust.CreatedDateTime,Nc.ChannelCode 
		FROM Notify_SMMCustomer nSmmCust INNER JOIN Notify_Channel Nc ON nSmmCust.NotificationChannel = Nc.ChannelId 
		WHERE nSmmCust.UserId = ' , '''',p_SearchValue,'''' , ' AND nSmmCust.Active = 1 ORDER BY CreatedDateTime DESC LIMIT 1');
		SET @stmt_str = v_QueryLINEID;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
	
	IF ((UPPER(p_SearchBy) = UPPER('CustomerOrgId') AND (v_CIF = p_SearchValue)))
	THEN
		
		SET v_QueryCIF = CONCAT('SELECT nSmmCust.CustomerOrgId, nSmmCust.CustomerChannelId,nSmmCust.UserId,
		nSmmCust.RegistrationMode,nSmmCust.CreatedBy,nSmmCust.CreatedDateTime,Nc.ChannelCode 
		FROM Notify_SMMCustomer nSmmCust INNER JOIN Notify_Channel Nc ON nSmmCust.NotificationChannel = Nc.ChannelId 
		WHERE nSmmCust.CustomerOrgId = ' , '''',p_SearchValue,'''' , ' AND nSmmCust.Active = 1 ORDER BY CreatedDateTime DESC LIMIT 1');
		SET @stmt_str = v_QueryCIF;
		PREPARE stmt FROM @stmt_str;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
END//
DELIMITER ;

-- Dumping structure for procedure OCM.ValidateNodeName
DELIMITER //
CREATE PROCEDURE `ValidateNodeName`(p_Name longtext
)
begin
SELECT count(1) FROM IVR_IW_DTMF_Map where SEMANTIC_TAG=p_Name;
end//
DELIMITER ;

-- Dumping structure for function OCM.VARCHARTODATETIME
DELIMITER //
CREATE FUNCTION `VARCHARTODATETIME`(
    p_varchardatetime varchar(30)
) RETURNS datetime(3)
    DETERMINISTIC
BEGIN
    RETURN case WHEN IFNULL(p_varchardatetime,'')='' THEN NULL
    when ISDATE(p_varchardatetime, '%Y%m%d%H%i%s')=1 then CONVERT(p_varchardatetime, DATETIME(3)) 
    ELSE NULL END;            
END//
DELIMITER ;

-- Dumping structure for table OCM.VB_Enrolment_Eligibility
CREATE TABLE IF NOT EXISTS `VB_Enrolment_Eligibility` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DNIS` varchar(20) DEFAULT NULL,
  `HotlineNumber` varchar(20) DEFAULT NULL,
  `EnrollmentFlag` varchar(1) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.VDN_DETAILS
CREATE TABLE IF NOT EXISTS `VDN_DETAILS` (
  `VDN_No` varchar(20) DEFAULT NULL,
  `VDN_NAME` varchar(100) DEFAULT NULL,
  `LAST_CHANGED_BY` varchar(50) DEFAULT NULL,
  `LAST_CHANGED_ON` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.VDN_Monitor
CREATE TABLE IF NOT EXISTS `VDN_Monitor` (
  `UCID` varchar(50) DEFAULT NULL,
  `AgentDevice` varchar(50) DEFAULT NULL,
  `AgentID` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `VDN` varchar(50) DEFAULT NULL,
  `Queue` varchar(50) DEFAULT NULL,
  `ConnectDate` varchar(50) DEFAULT NULL,
  `ConnectTime` varchar(50) DEFAULT NULL,
  `ConnectionHandle` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.VDN_Monitoring
CREATE TABLE IF NOT EXISTS `VDN_Monitoring` (
  `UCID` varchar(30) NOT NULL,
  `TRANSFER_VDN` varchar(50) DEFAULT NULL,
  `CB_VDN` varchar(50) DEFAULT NULL,
  `QUEUE_WAIT_TIME` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`UCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.VDN_MONITOR_DETAILS
CREATE TABLE IF NOT EXISTS `VDN_MONITOR_DETAILS` (
  `vdn` varchar(10) DEFAULT NULL,
  `ucid` varchar(50) DEFAULT NULL,
  `agentid` varchar(50) DEFAULT NULL,
  `agent_connect_datetime` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.VDN_MON_QUEUETIME
CREATE TABLE IF NOT EXISTS `VDN_MON_QUEUETIME` (
  `UCID` varchar(50) DEFAULT NULL,
  `QUEUETIME` datetime(3) DEFAULT NULL,
  `TRANS_VDN` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table OCM.Voyage_Drop_Request
CREATE TABLE IF NOT EXISTS `Voyage_Drop_Request` (
  `Voyage_Drop_Request_ID` int NOT NULL AUTO_INCREMENT,
  `CLID` varchar(20) DEFAULT NULL,
  `REQUEST_DATE` varchar(20) DEFAULT NULL,
  `REQUEST_TIME` varchar(20) DEFAULT NULL,
  `NRIC` varchar(15) DEFAULT NULL,
  `CARD_NUMBER` varchar(16) DEFAULT NULL,
  `HAND_PHONE` varchar(15) DEFAULT NULL,
  `VERIFIED` varchar(1) DEFAULT NULL,
  `OPTIONS` varchar(9) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `UCID` varchar(25) DEFAULT NULL,
  `Channel` varchar(10) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `VoyageFlag` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`Voyage_Drop_Request_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for view OCM.vw_email_actions_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_actions_view` (
	`ID` INT(10) NOT NULL,
	`Action` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Direction` VARCHAR(5) NULL COLLATE 'utf8mb4_general_ci',
	`ActionDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ActionTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`ActionBy` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Info` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`RouteId` BIGINT(19) NULL
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_draft_body_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_draft_body_view` (
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`body` LONGTEXT NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Label` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`InSessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`BCCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`sendDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`Routeid` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_draft_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_draft_view` (
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Label` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`InSessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`BCCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`sendDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`Routeid` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_inbox_body_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_inbox_body_view` (
	`SentDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SentTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CMSkill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(520) NULL COLLATE 'utf8mb4_general_ci',
	`Body` LONGTEXT NULL COLLATE 'utf8mb4_general_ci',
	`HasAttachments` BIGINT(19) NOT NULL,
	`AssignedTo` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedStatus` BIGINT(19) NOT NULL,
	`ClosedReasonCode` INT(10) NULL,
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`Priority` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedBy` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedBy` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedStatus` VARCHAR(8) NOT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_inbox_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_inbox_view` (
	`SentDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SentTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CMSkill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(520) NULL COLLATE 'utf8mb4_general_ci',
	`HasAttachments` BIGINT(19) NOT NULL,
	`AssignedTo` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedStatus` BIGINT(19) NOT NULL,
	`ClosedReasonCode` INT(10) NULL,
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`Priority` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedBy` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedBy` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedStatus` VARCHAR(8) NOT NULL COLLATE 'utf8mb4_general_ci',
	`EmailType` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_makerqueue_body_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_makerqueue_body_view` (
	`RID` BIGINT(19) NOT NULL,
	`Skill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CMSkill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Priority` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`SentDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SentTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(520) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Body` LONGTEXT NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteType` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_makerqueue_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_makerqueue_view` (
	`RID` BIGINT(19) NOT NULL,
	`Skill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CMSkill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Priority` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`SentDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SentTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(520) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteType` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_raw_data_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_raw_data_view` (
	`RID` BIGINT(19) NOT NULL,
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CMSkill=rte.Skill` INT(10) NULL,
	`RouteReason` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`SentDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SentTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`ReceivedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedTo` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssingedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedDateTime = inbox.RepliedDate + ''+inbox.RepliedTime` INT(10) NULL,
	`ClosedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`DraftDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(520) NULL COLLATE 'utf8mb4_general_ci',
	`currentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteActivTime` INT(10) NULL,
	`RouteActivHoldTime` INT(10) NULL,
	`RouteActivorHold` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Name_exp_22` INT(10) NULL,
	`deleted=IFNULL(inbox.deleted,0)` INT(10) NULL,
	`DeletedBy` VARCHAR(10) NULL COLLATE 'utf8mb4_general_ci',
	`DeletedOn` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_routes_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_routes_view` (
	`RID` BIGINT(19) NOT NULL,
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteType` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteTo` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssignedTo` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`AssingedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ClosedDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ReplyIDList` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`DraftID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ActiveTime` INT(10) NULL,
	`HoldTime` INT(10) NULL,
	`ActiveOrHold` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`Skill` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`DraftDateTime` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RouteReason` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CloseReason` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`RepliedBy` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ATTACHMENTINFO` VARCHAR(20) NULL COLLATE 'utf8mb4_general_ci',
	`EWS_EmailSentDateTime` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_sent_body_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_sent_body_view` (
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`BCCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`SendDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SendTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`InSessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`Label` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`SendStatus` VARCHAR(10) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`HasAttachments` BIGINT(19) NOT NULL,
	`Body` LONGTEXT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view OCM.vw_email_sent_view
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_email_sent_view` (
	`SessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ConversationID` VARCHAR(16) NULL COLLATE 'utf8mb4_general_ci',
	`From` VARCHAR(250) NULL COLLATE 'utf8mb4_general_ci',
	`CCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`BCCList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentServicePoint` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`ToList` VARCHAR(4000) NULL COLLATE 'utf8mb4_general_ci',
	`Subject` VARCHAR(1000) NULL COLLATE 'utf8mb4_general_ci',
	`SendDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`SendTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`InSessionID` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatus` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusDate` VARCHAR(8) NULL COLLATE 'utf8mb4_general_ci',
	`CurrentStatusTime` VARCHAR(6) NULL COLLATE 'utf8mb4_general_ci',
	`Label` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`SendStatus` VARCHAR(10) NULL COLLATE 'utf8mb4_general_ci',
	`Mailbox` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`HasAttachments` BIGINT(19) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for function OCM.WorkQueueData
DELIMITER //
CREATE FUNCTION `WorkQueueData`(
	`p_Date` varchar(8),
	`p_StartTime` varchar(6),
	`p_EndTime` varchar(6),
	`p_Id` varchar(8000),
	`p_acceptableSL` int
) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN 
   DECLARE sf_result INT DEFAULT 0; 
	DECLARE v_status INT;
	
	 SET v_status := BreakStringIntoRows(p_Id);
	 
	 DROP TEMPORARY TABLE IF EXISTS WorkQueueDataResult;
      CREATE TEMPORARY TABLE WorkQueueDataResult (Skill VARCHAR(100),AbandTime INT,AbandCalls INT,CallsHandledWithinSLAThreshold INT,
		CallsAbandonedAfterSLAThreshold INT,PassedCalls INT);
      
INSERT INTO WorkQueueDataResult(Skill,AbandTime,AbandCalls,CallsHandledWithinSLAThreshold,CallsAbandonedAfterSLAThreshold,PassedCalls) 
	SELECT 
	Skill,
	IFNULL(SUM(AbandTime),0) as AbandTime, IFNULL(SUM(AbandCalls),0) as AbandCalls, 
	IFNULL(SUM(SLNumCount),0) as CallsHandledWithinSLAThreshold, IFNULL(SUM(SLDenCount),0) as CallsAbandonedAfterSLAThreshold,
	IFNULL(SUM(SuccessCalls),0) as PassedCalls
	FROM (
	SELECT 
	Skill,
	CASE when TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(CONCAT(CreateDate,CreatedTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
	CONVERT(INSERT(INSERT(INSERT(CONCAT(RouteDate,RouteTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime)) < (Select  DISTINCT AcceptableServiceLevel from TMAC_Skills where SkillExtension=Skill) and Reason = 'AutoRoute' then 1 else 0 end AS SLNumCount,

	CASE when TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(CONCAT(CreateDate,CreatedTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
	CONVERT(INSERT(INSERT(INSERT(CONCAT(RouteDate,RouteTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime)) > (Select  DISTINCT AcceptableServiceLevel from TMAC_Skills where SkillExtension=Skill) and Reason = 'timedout' then 1 else 0 end AS SLDenCount,

	CASE when Reason = 'timedout' then 1 else 0 end as AbandCalls,
	CASE when Reason = 'AutoRoute' then 1 else 0 end as SuccessCalls,

	CASE when Reason = 'timedout' then 
	TIMESTAMPDIFF(SECOND,CONVERT(INSERT(INSERT(INSERT(CONCAT(CreateDate,CreatedTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime),
	CONVERT(INSERT(INSERT(INSERT(CONCAT(RouteDate,RouteTime), 9, 0, ' '), 12, 0, ':'), 15, 0, ':'), datetime)) else 0 
	end AbandTime

	FROM TMAC_WorkQueueHistory 
	where Skill in (Select id from BreakStringIntoRowsResult) and  CreateDate  = p_Date and CreatedTime between p_StartTime and p_EndTime)
	Temp
	GROUP BY Skill;
	
		SET sf_result = 1;
  
 		RETURN sf_result;
END//
DELIMITER ;



-- Dumping structure for view OCM.email_actions_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `email_actions_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `email_actions_view` AS select `email_actions`.`ID` AS `ID`,`email_actions`.`Action` AS `Action`,`email_actions`.`SessionID` AS `SessionID`,`email_actions`.`Direction` AS `Direction`,`email_actions`.`ActionDate` AS `ActionDate`,`email_actions`.`ActionTime` AS `ActionTime`,`email_actions`.`ActionBy` AS `ActionBy`,`email_actions`.`Info` AS `Info`,`email_actions`.`RouteId` AS `RouteId` from `email_actions`;

-- Dumping structure for view OCM.email_routes_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `email_routes_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `email_routes_view` AS select `email_routes`.`RID` AS `RID`,`email_routes`.`SessionID` AS `SessionID`,`email_routes`.`RouteType` AS `RouteType`,`email_routes`.`RouteTo` AS `RouteTo`,`email_routes`.`RouteDateTime` AS `RouteDateTime`,`email_routes`.`AssignedTo` AS `AssignedTo`,`email_routes`.`AssingedDateTime` AS `AssingedDateTime`,`email_routes`.`RepliedDateTime` AS `RepliedDateTime`,`email_routes`.`ClosedDateTime` AS `ClosedDateTime`,`email_routes`.`CurrentStatus` AS `CurrentStatus`,`email_routes`.`ReplyIDList` AS `ReplyIDList`,`email_routes`.`DraftID` AS `DraftID`,`email_routes`.`ActiveTime` AS `ActiveTime`,`email_routes`.`HoldTime` AS `HoldTime`,`email_routes`.`ActiveOrHold` AS `ActiveOrHold`,`email_routes`.`Skill` AS `Skill`,`email_routes`.`DraftDateTime` AS `DraftDateTime`,`email_routes`.`RouteReason` AS `RouteReason`,`email_routes`.`CloseReason` AS `CloseReason`,`email_routes`.`RepliedBy` AS `RepliedBy`,`email_routes`.`ATTACHMENTINFO` AS `ATTACHMENTINFO`,`email_routes`.`EWS_EmailSentDateTime` AS `EWS_EmailSentDateTime` from `email_routes`;

-- Dumping structure for view OCM.vw_email_actions_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_actions_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_actions_view` AS select `email_actions`.`ID` AS `ID`,`email_actions`.`Action` AS `Action`,`email_actions`.`SessionID` AS `SessionID`,`email_actions`.`Direction` AS `Direction`,`email_actions`.`ActionDate` AS `ActionDate`,`email_actions`.`ActionTime` AS `ActionTime`,`email_actions`.`ActionBy` AS `ActionBy`,`email_actions`.`Info` AS `Info`,`email_actions`.`RouteId` AS `RouteId` from `email_actions`;

-- Dumping structure for view OCM.vw_email_draft_body_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_draft_body_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_draft_body_view` AS select `email_outbox`.`SessionID` AS `SessionID`,`email_outbox`.`ToList` AS `ToList`,`email_outbox`.`Subject` AS `Subject`,`email_outbox`.`Body` AS `body`,`email_outbox`.`CurrentStatus` AS `CurrentStatus`,`email_outbox`.`Label` AS `Label`,`email_outbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_outbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_outbox`.`InSessionID` AS `InSessionID`,`email_outbox`.`From` AS `From`,`email_outbox`.`CCList` AS `CCList`,`email_outbox`.`BCCList` AS `BCCList`,`email_outbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_outbox`.`SendDate` AS `sendDate`,`email_outbox`.`ConversationID` AS `ConversationID`,`email_outbox`.`RouteID` AS `Routeid`,`email_outbox`.`Mailbox` AS `Mailbox` from `email_outbox` where ((`email_outbox`.`CurrentStatus` = 'Draft') or (`email_outbox`.`Label` = 'Draft'));

-- Dumping structure for view OCM.vw_email_draft_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_draft_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_draft_view` AS select `email_outbox`.`SessionID` AS `SessionID`,`email_outbox`.`ToList` AS `ToList`,`email_outbox`.`Subject` AS `Subject`,`email_outbox`.`CurrentStatus` AS `CurrentStatus`,`email_outbox`.`Label` AS `Label`,`email_outbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_outbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_outbox`.`InSessionID` AS `InSessionID`,`email_outbox`.`From` AS `From`,`email_outbox`.`CCList` AS `CCList`,`email_outbox`.`BCCList` AS `BCCList`,`email_outbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_outbox`.`SendDate` AS `sendDate`,`email_outbox`.`ConversationID` AS `ConversationID`,`email_outbox`.`RouteID` AS `Routeid`,`email_outbox`.`Mailbox` AS `Mailbox` from `email_outbox` where ((`email_outbox`.`CurrentStatus` = 'Draft') or (`email_outbox`.`Label` = 'Draft'));

-- Dumping structure for view OCM.vw_email_inbox_body_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_inbox_body_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_inbox_body_view` AS select `email_inbox`.`SentDate` AS `SentDate`,`email_inbox`.`SentTime` AS `SentTime`,`email_inbox`.`SessionID` AS `SessionID`,`email_inbox`.`From` AS `From`,`email_inbox`.`ToList` AS `ToList`,`email_inbox`.`CCList` AS `CCList`,`email_inbox`.`CMSkill` AS `CMSkill`,`email_inbox`.`Subject` AS `Subject`,`email_inbox`.`Body` AS `Body`,ifnull(`email_inbox`.`HasAttachments`,0) AS `HasAttachments`,`email_inbox`.`AssignedTo` AS `AssignedTo`,ifnull(`email_inbox`.`RepliedStatus`,0) AS `RepliedStatus`,`email_inbox`.`ClosedReasonCode` AS `ClosedReasonCode`,`email_inbox`.`ConversationID` AS `ConversationID`,`email_inbox`.`Priority` AS `Priority`,`email_inbox`.`ReceivedDate` AS `ReceivedDate`,`email_inbox`.`ReceivedTime` AS `ReceivedTime`,`email_inbox`.`AssignedDate` AS `AssignedDate`,`email_inbox`.`RepliedTime` AS `RepliedTime`,`email_inbox`.`RepliedBy` AS `RepliedBy`,`email_inbox`.`ClosedDate` AS `ClosedDate`,`email_inbox`.`ClosedTime` AS `ClosedTime`,`email_inbox`.`ClosedBy` AS `ClosedBy`,`email_inbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_inbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_inbox`.`Mailbox` AS `Mailbox`,`email_inbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_inbox`.`AssignedTime` AS `AssignedTime`,`email_inbox`.`RepliedDate` AS `RepliedDate`,`email_inbox`.`CurrentStatus` AS `CurrentStatus`,ifnull(`email_inbox`.`ClosedDate`,'0') AS `ClosedStatus` from `email_inbox` where (ifnull(`email_inbox`.`Deleted`,0) <> 1);

-- Dumping structure for view OCM.vw_email_inbox_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_inbox_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_inbox_view` AS select `email_inbox`.`SentDate` AS `SentDate`,`email_inbox`.`SentTime` AS `SentTime`,`email_inbox`.`SessionID` AS `SessionID`,`email_inbox`.`From` AS `From`,`email_inbox`.`ToList` AS `ToList`,`email_inbox`.`CCList` AS `CCList`,`email_inbox`.`CMSkill` AS `CMSkill`,`email_inbox`.`Subject` AS `Subject`,ifnull(`email_inbox`.`HasAttachments`,0) AS `HasAttachments`,`email_inbox`.`AssignedTo` AS `AssignedTo`,ifnull(`email_inbox`.`RepliedStatus`,0) AS `RepliedStatus`,`email_inbox`.`ClosedReasonCode` AS `ClosedReasonCode`,`email_inbox`.`ConversationID` AS `ConversationID`,`email_inbox`.`Priority` AS `Priority`,`email_inbox`.`ReceivedDate` AS `ReceivedDate`,`email_inbox`.`ReceivedTime` AS `ReceivedTime`,`email_inbox`.`AssignedDate` AS `AssignedDate`,`email_inbox`.`RepliedTime` AS `RepliedTime`,`email_inbox`.`RepliedBy` AS `RepliedBy`,`email_inbox`.`ClosedDate` AS `ClosedDate`,`email_inbox`.`ClosedTime` AS `ClosedTime`,`email_inbox`.`ClosedBy` AS `ClosedBy`,`email_inbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_inbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_inbox`.`Mailbox` AS `Mailbox`,`email_inbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_inbox`.`AssignedTime` AS `AssignedTime`,`email_inbox`.`RepliedDate` AS `RepliedDate`,`email_inbox`.`CurrentStatus` AS `CurrentStatus`,ifnull(`email_inbox`.`ClosedDate`,0) AS `ClosedStatus`,`email_inbox`.`EmailType` AS `EmailType` from `email_inbox` where (ifnull(`email_inbox`.`Deleted`,0) <> 1);

-- Dumping structure for view OCM.vw_email_makerqueue_body_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_makerqueue_body_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_makerqueue_body_view` AS select `email_routes`.`RID` AS `RID`,`email_routes`.`Skill` AS `Skill`,`email_inbox`.`ConversationID` AS `ConversationID`,`email_inbox`.`From` AS `From`,`email_inbox`.`CCList` AS `CCList`,`email_inbox`.`CMSkill` AS `CMSkill`,`email_inbox`.`Priority` AS `Priority`,`email_inbox`.`SentDate` AS `SentDate`,`email_inbox`.`SentTime` AS `SentTime`,`email_inbox`.`SessionID` AS `SessionID`,`email_inbox`.`Subject` AS `Subject`,`email_inbox`.`ToList` AS `ToList`,`email_inbox`.`Body` AS `Body`,`email_inbox`.`ReceivedDate` AS `ReceivedDate`,`email_inbox`.`ReceivedTime` AS `ReceivedTime`,`email_inbox`.`Mailbox` AS `Mailbox`,`email_routes`.`RouteType` AS `RouteType`,`email_routes`.`CurrentStatus` AS `CurrentStatus` from (`email_routes` left join `email_inbox` on((`email_inbox`.`SessionID` = `email_routes`.`SessionID`))) where ((`email_routes`.`RouteType` = 'queue') and (`email_routes`.`CurrentStatus` = 'queue'));

-- Dumping structure for view OCM.vw_email_makerqueue_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_makerqueue_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_makerqueue_view` AS select `email_routes`.`RID` AS `RID`,`email_routes`.`Skill` AS `Skill`,`email_inbox`.`ConversationID` AS `ConversationID`,`email_inbox`.`From` AS `From`,`email_inbox`.`CCList` AS `CCList`,`email_inbox`.`CMSkill` AS `CMSkill`,`email_inbox`.`Priority` AS `Priority`,`email_inbox`.`SentDate` AS `SentDate`,`email_inbox`.`SentTime` AS `SentTime`,`email_inbox`.`SessionID` AS `SessionID`,`email_inbox`.`Subject` AS `Subject`,`email_inbox`.`ToList` AS `ToList`,`email_inbox`.`ReceivedDate` AS `ReceivedDate`,`email_inbox`.`ReceivedTime` AS `ReceivedTime`,`email_inbox`.`Mailbox` AS `Mailbox`,`email_routes`.`RouteType` AS `RouteType`,`email_routes`.`CurrentStatus` AS `CurrentStatus` from (`email_routes` left join `email_inbox` on((`email_inbox`.`SessionID` = `email_routes`.`SessionID`))) where ((`email_routes`.`RouteType` = 'queue') and (`email_routes`.`CurrentStatus` = 'queue'));

-- Dumping structure for view OCM.vw_email_raw_data_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_raw_data_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_raw_data_view` AS select `rte`.`RID` AS `RID`,`inbox`.`SessionID` AS `SessionID`,(`inbox`.`CMSkill` = `rte`.`Skill`) AS `CMSkill=rte.Skill`,`rte`.`RouteReason` AS `RouteReason`,`inbox`.`SentDate` AS `SentDate`,`inbox`.`SentTime` AS `SentTime`,`rte`.`RouteDateTime` AS `ReceivedDateTime`,`rte`.`AssignedTo` AS `AssignedTo`,`rte`.`AssingedDateTime` AS `AssingedDateTime`,(`rte`.`RepliedDateTime` = ((`inbox`.`RepliedDate` + '') + `inbox`.`RepliedTime`)) AS `RepliedDateTime = inbox.RepliedDate + ''+inbox.RepliedTime`,`rte`.`ClosedDateTime` AS `ClosedDateTime`,`rte`.`DraftDateTime` AS `DraftDateTime`,`inbox`.`From` AS `From`,`inbox`.`Mailbox` AS `Mailbox`,`inbox`.`ToList` AS `ToList`,`inbox`.`CCList` AS `CCList`,`inbox`.`Subject` AS `Subject`,`rte`.`CurrentStatus` AS `currentStatus`,`rte`.`ActiveTime` AS `RouteActivTime`,`rte`.`HoldTime` AS `RouteActivHoldTime`,`rte`.`ActiveOrHold` AS `RouteActivorHold`,(`rte`.`ReplyIDList` = ((((ifnull(`inbox`.`RepliedDate`,'') + ifnull(`inbox`.`RepliedTime`,'')) + '  ') + ifnull(`inbox`.`ClosedDate`,'')) + ifnull(`inbox`.`ClosedTime`,''))) AS `Name_exp_22`,(`inbox`.`Deleted` = ifnull(`inbox`.`Deleted`,0)) AS `deleted=IFNULL(inbox.deleted,0)`,`inbox`.`DeletedBy` AS `DeletedBy`,`inbox`.`DeletedOn` AS `DeletedOn` from (`email_inbox` `inbox` join `email_routes` `rte` on((`inbox`.`SessionID` = `rte`.`SessionID`)));

-- Dumping structure for view OCM.vw_email_routes_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_routes_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_routes_view` AS select `email_routes`.`RID` AS `RID`,`email_routes`.`SessionID` AS `SessionID`,`email_routes`.`RouteType` AS `RouteType`,`email_routes`.`RouteTo` AS `RouteTo`,`email_routes`.`RouteDateTime` AS `RouteDateTime`,`email_routes`.`AssignedTo` AS `AssignedTo`,`email_routes`.`AssingedDateTime` AS `AssingedDateTime`,`email_routes`.`RepliedDateTime` AS `RepliedDateTime`,`email_routes`.`ClosedDateTime` AS `ClosedDateTime`,`email_routes`.`CurrentStatus` AS `CurrentStatus`,`email_routes`.`ReplyIDList` AS `ReplyIDList`,`email_routes`.`DraftID` AS `DraftID`,`email_routes`.`ActiveTime` AS `ActiveTime`,`email_routes`.`HoldTime` AS `HoldTime`,`email_routes`.`ActiveOrHold` AS `ActiveOrHold`,`email_routes`.`Skill` AS `Skill`,`email_routes`.`DraftDateTime` AS `DraftDateTime`,`email_routes`.`RouteReason` AS `RouteReason`,`email_routes`.`CloseReason` AS `CloseReason`,`email_routes`.`RepliedBy` AS `RepliedBy`,`email_routes`.`ATTACHMENTINFO` AS `ATTACHMENTINFO`,`email_routes`.`EWS_EmailSentDateTime` AS `EWS_EmailSentDateTime` from `email_routes`;

-- Dumping structure for view OCM.vw_email_sent_body_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_sent_body_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_sent_body_view` AS select `email_outbox`.`SessionID` AS `SessionID`,`email_outbox`.`ConversationID` AS `ConversationID`,`email_outbox`.`From` AS `From`,`email_outbox`.`CCList` AS `CCList`,`email_outbox`.`BCCList` AS `BCCList`,`email_outbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_outbox`.`ToList` AS `ToList`,`email_outbox`.`Subject` AS `Subject`,`email_outbox`.`SendDate` AS `SendDate`,`email_outbox`.`SendTime` AS `SendTime`,`email_outbox`.`InSessionID` AS `InSessionID`,`email_outbox`.`CurrentStatus` AS `CurrentStatus`,`email_outbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_outbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_outbox`.`Label` AS `Label`,`email_outbox`.`SendStatus` AS `SendStatus`,`email_outbox`.`Mailbox` AS `Mailbox`,ifnull(`email_outbox`.`HasAttachments`,0) AS `HasAttachments`,`email_outbox`.`Body` AS `Body` from `email_outbox` where (`email_outbox`.`SendStatus` = '1');

-- Dumping structure for view OCM.vw_email_sent_view
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_email_sent_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_email_sent_view` AS select `email_outbox`.`SessionID` AS `SessionID`,`email_outbox`.`ConversationID` AS `ConversationID`,`email_outbox`.`From` AS `From`,`email_outbox`.`CCList` AS `CCList`,`email_outbox`.`BCCList` AS `BCCList`,`email_outbox`.`CurrentServicePoint` AS `CurrentServicePoint`,`email_outbox`.`ToList` AS `ToList`,`email_outbox`.`Subject` AS `Subject`,`email_outbox`.`SendDate` AS `SendDate`,`email_outbox`.`SendTime` AS `SendTime`,`email_outbox`.`InSessionID` AS `InSessionID`,`email_outbox`.`CurrentStatus` AS `CurrentStatus`,`email_outbox`.`CurrentStatusDate` AS `CurrentStatusDate`,`email_outbox`.`CurrentStatusTime` AS `CurrentStatusTime`,`email_outbox`.`Label` AS `Label`,`email_outbox`.`SendStatus` AS `SendStatus`,`email_outbox`.`Mailbox` AS `Mailbox`,ifnull(`email_outbox`.`HasAttachments`,0) AS `HasAttachments` from `email_outbox` where (`email_outbox`.`SendStatus` = '1');



/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;


#************************************************************CREATE PAGE BASE**********************************************************************************************
#Replace Tetherfi\Admin with client server lan id
INSERT INTO `CMM_USER_MANAGEMENT`
(`USER_ID`,`FUNCTIONALITY`,`USER_ACCESS`,`LAST_CHANGED_BY`,`LAST_CHANGED_ON`,`ADD_ACCESS`,`EDIT_ACCESS`,`DELETE_ACCESS`,`EXPORT_ACCESS`)
VALUES('Tetherfi\\Admin','UserManagement','Enable','Tetherfi\\Admin','20180608 123432','Enable','Enable','Enable','Enable');

#*************************************************************************************************************************************************************************
           

#************************************************************CREATE ROLE BASE**********************************************************************************************
#Change the OCM Maker role to as required in client place and execute both Maker & Checker DB
INSERT INTO `CMM_Roles`(`RoleName`,`RoleID`)VALUES('OCM Maker',1);

#Change the OCM Checker role to as required in client place and execute both Maker & Checker DB
INSERT INTO `CMM_Roles`(`RoleName`,`RoleID`)VALUES('OCM Checker',2);

#Change the `TeamName` as per client
INSERT INTO `AGT_Teams`(`TeamName`,`LAST_CHANGED_ON`,`LAST_CHANGED_BY`,`LevelHierarchy`,`ParentID`,`DisplayName`,`LevelHierarchyID`,`IsDeleted`)
VALUES('Tetherfi Head','Admin','01/01/2021 00:00:00','Country','0','Country Head','1',0);

#Change the Username,fisrtname,lastname, avayaloginid,teamid(any existing teamid) as per client
 INSERT INTO CMM_User_Details(UserName,RoleID,TeamID,FirstName,LastName,CreatedDate,CreatedTime,CreatedBy) 
 VALUES ('Administrator','1','1','FirstName','LastName','20180612','000000','Administrator');

 INSERT INTO AGT_Agent(UserName,FirstName,LastName,AvayaLoginID,Profile,TeamID,PrimarySupervisorID,CreatedDate,CreatedTime,CreatedBy,`PBXId`,`IsDeleted`,`IsActive`,`IsInvited`) 
 VALUES ('Administrator','FirstName','LastName','50001','S',1,'0','20180612','000000','Administrator','50001',0,1,0);

#Insert role access  RoleManagement,UserRoleMapping and UserManagement

 INSERT INTO `CMM_Role_Pages`(`RoleID`,`PageName`,`LAST_CHANGED_ON`,`LAST_CHANGED_BY`,`USER_ACCESS`,`ADD_ACCESS`,`EDIT_ACCESS`,`DELETE_ACCESS`,`EXPORT_ACCESS`)
 VALUES ('1','RoleManagement','20180608 123432','Administrator','Enable','Enable','Enable','Enable','Enable');

 INSERT INTO `CMM_Role_Pages`(`RoleID`,`PageName`,`LAST_CHANGED_ON`,`LAST_CHANGED_BY`,`USER_ACCESS`,`ADD_ACCESS`,`EDIT_ACCESS`,`DELETE_ACCESS`,`EXPORT_ACCESS`)
 VALUES ('1','UserRoleMapping','20180608 123432','Administrator','Enable','Enable','Enable','Enable','Enable');
 
 INSERT INTO `CMM_Role_Pages`(`RoleID`,`PageName`,`LAST_CHANGED_ON`,`LAST_CHANGED_BY`,`USER_ACCESS`,`ADD_ACCESS`,`EDIT_ACCESS`,`DELETE_ACCESS`,`EXPORT_ACCESS`)
 VALUES ('1','UserManagement','20180608 123432','Administrator','Enable','Enable','Enable','Enable','Enable');

 #*****************************************************************************************************************************************************************
  
#Insert Supervisor

INSERT `AGT_Agent` ( `UserName`, `FirstName`, `LastName`, `AvayaLoginID`, `Profile`, `TeamID`, `PrimarySupervisorID`, `LastLoginDate`, `LastLoginTime`, `CreatedDate`, `CreatedTime`, `CreatedBy`,`PBXId`,`IsDeleted`,`IsActive`,`IsInvited`) VALUES (N'Administrator', N'Administrator', N'Admin', N'1000', N'S', 1, 0, N'20180809', N'123038', N'20180809', N'123038', N'Administrator','1000',0,1,0);
INSERT `AGT_Agent_Profile` (`AgentID`, `Voice`, `Email`, `SMS`, `TextChat`, `VideoChat`, `Role`) VALUES (N'1000', 1, 0, 0, 0, 0, N'Maker');
INSERT `AGT_TMACAgentProfile` (`IsHoldVoiceCallOnChatCall`, `IsSecondTextChatAutoAnswer`, `IsTextChatAutoAnswer`, `TotalTabsAllowed`, `TotalChatTabsAllowed`, `TotalVoiceTabsAllowed`, `TextChatGreetingTemplateID`, `IsCRMEnabled`, `CRMName`, `AgentID`, `LAST_CHANGED_BY`, `LAST_CHANGED_ON`, `IsManualInEnabled`, `IsVoiceACDAutoAnswerEnabled`, `IsVoiceACDAutoACWEnabled`, `IsTextChatAutoACWEnabled`, `IsVoiceAllAutoACWEnabled`, `TotalEmailTabsAllowed`) VALUES (N'0', N'0', N'0', N'20', N'0', N'20', 0, 0, N'0', N'1000', NULL, NULL, 0, 1, 0, 0, 0, 0);

INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1000', N'voice', 20, N'VoiceInteraction',1);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1000', N'fax', 20, N'FaxInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1000', N'textchat', 20, N'TextChatInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1000', N'audiochat', 20, N'TextChatInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1000', N'videochat', 20, N'TextChatInteraction',0);

#Insert Agent

INSERT `AGT_Agent` ( `UserName`, `FirstName`, `LastName`, `AvayaLoginID`, `Profile`, `TeamID`, `PrimarySupervisorID`, `LastLoginDate`, `LastLoginTime`, `CreatedDate`, `CreatedTime`, `CreatedBy`,`PBXId`,`IsDeleted`,`IsActive`,`IsInvited`) VALUES (N'Agent', N'Agent', N'Test', N'1001', N'A', 1, 1, N'20180809', N'123038', N'20180809', N'123038', N'Administrator','1002',0,1,0);
INSERT `AGT_Agent_Profile` (`AgentID`, `Voice`, `Email`, `SMS`, `TextChat`, `VideoChat`, `Role`) VALUES (N'1001', 1, 0, 0, 0, 0, N'Maker');
INSERT `AGT_TMACAgentProfile` (`IsHoldVoiceCallOnChatCall`, `IsSecondTextChatAutoAnswer`, `IsTextChatAutoAnswer`, `TotalTabsAllowed`, `TotalChatTabsAllowed`, `TotalVoiceTabsAllowed`, `TextChatGreetingTemplateID`, `IsCRMEnabled`, `CRMName`, `AgentID`, `LAST_CHANGED_BY`, `LAST_CHANGED_ON`, `IsManualInEnabled`, `IsVoiceACDAutoAnswerEnabled`, `IsVoiceACDAutoACWEnabled`, `IsTextChatAutoACWEnabled`, `IsVoiceAllAutoACWEnabled`, `TotalEmailTabsAllowed`) VALUES (N'0', N'0', N'0', N'20', N'0', N'20', 0, 0, N'0', N'1001', NULL, NULL, 0, 1, 0, 0, 0, 0);

INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1001', N'voice', 20, N'VoiceInteraction',1);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1001', N'fax', 20, N'FaxInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1001', N'textchat', 20, N'TextChatInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1001', N'audiochat', 20, N'TextChatInteraction',0);
INSERT `AGT_ChannelCount` (`AgentID`, `Channel`, `Count`, `BaseInteraction`,`Enable`) VALUES (N'1001', N'videochat', 20, N'TextChatInteraction',0);

#*****************************************************************************************************************************************************************
 
 #*******************************************************************************REPORT**********************************************************************************
INSERT ExportReportScheduler (`ReportName`, `LastExecutedDateTime`, `FrequencyInMinutes`, `ServerID`, `Status`, `STATUSDATETIME`, `InputStartDate`, `InputEndDate`, `WIPTIMEOUT`) 
VALUES ('IvrCallTransferReport', CAST('2018-05-25T12:07:08.047' AS DateTime(3)), 144000, '1', 'COMPLETED', CAST('2017-05-25T12:07:08.047' AS DateTime(3)), '20170101 000000', '20170101 000000', 120);

INSERT ExportReportScheduler (`ReportName`, `LastExecutedDateTime`, `FrequencyInMinutes`, `ServerID`, `Status`, `STATUSDATETIME`, `InputStartDate`, `InputEndDate`, `WIPTIMEOUT`) 
VALUES ('IvrCallTraceReport', CAST('2018-05-08T12:30:24.417' AS DateTime(3)), 144000, '1', 'COMPLETED', CAST('2017-05-25T11:07:07.287' AS DateTime(3)), '20170101 000000', '20170101 000000', 120);

INSERT ExportReportScheduler (`ReportName`, `LastExecutedDateTime`, `FrequencyInMinutes`, `ServerID`, `Status`, `STATUSDATETIME`, `InputStartDate`, `InputEndDate`, `WIPTIMEOUT`) 
VALUES ('IvrHostTransactionReport', CAST('2018-05-08T12:26:53.630' AS DateTime(3)), 144000, '1', 'COMPLETED', CAST('2017-05-25T11:07:07.287' AS DateTime(3)), '20170101 000000', '20170101 000000', 120);

INSERT ExportReportScheduler (`ReportName`, `LastExecutedDateTime`, `FrequencyInMinutes`, `ServerID`, `Status`, `STATUSDATETIME`, `InputStartDate`, `InputEndDate`, `WIPTIMEOUT`) 
VALUES ('IvrMenuAnalysisReport', CAST('2018-05-15T19:01:10.767' AS DateTime(3)), 144000, '1', 'COMPLETED', CAST('2017-05-25T11:07:07.287' AS DateTime(3)), '20170101 000000', '20170101 000000', 120);


INSERT OCMCustomReport ( ReportName, ReportQuery, ReportCreatedBy, ReportCreatedOn, LastChangedBy, LastChangedOn, ReportType) 
	VALUES ( N'OCMCallTransferReport',N'Select `UCID`,`CallerID`,`UserID`,`CreditorDebitCardNumber`,`CIN`,`LastMenu`,`LastMenu1`,`LastMenu2`,`LastMenu3`,`HotlineNumber`,
	`TransferredVDN`,`IntentSkill`,`VDNName`,`StartDateTime`,`EndDateTime`,`ReportDateTime` 
	from OCM_CallTransferReport  WHERE `ReportDateTime` >= ExportFromDate AND `ReportDateTime`<= ExportToDate',
	N'Admin',DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Admin', DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Generic');

INSERT OCMCustomReport ( ReportName, ReportQuery, ReportCreatedBy, ReportCreatedOn, LastChangedBy, LastChangedOn, ReportType) 
    VALUES ( N'OCMIvrCallTraceReport', N'SELECT `UCID`,`Name`,`StartDate`,`StartTime`,`EndDate`,`EndTime`,`Duration`,
	`CallerID`,`HotlineNumber`,`UID`,`CIF`,`CIN`,`MembershipID`,`CallerStatus`,
	`Lastmenu1`,`Lastmenu2`,`Lastmenu3`,`Lastmenu4`,`TransferredFlag`,`TransferVDN`,
	`TransferredToFeewaiver`,`Intent`,`OTPVerified`,`Segment`,`Language`,`SMSEligibility`,
	`ReportDateTime`,`TpinVerified`,`VDNName` FROM OCM_IvrCallTraceReport
	WHERE `ReportDateTime` >= ExportFromDate AND `ReportDateTime` <= ExportToDate',
	N'Admin',DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Admin', DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Generic');

INSERT OCMCustomReport (ReportName, ReportQuery, ReportCreatedBy, ReportCreatedOn, LastChangedBy, LastChangedOn, ReportType) 
	VALUES (N'OCMIvrHostTransactionReport', N'SELECT `UCID`,`RequestDateTime`,`CIN`,`TransactionName`,`MenuDescription`,`RequestMessage`,`ResponseMessage`,
	`HotlineNumber`,`PhoneCode`,`CIF`,`CustomerSegment`,`ReportDateTime` FROM OCM_IvrHostTransactionReport  
	WHERE `ReportDateTime` >= ExportFromDate AND `ReportDateTime` <= ExportToDate',
	N'Admin',DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Admin', DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Generic');

INSERT OCMCustomReport ( ReportName, ReportQuery, ReportCreatedBy, ReportCreatedOn, LastChangedBy, LastChangedOn, ReportType) 
	VALUES ( N'OCMIvrMenuAnalysisReport', N'SELECT `MENU` ,sum(`ACCESSCOUNT`) AS `AccessCount` ,sum(`INVALIDINPUT`) AS `InvalidInput` ,
	sum(`NOINPUT`) AS `NoInput` ,sum(`MAXTRIES`) AS `MaxTries` ,sum(`AgentTransfers`) AS `AgentTransfers` ,sum(`IVRDISCONNECTS`) AS `IvrDisconnects` 
	FROM OCM_ANALYSISCOUNTREPORT  WHERE `REPORTDATETIME`>=ExportFromDate AND `REPORTDATETIME`<=ExportToDate GROUP BY `MENU`',
	N'Admin',DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Admin', DATE_FORMAT(NOW(), '%Y%m%d %k%i%s'), N'Generic');

#*****************************************************************************************************************************************************************