USE `NEW_OCM`;

--
-- Alter column `ID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_agent`
--
ALTER TABLE agt_agent 
   DROP PRIMARY KEY;

--
-- Alter table `agt_agent`
--
ALTER TABLE agt_agent 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `UserName` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN UserName UserName VARCHAR(50) NOT NULL;

--
-- Alter column `FirstName` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN FirstName FirstName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LastName` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN LastName LastName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `AvayaLoginID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN AvayaLoginID AvayaLoginID VARCHAR(50) NOT NULL;

--
-- Alter column `Profile` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN Profile Profile VARCHAR(1) DEFAULT NULL;

--
-- Alter column `LastLoginDate` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN LastLoginDate LastLoginDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `LastLoginTime` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN LastLoginTime LastLoginTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `CreatedDate` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN CreatedDate CreatedDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `CreatedTime` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN CreatedTime CreatedTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `CreatedBy` on table `agt_agent`
--
ALTER TABLE agt_agent 
  CHANGE COLUMN CreatedBy CreatedBy VARCHAR(50) DEFAULT NULL;

--
-- Create column `CreatedDateTime` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN CreatedDateTime DATETIME(3) NOT NULL DEFAULT current_timestamp(3);

--
-- Create column `UpdatedDateTime` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN UpdatedDateTime DATETIME(3) DEFAULT NULL;

--
-- Create column `PBXId` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN PBXId VARCHAR(20) DEFAULT NULL;

--
-- Create column `IsDeleted` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN IsDeleted BIT(1) NOT NULL DEFAULT b'0';

--
-- Create column `IsActive` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN IsActive BIT(1) NOT NULL DEFAULT b'1';

--
-- Create column `IsInvited` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN IsInvited BIT(1) NOT NULL DEFAULT b'0';

--
-- Create column `Email` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN Email VARCHAR(100) DEFAULT NULL;

--
-- Create column `OrgUnitTemplateUser` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD COLUMN OrgUnitTemplateUser VARCHAR(50) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD PRIMARY KEY (UserName, AvayaLoginID);

--
-- Create index `IX_AGT_Agent_PrimarySupervisorID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD INDEX IX_AGT_Agent_PrimarySupervisorID(PrimarySupervisorID);

--
-- Create index `IX_AGT_Agent_TeamID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD INDEX IX_AGT_Agent_TeamID(TeamID);

--
-- Create index `ID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `agt_agent`
--
ALTER TABLE agt_agent 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `AgentProfileID` on table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  MODIFY AgentProfileID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
   DROP PRIMARY KEY;

--
-- Drop column `AgentProfileID` from table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  DROP COLUMN AgentProfileID;

--
-- Alter table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AgentID` on table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) NOT NULL;

--
-- Alter column `Role` on table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  CHANGE COLUMN Role Role VARCHAR(10) DEFAULT NULL;

--
-- Create column `ProfilePicture` on table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  ADD COLUMN ProfilePicture LONGTEXT DEFAULT NULL;

--
-- Create index `PRIMARY` on table `agt_agent_profile`
--
ALTER TABLE agt_agent_profile 
  ADD PRIMARY KEY (AgentID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  MODIFY ID BIGINT(20) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
   DROP PRIMARY KEY;

--
-- Alter table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AgentID` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `RemindDate` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN RemindDate RemindDate VARCHAR(50) DEFAULT NULL;

--
-- Alter column `RemindTime` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN RemindTime RemindTime VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Status` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN Status Status VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Message` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN Message Message VARCHAR(1000) DEFAULT NULL;

--
-- Alter column `CreatedDate` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN CreatedDate CreatedDate VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CreatedTime` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN CreatedTime CreatedTime VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CreatedBy` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN CreatedBy CreatedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedDate` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN LastChangedDate LastChangedDate VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedTime` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN LastChangedTime LastChangedTime VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedBy` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  CHANGE COLUMN LastChangedBy LastChangedBy VARCHAR(50) DEFAULT NULL;

--
-- Create column `Type` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  ADD COLUMN Type VARCHAR(20) DEFAULT NULL;

--
-- Create column `Source` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  ADD COLUMN Source VARCHAR(50) DEFAULT NULL;

--
-- Create column `RefId` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  ADD COLUMN RefId VARCHAR(100) DEFAULT NULL;

--
-- Create index `ID` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `agt_agent_reminders`
--
ALTER TABLE agt_agent_reminders 
  MODIFY ID BIGINT(20) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AgentID` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `StationID` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN StationID StationID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TimeStamp` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN TimeStamp TimeStamp VARCHAR(14) DEFAULT NULL;

--
-- Alter column `Status` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN Status Status VARCHAR(50) DEFAULT NULL;

--
-- Alter column `StatusType` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN StatusType StatusType VARCHAR(20) DEFAULT NULL;

--
-- Alter column `ReasonCode` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN ReasonCode ReasonCode VARCHAR(5) DEFAULT NULL;

--
-- Alter column `TalkStatus` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN TalkStatus TalkStatus VARCHAR(20) DEFAULT NULL;

--
-- Alter column `LogReason` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN LogReason LogReason VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LoginInstanceID` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  CHANGE COLUMN LoginInstanceID LoginInstanceID VARCHAR(50) DEFAULT NULL;

--
-- Create column `Duration` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  ADD COLUMN Duration FLOAT DEFAULT NULL;

--
-- Create index `IDX_AGT_Agent_StatusTrack_AgentID_LoginInstanceID_Status` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  ADD INDEX IDX_AGT_Agent_StatusTrack_AgentID_LoginInstanceID_Status(AgentID, LoginInstanceID, Status);

--
-- Create index `IX_N_AGT_Agent_StatusTrack_AgentID` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  ADD INDEX IX_N_AGT_Agent_StatusTrack_AgentID(AgentID);

--
-- Create index `IX_N_AGT_Agent_StatusTrack_TimeStamp` on table `agt_agent_statustrack`
--
ALTER TABLE agt_agent_statustrack 
  ADD INDEX IX_N_AGT_Agent_StatusTrack_TimeStamp(TimeStamp);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 


--
-- Alter table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AgentID` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `StationID` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN StationID StationID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LoginDate` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LoginDate LoginDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `LoginTime` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LoginTime LoginTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `LogoutDate` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LogoutDate LogoutDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `LogoutTime` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LogoutTime LogoutTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `SkillList` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN SkillList SkillList VARCHAR(4000) DEFAULT NULL;

--
-- Alter column `LoginInstanceID` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LoginInstanceID LoginInstanceID VARCHAR(4000) DEFAULT NULL;

--
-- Alter column `LogoutReason` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LogoutReason LogoutReason VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LogoutReasonCode` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  CHANGE COLUMN LogoutReasonCode LogoutReasonCode VARCHAR(100) DEFAULT NULL;

--
-- Change columns order on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
 MODIFY LogoutReason VARCHAR(100) DEFAULT NULL AFTER LoginInstanceID;
ALTER TABLE agt_agent_timetrack 
 MODIFY LogoutReasonCode VARCHAR(100) DEFAULT NULL AFTER LogoutReason;

--
-- Create index `IX_N_AGT_Agent_TimeTrack_AgentID` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  ADD INDEX IX_N_AGT_Agent_TimeTrack_AgentID(AgentID);

--
-- Create index `IX_N_AGT_Agent_TimeTrack_LoginDateTime` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  ADD INDEX IX_N_AGT_Agent_TimeTrack_LoginDateTime(LoginDate, LoginTime);

--
-- Create index `IX_N_AGT_Agent_TimeTrack_LogoutDateTime` on table `agt_agent_timetrack`
--
ALTER TABLE agt_agent_timetrack 
  ADD INDEX IX_N_AGT_Agent_TimeTrack_LogoutDateTime(LogoutDate, LogoutTime);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_aux_codes`
--
ALTER TABLE agt_aux_codes 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Name` on table `agt_aux_codes`
--
ALTER TABLE agt_aux_codes 
  CHANGE COLUMN Name Name VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Code` on table `agt_aux_codes`
--
ALTER TABLE agt_aux_codes 
  CHANGE COLUMN Code Code VARCHAR(100) DEFAULT NULL;

--
-- Create column `LastChangedBy` on table `agt_aux_codes`
--
ALTER TABLE agt_aux_codes 
  ADD COLUMN LastChangedBy VARCHAR(50) DEFAULT NULL;

--
-- Create column `LastChangedOn` on table `agt_aux_codes`
--
ALTER TABLE agt_aux_codes 
  ADD COLUMN LastChangedOn VARCHAR(20) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Location` on table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
  CHANGE COLUMN Location Location VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Message` on table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
  CHANGE COLUMN Message Message VARCHAR(4000) DEFAULT NULL;

--
-- Alter column `Status` on table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
  CHANGE COLUMN Status Status VARCHAR(10) DEFAULT NULL;

--
-- Alter column `LastChangedBy` on table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
  CHANGE COLUMN LastChangedBy LastChangedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedOn` on table `agt_broadcast_messages`
--
ALTER TABLE agt_broadcast_messages 
  CHANGE COLUMN LastChangedOn LastChangedOn VARCHAR(50) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Drop index `PRIMARY` from table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
   DROP PRIMARY KEY;

--
-- Alter table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AACC_SkillID` on table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
  CHANGE COLUMN AACC_SkillID AACC_SkillID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SkillName` on table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
  CHANGE COLUMN SkillName SkillName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `CM_SkillID` on table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
  CHANGE COLUMN CM_SkillID CM_SkillID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Channel` on table `agt_favourite_text_skills`
--
ALTER TABLE agt_favourite_text_skills 
  CHANGE COLUMN Channel Channel VARCHAR(20) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  MODIFY ID BIGINT(20) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
   DROP PRIMARY KEY;

--
-- Alter table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `UCID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN UCID UCID VARCHAR(30) DEFAULT NULL;

--
-- Alter column `AgentID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ConnectionHandle` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN ConnectionHandle ConnectionHandle VARCHAR(50) DEFAULT NULL;

--
-- Alter column `PhoneNumber` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN PhoneNumber PhoneNumber VARCHAR(50) DEFAULT NULL;

--
-- Alter column `VDN` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN VDN VDN VARCHAR(20) DEFAULT NULL;

--
-- Alter column `Queue` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN Queue Queue VARCHAR(20) DEFAULT NULL;

--
-- Alter column `QueuedDateTime` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN QueuedDateTime QueuedDateTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `AnsweredDateTime` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN AnsweredDateTime AnsweredDateTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `DisconnectedDateTime` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN DisconnectedDateTime DisconnectedDateTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `Status` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  CHANGE COLUMN Status Status VARCHAR(5) DEFAULT NULL;

--
-- Create index `IX_AGT_InboundACD_Calls_ConnectionHandle_QueuedDateTime` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  ADD INDEX IX_AGT_InboundACD_Calls_ConnectionHandle_QueuedDateTime(ConnectionHandle, QueuedDateTime);

--
-- Create index `IX_AGT_InboundACD_Calls_ConnectionHandle_Status` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  ADD INDEX IX_AGT_InboundACD_Calls_ConnectionHandle_Status(ConnectionHandle, Status);

--
-- Create index `IX_AGT_InboundACD_Calls_UCID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  ADD INDEX IX_AGT_InboundACD_Calls_UCID(UCID);

--
-- Create index `IX_InboundACD_Calls_ID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  ADD INDEX IX_InboundACD_Calls_ID(ID);

--
-- Create index `NonClusteredIndex_UCID_AGT_InboundACD_Calls` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  ADD INDEX NonClusteredIndex_UCID_AGT_InboundACD_Calls(UCID);

--
-- Alter column `ID` on table `agt_inboundacd_calls`
--
ALTER TABLE agt_inboundacd_calls 
  MODIFY ID BIGINT(20) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `AgentSkillMapID` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  MODIFY AgentSkillMapID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
   DROP PRIMARY KEY;

--
-- Drop column `AgentSkillMapID` from table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  DROP COLUMN AgentSkillMapID;

--
-- Alter table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Intent` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN Intent Intent VARCHAR(50) NOT NULL;

--
-- Alter column `Channel` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN Channel Channel VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AACCSkillName` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN AACCSkillName AACCSkillName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CMSkillName` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN CMSkillName CMSkillName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CMCheckerSkillName` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN CMCheckerSkillName CMCheckerSkillName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AACCCheckerSkillName` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  CHANGE COLUMN AACCCheckerSkillName AACCCheckerSkillName VARCHAR(50) DEFAULT NULL;

--
-- Create column `EmailAutoRespID` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  ADD COLUMN EmailAutoRespID INT(11) DEFAULT 0;

--
-- Create index `PRIMARY` on table `agt_intent_skill_map`
--
ALTER TABLE agt_intent_skill_map 
  ADD PRIMARY KEY (IncomingMailBox, Intent);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN Channel Channel VARCHAR(10) DEFAULT NULL;

--
-- Alter column `SessionID` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN SessionID SessionID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ServicedBy` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN ServicedBy ServicedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ServicedDate` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN ServicedDate ServicedDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `ServicedTime` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN ServicedTime ServicedTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `ServiceDescription` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  CHANGE COLUMN ServiceDescription ServiceDescription VARCHAR(250) DEFAULT NULL;

--
-- Create index `IX_AGT_Interaction_Service_History_SessionID` on table `agt_interaction_service_history`
--
ALTER TABLE agt_interaction_service_history 
  ADD INDEX IX_AGT_Interaction_Service_History_SessionID(SessionID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Drop index `PRIMARY` from table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
   DROP PRIMARY KEY;

--
-- Alter table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Language` on table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
  CHANGE COLUMN Language Language VARCHAR(50) NOT NULL;

--
-- Alter column `IVRNode` on table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
  CHANGE COLUMN IVRNode IVRNode VARCHAR(50) NOT NULL;

--
-- Alter column `VDN` on table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
  CHANGE COLUMN VDN VDN VARCHAR(20) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `agt_ivr_transfer_vdns`
--
ALTER TABLE agt_ivr_transfer_vdns 
  ADD PRIMARY KEY (Language, IVRNode);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Drop index `PRIMARY` from table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
   DROP PRIMARY KEY;

--
-- Alter table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `UCID` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN UCID UCID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Number` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN Number Number VARCHAR(20) DEFAULT NULL;

--
-- Alter column `DestinationType` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN DestinationType DestinationType VARCHAR(1) DEFAULT NULL;

--
-- Alter column `DialDate` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN DialDate DialDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `DialTime` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN DialTime DialTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `Agent` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN Agent Agent VARCHAR(10) DEFAULT NULL;

--
-- Alter column `ConnectDate` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN ConnectDate ConnectDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `ConnectTime` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN ConnectTime ConnectTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `DisconnectDate` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN DisconnectDate DisconnectDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `DisconnectTime` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN DisconnectTime DisconnectTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `Source` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN Source Source VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SourceID` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  CHANGE COLUMN SourceID SourceID VARCHAR(50) DEFAULT NULL;

--
-- Create index `IX_AGT_Outbound_Calls_UCID` on table `agt_outbound_calls`
--
ALTER TABLE agt_outbound_calls 
  ADD INDEX IX_AGT_Outbound_Calls_UCID(UCID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Name` on table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
  CHANGE COLUMN Name Name VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(50) DEFAULT NULL;

--
-- Create column `Channel` on table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
  ADD COLUMN Channel VARCHAR(20) DEFAULT NULL;

--
-- Create column `OrgUnit` on table `agt_sms_template_departments`
--
ALTER TABLE agt_sms_template_departments 
  ADD COLUMN OrgUnit INT(11) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Type` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN Type Type VARCHAR(20) DEFAULT NULL;

--
-- Alter column `RespTemplate` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN RespTemplate RespTemplate VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Intent` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN Intent Intent VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Name` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN Name Name VARCHAR(100) DEFAULT NULL;

--
-- Alter column `Text` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  CHANGE COLUMN Text Text VARCHAR(4000) DEFAULT NULL;

--
-- Create column `StartTime` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  ADD COLUMN StartTime VARCHAR(10) DEFAULT NULL;

--
-- Create column `EndTime` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  ADD COLUMN EndTime VARCHAR(10) DEFAULT NULL;

--
-- Create column `templatetype` on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
  ADD COLUMN templatetype INT(11) DEFAULT NULL;

--
-- Change columns order on table `agt_sms_templates`
--
ALTER TABLE agt_sms_templates 
 MODIFY Name VARCHAR(100) DEFAULT NULL AFTER LAST_CHANGED_ON;
ALTER TABLE agt_sms_templates 
 MODIFY Text VARCHAR(4000) DEFAULT NULL AFTER Name;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Name` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN Name Name VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Value` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN Value Value VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Type` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN Type Type VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TeamID` on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
  CHANGE COLUMN TeamID TeamID VARCHAR(5) DEFAULT NULL;

--
-- Change columns order on table `agt_speed_dial`
--
ALTER TABLE agt_speed_dial 
 MODIFY TeamID VARCHAR(5) DEFAULT NULL AFTER LAST_CHANGED_ON;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `TeamID` on table `agt_teams`
--
ALTER TABLE agt_teams 
  MODIFY TeamID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `agt_teams`
--
ALTER TABLE agt_teams 
   DROP PRIMARY KEY;

--
-- Alter table `agt_teams`
--
ALTER TABLE agt_teams 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `TeamName` on table `agt_teams`
--
ALTER TABLE agt_teams 
  CHANGE COLUMN TeamName TeamName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_teams`
--
ALTER TABLE agt_teams 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_teams`
--
ALTER TABLE agt_teams 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(100) DEFAULT NULL;

--
-- Create column `LevelHierarchy` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD COLUMN LevelHierarchy VARCHAR(30) DEFAULT NULL;

--
-- Create column `ParentID` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD COLUMN ParentID INT(11) DEFAULT NULL;

--
-- Create column `DisplayName` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD COLUMN DisplayName VARCHAR(4000) DEFAULT NULL;

--
-- Create column `LevelHierarchyID` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD COLUMN LevelHierarchyID INT(11) DEFAULT NULL;

--
-- Create column `IsDeleted` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD COLUMN IsDeleted BIT(1) NOT NULL DEFAULT b'0';

--
-- Change columns order on table `agt_teams`
--
ALTER TABLE agt_teams 
 MODIFY LAST_CHANGED_ON VARCHAR(100) DEFAULT NULL AFTER LAST_CHANGED_BY;

--
-- Create index `TeamID` on table `agt_teams`
--
ALTER TABLE agt_teams 
  ADD INDEX TeamID(TeamID);

--
-- Alter column `TeamID` on table `agt_teams`
--
ALTER TABLE agt_teams 
  MODIFY TeamID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Drop index `PRIMARY` from table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
   DROP PRIMARY KEY;

--
-- Alter table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `IsHoldVoiceCallOnChatCall` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN IsHoldVoiceCallOnChatCall IsHoldVoiceCallOnChatCall VARCHAR(50) DEFAULT NULL;

--
-- Alter column `IsSecondTextChatAutoAnswer` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN IsSecondTextChatAutoAnswer IsSecondTextChatAutoAnswer VARCHAR(50) DEFAULT NULL;

--
-- Alter column `IsTextChatAutoAnswer` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN IsTextChatAutoAnswer IsTextChatAutoAnswer VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TotalTabsAllowed` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN TotalTabsAllowed TotalTabsAllowed VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TotalChatTabsAllowed` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN TotalChatTabsAllowed TotalChatTabsAllowed VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TotalVoiceTabsAllowed` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN TotalVoiceTabsAllowed TotalVoiceTabsAllowed VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CRMName` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN CRMName CRMName VARCHAR(250) DEFAULT NULL;

--
-- Alter column `AgentID` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) NOT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AccessRole` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  CHANGE COLUMN AccessRole AccessRole VARCHAR(50) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `agt_tmacagentprofile`
--
ALTER TABLE agt_tmacagentprofile 
  ADD PRIMARY KEY (AgentID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `AuditTrailID` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  MODIFY AuditTrailID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `audittrail_report`
--
ALTER TABLE audittrail_report 
   DROP PRIMARY KEY;

--
-- Drop column `AuditTrailID` from table `audittrail_report`
--
ALTER TABLE audittrail_report 
  DROP COLUMN AuditTrailID;

--
-- Alter table `audittrail_report`
--
ALTER TABLE audittrail_report 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `TRANSACTION_NAME` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN TRANSACTION_NAME TRANSACTION_NAME VARCHAR(50) DEFAULT NULL;

--
-- Alter column `FUNCTIONNAME` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN FUNCTIONNAME FUNCTIONNAME VARCHAR(255) DEFAULT NULL;

--
-- Alter column `USER_ID` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN USER_ID USER_ID VARCHAR(250) DEFAULT NULL;

--
-- Alter column `TXN_DATE` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN TXN_DATE TXN_DATE VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TXN_TIME` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN TXN_TIME TXN_TIME VARCHAR(50) DEFAULT NULL;

--
-- Alter column `OLD_VALUES` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN OLD_VALUES OLD_VALUES LONGTEXT DEFAULT NULL;

--
-- Alter column `NEW_VALUES` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN NEW_VALUES NEW_VALUES LONGTEXT DEFAULT NULL;

--
-- Alter column `CHANGEREASON` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  CHANGE COLUMN CHANGEREASON CHANGEREASON VARCHAR(250) DEFAULT NULL;

--
-- Create column `ModuleName` on table `audittrail_report`
--
ALTER TABLE audittrail_report 
  ADD COLUMN ModuleName VARCHAR(255) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 


--
-- Alter column `CCLID` on table `ccl`
--
ALTER TABLE ccl 
  MODIFY CCLID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `ccl`
--
ALTER TABLE ccl 
   DROP PRIMARY KEY;

--
-- Drop column `CCLID` from table `ccl`
--
ALTER TABLE ccl 
  DROP COLUMN CCLID;

--
-- Alter table `ccl`
--
ALTER TABLE ccl 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Name` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Name Name VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CIF` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN CIF CIF VARCHAR(50) DEFAULT NULL;

--
-- Alter column `NRIC` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN NRIC NRIC VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AccountNumber` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN AccountNumber AccountNumber VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Email` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Email Email VARCHAR(50) DEFAULT NULL;

--
-- Alter column `PhoneNumber` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN PhoneNumber PhoneNumber VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ChatID` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN ChatID ChatID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Note` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Note Note VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Country` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Country Country VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Address` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Address Address VARCHAR(500) DEFAULT NULL;

--
-- Alter column `OtherPhoneNumbers` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN OtherPhoneNumbers OtherPhoneNumbers VARCHAR(100) DEFAULT NULL;

--
-- Alter column `Salutation` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Salutation Salutation VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Company` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN Company Company VARCHAR(100) DEFAULT NULL;

--
-- Alter column `OtherEmailAddresses` on table `ccl`
--
ALTER TABLE ccl 
  CHANGE COLUMN OtherEmailAddresses OtherEmailAddresses VARCHAR(200) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `CheckerAuditTrailID` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  MODIFY CheckerAuditTrailID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
   DROP PRIMARY KEY;

--
-- Drop column `revert_query` from table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  DROP COLUMN revert_query;

--
-- Drop column `CheckerAuditTrailID` from table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  DROP COLUMN CheckerAuditTrailID;

--
-- Alter table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `TRANSACTION_NAME` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN TRANSACTION_NAME TRANSACTION_NAME VARCHAR(50) DEFAULT NULL;

--
-- Alter column `FUNCTIONNAME` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN FUNCTIONNAME FUNCTIONNAME VARCHAR(255) DEFAULT NULL;

--
-- Alter column `USER_ID` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN USER_ID USER_ID VARCHAR(250) DEFAULT NULL;

--
-- Alter column `TXN_DATE` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN TXN_DATE TXN_DATE VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TXN_TIME` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN TXN_TIME TXN_TIME VARCHAR(50) DEFAULT NULL;

--
-- Alter column `OLD_VALUES` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN OLD_VALUES OLD_VALUES LONGTEXT DEFAULT NULL;

--
-- Alter column `NEW_VALUES` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN NEW_VALUES NEW_VALUES LONGTEXT DEFAULT NULL;

--
-- Alter column `CHANGEREASON` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN CHANGEREASON CHANGEREASON VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Status` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN Status Status VARCHAR(20) DEFAULT NULL;

--
-- Alter column `Query` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN Query Query LONGTEXT DEFAULT NULL;

--
-- Alter column `Review_Time` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN Review_Time Review_Time VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Review_Date` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN Review_Date Review_Date VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Comments` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  CHANGE COLUMN Comments Comments VARCHAR(4000) DEFAULT NULL;

--
-- Create column `Revert_Query` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD COLUMN Revert_Query LONGTEXT DEFAULT NULL;

--
-- Create column `VERSION_ID` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD COLUMN VERSION_ID INT(11) DEFAULT NULL;

--
-- Create column `Review_By` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD COLUMN Review_By VARCHAR(50) DEFAULT NULL;

--
-- Create column `OrgUnit` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD COLUMN OrgUnit INT(11) DEFAULT NULL;

--
-- Create column `ModuleName` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD COLUMN ModuleName VARCHAR(255) DEFAULT NULL;

--
-- Alter column `RequestId` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  MODIFY COLUMN RequestId BIGINT(20) NOT NULL AUTO_INCREMENT,
  ADD PRIMARY KEY (RequestId);

--
-- Change columns order on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
 MODIFY RequestId BIGINT(20) NOT NULL AUTO_INCREMENT AFTER Review_By;

--
-- Create index `IX_N_CHECKER_AUDITTRAIL_REPORT` on table `checker_audittrail_report`
--
ALTER TABLE checker_audittrail_report 
  ADD INDEX IX_N_CHECKER_AUDITTRAIL_REPORT(FUNCTIONNAME, OrgUnit, Status, TXN_DATE, TXN_TIME);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Type` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN Type Type VARCHAR(250) DEFAULT NULL;

--
-- Alter column `ReportName` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN ReportName ReportName VARCHAR(200) DEFAULT NULL;

--
-- Alter column `ReportPath` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN ReportPath ReportPath VARCHAR(1000) DEFAULT NULL;

--
-- Alter column `ReportGeneratedBy` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN ReportGeneratedBy ReportGeneratedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ReportGeneratedOn` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN ReportGeneratedOn ReportGeneratedOn VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ReportDownloadCount` on table `cmm_report_logs`
--
ALTER TABLE cmm_report_logs 
  CHANGE COLUMN ReportDownloadCount ReportDownloadCount VARCHAR(50) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
   DROP PRIMARY KEY;

--
-- Drop column `CHECKER_ACCESS` from table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  DROP COLUMN CHECKER_ACCESS;

--
-- Alter table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `ID` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN ID ID INT(11) DEFAULT NULL;

--
-- Alter column `RoleID` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN RoleID RoleID INT(11) NOT NULL;

--
-- Alter column `PageName` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN PageName PageName VARCHAR(100) NOT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(100) DEFAULT NULL;

--
-- Alter column `ADD_ACCESS` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN ADD_ACCESS ADD_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `EDIT_ACCESS` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN EDIT_ACCESS EDIT_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `DELETE_ACCESS` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN DELETE_ACCESS DELETE_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `EXPORT_ACCESS` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  CHANGE COLUMN EXPORT_ACCESS EXPORT_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Create column `USER_ACCESS` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  ADD COLUMN USER_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Change columns order on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
 MODIFY USER_ACCESS VARCHAR(10) DEFAULT NULL AFTER LAST_CHANGED_BY;

--
-- Create index `PRIMARY` on table `cmm_role_pages`
--
ALTER TABLE cmm_role_pages 
  ADD PRIMARY KEY (RoleID, PageName);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
   DROP PRIMARY KEY;

--
-- Alter table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `UserName` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN UserName UserName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `RoleID` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN RoleID RoleID VARCHAR(100) DEFAULT NULL;

--
-- Alter column `FirstName` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN FirstName FirstName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastName` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN LastName LastName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastLoginDate` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN LastLoginDate LastLoginDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `LastLoginTime` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN LastLoginTime LastLoginTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `CreatedDate` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN CreatedDate CreatedDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `CreatedTime` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN CreatedTime CreatedTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `CreatedBy` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  CHANGE COLUMN CreatedBy CreatedBy VARCHAR(50) DEFAULT NULL;

--
-- Create index `ID` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `cmm_user_details`
--
ALTER TABLE cmm_user_details 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `UMID` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  MODIFY UMID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
   DROP PRIMARY KEY;

--
-- Drop index `USER_ID` from table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
   DROP INDEX USER_ID;

--
-- Drop column `USER_NAME` from table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  DROP COLUMN USER_NAME;

--
-- Drop column `CHECKER_ACCESS` from table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  DROP COLUMN CHECKER_ACCESS;

--
-- Drop column `UMID` from table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  DROP COLUMN UMID;

--
-- Alter table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `USER_ID` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN USER_ID USER_ID VARCHAR(50) NOT NULL;

--
-- Alter column `FUNCTIONALITY` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN FUNCTIONALITY FUNCTIONALITY VARCHAR(100) NOT NULL;

--
-- Alter column `USER_ACCESS` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN USER_ACCESS USER_ACCESS VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(100) DEFAULT NULL;

--
-- Alter column `ADD_ACCESS` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN ADD_ACCESS ADD_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `EDIT_ACCESS` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN EDIT_ACCESS EDIT_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `DELETE_ACCESS` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN DELETE_ACCESS DELETE_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Alter column `EXPORT_ACCESS` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  CHANGE COLUMN EXPORT_ACCESS EXPORT_ACCESS VARCHAR(10) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `cmm_user_management`
--
ALTER TABLE cmm_user_management 
  ADD PRIMARY KEY (USER_ID, FUNCTIONALITY);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `cmm_users_timetrack`
--
ALTER TABLE cmm_users_timetrack 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `USER_ID` on table `cmm_users_timetrack`
--
ALTER TABLE cmm_users_timetrack 
  CHANGE COLUMN USER_ID USER_ID VARCHAR(50) NOT NULL;

--
-- Alter column `LAST_LOGGED_TIME` on table `cmm_users_timetrack`
--
ALTER TABLE cmm_users_timetrack 
  CHANGE COLUMN LAST_LOGGED_TIME LAST_LOGGED_TIME VARCHAR(50) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `cmm_users_timetrack`
--
ALTER TABLE cmm_users_timetrack 
  ADD PRIMARY KEY (USER_ID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `CallWorkCodeMapID` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  MODIFY CallWorkCodeMapID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
   DROP PRIMARY KEY;

--
-- Drop column `CallWorkCodeMapID` from table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  DROP COLUMN CallWorkCodeMapID;

--
-- Alter table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `WorkCodeName` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  CHANGE COLUMN WorkCodeName WorkCodeName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TeamID` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  CHANGE COLUMN TeamID TeamID INT(11) DEFAULT NULL;

--
-- Create column `WorkLevel` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  ADD COLUMN WorkLevel VARCHAR(50) DEFAULT NULL;

--
-- Create column `ParentID` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  ADD COLUMN ParentID INT(11) DEFAULT 0;

--
-- Create column `LastChangedBy` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  ADD COLUMN LastChangedBy VARCHAR(50) DEFAULT NULL;

--
-- Create column `LastChangedOn` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  ADD COLUMN LastChangedOn VARCHAR(20) DEFAULT NULL;

--
-- Alter column `WorkCode` on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
  MODIFY COLUMN WorkCode INT(11) NOT NULL AUTO_INCREMENT,
  ADD PRIMARY KEY (WorkCode);

--
-- Change columns order on table `gbl_callworkcodemapping`
--
ALTER TABLE gbl_callworkcodemapping 
 MODIFY WorkLevel VARCHAR(50) DEFAULT NULL FIRST;
ALTER TABLE gbl_callworkcodemapping 
 MODIFY WorkCode INT(11) NOT NULL AUTO_INCREMENT AFTER TeamID;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN Channel Channel VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SessionID` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN SessionID SessionID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CallerID` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN CallerID CallerID VARCHAR(100) DEFAULT NULL;

--
-- Alter column `WorkCode` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN WorkCode WorkCode INT(11) DEFAULT NULL;

--
-- Alter column `AgentID` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `InsertDate` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN InsertDate InsertDate VARCHAR(50) DEFAULT NULL;

--
-- Alter column `InsertTime` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  CHANGE COLUMN InsertTime InsertTime VARCHAR(50) DEFAULT NULL;

--
-- Create index `IX_N_GBL_CallWorkCodesz_WorkCode` on table `gbl_callworkcodes`
--
ALTER TABLE gbl_callworkcodes 
  ADD INDEX IX_N_GBL_CallWorkCodesz_WorkCode(WorkCode);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
   DROP PRIMARY KEY;

--
-- Alter table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN Channel Channel VARCHAR(10) DEFAULT NULL;

--
-- Alter column `SessionID` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN SessionID SessionID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `IntentName` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN IntentName IntentName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `IntentStatus` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN IntentStatus IntentStatus VARCHAR(10) DEFAULT NULL;

--
-- Alter column `LastServicedAgent` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN LastServicedAgent LastServicedAgent VARCHAR(50) DEFAULT NULL;

--
-- Alter column `OpenDate` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN OpenDate OpenDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `ClosedDate` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN ClosedDate ClosedDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `Comment` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN Comment Comment VARCHAR(250) DEFAULT NULL;

--
-- Alter column `OpenTime` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN OpenTime OpenTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `ClosedTime` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN ClosedTime ClosedTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `ChangeMode` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  CHANGE COLUMN ChangeMode ChangeMode VARCHAR(1) DEFAULT NULL;

--
-- Create index `IX_GBL_IntentMapping_ID` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  ADD INDEX IX_GBL_IntentMapping_ID(ID);

--
-- Create index `IX_GBL_IntentMapping_SessionID` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  ADD INDEX IX_GBL_IntentMapping_SessionID(SessionID);

--
-- Alter column `ID` on table `gbl_intentmapping`
--
ALTER TABLE gbl_intentmapping 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `GblInteractionID` on table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  MODIFY GblInteractionID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
   DROP PRIMARY KEY;

--
-- Drop column `GblInteractionID` from table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  DROP COLUMN GblInteractionID;

--
-- Alter table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `SessionID` on table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  CHANGE COLUMN SessionID SessionID VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Name` on table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  CHANGE COLUMN Name Name VARCHAR(250) DEFAULT NULL;

--
-- Alter column `Value` on table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  CHANGE COLUMN Value Value VARCHAR(250) DEFAULT NULL;

--
-- Create index `IX_GBL_Interaction_CustomData` on table `gbl_interaction_customdata`
--
ALTER TABLE gbl_interaction_customdata 
  ADD INDEX IX_GBL_Interaction_CustomData(SessionID, Value);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
   DROP PRIMARY KEY;

--
-- Alter table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN Channel Channel VARCHAR(10) DEFAULT NULL;

--
-- Alter column `SessionID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN SessionID SessionID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `NRIC` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN NRIC NRIC VARCHAR(15) DEFAULT NULL;

--
-- Alter column `Email` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN Email Email VARCHAR(100) DEFAULT NULL;

--
-- Alter column `ChatID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN ChatID ChatID VARCHAR(100) DEFAULT NULL;

--
-- Alter column `CLID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN CLID CLID VARCHAR(20) DEFAULT NULL;

--
-- Alter column `CIF` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN CIF CIF VARCHAR(50) DEFAULT NULL;

--
-- Alter column `InteractionText` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN InteractionText InteractionText TEXT DEFAULT NULL;

--
-- Alter column `InteractionDate` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN InteractionDate InteractionDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `Direction` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN Direction Direction VARCHAR(3) DEFAULT NULL;

--
-- Alter column `InteractionTime` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN InteractionTime InteractionTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `InsertedBy` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN InsertedBy InsertedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `GroupID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN GroupID GroupID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SubType` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN SubType SubType VARCHAR(50) DEFAULT NULL;

--
-- Alter column `IsVerified` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN IsVerified IsVerified VARCHAR(2) DEFAULT NULL;

--
-- Alter column `CustomDataType` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN CustomDataType CustomDataType VARCHAR(20) DEFAULT NULL;

--
-- Alter column `CustomData` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  CHANGE COLUMN CustomData CustomData VARCHAR(4000) DEFAULT NULL;

--
-- Create index `IX_GBL_InteractionHistory_CIF` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_CIF(CIF);

--
-- Create index `IX_GBL_InteractionHistory_CLID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_CLID(CLID);

--
-- Create index `IX_GBL_InteractionHistory_Email` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_Email(Email);

--
-- Create index `IX_GBL_InteractionHistory_GroupID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_GroupID(GroupID);

--
-- Create index `IX_GBL_InteractionHistory_ID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_ID(ID);

--
-- Create index `IX_GBL_InteractionHistory_NRIC` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_NRIC(NRIC);

--
-- Create index `IX_GBL_InteractionHistory_SessionID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  ADD INDEX IX_GBL_InteractionHistory_SessionID(SessionID);

--
-- Alter column `ID` on table `gbl_interactionhistory`
--
ALTER TABLE gbl_interactionhistory 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
   DROP PRIMARY KEY;

--
-- Alter table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN Channel Channel VARCHAR(10) DEFAULT NULL;

--
-- Alter column `SessionID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN SessionID SessionID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `CLID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN CLID CLID VARCHAR(200) DEFAULT NULL;

--
-- Alter column `Intent` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN Intent Intent VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AgentID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN AgentID AgentID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `OpenDate` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN OpenDate OpenDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `OpenTime` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  CHANGE COLUMN OpenTime OpenTime VARCHAR(6) DEFAULT NULL;

--
-- Create index `ID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `gbl_openintents`
--
ALTER TABLE gbl_openintents 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `UCID` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN UCID UCID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Segment` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN Segment Segment VARCHAR(10) DEFAULT NULL;

--
-- Alter column `PhoneNumber` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN PhoneNumber PhoneNumber VARCHAR(30) DEFAULT NULL;

--
-- Alter column `LastMenu` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN LastMenu LastMenu VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LastMenu_2` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN LastMenu_2 LastMenu_2 VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LastMenu_3` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN LastMenu_3 LastMenu_3 VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LastMenu_4` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN LastMenu_4 LastMenu_4 VARCHAR(100) DEFAULT NULL;

--
-- Alter column `AccountNumber` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN AccountNumber AccountNumber VARCHAR(20) DEFAULT NULL;

--
-- Alter column `DNIS` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN DNIS DNIS VARCHAR(30) DEFAULT NULL;

--
-- Alter column `InsertDate` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN InsertDate InsertDate VARCHAR(8) DEFAULT NULL;

--
-- Alter column `SpeechKeywords` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN SpeechKeywords SpeechKeywords VARCHAR(4000) DEFAULT NULL;

--
-- Alter column `InsertTime` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN InsertTime InsertTime VARCHAR(6) DEFAULT NULL;

--
-- Alter column `TPIN_Verified` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN TPIN_Verified TPIN_Verified VARCHAR(10) DEFAULT NULL;

--
-- Alter column `OTP_Verified` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN OTP_Verified OTP_Verified VARCHAR(50) DEFAULT NULL;

--
-- Alter column `VB_Verified` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN VB_Verified VB_Verified VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Verbal_Verified` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN Verbal_Verified Verbal_Verified VARCHAR(30) DEFAULT NULL;

--
-- Alter column `TRANSFER_VDN` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN TRANSFER_VDN TRANSFER_VDN VARCHAR(50) DEFAULT NULL;

--
-- Alter column `UUI` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN UUI UUI VARCHAR(200) DEFAULT NULL;

--
-- Alter column `CustomData` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  CHANGE COLUMN CustomData CustomData VARCHAR(4000) DEFAULT NULL;

--
-- Create index `IX_IVR_Call_Active_InsertDate` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  ADD INDEX IX_IVR_Call_Active_InsertDate(InsertDate);

--
-- Create index `IX_IVR_Call_Active_InsertTime` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  ADD INDEX IX_IVR_Call_Active_InsertTime(InsertTime);

--
-- Create index `IX_IVR_Call_Active_UCID` on table `ivr_call_active`
--
ALTER TABLE ivr_call_active 
  ADD INDEX IX_IVR_Call_Active_UCID(UCID);
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `IvrIwTransactionMapID` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  MODIFY IvrIwTransactionMapID MEDIUMINT(9) NOT NULL;

--
-- Drop index `PRIMARY` from table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
   DROP PRIMARY KEY;

--
-- Drop column `Language` from table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  DROP COLUMN Language;

--
-- Drop column `DNIS` from table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  DROP COLUMN DNIS;

--
-- Drop column `IvrIwTransactionMapID` from table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  DROP COLUMN IvrIwTransactionMapID;

--
-- Alter table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN Channel Channel VARCHAR(10) NOT NULL;

--
-- Alter column `InputTag` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN InputTag InputTag VARCHAR(100) NOT NULL;

--
-- Alter column `ConfidenceThreshold` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN ConfidenceThreshold ConfidenceThreshold VARCHAR(10) DEFAULT NULL;

--
-- Alter column `DestinationAction` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN DestinationAction DestinationAction VARCHAR(50) NOT NULL;

--
-- Alter column `DestinationNode` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN DestinationNode DestinationNode VARCHAR(100) NOT NULL;

--
-- Alter column `DialogState` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN DialogState DialogState VARCHAR(100) NOT NULL;

--
-- Alter column `Product` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN Product Product VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Intent` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN Intent Intent VARCHAR(100) NOT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `ivr_iw_transition_map`
--
ALTER TABLE ivr_iw_transition_map 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(100) DEFAULT NULL;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
   DROP PRIMARY KEY;

--
-- Alter table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `ID` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN ID ID BIGINT(20) NOT NULL;

--
-- Alter column `ReportName` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN ReportName ReportName VARCHAR(250) DEFAULT NULL;

--
-- Alter column `ReportQuery` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN ReportQuery ReportQuery LONGTEXT NOT NULL;

--
-- Alter column `ReportCreatedBy` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN ReportCreatedBy ReportCreatedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ReportCreatedOn` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN ReportCreatedOn ReportCreatedOn VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedBy` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN LastChangedBy LastChangedBy VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LastChangedOn` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  CHANGE COLUMN LastChangedOn LastChangedOn VARCHAR(50) DEFAULT NULL;

--
-- Create column `ReportType` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  ADD COLUMN ReportType VARCHAR(50) DEFAULT NULL;

--
-- Create index `PRIMARY` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  ADD PRIMARY KEY (ID);

--
-- Alter column `ID` on table `ocmcustomreport`
--
ALTER TABLE ocmcustomreport 
  MODIFY ID BIGINT(20) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  MODIFY ID BIGINT(20) NOT NULL;

--
-- Drop index `PRIMARY` from table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
   DROP PRIMARY KEY;

--
-- Alter table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `LoginInstanceID` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  CHANGE COLUMN LoginInstanceID LoginInstanceID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AgentId` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  CHANGE COLUMN AgentId AgentId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `StationId` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  CHANGE COLUMN StationId StationId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LogTime` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  CHANGE COLUMN LogTime LogTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `Data` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  CHANGE COLUMN Data Data VARCHAR(4000) DEFAULT NULL;

--
-- Create index `ID` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `tmac_cti_events`
--
ALTER TABLE tmac_cti_events 
  MODIFY ID BIGINT(20) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  MODIFY ID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
   DROP PRIMARY KEY;

--
-- Drop column `SessionId` from table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  DROP COLUMN SessionId;

--
-- Alter table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `AgentId` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN AgentId AgentId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Action` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN Action Action VARCHAR(50) DEFAULT NULL;

--
-- Alter column `ActionTime` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN ActionTime ActionTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `ActionResult` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN ActionResult ActionResult VARCHAR(5) DEFAULT NULL;

--
-- Alter column `Details` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN Details Details LONGTEXT DEFAULT NULL;

--
-- Alter column `LoginInstanceID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  CHANGE COLUMN LoginInstanceID LoginInstanceID VARCHAR(50) DEFAULT NULL;

--
-- Create column `SessionID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  ADD COLUMN SessionID VARCHAR(50) DEFAULT NULL;

--
-- Create column `InsertedDateTime` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  ADD COLUMN InsertedDateTime DATETIME(3) NOT NULL DEFAULT current_timestamp(3);

--
-- Create index `IX_N_TMAC_Interaction_Actions_SessionID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  ADD INDEX IX_N_TMAC_Interaction_Actions_SessionID(SessionID);

--
-- Create index `ID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `tmac_interaction_actions`
--
ALTER TABLE tmac_interaction_actions 
  MODIFY ID INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `ID` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  MODIFY ID BIGINT(20) NOT NULL;

--
-- Drop index `PRIMARY` from table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
   DROP PRIMARY KEY;

--
-- Alter table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `Channel` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN Channel Channel VARCHAR(20) DEFAULT NULL;

--
-- Alter column `SubChannel` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN SubChannel SubChannel VARCHAR(20) DEFAULT NULL;

--
-- Alter column `SessionId` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN SessionId SessionId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SubSessionId` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN SubSessionId SubSessionId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `AgentId` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN AgentId AgentId VARCHAR(50) DEFAULT NULL;

--
-- Alter column `InteractionId` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN InteractionId InteractionId VARCHAR(5) DEFAULT NULL;

--
-- Alter column `CreatedDateTime` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN CreatedDateTime CreatedDateTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `CreatedReason` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN CreatedReason CreatedReason VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Skill` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN Skill Skill VARCHAR(20) DEFAULT NULL;

--
-- Alter column `Direction` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN Direction Direction VARCHAR(5) DEFAULT NULL;

--
-- Alter column `User` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN User User VARCHAR(50) NOT NULL;

--
-- Alter column `UserName` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN UserName UserName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `Dnis` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN Dnis Dnis VARCHAR(50) DEFAULT NULL;

--
-- Alter column `DnisName` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN DnisName DnisName VARCHAR(50) DEFAULT NULL;

--
-- Alter column `TrasnferConferenceFromAgent` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN TrasnferConferenceFromAgent TrasnferConferenceFromAgent VARCHAR(10) DEFAULT NULL;

--
-- Alter column `TrasnferConferenceFromInteraction` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN TrasnferConferenceFromInteraction TrasnferConferenceFromInteraction VARCHAR(5) DEFAULT NULL;

--
-- Alter column `OtherData` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN OtherData OtherData LONGTEXT DEFAULT NULL;

--
-- Alter column `ClosedDateTime` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN ClosedDateTime ClosedDateTime VARCHAR(14) DEFAULT NULL;

--
-- Alter column `ClosedReason` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN ClosedReason ClosedReason VARCHAR(20) DEFAULT NULL;

--
-- Alter column `CALLCONNECTEDTIME` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN CALLCONNECTEDTIME CALLCONNECTEDTIME VARCHAR(14) DEFAULT NULL;

--
-- Alter column `CALLDISCONNECTEDTIME` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN CALLDISCONNECTEDTIME CALLDISCONNECTEDTIME VARCHAR(14) DEFAULT NULL;

--
-- Alter column `CALLTYPE` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN CALLTYPE CALLTYPE VARCHAR(10) DEFAULT NULL;

--
-- Alter column `TrasnferToAgent` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN TrasnferToAgent TrasnferToAgent VARCHAR(10) DEFAULT NULL;

--
-- Alter column `ConferenceToAgentList` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN ConferenceToAgentList ConferenceToAgentList VARCHAR(100) DEFAULT NULL;

--
-- Alter column `LoginInstanceID` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN LoginInstanceID LoginInstanceID VARCHAR(100) DEFAULT NULL;

--
-- Alter column `AgentComment` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  CHANGE COLUMN AgentComment AgentComment VARCHAR(2000) DEFAULT NULL;

--
-- Create column `CallStatus` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD COLUMN CallStatus INT(11) DEFAULT NULL;

--
-- Create column `Intent` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD COLUMN Intent VARCHAR(250) DEFAULT NULL;

--
-- Create column `DisconnectedBy` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD COLUMN DisconnectedBy VARCHAR(10) DEFAULT NULL;

--
-- Create column `DisconnectReason` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD COLUMN DisconnectReason VARCHAR(25) DEFAULT NULL;

--
-- Create column `CallRefId` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD COLUMN CallRefId VARCHAR(50) DEFAULT NULL;

--
-- Create index `ID` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  ADD INDEX ID(ID);

--
-- Alter column `ID` on table `tmac_interactions`
--
ALTER TABLE tmac_interactions 
  MODIFY ID BIGINT(20) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `id` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  MODIFY id INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
   DROP PRIMARY KEY;

--
-- Alter table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `startTime` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN startTime startTime VARCHAR(20) DEFAULT NULL;

--
-- Alter column `endTime` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN endTime endTime VARCHAR(20) DEFAULT NULL;

--
-- Alter column `color` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN color color VARCHAR(100) DEFAULT NULL;

--
-- Alter column `colorcode` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN colorcode colorcode VARCHAR(10) DEFAULT NULL;

--
-- Alter column `lastchangedby` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN lastchangedby lastchangedby VARCHAR(50) DEFAULT NULL;

--
-- Alter column `lastchangedon` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  CHANGE COLUMN lastchangedon lastchangedon VARCHAR(50) DEFAULT NULL;

--
-- Create index `id` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  ADD INDEX id(id);

--
-- Alter column `id` on table `tmac_wait_time_color_config`
--
ALTER TABLE tmac_wait_time_color_config 
  MODIFY id INT(11) NOT NULL AUTO_INCREMENT;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 


--
-- Drop procedure `Get_AuditTrailOCMReport`
--
DROP PROCEDURE Get_AuditTrailOCMReport;

DELIMITER $$

--
-- Create procedure `Get_AuditTrailOCMReport`
--
CREATE PROCEDURE Get_AuditTrailOCMReport(
	p_startdate varchar(20),
	p_enddate varchar(20),
	p_SearchString LONGTEXT,
	p_SortString VARCHAR(1000),
	p_PageNo INT /* = 1 */,
	p_PageSize INT /* = 10 */,
	OUT p_TotalPageSize INT )
BEGIN
DECLARE v_DataFromDate VARCHAR(50);
DECLARE v_DataToDate VARCHAR(50);

Declare v_lPageNbr INT;
Declare v_lPageSize INT;
Declare v_lFirstRec INT;
Declare v_lLastRec INT;
Declare v_lTotalRows INT;
Declare v_CombineQuery LONGTEXT;
Declare v_MAIN LONGTEXT;
Declare v_DRILL LONGTEXT;
Declare v_ToatlCount LONGTEXT;
Declare v_SortValue LONGTEXT;
		
BEGIN		
	SET p_TotalPageSize = 0;
	SET v_lPageNbr = p_PageNo;
	SET v_lPageSize = p_PageSize;
	SET v_DataFromDate = p_startdate;
	SET v_DataToDate = p_enddate;
	SET v_lFirstRec = ( v_lPageNbr - 1 ) * v_lPageSize;
	SET v_lLastRec = ( v_lPageNbr * v_lPageSize + 1 );
	SET v_SortValue =  CASE WHEN IFNULL(p_SortString,'')='' THEN 'ORDER BY `DateTime` ASC' ELSE p_SortString END;

			SET v_MAIN=CONCAT('SELECT TXN_DATE,TRANSACTION_NAME AS `Transaction`,FUNCTIONNAME AS `Function`,CONCAT(TXN_DATE,'' '',TXN_TIME) AS `DateTime`,
			OLD_VALUES AS OldValues,NEW_VALUES as NewValues,USER_ID AS UserID,concat(IFNULL(A.FirstName,''NA''),'' '', IFNULL(A.LastName,'''')) as UserName,
			IFNULL(CONVERT(B.UserName, CHAR(30)),''NA'') AS SupervisorID,	A.TeamID,CHANGEREASON AS ChangeReason,`ModuleName` 
			FROM AUDITTRAIL_REPORT ATR LEFT JOIN `AGT_Agent` A 
			ON LOWER(SUBSTRING(ATR.USER_ID,LOCATE(''\\\\'',ATR.USER_ID)+1,CHAR_LENGTH(RTRIM(ATR.USER_ID)))) = LOWER(A.UserName) 
			and IFNULL(A.IsDeleted,0) = 0 and IFNULL(A.IsActive,1) = 1 
			LEFT JOIN `AGT_Agent` B ON A.PrimarySupervisorID = B.ID and IFNULL(B.IsDeleted,0) = 0 and IFNULL(B.IsActive,1) = 1 
			WHERE CONCAT(TXN_DATE,'' '',TXN_TIME) >=''',v_DataFromDate,''' 
			AND CONCAT(TXN_DATE,'' '',TXN_TIME) <= ''',v_DataToDate ,'''');
	      
			SET v_CombineQuery=CONCAT(' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(', v_SortValue ,') RowNumber, table1.* FROM  (',v_MAIN,'
			) AS table1  WHERE 1=1',p_SearchString,'
			)As tabl1 WHERE 1=1 AND RowNumber > ',CONVERT(v_lFirstRec, CHAR),' AND RowNumber < ',CONVERT(v_lLastRec, CHAR));
         
			SET v_ToatlCount = CONCAT('SELECT COUNT(*) INTO @x FROM(',v_MAIN,')AS table1 Where 1=1  AND (`DateTime` >= ''',v_DataFromDate,''' AND `DateTime` <=''',v_DataToDate,''') ',p_SearchString); -- +' '+@SortString
			
			SET @stmt_str = v_CombineQuery;
			PREPARE stmt FROM @stmt_str;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			
			SET @stmt_strtot = v_ToatlCount;
			PREPARE stmtTot FROM @stmt_strtot;
			EXECUTE stmtTot;
			DEALLOCATE PREPARE stmtTot;
			
			SET p_TotalPageSize :=  @x;
			SELECT	p_TotalPageSize as 'TotalPageSize';
END;
END
$$

DELIMITER ;
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Drop index `PRIMARY` from table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
   DROP PRIMARY KEY;

--
-- Alter table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `SkillID` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  CHANGE COLUMN SkillID SkillID VARCHAR(50) DEFAULT NULL;

--
-- Alter column `SkillName` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  CHANGE COLUMN SkillName SkillName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `VDN` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  CHANGE COLUMN VDN VDN VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_BY` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  CHANGE COLUMN LAST_CHANGED_BY LAST_CHANGED_BY VARCHAR(50) DEFAULT NULL;

--
-- Alter column `LAST_CHANGED_ON` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  CHANGE COLUMN LAST_CHANGED_ON LAST_CHANGED_ON VARCHAR(50) DEFAULT NULL;

--
-- Create column `Channel` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  ADD COLUMN Channel VARCHAR(20) DEFAULT NULL;

--
-- Create column `ID` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  ADD COLUMN ID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT;

--
-- Create index `ID` on table `agt_favourite_voice_skills`
--
ALTER TABLE agt_favourite_voice_skills 
  ADD INDEX ID(ID);
  
  
 
 
  
  
 -- ----------------------------------------- END OF ONE TABLE ------------------------------------------- 
 
 

--
-- Alter column `RoleID` on table `cmm_roles`
--
ALTER TABLE cmm_roles 
  MODIFY RoleID INT(11) NOT NULL;

--
-- Drop index `PRIMARY` from table `cmm_roles`
--
ALTER TABLE cmm_roles 
   DROP PRIMARY KEY;

--
-- Alter table `cmm_roles`
--
ALTER TABLE cmm_roles 
CHARACTER SET utf8mb4,
COLLATE utf8mb4_general_ci;

--
-- Alter column `RoleName` on table `cmm_roles`
--
ALTER TABLE cmm_roles 
  CHANGE COLUMN RoleName RoleName VARCHAR(100) DEFAULT NULL;

--
-- Alter column `RoleID` on table `cmm_roles`
--
ALTER TABLE cmm_roles 
  CHANGE COLUMN RoleID RoleID INT(11) NOT NULL DEFAULT 0;

--
-- Create column `OrgUnit` on table `cmm_roles`
--
ALTER TABLE cmm_roles 
  ADD COLUMN OrgUnit INT(11) DEFAULT NULL;

-- -- Skipping this due to an error. Similar query in the next one
-- 
-- --
-- -- Create column `ID` on table `cmm_roles`
-- --
-- ALTER TABLE cmm_roles 
--   ADD COLUMN ID INT(11) NOT NULL AUTO_INCREMENT;

--
-- Change columns order on table `cmm_roles`
--
ALTER TABLE cmm_roles 
 ADD ID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT FIRST;
ALTER TABLE cmm_roles 
 MODIFY RoleName VARCHAR(100) DEFAULT NULL AFTER ID;

--
-- Create index `ID` on table `cmm_roles`
--
ALTER TABLE cmm_roles 
  ADD INDEX ID(ID);